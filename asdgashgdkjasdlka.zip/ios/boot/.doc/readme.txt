一，独立启动说明
	在linux环境下，启动一个本地的erlang虚拟机环境，用于独立运行指定的业务逻辑。
二，独立启动相关文件
	1.启动脚本
		boot/standalone/start.sh，是用于启动erlang虚拟机环境的脚本，更新和启动时注意修改脚本中的本地ip, 本地ip一般是指本地服务器的LAN ip。
	2.sasl.log
		boot/standalone/sasl.log，是erlang虚拟机环境的底层运行日志，一般记录了从启动到关闭时进程的相关状态信息，以及底层的异常信息。
		正常情况下，执行启动脚本后，sasl.log将会有记录，类似=PROGRESS REPORT==== 26-Oct-2011::10:28:16 ===开头的记录是正常的日志，
		除此之外的日志表示异常日志，异常日志不一定都是业务逻辑的异常。
	3.erl_crash.dump
		boot/standalone/erl_crash.dump，崩溃日志，当erlang虚拟机崩溃后，会生成。
三，启动注意事项
	1.启动前请确认整个工作目录的用户组是否一致，是否对整个工作目录有读，写和执行的权限
	2.执行start.sh后，观察erlang虚拟机进程是否存在，erlang虚拟机进程名一般为beam.smp。
	如存在，则观察beam.smp进程的cpu消耗，当数据库比较大时，刚启动后，beam.smp进程会有一定时间内会大量占用cpu，这个情况是正常的，等数据库加载完毕后会恢复正常的cpu占用，大概是0% - 1%之间。
	3.当beam.smp进程创建并加载数据库成功后，需要观察sasl.log日志看是否有异常日志出现。
	另外查看是否有erl_crash.dump出现，如果erl_crash.dump出现说明beam.smp进程已经异常结束，可能是比较严重的配置或环境问题。
	还有可观察log/目录下的形如boot.log.日期的日志，查找日志最接近的日志，打开查看是否有类似如下的日志条目:
	2011-10-26 10:22:22 dfgs_gc@192.168.1.36 <0.2.0> dfgs_gc main  info startup/2, load main application ok, main:<0.46.0>, apps: [{kernel,
                                                            "ERTS  CXC 138 10",
                                                            "2.14.3"},
                                                           {crypto,
                                                            "CRYPTO version 2",
                                                            "2.0.2.1"},
                                                           {sasl,
                                                            "SASL  CXC 138 11",
                                                            "2.1.9.3"},
                                                           {stdlib,
                                                            "ERTS  CXC 138 10",
                                                            "1.17.3"}]
	2011-10-26 10:22:22 dfgs_gc@192.168.1.36 <0.2.0> dfgs_gc main  info startup/2, user script eval ok, file: "user.config"
	当启动时，会在形如boot.log.日期的日志中生成类似以上条目的日志，正常启动时应该只有以上的两条记录。
