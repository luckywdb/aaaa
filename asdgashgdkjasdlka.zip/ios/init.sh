#引入服务器配置
source ./work_dir.info
#进入游戏根目录
cd $server_root
cd "db"
rm -rf bi
rm -rf game_center
rm -rf game_app
rm -rf game_test
cd "game"
#开启扩展通配符
shopt -s  extglob
#删除文件夹,除了identity不删
rm -rf !(identity)
