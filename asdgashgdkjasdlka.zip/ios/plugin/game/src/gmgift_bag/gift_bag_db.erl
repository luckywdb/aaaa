%%礼包，GM工具动态生成礼包，礼包奖励内容为游戏已有资源，礼包非道具
%%礼包格式[{id,1001},{award,[{money,100},{rmb,10},{prop,{10001,1}},{prop,{10002,2}}]},{describe1,"aa"},{describe2,"bb"},...]
-module(gift_bag_db).

%%%=======================STATEMENT====================
-description("gift_bag_db").
-copyright("seasky,www.seasky.cn").
-author("zhj,zhoujie@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_gift_bag/2, set_gift_bag/3, del_gift_bag/2, award_gift_bag/3, award_gift_bag/4]).
-export([reads/2, iterate/1, get_all/1, get_all/3, convert_annex/2, fore_gift_bag/2]).

%%%=======================INCLUDE======================
%%%=======================RECORD=======================

%%%=======================DEFINE=======================


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% Func: get_gift_bag/2
%% Description: 获得礼包 
%% Returns: [{id,1001},{award,[{money,100},{rmb,10},{prop,{10001,1}},{prop,10002,2}]},{describe1,"aa"},{describe2,"bb"},...]
%% Arg: GiftBagId礼包id
%% ----------------------------------------------------
get_gift_bag(Src, GiftBagId) ->
    Table = game_lib:get_table(Src, 'gift_bag'),
    z_db_lib:get(Table, GiftBagId, []).

%% ----------------------------------------------------
%% Func: set_gift_bag/3
%% Description: 设置礼包 
%% Returns: ok
%% Arg: GiftBagId礼包id
%% Arg: GiftBag礼包
%% ----------------------------------------------------
set_gift_bag(Src, GiftBagId, GiftBag) ->
    Table = game_lib:get_table(Src, 'gift_bag'),
    z_db_lib:update(Table, GiftBagId, GiftBag).

%% ----------------------------------------------------
%% Func: del_gift_bag/2
%% Description: 删除礼包 
%% Returns: ok
%% Arg: GiftBagId礼包id
%% ----------------------------------------------------
del_gift_bag(Src, GiftBagId) ->
    Table = game_lib:get_table(Src, 'gift_bag'),
    z_db_lib:delete(Table, GiftBagId).

%% ----------------------------------------------------
%% Func: award_gift_bag/4
%% Description: 领取礼包 
%% Returns: none|List=award格式奖励内容 
%% Arg: RoleUid玩家id
%% Arg: GiftBagId礼包id
%% ----------------------------------------------------
award_gift_bag(Src, RoleUid, GiftBagId, Num) when is_integer(GiftBagId) ->
    award_gift_bag(Src, RoleUid, [{GiftBagId, Num}]);
award_gift_bag(Src, RoleUid, GiftBagIds, Num) when is_list(GiftBagIds) ->
    award_gift_bag(Src, RoleUid, [{GiftBagId, Num} || GiftBagId <- GiftBagIds]).
award_gift_bag(Src, RoleUid, [{_, _} | _] = List) -> %%发奖方法
    AwardList = lists:append([awarder_game:award_total_item(fore_gift_bag(Src, Gid), N) || {Gid, N} <- List]),
    awarder_game:give_award(Src, RoleUid, [], AwardList);
award_gift_bag(Src, RoleUid, GiftBagId) when is_integer(GiftBagId) ->
    award_gift_bag(Src, RoleUid, [{GiftBagId, 1}]);
award_gift_bag(Src, RoleUid, GiftBagIds) when is_list(GiftBagIds) ->
    award_gift_bag(Src, RoleUid, [{GiftBagId, 1} || GiftBagId <- GiftBagIds]).
%% ----------------------------------------------------
%% Func: reads/2
%% Description: 获得指定ID的礼包
%% Returns: List=一组礼包
%% ----------------------------------------------------
reads(_, []) ->
    [];
reads(Src, Uids) ->
    Table = game_lib:get_table(Src, 'gift_bag'),
    Reply = z_db_lib:gets(Table, Uids),
    [R || R <- Reply, R =/= 'none'].

%% ----------------------------------------------------
%% Func: iterate/1
%% Description: 礼包迭代器
%% Returns: Iterator
%% ----------------------------------------------------
iterate(Src) ->
    Table = game_lib:get_table(Src, 'gift_bag'),
    case zm_db_client:iterate(Table, descending, false) of
        {ok, Iterator} ->
            Iterator;
        {error, Reason} ->
            throw(Reason)
    end.
%% ----------------------------------------------------
%% Func: get_all/1
%% Description: 获得所有礼包
%% Returns: List
%% ----------------------------------------------------
get_all(Src) ->
    get_all(Src, gift_bag_db:iterate(Src), []).
%% ----------------------------------------------------
%% Func: get_all/3
%% Description: 获得所有礼包
%% Returns: List
%% Arg: Iterator 礼包迭代器
%% Arg: R 接收
%% ----------------------------------------------------
get_all(Src, Iterator, R) ->
    case zm_db_client:iterate_next(Iterator) of
        {ok, {Key, _, _}, NewIterator} ->
            get_all(Src, NewIterator, [get_gift_bag(Src, Key) | R]);
        over ->
            R;
        E ->
            E
    end.
%% ----------------------------------------------------
%% Func: convert_annex/2
%% Description: 礼包转换邮件附件
%% Returns: 邮件附件|none
%% ----------------------------------------------------
convert_annex(Src, GiftBagId) ->
    case lists:keyfind(award, 1, get_gift_bag(Src, GiftBagId)) of
        false ->
            [];
        {_, Awards} ->
            Awards
    end.
%% ----------------------------------------------------
%% Func: fore_gift_bag/2
%% Description: 礼包转换为前台需要格式
%% Returns: 前台格式|none
%% ----------------------------------------------------
fore_gift_bag(Src, GiftBagId) ->
    case lists:keyfind(award, 1, get_gift_bag(Src, GiftBagId)) of
        false ->
            [];
        {_, Awards} ->
            Awards
    end.


%%%===================LOCAL FUNCTIONS==================


