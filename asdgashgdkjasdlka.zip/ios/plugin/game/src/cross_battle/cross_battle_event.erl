-module(cross_battle_event).

%%%=======================STATEMENT====================
-description("cross_battle_event").
-copyright('youkia,www.youkia.net').
-author("shusong,shusong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([notify/4]).

%%%=======================INCLUDE======================
-include("../../../include/sign_key.hrl").
-include("../include/cross_battle.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=================EXPORTED FUNCTIONS=================

%% ----------------------------------------------------
%% @doc
%%		事件处理
%% @end
%% ----------------------------------------------------
notify(_A, Src, 'award_role_points', {RoleUid, Season, Wheel, Points, Items}) ->
    cross_battle_db:award_role_points(Src, Season, Wheel, RoleUid, Points, Items);
%%状态变化
notify(_A, Src, 'cross_battle_server_state_change', Args) ->
    %%在跨服战结束的时候存储标记，用于跨服抽卡次判定
    change_session(Src, Args),
    %%新状态是同步军团分组中时旧状态需要根据cbs的轮数来算
    {_, CrossBattleServer} = lists:keyfind('cbs', 1, Args),
    cross_battle_db:update_cache_cross_battle_server("cb_area", CrossBattleServer),
    State = z_lib:get_value(Args, 'state', 0),
    NState = z_lib:get_value(Args, 'nstate', 0),
    if
        State =:= ?CROSS_SERVER_STATE_STOP andalso NState =:= ?CROSS_SERVER_STATE_CLEAR ->
            cross_battle_db:clear_data(Src, cross_battle_server:get_term(CrossBattleServer), cross_battle_server:get_wheel(CrossBattleServer));
        true ->
            ok
    end.


%%%===================LOCAL FUNCTIONS==================
change_session(Src, Args) ->
    {_, State} = lists:keyfind('nstate', 1, Args),
    {_, CrossBattleServer} = lists:keyfind('cbs', 1, Args),
    Wheel = cross_battle_server:get_wheel(CrossBattleServer),
    AllWheel = length(?CROSS_BATTLE_ALL_WHEEL),
    %%当跨服战进入最后一轮的清理阶段时候把标记加1，表明抽卡赛季进入下一阶段
    if
        State =:= ?CROSS_SERVER_STATE_STOP andalso Wheel =:= AllWheel ->
            z_db_lib:update(game_lib:get_table(Src, 'cross_battle_execute'), session, 0,
                fun(_, Num) ->
                    {ok, ok, Num + 1}
                end, none);
        true ->
            'ok'
    end.