-module(cross_battle_lib).

%%%=======================STATEMENT====================
-description("军团跨服工具模块").
-copyright('youkia,www.youkia.net').
-author("shusong,shusong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_award_role_points_item/1, get_ld_num/2]).
-export([check/3, consume/3]).
-export([progress_corps_point_show/3, progress_role_point_show/3, select_same_server/3, resource_to_point/1]).

%%%=======================INCLUDE======================
-include("../include/rank.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      获得指定积分可领的奖励条目
%% @end
%% ----------------------------------------------------
get_award_role_points_item(Points) ->
    {_, AwardPointsList} = zm_config:get('cross_battle_info', 'award_role_points'),
    [AwardItem || {NeedPoint, AwardItem} <- AwardPointsList, Points >= NeedPoint].

%% ----------------------------------------------------
%% @doc
%%      检测
%% @end
%% ----------------------------------------------------
check({Rmb, _Goods}, 'transfer_consume', {'rmb', V}) ->
    rmb_lib:get_rmb(Rmb) >= V;
check({_Rmb, Goods}, 'transfer_consume', {'prop', {Sid, Num}}) ->
    storage_lib:get_count(Goods, Sid) >= Num;
check(_, _, _) ->
    false.

%% ----------------------------------------------------
%% @doc
%%      消耗
%% @end
%% ----------------------------------------------------
consume({Rmb, Goods}, 'transfer_consume', {'rmb', V}) ->
    {BiCs, NRmb} = rmb_lib:reduct_rmb(Rmb, V),
    {BiCs, {NRmb, Goods}};
consume({Rmb, Goods}, 'transfer_consume', {'prop', {Sid, Num}}) ->
    {BiCs, NGoods} = storage_lib:deduct_by_sid(Goods, {Sid, Num}),
    {BiCs, {Rmb, NGoods}};
consume(Tables, _, _) ->
    {'none', Tables}.
%% ----------------------------------------------------
%% @doc
%%      个人积分战况显示
%% @end
%% ----------------------------------------------------
progress_role_point_show(A, Src, Rankers) ->
    SelectRankers = case lists:keyfind('mfa', 1, A) of
        {M, F, A} ->
            M:F(A, Src, Rankers);
        _ ->
            Rankers
    end,
    Fun = fun({_ServerName, Rank, RoleName, CorpsName, MapId, Value, RoleUid}) ->
        {ShowName, ShowCorpsName} = case role_db:get_role_show(Src, RoleUid) of
            'none' ->
                {RoleName, CorpsName};
            RoleShow ->
                {role_show:get_name(RoleShow), role_show:get_corps_name(RoleShow)}
        end,
        {Rank, ShowName, ShowCorpsName, MapId rem 10000, Value}
    end,
    [Fun(SelectRanker) || SelectRanker <- SelectRankers].
%% ----------------------------------------------------
%% @doc
%%      军团战况显示
%% @end
%% ----------------------------------------------------
progress_corps_point_show(A, Src, Rankers) ->
    SelectRankers = case lists:keyfind('mfa', 1, A) of
        {_, {M, F, A_}} ->
            M:F(A_, Src, Rankers);
        _ ->
            Rankers
    end,
    Fun = fun({_ServerName, Rank, CorpsName, OwnerName, MapId, Value, CorpsUid}) ->
        ShowName = case corps_db:get_corps(Src, CorpsUid) of
            'none' ->
                CorpsName;
            Corps ->
                corps:get_name(Corps)
        end,
        {Rank, ShowName, OwnerName, MapId rem 10000, Value}
    end,
    [Fun(SelectRanker) || SelectRanker <- SelectRankers].
%% ----------------------------------------------------
%% @doc
%%      获得资源转换成积分
%% @end
%% ----------------------------------------------------
resource_to_point(Award) ->
    {_, Rates} = zm_config:get('cross_battle_info', 'resource_to_point'),
    Fun = fun({Type, Rate}, Point) ->
        case lists:keyfind(Type, 1, Award) of
            {_, Value} ->
                Value * Rate div 10000 + Point;
            _ ->
                Point
        end
    end,
    lists:foldl(Fun, 0, Rates).

%% ----------------------------------------------------
%% @doc
%%      获得玩家当前的抽卡次数(抽卡次数会在每次跨服赛季结束的时候清空抽取次数)
%% @end
%% ----------------------------------------------------
get_ld_num(Src, RoleUid) ->
    SetSession = z_db_lib:get(game_lib:get_table(Src, 'cross_battle_execute'), session, 0),
    z_db_lib:update(game_lib:get_table(Src, 'cross_battle_execute'), RoleUid, {0, 0},
        fun
            (_, {Session, Num}) when SetSession =:= Session ->
                {ok, Num};
            (_, _) ->
                {ok, 0, {SetSession, 0}}
        end, none).


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%      本服务器删选
%% @end
%% ----------------------------------------------------
select_same_server(_, Src, Rankers) ->
    ServerNames = args_db:get_all_servernames(Src),
    [Ranker || Ranker <- Rankers, lists:member(element(1, Ranker), ServerNames)].
