-module(cross_battle_role_db).

%%%=======================STATEMENT====================
-description("cross_battle_role").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    transfer_consume_res/3
]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================

%% ----------------------------------------------------
%% @doc  
%%        划拨元宝和goods
%% @end
%% ----------------------------------------------------
transfer_consume_res(GameSrc, RoleUid, Consumes) ->
    TableName = game_lib:get_table(GameSrc),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'rmb', RoleUid, rmb_lib:init()},
        {'goods', RoleUid, {}},
        {'cross_battle_transfer', RoleUid, []}]),
    Fun = fun(_, [{Index1, Rmb}, {Index2, Goods}, {Index3, RoleTransferAwards}]) ->
        Bool = game_lib:checks({'cross_battle_lib', 'check'}, {Rmb, Goods}, 'transfer_consume', Consumes),
        if
            Bool ->
                {BiCs, {NRmb, NGoods}} = game_lib:consumes({'cross_battle_lib', 'consume'}, {Rmb, Goods}, 'transfer_consume', Consumes),
                NRoleTransferAwards = awarder_game:merger(Consumes, RoleTransferAwards),
                {ok, {ok, BiCs}, [{Index1, NRmb}, {Index2, NGoods}, {Index3, NRoleTransferAwards}]};
            true ->
                throw(Bool)
        end
    end,
    z_db_lib:handle(TableName, Fun, {}, TableKeys).


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
