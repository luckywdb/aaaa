-module(cross_battle_role_rpc).

%%%=======================STATEMENT====================
-description("cross_battle_role_rpc").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    get_transfer_info/2,
    transfer_consume_res/2,
    repay_transfer_res/2,
    get_role_mail_content/7,
    get_corps_mail_content/7,
    get_award_rank_mail/7,
    get_pos_award/4,
    send_corps_award/7,
    send_role_award/7

]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%     获取转换信息
%% @end
%% ----------------------------------------------------
get_transfer_info(GameSrc, RoleUid) ->
    Rmb = rmb_db:get_all_rmb(GameSrc, RoleUid),
    StorageSet = storage_db:get_storage('goods', GameSrc, RoleUid),
    {_, PropSids} = zm_config:get('cross_battle_info', 'transfer_goods_sids'),
    PropSidCounts = lists:map(fun(PropSid) ->
        {PropSid, storage_lib:get_count(StorageSet, PropSid)}
                              end, PropSids),
    {ok, Rmb, PropSidCounts}.


%% ----------------------------------------------------
%% @doc
%%      划拨消耗
%% @end
%% ----------------------------------------------------
transfer_consume_res(GameSrc, {RoleUid, Consumes}) ->
    case cross_battle_role_db:transfer_consume_res(GameSrc, RoleUid, Consumes) of
        {ok, BiCs} ->
            zm_log:info(GameSrc, ?MODULE, 'transfer_consume_res', "transfer_consume_res",
                        [{'roleuid', RoleUid}, {'consume', Consumes}]),
            zm_event:notify(GameSrc, 'bi_cb_transfer_consume', [{'role_uid', RoleUid}, {'consume', BiCs}]),
            ok;
        Err ->
            Err
    end.
%% ----------------------------------------------------
%% @doc
%%      返还划拨
%% @end
%% ----------------------------------------------------
repay_transfer_res(GameSrc, {CorpsUid, RoleAwardList, RoleRankList, CorpsRankList}) ->
    MailType = award_source:get_source(?MODULE),
    Now = time_lib:now_second(),
    CrossBattleServer = cross_battle_db:get_cross_battle_server(GameSrc, "cb_area"),
    Season = cross_battle_server:get_term(CrossBattleServer),
    Wheel = cross_battle_server:get_wheel(CrossBattleServer),
    MaxWheel = size(cross_battle_server:get_wheel_time(CrossBattleServer)),
    zm_log:info(GameSrc, ?MODULE, 'repay_transfer_res', "repay_transfer_res_start",
                [{'corps_uid', CorpsUid}, {'role_award_list', RoleAwardList}]),
    %%物资返回
    TransferTable = game_lib:get_table(GameSrc, 'cross_battle_transfer'),
    lists:foreach(fun({RoleUid, AwardList}) ->
        TransferResList = z_db_lib:delete1(TransferTable, RoleUid, 'none'),
        case TransferResList =/= 'none' of
            true ->
                case AwardList =/= [] of
                    true ->
                        TRmb = z_lib:get_value(TransferResList, 'rmb', 0),
                        RRmb = z_lib:get_value(AwardList, 'rmb', 0),
                        NAwardList =
                            if
                                RRmb > TRmb andalso TRmb > 0 ->
                                    lists:keyreplace('rmb', 1, AwardList, {'rmb', TRmb});
                                RRmb > TRmb ->
                                    lists:keydelete('rmb', 1, AwardList);
                                true ->
                                    AwardList
                            end,
                        case NAwardList =/= [] of
                            true ->
                                Mail = mail:init({MailType, Now, 0, {3001}, {3001}, NAwardList}),
                                mail_db:send(GameSrc, RoleUid, Mail);
                            false ->
                                ok
                        end;
                    false ->
                        ok
                end;
            false ->
                ok
        end
                  end, RoleAwardList),
    zm_log:info(GameSrc, ?MODULE, 'repay_transfer_res', "repay_transfer_res_end",
                [{'corps_uid', CorpsUid}]),
    %%军团排行榜发奖邮件
    RoleUids = corps_db:get_corps_members(GameSrc, CorpsUid),
    RankAwardStateTable = game_lib:get_table(GameSrc, 'cross_battle_rank_award_state'),
    CorpsAwardFun = fun({RankType, Rank, Value}, CorpsUid_) ->
        %%更新排名信息
        cross_battle_db:update_cross_battle_rank(GameSrc, Season, Wheel, CorpsUid_, RankType, {Rank, Value}),
        case get_award_rank_mail(GameSrc, CorpsUid_, Season, Wheel, MaxWheel, RankType, Rank) of
            {MailTitle, MailContent, Award} ->
                lists:foreach(fun(RoleUid) ->
                    z_db_lib:update(RankAwardStateTable, RoleUid, [], fun(_, States) ->
                        case lists:keyfind({Season, Wheel, RankType}, 1, States) of
                            false ->
                                PowAward = get_pos_award(GameSrc, RoleUid, RankType, Rank),
                                TotalAward = award_lib:merger(PowAward, Award),
                                Mail = mail:init({MailType, Now, 0, MailTitle, MailContent, TotalAward}),
                                mail_db:send(GameSrc, RoleUid, Mail),
                                {ok, ok, [{Season, Wheel, RankType} | States]};
                            _ ->
                                {ok, ok}
                        end end,    [])

                              end, RoleUids),
                CorpsUid_;
            _ ->
                CorpsUid_
        end
                    end,
    lists:foldl(CorpsAwardFun, CorpsUid, CorpsRankList),
    %%个人排行榜发奖邮件
    RoleAwardFun = fun({RoleUid, RankInfos}, _) ->
        lists:foreach(fun({RankType, Rank, Value}) ->
            %%更新排名信息
            cross_battle_db:update_cross_battle_rank(GameSrc, Season, Wheel, RoleUid, RankType, {Rank, Value}),
            case get_award_rank_mail(GameSrc, RoleUid, Season, Wheel, MaxWheel, RankType, Rank) of
                {MailTitle, MailContent, Award} ->
                    z_db_lib:update(RankAwardStateTable, RoleUid, [], fun(_, States) ->
                        case lists:keyfind({Season, Wheel, RankType}, 1, States) of
                            false ->
                                Mail = mail:init({MailType, Now, 0, MailTitle, MailContent, Award}),
                                mail_db:send(GameSrc, RoleUid, Mail),
                                {ok, ok, [{Season, Wheel, RankType} | States]};
                            _ ->
                                {ok, ok}
                        end end,    []);
                _ ->
                    ok
            end
                      end, RankInfos)
                   end,
    lists:foldl(RoleAwardFun, [], RoleRankList),
    ok.
%% ----------------------------------------------------
%% @doc
%%      获得排名奖励邮件信息
%% @end
%% ----------------------------------------------------
get_award_rank_mail(Src, Uid, Season, Wheel, MaxWheel, RankType, Rank) ->
    case get_mail(Rank, rank_lib:get_type(RankType), RankType, Wheel, MaxWheel) of
        {{M, F, A}, Award} ->
            {Title, Content} = M:F(A, Src, Uid, RankType, Season, Wheel, Rank),
            {Title, Content, Award};
        _ ->
            'none'
    end.

%% ----------------------------------------------------
%% @doc
%%      获得职位奖励
%% @end
%% ----------------------------------------------------
get_pos_award(Src, RoleUid, RankType, Rank) ->
    RoleCorps = corps_db:get_role_corps(Src, RoleUid),
    Pos = role_corps:get_position(RoleCorps),
    case zm_config:get('cross_battle_award', {'corps_pos', RankType, Pos}) of
        {_, AwardList, AttendAward} ->
            case get_rank_award(Rank, AwardList) of
                [] ->
                    AttendAward;
                Award ->
                    Award
            end;
        _ ->
            []
    end.
%% ----------------------------------------------------
%% @doc  
%%      获得排名奖励
%% @end
%% ----------------------------------------------------
get_rank_award(Rank, [{MinRank, MaxRank, Award} | RankAwards]) ->
    if
        Rank >= MinRank andalso Rank =< MaxRank ->
            Award;
        true ->
            get_rank_award(Rank, RankAwards)
    end;
get_rank_award(_Rank, []) ->
    [].
%% ----------------------------------------------------
%% @doc
%%      获得邮件
%% @end
%% ----------------------------------------------------
get_mail(Rank, NewRankType, RankType, _Wheel, _MaxWheel) when NewRankType =/= RankType -> %%小组排行榜，每轮发奖
    get_mail_(Rank, RankType);
get_mail(Rank, _NewRankType, RankType, Wheel, MaxWheel) when Wheel >= MaxWheel ->    %%总榜，最后一轮发奖
    get_mail_(Rank, RankType);
get_mail(_Rank, _NewRankType, _RankType, _Wheel, _MaxWheel) ->
    none.

%% ----------------------------------------------------
%% @doc
%%      获得排名奖励
%% @end
%% ----------------------------------------------------
get_mail_(Rank, RankType) ->
    case zm_config:get('cross_battle_award', {'rank_type', RankType}) of
        {_, MFA, AwardList, AttendAward} ->
            case get_rank_award(Rank, AwardList) of
                [] ->
                    if
                        AttendAward =/= [] ->
                            {MFA, AttendAward};
                        true ->
                            'none'
                    end;
                RankAward ->
                    {MFA, RankAward}
            end
    end.
%% ----------------------------------------------------
%% @doc
%%      获得个人排行榜邮件内容
%% @end
%% ----------------------------------------------------
get_role_mail_content({Title, Content}, _Src, _Uid, RankType, Season, Wheel, 0) ->
    NewRankType = rank_lib:get_type(RankType),
    if
        NewRankType =:= RankType ->
            {{Title, Season}, {Content * 10 + 1, Season}};
        true ->
            {{Title, Season, Wheel}, {Content * 10 + 1, Season, Wheel}}
    end;
get_role_mail_content({Title, Content}, _Src, _Uid, RankType, Season, Wheel, Rank) ->
    NewRankType = rank_lib:get_type(RankType),
    if
        NewRankType =:= RankType ->
            {{Title, Season}, {Content, Season, Rank}};
        true ->
            {{Title, Season, Wheel}, {Content, Season, Wheel, Rank}}
    end.
%% ----------------------------------------------------
%% @doc
%%      获得军团排行榜邮件内容
%% @end
%% ----------------------------------------------------
get_corps_mail_content({Title, Content}, Src, Uid, RankType, Season, Wheel, 0) ->
    NewRankType = rank_lib:get_type(RankType),
    Corps = corps_db:get_corps(Src, Uid),
    CorpsName = corps:get_name(Corps),
    if
        NewRankType =:= RankType ->
            {{Title, Season}, {Content * 10 + 1, CorpsName, Season}};
        true ->
            {{Title, Season, Wheel}, {Content * 10 + 1, CorpsName, Season, Wheel}}
    end;
get_corps_mail_content({Title, Content}, Src, Uid, RankType, Season, Wheel, Rank) ->
    NewRankType = rank_lib:get_type(RankType),
    Corps = corps_db:get_corps(Src, Uid),
    CorpsName = corps:get_name(Corps),
    if
        NewRankType =:= RankType ->
            {{Title, Season}, {Content, CorpsName, Season, Rank}};
        true ->
            {{Title, Season, Wheel}, {Content, CorpsName, Season, Wheel, Rank}}
    end.


%% ----------------------------------------------------
%% @doc
%%      补发军团奖励(不检查是否发送过)
%% @end
%% ----------------------------------------------------
send_corps_award(GameSrc, CorpsUid, Season, Wheel, MaxWheel, RankType, Rank) ->
    RoleUids = corps_db:get_corps_members(GameSrc, CorpsUid),
    NowTime = time_lib:now_second(),
    case cross_battle_role_rpc:get_award_rank_mail(GameSrc, CorpsUid, Season, Wheel, MaxWheel, RankType, Rank) of
        {MailTitle, MailContent, Award} ->
            lists:foreach(fun(RoleUid) ->
                PowAward = get_pos_award(GameSrc, RoleUid, RankType, Rank),
                TotalAward = award_lib:merger(PowAward, Award),
                MailType = award_source:get_source(?MODULE),
                Mail = mail:init({MailType, NowTime, 0, MailTitle, MailContent, TotalAward}),
                mail_db:send(GameSrc, RoleUid, Mail),
                %%额外邮件补偿
                case zm_config:get('cross_battle_info', 'rank_error_award') of
                    {_, {ErrorTitle, ErrorContent, ErrorAward}} ->
                        ErrorMail = mail:init({award_source:get_source('corps_event'), NowTime, 0, {0, game_lib:get_language({mail_title, ErrorTitle})}, {0, game_lib:get_language({mail_content, ErrorContent})}, ErrorAward}),
                        mail_db:send(GameSrc, RoleUid, ErrorMail);
                    _ ->
                        ok
                end
                          end, RoleUids);
        _ ->
            ok
    end.
%% ----------------------------------------------------
%% @doc
%%      补发个人奖励
%% @end
%% ----------------------------------------------------
send_role_award(GameSrc, RoleUid, Season, Wheel, MaxWheel, RankType, Rank) ->
    case get_award_rank_mail(GameSrc, RoleUid, Season, Wheel, MaxWheel, RankType, Rank) of
        {MailTitle, MailContent, Award} ->
            MailType = award_source:get_source(?MODULE),
            Mail = mail:init({MailType, time_lib:now_second(), 0, MailTitle, MailContent, Award}),
            mail_db:send(GameSrc, RoleUid, Mail);
        _ ->
            ok
    end.