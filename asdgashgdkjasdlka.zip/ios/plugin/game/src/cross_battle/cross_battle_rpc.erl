-module(cross_battle_rpc).

%%%=======================STATEMENT====================
-description("cross_battle_rpc").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    sync_cross_battle_corps_rank/2,
    sync_cross_battle_corps_name/2,

    area_cross_battle_update/2,

    get_corps_cross_battle/2,
    get_role_cross_battle/2,

    area_cross_battle_sync_mcorps/2,

    cross_battle_progress/2,
    award_role_points/2,

    get_assault_info/2,
    send_assault_info/2,

    area_get_cross_battle_state/2
]).

%%%=======================INCLUDE======================
-include("../include/rank.hrl").
-include("../include/point.hrl").
-include("../include/cross_battle.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      同步军团分组信息
%% @end
%% ----------------------------------------------------
sync_cross_battle_corps_rank(GameSrc, {AreaNum, Term, Wheel, WheelTime, RankNum}) ->
    RankList = rank_get:get_rank_range(GameSrc, ?CORPS_POWER_ALL_RANK, 1, RankNum * 2),
    CNameValueList =
        z_lib:foreach(fun(Acc, {CorpsUid, Value}) ->
            Corps = corps_db:get_corps(GameSrc, CorpsUid),
            case Corps =/= 'none' of
                true ->
                    {ok, [{CorpsUid, corps:get_name(Corps), Value} | Acc]};
                false ->
                    {ok, Acc}
            end
        end, [], RankList),
    NCNameValueList = lists:sublist(lists:reverse(CNameValueList), RankNum),
    CorpsUids = [CorpsUid || {CorpsUid, _, _} <- NCNameValueList],
    CrossBattleServer = cross_battle_server:init(AreaNum, Term, Wheel, CorpsUids, WheelTime),
    Now = time_lib:now_second(),
    NCrossBattleServer = cross_battle_server:update_state(CrossBattleServer, ?CROSS_SERVER_STATE_SYNC_GROUP, Now, 0),
    cross_battle_db:update_cross_battle_server(GameSrc, "cb_area", NCrossBattleServer),
    zm_event:notify(GameSrc, 'cross_battle_server_state_change', [{'state', ?CROSS_SERVER_STATE_CLOSS}, {'nstate', ?CROSS_SERVER_STATE_SYNC_GROUP}, {'cbs', CrossBattleServer}]),
    {ok, NCNameValueList}.

%% ----------------------------------------------------
%% @doc
%%      同步军团名字
%% @end
%% ----------------------------------------------------
sync_cross_battle_corps_name(GameSrc, Wheel) ->
    ActionType = "cb_area",
    CrossBattleServer = cross_battle_db:get_cross_battle_server(GameSrc, ActionType),
    CorpsUids = cross_battle_server:get_corps_uids(CrossBattleServer),
    CNameList = lists:map(fun(CorpsUid) ->
        Corps = corps_db:get_corps(GameSrc, CorpsUid),
        {CorpsUid, corps:get_name(Corps)}
    end, CorpsUids),
    Now = time_lib:now_second(),
    NCrossBattleServer1 = cross_battle_server:update_state(CrossBattleServer, ?CROSS_SERVER_STATE_SYNC_GROUP, Now, 0),
    NCrossBattleServer = cross_battle_server:update_term_wheel(NCrossBattleServer1, cross_battle_server:get_term(NCrossBattleServer1), Wheel),
    cross_battle_db:update_cross_battle_server(GameSrc, ActionType, NCrossBattleServer),
    {ok, CNameList}.


%% ----------------------------------------------------
%% @doc
%%      同步分组信息
%% @end
%% ----------------------------------------------------
area_cross_battle_sync_mcorps(GameSrc, MapCNameServersList) ->
    ActionType = "cb_area",
    CrossBattleServer = cross_battle_db:get_cross_battle_server(GameSrc, ActionType),
    Wheel = cross_battle_server:get_wheel(CrossBattleServer),
    TableName = game_lib:get_table(GameSrc, 'cross_battle_cgroup'),
    lists:foreach(fun({MapId, CSNames}) ->
        lists:foreach(fun({CorpsUid, _, _}) ->
            case args_system:get_server_name_bypsid(GameSrc, {uid_lib:get_pid(CorpsUid), uid_lib:get_sid(CorpsUid)}) of
                none ->
                    ok;
                _ ->
                    z_db_lib:update(TableName, {CorpsUid, Wheel}, {MapId, list_to_tuple(CSNames)})
            end
        end, CSNames)
    end, MapCNameServersList).

%% ----------------------------------------------------
%% @doc
%%      更新
%% @end
%% ----------------------------------------------------
area_cross_battle_update(GameSrc, {Ip, Port, CBServerName, OState, State, Term, Wheel, StartTime, ContinueTime}) ->
    ActionType = "cb_area",
    Fun = fun(_, CrossBattleServer) ->
        NCrossBattleServer1 = cross_battle_server:update_state(CrossBattleServer, State, StartTime, ContinueTime),
        NCrossBattleServer2 = cross_battle_server:update_address(NCrossBattleServer1, Ip, Port, CBServerName),
        NCrossBattleServer = cross_battle_server:update_term_wheel(NCrossBattleServer2, Term, Wheel),
        {ok, NCrossBattleServer, NCrossBattleServer}
    end,
    CrossBattleServer = z_db_lib:update(game_lib:get_table(GameSrc, 'cross_battle'), {'cross_battle_server', ActionType}, 'none', Fun, []),
    case OState =/= State andalso State =:= ?CROSS_SERVER_STATE_CLOSS andalso
        cross_battle_server:get_wheel(CrossBattleServer) =:= tuple_size(cross_battle_server:get_wheel_time(CrossBattleServer)) of
        true ->
            TableList = ['cross_battle_cgroup'],
            lists:foreach(fun(Table) ->
                z_db_lib:clear(game_lib:get_table(GameSrc, Table))
            end, TableList);
        false ->
            ok
    end,
    case OState =/= State of
        true ->
            Wheel = cross_battle_server:get_wheel(CrossBattleServer),
            set_front_lib:send_cross_battle_state(GameSrc, Wheel, State, StartTime, ContinueTime),
            zm_event:notify(GameSrc, 'cross_battle_server_state_change', [{'state', OState}, {'nstate', State}, {'cbs', CrossBattleServer}]);
        false ->
            ok
    end,
    ok.
%% ----------------------------------------------------
%% @doc
%%      更新本服战况
%% @end
%% ----------------------------------------------------
cross_battle_progress(Src, {Type, Season, Wheel, MapId, RankerViews}) ->
    z_db_lib:update(game_lib:get_table(Src, 'cross_battle_progress'), {Type, Season, Wheel, MapId}, RankerViews).

%% ----------------------------------------------------
%% @doc  
%%       获取军团信息
%% @end
%% ----------------------------------------------------
get_corps_cross_battle(GameSrc, CorpsUid) ->
    Corps = corps_db:get_corps(GameSrc, CorpsUid),
    CorpsMember = corps_db:get_corps_members(GameSrc, CorpsUid),
    OwnerUid = corps:get_owner(Corps),
    OwnerRName = role_show:get_name(role_db:get_role_show(GameSrc, OwnerUid)),
    {Corps, CorpsMember, OwnerRName}.

%% ----------------------------------------------------
%% @doc
%%      获取玩家信息
%% @end
%% ----------------------------------------------------
get_role_cross_battle(GameSrc, RoleUid) ->
    Role = role_db:get_role(GameSrc, RoleUid),
    Role1 = role:role(RoleUid, role:get_name(Role), role:get_style(Role), role:get_sex(Role)),
    NRole = role:set_exp(role:set_vipexp(role:set_country(Role1, role:get_country(Role)), role:get_vipexp(Role)), role:get_exp(Role)),
    Castle = castle:clear_breach(castle:remove_protect(castle_db:get_castle(GameSrc, RoleUid))),
    Buildings = castle:get_building(Castle),
    ResTypes = element(2, zm_config:get('building_info', 'res_type')),
    NBuildings =
        lists:filter(fun({_, BSid, _, _}) ->
            Type = building:get_type(building:get_cfg(BSid)),
            not lists:member(Type, ResTypes)
        end, Buildings),
    NCastle = castle:set_building(Castle, NBuildings),
    Study = building_db:get_study(GameSrc, RoleUid),
    User = user_db:get_user(GameSrc, RoleUid),
    RoleCorps = role_corps:set_requests(role_corps:set_invites(corps_db:get_role_corps(GameSrc, RoleUid), []), []),
    CardStorage = storage_db:get_storage('card', GameSrc, RoleUid),
    EquipStorage = storage_db:get_storage('equipment', GameSrc, RoleUid),
    TreasureStorage = storage_db:get_storage('treasure', GameSrc, RoleUid),
    GIds = garray_lib:get_garray_ids(GameSrc, RoleUid),
    Garrays = garray_db:get_garray(GameSrc, RoleUid, GIds),
    NGarrays = lists:map(fun({GId, Garray}) ->
        NQueue = list_to_tuple(z_lib:tuple_foreach(garray:get_queue(Garray), fun(Acc, _, {CUid, _}) ->
            {ok, [{CUid, 0} | Acc]}
        end, [])),
        Weapon = list_to_tuple(lists:duplicate(tuple_size(garray:get_weapon(Garray)), {0, 0})),
        NGarray = garray:set_auto_add_soldier(garray:set_state(garray:set_weapon(garray:set_queue(garray:set_injured_init(Garray), NQueue), Weapon), ?IDLE), 0),
        {GId, NGarray}
    end, Garrays),
    CardPutProps =
        z_lib:tuple_foreach(CardStorage, fun(Acc, _, CardProp) ->
            CardUid = prop_kit_lib:get_prop_uid(CardProp),
            case z_db_lib:get(game_lib:get_table(GameSrc, 'card_put_prop'), CardUid, 'none') of
                'none' ->
                    {ok, Acc};
                CardPutProp ->
                    {ok, [{CardUid, CardPutProp} | Acc]}
            end
        end, []),
    CardFetter = card_db:get_card_fetter(GameSrc, RoleUid),
    PutTreasureSids = z_db_lib:get(game_lib:get_table(GameSrc, 'card_put_treasure'), RoleUid, []),
    ServerName = args_system:get_server_name(GameSrc),
    {NRole, NCastle, Study, User, RoleCorps, NGarrays, CardStorage, EquipStorage, TreasureStorage, CardPutProps, CardFetter, PutTreasureSids, ServerName}.
%% ----------------------------------------------------
%% @doc
%%      发放积分奖励
%% @end
%% ----------------------------------------------------
award_role_points(GameSrc, Msg) ->
    zm_event:notify(GameSrc, 'award_role_points', Msg),
    ok.

%% ----------------------------------------------------
%% @doc
%%      获取袭击信息以及协防信息
%% @end
%% ----------------------------------------------------
get_assault_info(GameSrc, RoleUid) ->
    fight_db:cross_get_assault_info(GameSrc, RoleUid).
%% ----------------------------------------------------
%% @doc
%%      袭击信息发送推送
%% @end
%% ----------------------------------------------------
send_assault_info(GameSrc, {RoleUid, AssaultView}) ->
    set_front_lib:send_assault(GameSrc, RoleUid, AssaultView).


%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
area_get_cross_battle_state(GameSrc, _) ->
    CrossBattleServer = cross_battle_db:get_cross_battle_server(GameSrc, "cb_area"),
    GState = cross_battle_server:get_state(CrossBattleServer),
    GStartTime = cross_battle_server:get_start_time(CrossBattleServer),
    GContinueTime = cross_battle_server:get_continue_time(CrossBattleServer),
    GTerm = cross_battle_server:get_term(CrossBattleServer),
    GWheel = cross_battle_server:get_wheel(CrossBattleServer),
    {GState, GStartTime, GContinueTime, GTerm, GWheel}.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
