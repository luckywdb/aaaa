-module(cross_battle_port).

%%%=======================STATEMENT====================
-description("cb_port").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_battle_server/5, get_battle_group/5, get_ld_rank_num/1]).
-export([get_battle_info/5]).
-export([get_battle_rank_shop_info/5, execute/5, get_battle_progress/5, get_end_rank_info/5]).
-export([transfer_res/5]).
-export([get_assault_info/5]).

%%%=======================INCLUDE======================
-include("../include/cross_battle.hrl").
-include("../include/rank.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%       获取跨服战赛季信息
%% @end
%% ----------------------------------------------------
get_battle_info(_, _, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    CorpsUid = role_show:get_corps_uid(RoleShow),
    Reply = cross_battle_db:get_cross_battle_server_st(Src, CorpsUid, "cb_area"),
    {ok, [], Info, [{'msg', Reply}]}.
%% ----------------------------------------------------
%% @doc
%%       获取跨服战斗服务器信息
%% @end
%% ----------------------------------------------------
get_battle_server(_, _, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    case cross_battle_db:get_cross_battle_server(Src, "cb_area") of
        'none' ->
            {ok, [], Info, [{'msg', "cross_battle_not_find"}]};
        CrossBattbleServer ->
            CBSState = cross_battle_server:get_state(CrossBattbleServer),
            CBSEndTime = cross_battle_server:get_start_time(CrossBattbleServer) + cross_battle_server:get_continue_time(CrossBattbleServer),
            case CBSState =:= ?CROSS_SERVER_STATE_OPEN andalso CBSEndTime > time_lib:now_second() of
                true ->
                    RoleShow = role_db:get_role_show(Src, RoleUid),
                    CorpsUid = role_show:get_corps_uid(RoleShow),
                    case CorpsUid =/= 0 of
                        true ->
                            case lists:member(CorpsUid, cross_battle_server:get_corps_uids(CrossBattbleServer)) of
                                true ->
                                    User = user_db:get_user(Src, RoleUid),
                                    UserId = integer_to_list(RoleUid),
                                    PushId = guser:get_push_id(User),
                                    NPushId = case is_integer(PushId) of
                                        true ->
                                            "(null)";
                                        false ->
                                            PushId
                                    end,
                                    DeviceId = guser:get_device_id(User),
                                    PlatformId = guser:get_platform_id(User),
                                    Time = time_lib:now_second(),
                                    Sign = sign_lib:sign_compute(UserId, lists:concat([UserId, Time])),
                                    OSystem =
                                        case guser:get_o_system(User) of
                                            1 ->
                                                "android";
                                            2 ->
                                                "ios";
                                            _ ->
                                                ""
                                        end,
                                    Ip = cross_battle_server:get_ip(CrossBattbleServer),
                                    Port = cross_battle_server:get_port(CrossBattbleServer),
                                    ServerName = cross_battle_server:get_server_name(CrossBattbleServer),
                                    Url = lists:flatten(io_lib:format("url?&userid=~s&time=~p&sig=~s&server_name=~s&OS=~s&bi_platform_id=~p&push_id=~s",
                                        [UserId, Time, Sign, ServerName, OSystem, PlatformId, NPushId])),
                                    {ok, [], Info, [{'msg', {Ip, Port, {{"userid", UserId}, {"url", Url}, {"deviceId", DeviceId}}}}]};
                                false ->
                                    {ok, [], Info, [{'msg', "cross_battle_not_in"}]}
                            end;
                        false ->
                            {ok, [], Info, [{'msg', "corps_not_in"}]}
                    end;
                false ->
                    {ok, [], Info, [{'msg', "cross_battle_not_open"}]}
            end
    end.

%% ----------------------------------------------------
%% @doc
%%       获取跨服战斗分组信息
%% @end
%% ----------------------------------------------------
get_battle_group(_, _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    case cross_battle_db:get_cross_battle_server(Src, "cb_area") of
        'none' ->
            {ok, [], Info, [{'msg', "cross_battle_not_find"}]};
        CrossBattbleServer ->
            Wheel = z_lib:get_value(Msg, "wheel", cross_battle_server:get_wheel(CrossBattbleServer)),
            State = cross_battle_server:get_state(CrossBattbleServer),
            StartTime = cross_battle_server:get_start_time(CrossBattbleServer),
            ContinueTime = cross_battle_server:get_continue_time(CrossBattbleServer),
            case State =/= ?CROSS_SERVER_STATE_CLOSS andalso State =/= ?CROSS_SERVER_STATE_SYNC_GROUP of
                true ->
                    RoleShow = role_db:get_role_show(Src, RoleUid),
                    CorpsUid = role_show:get_corps_uid(RoleShow),
                    CorpsUids = cross_battle_server:get_corps_uids(CrossBattbleServer),
                    NCorpsUid =
                        case lists:member(CorpsUid, CorpsUids) of
                            true ->
                                CorpsUid;
                            false ->
                                hd(CorpsUids)
                        end,
                    case z_db_lib:get(game_lib:get_table(Src, 'cross_battle_cgroup'), {NCorpsUid, Wheel}, 'none') of
                        'none' ->
                            {ok, [], Info, [{'msg', "input_error"}]};
                        {MapId, CSNames} ->
                            Reply = {
                                cross_battle_server:get_term(CrossBattbleServer),
                                cross_battle_server:get_wheel(CrossBattbleServer),
                                cross_battle_server:get_wheel_time(CrossBattbleServer),
                                State, StartTime, ContinueTime, MapId rem 10000, CSNames
                            },
                            {ok, [], Info, [{'msg', Reply}]}
                    end;
                false ->
                    {ok, [], Info, [{'msg', "cross_battle_not_open"}]}
            end
    end.


%% ----------------------------------------------------
%% @doc
%%       获取跨服战斗军团排名,抽取半价卡包信息
%% @end
%% ----------------------------------------------------
get_battle_rank_shop_info(_, _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    Season = z_lib:get_value(Msg, "season", 1),%%所取赛季
    UseNum = cross_battle_lib:get_ld_num(Src, RoleUid),
    %{_, UseNum} = cross_battle_lib:get_use_num(OldWeek, Num),%%刷新玩家已经抽取的次数
    CorpsUid = role_corps:get_corps_uid(corps_db:get_role_corps(Src, RoleUid)),
    {Rank, _} = cross_battle_db:get_cross_battle_rank(Src, Season, 3, CorpsUid, ?BATTLE_POINTS_ALL_CORPS_RANK),%%根据军团的UID获得对应军团在跨服战中的排名，如果没有就取0，
    {_CheckLd, AllNum} = get_ld_rank_num(Rank),%获得军团是否有抽卡资格，和抽卡的总次数
    {ok, [], Info, [{'msg', {Rank, max(0, AllNum - UseNum)}}]}.


%% ----------------------------------------------------
%% @doc
%%       抽卡 分为单抽和十抽，如果玩家有半价次数，则
%% @end
%% ----------------------------------------------------
execute([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    CorpsUid = role_corps:get_corps_uid(corps_db:get_role_corps(Src, RoleUid)),
    Season = z_lib:get_value(Msg, "season", 1),%%所取赛季
    {Rank, _} = cross_battle_db:get_cross_battle_rank(Src, Season, 3, CorpsUid, ?BATTLE_POINTS_ALL_CORPS_RANK),
    {CheckLd, AllNum} = get_ld_rank_num(Rank),%获得军团是否有抽卡资格，和抽卡的总次数
    if
        CheckLd ->
            UseNum = cross_battle_lib:get_ld_num(Src, RoleUid),
            Choose = z_lib:get_value(Msg, "choose", 2),    % 单抽还是十连抽
            NowNum = if
                Choose =:= 2 -> 1;
                true -> 10
            end,
            if
                UseNum + NowNum =< AllNum ->
                    ld_port:execute([{M, F, A}], 1, Attr, Info, Msg);
                true ->
                    {ok, [], Info, [{'msg', "cross_battle_num_limit"}]}
            end;
        true ->
            {ok, [], Info, [{'msg', "cross_battle_rank_limit"}]}
    end.


%% ----------------------------------------------------
%% @doc
%%       获得跨服战本服战况
%% @end
%% ----------------------------------------------------
get_battle_progress(_, _, _Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    Type = z_lib:get_value(Msg, "type", 1),
    SRank = z_lib:get_value(Msg, "start_rank", 1),
    ERank = z_lib:get_value(Msg, "end_rank", 100),
    Season = z_lib:get_value(Msg, "season", 1),%%所取赛季
    Wheel = z_lib:get_value(Msg, "wheel", 1),%%所取轮次
    NewType = rank_lib:get_type(Type),
    case rank_db:get_actions(Src, NewType) of
        {_AcfgKey, Actions} when SRank >= 1, ERank - SRank =< 100 ->
            %%本服战况只有总排行榜，故小组传0
            Rankers = z_db_lib:get(game_lib:get_table(Src, 'cross_battle_progress'), {Type, Season, Wheel, 0}, []),
            SizeRankers = lists:sublist(Rankers, SRank, ERank - SRank + 1),
            case lists:keyfind('format', 1, Actions) of
                {_, {M, F, A}} ->
                    FormatRankers = M:F(A, Src, SizeRankers),
                    {ok, [], Info, [{msg, list_to_tuple(FormatRankers)}]};
                _ ->
                    {ok, [], Info, [{msg, "input_error"}]}
            end;
        _ ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.
%% ----------------------------------------------------
%% @doc
%%      跨服结束获得积分信息
%% @end
%% ----------------------------------------------------
get_end_rank_info(_, _, Attr, Info, _Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    CorpsUid = role_show:get_corps_uid(RoleShow),
    CrossBattleServer = cross_battle_db:get_cross_battle_server(Src, "cb_area"),
    Season = cross_battle_server:get_term(CrossBattleServer),
    Wheel = cross_battle_server:get_wheel(CrossBattleServer),
    WheelSize = erlang:size(cross_battle_server:get_wheel_time(CrossBattleServer)),
    {CorpsRank, _} = cross_battle_db:get_cross_battle_rank(Src, Season, Wheel, CorpsUid, ?BATTLE_POINTS_ALL_CORPS_RANK),
    {RoleRank, Value} = cross_battle_db:get_cross_battle_rank(Src, Season, Wheel, RoleUid, ?BATTLE_POINTS_ALL_ROLE_RANK),
    Fun = fun(Wheel_, R) ->
        {CorpsRank1, _} = cross_battle_db:get_cross_battle_rank(Src, Season, Wheel_, CorpsUid, ?BATTLE_POINTS_SINGLE_CORPS_RANK),
        {RoleRank1, Value1} = cross_battle_db:get_cross_battle_rank(Src, Season, Wheel_, RoleUid, ?BATTLE_POINTS_SINGLE_ROLE_RANK),
        [{CorpsRank1, RoleRank1, Value1} | R]
    end,
    FormatList = lists:foldl(Fun, [], lists:seq(1, WheelSize)),
    {ok, [], Info, [{msg, {{CorpsRank, RoleRank, Value}, list_to_tuple(lists:reverse(FormatList))}}]}.

%% ----------------------------------------------------
%% @doc
%%      划拨资源
%% @end
%% ----------------------------------------------------
transfer_res(_, _, Attr, Info, Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    List = [list_to_integer(Str) || Str <- string:tokens(z_lib:get_value(Msg, "str", Msg), ",")],
    {_, GoodsSids} = zm_config:get('cross_battle_info', 'transfer_goods_sids'),
    case check_transfer_res(GoodsSids, [], List) of
        {ok, Consumes} ->
            {_, ServerCross} = lists:keyfind('server_cross', 1, Msg),
            case cross_battle_role_db:transfer_consume_res(Src, RoleUid, Consumes) of
                {ok, BiCs} ->
                    zm_log:info(Src, ?MODULE, 'transfer_consume_res', "transfer_consume_res",
                        [{'roleuid', RoleUid}, {'consume', Consumes}]),
                    zm_event:notify(Src, 'bi_cb_transfer_consume', [{'role_uid', RoleUid}, {'consume', BiCs}]),
                    ok = server_cross_msg:send_call_node(Src, server_cross:get_node(ServerCross), "cb_area",
                        [server_cross:get_group(ServerCross), {'cross_battle_area_rpc', 'game_transfer_award_res', {RoleUid, Consumes}}]),
                    {ok, [], Info, [{msg, "ok"}]};
                Err ->
                    {ok, [], Info, [{msg, Err}]}
            end;
        Err ->
            {ok, [], Info, [{msg, Err}]}
    end.
%% ----------------------------------------------------
%% @doc
%%      获取另一个服务器的 协防和袭击信息
%% @end
%% ----------------------------------------------------
get_assault_info(_, _, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, src, none),
    CenterSrc = game_lib:get_center_src(),
    GameSrc = game_lib:get_game_src(),
    ActionType = "cb_area",
    MapId = role_lib:get_mapid(Attr),
    RoleUid = role_lib:get_uid(Attr),
    R = case cross_battle_area_db:check_cross_is_open(Src, RoleUid, MapId, ActionType) of
        false ->
            {{}, {}};
        _ ->
            if
                MapId > 0 ->
                    case cross_server_msg:send_call(CenterSrc, ActionType, RoleUid, {'cross_battle_rpc', 'get_assault_info', RoleUid}) of
                        {ok, ReternInfo} ->
                            ReternInfo;
                        Err when is_list(Err) ->
                            {{}, {}}
                    end;
                true ->
                    case server_cross_msg:send_call(GameSrc, ActionType, RoleUid, {'cross_battle_area_rpc', 'get_assault_info', RoleUid}) of
                        {ok, ReternInfo} ->
                            ReternInfo;
                        Err when is_list(Err) ->
                            {{}, {}}
                    end
            end
    end,
    {'ok', [], Info, [{'msg', R}]}.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%      获得抽卡的消耗
%% @end
%% ----------------------------------------------------
%%get_execute_consume(_Src, _RoleUid, Choose) ->
%%    {_, LdInfo} = zm_config:get(cross_battle_info, ld_consume),
%%    case Choose of
%%        2 ->%%单抽
%%            z_lib:get_value('one', LdInfo, []);
%%        _ ->%%十连抽
%%            z_lib:get_value('ten', LdInfo, [])
%%    end.

%% ----------------------------------------------------
%% @doc
%%      检测划拨参数
%% @end
%% ----------------------------------------------------
check_transfer_res(TGoodsSids, Acc, [Sid, Num | Tails]) ->
    case Sid =:= 0 orelse lists:member(Sid, TGoodsSids) of
        true ->
            check_transfer_res(TGoodsSids, times_set_lib:update(Acc, {Sid, Num}), Tails);
        false ->
            "input_error"
    end;
check_transfer_res(_, _Acc, [_]) ->
    "input_error";
check_transfer_res(_, Acc, []) ->
    NAcc = lists:map(fun({Sid, Num}) ->
        case Sid =:= 0 of
            true ->
                {'rmb', Num};
            false ->
                {'prop', {Sid, Num}}
        end
    end, Acc),
    {ok, NAcc}.

%% ----------------------------------------------------
%% @doc
%%      根据军团排名获得抽卡的次数
%% @end
%% ----------------------------------------------------
get_ld_rank_num(Rank) ->
    {_, LdInfo} = zm_config:get(cross_battle_info, ld_rank),
    Fun = fun({[Rank1, Rank2], Num}, {R1, R2}) ->
        if
            Rank >= Rank1 andalso Rank =< Rank2 ->
                {true, Num};
            true ->
                {R1, R2}
        end
    end,
    lists:foldl(Fun, {false, 0}, LdInfo).