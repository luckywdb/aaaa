-module(cross_battle_db).

%%%=======================STATEMENT====================
-description("cross_battle_db").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    get_cross_battle_server/2,
    update_cross_battle_server/3,
    get_cross_battle_server_st/3,
    award_role_points/6,

    check_corps_in_cross_battle/2,
    check_corps_in_wheel_cross_battle_ignore_state/2,

    get_cross_battle_rank/5,
    update_cross_battle_rank/6,
    clear_data/3
]).
-export([update_cache_cross_battle_server/2, get_cache_cross_battle_server/2]).

%%%=======================INCLUDE======================
-include("../include/cross_battle.hrl").
%%%=======================DEFINE======================
-define(SERVER_CROSS_BATTLE_TABLE, 'server_cross_battle_table').
%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%        清理数据
%% @end
%% ----------------------------------------------------
clear_data(Src, CurrentSeason, _CurrentWheel) ->
    %%删除每轮积分奖励领取信息
    z_db_lib:clear(game_lib:get_table(Src, 'cross_battle_points_award')),
    %%删除过期排名信息
    {_, MaxSaveSeason} = zm_config:get('center_cross_battle_info', 'max_save_season'),
    DelSeason = CurrentSeason - MaxSaveSeason,
    UpdateRankFun = fun(_, RankInfo) ->
        NewRankInfo = lists:filter(fun({{Season, _}, _}) -> Season >= DelSeason end, RankInfo),
        {ok, ok, NewRankInfo}
                    end,
    ClearRankFun = fun(_Src, Key, ClearTable_, _) ->
        z_db_lib:update(ClearTable_, Key, [], UpdateRankFun, [])
                   end,
    RankTable = game_lib:get_table(Src, 'cross_battle_rank'),
    z_db_lib:table_iterate(Src, RankTable, ClearRankFun, RankTable, []),
    %%删除过期通报信息
    ProgressTable = game_lib:get_table(Src, 'cross_battle_progress'),
    ClearProgressFun = fun(_Src, {_Type, Season, _Wheel, _MapId} = Key, ClearTable_, _) ->
        if
            Season < DelSeason ->
                z_db_lib:delete(ClearTable_, Key);
            true ->
                ok
        end
                       end,
    z_db_lib:table_iterate(Src, ProgressTable, ClearProgressFun, ProgressTable, []),
    %%删除排行榜奖励领取状态
    RankAwardStateTable = game_lib:get_table(Src, 'cross_battle_rank_award_state'),
    UpdateRankAwardFun = fun(_, RankAwardStates) ->
        NewRankAwardStates = lists:filter(fun({Season, _, _}) -> Season >= DelSeason end, RankAwardStates),
        {ok, ok, NewRankAwardStates}
                         end,
    ClearRankAwardFun = fun(_Src, Key, ClearTable_, _) ->
        z_db_lib:update(ClearTable_, Key, [], UpdateRankAwardFun, [])
                        end,
    z_db_lib:table_iterate(Src, RankAwardStateTable, ClearRankAwardFun, RankAwardStateTable, []).

%% ----------------------------------------------------
%% @doc
%%        设置跨服战排名
%% @end
%% ----------------------------------------------------
update_cross_battle_rank(Src, Season, Wheel, Uid, RankType, Rank) ->
    Fun = fun(_, RankInfo) ->
        {ok, ok, lists:keystore({Season, Wheel}, 1, RankInfo, {{Season, Wheel}, Rank})}
          end,
    z_db_lib:update(game_lib:get_table(Src, 'cross_battle_rank'), {Uid, RankType}, [], Fun, []).
%% ----------------------------------------------------
%% @doc
%%        获得跨服战排名
%% @end
%% ----------------------------------------------------
get_cross_battle_rank(Src, Season, Wheel, Uid, RankType) ->
    RankInfo = z_db_lib:get(game_lib:get_table(Src, 'cross_battle_rank'), {Uid, RankType}, []),
    z_lib:get_value(RankInfo, {Season, Wheel}, {0, 0}).

%% ----------------------------------------------------
%% @doc  
%%        获取跨服战斗服务器信息
%% @end
%% ----------------------------------------------------
get_cross_battle_server(Src, CrossType) ->
    z_db_lib:get(game_lib:get_table(Src, 'cross_battle'), {'cross_battle_server', CrossType}, 'none').
%% ----------------------------------------------------
%% @doc
%%      更新跨服战斗服务器信息
%% @end
%% ----------------------------------------------------
update_cross_battle_server(Src, CrossType, CrossBattleServer) ->
    z_db_lib:update(game_lib:get_table(Src, 'cross_battle'), {'cross_battle_server', CrossType}, CrossBattleServer).

%% ----------------------------------------------------
%% @doc
%%       获取跨服战斗服务器状态和开启时间
%% @end
%% ----------------------------------------------------
get_cross_battle_server_st(Src, CorpsUid, CrossType) ->
    case get_cross_battle_server(Src, CrossType) of
        'none' ->
            {?CROSS_SERVER_STATE_CLOSS, 0, {}};
        CrossBattleServer ->
            State = cross_battle_server:get_state(CrossBattleServer),
            Wheel = cross_battle_server:get_wheel(CrossBattleServer),
            WheelTime = cross_battle_server:get_wheel_time(CrossBattleServer),
            Bool =
                if
                    State =:= ?CROSS_SERVER_STATE_CLOSS ->
                        false;
                    State =:= ?CROSS_SERVER_STATE_SYNC_GROUP ->
                        false;
                    State =:= ?CROSS_SERVER_STATE_STOP orelse State =:= ?CROSS_SERVER_STATE_CLEAR_COMPLETE ->
                        Wheel =/= tuple_size(WheelTime);
                    true ->
                        true
                end,
            Term = cross_battle_server:get_term(CrossBattleServer),
            case Bool of
                true ->
                    StartTime = cross_battle_server:get_start_time(CrossBattleServer),
                    ContinueTime = cross_battle_server:get_continue_time(CrossBattleServer),
                    Flag =
                        case lists:member(CorpsUid, cross_battle_server:get_corps_uids(CrossBattleServer)) of
                            true ->
                                1;
                            false ->
                                0
                        end,
                    {State, Term, Wheel, WheelTime, StartTime, ContinueTime, Flag, 0, {0, 0}};
                false ->
                    {?CROSS_SERVER_STATE_CLOSS, Term, WheelTime}
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      检测军团是否跨服战中(开启中)
%% @end
%% ----------------------------------------------------
check_corps_in_cross_battle(Src, CorpsUid) ->
    CrossType = "cb_area",
    case get_cross_battle_server(Src, CrossType) of
        'none' ->
            false;
        CrossBattleServer ->
            State = cross_battle_server:get_state(CrossBattleServer),
            (State =:= ?CROSS_SERVER_STATE_SYNC_DATA orelse State =:= ?CROSS_SERVER_STATE_SYNC_DATA_COMPLETE orelse State =:= ?CROSS_SERVER_STATE_OPEN)
            andalso lists:member(CorpsUid, cross_battle_server:get_corps_uids(CrossBattleServer))
    end.

%% ----------------------------------------------------
%% @doc
%%  检测军团是否跨服战中(最后一轮的休息状态不算)
%% @end
%% ----------------------------------------------------
check_corps_in_wheel_cross_battle_ignore_state(Src, CorpsUid) ->
    CrossType = "cb_area",
    case get_cross_battle_server(Src, CrossType) of
        'none' ->
            false;
        CrossBattleServer ->
            State = cross_battle_server:get_state(CrossBattleServer),
            Wheel = cross_battle_server:get_wheel(CrossBattleServer),
            MaxWheel = tuple_size(cross_battle_server:get_wheel_time(CrossBattleServer)),
            lists:member(CorpsUid, cross_battle_server:get_corps_uids(CrossBattleServer)) andalso
            (Wheel =/= MaxWheel orelse
             (State =:= ?CROSS_SERVER_STATE_STOP orelse State =:= ?CROSS_SERVER_STATE_CLEAR orelse State =:= ?CROSS_SERVER_STATE_CLEAR_COMPLETE))
    end.
%% ----------------------------------------------------
%% @doc
%%       积分到达奖励
%% @end
%% ----------------------------------------------------
award_role_points(Src, Season, Wheel, RoleUid, Points, Items) ->
    CheckFun = fun(Item, {RealItems, AwardItemInfo}) ->
        {_, NeedPoints, Award} = zm_config:get('cross_battle_award', Item),
        if
            Points >= NeedPoints ->
                {[Item | RealItems], [{Item, NeedPoints, Award} | AwardItemInfo]};
            true ->
                {RealItems, AwardItemInfo}
        end
               end,
    Fun = fun(_, GotItems) ->
        AwardItems = Items--GotItems,
        {RealItems, AwardItemInfo} = lists:foldl(CheckFun, {[], []}, AwardItems),
        {ok, AwardItemInfo, RealItems}
          end,
    case z_db_lib:update(game_lib:get_table(Src, 'cross_battle_points_award'), RoleUid, [], Fun, []) of
        [] ->
            ok;
        AwardItemInfo ->
            AwardFun = fun({_Item, NeedPoints, Award}, _) ->
                MailType = award_source:get_source(?MODULE),
                Mail = mail:init({MailType, time_lib:now_second(), 0, {3101, Season, Wheel}, {3101, Season, Wheel, NeedPoints}, Award}),
                mail_db:send(Src, RoleUid, Mail)
                       end,
            lists:foldl(AwardFun, [], AwardItemInfo)
    end.


%% ----------------------------------------------------
%% @doc
%%    更新server cache
%% @end
%% ----------------------------------------------------
update_cache_cross_battle_server(ActionType, CrossBattleServer) ->
    zm_config:set(?SERVER_CROSS_BATTLE_TABLE, {{'cross_battle_server', ActionType}, CrossBattleServer}).

%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
get_cache_cross_battle_server(Src, ActionType) ->
    case zm_config:get(?SERVER_CROSS_BATTLE_TABLE, {'cross_battle_server', ActionType}) of
        'none' ->
            CrossBattleServer = get_cross_battle_server(Src, ActionType),
            update_cache_cross_battle_server(ActionType, CrossBattleServer),
            CrossBattleServer;
        {_, V} ->
            V
    end.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
