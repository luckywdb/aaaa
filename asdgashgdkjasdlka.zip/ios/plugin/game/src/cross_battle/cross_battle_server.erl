-module(cross_battle_server).

%%%=======================STATEMENT====================
-description("cross_battle_server").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    init/5
]).
-export([
    get_ip/1,
    get_port/1,
    get_server_name/1,
    get_term/1,
    get_wheel/1,
    get_state/1,
    get_start_time/1,
    get_continue_time/1,
    get_corps_uids/1,
    get_area_num/1,
    get_wheel_time/1
]).
-export([
    update_state/4,
    update_term_wheel/3,
    update_address/4
]).

%%%=======================INCLUDE======================
-include("../include/cross_battle.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(cross_battle_server, {
    ip = "" :: string(),
    port = 0 :: integer(),
    server_name = "" :: string(),
    area_num = 0 :: integer(),%%赛区
    term = 0 :: integer(),%%当前赛季
    wheel = 1 :: integer(),%%当前轮数
    state = ?CROSS_SERVER_STATE_CLOSS :: integer(),%%状态(默认准备中),
    start_time = 0 :: integer(),%%开始时间
    continue_time = 0 :: integer(),%%持续时间
    corps_uids = [] :: [integer()], %%跨服的军团uid列表
    wheel_time :: tuple()%%{{开始时间,持续时间}}每轮时间
}).
%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        
%% @end
%% ----------------------------------------------------
init(AreaNum, Term, Wheel, CorpsUids, WheelTime) ->
    #cross_battle_server{area_num = AreaNum, term = Term, wheel = Wheel, corps_uids = CorpsUids, wheel_time = WheelTime}.

get_ip(#cross_battle_server{ip = V}) -> V.
get_port(#cross_battle_server{port = V}) -> V.
get_server_name(#cross_battle_server{server_name = V}) -> V.
get_area_num(#cross_battle_server{area_num = V}) -> V.
get_term(#cross_battle_server{term = V}) -> V.
get_wheel(#cross_battle_server{wheel = V}) -> V.
get_state(#cross_battle_server{state = V}) -> V.
get_start_time(#cross_battle_server{start_time = V}) -> V.
get_continue_time(#cross_battle_server{continue_time = V}) -> V.
get_corps_uids(#cross_battle_server{corps_uids = V}) -> V.
get_wheel_time(#cross_battle_server{wheel_time = V}) -> V.

update_address(CrossBattleServer, Ip, Port, ServerName) ->
    CrossBattleServer#cross_battle_server{ip = Ip, port = Port, server_name = ServerName}.

update_state(CrossBattleServer, State, StartTime, ContinueTime) ->
    CrossBattleServer#cross_battle_server{state = State, start_time = StartTime, continue_time = ContinueTime}.

update_term_wheel(CrossBattleServer, Term, Wheel) ->
    CrossBattleServer#cross_battle_server{term = Term, wheel = Wheel}.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
