%%关卡基本信息
-module(duplicate).
-description("duplicate").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_sid/1, get_chapter/1, get_day/1, get_fight_num/1, get_reset_num/1, get_star/1]).
-export([set_sid/2, set_day/2, set_fight_num/2, set_reset_num/2, set_star/2]).
-export([init/3, refresh/2]).


-export_type([duplicates/0, duplicate/0, pub_times/0]).
%%%=======================DEFINE=======================

%%%=======================INCLUDE======================
%%%=======================RECORD=======================
-record(duplicate, {
    sid :: integer(),
    day :: integer(),            %%日
    fight_num :: integer(),        %%挑战次数
    reset_num = 0 :: integer(),        %%重置次数
    star = 0 :: integer(),            %%星数
    info = [] :: list()
}).

%%%=======================TYPE=========================
-type duplicates() :: [duplicate()].
-type duplicate() :: #duplicate{}.
-type pub_times() :: [{integer(), integer()}].

%%%=================EXPORTED FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%      获取sid
%% @end
%% ----------------------------------------------------
-spec get_sid(duplicate()) -> integer().
get_sid(#duplicate{sid = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      获取章id
%% @end
%% ----------------------------------------------------
-spec get_chapter(duplicate()) -> integer().
get_chapter(#duplicate{sid = Value}) ->
    element(2, lists:keyfind('chapter', 1, element(2, zm_config:get('duplicate', Value)))).
%% ----------------------------------------------------
%% @doc
%%      获取本节点的挑战日
%% @end
%% ----------------------------------------------------
-spec get_day(duplicate()) -> integer().
get_day(#duplicate{day = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      获取本节点的挑战次
%% @end
%% ----------------------------------------------------
-spec get_fight_num(duplicate()) -> integer().
get_fight_num(#duplicate{fight_num = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      获取本节点的星置次数
%% @end
%% ----------------------------------------------------
-spec get_reset_num(duplicate()) -> integer().
get_reset_num(#duplicate{reset_num = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      获取本节点的星级
%% @end
%% ----------------------------------------------------
-spec get_star(duplicate()) -> integer().
get_star(#duplicate{star = Value}) -> Value.


%% ----------------------------------------------------
%% @doc
%%      设置sid
%% @end
%% ----------------------------------------------------
-spec set_sid(duplicate(), integer()) -> duplicate().
set_sid(Duplicate, Value) -> Duplicate#duplicate{sid = Value}.
%% ----------------------------------------------------
%% @doc
%%      设置本节点的挑战日
%% @end
%% ----------------------------------------------------
-spec set_day(duplicate(), integer()) -> duplicate().
set_day(Duplicate, Value) -> Duplicate#duplicate{day = Value}.
%% ----------------------------------------------------
%% @doc
%%      设置本节点的挑战次
%% @end
%% ----------------------------------------------------
-spec set_fight_num(duplicate(), integer()) -> duplicate().
set_fight_num(Duplicate, Value) -> Duplicate#duplicate{fight_num = Value}.
%% ----------------------------------------------------
%% @doc
%%      设置本节点的星置次数
%% @end
%% ----------------------------------------------------
-spec set_reset_num(duplicate(), integer()) -> duplicate().
set_reset_num(Duplicate, Value) -> Duplicate#duplicate{reset_num = Value}.
%% ----------------------------------------------------
%% @doc
%%      设置本节点的星级
%% @end
%% ----------------------------------------------------
-spec set_star(duplicate(), integer()) -> duplicate().
set_star(Duplicate, Value) -> Duplicate#duplicate{star = Value}.
%% ----------------------------------------------------
%% @doc
%%      进行刷新
%% @end
%% ----------------------------------------------------
-spec refresh(duplicate(), integer()) -> duplicate().
refresh(Duplicate, Day) ->
    case get_day(Duplicate) of
        Day ->
            Duplicate;
        _ ->
            Duplicate#duplicate{day = Day, fight_num = 0, reset_num = 0}
    end.
%% ----------------------------------------------------
%% @doc
%%      初始
%% @end
%% ----------------------------------------------------
-spec init(integer(), integer(), integer()) -> duplicate().
init(Sid, FightNum, Star) ->
    #duplicate{sid = Sid, day = time_lib:get_date_by_type('day_of_year'), fight_num = FightNum, star = Star}.
		