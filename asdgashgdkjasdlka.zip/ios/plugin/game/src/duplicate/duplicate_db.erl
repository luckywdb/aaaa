%%关卡db操作
-module(duplicate_db).
-description("duplicate_db").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([fight/3, fight_format/2, result/6, result_/3, reset_num/3, star_award/3, sweep/3, get_duplicate_info/2, get_pulic_day_count/2]).
-export([get_duplicate_progress/3]).
-export([famous_duplicate_change_card/3]).
%%%=======================DEFINE=======================

%%%=======================INCLUDE======================
-include("../include/duplicate.hrl").
%%%=================EXPORTED FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%      进行挑战
%% @end
%%-------------------------------------------------------------------
-spec fight(list(), tuple(), list()) ->
    string()|tuple().
fight(_A, {Src, Sid, RoleUid, FighterRole, Gid, FamousDuplicate, DupType}, [{_, Role}, {Index2, FightArgs}, {_, DuplicateInfo}, {Index4, Restore}, {_, PubInfo}]) ->
    NowTime = time_lib:now_second(),
    FightTime = z_db_lib:get_value(FightArgs, 'fight_time', 0),
    if
        NowTime - FightTime >= 5 ->
            {_, Duplicate} = zm_config:get('duplicate', Sid),
            Conditions = z_lib:get_value(Duplicate, 'conditions', []),
            {_, Con1} = zm_config:get('duplicate_info', 'condition'),
            Bool0 = game_lib:checks({'duplicate_lib', 'check'}, {PubInfo, Sid}, 'fight2', Con1),
            if
                Bool0 ->
                    Bool1 = game_lib:checks({'duplicate_lib', 'check'}, {Role, DuplicateInfo, Restore, Sid}, 'fight', Conditions),
                    if
                        Bool1 ->
                            Consumes = z_lib:get_value(Duplicate, 'start_consumes', []),
                            {CS, {_, _, NRestore}} = game_lib:consumes({'duplicate_lib', 'consume'}, {Src, Role, Restore}, 'fight', Consumes),
                            %%生成随机种子
                            Seed = game_lib:get_seed(),
                            NpcArrayTuple = z_lib:get_value(Duplicate, 'npc_array_sid', []),
                            AllDupNpcIndexs = famous_duplicate:get_famous_duplicate_npc_indexs(FamousDuplicate),
                            Index = case lists:keyfind(Sid, 1, AllDupNpcIndexs) of
                                {_, IndexTmp} ->
                                    IndexTmp;
                                false ->
                                    z_lib:random(1, erlang:tuple_size(NpcArrayTuple))
                            end,
                            NpcArray = element(Index, NpcArrayTuple),
                            %%通关奖励
                            PassAwardSidTuple = z_lib:get_value(Duplicate, 'pass_award', 0),
                            PassAwardSid = element(Index, PassAwardSidTuple),
                            %%双倍活动
                            Multi = case lists:member(DupType, ?DUPLICATE_TYPE_NORMAL_LIST) of
                                true ->
                                    active_addition:get_duplicate_drop_multi(Src);
                                false -> 10000
                            end,
                            ActiveDropAwardList = active_duplicate_drop:get_active_duplicate_drops(Src, Sid),
                            NActiveDropAwardList = awarder_game:award_percent(ActiveDropAwardList, Multi),
                            NPassAwardList = awarder_game:award_percent(PassAwardSid, Multi),
                            {PassAwardView, Award} = awarder_game:get_advance_award(Src, RoleUid, ?MODULE, NPassAwardList ++ NActiveDropAwardList),
                            FirstAward = z_lib:get_value(Duplicate, 'frist_award', 'none'),
                            FightType = match_lib:get_fight_type(?MODULE),
                            ReFightArgs = [
                                {'ma', {?MODULE, []}},
                                {'seed', Seed},
                                {'auto', 0},%是否自动释放技能自动战斗 1:自动,0:手动
                                {'fight_role', FighterRole},
                                {'sid', Sid},
                                {'npc_array', NpcArray},
                                {'fight_time', NowTime},
                                {'fight_type', FightType},
                                {'pass_award', Award},
                                {'frist_award', FirstAward},
                                {'pass_award_view', PassAwardView},
                                {'award_muitl', Multi},
                                {'role_uid', RoleUid},
                                {'garray_id', Gid}],
                            {ok, {fight_format(Src, ReFightArgs), CS}, [{Index2, ReFightArgs}, {Index4, NRestore}]};
                        true ->
                            throw(Bool1)
                    end;
                true ->
                    throw(Bool0)
            end;
        true ->
            {ok, {'ok', fight_format(Src, FightArgs)}}
    end.

%%-------------------------------------------------------------------
%% @doc
%%      战斗数据format时候,fightargs中必须添加key为format,match.erl中会直接取该值传给web验证
%%		战斗数据,注意:web和前台战斗数据的key:seed,camp,fight_role(己方),fight_enemy(敌方:role或npc等)是必须的
%% @end
%%-------------------------------------------------------------------
-spec fight_format(atom(), FightArgs) -> tuple()|string() when
    FightArgs :: 'none'|list().
fight_format(_Src, 'none') ->
    throw("no_normal");
fight_format(_Src, FightArgs) ->
    Seed = z_lib:get_value(FightArgs, 'seed', 0),
    FightRole = z_lib:get_value(FightArgs, 'fight_role', 'none'),
    FightType = z_lib:get_value(FightArgs, 'fight_type', 0),
    Password = z_lib:get_value(FightArgs, 'pass_award_view', []),
    Auto = z_lib:get_value(FightArgs, 'auto', 0),
    Sid = z_lib:get_value(FightArgs, 'sid', 0),
    NpcArray = z_lib:get_value(FightArgs, 'npc_array', []),
    FighterNpc = fighter:init_npc(NpcArray),
    {{'seed', Seed}, {'auto', Auto}, {'fight_role', FightRole}, {'fight_enemy', FighterNpc}, {'fight_type', FightType},
        {'pass_award', list_to_tuple(Password)}, {'duplicate_sid', Sid}}.

%%-------------------------------------------------------------------
%% @doc
%%      进行结果处理
%% @end
%%-------------------------------------------------------------------
-spec result(Src, _A, RoleUid, _Msg, FightArgs, Result) -> string()|tuple() when
    Src :: atom(),
    _A :: list(),
    RoleUid :: integer(),
    _Msg :: [{string(), term()}],
    FightArgs :: [{term(), term()}],
    Result :: [{string(), term()}].
result(Src, _A, RoleUid, _Msg, FightArgs, Result) ->
    Winner = z_lib:get_value(Result, "winner", 1), %%winner=0玩家胜利,1怪物胜利
    Md5 = z_lib:get_value(Result, "md5", ""),% md5验证
    {_, Sid} = lists:keyfind('sid', 1, FightArgs),
    if
        Winner =/= 0 -> %% 失败
%%            zm_event:notify(Src, achieve, {RoleUid, {argu, 'duplicate', Sid}}),%失败不计算完成任务
            {Winner, Md5};
        true ->%%玩家胜利
            Role = role_db:get_role(Src, RoleUid),
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName,
                [{'duplicate_info', RoleUid, []},
                    {'role_restore', RoleUid, restore_db:init(Src, RoleUid)},
                    {'duplicate_pub_info', RoleUid, []},
                    {'famous_duplicate', RoleUid, famous_duplicate:init()}]),
            case z_db_lib:handle(TableName, {?MODULE, result_, Winner}, {Src, Result, Role, FightArgs}, TableKeys) of
                {ok, OldD, Star, CS, DuplicateInfo, NDuplicateInfo} ->
                    %DupType = duplicate_lib:get_type_by_sid(Sid),
                    PassAward = z_lib:get_value(FightArgs, 'pass_award', 'none'),
                    Multi = z_lib:get_value(FightArgs, 'award_muitl', 1),
                    PassAwardLog = awarder_game:give_award(PassAward),
                    IsFirstPass = lists:keyfind(Sid, 2, DuplicateInfo) =:= false,
                    FirstAwardLog = if
                        IsFirstPass ->
                            case z_lib:get_value(FightArgs, 'frist_award', 'none') of
                                'none' ->
                                    {};
                                FirstAwardSid ->
                                    awarder_game:give_award(Src, RoleUid, ?MODULE, FirstAwardSid)
                            end;
                        true ->
                            {}
                    end,
                    OldStar = duplicate:get_star(OldD),
                    if
                        Star > OldStar ->
                            %% 关卡挑战星星排行榜
                            zm_event:notify(Src, 'active_event', {'active_duplicate_star_rank', [{'role_uid', RoleUid}, {'star', duplicate_lib:get_all_star(NDuplicateInfo)}]});
                        true ->
                            'ok'
                    end,
                    GarrayId = z_lib:get_value(FightArgs, 'garray_id', 0),
                    {_, DuplicateConfig} = zm_config:get('duplicate', Sid),
                    BaseValue = z_lib:get_value(DuplicateConfig, 'award_card_exp', 0),
                    AddCardExp = role_addition:get_card_exp(Src, RoleUid, BaseValue) * Multi div 10000,
                    garray_db:award_card_oneexp(Src, RoleUid, GarrayId, AddCardExp, Sid),
                    %%bi收集
                    zm_event:notify(Src, 'bi_duplicate_result', [{'role_uid', RoleUid}, {'award', PassAwardLog}, {'first_award', FirstAwardLog}, {'winner', Winner},
                        {'number', 1}, {'consume', CS}, {'sid', Sid}, {'type', z_lib:get_value(DuplicateConfig, 'type', 1)}]),
                    %%任务成就
                    zm_event:notify(Src, achieve, {RoleUid, {argu, {'duplicate', Sid, 1}}}),
%%                    if %%策划需求取消该广播
%%                        IsFirstPass ->
%%                            zm_event:notify(Src, 'broadcast', {'duplicate', [{'role_uid', RoleUid}, {'sid', Sid}, {'country', role:get_country(Role)}]});
%%                        true ->
%%                            ok
%%                    end,
                    {Winner, Md5, {z_lib:get_value(Result, "death_toll", 0), PassAwardLog, FirstAwardLog, Multi, AddCardExp}};
                Reply ->
                    Reply
            end
    end.
%%-------------------------------------------------------------------
%% @doc
%%      进行结果处理
%% @end
%%-------------------------------------------------------------------
-spec result_(list(), tuple(), list()) -> tuple() | no_return().
result_(_, {Src, Result, Role, FightArgs}, [{Index1, DuplicateInfo}, {Index2, Restore}, {Index3, PubInfo}, {Index4, FamousDuplicate}]) ->
    Sid = z_lib:get_value(FightArgs, 'sid', 0),
    {_, Duplicate} = zm_config:get('duplicate', Sid),
    Consumes = z_lib:get_value(Duplicate, 'end_consumes', []),
    Bool1 = game_lib:checks({duplicate_lib, check}, {Role, DuplicateInfo, Restore, Sid}, 'fight', Consumes),
    if
        Bool1 ->
            ok;
        true ->
            throw(Bool1)
    end,
    {CS, {_, _, NRestore}} = game_lib:consumes({duplicate_lib, consume}, {Src, Role, Restore}, 'fight', Consumes),
    Star = max(1, 3 - z_lib:get_value(Result, "death_toll", 3)),   %通关星数   1星：通关即可获得。%2星：损失2名以下武将的情况下通关。%3星：未损失任何武将的情况下通关。
    OldD = case lists:keyfind(Sid, 2, DuplicateInfo) of
        false ->
            duplicate:init(Sid, 0, 0);
        D ->
            D
    end,
    NDuplicateInfo = duplicate_lib:update_record(DuplicateInfo, Sid, Star),
    {_, Type} = lists:keyfind(type, 1, Duplicate),
    NPubInfo = duplicate_lib:add_public_day_count(PubInfo, Type, 1),
    T = if
        Type =:= ?DUPLICATE_TYPE_FAMOUS ->
            [{Index4, famous_duplicate:refresh(FamousDuplicate, {'duplicate_npc_index', [Sid]}, 0)}];
        true ->
            []
    end,
    {ok, {ok, OldD, Star, CS, DuplicateInfo, NDuplicateInfo},
        [{Index1, NDuplicateInfo},
            {Index2, NRestore}, {Index3, NPubInfo} | T]}.

%%-------------------------------------------------------------------
%% @doc
%%      重置挑战次数
%% @end
%%-------------------------------------------------------------------
-spec reset_num(list(), tuple(), list()) ->
    string()|tuple().
reset_num(_A, {_Src, Sid}, [{_Index1, Role}, {Index2, Rmb}, {Index3, DuplicateInfo}]) ->
    case lists:keyfind(Sid, 2, DuplicateInfo) of
        false ->
            throw("input_error");
        Duplicate ->
            {_, Conditions} = zm_config:get('duplicate_reset', Sid),
            Day = time_lib:get_date_by_type('day_of_year'),
            Duplicate1 = duplicate:refresh(Duplicate, Day),
            DuplicateInfo1 = lists:keystore(duplicate:get_sid(Duplicate), 2, DuplicateInfo, Duplicate1),
            Bool1 = game_lib:checks({duplicate_lib, check}, {Role, DuplicateInfo1, Rmb}, {'reset_num', Sid}, Conditions),
            if
                Bool1 ->
                    {CS, {_, NDuplicateInfo1, Rmb1}} = game_lib:consumes({duplicate_lib, consume}, {Role, DuplicateInfo1, Rmb}, {'reset_num', Sid}, Conditions),
                    {ok, {Duplicate, lists:keyfind(Sid, 2, NDuplicateInfo1), CS}, [{Index2, Rmb1}, {Index3, NDuplicateInfo1}]};
                true ->
                    throw(Bool1)
            end
    end.


%%-------------------------------------------------------------------
%% @doc
%%      领取星星的奖励
%% @end
%%-------------------------------------------------------------------
-spec star_award(list(), tuple(), list()) ->
    string()|tuple().
star_award(_A, {Chapter, Index, AwardInfo}, [{_, DuplicateInfo}, {Index2, TimesSet}]) ->
    Value = case times_set_lib:get(TimesSet, {Chapter, Index}) of
        none ->
            0;
        {_, Number} ->
            Number
    end,
    if
        Value > 0 ->
            throw("duplicate_star_awarded");
        true ->
            {S, AwardSid} = erlang:element(Index, AwardInfo),
            Star = duplicate_lib:get_chapter_star(DuplicateInfo, Chapter),
            if
                Star >= S ->
                    NTimesSet = times_set_lib:update(TimesSet, {{Chapter, Index}, 1}),
                    {ok, {ok, AwardSid}, [{Index2, NTimesSet}]};
                true ->
                    throw("duplicate_star_limit")
            end
    end.

%%-------------------------------------------------------------------
%% @doc
%%      进行扫荡
%% @end
%%-------------------------------------------------------------------
-spec sweep(list(), tuple(), list()) -> tuple() | no_return().
sweep(_A, {Src, Sid, Number}, [{_, Role}, {Index2, DuplicateInfo}, {Index3, Restore}, {Index4, PubInfo}]) ->
    {Sid, Conditions, _} = zm_config:get('duplicate_sweep', Sid),
    {_, DuplicateCfg} = zm_config:get('duplicate', Sid),
    {_, Type} = lists:keyfind(type, 1, DuplicateCfg),
    {_, Con1} = zm_config:get(duplicate_info, condition),
    Bool0 = game_lib:checks({duplicate_lib, check}, {Role, PubInfo}, {'sweep', Sid, Number}, Con1),
    if
        Bool0 ->
            Bool1 = game_lib:checks({duplicate_lib, check}, {Role, DuplicateInfo, Restore}, {'sweep', Sid, Number}, Conditions),
            if
                Bool1 ->
                    {CS, {_, _, NRestore}} = game_lib:consumes({duplicate_lib, consume}, {Src, Role, Restore}, {'sweep', Number}, Conditions),
                    %% 添加每日次数
                    Day = time_lib:get_date_by_type('day_of_year'),
                    NDuplicate = duplicate:refresh(lists:keyfind(Sid, 2, DuplicateInfo), Day),
                    NDuplicateInfo = lists:keystore(Sid, 2, DuplicateInfo, duplicate:set_fight_num(NDuplicate, duplicate:get_fight_num(NDuplicate) + Number)),
                    NPubInfo = duplicate_lib:add_public_day_count(PubInfo, Type, Number),
                    {ok, {ok, CS, Role, duplicate_lib:get_type_by_sid(Sid), z_lib:get_value(DuplicateCfg, 'award_card_exp', 0)}, [{Index2, NDuplicateInfo}, {Index3, NRestore}, {Index4, NPubInfo}]};
                true ->
                    throw(Bool1)
            end;
        true ->
            throw(Bool0)
    end.

%%-------------------------------------------------------------------
%% @doc
%%      获取副本信息
%% @end
%%-------------------------------------------------------------------
-spec get_duplicate_info(Src :: atom(), RoleUid :: integer()) -> duplicate:duplicates().
get_duplicate_info(Src, RoleUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'duplicate_info'), RoleUid, []).

%%-------------------------------------------------------------------
%% @doc
%%      获取公用次数信息
%% @end
%%-------------------------------------------------------------------
-spec get_pulic_day_count(Src :: atom(), RoleUid :: integer()) -> duplicate:pub_times().
get_pulic_day_count(Src, RoleUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'duplicate_pub_info'), RoleUid, []).


%%-------------------------------------------------------------------
%% @doc
%%      获取类型对应的最新通过关卡
%% @end
%%-------------------------------------------------------------------
get_duplicate_progress(Src, RoleUid, DupTypeList) ->
    Duplicates = get_duplicate_info(Src, RoleUid),
    DupTypeSidList =
        z_lib:foreach(fun(Acc, Duplicate) ->
            Sid = duplicate:get_sid(Duplicate),
            DupType = duplicate_lib:get_type_by_sid(Sid),
            OSid = z_lib:get_value(Acc, DupType, 0),
            case Sid > OSid of
                true ->
                    {ok, lists:keystore(DupType, 1, Acc, {DupType, Sid})};
                false ->
                    {ok, Acc}
            end
        end, [], Duplicates),
    lists:reverse(z_lib:foreach(fun(Acc, DupType) ->
        {ok, [z_lib:get_value(DupTypeSidList, DupType, 0) | Acc]}
    end, [], DupTypeList)).
%%-------------------------------------------------------------------
%% @doc
%%      名将副本换将
%% @end
%%-------------------------------------------------------------------
famous_duplicate_change_card(_A, {Sid, DuplicateInfo, Consumes, ToDay}, [{Index1, FamousDupInfo}, {Index2, Rmb}]) ->
    FamousDupInfo1 = famous_duplicate:refresh(FamousDupInfo, 'day', ToDay),
    Bool1 = game_lib:checks({duplicate_lib, check}, {FamousDupInfo1, DuplicateInfo, Rmb}, {'famous_duplicate_change_card', Sid}, Consumes),
    if
        Bool1 ->
            {Cs, {FamousDupInfo2, NRmb}} = game_lib:consumes({duplicate_lib, consume}, {FamousDupInfo1, Rmb}, {'famous_duplicate_change_card', Sid}, Consumes),
            FamousDupInfo3 = famous_duplicate:refresh(FamousDupInfo2, {'duplicate_npc_index', [Sid]}, 0),
            {ok, {Cs, FamousDupInfo3}, [{Index1, FamousDupInfo3}, {Index2, NRmb}]};
        true ->
            throw(Bool1)
    end.


%%%=====================LOCAL FUNCTIONS=================
