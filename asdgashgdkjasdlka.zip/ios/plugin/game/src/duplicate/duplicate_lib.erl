%%副本工具
-module(duplicate_lib).
-description("duplicate_lib").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([update_record/3, get_star/3, get_all_star/1, get_chapter_star/2, get_type_by_sid/1]).
-export([check/3, consume/3, star_format/1, add_public_day_count/3,
    get_public_day_count/2, format_duplicate/2, get_public_day_count_list/2]).
%%%=======================DEFINE========================

%%%=======================INCLUDE=======================

%%%=================EXPORTED FUNCTIONS====================
%% ----------------------------------------------------
%% @doc
%%      获得玩家关卡总星级,只获取玩家,普通副本关卡星级(副本类型为1,2,3)
%% @end
%% ----------------------------------------------------
-spec get_star(list(), atom(), integer()) -> integer().
get_star(_A, Src, RoleUid) ->
    DuplicateInfo = duplicate_db:get_duplicate_info(Src, RoleUid),
    get_all_star(DuplicateInfo).

%% ----------------------------------------------------
%% @doc
%%      获得玩家关卡总星级,只获取玩家,普通副本关卡星级(副本类型为1,2,3)
%% @end
%% ----------------------------------------------------
get_all_star(Duplicates) ->
    lists:sum([duplicate:get_star(Duplicate) || Duplicate <- Duplicates]).

%% ----------------------------------------------------
%% @doc
%%      获得本章星星总数
%% @end
%% ----------------------------------------------------
-spec get_chapter_star(duplicate:duplicates(), integer()) -> integer().
get_chapter_star(DuplicateInfo, Chapter) ->
    F = fun(Duplicate, Sum) ->
        case duplicate:get_chapter(Duplicate) of
            Chapter ->
                duplicate:get_star(Duplicate) + Sum;
            _ ->
                Sum
        end
    end,
    lists:foldl(F, 0, DuplicateInfo).
%% ----------------------------------------------------
%% @doc
%%      获得关卡每天次数(增加vip增加的次数)
%% @end
%% ----------------------------------------------------
-spec get_dup_day_times(role:role(), integer(), integer()) -> integer().
get_dup_day_times(Role, Num, Type) ->
    Num + vip_lib:duplicate_fight_count(Role, Type).

%% ----------------------------------------------------
%% @doc
%%      获得关卡type
%% @end
%% ----------------------------------------------------
-spec get_type_by_sid(integer()) -> integer().
get_type_by_sid(Sid) ->
    {_, Duplicate} = zm_config:get('duplicate', Sid),
    {_, Type} = lists:keyfind(type, 1, Duplicate),
    Type.

%% ----------------------------------------------------
%% @doc
%%      进行更新挑战记录
%% @end
%% ----------------------------------------------------
-spec update_record(duplicate:duplicates(), integer(), integer()) -> duplicate:duplicates().
update_record(DuplicateInfo, _Sid, 0) ->
    DuplicateInfo;
update_record(DuplicateInfo, Sid, Star) ->
    case lists:keyfind(Sid, 2, DuplicateInfo) of
        false ->
            lists:keystore(Sid, 2, DuplicateInfo, duplicate:init(Sid, 1, Star));
        D ->
            Day = time_lib:get_date_by_type('day_of_year'),
            Duplicate = duplicate:refresh(D, Day),
            OStar = duplicate:get_star(Duplicate),
            if
                OStar > Star ->
                    lists:keystore(Sid, 2, DuplicateInfo, duplicate:set_fight_num(Duplicate, duplicate:get_fight_num(Duplicate) + 1));
                true ->
                    lists:keystore(Sid, 2, DuplicateInfo, duplicate:set_fight_num(duplicate:set_star(Duplicate, Star), duplicate:get_fight_num(Duplicate) + 1))
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      星星格式化
%% @end
%% ----------------------------------------------------
-spec star_format([{integer(), integer()}]) -> tuple().
star_format(List) ->
    star_format(List, []).
star_format([{{Chapter, Index}, _} | T], L) ->
    case lists:keyfind(Chapter, 1, L) of
        false ->
            star_format(T, [{Chapter, {Index}} | L]);
        {Chapter, Indexs} ->
            star_format(T, lists:keyreplace(Chapter, 1, L, {Chapter, erlang:append_element(Indexs, Index)}))
    end;
star_format([], L) ->
    erlang:list_to_tuple(L).

%% ----------------------------------------------------
%% @doc
%%      根据副本类型获取给予前台展示的副本信息
%% @end
%% ----------------------------------------------------
-spec format_duplicate(DuplicateInfo, Type) -> [{Sid, Day, DayFightNum, ResetNum, Star}] when
    DuplicateInfo :: duplicate:duplicates(),
    Type :: integer()|[integer()],
    Sid :: integer(),
    Day :: integer(),
    DayFightNum :: integer(),
    ResetNum :: integer(),
    Star :: integer().
format_duplicate(DuplicateInfo, Type) when is_integer(Type) ->
    format_duplicate(DuplicateInfo, [Type]);
format_duplicate(DuplicateInfo, TypeList) ->
    Day = time_lib:get_date_by_type('day_of_year'),
    [begin NDuplicate = duplicate:refresh(Duplicate, Day),
    Sid = duplicate:get_sid(NDuplicate),
    {_, DupConfig} = zm_config:get('duplicate', Sid),
    DayFightNum = case lists:keyfind('conditions', 1, DupConfig) of
        {_, Con1} ->
            case lists:keyfind('day_num', 1, Con1) of
                {_, SidList, _} ->
                    get_day_fight_num(DuplicateInfo, SidList);
                _ ->
                    0
            end;
        _ ->
            0
    end,
    {Sid,
        duplicate:get_day(NDuplicate),
        DayFightNum,
        duplicate:get_reset_num(NDuplicate),
        duplicate:get_star(NDuplicate)}
    end || Duplicate <- DuplicateInfo, lists:member(duplicate_lib:get_type_by_sid(duplicate:get_sid(Duplicate)), TypeList)].


%%%=====================LOCAL FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      检查
%% @end
%% ----------------------------------------------------
-spec check(term(), term(), tuple()) -> boolean().
check(DuplicateInfo, 'duplicate_award_box', {'node', Value}) ->
    case lists:keyfind(Value, 2, DuplicateInfo) of
        false ->
            false;
        _ ->
            true
    end;
%%校验pve,pvp
check({_Role, _DuplicateInfo, Restore}, {'sweep', _Sid, Number}, {Type, Value}) when Type =:= 'pve';Type =:= 'pvp' ->
    P = restore_lib:get_value(Restore, Type),
    abs(P) >= abs(Value * Number);
%%vip条件判断
check({Role, _DuplicateInfo, _Restore}, {'sweep', _Sid, _Number}, {'vip_level', Value}) ->
    game_lib:get_level(vip, Role) >= Value;
%%校验等级是否达到
check({Role, _DuplicateInfo, _Restore}, {'sweep', _Sid, _Number}, {'role_level', Level}) ->
    game_lib:get_level('role', Role) >= Level;
%%校验星星条件
check({_Role, DuplicateInfo, _Restore}, {'sweep', Sid, _Number}, {'star', Value}) ->
    case lists:keyfind(Sid, 2, DuplicateInfo) of
        false ->
            false;
        Duplicate ->
            duplicate:get_star(Duplicate) >= Value
    end;
%%校验次数是否通过
check({Role, DuplicateInfo, _Restore}, {'sweep', Sid, Number}, {'day_num', SidList, Num}) ->
    check_day_fight_num(Role, DuplicateInfo, Sid, Num, SidList, Number);
%%扫荡  校验公用次数是否足够
check({_Role, PubInfo}, {'sweep', Sid, Number}, {'public_day_count', L}) ->
    check_public_day_count(Sid, L, PubInfo, Number);
%%校验点是否通过
check({_Role, DuplicateInfo, _Rmb}, {'reset_num', _Sid}, {'node', CSids}) when is_list(CSids) ->
    [CSid || CSid <- CSids, false =/= lists:keyfind(CSid, 2, DuplicateInfo)] =:= CSids;
%%校验点是否通过
check({_Role, DuplicateInfo, _Rmb}, {'reset_num', _Sid}, {'node', CSid}) ->
    false =/= lists:keyfind(CSid, 2, DuplicateInfo);
%%校验重置次
check({Role, DuplicateInfo, _Rmb}, {'reset_num', Sid}, {'reset', Num}) ->
    case lists:keyfind(Sid, 2, DuplicateInfo) of
        false ->
            false;
        Duplicate ->
            Type = get_type_by_sid(Sid),
            VipResetNum = vip_lib:duplicate_reset_count(Role, Type),
            duplicate:get_reset_num(Duplicate) < VipResetNum + Num
    end;
%%校验rmb是否够
check({_Role, _DuplicateInfo, Rmb}, {'reset_num', Sid}, {'rmb', List}) ->
    Duplicate = lists:keyfind(Sid, 2, _DuplicateInfo),
    ResetNum = duplicate:get_reset_num(Duplicate),
    NeedRmb = if
        ResetNum + 1 > size(List) ->
            erlang:element(size(List), List);
        true ->
            erlang:element(ResetNum + 1, List)
    end,
    rmb_lib:get_rmb(Rmb) >= NeedRmb;
%%校验等级是否达到
check({Role, _DuplicateInfo, _Restore, _Sid}, 'fight', {'role_level', Level}) ->
    game_lib:get_level('role', Role) >= Level;
%%vip条件判断
check({Role, _DuplicateInfo, _Restore, _Sid}, 'fight', {'vip_level', Level}) ->
    game_lib:get_level('vip', Role) >= Level;
%%校验pve,pvp是否够
check({_Role, _DuplicateInfo, Restore, _Sid}, 'fight', {Type, Value}) when Type =:= 'pve';Type =:= 'pvp' ->
    P = restore_lib:get_value(Restore, Type),
    P >= abs(Value);
%%校验点是否通过
check({_Role, DuplicateInfo, _Restore, _Sid}, 'fight', {'node', CSids}) when is_list(CSids) ->
    [CSid || CSid <- CSids, false =/= lists:keyfind(CSid, 2, DuplicateInfo)] =:= CSids;
%%校验点是否通过
check({_Role, DuplicateInfo, _Restore, _Sid}, 'fight', {'node', CSid}) ->
    false =/= lists:keyfind(CSid, 2, DuplicateInfo);
%%校验次数是否通过
check({Role, DuplicateInfo, _Restore, Sid}, 'fight', {'day_num', SidList, Num}) ->
    check_day_fight_num(Role, DuplicateInfo, Sid, Num, SidList, 1);
%%校验星星条件
check({_Role, DuplicateInfo, _Restore, Sid}, 'fight', {'star', Num}) ->
    case lists:keyfind(Sid, 2, DuplicateInfo) of
        false ->
            false;
        Duplicate ->
            duplicate:get_star(Duplicate) >= Num
    end;
%%校验公用次数是否用完
check({PubInfo, Sid}, 'fight2', {'public_day_count', L}) ->
    check_public_day_count(Sid, L, PubInfo, 1);
%%校验点是否通过
check({_FamousDupInfo, DuplicateInfo, _Rmb}, {'famous_duplicate_change_card', _Sid}, {'node', CSids}) when is_list(CSids) ->
    [CSid || CSid <- CSids, false =/= lists:keyfind(CSid, 2, DuplicateInfo)] =:= CSids;
%%校验点是否通过
check({_FamousDupInfo, DuplicateInfo, _Rmb}, {'famous_duplicate_change_card', _Sid}, {'node', CSid}) ->
    false =/= lists:keyfind(CSid, 2, DuplicateInfo);
%%校验重置次
check({FamousDupInfo, _DuplicateInfo, _Rmb}, {'famous_duplicate_change_card', Sid}, {'reset', Num}) ->
    ChangeCardTimes = famous_duplicate:get_change_card_times(FamousDupInfo),
    Times = case lists:keyfind(Sid, 1, ChangeCardTimes) of
        false ->
            0;
        {_, TimesTmp} ->
            TimesTmp
    end,
    Times < Num;
%%校验rmb是否够
check({FamousDupInfo, _DuplicateInfo, Rmb}, {'famous_duplicate_change_card', Sid}, {'rmb', List}) ->
    ChangeCardTimes = famous_duplicate:get_change_card_times(FamousDupInfo),
    Times = case lists:keyfind(Sid, 1, ChangeCardTimes) of
        false ->
            0;
        {_, TimesTmp} ->
            TimesTmp
    end,
    NeedRmb = if
        Times + 1 > size(List) ->
            erlang:element(size(List), List);
        true ->
            erlang:element(Times + 1, List)
    end,
    rmb_lib:get_rmb(Rmb) >= NeedRmb;
check(_, _, _) ->
    false.

%% ----------------------------------------------------
%% @doc
%%      消耗
%% @end
%% ----------------------------------------------------
-spec consume(term(), term(), tuple()) -> {term(), term()}.
%% 消耗pve,pvp
consume({Src, Role, Restore}, 'fight', {Type, Value}) when Type =:= 'pve';Type =:= 'pvp' ->
    NRestore = restore_lib:update(Restore, time_lib:now_second(), restore_lib:get_max(Src, Role, Type), Type, -Value),
    {{Type, Value, restore_lib:get_value(NRestore, Type)}, {Src, Role, NRestore}};
%%扫荡消耗pve,pvp
consume({Src, Role, Restore}, {'sweep', Number}, {Type, Value}) when Type =:= 'pve';Type =:= 'pvp' ->
    NRestore = restore_lib:update(Restore, time_lib:now_second(), restore_lib:get_max(Src, Role, Type), Type, -Number * Value),
    {{Type, Number * Value, restore_lib:get_value(NRestore, Type)}, {Src, Role, NRestore}};
%% 重置消耗rmb
consume({Role, DuplicateInfo, Rmb}, {'reset_num', Sid}, {'rmb', List}) ->
    Duplicate = lists:keyfind(Sid, 2, DuplicateInfo),
    ResetNum = duplicate:get_reset_num(Duplicate),
    NeedRmb = if
        ResetNum + 1 > size(List) ->
            erlang:element(size(List), List);
        true ->
            erlang:element(ResetNum + 1, List)
    end,
    {CS, NRmb} = rmb_lib:reduct_rmb(Rmb, NeedRmb),
    {CS, {Role, lists:keystore(Sid, 2, DuplicateInfo, duplicate:set_fight_num(duplicate:set_reset_num(Duplicate, ResetNum + 1), 0)), NRmb}};
%% 重置消耗rmb
consume({FamousDupInfo, Rmb}, {'famous_duplicate_change_card', Sid}, {'rmb', List}) ->
    ChangeCardTimes = famous_duplicate:get_change_card_times(FamousDupInfo),
    Times = case lists:keyfind(Sid, 1, ChangeCardTimes) of
        false ->
            0;
        {_, TimesTmp} ->
            TimesTmp
    end,
    NeedRmb = if
        Times + 1 > size(List) ->
            erlang:element(size(List), List);
        true ->
            erlang:element(Times + 1, List)
    end,
    {CS, NRmb} = rmb_lib:reduct_rmb(Rmb, NeedRmb),
    NChangeCardTimes = lists:keystore(Sid, 1, ChangeCardTimes, {Sid, Times + 1}),
    {CS, {famous_duplicate:set_change_card_times(FamousDupInfo, NChangeCardTimes), NRmb}};
consume(Tables, _, _) ->
    {'none', Tables}.

%% ----------------------------------------------------
%% @doc
%%      检测公共次数
%% @end
%% ----------------------------------------------------
-spec check_public_day_count(integer(), list(), duplicate:pub_times(), integer()) -> boolean().
check_public_day_count(Sid, _L, PubInfo, Number) ->
    Type = get_type_by_sid(Sid),
    {Id, _, MaxTims} = get_public_info(Type),
    if
        Id =:= 0 ->
            true;
        true ->
            get_public_day_count(PubInfo, Id) + Number =< MaxTims
    end.

%% ----------------------------------------------------
%% @doc
%%      获取公共次数信息
%% @end
%% ----------------------------------------------------
-spec get_public_info(Type) -> {Id, Types, MaxTims} when
    Type :: integer(),
    Id :: integer(),
    Types :: [integer()],
    MaxTims :: integer().
get_public_info(Type) ->
    {_, Con1} = zm_config:get('duplicate_info', 'condition'),
    List = case lists:keyfind('public_day_count', 1, Con1) of
        false ->
            [];
        {_, PubList} ->
            PubList
    end,
    F = fun(A, {_, ConList, _} = Info) ->
        Bool = lists:member(Type, ConList),
        if
            Bool -> {break, Info};
            true -> {ok, A}
        end
    end,
    z_lib:foreach(F, {0, [], 0}, List).


%% ----------------------------------------------------
%% @doc
%%      增加公共次数
%% @end
%% ----------------------------------------------------
-spec add_public_day_count(duplicate:pub_times(), integer(), integer()) -> duplicate:pub_times().
add_public_day_count(PubInfo, Type, Number) ->
    Day = time_lib:get_date_by_type('day_of_year'),
    {ID, _, _} = get_public_info(Type),
    if
        ID =:= 0 ->
            PubInfo;
        true ->
            case lists:keyfind('public_day_count', 1, PubInfo) of
                {_, DC} ->
                    case lists:keyfind(ID, 1, DC) of
                        {_, {Day, Count}} ->
                            lists:keyreplace('public_day_count', 1, PubInfo,
                                {'public_day_count', lists:keystore(ID, 1, DC, {ID, {Day, Count + Number}})});
                        _ ->
                            lists:keyreplace('public_day_count', 1, PubInfo,
                                {'public_day_count', lists:keystore(ID, 1, DC, {ID, {Day, Number}})})
                    end;
                _ ->
                    [{'public_day_count', [{ID, {Day, Number}}]} | PubInfo]
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      获取公共次数
%% @end
%% ----------------------------------------------------
-spec get_public_day_count(duplicate:pub_times(), integer()) -> integer().
get_public_day_count(PubInfo, Id) ->
    Day = time_lib:get_date_by_type('day_of_year'),
    case lists:keyfind('public_day_count', 1, PubInfo) of
        {_, DC} ->
            case lists:keyfind(Id, 1, DC) of
                {_, {Day, N}} ->
                    N;
                _ ->
                    0
            end;
        _ ->
            0
    end.

%% ----------------------------------------------------
%% @doc
%%      获取公共次数 列表
%% @end
%% ----------------------------------------------------
-spec get_public_day_count_list(duplicate:pub_times(), [integer()]) -> [{integer(), integer()}].
get_public_day_count_list(PubInfo, TypeList) ->
    [begin
        {ID, _, _} = get_public_info(Type),
        {Type, get_public_day_count(PubInfo, ID)}
    end || Type <- TypeList].


%% ----------------------------------------------------
%% @doc
%%      检测每日次数是否足够
%% @end
%% ----------------------------------------------------
-spec check_day_fight_num(Role, DuplicateInfo, Sid, Num, SidList, CTimes) -> boolean() when
    Role :: role:role(),
    DuplicateInfo :: duplicate:duplicates(),
    Sid :: integer(),
    Num :: integer(),
    SidList :: [integer()],
    CTimes :: integer().
check_day_fight_num(Role, DuplicateInfo, Sid, Num, SidList, CTimes) ->
    Type = get_type_by_sid(Sid),
    {_, CL} = zm_config:get('duplicate', Sid),
    AddDayNumList = z_lib:get_value(CL, 'add_day_num', []),
    AddDayNum = lists:foldl(fun({'week_day', WDList}, C) ->
        C + z_lib:get_value(WDList, time_lib:get_date_by_type('day_of_week'), 0)
    end, 0, AddDayNumList),
    DayMaxTimes = get_dup_day_times(Role, Num + AddDayNum, Type),
    %%已经打过的副本列表中不存在该副本则直接允许攻打,注意:判断是否有前置node的条件需要放在次数之前
    DayNum = get_day_fight_num(DuplicateInfo, SidList),
    DayNum + CTimes =< DayMaxTimes.

%% ----------------------------------------------------
%% @doc
%%      获取每日次数
%% @end
%% ----------------------------------------------------
-spec get_day_fight_num(DuplicateInfo, SidList) -> integer() when
    DuplicateInfo :: duplicate:duplicates(),
    SidList :: [integer()].
get_day_fight_num(DuplicateInfo, SidList) ->
    %%已经打过的副本列表中不存在该副本则直接允许攻打,注意:判断是否有前置node的条件需要放在次数之前
    lists:sum([begin case lists:keyfind(S, 2, DuplicateInfo) of
        false ->
            0;
        Dup ->
            Day = time_lib:get_date_by_type('day_of_year'),
            NDuplicate = duplicate:refresh(Dup, Day),
            duplicate:get_fight_num(NDuplicate)
    end end || S <- SidList]).