-module(famous_duplicate).

%%%=======================STATEMENT====================
-description("famous_duplicate").
-copyright('youkia,www.youkia.net').
-author("ljh,lvjihong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================

-export([get_day/1, get_famous_duplicate_npc_indexs/1, get_change_card_times/1]).
-export([set_day/2, set_famous_duplicate_npc_indexs/2, set_change_card_times/2]).
-export([init/0, refresh/3]).

%%%=======================INCLUDE======================
-include("../include/duplicate.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(famous_duplicate, {
    day = 0 :: integer(),            %%刷新日子
    famous_duplicate_npc_indexs = [] :: list(),  %%难度副本怪物索引号[{1,IndexA},{2,IndexB}..]，现在共五个副本
    change_card_times = [] %%换将次数
}).
%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        获取刷新day
%% @end
%% ----------------------------------------------------
get_day(#famous_duplicate{day = V}) ->
    V.
%% ----------------------------------------------------
%% @doc
%%        获取名将副本npc索引
%% @end
%% ----------------------------------------------------
get_famous_duplicate_npc_indexs(#famous_duplicate{famous_duplicate_npc_indexs = V}) ->
    V.
%% ----------------------------------------------------
%% @doc
%%        设置刷新day
%% @end
%% ----------------------------------------------------
set_day(FamousDuplicate, V) ->
    FamousDuplicate#famous_duplicate{day = V}.
%% ----------------------------------------------------
%% @doc
%%        设置名将副本npc索引
%% @end
%% ----------------------------------------------------
set_famous_duplicate_npc_indexs(FamousDuplicate, V) ->
    FamousDuplicate#famous_duplicate{famous_duplicate_npc_indexs = V}.
%% ----------------------------------------------------
%% @doc
%%        获取名将副本换将次数
%% @end
%% ----------------------------------------------------
get_change_card_times(#famous_duplicate{change_card_times = V}) ->
    V.
%% ----------------------------------------------------
%% @doc
%%        设置名将副本换将次数
%% @end
%% ----------------------------------------------------
set_change_card_times(FamousDuplicate, V) ->
    FamousDuplicate#famous_duplicate{change_card_times = V}.
%% ----------------------------------------------------
%% @doc
%%        初始化
%% @end
%% ----------------------------------------------------
init() ->
    #famous_duplicate{}.


%% ----------------------------------------------------
%% @doc
%%        刷新
%% @end
%% ----------------------------------------------------
refresh(FamousDuplicate, 'day', Day) ->
    case get_day(FamousDuplicate) =:= Day of
        true ->
            FamousDuplicate;
        false ->
            {_, FasmousDupSids} = zm_config:get('duplicate_info', 'famous_duplicate'),
            FamousDuplicate1 = refresh(FamousDuplicate, {'duplicate_npc_index', FasmousDupSids}, Day),
            FamousDuplicate2 = refresh(FamousDuplicate1, {'famous_duplicate_change_card', FasmousDupSids}, Day),
            set_day(FamousDuplicate2, Day)
    end;
refresh(FamousDuplicate, {'duplicate_npc_index', FasmousDupSids}, _Day) ->
    DiffIndexs = get_famous_duplicate_npc_indexs(FamousDuplicate),
    Fun1 = fun(FasmousDupSid, AccDiffIndexs) ->
        {_, DuplicateInfo} = zm_config:get('duplicate', FasmousDupSid),
        {_, NpcArrayTuple} = lists:keyfind('npc_array_sid', 1, DuplicateInfo),
        Index = z_lib:random(1, tuple_size(NpcArrayTuple)),
        lists:keystore(FasmousDupSid, 1, AccDiffIndexs, {FasmousDupSid, Index})
    end,
    NDiffIndexs = lists:foldl(Fun1, DiffIndexs, FasmousDupSids),
    set_famous_duplicate_npc_indexs(FamousDuplicate, NDiffIndexs);
refresh(FamousDuplicate, {'famous_duplicate_change_card', FasmousDupSids}, Day) ->
    NChangeCardTimes =
        case get_day(FamousDuplicate) =:= Day of
            true ->
                ChangeCardTimes = get_change_card_times(FamousDuplicate),
                Fun1 = fun(FamousDupSid, AccChangCardTimes) ->
                    case lists:keyfind(FamousDupSid, 1, AccChangCardTimes) of
                        false ->
                            [{FamousDupSid, 1} | AccChangCardTimes];
                        {_, Times} ->
                            lists:keystore(FamousDupSid, 1, AccChangCardTimes, {FamousDupSid, Times + 1})
                    end
                end,
                lists:foldl(Fun1, ChangeCardTimes, FasmousDupSids);
            false ->
                []
        end,
    set_change_card_times(FamousDuplicate, NChangeCardTimes).
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
