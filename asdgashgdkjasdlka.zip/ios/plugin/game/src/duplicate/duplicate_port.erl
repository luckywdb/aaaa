%%关卡端口
-module(duplicate_port).
-description("duplicate_port").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_duplicate_info/5, get_star_award/5, get_duplicate_type_info/5, get_duplicate_award_box/5,
    fight/5, reset_num/5, star_award/5, sweep/5, duplicate_award_box/5, get_famous_duplicate_info/5, famous_duplicate_change_card/5]).

%%%=======================DEFINE======================
-define(SWEEP_MAX_NUM, 20).
%%%=======================INCLUDE======================
-include("../include/duplicate.hrl").

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      得到通关副本信息
%% @end
%% ----------------------------------------------------
get_duplicate_info(_A, _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    Reply = list_to_tuple(duplicate_lib:format_duplicate(duplicate_db:get_duplicate_info(Src, RoleUid), ?DUPLICATE_TYPE_NORMAL_LIST)),
    DuplicateTimes = duplicate_lib:get_public_day_count_list(duplicate_db:get_pulic_day_count(Src, RoleUid), ?DUPLICATE_TYPE_NORMAL_LIST),
    {ok, [], Info, [{'msg', {Reply, list_to_tuple(DuplicateTimes)}}]}.

%% ----------------------------------------------------
%% @doc
%%      获得领奖星星的记录
%% @end
%% ----------------------------------------------------
get_star_award(_Args, _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    Reply = duplicate_lib:star_format(z_db_lib:get(game_lib:get_table(Src, 'times_set'), {RoleUid, 2}, [])),
    {ok, [], Info, [{msg, Reply}]}.

%% ----------------------------------------------------
%% @doc
%%      获得关卡宝箱领取记录
%% @end
%% ----------------------------------------------------
get_duplicate_award_box(_Args, _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    Reply = z_db_lib:get(game_lib:get_table(Src, 'times_set'), {RoleUid, 3}, []),
    {ok, [], Info, [{msg, list_to_tuple(Reply)}]}.

%% ----------------------------------------------------
%% @doc
%%      得到通关副本信息,指定关卡类型,根据章节获取挑战次数
%% @end
%% ----------------------------------------------------
get_duplicate_type_info(_A, _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    TypeList = [list_to_integer(Id) || Id <- string:tokens(z_lib:get_value(Msg, "type", "0"), ",")],
    DuplicateInfo = duplicate_db:get_duplicate_info(Src, RoleUid),
    Reply = list_to_tuple(duplicate_lib:format_duplicate(DuplicateInfo, TypeList)),
    DuplicateTimes = duplicate_lib:get_public_day_count_list(duplicate_db:get_pulic_day_count(Src, RoleUid), TypeList),
    {ok, [], Info, [{'msg', {Reply, list_to_tuple(DuplicateTimes)}}]}.

%% ----------------------------------------------------
%% @doc
%%      领取关卡奖励宝箱
%% @end
%% ----------------------------------------------------
duplicate_award_box(_, _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    Sid = z_lib:get_value(Msg, "sid", 0),
    if
        Sid =:= 0 ->
            {ok, [], Info, [{msg, "input_error"}]};
        true ->
            case zm_config:get('duplicate_award_box', Sid) of
                none ->
                    {ok, [], Info, [{msg, "input_error"}]};
                {_, AwardSid, Conditions} ->
                    DuplicateInfo = z_db_lib:get(game_lib:get_table(Src, 'duplicate_info'), RoleUid, []),
                    case game_lib:checks({duplicate_lib, check}, DuplicateInfo, 'duplicate_award_box', Conditions) of
                        true ->
                            Fun = fun(_, TimeSet) ->
                                Value =
                                    case times_set_lib:get(TimeSet, Sid) of
                                        none ->
                                            0;
                                        {_, Number} ->
                                            Number
                                    end,
                                if
                                    Value > 0 ->
                                        {ok, "duplicate_box_awarded"};
                                    true ->
                                        {ok, ok, times_set_lib:update(TimeSet, {Sid, 1})}
                                end
                            end,
                            Reply =
                                case z_db_lib:update(game_lib:get_table(Src, 'times_set'), {RoleUid, 3}, [], Fun, []) of
                                    ok ->
                                        AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, AwardSid),
                                        zm_log:info(Src, ?MODULE, 'duplicate_award_box', "duplicate_award_box",
                                            [{'roleuid', RoleUid}, {'sid', Sid}, {'award', AwardLog}]),
                                        zm_event:notify(Src, 'bi_duplicate_award_box', [{'role_uid', RoleUid},
                                            {'award', AwardLog}, {'sid', Sid}]),
                                        AwardLog;
                                    Other ->
                                        Other
                                end,
                            {ok, [], Info, [{msg, Reply}]};
                        Reasion ->
                            {ok, [], Info, [{msg, Reasion}]}
                    end
            end
    end.
%% ----------------------------------------------------
%% @doc
%%      副本战斗
%% @end
%% ----------------------------------------------------
fight([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    Sid = z_lib:get_value(Msg, "sid", 0),
    Gid = z_lib:get_value(Msg, "gid", 1),
    CheckVaild = valid_lib:check_valib([{'unequal', Sid, 0}, {'range', Gid, {1, garray_lib:get_max_gid()}}]),
    if
        CheckVaild ->
            restore_db:restore(Src, RoleUid),
            %% 	%%初始化队伍，初始化怪物
            Garray = garray_db:get_garray(Src, RoleUid, Gid),
            FightBool = garray:check_fight_dup(Garray),
            if
                FightBool ->
                    case zm_config:get('duplicate', Sid) of
                        'none' ->
                            {ok, [], Info, [{msg, "input_error"}]};
                        _ ->
                            Type = duplicate_lib:get_type_by_sid(Sid),
                            Reply = if
                                Type =:= ?DUPLICATE_TYPE_FAMOUS ->
                                    Castle = castle_db:get_castle(Src, RoleUid),
                                    Building = castle:get_building(Castle),
                                    BlackMarketBSid = building_lib:get_bsid('black_market'),
                                    BreasureBSid = building_lib:get_bsid('treasure'),
                                    case lists:keyfind(BlackMarketBSid, 2, Building) =:= false orelse lists:keyfind(BreasureBSid, 2, Building) =:= false of
                                        true ->
                                            "no_treasure_house_or_black_market";
                                        false ->
                                            fight_(Src, [{M, F, A}], Sid, Type, RoleUid, Gid, Garray)
                                    end;
                                true ->
                                    fight_(Src, [{M, F, A}], Sid, Type, RoleUid, Gid, Garray)
                            end,
%%                    test_statistics:millisecond('duplicate_fight', StartMs),
                            {ok, [], Info, [{msg, Reply}]}
                    end;
                true ->
                    {ok, [], Info, [{msg, "garray_error"}]}
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.
%% ----------------------------------------------------
%% @doc
%%      重置次数
%% @end
%% ----------------------------------------------------
reset_num([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    TableName = game_lib:get_table(Src),
    Sid = z_lib:get_value(Msg, "sid", 0),
    if
        Sid =:= 0 ->
            {ok, [], Info, [{msg, "input_error"}]};
        true ->
            case zm_config:get('duplicate_reset', Sid) of
                none ->
                    {ok, [], Info, [{msg, "duplicate_no_reset"}]};
                _ ->
                    case duplicate_lib:get_type_by_sid(Sid) =:= ?DUPLICATE_TYPE_FAMOUS of
                        false ->
                            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'role', RoleUid},
                                {'rmb', RoleUid, rmb_lib:init()},
                                {'duplicate_info', RoleUid, []}]),
                            Reply = case z_db_lib:handle(TableName, {M, F, A}, {Src, Sid}, TableKeys) of
                                {_OldD, _NewD, CS} ->
                                    zm_log:info(Src, ?MODULE, 'reset_num', "duplicate_reset_num",
                                        [{'roleuid', RoleUid}, {'sid', Sid}, {'consume', CS}]),
                                    %% 关卡重置事件
                                    zm_event:notify(Src, 'bi_duplicate_reset', [{'role_uid', RoleUid}, {'sid', Sid}, {'consume', CS}]),
                                    zm_event:notify(Src, 'active_consume', {RoleUid, CS}),
                                    ok;
                                Other ->
                                    Other
                            end,
                            {ok, [], Info, [{msg, Reply}]};
                        true ->
                            {ok, [], Info, [{msg, "input_error"}]}
                    end
            end
    end.
%% ----------------------------------------------------
%% @doc
%%      星星领奖
%% @end
%% ----------------------------------------------------
star_award([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    Chapter = z_lib:get_value(Msg, "chapter", 0),
    Index = z_lib:get_value(Msg, "index", 0),
    CheckVaild = valid_lib:check_valib([{'unequal', Chapter, 0}, {'ge', Index, 1}]),
    if
        CheckVaild ->
            case zm_config:get(duplicate_star_award, Chapter) of
                {Chapter, AwardInfo} when Index =< erlang:size(AwardInfo) ->
                    TableName = game_lib:get_table(Src),
                    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'duplicate_info', RoleUid, []}, {'times_set', {RoleUid, 2}, []}]),
                    Reply1 = case z_db_lib:handle(TableName, {M, F, A}, {Chapter, Index, AwardInfo}, TableKeys) of
                        {ok, AwardSid} ->
                            AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, AwardSid),
                            zm_log:info(Src, ?MODULE, 'star_award', "duplicate_star_award",
                                [{'roleuid', RoleUid}, {'chapter', Chapter}, {'index', Index}, {'award', AwardLog}]),
                            %% 星级奖励事件
                            zm_event:notify(Src, 'bi_duplicate_star_award', [{'role_uid', RoleUid}, {'sid', Chapter}, {'index', Index}, {'award', AwardLog}]),
                            AwardLog;
                        Reply ->
                            Reply
                    end,
                    {ok, [], Info, [{msg, Reply1}]};
                _ ->
                    {ok, [], Info, [{msg, "input_error"}]}
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.
%% ----------------------------------------------------
%% @doc
%%      扫荡
%% @end
%% ----------------------------------------------------
sweep([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    Sid = z_lib:get_value(Msg, "sid", 0),
    Gid = z_lib:get_value(Msg, "gid", 0),
    Number = z_lib:get_value(Msg, "number", 1),
    CheckVaild = valid_lib:check_valib([{'unequal', Sid, 0}, {'range', Gid, {1, garray_lib:get_max_gid()}}, {'range', Number, {1, ?SWEEP_MAX_NUM}}]),
    if
        CheckVaild ->
            case zm_config:get('duplicate_sweep', Sid) of
                none ->
                    {ok, [], Info, [{msg, "input_error"}]};
                {_, _, AwardSidTuple} ->
                    AwardSid = element(1, AwardSidTuple),
                    restore_db:restore(Src, RoleUid),
                    TableName = game_lib:get_table(Src),
                    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'role', RoleUid}, {'duplicate_info', RoleUid, []},
                        {'role_restore', RoleUid, restore_db:init(Src, RoleUid)},
                        {'duplicate_pub_info', RoleUid, []}]),
                    Reply1 = case z_db_lib:handle(TableName, {M, F, A}, {Src, Sid, Number}, TableKeys) of
                        {ok, CS, _Role, DupType, BaseExp} ->
                            %%双倍活动
                            Multi = case lists:member(DupType, ?DUPLICATE_TYPE_NORMAL_LIST) of
                                true ->
                                    active_addition:get_duplicate_drop_multi(Src);
                                false -> 1
                            end,
                            %%扫荡多次需要奖励分开,则预奖励分为多次,然后整合之后奖励只发一次
                            AwardList = awarder_game:award_percent(AwardSid, Multi),
                            ActiveDropAwardList = active_duplicate_drop:get_active_duplicate_drops(Src, Sid),
                            NActiveDropAwardList = awarder_game:award_percent(ActiveDropAwardList, Multi),
                            AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, AwardList ++ NActiveDropAwardList, Number),
                            AddCardExp = role_addition:get_card_exp(Src, RoleUid, BaseExp) * Number * Multi div 10000,
                            garray_db:award_card_oneexp(Src, RoleUid, Gid, AddCardExp, Sid),
                            zm_log:info(Src, ?MODULE, 'sweep', "duplicate_sweep",
                                [{'roleuid', RoleUid}, {'sid', Sid}, {'number', Number}, {'multi', Multi},
                                    {'award', AwardLog}, {'gid', Gid}, {'add_card_exp', AddCardExp}]),
                            %% 副本扫荡事件
                            zm_event:notify(Src, 'bi_duplicate_sweep', [{'role_uid', RoleUid}, {'sid', Sid}, {'number', Number},
                                {'award', AwardLog}, {'consume', CS}]),
                            zm_event:notify(Src, 'active_consume', {RoleUid, CS}),
                            %%记录成就任务
                            zm_event:notify(Src, achieve, {RoleUid, {argu, {'duplicate', Sid, Number}}}),
                            {AwardLog, Multi, AddCardExp};
                        Reply ->
                            Reply
                    end,
                    {ok, [], Info, [{msg, Reply1}]}
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.
%% ----------------------------------------------------
%% @doc
%%      获取名将副本信息
%% @end
%% ----------------------------------------------------
get_famous_duplicate_info(_, _Session, Attr, Info, _) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    ToDay = time_lib:get_date_by_type('day_of_year'),
    Fun1 = fun(_, FamousDuplicate) ->
        NFamousDuplicate = famous_duplicate:refresh(FamousDuplicate, 'day', ToDay),
        {ok, NFamousDuplicate, NFamousDuplicate}
    end,
    NFamousDuplicate = z_db_lib:update(game_lib:get_table(Src, 'famous_duplicate'), RoleUid, famous_duplicate:init(), Fun1, []),
    NpcIndexs = famous_duplicate:get_famous_duplicate_npc_indexs(NFamousDuplicate),
    ChangeCardTimes = famous_duplicate:get_change_card_times(NFamousDuplicate),
    Fun2 = fun(Acc, {Sid, Index}) ->
        case lists:keyfind(Sid, 1, ChangeCardTimes) of
            false ->
                {ok, [{Sid, Index, 0} | Acc]};
            {_, Times} ->
                {ok, [{Sid, Index, Times} | Acc]}
        end
    end,
    Acc = z_lib:foreach(Fun2, [], NpcIndexs),
    {ok, [], Info, [{msg, list_to_tuple(lists:reverse(Acc))}]}.

%% ----------------------------------------------------
%% @doc
%%      换将
%% @end
%% ----------------------------------------------------
famous_duplicate_change_card([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    Sid = z_lib:get_value(Msg, "sid", 0),
    if
        Sid =:= 0 ->
            {ok, [], Info, [{msg, "input_error"}]};
        true ->
            case zm_config:get('duplicate_reset', Sid) of
                none ->
                    {ok, [], Info, [{msg, "duplicate_no_change"}]};
                {_, Consumes} ->
                    Type = duplicate_lib:get_type_by_sid(Sid),
                    if
                        Type =:= ?DUPLICATE_TYPE_FAMOUS ->
                            DuplicateInfo = duplicate_db:get_duplicate_info(Src, RoleUid),
                            ToDay = time_lib:get_date_by_type('day_of_year'),
                            TableName = game_lib:get_table(Src),
                            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'famous_duplicate', RoleUid, famous_duplicate:init()}, {'rmb', RoleUid, rmb_lib:init()}]),
                            Reply1 = case z_db_lib:handle(TableName, {M, F, A}, {Sid, DuplicateInfo, Consumes, ToDay}, TableKeys) of
                                {Cs, NFamousDupInfo} ->
                                    DuplicateNpcIndex = famous_duplicate:get_famous_duplicate_npc_indexs(NFamousDupInfo),
                                    {_, Index} = lists:keyfind(Sid, 1, DuplicateNpcIndex),
                                    zm_log:info(Src, ?MODULE, 'famous_duplicate_change_card', "famous_duplicate_change_card",
                                        [{'roleuid', RoleUid}, {'sid', Sid}, {'consume', Cs}]),
                                    zm_event:notify(Src, 'bi_famous_duplicate_change_card', [{'role_uid', RoleUid}, {'sid', Sid}, {'consume', Cs}]),
                                    zm_event:notify(Src, 'active_consume', {RoleUid, Cs}),
                                    Index;
                                Err ->
                                    Err
                            end,
                            {ok, [], Info, [{msg, Reply1}]};
                        true ->
                            {ok, [], Info, [{msg, "duplicate_no_change"}]}
                    end
            end
    end.
%%%=====================LOCAL FUNCTIONS=================
fight_(Src, [{M, F, A}], Sid, Type, RoleUid, Gid, Garray) ->
    FighterRole = fighter:init_role(Src, RoleUid, Gid, 0, Garray),
    FamousDuplicate = z_db_lib:get(game_lib:get_table(Src, 'famous_duplicate'), RoleUid, famous_duplicate:init()),
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'role', RoleUid},
        {'fight_args', RoleUid, []},
        {'duplicate_info', RoleUid, []},
        {'role_restore', RoleUid},
        {'duplicate_pub_info', RoleUid, []}]),
    case z_db_lib:handle(TableName, {M, F, A}, {Src, Sid, RoleUid, FighterRole, Gid, FamousDuplicate, Type}, TableKeys) of
        {ok, FightFormat} ->
            FightFormat;
        {FightFormat, Consumes} ->
            %% 副本挑战事件
            zm_event:notify(Src, 'bi_duplicate_fight', [{'role_uid', RoleUid}, {'sid', Sid}, {'consume', Consumes}, {'type', Type}]),
            zm_event:notify(Src, 'active_consume', {RoleUid, Consumes}),
            FightFormat;
        Err ->
            Err
    end.