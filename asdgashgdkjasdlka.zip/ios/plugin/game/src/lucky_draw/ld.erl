-module(ld).

%%%=======================STATEMENT====================
-description("抽奖信息模块").
-copyright('youkia,www.youkia.net').
-author("zjx,zhaojunxian@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_day/1, get_free_count/1, get_total_count/1, get_total_ten_count/1, get_last_time/1, get_day_times/1, get_times_award_sids/1, get_award_sids/1, get_limit_times/1]).
-export([set_day/2, set_free_count/2, set_total_count/2, set_total_ten_count/2, set_last_time/2, set_day_times/2, set_times_award_sids/2, set_award_sids/2, set_limit_times/2]).
-export([refresh_count/1, clear_up/1, init/0]).

-export_type([ld/0]).
%%%=======================INCLUDE======================

%%%=======================RECORD=======================
-record(ld, {
    'day' :: integer(),%每日刷新标记
    'free_count' = 0 :: integer(),%每日使用的免费次数
    'total_count' = 0 :: integer(),%抽奖累计次数
    'last_time' = 0 :: integer(),%下次的次数回复时间
    'day_times' = 0 :: integer(),%今日抽奖次数
    'times_award_sids' = [] :: list(),%第几次抽到哪个物品(用于增加概率)
    'award_sids' = [] :: list(), %前N次已抽取奖池奖品sid
    'total_ten_count' = 0 :: integer(), %10连抽的次数
    limit_times = [] :: [{integer(), integer()}] %记录需要控制出现间隔的sid以及上一次出现的次数
}).
%%%=======================DEFINE=======================

%%%=======================TYPE=========================
-type ld() :: #ld{}.

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      获取重置记录日期
%% @end
%% ----------------------------------------------------
-spec get_day(ld()) -> integer().
get_day(#ld{'day' = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%      设置重置记录日期
%% @end
%% ----------------------------------------------------
-spec set_day(Ld :: ld(), Value :: integer()) -> ld().
set_day(Ld, Value) ->
    Ld#ld{'day' = Value}.

%% ----------------------------------------------------
%% @doc
%%       获取每日已使用的免费次数
%% @end
%% ----------------------------------------------------
-spec get_free_count(ld()) -> integer().
get_free_count(#ld{'free_count' = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%      设置每日已使用的免费次数
%% @end
%% ----------------------------------------------------
-spec set_free_count(Ld :: ld(), Value :: integer()) -> ld().
set_free_count(Ld, Value) ->
    Ld#ld{'free_count' = Value}.

%% ----------------------------------------------------
%% @doc
%%      获取此条目抽取的总次数
%% @end
%% ----------------------------------------------------
-spec get_total_count(ld()) -> integer().
get_total_count(#ld{'total_count' = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%      获取此条目10连抽抽取的总次数
%% @end
%% ----------------------------------------------------
-spec get_total_ten_count(ld()) -> integer().
get_total_ten_count(#ld{'total_ten_count' = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%      设置此条目抽取的总次数
%% @end
%% ----------------------------------------------------
-spec set_total_count(Ld :: ld(), Value :: integer()) -> ld().
set_total_count(Ld, Value) ->
    Ld#ld{'total_count' = Value}.

%% ----------------------------------------------------
%% @doc
%%      设置此条目10连抽抽取的总次数
%% @end
%% ----------------------------------------------------
-spec set_total_ten_count(Ld :: ld(), Value :: integer()) -> ld().
set_total_ten_count(Ld, Value) ->
    Ld#ld{'total_ten_count' = Value}.

%% ----------------------------------------------------
%% @doc
%%      获取最后一次免费抽取的时间
%% @end
%% ----------------------------------------------------
-spec get_last_time(ld()) -> integer().
get_last_time(#ld{'last_time' = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%      设置最后一次免费抽取的时间
%% @end
%% ----------------------------------------------------
-spec set_last_time(Ld :: ld(), Value :: integer()) -> ld().
set_last_time(Ld, Value) ->
    Ld#ld{'last_time' = Value}.

%% ----------------------------------------------------
%% @doc
%%      获取今日抽奖次数
%% @end
%% ----------------------------------------------------
-spec get_day_times(ld()) -> integer().
get_day_times(#ld{'day_times' = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%      设置今日抽奖次数
%% @end
%% ----------------------------------------------------
-spec set_day_times(Ld :: ld(), Value :: integer()) -> ld().
set_day_times(Ld, Value) ->
    Ld#ld{'day_times' = Value}.

%% ----------------------------------------------------
%% @doc
%%      第几次抽到哪个物品(用于增加概率)
%% @end
%% ----------------------------------------------------
-spec get_times_award_sids(ld()) -> list().
get_times_award_sids(#ld{'times_award_sids' = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%      设置当前使用的奖池下标
%% @end
%% ----------------------------------------------------
-spec set_times_award_sids(Ld :: ld(), Value :: list()) -> ld().
set_times_award_sids(Ld, Value) ->
    Ld#ld{'times_award_sids' = Value}.

%% ----------------------------------------------------
%% @doc
%%      获取在该奖池中,已抽取的奖励sid
%% @end
%% ----------------------------------------------------
-spec get_award_sids(ld()) -> list().
get_award_sids(#ld{'award_sids' = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%      设置在该奖池中,已抽取的奖励sid
%% @end
%% ----------------------------------------------------
-spec set_award_sids(Ld :: ld(), Value :: list()) -> ld().
set_award_sids(Ld, Value) ->
    Ld#ld{'award_sids' = Value}.

%% ----------------------------------------------------
%% @doc
%%      刷新每日使用的免费抽奖次数，每日刷新
%% @end
%% ----------------------------------------------------
-spec refresh_count(Ld :: ld()) -> ld().
refresh_count(Ld) ->
    NowDay = time_lib:get_date_by_type('day_of_year'),
    case get_day(Ld) of
        NowDay ->
            Ld;
        _ ->
            Ld#ld{'day' = NowDay, 'free_count' = 0, 'day_times' = 0}
    end.

%% ----------------------------------------------------
%% @doc
%%      清除抽奖信息
%% @end
%% ----------------------------------------------------
-spec clear_up(Ld :: ld()) -> ld().
clear_up(Ld) ->
    Ld#ld{'times_award_sids' = [], 'award_sids' = [], limit_times = []}.

%% ----------------------------------------------------
%% @doc
%%      初始化信息
%% @end
%% ----------------------------------------------------
-spec init() -> ld().
init() ->
    NowDay = time_lib:get_date_by_type('day_of_year'),
    #ld{'day' = NowDay}.

%% ----------------------------------------------------
%% @doc
%%      记录需要控制出现间隔的sid以及上一次出现的次数
%% @end
%% ----------------------------------------------------
get_limit_times(#ld{limit_times = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%      记录需要控制出现间隔的sid以及上一次出现的次数
%% @end
%% ----------------------------------------------------
set_limit_times(Ld, Value) ->
    Ld#ld{limit_times = Value}.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc 
%% 
%% @end 
%% ----------------------------------------------------
