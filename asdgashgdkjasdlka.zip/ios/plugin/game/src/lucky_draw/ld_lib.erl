%%抽奖工具
-module(ld_lib).
-description("ld_lib").
-copyright("seasky,www.seasky.cn").
-author("cb,chenbin@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_prize/9, front_format/3]).
-export([check/3, consume/3]).
%%%=======================INCLUDE======================

%%%=======================RECORD=======================

%%%=======================DEFINE=======================

%%%=================EXPORTED FUNCTIONS=================

%%-------------------------------------------------------------------
%% @doc
%%      条件检测
%% @end
%%-------------------------------------------------------------------
-spec check(tuple(), term(), term()) -> boolean().
%%玩家等级是否满足
check({Role, _Rmb, _CardStorage, _Ld, _LdInfo}, 'draw', {'role_level', Value}) ->
    game_lib:get_level('role', Role) >= Value;
check({Role, _Rmb, _CardStorage, _Ld, _LdInfo}, 'draw', {'vip_level', Value}) ->
    game_lib:get_level('vip', Role) >= Value;
%%校验rmb是否足够
check({_Role, Rmb, _CardStorage, _Ld, _LdInfo}, 'draw', {'rmb', Value}) ->
    rmb_lib:get_rmb(Rmb) >= Value;
%%检验消耗游戏币
check({Role, _Rmb, _CardStorage, _Ld, _LdInfo}, 'draw', {'money', Value}) ->
    role:get_money(Role) >= Value;
%%检验包裹空间
check({_Role, _Rmb, CardStorage, _Ld, _LdInfo}, 'draw', {'card_storage', Value}) ->
    Limit = element(2, zm_config:get('storage_size', 'card')),
    Limit - tuple_size(CardStorage) >= Value;
%%检验免费次数
check({Role, _Rmb, _CardStorage, Ld, LdInfo}, 'draw', {'free_times', Num}) ->
    NowTime = time_lib:now_second(),
    DayFreeMax = case lists:keyfind('free', 1, LdInfo) of
        {_, {M, F, A}} ->
            M:F(A, Role);
        {_, FreeMax1} ->
            FreeMax1
    end,
    {_, CdTime} = lists:keyfind('cd', 1, LdInfo),
    LastTime = ld:get_last_time(Ld),
    DayFree = ld:get_free_count(Ld),
    NowTime > LastTime + CdTime andalso DayFreeMax >= DayFree + Num;
%%检验坐骑包裹空间
check({_Role, _Rmb, CardStorage, _Ld, _LdInfo}, 'draw', {'mount_storage', Value}) ->
    Limit = element(2, zm_config:get('storage_size', 'mount')),
    Limit - tuple_size(CardStorage) >= Value;
check({_Role, _Rmb, _CardStorage, _Ld, _LdInfo}, 'draw', {'cross_battle_num', _}) ->
    true;
%%校验走银环是否足够
check({Role, _Rmb, _CardStorage, _Ld, _LdInfo}, 'draw', {'officer_silver', Value}) ->
    role:get_officer_silver(Role) >= Value;
check(_, _, _) ->
    false.

%%-------------------------------------------------------------------
%% @doc
%%      消耗
%% @end
%%-------------------------------------------------------------------
-spec consume(tuple(), term(), term()) -> {term(), term()}.
consume({Ld, Role, Rmb, CrossBattleExecute}, 'draw', {'free_times', Num}) ->
    NowTime = time_lib:now_second(),
    DayFree = ld:get_free_count(Ld),
    NLd = ld:set_free_count(ld:set_last_time(Ld, NowTime), DayFree + Num),
    {[{'free_count', Num, ld:get_free_count(NLd)}], {NLd, Role, Rmb, CrossBattleExecute}};
consume({Ld, Role, Rmb, CrossBattleExecute}, 'draw', {'money', Num}) ->
    {Cs, NRole} = role_lib:deduct_money(Role, Num),
    {Cs, {Ld, NRole, Rmb, CrossBattleExecute}};
consume({Ld, Role, Rmb, CrossBattleExecute}, 'draw', {'rmb', Num}) ->
    {Cs, NRmb} = rmb_lib:reduct_rmb(Rmb, Num),
    {Cs, {Ld, Role, NRmb, CrossBattleExecute}};
consume({Ld, Role, Rmb, {Session, AllNum}}, 'draw', {'cross_battle_num', Num}) ->
    {'none', {Ld, Role, Rmb, {Session, AllNum + Num}}};
consume({Ld, Role, Rmb, CrossBattleExecute}, 'draw', {'officer_silver', Num}) ->
    {Cs, NRole} = role_lib:deduct_officer_silver(Role, Num),
    {Cs, {Ld, NRole, Rmb, CrossBattleExecute}};
consume(Tables, _, _) ->
    {'none', Tables}.


%% ----------------------------------------------------
%% @doc
%%      抽取多次，并发放奖励
%% @end 
%% ----------------------------------------------------
-spec handle_prize(Src :: atom(),
        Id :: integer(),
        Role :: role:role(),
        Ld :: ld:ld(),
        Min :: integer(),
        Max :: integer(),
        List :: list(),
        TenBool :: boolean(),
        TenRand :: integer()) ->
    {ld:ld(), list()}.
handle_prize(Src, Id, Role, Ld, Min, Max, List, TenBool, TenRand) when Min =< Max ->
    {_, TimesPoolSids, DefaultPoolSid, NoRepeatTimes, WhileBegin, WhileEnd, QualityList, TenLibRary} = zm_config:get('ld_library', Id),
    PoolSid = case TenBool andalso lists:keyfind(ld:get_total_ten_count(Ld), 1, TenLibRary) =/= false of
        true ->
            {TPoolSid, TDPoolSid} = z_lib:get_value(TenLibRary, ld:get_total_ten_count(Ld), {DefaultPoolSid, DefaultPoolSid}),
            if
                Min =:= TenRand ->
                    if
                        is_tuple(TPoolSid) ->
                            element(role:get_country(Role), TPoolSid);
                        true ->
                            TPoolSid
                    end;
                true ->
                    TDPoolSid
            end;
        false ->
            T = if
                Min > WhileEnd ->
                    V = Min rem WhileEnd,
                    if
                        V =:= 0 ->
                            WhileEnd;
                        true ->
                            if
                                V < WhileBegin ->
                                    Min;
                                true ->
                                    V
                            end
                    end;
                true ->
                    Min
            end,
            z_lib:get_value(TimesPoolSids, T, DefaultPoolSid)
    end,
    NPoolSid = if
        is_tuple(PoolSid) ->
            element(role:get_country(Role), PoolSid);
        true ->
            PoolSid
    end,
    {_, Pool} = zm_config:get('ld_pool', NPoolSid),
    Pools = select_pools(game_lib:get_level('vip', Role), Pool),
    {Ld2, AddAwardItem, NLimiTimes} = random_prop(Min, Ld, Pools, QualityList, DefaultPoolSid, NPoolSid, WhileEnd, NoRepeatTimes),
    Ld3 =
        if
            Min >= NoRepeatTimes -> ld:set_award_sids(Ld2, []);
            true -> Ld2
        end,
    handle_prize(Src, Id, Role, ld:set_limit_times(Ld3, NLimiTimes), Min + 1, Max, [AddAwardItem | List], TenBool, TenRand);
handle_prize(_Src, _Id, _Role, Ld, _Min, _Max, List, _TenBool, _TenRand) ->
    {Ld, List}.

%% ----------------------------------------------------
%% @doc
%%      格式化抽奖信息，发送给前端
%% @end
%% ----------------------------------------------------
-spec front_format(Id :: integer(),
        Ld :: ld:ld(),
        LdInfo :: list()) -> tuple().
front_format(Id, Ld, LdInfo) ->
    {_, FreeMax} = lists:keyfind('free', 1, LdInfo),
    {_, CdTime} = lists:keyfind('cd', 1, LdInfo),
    Free = ld:get_free_count(Ld),
    NextTime = ld:get_last_time(Ld) + CdTime,
    {Id, ld:get_day_times(Ld), max(FreeMax - Free, 0), max(NextTime - time_lib:now_second(), 0), ld:get_total_count(Ld), ld:get_total_ten_count(Ld)}.

%%%===================LOCAL FUNCTIONS==================

%% ----------------------------------------------------
%% @doc
%%      进行池选择
%% @end
%% ----------------------------------------------------
select_pools(Vip, [{{Min, Max}, Pool} | _]) when Vip >= Min andalso Vip =< Max ->
    Pool;
select_pools(Vip, [{Level, Pool} | _]) when is_integer(Level) andalso Vip =< Level ->
    Pool;
select_pools(Vip, [_ | T]) ->
    select_pools(Vip, T);
select_pools(_Vip, []) ->
    'none'.

%% ----------------------------------------------------
%% @doc
%%      进行随机物品
%% @end
%% ----------------------------------------------------
random_prop(Times, Ld, Pools, QualityList, DefaultPoolSid, PoolSid, Cycle, NoRepeatTimes) ->
    TimesSids = ld:get_times_award_sids(Ld),
    AwardSids = ld:get_award_sids(Ld),
    Limits = ld:get_limit_times(Ld),
    {TW, NPools, Sids} = lists:foldl(fun({W, {'prop', {Sid, _}} = FA, AW}, {C, Ps, SidList}) ->
        {NC, NPs} =
            case lists:member(Sid, AwardSids) of
                true ->
                    {C, Ps};
                false ->
                    if
                        DefaultPoolSid =/= PoolSid andalso is_tuple(AW) andalso QualityList =/= [] ->
                            %%QualityList任意一品质抽中即清除次数,故直接用了第一个
                            AddNotChooseTimes = Times div Cycle - z_lib:get_value(TimesSids, hd(QualityList), 0) div Cycle-1,
                            NW = AddNotChooseTimes * element(2, AW) + W,
                            {C + NW, [{NW, {FA, AW}} | Ps]};
                        true ->
                            {C + W, [{W, {FA, 0}} | Ps]}
                    end
            end,
        NSidList =
            if
                is_tuple(AW) ->
                    [Sid | SidList];
                true ->
                    SidList
            end,
        {NC, NPs, NSidList}
    end, {0, [], []}, Pools),
    {{{'prop', {Sid, _}} = FA, AddW}, NLimits} = random_prop(Times, lists:reverse(NPools), TW, NoRepeatTimes, Sids, Limits),
    NLd = if
        DefaultPoolSid =/= PoolSid andalso is_tuple(AddW) ->
            Quality = element(1, AddW),
            NTimesSids = lists:keystore(Quality, 1, TimesSids, {Quality, Times}),
            case lists:member(Quality, QualityList) of
                true ->
                    ld:set_times_award_sids(ld:set_award_sids(Ld, [Sid | AwardSids]), NTimesSids);
                false ->
                    ld:set_times_award_sids(Ld, NTimesSids)
            end;
        true ->
            Ld
    end,
    {NLd, FA, NLimits}.


random_prop(Times, NPools, TW, NoRepeatTimes, Sids, LimitList) ->
    case random_prop(NPools, z_lib:random(1, TW)) of
        Prop = {{'prop', {Sid, _}}, _AddW} ->
            case lists:member(Sid, Sids) of
                true ->
                    case lists:keytake(Sid, 1, LimitList) of
                        {value, {_, Time}, TupleList2} ->
                            if
                                Times - Time > NoRepeatTimes ->
                                    {Prop, [{Sid, Times} | TupleList2]};
                                true ->
                                    random_prop(Times, NPools, TW, NoRepeatTimes, Sids, [{Sid, Time} | TupleList2])
                            end;
                        false ->
                            {Prop, [{Sid, Times} | LimitList]}
                    end;
                false ->
                    {Prop, LimitList}
            end;
        Other ->
            {Other, LimitList}
    end.

random_prop([{W, FA} | _], Value) when Value =< W ->
    FA;
random_prop([{W, _} | T], Value) ->
    random_prop(T, Value - W);
random_prop([], _Value) ->
    none.
