-module(ld_port).

%%%=======================STATEMENT====================
-description("ld_port").
-copyright("seasky,www.seasky.cn").
-author("liumin,liumin@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([execute/5, get_info/5, execute1/5]).
%%%=======================INCLUDE======================

%%%=======================RECORD=======================

%%%=======================DEFINE=======================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      执行抽奖 
%% @end 
%% ----------------------------------------------------
execute([{M, F, A}], _, Attr, Info, Msg) ->
    RoleUid = role_lib:get_uid(Attr),    % 抽取奖励玩家
    Src = z_lib:get_value(Info, src, none),
    Id = z_lib:get_value(Msg, "id", 0),    % 抽取奖励类型（金币，钻石。。。）
    ActiveSidTemplate1 = template_lib:get_templates(Src, 'active_ld'),
    ActiveSidTemplate2 = template_lib:get_templates(Src, 'active_sworn_brothers'),
    TId = case lists:keyfind(Id, 1, ActiveSidTemplate1 ++ ActiveSidTemplate2) of
        false ->
            Id;
        {_, TName} ->
            TName
    end,
    case zm_config:get('ld_info', TId) of
        none ->
            {ok, [], Info, [{msg, "input_error"}]};
        {_, LdInfo} ->
            Choose = z_lib:get_value(Msg, "choose", 1),    % 1抽还是多连抽
            case zm_config:get('ld_consume_info', {TId, Choose}) of
                'none' ->
                    {ok, [], Info, [{msg, "input_error"}]};
                {_, Conditions, Consumes, PoolSid, OtherAwardList} ->
                    Storage = case lists:keyfind('type', 1, LdInfo) of
                        {_, 1} ->
                            storage_db:get_storage('card', Src, RoleUid);
                        {_, 3} ->
                            storage_db:get_storage('mount', Src, RoleUid);
                        _ ->  %由于寻宝时，可能出宝物、图纸、材料，由于不知道具体数量且这三个分别在不同背包，所以无法检查背包空间。寻宝时不检查背包
                            {}
                    end,
                    Reply = execute_(Src, RoleUid, Id, TId, {M, F, A}, Choose, Conditions, Consumes, PoolSid, LdInfo, Storage, OtherAwardList),
                    {ok, [], Info, [{msg, Reply}]}
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      获取抽奖信息
%% @end 
%% ----------------------------------------------------
get_info(_, _, Attr, Info, _) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    Reply = [ld_lib:front_format(Id, ld:refresh_count(ld_db:get_ld_count(Src, {RoleUid, Id})), LdInfo) ||
        {Id, LdInfo} <- zm_config:get('ld_info'), is_integer(Id)],
    {ok, [], Info, [{msg, list_to_tuple(Reply)}]}.


%% ----------------------------------------------------
%% @doc
%%      执行抽奖（外部传入消耗）
%% @end
%% ----------------------------------------------------
execute1([{M, F, A}], _, Attr, Info, Msg) ->
    RoleUid = role_lib:get_uid(Attr),    % 抽取奖励玩家
    Src = z_lib:get_value(Info, src, none),
    Id = z_lib:get_value(Msg, "id", 0),    % 抽取奖励类型（金币，钻石。。。）
    Consumes = z_lib:get_value(Msg, "consume", 0),
    ActiveSidTemplate1 = template_lib:get_templates(Src, 'active_ld'),
    ActiveSidTemplate2 = template_lib:get_templates(Src, 'active_sworn_brothers'),
    TId = case lists:keyfind(Id, 1, ActiveSidTemplate1 ++ ActiveSidTemplate2) of
        false ->
            Id;
        {_, TName} ->
            TName
    end,
    case zm_config:get('ld_info', TId) of
        none ->
            {ok, [], Info, [{msg, "input_error"}]};
        {_, LdInfo} ->
            Choose = z_lib:get_value(Msg, "choose", 1),    % 1抽还是多连抽
            case zm_config:get('ld_consume_info', {TId, Choose}) of
                'none' ->
                    {ok, [], Info, [{msg, "input_error"}]};
                {_, Conditions, _, PoolSid, OtherAwardList} ->
                    Storage = case lists:keyfind('type', 1, LdInfo) of
                        {_, 1} ->
                            storage_db:get_storage('card', Src, RoleUid);
                        {_, 3} ->
                            storage_db:get_storage('mount', Src, RoleUid);
                        _ ->  %由于寻宝时，可能出宝物、图纸、材料，由于不知道具体数量且这三个分别在不同背包，所以无法检查背包空间。寻宝时不检查背包
                            {}
                    end,
                    Reply = execute_(Src, RoleUid, Id, TId, {M, F, A}, Choose, Conditions, Consumes, PoolSid, LdInfo, Storage, OtherAwardList),
                    {ok, [], Info, [{msg, Reply}]}
            end
    end.
%%%===================LOCAL FUNCTIONS==================
execute_(Src, RoleUid, Id, TId, {M, F, A}, Choose, Conditions, Consumes, PoolSid, LdInfo, Storage, OtherAwardList) ->
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'role', RoleUid},
        {'rmb', RoleUid, rmb_lib:init()}, {'ld_count', {RoleUid, Id}, ld:init()}, {'cross_battle_execute', RoleUid, {0, 0}}]),
    case z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, Id, Choose, Conditions, Consumes, PoolSid, LdInfo, Storage}, TableKeys) of
        {ok, Cs, AwardList, Times} ->
            AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, awarder_game:merger(AwardList, OtherAwardList)),
            %% 抽奖日志
            zm_log:info(Src, ?MODULE, 'execute', "ld_execute", [{'roleuid', RoleUid},
                {'lucky_draw', Id, Choose}, {'consume', Cs}, {'award', AwardLog}, {'times', Times}]),
            %% 兑换事件触发
            zm_event:notify(Src, 'lucky_draw', [{'role_uid', RoleUid}, {'lucky_draw', Id, Choose},
                {'consume', Cs}, {'award', AwardLog}, {'times', Times}]),
            zm_event:notify(Src, achieve, {RoleUid, {argu, {'lucky_draw', Id, Times}}}),
            zm_event:notify(Src, 'broadcast', {'lucky_draw', [{'role_uid', RoleUid}, {'award', AwardLog}, {'sid', TId}]}),
            Bool = ld_db:check_active_sid(Src, Id),
            if
                Bool ->
                    %%限时抽卡活动,收集
                    zm_event:notify(Src, 'active_event', {'active_ld_ok', [{'sid', Id}, {'role_uid', RoleUid}, {'choose', Choose}]});
                true ->
                    'ignore'
            end,
            %%活动 求贤若渴 抛事件
            zm_event:notify(Src, 'active_event', {'active_collect_target', {'card', [{'role_uid', RoleUid}, {'award_list', AwardList}]}}),
            AwardLog;
        Other ->
            Other
    end.