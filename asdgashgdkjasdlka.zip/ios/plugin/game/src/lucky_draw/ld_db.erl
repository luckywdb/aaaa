%%抽奖
-module(ld_db).

%%%=======================STATEMENT====================
-description("ld_db").
-copyright("seasky,www.seasky.cn").
-author("liumin,liumin@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_ld_count/2, set_ld_count/3, execute/3, get_day_max/3, get_config/2, check_active_sid/2]).
%%%=======================INCLUDE======================

%%%=======================RECORD=======================

%%%=======================DEFINE=======================
-define(LOG_NUM, 5).%最近抽奖信息日志记录条数.

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      获取抽奖次数信息，key={RoleUid,ActiveId}
%%      Tuple {每日刷新标记,每日使用的免费次数,抽奖累计次数,下次的次数回复时间,各种模式的首次抽取状态}
%% @end
%% ----------------------------------------------------
-spec get_ld_count(Src :: atom(), Key :: {integer(), integer()}) -> ld:ld().
get_ld_count(Src, Key) ->
    z_db_lib:get(game_lib:get_table(Src, 'ld_count'), Key, ld:init()).

%% ----------------------------------------------------
%% @doc
%%      保存抽奖次数信息
%% @end 
%% ----------------------------------------------------
-spec set_ld_count(Src :: atom(), Key :: {integer(), integer()}, LdInfo :: ld:ld()) -> ld:ld().
set_ld_count(Src, Key, LdInfo) ->
    z_db_lib:update(game_lib:get_table(Src, 'ld_count'), Key, LdInfo).

%% ----------------------------------------------------
%% @doc
%%      执行抽奖
%% @end 
%% ----------------------------------------------------
-spec execute(list(), tuple(), list()) ->
    string()|tuple().
execute(_A, {Src, _RoleUid, _Id, Choose, Conditions, Consumes, PoolSid, LdInfo, Storage},
        [{Index1, Role}, {Index2, Rmb}, {Index3, Ld1}, {Index4, CrossBattleExecute}]) ->
    Ld = ld:refresh_count(Ld1),
    Bool = game_lib:checks({ld_lib, check}, {Role, Rmb, Storage, Ld, LdInfo}, 'draw', Conditions ++ Consumes),
    if
        Bool ->
            {_, ChooseTimes} = lists:keyfind('times', 1, LdInfo),
            Times = element(Choose, ChooseTimes),
            Total = ld:get_total_count(Ld),
            %%得到今日可抽的最大次数
            Max = case lists:keyfind('day_max', 1, LdInfo) of
                {_, {M, F, A}} ->
                    M:F(Src, A, Role);
                {_, DayMax} ->
                    DayMax;
                _ ->
                    9999999%%今天最大次数
            end,
            DayTimes = ld:get_day_times(Ld),
            if
                DayTimes + Times =< Max ->
                    ok;
                true ->
                    throw("ld_day_max")
            end,
            TenTotal = ld:get_total_ten_count(Ld),
            {TenBool, TenRand, Ld2} = if
                Times =:= 10 ->
                    {true, rand:uniform(10), ld:set_total_ten_count(Ld, TenTotal + 1)};
                true ->
                    {false, 0, Ld}
            end,
            {Consume, {NLd1, NRole, NRmb, NCrossBattleExecute}} = game_lib:consumes({ld_lib, consume},
                {ld:set_total_count(Ld2, Total + Times), Role, Rmb, CrossBattleExecute}, 'draw', Consumes),
            {NLd, AwardList} = ld_lib:handle_prize(Src, PoolSid, Role, NLd1, Total + 1, Total + Times, [], TenBool, Total + TenRand),
            {ok, {ok, Consume, AwardList, Times}, [{Index1, NRole}, {Index2, NRmb}, {Index3, ld:set_day_times(NLd, DayTimes + Times)}, {Index4, NCrossBattleExecute}]};
        true ->
            throw(Bool)
    end.

%% ----------------------------------------------------
%% @doc
%%      得到每天最大可抽奖次数
%% @end 
%% ----------------------------------------------------
-spec get_day_max(Src :: atom(),
        Args :: list(),
        Role :: role:role()) ->
    integer().
get_day_max(_Src, Args, Role) ->
    {'init_times', Times} = lists:keyfind('init_times', 1, Args),
    {'additional', {L, N}} = lists:keyfind('additional', 1, Args),
    Level = game_lib:get_level('role', Role),
    Times + (Level div L * N).


%%-------------------------------------------------------------------
%% @doc
%%      获取ld配置
%% @end
%%-------------------------------------------------------------------
-spec get_config(atom(), integer()) -> tuple() | 'none'.
get_config(Src, Sid) ->
    template_lib:get_config(Src, 'active_ld', Sid, 'ld_info').

%%-------------------------------------------------------------------
%% @doc
%%      是否是限时抽卡sid
%% @end
%%-------------------------------------------------------------------
-spec check_active_sid(atom(), integer()) -> boolean().
check_active_sid(Src, Sid) ->
    template_lib:check_sid(Src, 'active_ld', Sid).


%%%===================LOCAL FUNCTIONS==================