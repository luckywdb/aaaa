%%发奖
-module(ld_prize).

%%%======================STATEMENT=====================
-description("ld_prize").
-copyright({seasky, 'www.seasky.cn'}).
-author({cb, 'chenbin@youkia.net'}).
-vsn(1).

%%%=======================EXPORT=======================
-export([prize/3, prize_money/3, prize_wood/3, prize_mineral/3, prize_iron/3, prize_forage/3, prize_prop/3]).
%%%=======================INCLUDE======================

%%%=======================RECORD=======================

%%%=======================DEFINE=======================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      发奖
%% @end
%% ----------------------------------------------------
-spec prize(Src :: atom(),
        RoleUid :: integer(),
        {F :: atom(), A :: term()}) -> tuple().
prize(Src, RoleUid, {F, A}) ->
    ld_prize:F(Src, RoleUid, A).

%% ----------------------------------------------------
%% @doc
%%      奖励游戏币
%% @end
%% ----------------------------------------------------
-spec prize_money(Src :: atom(),
        RoleUid :: integer(),
        Money :: integer()) -> tuple().
prize_money(Src, RoleUid, Money) ->
    role_db:award_money([Src], RoleUid, ?MODULE, Money).

%% ----------------------------------------------------
%% @doc
%%      奖励木材
%% @end
%% ----------------------------------------------------
-spec prize_wood(Src :: atom(),
        RoleUid :: integer(),
        Wood :: integer()) -> tuple().
prize_wood(Src, RoleUid, Wood) ->
    role_db:award_wood([Src], RoleUid, ?MODULE, Wood).

%% ----------------------------------------------------
%% @doc
%%      奖励矿石
%% @end
%% ----------------------------------------------------
-spec prize_mineral(Src :: atom(),
        RoleUid :: integer(),
        Mineral :: integer()) -> tuple().
prize_mineral(Src, RoleUid, Mineral) ->
    role_db:award_mineral([Src], RoleUid, ?MODULE, Mineral).

%% ----------------------------------------------------
%% @doc
%%      奖励铁
%% @end
%% ----------------------------------------------------
-spec prize_iron(Src :: atom(),
        RoleUid :: integer(),
        Iron :: integer()) -> tuple().
prize_iron(Src, RoleUid, Iron) ->
    role_db:award_iron([Src], RoleUid, ?MODULE, Iron).

%% ----------------------------------------------------
%% @doc
%%      奖励粮草
%% @end
%% ----------------------------------------------------
-spec prize_forage(Src :: atom(),
        RoleUid :: integer(),
        Forage :: integer()) -> tuple().
prize_forage(Src, RoleUid, Forage) ->
    role_db:award_forage([Src], RoleUid, ?MODULE, Forage).

%% ----------------------------------------------------
%% @doc
%%      奖励道具
%% @end
%% ----------------------------------------------------
-spec prize_prop(Src :: atom(),
        RoleUid :: integer(),
        Sid :: integer()) -> tuple();
        (Src :: atom(),
                RoleUid :: integer(),
                {Sid :: integer(), Num :: integer()}) -> tuple().
prize_prop(Src, RoleUid, Sid) when is_integer(Sid) ->
    prize_prop(Src, RoleUid, {Sid, 1});
prize_prop(Src, RoleUid, {Sid, Num}) ->
    role_db:award_prop([Src], RoleUid, ?MODULE, {Sid, Num}).

%%%===================LOCAL FUNCTIONS 模块内部调用==================

