-module(result).

%%%=======================STATEMENT====================
-description("地图战斗结果结构").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    init/1,
    get_dead/1,
    get_injured/1,
    get_queue/1,
    get_allexp/1,
    get_role_feats/1,
    get_enemy_feats_list/1,
    get_waves/1,
    get_enemy_last_hps/1,
    get_enemy_total_dead/1,
    get_enemy_total_injure/1,
    get_fight_last_hps/1
]).

-export_type([result/0]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(result, {
    role_result :: {integer(), integer(), integer(), [{integer(), integer(), integer(), integer(), integer(), integer(), integer(), integer(), integer(), integer()}]},%进攻方结果 {死亡数量,伤兵数量,死亡+伤兵折算成功勋值,[{Uid, Sid, Star, DeadNum1, InjureNum1, CurSoldier,WeaponSid,DeadWeaponNum,LeisureWeaponNum,OccWeaponNum}]}
    all_exp = 0 :: integer(),%获得的所有经验
    role_feats = 0 :: integer(),%进攻方获得的功勋
    enemy_feats_list = [] :: [integer()],%被攻击方获得的功勋
    waves :: [{{integer(), integer(), [{integer(), integer(), integer(), integer(), integer(), integer(), integer(), integer(), integer(), integer()}]},
        {integer(), integer(), [{integer(), integer(), integer(), integer(), integer(), integer(), integer(), integer(), integer(), integer()}]}}], %每一波,进攻方和被攻击方,死亡伤兵和阵型详情. {死亡数量,伤兵数量,[{carduid,当前兵}]}
    enemy_last_hps :: {integer(), [{integer(), integer(), integer()}]}, %防守方最后一波当前血量
    enemy_total_dead = 0 :: integer(),%被攻击方死亡数量
    enemy_total_injure = 0 :: integer(), %被攻击方受伤数量
    fight_last_hps :: {integer(), [{integer(), integer(), integer()}]}  %进攻方最后一波当前血量
}).

%%%=======================TYPE=========================
-type result() :: #result{}.


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%     web战斗结果
%% @end
%% ----------------------------------------------------
%%-spec my_function(Args1::integer()) -> integer().
init({RResult, AExp, RFeats, EFeatsList, Waves, {WaveLen, LastEnemyHp}, EnemyTotalDead, EnemyTotalInjure, {RWaveLen, RNewLastEnemyHp}}) ->
    NewLastEnemyHp = [{Uid, Hp, MaxHp} || {_, [Uid, Hp, MaxHp]} <- LastEnemyHp],
    #result{role_result = RResult, all_exp = AExp, role_feats = RFeats,
        enemy_feats_list = EFeatsList, waves = Waves, enemy_last_hps = {WaveLen, NewLastEnemyHp},
        enemy_total_dead = EnemyTotalDead, enemy_total_injure = EnemyTotalInjure,
        fight_last_hps = {RWaveLen, RNewLastEnemyHp}}.

%% ----------------------------------------------------
%% @doc
%%     获取进攻方死亡数量
%% @end
%% ----------------------------------------------------
-spec get_dead(result()) -> integer().
get_dead(#result{role_result = RRsult}) ->
    element(1, RRsult).

%% ----------------------------------------------------
%% @doc
%%     获取进攻方伤兵数量
%% @end
%% ----------------------------------------------------
-spec get_injured(result()) -> integer().
get_injured(#result{role_result = RRsult}) ->
    element(2, RRsult).

%% ----------------------------------------------------
%% @doc
%%     获取进攻方,阵型各武将兵伤亡信息
%% @end
%% ----------------------------------------------------
get_queue(#result{role_result = RRsult}) ->
    element(4, RRsult).

%% ----------------------------------------------------
%% @doc
%%     获取进攻方获取的所有经验
%% @end
%% ----------------------------------------------------
-spec get_allexp(result()) -> integer().
get_allexp(#result{all_exp = AExp}) -> AExp.

%% ----------------------------------------------------
%% @doc
%%     获取进攻方获得功勋值
%% @end
%% ----------------------------------------------------
-spec get_role_feats(result()) -> integer().
get_role_feats(#result{role_feats = RFeats}) -> RFeats.

%% ----------------------------------------------------
%% @doc
%%     获取防守方获得功勋列表
%% @end
%% ----------------------------------------------------
-spec get_enemy_feats_list(result()) -> [integer()].
get_enemy_feats_list(#result{enemy_feats_list = EFeatsList}) -> EFeatsList.

%% ----------------------------------------------------
%% @doc
%%     获取每一波,进攻方和被攻击方,死亡伤兵和阵型详情. {死亡数量,伤兵数量,[{carduid,当前兵}]}
%% @end
%% ----------------------------------------------------
-spec get_waves(result()) -> [{{integer(), integer(), [{integer(), integer()}]}, {integer(), integer(), [{integer(), integer()}]}}].
get_waves(#result{waves = Waves}) -> Waves.

%% ----------------------------------------------------
%% @doc
%%     获取防守方,当前是第几波,剩余血量
%% @end
%% ----------------------------------------------------
-spec get_enemy_last_hps(result()) -> {integer(), [{integer(), integer(), integer()}]}.
get_enemy_last_hps(#result{enemy_last_hps = LastHps}) -> LastHps.

%%-------------------------------------------------------------------
%% @doc
%%      被攻击方死亡数量
%% @end
%%-------------------------------------------------------------------
-spec get_enemy_total_dead(result()) -> integer().
get_enemy_total_dead(#result{enemy_total_dead = V}) -> V.

%%-------------------------------------------------------------------
%% @doc
%%      被攻击方受伤数量
%% @end
%%-------------------------------------------------------------------
-spec get_enemy_total_injure(result()) -> integer().
get_enemy_total_injure(#result{enemy_total_injure = V}) -> V.


%% ----------------------------------------------------
%% @doc
%%     进攻方,当前是第几波,剩余血量
%% @end
%% ----------------------------------------------------
get_fight_last_hps(#result{fight_last_hps = LastHps}) -> LastHps.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
