-module(station_fight).

%%%=======================STATEMENT====================
-description("station_fight").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    fighting/8
]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      玩家战斗
%% @end
%% ----------------------------------------------------
fighting(Src, Now, EndPoint, {_, EndRoleUid} = EndPState, ArrMarch, EndGId, Occ, Station) ->%需要战斗
    EndRShow = role_db:get_role_show(Src, EndRoleUid),
    FightType = match_lib:get_fight_type(?MODULE),
    FightArgs = [
        {'ma', {'fighting', []}},
        {'auto', 1},%是否自动释放技能自动战斗 1:自动,0:手动
        {'fight_type', FightType},
        {'point_int', EndPoint}],
    EndCorpsUid = role_show:get_corps_uid(EndRShow),
    CastleLv = role_show:get_castle_lv(EndRShow),
    MaxBValue = station_lib:get_max_bvalue(CastleLv),
    do_fighting(Src, EndCorpsUid, Now, EndPoint, FightArgs, EndPState, ArrMarch, [], EndGId, Occ, Station, MaxBValue).

%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
do_fighting(_, _, _, _, _, _, [], UpGoBack, _EndGId, Occ, Station, _MaxBValue) ->
    {false, Station, UpGoBack, Occ};
do_fighting(Src, EndCorpsUid, Now, EndPoint, FightArgs,
        {_, EndRoleUid} = EndPState, [Marching | T], UpGoBack, EndGId, Occ, Station, MaxBValue) ->
    MState = marching:get_state(Marching),
    {MarchRoleUid, MarchGId} = MarchRGId = marching:get_roleuid_gid(Marching),
    MEtime = marching:get_etime(Marching),
    case MState =:= ?ON_THE_MB_CC orelse marching:get_state(Marching) =/= ?ON_THE_PATROL of
        true ->
            case marching:get_roleuid(Marching) =/= EndCorpsUid of
                true ->
                    ArrMarchToGoback = lists:filter(fun(M) ->
                        marching:get_state(M) =/= ?ON_THE_MB_CC andalso marching:get_state(Marching) =/= ?ON_THE_PATROL end, T),
                    OccToGoback = marching:change_goback(Occ, EndPoint),
                    NUpGoBack = fighting:mrole_endpoint_change(Src, EndPoint, ArrMarchToGoback) ++ OccToGoback ++ UpGoBack,
                    MExtra = marching:get_extra(Marching),
                    zm_event:notify(Src, 'station_map_build_fly', [
                        {'time', MEtime},
                        {'role_uid', EndRoleUid},
                        {'country', marching:get_extra_mb_cc_country(MExtra)},
                        {'corps_name', marching:get_extra_mb_cc_corpsname(MExtra)} | FightArgs]),
                    {true, Station, NUpGoBack, []};
                false ->
                    do_fighting(Src, EndCorpsUid, Now, EndPoint, FightArgs,
                        EndPState, T, UpGoBack, EndGId, Occ, Station, MaxBValue)
            end;
        false ->
            case MState =:= ?ON_THE_CASTLE_MARCHING of
                true ->
                    MarchCorpUid = role_show:get_corps_uid(role_db:get_role_show(Src, MarchRoleUid)),
                    if
                        MarchRoleUid =:= EndRoleUid orelse (MarchCorpUid > 0 andalso MarchCorpUid =:= EndCorpsUid) ->
                            Max = element(2, zm_config:get('station_info', 'garrison_friend_max_num')),
                            TupOcc = list_to_tuple(Occ),
                            Size = tuple_size(TupOcc),
                            Index = case Size > 0 of
                                true ->
                                    case marching:get_roleuid_gid(element(Size, TupOcc)) =:= {EndRoleUid, EndGId} of
                                        true ->
                                            Size;
                                        false ->
                                            Size + 1
                                    end;
                                false ->
                                    Size + 1
                            end,
                            case Index - 1 < Max of
                                true ->
                                    OMarching = marching:change_occ(Marching, MEtime, ?ON_THE_CASTLE_OTHER),
                                    NOcc = tuple_to_list(erlang:insert_element(Index, TupOcc, OMarching)),
                                    do_fighting(Src, EndCorpsUid, Now, EndPoint, FightArgs,
                                        EndPState, T, UpGoBack, EndGId, NOcc, Station, MaxBValue);
                                false ->
                                    zm_event:notify(Src, 'fight_null_report', [
                                        {'role_uid', MarchRoleUid},
                                        {'point_int', EndPoint},
                                        {'time', MEtime},
                                        {'r_type', ?REPORT_NULL_GARRISON_FULL},
                                        {'id', EndRoleUid}]),
                                    do_fighting(Src, EndCorpsUid, Now, EndPoint, FightArgs,
                                        EndPState, T, UpGoBack, EndGId, Occ, Station, MaxBValue)
                            end;
                        true ->
                            zm_event:notify(Src, 'fight_null_report', [
                                {'role_uid', MarchRoleUid},
                                {'point_int', EndPoint},
                                {'time', MEtime},
                                {'r_type', ?REPORT_NULL_GARRISON_DIFF_CORPS},
                                {'id', EndRoleUid}]),
                            do_fighting(Src, EndCorpsUid, Now, EndPoint, FightArgs,
                                EndPState, T, UpGoBack, EndGId, Occ, Station, MaxBValue)
                    end;
                false ->
                    MarchCorpUid = role_show:get_corps_uid(role_db:get_role_show(Src, MarchRoleUid)),
                    if
                        MarchCorpUid > 0 andalso MarchCorpUid =:= EndCorpsUid ->%都没有军团是可以攻打的
                            zm_event:notify(Src, 'fight_null_report', [
                                {'role_uid', MarchRoleUid},
                                {'point_int', EndPoint},
                                {'time', MEtime},
                                {'r_type', ?REPORT_NULL_SAME_CORPS},
                                {'id', EndRoleUid}]),
                            do_fighting(Src, EndCorpsUid, Now, EndPoint, FightArgs, EndPState,
                                T, UpGoBack, EndGId, Occ, Station, MaxBValue);
                        true ->
                            Fun = fun() ->
                                FightRole = fighter:init_role(Src, MarchRoleUid, MarchGId, 0, garray_db:get_garray(Src, MarchRoleUid, MarchGId)),
                                Attack = get_station_bvalue_attack(FightRole),
                                {IsStationOver, DealDeductBValue, NStation} = station_lib:deduct_bvalue(Station, Attack, MaxBValue),
                                GobackMarchng = marching:change_goback(Marching, EndPoint),
                                zm_event:notify(Src, 'fight_role_station_bvalue_report', [
                                    {'time', MEtime},
                                    {'role_uid', MarchRoleUid},
                                    {'ruid', EndRoleUid},
                                    {'is_staion_over', IsStationOver},
                                    {'del_bvalue', DealDeductBValue},
                                    {'max_bvalue', MaxBValue - station:get_del_bvalue(NStation) + DealDeductBValue},
                                    {'fight_role', FightRole} | FightArgs]),
                                if
                                    IsStationOver ->%%被打爆
                                        AddGoBackMarching = marching:change_goback(Occ, EndPoint, MEtime),
                                        {true, NStation, [GobackMarchng | AddGoBackMarching] ++ UpGoBack, []};
                                    true ->
                                        do_fighting(Src, EndCorpsUid, Now, EndPoint, FightArgs, EndPState,
                                            T, [GobackMarchng | UpGoBack], EndGId, Occ, NStation, MaxBValue)
                                end
                            end,
                            case Occ of
                                [] ->
                                    Fun();
                                [OMarching | TailOcc] ->
                                    {ORoleUid, OGId} = marching:get_roleuid_gid(OMarching),
                                    OGarray = garray_db:get_garray(Src, ORoleUid, OGId),
                                    case ORoleUid =:= EndRoleUid andalso OGId =:= EndGId andalso garray_lib:is_no_soldiers(OGarray) of
                                        true ->
                                            Fun();
                                        false ->
                                            MarchGarray = garray_db:get_garray(Src, MarchRoleUid, MarchGId),
                                            FighterRole = fighter:init_role(Src, MarchRoleUid, MarchGId, 0, MarchGarray),
                                            FightEnemy = fighter:init_role(Src, ORoleUid, OGId, 1, OGarray),
                                            NFightArgs = [
                                                {'orgid', {ORoleUid, OGId}},
                                                {'duplicate_sid', fighting:get_fight_scene('station')},
                                                {'seed', game_lib:get_seed()},
                                                {'fight_role', FighterRole},
                                                {'fight_enemy', [FightEnemy]}%由于npc时候会有多场,故给web发送的是一个list,打玩家时候也需要发送list
                                                | FightArgs],
                                            case match:auto_result(Src, MarchRoleUid, NFightArgs) of
                                                {Winner, Result} ->%攻打玩家不会获得武将经验
                                                    {NMarching, NOMarching, Bool, NStation} =
                                                        try
                                                            Dead = result:get_dead(Result),
                                                            Injured = result:get_injured(Result),
                                                            RoleChange = result:get_queue(Result),
                                                            RoleAddFeats = result:get_role_feats(Result),
                                                            EnemyAddFeatsList = result:get_enemy_feats_list(Result),
                                                            WaveInfos = result:get_waves(Result),
                                                            {SoldierBearload, MarchQueue, GarrayInjured, _, _DeductSosldierNum} =
                                                                fighting:update_garray_after_fight(Src, RoleChange, MarchRGId),
                                                            MarchingExtra = marching:set_extra_soldier_bearload(marching:get_extra(Marching), SoldierBearload),
                                                            set_front_lib:send_map_result(Src, MarchRoleUid, {MEtime, EndPoint, ?ROLE, ?STATION, Winner, MarchGId, {MarchQueue, Dead, Injured, GarrayInjured}, 0}),
                                                            NRoleAddFeats = role_db:award_feats(Src, MarchRoleUid, RoleAddFeats),

                                                            {OFeats, OMarching1, NStation1} = update_occ_garray(Src, Winner, OMarching, EndPoint, EndRoleUid, EndGId,
                                                                WaveInfos, EnemyAddFeatsList, MEtime, Station),
                                                            AttackAward = if
                                                                NRoleAddFeats > 0 ->
                                                                    [{'feats', NRoleAddFeats}];
                                                                true ->
                                                                    []
                                                            end,
                                                            FeatsList = [{MarchRoleUid, NRoleAddFeats}, {ORoleUid, OFeats}],
                                                            DealDeductBValue =
                                                                case check_fight_last_occ(Src, EndRoleUid, EndGId, Winner, TailOcc) of
                                                                    true ->
                                                                        FightRole = fighter:init_role(Src, MarchRoleUid, MarchGId, 0, garray_db:get_garray(Src, MarchRoleUid, MarchGId)),
                                                                        Attack = get_station_bvalue_attack(FightRole),
                                                                        {_, DealDeductBValue1, _} = station_lib:deduct_bvalue(Station, Attack, MaxBValue),
                                                                        DealDeductBValue1;
                                                                    false ->
                                                                        0
                                                                end,
                                                            zm_event:notify(Src, 'fight_role_station_report', [
                                                                {'time', MEtime},
                                                                {'role_uid', MarchRoleUid},
                                                                {'ruid', EndRoleUid},
                                                                {'garrison_role_uid', ORoleUid},
                                                                {'winner', Winner},
                                                                {'award_list', []},
                                                                {'del_bvalue', DealDeductBValue},
                                                                {'max_bvalue', MaxBValue - station:get_del_bvalue(Station)},
                                                                {'wave_infos', WaveInfos},
                                                                {'feats', FeatsList} | NFightArgs]),
                                                            zm_event:notify(Src, 'bi_fight_attack_station', [{'role_uid', MarchRoleUid}, {'be_role_uid', EndRoleUid}, {'type', ?STATION}, {'dead', Dead},
                                                                {'injured', Injured}, {'be_dead', result:get_enemy_total_dead(Result)}, {'be_injured', result:get_enemy_total_injure(Result)},
                                                                {'award_list', []}, {'win', Winner}]),
                                                            Marching1 = marching:set_extra(marching:fight_result(Marching, Injured, Dead, AttackAward), MarchingExtra),
                                                            {Marching1, OMarching1, true, NStation1}
                                                        catch
                                                            E1: E2 ->
                                                                zm_log:warn(?MODULE, ?MODULE, 'fighting', "handle_error", [{'e1', E1}, {'e2', E2}, {'point_uid', EndPoint},
                                                                    {'marching', Marching}, {'stacktrace', erlang:get_stacktrace()}]),
                                                                {Marching, OMarching, false, Station}
                                                        end,
                                                    case Bool andalso Winner =:= 1 of  %失败抛事件,胜利在 方法 do_fight_end_role中抛
                                                        true ->
                                                            task_event:notify(Src, MarchRoleUid, [{'fight_times', ?STATION, EndRoleUid}]),
                                                            zm_event:notify(Src, achieve, {MarchRoleUid, {argu, [{fight_times, ?STATION, EndRoleUid, 0}]}});
                                                        false ->
                                                            ok
                                                    end,
                                                    if
                                                        Bool andalso Winner =:= 0 ->
                                                            case ORoleUid =:= EndRoleUid andalso OGId =:= EndGId of
                                                                true ->
                                                                    do_fighting(Src, EndCorpsUid, Now, EndPoint, FightArgs, EndPState,
                                                                        [NMarching | T], UpGoBack, EndGId, TailOcc ++ [NOMarching], NStation, MaxBValue);
                                                                false ->
                                                                    AddGoback = marching:change_goback(NOMarching, EndPoint, MEtime, ?ON_THE_CASTLE_GOBACK),
                                                                    do_fighting(Src, EndCorpsUid, Now, EndPoint, FightArgs, EndPState,
                                                                        [NMarching | T], [AddGoback | UpGoBack], EndGId, TailOcc, NStation, MaxBValue)
                                                            end;
                                                        Bool andalso Winner =:= 1 ->
                                                            AddGoBack = marching:change_goback(NMarching, EndPoint),
                                                            case ORoleUid =:= EndRoleUid andalso OGId =:= EndGId of
                                                                true ->
                                                                    do_fighting(Src, EndCorpsUid, Now, EndPoint, FightArgs, EndPState,
                                                                        T, [AddGoBack | UpGoBack], EndGId, TailOcc ++ [NOMarching], NStation, MaxBValue);
                                                                false ->
%%                                                            case garray_lib:is_no_soldiers(garray_db:get_garray(Src, ORoleUid, OGId)) of
%%                                                                true ->
%%                                                                    AddGoBackList = [AddGoBack, marching:change_goback(NOMarching, EndPoint, MEtime, ?ON_THE_CASTLE_GOBACK)],
%%                                                                    do_fighting(Src, EndCorpsUid, Now, EndPoint, FightArgs, EndPState,
%%                                                                        T, AddGoBackList ++ UpGoBack, EndGId, TailOcc, NStation,MaxBValue);
%%                                                                false ->
                                                                    do_fighting(Src, EndCorpsUid, Now, EndPoint, FightArgs, EndPState,
                                                                        T, [AddGoBack | UpGoBack], EndGId, Occ, NStation, MaxBValue)
%%                                                            end
                                                            end;

                                                        true ->
                                                            do_fighting(Src, EndCorpsUid, Now, EndPoint, FightArgs, EndPState,
                                                                T, UpGoBack, EndGId, Occ, NStation, MaxBValue)
                                                    end;
                                                WebErr ->
                                                    zm_log:warn(?MODULE, ?MODULE, 'fighting', "web_error", [{'error', WebErr}, {'point_uid', EndPoint}, {'marching', Marching}]),
                                                    do_fighting(Src, EndCorpsUid, Now, EndPoint, FightArgs, EndPState,
                                                        T, UpGoBack, EndGId, Occ, Station, MaxBValue)
                                            end
                                    end
                            end
                    end
            end
    end.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%      驻防友军战斗后阵型等数据修改
%% @end
%% ----------------------------------------------------
update_occ_garray(Src, Winner, OMarching, EndPoint, EndRoleUid, EndGId, [{_, {DeadNum, Injured, GarrayList}} | _] = WaveInfos, EnemyAddFeatsList, FightTime, Station) ->
    {ORoleUid, OGId} = marching:get_roleuid_gid(OMarching),
    case ORoleUid =:= EndRoleUid andalso EndGId =:= OGId of
        true ->
            update_owner_garray(Src, Winner, OMarching, EndPoint, EndRoleUid, EndGId, WaveInfos, EnemyAddFeatsList, FightTime, Station);
        false ->
            %%死亡数和受伤数累计
            [Feats] = EnemyAddFeatsList,
            OAddFeats = role_db:award_feats(Src, ORoleUid, Feats),
            {_, FQueue, GarrayInjured, _AutoAddSoldier, _DeductSoldierNum} =
                fighting:update_garray_after_fight(Src, GarrayList, {ORoleUid, OGId}),%修改队伍信息
            set_front_lib:send_map_result(Src, ORoleUid, {FightTime, EndPoint, ?ROLE, ?STATION, Winner, OGId, {FQueue, DeadNum, Injured, GarrayInjured}, 2}),
            case ORoleUid =/= EndRoleUid of
                true ->
                    set_front_lib:send_map_result(Src, EndRoleUid, {FightTime, EndPoint, ?ROLE, ?STATION, Winner, 0, ORoleUid, 1});
                false ->
                    ok
            end,
            NOMarching = marching:fight_result(OMarching, Injured, DeadNum, [{'feats', OAddFeats}]),
            {OAddFeats, NOMarching, Station}
    end.


%% ----------------------------------------------------
%% @doc
%%      自己驻防或者只有城墙战斗后阵型等数据修改
%% @end
%% ----------------------------------------------------
update_owner_garray(Src, Winner, OMarching, EndPoint, EndRoleUid, GId, [{_, {DeadNum, Injured, GarrayList}} | _], EnemyAddFeatsList, FightTime, Station) ->
    [Feats] = EnemyAddFeatsList,
    OAddFeats = role_db:award_feats(Src, EndRoleUid, Feats),
    %%自己队伍
    {_, FQueue, GarrayInjured, _AutoAddSoldier, _DeductSosldierNum} =
        fighting:update_garray_after_fight(Src, GarrayList, {EndRoleUid, GId}, false),%修改队伍信息
    set_front_lib:send_map_result(Src, EndRoleUid, {FightTime, EndPoint, ?ROLE, ?STATION, Winner, GId, {FQueue, DeadNum, Injured, GarrayInjured}, 1}), %10s内的战斗才推送给玩家战斗结果
    FInjureMax = building_db:get_injure_max(Src, EndRoleUid),
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'barracks', EndRoleUid, barracks:init()},
        {'garray', {EndRoleUid, GId}, garray:init()}
    ]),
    Fun = fun(_, [{Index1, Barracks}, {Index2, Garry}]) ->
        {FInjure2Dead, NBarracks} = barracks:fight_over(Barracks, GId, DeadNum, Injured, FInjureMax),
        NGarray = garray:set_injured_init(Garry),
        {'ok', {barracks:get_leisure(GId, NBarracks), FInjure2Dead}, [{Index1, NBarracks}, {Index2, NGarray}]}
    end,
    {_Leisure, Injure2Dead} = z_db_lib:handle(TableName, Fun, [], TableKeys),%修改兵营信息,以及阵型伤病数据
    fighting:injure2dead_mail(Src, EndRoleUid, Injure2Dead),
    NStation =
        if
            Injured =/= 0 orelse DeadNum =/= 0 ->
                Study = building_db:get_study(Src, EndRoleUid),
                OfficailAttr = official_db:get_attrs(Src, EndRoleUid),
                CardStorage = storage_db:get_storage('card', Src, EndRoleUid),
                Political = building_db:get_political(Src, EndRoleUid),
                garray_db:auto_add_soldiers(Src, EndRoleUid, GId, Study, CardStorage, Political, OfficailAttr, false, true, true, true),
                Station;
            true ->
                Station
        end,
    Bool = garray_lib:is_no_soldiers(garray_db:get_garray(Src, EndRoleUid, GId)),
    if
        Bool ->
            case garrison_db:down_garray(Src, EndRoleUid, GId) of
                'ok' ->
                    set_front_lib:send_garrison_down_garray(Src, EndRoleUid, GId),
                    ok;
                Other ->
                    Other
            end;
        true ->
            ok
    end,
    NOMarching = marching:fight_result(OMarching, 0, 0, [{'feats', OAddFeats}]),
    {role_db:award_feats(Src, EndRoleUid, lists:sum(EnemyAddFeatsList)), NOMarching, NStation}.


%% ----------------------------------------------------
%% @doc
%%     攻击驻扎点建筑值造成伤害
%% @end
%% ----------------------------------------------------
get_station_bvalue_attack(FightRole) ->
    Attack = z_lib:foreach(fun(A, Fighter) ->
        {'ok', A + fighter:get_attack(Fighter)} end, 0, fighter:get_fighters(FightRole)),
    {OAttack, Speed} = case fighter:get_ordnance(FightRole) of
        {} -> {0, 10000};
        Ordnance ->
            {_, _, _, S} = zm_config:get('study_attrs', {fighter:get_o_sid(Ordnance), fighter:get_o_level(Ordnance)}),
            {fighter:get_o_attack(Ordnance), S}
    end,
    %speed是扩大了10000倍
    (Attack + (OAttack * 10000 div Speed)) div 10000.

%% ----------------------------------------------------
%% @doc
%%    检测是否是occ里最后一个有效的
%% @end
%% ----------------------------------------------------
check_fight_last_occ(Src, EndRoleUid, EndGId, Winner, TailOcc) ->
    case Winner =:= 0 of
        true ->
            case TailOcc =:= [] of
                true ->
                    true;
                false ->
                    case TailOcc of
                        [Marching] ->
                            {MRUid, MGId} = marching:get_roleuid_gid(Marching),
                            case MRUid =:= EndRoleUid andalso MGId =:= EndGId of
                                true ->
                                    OGarray = garray_db:get_garray(Src, MRUid, MGId),
                                    garray_lib:is_no_soldiers(OGarray);
                                false ->
                                    false
                            end;
                        _ ->
                            false
                    end
            end;
        false ->
            false
    end.