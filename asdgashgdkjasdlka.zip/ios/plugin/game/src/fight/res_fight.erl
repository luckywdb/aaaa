-module(res_fight).

%%%=======================STATEMENT====================
-description("资源点战斗").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    fighting/5
]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").
-include("../include/report.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        
%% @end
%% ----------------------------------------------------
-spec fighting(Src, Now, EndPoint, {?RES, RSid}, {ArrMarch, Occ, ORoleUid}) -> {[marching:marching()], list()} when
    Src :: atom(),
    Now :: integer(),
    EndPoint :: integer(),
    RSid :: integer(),
    ArrMarch :: [marching:marching()],
    Occ :: [marching:marching()],
    ORoleUid :: integer().
fighting(Src, Now, EndPoint, {?RES, ResSid}, {ArrMarch, Occ, ORoleUid}) ->
    {NOcc, AddBackMarchings, NORoleUid} = do_fighting(Src, Now, EndPoint, ResSid, ArrMarch, Occ, [], ORoleUid),
    {NOcc, AddBackMarchings, NORoleUid}.

%%%===================LOCAL FUNCTIONS==================
do_fighting(_Src, _Now, _EndPoint, _ResSid, [], Occ, BackMarchs, ORoleUid) ->
    {Occ, BackMarchs, ORoleUid};
do_fighting(Src, Now, EndPoint, ResSid, [Marching | Marchings], Occ, BackMarchs, ORoleUid) ->
    MarchingState = marching:get_state(Marching),
    {MarchRoleUid, MarchGId} = marching:get_roleuid_gid(Marching),
    ETime = marching:get_etime(Marching),
    if
        MarchRoleUid =:= ORoleUid andalso MarchingState =:= ?ON_THE_GARRISON_RES ->%资源点有玩家驻守中
            if
                ETime =/= 0 andalso ETime =< Now ->
                    BMarching1 = marching:init(MarchRoleUid, MarchGId, marching:get_s_point(Marching), EndPoint,
                        marching:get_speed(Marching), marching:get_sptype(Marching), marching:get_epstate(Marching)),
                    BMarching2 = marching:set_stime(marching:set_etime(BMarching1, ETime + marching:get_etime(BMarching1) - marching:get_stime(BMarching1)), ETime),
                    NAddGoBack = marching:set_state(BMarching2, ?ON_THE_GOBACK),
                    do_fighting(Src, Now, EndPoint, ResSid, Marchings, [], [NAddGoBack | BackMarchs], ORoleUid);
                true ->
                    do_fighting(Src, Now, EndPoint, ResSid, Marchings, Occ, BackMarchs, ORoleUid)
            end;
        MarchRoleUid =:= ORoleUid ->
            case MarchingState =:= ?ON_THE_MARCHING_GARRISON_RES andalso Occ =:= [] of
                true ->%%驻守
                    OccMarching = marching:set_etime(marching:set_state(Marching, ?ON_THE_GARRISON_RES), 0),
                    do_fighting(Src, Now, EndPoint, ResSid, Marchings, [OccMarching], BackMarchs, ORoleUid);
                false ->%%已有驻守或者不是驻守行军
                    BackMarching = marching:change_goback(Marching, EndPoint),
                    do_fighting(Src, Now, EndPoint, ResSid, Marchings, Occ, [BackMarching | BackMarchs], ORoleUid)
            end;
%%        MarchingState =:= ?ON_THE_MARCHING_GARRISON_RES ->%%驻守时已被其他占领
%%            BackMarching = marching:change_goback(Marching, EndPoint),
%%            do_fighting(Src, Now, EndPoint, ResSid, Marchings, Occ, [BackMarching | BackMarchs], ORoleUid);
        true ->
            RoleRes = res_db:get_role_res(Src, MarchRoleUid),
            MarchRoleShow = role_db:get_role_show(Src, MarchRoleUid),
            Lv = role_show:get_level(MarchRoleShow),
            MaxCount = game_lib:level_value(Lv, element(2, zm_config:get('res_info', 'role_level_res_count'))),
            CurCount = length(role_res:get_psids(RoleRes)),
            if
                CurCount >= MaxCount ->
                    BackMarching = marching:change_goback(Marching, EndPoint),
                    do_fighting(Src, Now, EndPoint, ResSid, Marchings, Occ, [BackMarching | BackMarchs], ORoleUid);
                Occ =/= [] ->%%打驻防玩家
                    [OccMarching] = Occ,
                    OGid = marching:get_gid(OccMarching),
                    MarchCorpUid = role_show:get_corps_uid(MarchRoleShow),
                    OCorpUid = role_show:get_corps_uid(role_db:get_role_show(Src, ORoleUid)),
                    if
                        MarchCorpUid > 0 andalso MarchCorpUid =:= OCorpUid ->
                            zm_event:notify(Src, 'fight_null_report', [
                                {'role_uid', MarchRoleUid},
                                {'point_int', EndPoint},
                                {'time', ETime},
                                {'r_type', ?REPORT_NULL_SAME_CORPS},
                                {'id', ORoleUid}]),
                            BackMarching = marching:change_goback(Marching, EndPoint),
                            do_fighting(Src, Now, EndPoint, ResSid, Marchings, Occ, [BackMarching | BackMarchs], ORoleUid);
                        true ->
                            MarchFightRole = fighter:init_role(Src, MarchRoleUid, MarchGId, 0, garray_db:get_garray(Src, MarchRoleUid, MarchGId)),
                            FightType = match_lib:get_fight_type(?MODULE),
                            Sid = fighting:get_fight_scene('res'),
                            FightArgs = [
                                {'auto', 1},
                                {'time', ETime},
                                {'fight_type', FightType},
                                {'duplicate_sid', Sid},
                                {'seed', game_lib:get_seed()},
                                {'fight_role', MarchFightRole},
                                {'role_uid', MarchRoleUid},
                                {'point_int', EndPoint}],

                            OFighterRole = fighter:init_role(Src, ORoleUid, OGid, 0, garray_db:get_garray(Src, ORoleUid, OGid)),
                            NFightArgs = [{'ma', {'fighting', []}},
                                {'fight_enemy', [OFighterRole]},
                                {'ruid', ORoleUid},
                                {'sid', ResSid} | FightArgs],
                            case match:auto_result(Src, MarchRoleUid, NFightArgs) of
                                {Winner, Result} ->%
                                    Dead = result:get_dead(Result),
                                    Injured = result:get_injured(Result),
                                    RoleChange = result:get_queue(Result),
                                    RoleAddFeats1 = result:get_role_feats(Result),
                                    [EnemyAddFeats1] = result:get_enemy_feats_list(Result),
                                    RoleAddFeats = role_db:award_feats(Src, MarchRoleUid, RoleAddFeats1),
                                    EnemyAddFeats = role_db:award_feats(Src, ORoleUid, EnemyAddFeats1),
                                    Feats = [{MarchRoleUid, RoleAddFeats}, {ORoleUid, EnemyAddFeats}],
                                    WaveInfos = result:get_waves(Result),
                                    [{_, {ODead, OInjured, TargetChange}} | _] = WaveInfos,
                                    {SoldierBearload, MarchQueue, GarrayInjured, _, _} =
                                        fighting:update_garray_after_fight(Src, RoleChange, {MarchRoleUid, MarchGId}),
                                    {OSoldierBearload, OQueue, OGarrayInjured, _, _} =
                                        fighting:update_garray_after_fight(Src, TargetChange, {ORoleUid, OGid}),
                                    MarchingExtra = marching:set_extra_soldier_bearload(marching:get_extra(Marching), SoldierBearload),
                                    OMarchingExtra = marching:set_extra_soldier_bearload(marching:get_extra(OccMarching), OSoldierBearload),
                                    set_front_lib:send_map_result(Src, MarchRoleUid,
                                        {ETime, EndPoint, ?RES, ?ROLE, Winner, MarchGId, {MarchQueue, Dead, Injured, GarrayInjured}, 0}),
                                    set_front_lib:send_map_result(Src, ORoleUid,
                                        {ETime, EndPoint, ?RES, ?ROLE, Winner, OGid, {OQueue, ODead, OInjured, OGarrayInjured}, 1}),
                                    OccFeatsAward = if
                                        EnemyAddFeats > 0 ->
                                            [{'feats', EnemyAddFeats}];
                                        true ->
                                            []
                                    end,
                                    MarchingFeatsAward = if
                                        RoleAddFeats > 0 ->
                                            [{'feats', RoleAddFeats}];
                                        true ->
                                            []
                                    end,
                                    zm_event:notify(Src, 'cross_battle_role_point', Feats),
                                    zm_event:notify(Src, 'fight_role_res_report', [
                                        {'winner', Winner},
                                        {'award_list', []},
                                        {'wave_infos', WaveInfos},
                                        {'personal_num', Feats} | NFightArgs]),
                                    if
                                        Winner =:= 0 ->%进攻方玩家胜利
                                            BMarching = marching:change_goback(marching:set_etime(OccMarching, ETime), EndPoint),
                                            OccBackMarching = marching:set_extra(marching:fight_result(BMarching, OInjured, ODead, OccFeatsAward), OMarchingExtra),
                                            NMarching = marching:set_extra(marching:fight_result(Marching, Injured, Dead, MarchingFeatsAward), MarchingExtra),
%%                                    task_event:notify(Src, MarchRoleUid, [{'fight_times', ?RES, ResSid}, {'fight_win_times', ?RES, ResSid}]),
%%                                    zm_event:notify(Src, achieve, {MarchRoleUid, {argu, [{fight_times, ?RES, ResSid, 1}]}}),
                                            do_fighting(Src, Now, EndPoint, ResSid, [NMarching | Marchings], [], [OccBackMarching | BackMarchs], ORoleUid);
                                        true ->
                                            OccBackMarching = marching:set_extra(marching:fight_result(OccMarching, OInjured, ODead, OccFeatsAward), OMarchingExtra),
                                            NMarching = marching:set_extra(marching:fight_result(Marching, Injured, Dead, MarchingFeatsAward), MarchingExtra),
                                            BackMarching = marching:change_goback(NMarching, EndPoint),
%%                                    task_event:notify(Src, MarchRoleUid, [{'fight_times', ?RES, ResSid}]),
%%                                    zm_event:notify(Src, achieve, {MarchRoleUid, {argu, [{fight_times, ?RES, ResSid, 0}]}}),
                                            do_fighting(Src, Now, EndPoint, ResSid, Marchings, [OccBackMarching], [BackMarching | BackMarchs], ORoleUid)
                                    end;
                                WebErr ->
                                    zm_log:warn(?MODULE, ?MODULE, 'fighting', "web_error", [{'error', WebErr}, {'point_uid', EndPoint}, {'marching', Marching}]),
                                    BackMarching = marching:change_goback(Marching, EndPoint),
                                    do_fighting(Src, Now, EndPoint, ResSid, Marchings, Occ, [BackMarching | BackMarchs], ORoleUid)
                            end
                    end;
                true ->%%打Npc
                    ResDetail = res_detail:get_cfg(ResSid),
                    [NpcArray] = game_lib:random_list(res_detail:get_npc_array(ResDetail), 1),
                    MarchFightRole = fighter:init_role(Src, MarchRoleUid, MarchGId, 0, garray_db:get_garray(Src, MarchRoleUid, MarchGId)),
                    FightType = match_lib:get_fight_type(?MODULE),
                    Sid = fighting:get_fight_scene('res'),
                    FightArgs = [
                        {'auto', 1},
                        {'time', ETime},
                        {'fight_type', FightType},
                        {'duplicate_sid', Sid},
                        {'seed', game_lib:get_seed()},
                        {'fight_role', MarchFightRole},
                        {'role_uid', MarchRoleUid},
                        {'point_int', EndPoint}],
                    FightNpc = fighter:init_npc(NpcArray),
                    NFightArgs = [{'ma', {'fighting', []}}, {'fight_enemy', FightNpc}, {'sid', ResSid} | FightArgs],
                    case match:auto_result(Src, MarchRoleUid, NFightArgs) of
                        {Winner, Result} ->
                            Dead = result:get_dead(Result),
                            Injured = result:get_injured(Result),
                            RoleChange = result:get_queue(Result),
                            AllCardExp = result:get_allexp(Result),
                            WaveInfos = result:get_waves(Result),
                            {SoldierBearload, MarchiQueue, GarrayInjured, _, _DeductSosldierNum} =
                                fighting:update_garray_after_fight(Src, RoleChange, {MarchRoleUid, MarchGId}),
                            MarchingExtra = marching:set_extra_soldier_bearload(marching:get_extra(Marching), SoldierBearload),
                            OneCardExp = garray_db:award_card_allexp(Src, MarchRoleUid, MarchGId, AllCardExp, Sid),%武将加经验
                            set_front_lib:send_map_result(Src, MarchRoleUid,
                                {ETime, EndPoint, ?RES, ?MONSTER, Winner, MarchGId, {MarchiQueue, Dead, Injured, GarrayInjured}, OneCardExp, ResSid}),
                            zm_event:notify(Src, 'fight_res_monster_report', [
                                {'winner', Winner},
                                {'time', ETime},
                                {'sid', ResSid},
                                {'award_list', {[], []}}, %[{'card_exp', OneCardExp}] 不奖励经验cross
                                {'wave_infos', WaveInfos},
                                {'report_type',?REPORT_FIGHT_RESOURCE_MONSTER},
                                {'orole_uid', ORoleUid} | NFightArgs]),
                            if
                                Winner =:= 0 ->
%%                            task_event:notify(Src, MarchRoleUid, [{'fight_times', ?RES, ResSid}, {'fight_win_times', ?RES, ResSid}]),
                                    zm_event:notify(Src, achieve, {MarchRoleUid, {argu, [{fight_times, ?RES, ResSid, 1}]}}),
                                    BackMarching = marching:set_extra(marching:fight_result(marching:change_goback(Marching, EndPoint), Injured, Dead, []), MarchingExtra),
                                    %%占领过的资源点等级
                                    ResLv = res_detail:get_level(ResDetail),
                                    TFun = fun(_, TimeSet1) ->
                                        KLv = z_lib:get_value(TimeSet1, 'res', 0),
                                        if
                                            ResLv > KLv ->
                                                NTimeSet1 = lists:keystore('res', 1, TimeSet1, {'res', ResLv}),
                                                {'ok', 'ok', NTimeSet1};
                                            true ->
                                                {'ok', 'ok'}
                                        end
                                    end,
                                    z_db_lib:update(game_lib:get_table(Src, 'times_set'), MarchRoleUid, times_set_lib:roleuid_key_init(), TFun, []),
                                    do_fighting(Src, Now, EndPoint, ResSid, Marchings, Occ, [BackMarching | BackMarchs], MarchRoleUid);
                                true ->
                                    BackMarching = marching:fight_result(marching:change_goback(marching:set_extra(Marching, MarchingExtra), EndPoint), Injured, Dead, []),
%%                            task_event:notify(Src, MarchRoleUid, [{'fight', ?RES, ResSid}]),
%%                            zm_event:notify(Src, achieve, {MarchRoleUid, {argu, [{fight_times, ?RES, ResSid, 0}]}}),
                                    do_fighting(Src, Now, EndPoint, ResSid, Marchings, Occ, [BackMarching | BackMarchs], ORoleUid)
                            end;
                        WebErr ->
                            %错误直接goback,返回
                            zm_log:warn(?MODULE, ?MODULE, 'fighting', "web_error", [{'error', WebErr}, {'point_uid', EndPoint}, {'marching', Marching}]),
                            BackMarching = marching:change_goback(Marching, EndPoint),
                            do_fighting(Src, Now, EndPoint, ResSid, Marchings, Occ, [BackMarching | BackMarchs], ORoleUid)
                    end
            end
    end.
