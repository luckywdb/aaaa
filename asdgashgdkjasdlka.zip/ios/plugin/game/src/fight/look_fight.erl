-module(look_fight).

%%%=======================STATEMENT====================
-description("寻访点").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    fighting/9,
    null_report/5,
    check_occ_goback/7
]).

-export([
    looking_state/1,
    lookgoback_state/1
]).
%%%=======================INCLUDE======================
-include("../include/point.hrl").

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%     寻访点处理
%% @end
%% ----------------------------------------------------
fighting(_Src, _Now, _EndPoint, _TCorpsUid, _LookSid, _TownSid, [], [], _MRoleUids) ->
    {[], []};
fighting(Src, Now, EndPoint, TCorpsUid, LookSid, TownSid, ArrMarch, Occ, MRoleUids) ->
    LookDetail = look_detail:get_cfg(LookSid),
    MaxNum = look_detail:get_max_num(LookDetail, TownSid),
    {AddBackMarchings, NOcc} =
        do_fighting(Src, EndPoint, LookSid, LookDetail, TownSid, TCorpsUid, ArrMarch, Occ, [], length(Occ), MaxNum),
    check_occ_goback(Src, EndPoint, TownSid, MRoleUids, Now, AddBackMarchings, NOcc).

%% ----------------------------------------------------
%% @doc
%%      检测occ是否有寻访返回
%% @end
%% ----------------------------------------------------
check_occ_goback(Src, EndPoint, TownSid, MRoleUids, Now, AddBackMarchings, NOcc) ->
    Index = marching:get_roleuid_gid_index(),
    Fun = fun({A1, A2}, M) ->
        MRuid = marching:get_roleuid(M),
        %只处理不在线的玩家事件,或者刚上线的玩家,
        AheadBack =
            case lists:member(MRuid, MRoleUids) of
                true ->
                    look_db:event(Src, EndPoint, M, TownSid, ?PSTATE_LOOK_EVENT);%新加入occ和之前occ的处理一次事件
                false ->
                    case login_db:is_online(Src, MRuid) =:= 0 of
                        true ->
                            'ok';
                        false ->
                            look_db:event(Src, EndPoint, M, TownSid, ?PSTATE_LOOK_EVENT) %新加入occ和之前occ的处理一次事件
                    end
            end,
        NewM = case AheadBack of
            {?LOOK_OVER, GoBackTime} ->
                marching:set_etime(M, GoBackTime);
            {?LOOK_OVER, GoBackTime, GType} ->
                marching:set_state(marching:set_etime(M, GoBackTime), GType);
            _ ->
                M
        end,
        Etime = marching:get_etime(NewM),
        if
            Etime =< Now ->
                MarchingState = marching:get_state(NewM),
                GoBackType =
                    if
                        MarchingState =:= ?ON_THE_LOOK_CONSUME ->
                            ?ON_THE_LOOK_GOBACK_CONSUME;
                        MarchingState =:= ?ON_THE_LOOK_DEAD ->
                            ?ON_THE_LOOK_GOBACK_DEAD;
                        true ->
                            ?ON_THE_LOOK_GOBACK_NORMAL
                    end,
                GoBack = marching:change_goback(NewM, EndPoint, 0, GoBackType),
                {'ok', {[GoBack | A1], lists:keydelete(marching:get_roleuid_gid(NewM), Index, A2)}};
            true ->
                {'ok', {A1, A2}}
        end
    end,
    z_lib:foreach(Fun, {AddBackMarchings, NOcc}, NOcc).

%% ----------------------------------------------------
%% @doc
%%     寻访中状态
%% @end
%% ----------------------------------------------------
looking_state(MState) ->
    MState =:= ?ON_THE_LOOK
        orelse MState =:= ?ON_THE_LOOK_CONSUME
        orelse MState =:= ?ON_THE_LOOK_DEAD.

%% ----------------------------------------------------
%% @doc
%%     寻访中状态
%% @end
%% ----------------------------------------------------
lookgoback_state(MState) ->%%这个状态在deal_goback中会发寻访返回的战报
    MState =:= ?ON_THE_LOOK_GOBACK_NORMAL
        orelse MState =:= ?ON_THE_LOOK_GOBACK_CONSUME
        orelse MState =:= ?ON_THE_LOOK_GOBACK_DEAD
        orelse MState =:= ?ON_THE_LOOK_GOBACK_TOWN
        orelse MState =:= ?ON_THE_LOOK_GOBACK_LEAVE_CORPS.

%%%===================LOCAL FUNCTIONS==================
do_fighting(_Src, _EndPoint, _LookSid, _LookDetail, _TownSid, _TCorpsUid, [], Occ, BackMarchs, _, _) ->
    {BackMarchs, Occ};
do_fighting(Src, EndPoint, LookSid, LookDetail, TownSid, TCorpsUid, [Marching | Marchings], Occ, BackMarchs, Num, MaxNum) ->
    {MarchRoleUid, _MarchGId} = marching:get_roleuid_gid(Marching),
    %到达时候,已经不属于自己军团或国家的寻访点
    MRShow = role_db:get_role_show(Src, MarchRoleUid),
    RCorpsUid = role_show:get_corps_uid(MRShow),
    if
        RCorpsUid > 0 andalso RCorpsUid =:= TCorpsUid ->
            if
                Num >= MaxNum ->
                    null_report(Src, TownSid, Marching, EndPoint, ?REPORT_NULL_LOOK_UPPER),
                    BackMarching = marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_LOOK_GOBACK_MAX_UPPER),
                    do_fighting(Src, EndPoint, LookSid, LookDetail, TownSid, TCorpsUid, Marchings, Occ, [BackMarching | BackMarchs], Num, MaxNum);
                true ->
                    OccMarching = marching:look_marching(LookSid, LookDetail, Marching, town_db:get_town_lv(Src, TownSid)),
                    do_fighting(Src, EndPoint, LookSid, LookDetail, TownSid, TCorpsUid, Marchings, [OccMarching | Occ], BackMarchs, Num + 1, MaxNum)
            end;
        true ->
            if
                RCorpsUid =:= 0 ->
                    null_report(Src, TownSid, Marching, EndPoint, ?REPORT_NULL_LOOK_NOCORPS);
                true ->
                    null_report(Src, TownSid, Marching, EndPoint, ?REPORT_NULL_LOOK_TOWN_NOTOWNER)
            end,
            BackMarching = marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_LOOK_GOBACK_MARCH_ARRIVE_NOT_CORPS),
            do_fighting(Src, EndPoint, LookSid, LookDetail, TownSid, TCorpsUid, Marchings, Occ, [BackMarching | BackMarchs], Num, MaxNum)
    end.

%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
null_report(Src, TownSid, Marching, EndPoint, RType) ->
    TownLv = town_db:get_town_lv(Src, TownSid),
    zm_event:notify(Src, 'fight_null_report', [
        {'role_uid', marching:get_roleuid(Marching)},
        {'point_int', EndPoint},
        {'time', marching:get_etime(Marching)},
        {'r_type', RType},
        {'id', {TownSid, TownLv}}]).
