-module(fight_db).

%%%=======================STATEMENT====================
-description("行军db").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    marching/3,
    recall/3,
    speed_up/3,
    role_online/6,
    role_online_garray_/3,
    marching_line/3,
    marching_role_line/4,
    collect_recall/3,
%%    goback_im/3,
    format_assault/2,
    pointuid_fight/4,
    town_occ_marching_back/2,
    town_occ_marching_back_corps/6,
    get_fight_lines/5,
    goback/2,
    castle_move_dealline/5,
    town_fight_notice/7,
    get_country_color/2,
    get_country_name/1,
    get_town_type_name/1,
    occ_repatriate/4,
    occ_repatriate/5,
    occ_recall/7,
    occ_recall/3,
    add_fight_assist/3,
    update_fight_assist/4,
    add_goback_award_log/2,
    del_goback_award_log/2,
    award_goback_award_log/1,
    get_role_march_garray/1,
    cross_get_assault_info/2
]).
-export([add_marching/4, add_marching/5]).
-export([send_assault_info/5]).
-export([marching_spy/3, check/3, consume/3]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").
-include("../include/role.hrl").

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      增加行军线
%% @end
%% ----------------------------------------------------
add_marching(Src, EPointUid, Marching, SeeRoleUidList) ->
    add_marching(Src, EPointUid, Marching, SeeRoleUidList, true).

%% ----------------------------------------------------
%% @doc
%%      增加行军线
%%      AddRoleMarchFlag:起点是否在role_march中加入终点坐标
%% @end
%% ----------------------------------------------------
add_marching(Src, EPointUid, Marching, SeeRoleUidList, AddRoleMarchFlag) ->
    Fun = fun(_, [{Index1, EndPointMarch}]) ->
        NEndPointMarch = point_march:set_marchies(EndPointMarch, [Marching | point_march:get_marchies(EndPointMarch)]),
        {ok, ok, [{Index1, NEndPointMarch}]};
        (_, [{Index1, EndPointMarch}, {Index2, PointMarch}]) ->
            NPointMarch = point_march:set_role_march(PointMarch, [EPointUid | point_march:get_role_march(PointMarch)]),
            NEndPointMarch = point_march:set_marchies(EndPointMarch, [Marching | point_march:get_marchies(EndPointMarch)]),
            {ok, ok, [{Index1, NEndPointMarch}, {Index2, NPointMarch}]}
    end,
    TableName = game_lib:get_table(Src),
    SPointUid = marching:get_s_point(Marching),
    TableKeys = case AddRoleMarchFlag of
        true ->
            z_db_lib:transformation_tablekey(TableName, [
                {'point_march', EPointUid, point_march:init()},
                {'point_march', SPointUid, point_march:init()}
            ]);
        false ->
            z_db_lib:transformation_tablekey(TableName, [
                {'point_march', EPointUid, point_march:init()}
            ])
    end,
    z_db_lib:handle(TableName, Fun, [], TableKeys),
    MarchLine = marching:marching_to_lines(EPointUid, marching:get_epstate(Marching), Marching),
    point_search_db:send_march_line(Src, SPointUid, EPointUid, MarchLine, SeeRoleUidList),
    fight_db:add_fight_assist(Src, EPointUid, Marching),
    ok.
%% ----------------------------------------------------
%% @doc  
%%      行军开始,战斗开始(占领资源,攻打土匪,攻打玩家)
%% @end
%% ----------------------------------------------------
marching(A, {Src, MapId, MarchPoint, EndPoint, Marching, EndPInfo, MarchPInfo, IsStation}, Args) ->
    marching(A, {Src, MapId, MarchPoint, EndPoint, Marching, EndPInfo, MarchPInfo, IsStation, {}}, Args);
marching(_, {Src, MapId, MarchPoint, EndPoint, Marching, EndPInfo, MarchPInfo, IsStation, Extra},
        [{IndexRole, MarchRole}, {Index1, Garray}, {Index2, MarchPMarch}, {Index3, EndPMarch}, {Index4, Restore} | T]) ->
    ConsumePer = if
        MapId > 0 ->
            case garray:check_march(Garray) of
                true ->
                    Dis = point_lib:get_2point_distance(MarchPoint, EndPoint),
                    %行军消耗=距离（按每格边长为1）* 每100兵消耗资源（配置）* 士兵数/100
                    {_, PDis} = zm_config:get('fight_info', 'point_distance'),
                    (Dis / PDis) * garray:get_garray_soldiers(Garray);
                false ->
                    throw("garray_error")
            end;
        true ->
            0
    end,
    case marching_consume(Src, MapId, EndPInfo, MarchRole, Restore, ConsumePer) of
        {ok, BiCs, {NMarchRole, NRestore}} ->
            {MRoleUid, MGId} = marching:get_roleuid_gid(Marching),
            {Bool, MarchPMarch1} =
                case Garray =/= 'none' of
                    true ->
                        case IsStation of
                            false ->
                                {garray:check_march(Garray), MarchPMarch};
                            true ->
                                point_march:check_fighting(MarchPMarch),
                                case lists:keytake({MRoleUid, MGId}, marching:get_roleuid_gid_index(), point_march:get_occupy(MarchPMarch)) of
                                    false ->
                                        {false, MarchPMarch};
                                    {'value', _, OccMs} ->
                                        {garray:check_fight_dup(Garray), point_march:set_occupy(MarchPMarch, OccMs)}
                                end
                        end;
                    false ->
                        {false, MarchPMarch}
                end,
            case Bool of
                true ->
                    RoleMarch = point_march:get_role_march(MarchPMarch),
                    EndMarchies = point_march:get_marchies(EndPMarch),
                    OccMarching = point_march:get_occupy(EndPMarch),
                    NGarray = garray:set_state(Garray, EndPoint),
                    NEndPMarch1 = point_march:set_marchies(EndPMarch, [Marching | EndMarchies]),
                    NEndPMarch = case point_march:get_point_info(NEndPMarch1) of
                        {0, 0} ->%只有point_march未变化时候才设置原先点信息
                            point_march:set_point_info(NEndPMarch1, EndPInfo);
                        _ ->
                            NEndPMarch1
                    end,
                    MState = marching:get_state(Marching),
                    {AddUpdate, OcRoleUid} = case T of
                        [{Index5, Value} | _] ->
                            EndType = element(1, EndPInfo),
                            if
                                MState =:= ?ON_THE_CASTLE_MARCHING ->
                                    Dispatchs = garrison:get_dispatchs(Value),
                                    RoleMarch = point_march:get_role_march(MarchPMarch),
                                    NDispatchs = lists:keystore(MGId, 1, Dispatchs, {MGId, element(2, EndPInfo), EndPoint}),
                                    NValue = garrison:set_dispatchs(Value, NDispatchs),
                                    {[{Index5, NValue}], 0};
                                EndType =:= ?ROLE ->
                                    {[{Index5, castle:remove_protect(Value)}], 0};
                                EndType =:= ?RESOURCE ->
                                    case OccMarching =/= [] of
                                        true ->
                                            OccMarch = hd(OccMarching),
                                            case marching:get_s_point(OccMarch) =/= MarchPoint of
                                                true ->
                                                    {[{Index5, castle:remove_protect(Value)}], marching:get_roleuid(OccMarch)};
                                                false ->
                                                    {[], 0}
                                            end;
                                        _ ->
                                            {[], 0}
                                    end;
                                EndType =:= ?TOWN ->
                                    {[{Index5, castle:remove_protect(Value)}], 0};
                                EndType =:= ?RES ->
                                    {[{Index5, castle:remove_protect(Value)}], 0};
                                EndType =:= ?NULL andalso MState =:= ?ON_THE_MARCHING_STATION ->
                                    {SoldierNum, Weapon} = Extra,
                                    Leisure = barracks:get_leisure(Value),
                                    case SoldierNum > Leisure of
                                        true ->
                                            throw("leisure_limit");
                                        false ->
                                            ok
                                    end,
                                    BWeapon = barracks:get_weapon(Value),
                                    case lists:all(fun({WSid, WNum}) ->
                                        WNum =< z_lib:get_value(BWeapon, WSid, 0) end, Weapon) of
                                        false ->
                                            throw("input_error");
                                        true ->
                                            ok
                                    end,
                                    Stations = barracks:get_stations(Value),
                                    RoleLevel = game_lib:get_level('role', MarchRole),
                                    MaxStationNum = station_lib:get_station_max_num(RoleLevel),
                                    case length(Stations) >= MaxStationNum of
                                        true ->
                                            throw("station_num_limit");
                                        false ->
                                            ok
                                    end,
                                    BStation = barracks:init_station(MGId, SoldierNum, Weapon),
                                    NStations = lists:keystore(MGId, barracks:get_station_gid_index(), Stations, BStation),
                                    NValue = barracks:set_stations(barracks:set_leisure(Value, Leisure - SoldierNum), NStations),
                                    {[{Index5, NValue}], 0};
                                EndType =:= ?MAP_BUILD_CORPS orelse EndType =:= ?MAP_BUILD_TOWN orelse EndType =:= ?MAP_BUILD_ROLE ->
                                    {[{Index5, castle:remove_protect(Value)}], 0};
                                true ->
                                    {[], 0}
                            end;
                        _ ->
                            EndType = element(1, EndPInfo),
                            if
                                EndType =:= ?ROLE ->
                                    {[], element(2, EndPInfo)};
                                EndType =:= ?RESOURCE ->
                                    case OccMarching =/= [] of
                                        true ->
                                            OccMarch = hd(OccMarching),
                                            case marching:get_s_point(OccMarch) =/= MarchPoint of
                                                true ->
                                                    {[], marching:get_roleuid(OccMarch)};
                                                false ->
                                                    {[], 0}
                                            end;
                                        _ ->
                                            {[], 0}
                                    end;
                                true ->
                                    {[], 0}
                            end
                    end,
                    NMarchPMarch = point_march:set_role_march(MarchPMarch1, [EndPoint | RoleMarch]),
                    {'ok', {'ok', NMarchPMarch, NEndPMarch, BiCs, AddUpdate =/= [], OcRoleUid}, [
                        {IndexRole, NMarchRole},
                        {Index1, NGarray},
                        {Index2, point_march:set_point_info(NMarchPMarch, MarchPInfo)},
                        {Index3, NEndPMarch},
                        {Index4, NRestore} | AddUpdate]};
                false ->
                    throw("garray_error")
            end;
        Err ->
            throw(Err)
    end.
%% ----------------------------------------------------
%% @doc
%%      侦查行军开始
%% @end
%% ----------------------------------------------------
marching_spy(_, {Src, RoleUid, EPointUid, MarchPInfo, EndPInfo, Marching}, [{Index1, MapSpy}, {Index2, SPointMarch}, {Index3, EndPointMarch}]) ->
    {_, Conditions} = zm_config:get('map_spy_info', 'investigate'),
    case game_lib:checks({?MODULE, check}, {Src, RoleUid, MapSpy}, 'investigate', Conditions) of
        true ->
            {ConsumeLogs, {_Src, _RoleUid, CrossBattleSpySoldier1}} = game_lib:consumes({?MODULE, consume}, {Src, RoleUid, MapSpy}, 'investigate', Conditions),
            MPoints = map_spy:get_mpoints(CrossBattleSpySoldier1),
            NMPoints = [EPointUid | MPoints],
            NCrossBattleSpySoldier = map_spy:set_mpoints(CrossBattleSpySoldier1, NMPoints),
            NewGid = length(map_spy:get_mpoints(MapSpy)) + length(map_spy:get_builds(MapSpy)),
            NewMarching = marching:set_gid(Marching, NewGid + 1),
            NEndPMarch1 = point_march:set_marchies(EndPointMarch, [NewMarching | point_march:get_marchies(EndPointMarch)]),
            NEndPMarch = case point_march:get_point_info(NEndPMarch1) of
                {0, 0} ->%只有point_march未变化时候才设置原先点信息
                    point_march:set_point_info(NEndPMarch1, EndPInfo);
                _ ->
                    NEndPMarch1
            end,
            NMarchPMarch = point_march:set_role_march(SPointMarch, [EPointUid | point_march:get_role_march(SPointMarch)]),
            {ok, {ok, ConsumeLogs, NewMarching}, [{Index1, NCrossBattleSpySoldier}, {Index2, point_march:set_point_info(NMarchPMarch, MarchPInfo)}, {Index3, NEndPMarch}]};
        Error ->
            throw(Error)
    end.
%%-------------------------------------------------------------------
%% @doc
%%      检查
%% @end
%%-------------------------------------------------------------------
check({_Src, _RoleUid, CrossBattleSpySoldier}, 'investigate', {'soldier_num', Num}) ->
    map_spy:get_leisure(CrossBattleSpySoldier) >= Num;
check({_Src, _RoleUid, CrossBattleSpySoldier}, 'investigate', {'marching_num', MaxNum}) ->
    length(map_spy:get_mpoints(CrossBattleSpySoldier)) + length(map_spy:get_builds(CrossBattleSpySoldier)) < MaxNum.
%%-------------------------------------------------------------------
%% @doc
%%      消耗
%% @end
%%-------------------------------------------------------------------
consume({Src, RoleUid, CrossBattleSpySoldier}, 'investigate', {'soldier_num', Num}) ->
    {{'soldier_num', Num}, {Src, RoleUid, map_spy:set_leisure(CrossBattleSpySoldier, map_spy:get_leisure(CrossBattleSpySoldier) - Num)}};
consume({Src, RoleUid, CrossBattleSpySoldier}, 'investigate', {'marching_num', _Num}) ->
    {[], {Src, RoleUid, CrossBattleSpySoldier}}.
%%-------------------------------------------------------------------
%% @doc
%%      玩家行军召回
%% @end
%%-------------------------------------------------------------------
-spec recall(_, tuple(), list()) -> string()|tuple().
recall(_, _, [{_, 'none'} | _]) ->
    throw("no_marching");
recall(_, {MarchRoleUid, MarchGid, Type, RecallTime, EndPointUid}, [{Index1, EndPMarch}, {Index2, GoodsOrRmb}]) ->
    point_march:check_fighting(EndPMarch),
    {_, {ConsumeProp, NeedRmb}} = zm_config:get('fight_info', 'recall'),
    Bool = if
        Type =:= 0 ->
            storage_lib:exist_by_sid(GoodsOrRmb, ConsumeProp);
        true ->
            rmb_lib:get_rmb(GoodsOrRmb) >= NeedRmb
    end,
    if
        Bool ->
            Marchies = point_march:get_marchies(EndPMarch),
            case lists:keytake({MarchRoleUid, MarchGid}, marching:get_roleuid_gid_index(), Marchies) of
                false ->
                    throw("input_error");
                {value, Marching, NMarchies} ->
                    {BiCs, NGoodsOrRmb} = if
                        Type =:= 0 ->
                            storage_lib:deduct_by_sid(GoodsOrRmb, ConsumeProp);
                        true ->
                            rmb_lib:reduct_rmb(GoodsOrRmb, NeedRmb)
                    end,
                    GoBackList = point_march:get_goback(EndPMarch),
                    {GoBack, ViewGoBack} = marching:change_recall(Marching, time_lib:now_second(), RecallTime, EndPointUid),
                    NGoBackList = [GoBack | GoBackList],
                    {'ok', {'ok', point_march:get_point_info(EndPMarch), ViewGoBack, BiCs, Marching, GoBack, point_march:get_occupy(EndPMarch)},
                        [{Index1, point_march:set_goback(point_march:set_marchies(EndPMarch, NMarchies), NGoBackList)},
                            {Index2, NGoodsOrRmb}]}
            end;
        true ->
            throw("consume_limit")
    end.

%% ----------------------------------------------------
%% @doc
%%      返回到达城堡事务数据处理.
%% @end
%% ----------------------------------------------------
speed_up(_, _, [{_, 'none'} | _]) ->
    throw("no_marching");
speed_up(_, {MarchRoleUid, MarchRole, MarchGId, Consume, Percent, Type}, [{Index1, EndPMarch}, {Index2, GoodsOrRmb}]) ->
    Bool = if
        Type =:= 0 ->
            storage_lib:exist_by_sid(GoodsOrRmb, Consume);
        true ->
            rmb_lib:get_rmb(GoodsOrRmb) >= Consume
    end,
    if
        Bool ->
            Index = marching:get_roleuid_gid_index(),
            Marchies = point_march:get_marchies(EndPMarch),
            EndPState = point_march:get_point_info(EndPMarch),
            {GoBackFlag, Marching, GobackOrMarchies} =
                case lists:keyfind({MarchRoleUid, MarchGId}, Index, Marchies) of
                    false ->
                        GoBack = point_march:get_goback(EndPMarch),
                        case lists:keyfind({MarchRoleUid, MarchGId}, Index, GoBack) of
                            false ->
                                throw("input_error");
                            MarchingTemp ->
                                {true, MarchingTemp, GoBack}
                        end;
                    MarchingTemp ->
                        {false, MarchingTemp, Marchies}
                end,
            Times = vip_lib:get_marching_speed_up_times(MarchRole),
            AddSpeedTimes = marching:get_add_speed_times(Marching),
            {NEndPMarch, NMarching} =
                if
                    AddSpeedTimes >= Times ->
                        throw("marching_add_speed_times");
                    true ->
                        NMarching1 = marching:set_add_speed_times(marching_speed(Marching, Percent), AddSpeedTimes + 1),
                        NGobackOrMarchies = lists:keyreplace({MarchRoleUid, MarchGId}, Index, GobackOrMarchies, NMarching1),
                        if
                            GoBackFlag ->
                                {point_march:set_goback(EndPMarch, NGobackOrMarchies), NMarching1};

                            true ->
                                {point_march:set_marchies(EndPMarch, NGobackOrMarchies), NMarching1}
                        end
                end,
            {BiCs, NGoodOrRmb} = if
                Type =:= 0 ->
                    storage_lib:deduct_by_sid(GoodsOrRmb, Consume);
                true ->
                    rmb_lib:reduct_rmb(GoodsOrRmb, Consume)
            end,
            {'ok', {'ok', GoBackFlag, Marching, NMarching, BiCs, EndPState, point_march:get_occupy(NEndPMarch)},
                [{Index1, NEndPMarch}, {Index2, NGoodOrRmb}]};
        true ->
            throw("consume_limit")
    end.

%%-------------------------------------------------------------------
%% @doc
%%      玩家采集中召回
%% @end
%%-------------------------------------------------------------------
-spec collect_recall(_, {integer(), integer()}, list()) -> string()|tuple().
collect_recall(_, _, [{_, 'none'} | _]) ->
    throw("no_marching");
collect_recall(Args, {MarchRoleUidGId, Time}, [{Index1, EndPMarch}]) ->
    point_march:check_fighting(EndPMarch),
    OccMarching = point_march:get_occupy(EndPMarch),
    Index = marching:get_roleuid_gid_index(),
    case lists:keyfind(MarchRoleUidGId, Index, OccMarching) of
        false ->
            throw("input_error");
        Marching ->
            NMarching =
                case Args of
                    [] ->
                        marching:set_etime(Marching, Time);
                    [GoBackType] ->
                        marching:set_state(marching:set_etime(Marching, Time), GoBackType)
                end,
            NOccMarching = lists:keyreplace(MarchRoleUidGId, Index, OccMarching, NMarching),
            NEndPMarch = point_march:set_occupy(EndPMarch, NOccMarching),
            {ok, {Marching, NOccMarching}, [{Index1, NEndPMarch}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      通用occ遣返
%% @end
%% ----------------------------------------------------
occ_repatriate(Src, MRoleUid, MGId, EndPointUid) ->
    occ_recall(Src, MRoleUid, MGId, EndPointUid, ?MODULE, 'occ_recall', []).
occ_repatriate(Src, MRoleUid, MGId, EndPointUid, GoBackMState) ->
    occ_recall(Src, MRoleUid, MGId, EndPointUid, ?MODULE, 'occ_recall', [GoBackMState]).

%% ----------------------------------------------------
%% @doc
%%      通用occ召回
%% @end
%% ----------------------------------------------------
occ_recall(Src, MRoleUid, MGId, EndPointUid, M, F, A) ->
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'point_march', EndPointUid, 'none'}]),
    case z_db_lib:handle(TableName, {M, F, A}, {MRoleUid, MGId, EndPointUid, time_lib:now_second()}, TableKeys) of
        {'ok', Marchings, EndPointState, NOccMarchings, OldMarchies} ->
            RUids =
                case EndPointState of
                    {PointType, _, Key} when PointType =:= ?MAP_BUILD_CORPS orelse PointType =:= ?MAP_BUILD_TOWN orelse PointType =:= ?MAP_BUILD_ROLE ->
                        map_build_db:recalc_map_build(Src, Key, EndPointUid, NOccMarchings),
                        [];
                    {PointType, EndRoleUid} when PointType =:= ?ROLE ->
                        [EndRoleUid];
                    {PointType, EndRoleUid} when PointType =:= ?STATION ->
                        point_search_db:update_station_occ(Src, EndPointUid, length(NOccMarchings)),
                        [EndRoleUid];
                    {PointType, EndRoleUid} when PointType =:= ?MAP_SPY ->
                        point_search_db:update_map_spy_build_occ(Src, EndPointUid, length(NOccMarchings)),
                        [EndRoleUid];
                    _ ->
                        []
                end,
            lists:foreach(fun(Marching) ->
                MarchLine = marching:marching_to_lines(EndPointUid, EndPointState, Marching),
                point_search_db:send_march_line(Src, marching:get_s_point(Marching), EndPointUid, MarchLine, [MRoleUid | RUids])
            end, Marchings),
            update_fight_assist(Src, EndPointUid, OldMarchies, Marchings),
            "ok";
        Err ->
            Err
    end.

%% ----------------------------------------------------
%% @doc
%%      通用occ召回
%% @end
%% ----------------------------------------------------
occ_recall(_, _, [{_, 'none'} | _]) ->
    throw("no_marching");
occ_recall(Args, {MRoleUid, GId, EndPointUid, Time}, Ls) when is_integer(GId) ->
    occ_recall(Args, {MRoleUid, [GId], EndPointUid, Time}, Ls);
occ_recall(Args, {MRoleUid, GIdList, EndPointUid, Time}, [{Index1, EndPMarch}]) ->
    point_march:check_fighting(EndPMarch),
    {AddGoBackMs, NOccMs, OldMarchings} = z_lib:foreach(fun({BAcc1, OAcc2, OldM}, M) ->
        {RUid, GId} = marching:get_roleuid_gid(M),
        case RUid =:= MRoleUid andalso lists:member(GId, GIdList) of
            true ->
                NM =
                    case Args of
                        [] ->
                            marching:change_goback(M, EndPointUid, Time);
                        [GoBackType] ->
                            marching:change_goback(M, EndPointUid, Time, GoBackType)
                    end,
                {ok, {[NM | BAcc1], OAcc2, [M | OldM]}};
            false ->
                {ok, {BAcc1, [M | OAcc2], OldM}}
        end
    end, {[], [], []}, point_march:get_occupy(EndPMarch)),
    case AddGoBackMs =:= [] of
        true ->
            throw("input_error");
        false ->
            NOccMarching = lists:reverse(NOccMs),
            NEndPMarch = point_march:set_goback(point_march:set_occupy(EndPMarch, NOccMarching), AddGoBackMs ++ point_march:get_goback(EndPMarch)),
            {ok, {ok, AddGoBackMs, point_march:get_point_info(EndPMarch), NOccMarching, OldMarchings}, [{Index1, NEndPMarch}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      登录获取各队伍信息:{ 0=没有攻击信息/=1有玩家攻打,{队伍id,队伍详细信息,队伍状态/0空闲/1行军中/2返回城堡中/3主城驻守/4盟友主城驻守/5采集中,起点uid,终点uid,速度,开始时间}}
%% @end
%% ----------------------------------------------------
role_online(Src, RoleUid, 0, [], _, _CardStorage) ->
    RoleStations = station_db:get_role_stations(Src, RoleUid),
    Garrion = garrison_db:get_garrison(Src, RoleUid),
    RoleMapBuild = map_build_db:get_map_build(Src, {'role', RoleUid}),
    {{}, [], Garrion, RoleStations, RoleMapBuild};
role_online(Src, RoleUid, 0, GarrayIds, _Bool, _CardStorage) ->%没有主城
    GIdArrays = garray_db:get_garray(Src, RoleUid, GarrayIds),
    Garrion = garrison_db:get_garrison(Src, RoleUid),
    RoleStations = station_db:get_role_stations(Src, RoleUid),
    RoleMapBuild = map_build_db:get_map_build(Src, {'role', RoleUid}),
    {{}, [garray_format_def(GId, Garray) || {GId, Garray} <- GIdArrays], Garrion, RoleStations, RoleMapBuild};
role_online(Src, RoleUid, RolePoint, GarrayIds, Bool, CardStorage) ->
    Now = time_lib:now_second(),
    GIdArrays1 = garray_db:get_garray(Src, RoleUid, GarrayIds),
%%    TODO 处理阵型兵器与武将类型不一致，下个版本删除
    GIdArrays =
        case CardStorage =/= {} of
            true ->
                lists:map(fun({GId, Garray}) ->
                    case garray:check_idle(Garray) of
                        true ->
                            NGarray = garray_db:clear_weapon_error(Src, RoleUid, GId, Garray, CardStorage),
                            {GId, NGarray};
                        false ->
                            {GId, Garray}
                    end
                end, GIdArrays1);
            false ->
                GIdArrays1
        end,
%%    RoleRes = res_db:get_role_res(Src, RoleUid),
%%    PSids = role_res:get_psids(RoleRes),
%%    PUids = lists:map(fun({PUid, _}) -> PUid end, PSids),
    Table = game_lib:get_table(Src, 'point_march'),
%%    ResFightPoints =
%%        z_lib:foreach(fun(R, {PUid, ResSid}) ->
%%            {ok, get_fight_lines(Table, PUid, {?RES, ResSid}) ++ R}
%%        end, [], PSids),
    RoleStations = station_db:get_role_stations(Src, RoleUid),
    RoleMapBuild = map_build_db:get_map_build(Src, {'role', RoleUid}),
    case get_role_march_garray(GIdArrays) of
        {[], [], FGarrys} ->
            pointuid_fight(Src, RoleUid, [RolePoint], Now),%如果有向玩家自己的行军信息
            Garrion = garrison_db:get_garrison(Src, RoleUid),
            FightLines = get_fight_lines(Table, RolePoint, RoleUid, RoleStations, RoleMapBuild),
            if
                Bool ->
                    deal_barracks_occupy(Src, RoleUid, GarrayIds);
                true ->
                    ok
            end,
            {list_to_tuple(FightLines), FGarrys, Garrion, RoleStations, RoleMapBuild};
        {_, EndPointS, _} ->
            pointuid_fight(Src, RoleUid, [RolePoint | EndPointS], Now),%直接判断是否战斗，需要则直接战斗一次
            Garrion = garrison_db:get_garrison(Src, RoleUid),
            NGIdArrays = garray_db:get_garray(Src, RoleUid, GarrayIds),%战斗之后重新获取队伍信息
            if
                Bool ->
                    deal_barracks_occupy(Src, RoleUid, GarrayIds);
                true ->
                    ok
            end,
            case get_role_march_garray(NGIdArrays) of
                {[], [], FGarrys} ->
                    FightLines = get_fight_lines(Table, RolePoint, RoleUid, RoleStations, RoleMapBuild),
                    {list_to_tuple(FightLines), FGarrys, Garrion, RoleStations, RoleMapBuild};
                {RoleGIdGArrays, FightPoints, IdleGArray} ->
                    EndPMarchs = z_db_lib:gets(Table, FightPoints, point_march:init()),
                    Dispatchs = garrison:get_dispatchs(Garrion),
                    {DelGids, GarrayStates, NAllSNum, Lines} = get_del_garray(Src, RoleUid, RoleGIdGArrays, FightPoints, EndPMarchs, Dispatchs),
                    if
                        DelGids =:= [] -> 'ok';
                        true ->
                            TableName = game_lib:get_table(Src),
                            %%由于存在,登录战斗时候可能在战斗中,然后战斗终点触发了战斗,然后将role_march中marching已经拿出来并准备deal_goback操作
                            %%然后此处将role_march删除后,导致fighting里面处理deal_goback时候变为none处理,兵力不一致,故这里不处理role_march
                            TableKeys = z_db_lib:transformation_tablekey(TableName, [
                                {'garrison', RoleUid, garrison:init()} |
                                [{'garray', {RoleUid, Gid}} || Gid <- DelGids]]),
                            z_db_lib:handle(TableName, {?MODULE, role_online_garray_, []}, {RoleUid, NAllSNum, DelGids}, TableKeys)
                    end,
                    FightLines = get_fight_lines(Table, RolePoint, RoleUid, RoleStations, RoleMapBuild),
                    {list_to_tuple(FightLines ++ Lines), IdleGArray ++ GarrayStates, Garrion, RoleStations, RoleMapBuild}
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      获取玩家有行军信息,但是行军信息已不存在的异常情况处理
%% @end
%% ----------------------------------------------------
-spec get_del_garray(Src, RoleUid, RoleGIdGArrays, FightPoints, EndPMarchs, Dispatchs) -> {list(), list(), integer(), list()} when
    Src :: atom(),
    RoleUid :: integer(),
    RoleGIdGArrays :: [{integer(), garray:garray()}],
    FightPoints :: [integer()],
    EndPMarchs :: [point_march:point_march()],
    Dispatchs :: list().
get_del_garray(_Src, RoleUid, RoleGIdGArrays, FightPoints, EndPMarchs, Dispatchs) ->%获取玩家行军信息已经不存在了的gid
    GidPmarch = lists:zipwith3(fun(X, Y, Z) -> {X, Y, Z} end, RoleGIdGArrays, FightPoints, EndPMarchs),
    F = fun({NoMarchs, GarrMarch, AllSNum, Lines}, {{GId, Garray}, PMUid, PMarch}) ->
        NAllSNum = AllSNum + garray:get_garray_soldiers(Garray),
        Marchies = point_march:get_marchies(PMarch),
        Index = marching:get_roleuid_gid_index(),
%%        PInfo = point_march:get_point_info(PMarch),
        {NNoMarchs, NNGState, NOccLines} =
            case lists:keyfind({RoleUid, GId}, Index, Marchies) of
                false ->
                    GoBack = point_march:get_goback(PMarch),
                    case lists:keyfind({RoleUid, GId}, Index, GoBack) of
                        false ->
                            OccMarchings = point_march:get_occupy(PMarch),
                            case lists:keyfind({RoleUid, GId}, Index, OccMarchings) of
                                false ->
                                    %%数据不一致
                                    NGState = garray_format_def(GId, garray:set_state(Garray, ?IDLE)),
                                    {[GId | NoMarchs], NGState, Lines};
                                OccMarching ->
                                    %%驻防好友中
                                    PInfo = marching:get_epstate(OccMarching),
                                    case lists:keyfind(GId, 1, Dispatchs) of
                                        false ->
                                            %%驻扎点中
                                            %%资源点采集中
                                            %%建筑驻防中
                                            NGState = garray_format_ext(GId, Garray, PMUid, OccMarching, PInfo),
                                            case element(1, PInfo) =:= ?RESOURCE of
                                                true ->
                                                    {NoMarchs, NGState, marching:marching_to_lines(PMUid, PInfo, Marchies ++ GoBack) ++ Lines};
                                                false ->
                                                    {NoMarchs, NGState, Lines}
                                            end;
                                        _ ->
                                            StartTime = marching:get_stime(OccMarching),
                                            FightNum = marching:get_fight_num(OccMarching),
                                            NGState = garray_format_castle(GId, Garray, ?ON_THE_CASTLE_OTHER, element(2, PInfo), StartTime, FightNum),
                                            {NoMarchs, NGState, Lines}
                                    end
                            end;
                        GMarching ->
                            PInfo = marching:get_epstate(GMarching),
                            NGState = garray_format_ext(GId, Garray, PMUid, GMarching, PInfo),
                            {NoMarchs, NGState, Lines}
                    end;
                MMarching ->
                    PInfo = marching:get_epstate(MMarching),
                    NGState = garray_format_ext(GId, Garray, PMUid, MMarching, PInfo),
                    {NoMarchs, NGState, Lines}
            end,
        {'ok', {NNoMarchs, [NNGState | GarrMarch], NAllSNum, NOccLines}}
    end,
    z_lib:foreach(F, {[], [], 0, []}, GidPmarch).

%% ----------------------------------------------------
%% @doc
%%      处理玩家阵型中,有行军信息,但是行军信息已不存在的异常情况处理
%% @end
%% ----------------------------------------------------
-spec role_online_garray_(_, {integer(), integer(), list()}, list()) -> tuple().
role_online_garray_(_, {_RoleUid, _NAllSoldiersNum, DeleteGIds}, [{Index3, Garrison} | Garrays]) ->
    Dispatchs = garrison:get_dispatchs(Garrison),
    NDispatchs = lists:filter(fun({GId, _, _}) -> not lists:member(GId, DeleteGIds) end, Dispatchs),
    NGarrison = garrison:set_dispatchs(Garrison, NDispatchs),
    {'ok', 'ok', [{Index3, NGarrison} | [{I, garray:set_state(Garray, ?IDLE)} || {I, Garray} <- Garrays]]}.

%% ----------------------------------------------------
%% @doc
%%      获取所有向自己行军的信息,
%% @end
%% ----------------------------------------------------
-spec get_fight_lines(Table, PointUid, RoleUid, RoleStaions, RoleMapBuild) -> list() when
    Table :: atom(),
    PointUid :: integer(),
    RoleUid :: integer(),
    RoleStaions :: [station:stations()],
    RoleMapBuild :: map_build:map_build().
get_fight_lines(Table, PointUid, RoleUid, RoleStations, RoleMapBuild) ->
    Fun = fun(STable, PUid, PointState) ->
        case z_db_lib:get(STable, PUid, 'none') of
            'none' ->
                [];
            RolePMarch ->
                AMarchies = point_march:get_marchies(RolePMarch),
                AGoMarchies = point_march:get_goback(RolePMarch),
                marching:marching_to_lines(PUid, PointState, AGoMarchies ++ AMarchies)
        end
    end,
    Lines = z_lib:foreach(fun(Acc, Station) ->
        {ok, Fun(Table, station:get_puid(Station), {?STATION, RoleUid}) ++ Acc}
    end, Fun(Table, PointUid, {?ROLE, RoleUid}), RoleStations),
    z_lib:foreach(fun(Acc, MBV) ->
        {ok, Fun(Table, map_build:get_v_point_uid(MBV), {?MAP_BUILD_ROLE, map_build:get_v_sid(MBV), {'role', RoleUid}}) ++ Acc}
    end, Lines, map_build:get_build(RoleMapBuild)).

%% ----------------------------------------------------
%% @doc
%%      上线战斗,
%% @end
%% ----------------------------------------------------
-spec pointuid_fight(atom(), integer(), [integer()], integer()) -> 'ok'.
pointuid_fight(_Src, _RoleUid, [], _) ->
    'ok';
pointuid_fight(Src, RoleUid, EndPMarchUids, FightTime) ->
    NEndPMarchUids = lists:usort(EndPMarchUids),
    Table = game_lib:get_table(Src, 'point_march'),
    EndPMarchs = z_db_lib:gets(Table, NEndPMarchUids),
    F = fun(Args, {_, 'none'}) ->
        {'ok', Args};
        (FightUids, {EndPoint, EndPMarch}) ->
            OccMarching = point_march:get_occupy(EndPMarch),
            PointInfo = point_march:get_point_info(EndPMarch),
            PT = element(1, PointInfo),
            Bool = OccMarching =/= [] andalso
                ((PT =/= ?TOWN andalso lists:any(fun(O) -> marching:get_etime(O) =< FightTime end, OccMarching)) orelse
                    (PT =:= ?TOWN andalso check_town_npc_fight(Src, element(2, PointInfo), EndPoint, OccMarching, FightTime))
                ),%注意:城池occ友军驻防的etime不能判断,有look需要处理事件
            NFightUids =
                case Bool orelse
                    point_march:check_arrive(point_march:get_marchies(EndPMarch), FightTime) orelse
                    point_march:check_arrive(point_march:get_goback(EndPMarch), FightTime) of
                    true -> [EndPoint | FightUids];
                    false -> FightUids
                end,
            {'ok', NFightUids}
    end,
    FightList = z_lib:foreach(F, [], lists:zip(NEndPMarchUids, EndPMarchs)),
    lists:foreach(fun(ArriveEndPoint) ->
        fighting:arrive(Src, ArriveEndPoint, point_state_db:get_point_info(Src, ArriveEndPoint), [RoleUid]) end, FightList).%战斗


%%-------------------------------------------------------------------
%% @doc
%%      判断驻守中的城池点是否发生npc刷新后战斗(城池不是自己的才会刷新Npc后和Npc战斗)
%% @end
%%-------------------------------------------------------------------
-spec check_town_npc_fight(atom(), integer(), integer(), list(), integer()) -> boolean().
check_town_npc_fight(Src, TownSid, EndPoint, OccMarching, Now) ->
    Town = point_db:get_town(Src, TownSid),
    {Tstate, Stime, _Etime} = town:get_state(Town),
    if
        Tstate =:= ?STATE_FIGHT ->
            RefreshTime = z_lib:get_value(town:get_npc_refresh_time(Town), EndPoint, Stime),
            {_, IntervalTime} = zm_config:get('fight_info', 'town_npc_refresh'),
            (Now - RefreshTime) div IntervalTime > 0;
        true ->
            TownDetail = town_detail:get_cfg(TownSid),
            PointUid = town_detail:get_point(TownDetail),
            EndPoint =:= PointUid %寻访点是第一个点,则战斗执行寻访事件
                andalso lists:any(fun(O) -> look_fight:looking_state(marching:get_state(O)) end, OccMarching)
    end.


%% ----------------------------------------------------
%% @doc
%%      行军指向点的行军线信息
%% @end
%% ----------------------------------------------------
marching_line(_, [], _) ->
    {[], []};
marching_line(Src, EndPoints, FUids) ->
    Table = game_lib:get_table(Src, 'point_march'),
    EndPMarchs = z_db_lib:gets(Table, EndPoints),
    Now = time_lib:now_second(),
    Fun = fun(Args, {_, 'none'}) ->
        {'ok', Args};
        ({EndPMarchUids, FightPoints, Lines}, {EndPoint, EndPMarch}) ->
            NEndPMarchUids =
                case point_march:get_role_march(EndPMarch) of
                    [] ->
                        EndPMarchUids;
                    RoleMarch ->
                        lists:usort(RoleMarch ++ EndPMarchUids)
                end,
            {NFightPoints, NLines} = get_fightuid_lines(EndPMarch, EndPoint, FightPoints, Lines, Now, FUids),
            {'ok', {NEndPMarchUids, NFightPoints, NLines}}
    end,
    {NEndPoints, NFightPoints1, NLines1} = z_lib:foreach(Fun, {[], [], []}, lists:zip(EndPoints, EndPMarchs)),
    {NFightPoints2, NLines2} = marching_role_line(Src, NEndPoints--EndPoints, Now, FUids),%去掉一屏里面相同的点的计算
    {NFightPoints2 ++ NFightPoints1, NLines2 ++ NLines1}.

%% ----------------------------------------------------
%% @doc
%%      玩家坐标点对应各行军线信息
%% @end
%% ----------------------------------------------------
-spec marching_role_line(Src, EndPoints, Now, FUids) -> {[integer()], list()} when
    Src :: atom(),
    EndPoints :: [integer()],
    Now :: integer(),
    FUids :: [integer()].
marching_role_line(_, [], _, _) ->
    {[], []};
marching_role_line(Src, EndPoints, Now, FUids) ->%玩家攻打方的线会
    Table = game_lib:get_table(Src, 'point_march'),
    PMarchs = z_db_lib:gets(Table, EndPoints),
    Fun = fun(Args, {_, 'none'}) ->
        {'ok', Args};
        ({FightPoints, Lines}, {EndPoint, EndPMarch}) ->
            Reply = get_fightuid_lines(EndPMarch, EndPoint, FightPoints, Lines, Now, FUids),
            {'ok', Reply}
    end,
    z_lib:foreach(Fun, {[], []}, lists:zip(EndPoints, PMarchs)).

%% ----------------------------------------------------
%% @doc
%%      获取需要战斗的点的uids以及行军线信息
%% @end
%% ----------------------------------------------------
-spec get_fightuid_lines(PMarch, PUid, FightUids, Lines, Now, FUids) -> tuple() when
    PMarch :: point_march:point_march(),
    PUid :: integer(),
    FightUids :: [integer()],
    Lines :: [tuple()],
    Now :: integer(),
    FUids :: [integer()].
get_fightuid_lines(EndPMarch, EndPoint, FightPoints, Lines, Now, FUids) ->
    Marchies = point_march:get_marchies(EndPMarch),
    GoBack = point_march:get_goback(EndPMarch),
    EndPState = point_march:get_point_info(EndPMarch),
    EType = element(1, EndPState),
    Occ = point_march:get_occupy(EndPMarch),
    if
        Marchies =:= [] andalso GoBack =:= [] ->
            case EType =:= ?TOWN andalso lists:any(fun(M) ->
                MState = marching:get_state(M),
                look_fight:looking_state(MState)
            end, Occ) of
                true ->
                    {[EndPoint | FightPoints], Lines};
                false ->
                    {FightPoints, Lines}
            end;
        true ->
            {ArrMList1, NArrMList1} = point_march:get_arrive(Marchies, Now, false),
            %行军到达之后,采集,驻防都不是直接返回
            {GoMList1, NGoMList1} = point_march:get_arrive(GoBack, Now, false),
            MapId = point_lib:xyz2mapid(EndPoint),
            TownFlag = zm_config:get(point_lib:mapid2cfgname('point_check_town', MapId), point_lib:xyz2view(EndPoint)) =/= 'none',
            NFightUids =
                case TownFlag
                    orelse ArrMList1 =/= []
                    orelse GoMList1 =/= []
                    orelse (Occ =/= [] andalso lists:any(fun(O) -> marching:get_etime(O) =< Now end, Occ))
                    orelse (EType =:= ?TOWN andalso Occ =/= [] andalso lists:any(fun(M) ->
                        MState = marching:get_state(M),
                        look_fight:looking_state(MState) end, Occ)) of
                    true ->
                        [EndPoint | FightPoints];
                    false -> FightPoints
                end,
            GList =
                case lists:member(point_lib:point2search_point(EndPoint), FUids) of
                    true ->
                        marching:marching_to_lines(EndPoint, EndPState, NGoMList1 ++ NArrMList1);
                    false ->
                        lists:foldl(fun(M, Acc) ->
                            case lists:member(point_lib:point2search_point(marching:get_s_point(M)), FUids) of
                                true ->
                                    [L] = marching:marching_to_lines(EndPoint, EndPState, M),
                                    [L | Acc];
                                false ->
                                    Acc
                            end
                        end, [], NGoMList1 ++ NArrMList1)
                end,
            {NFightUids, GList ++ Lines}
    end.


%%%% ----------------------------------------------------
%%%% @doc
%%%%      立即回城
%%%% @end
%%%% ----------------------------------------------------
%%-spec goback_im(Src, RoleUid, GId) -> 'ok' | string() when
%%    Src :: atom(),
%%    RoleUid :: integer(),
%%    GId :: integer().
%%goback_im(Src, RoleUid, GId) ->
%%    Garray = garray_db:get_garray(Src, RoleUid, GId),
%%    State = garray:get_state(Garray),
%%    case State of
%%        ?IDLE ->
%%            ok;
%%        ?ON_THE_CASTLE ->
%%            Garrison = garrison_db:get_garrison(Src, RoleUid),
%%            Dispatchs = garrison:get_dispatchs(Garrison),
%%            {EndRoleUid, _} = lists:keyfind(GId, 2, Dispatchs),
%%            MarchPoint = role_show:get_point(role_db:get_role_show(Src, RoleUid)),
%%            EndPoint = role_show:get_point(role_db:get_role_show(Src, EndRoleUid)),
%%            TableName = game_lib:get_table(Src),
%%            TableKeys = z_db_lib:transformation_tablekey(TableName, [
%%                {'garray', {RoleUid, GId}, garray:init()},
%%                {'garrison', RoleUid, garrison:init()},
%%                {'garrison', EndRoleUid, garrison:init()},
%%                {'point_march', MarchPoint, point_march:init()},
%%                {'point_march', EndPoint, point_march:init()},
%%                {'barracks', RoleUid, barracks:init()}
%%            ]),
%%            InjureMax = building_db:get_injure_max(Src, RoleUid),
%%            case z_db_lib:handle(TableName, fun goback_im_1/2, {Src, RoleUid, GId, EndRoleUid, EndPoint, InjureMax}, TableKeys) of
%%                {ok, ?ON_THE_CASTLE, IsDelMarching, Injure2Dead, _Feats} ->%%TODO 增加Feats
%%                    fighting:injure2dead_mail(Src, RoleUid, Injure2Dead),
%%                    if
%%                        IsDelMarching ->
%%                            point_search_db:del_marching(Src, MarchPoint),
%%                            point_search_db:del_marching(Src, EndPoint);
%%                        true ->
%%                            set_front_lib:send_garrison_remove_friend_garray(Src, EndRoleUid, RoleUid, GId)
%%                    end,
%%                    ok;
%%                {ok, _, _} ->
%%                    ok;
%%                Other ->
%%                    Other
%%            end;
%%        _ ->
%%            EndPoint = State,
%%            TableName = game_lib:get_table(Src),
%%            MarchPoint = role_show:get_point(role_db:get_role_show(Src, RoleUid)),
%%            TableKeys = z_db_lib:transformation_tablekey(TableName, [
%%                {'garray', {RoleUid, GId}, garray:init()},
%%                {'point_march', MarchPoint, point_march:init()},
%%                {'point_march', EndPoint, point_march:init()}
%%            ]),
%%            case z_db_lib:handle(TableName, fun goback_im_2/2, {Src, RoleUid, GId, EndPoint}, TableKeys) of
%%                {true, OccMarching} ->
%%                    point_search_db:del_marching(Src, MarchPoint),
%%                    point_search_db:del_marching(Src, EndPoint),
%%                    case OccMarching =/= [] of
%%                        true ->
%%                            point_search_db:update_resource_occ(Src, 0, EndPoint, OccMarching, []);
%%                        false ->
%%                            ok
%%                    end,
%%                    ok;
%%                false ->
%%                    ok;
%%                Other ->
%%                    Other
%%            end
%%    end.

%% ----------------------------------------------------
%% @doc
%%     获取袭击者显示信息
%% @end
%% ----------------------------------------------------
-spec format_assault(Src :: atom(), Marching :: marching:marching()) -> tuple().
format_assault(Src, Marching) ->
    MState = marching:get_state(Marching),
    if
        MState =:= ?ON_THE_MB_CC ->
            {_, Times} = marching:get_roleuid_gid(Marching),
            Extra = marching:get_extra(Marching),
            CorpsName = marching:get_extra_mb_cc_corpsname(Extra),
            Country = marching:get_extra_mb_cc_country(Extra),
            {_, BSids} = zm_config:get('map_build_info', 'ordnance'),
            Name = game_lib:get_language_package(map_build_detail:get_name(map_build_detail:get_cfg(hd(BSids)))),
            {MState, 0, Name, Country, CorpsName, 0, Times};
        MState =:= ?ON_THE_PATROL ->
            Extra = marching:get_extra(Marching),
            CorpsName = marching:get_extra_mb_cc_corpsname(Extra),
            Country = marching:get_extra_mb_cc_country(Extra),
            {_, BSids} = zm_config:get('map_build_info', 'map_build_patrol'),
            Name = game_lib:get_language_package(map_build_detail:get_name(map_build_detail:get_cfg(hd(BSids)))),
            {MState, 0, Name, Country, CorpsName, 0};
        MState =:= ?ON_THE_INVESTIGATE ->%%侦查
            {MRoleUid, SoldierNum} = marching:get_roleuid_gid(Marching),
            MRoleShow = role_db:get_role_show(Src, MRoleUid),
            %%TODO 获取战斗力
            SoldiersNum = 0,
            {MState, role_show:get_style(MRoleShow), role_show:get_name(MRoleShow), role_show:get_country(MRoleShow),
                role_show:get_corps_name(MRoleShow), SoldiersNum, SoldierNum};
        true ->
            {MRoleUid, MGId} = marching:get_roleuid_gid(Marching),
            MRoleShow = role_db:get_role_show(Src, MRoleUid),
            SoldiersNum = garray:get_garray_soldiers(garray_db:get_garray(Src, MRoleUid, MGId)),
            {MState, role_show:get_style(MRoleShow), role_show:get_name(MRoleShow), role_show:get_country(MRoleShow),
                role_show:get_corps_name(MRoleShow), SoldiersNum, MGId}
    end.

%% ----------------------------------------------------
%% @doc
%%     返回玩家主城()
%% @end
%% ----------------------------------------------------
goback(Src, EndPoint) ->
    Now = time_lib:now_second(),
    Fun = fun(_, 'none') ->
        throw("ok");
        (_, EndPMarch) ->
            GoBacks = point_march:get_goback(EndPMarch),
            {ArrMList1, NArrMList1} = point_march:get_arrive(GoBacks, Now),
            OPMarch = point_march:check_del(point_march:set_goback(EndPMarch, NArrMList1)),
            {'ok', {'ok', point_march:get_point_info(EndPMarch), ArrMList1, OPMarch}, OPMarch}
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'point_march'), EndPoint, 'none', Fun, []) of
        {'ok', _, [], OPMFlag} ->
            fighting:chk_del_psfight(Src, EndPoint, OPMFlag),
            "ok";
        {'ok', EndPState, Marchings, OPMFlag} ->
            fighting:chk_del_psfight(Src, EndPoint, OPMFlag),
            fighting:deal_goback(Src, EndPoint, Marchings, EndPState, false),
            "ok";
        Err ->
            Err
    end.


%% ----------------------------------------------------
%% @doc
%%     玩家迁城后行军线处理
%%     策划需求: 被击飞: 行军中的队伍,如果是pvp行为则回城 ;主动迁城不回城
%% @end
%% ----------------------------------------------------
castle_move_dealline(Src, RoleUid, OldPointUid, NPointUid, PvpIsGoBack) ->
    Table = game_lib:get_table(Src, 'point_march'),
    PMarch = z_db_lib:get(Table, OldPointUid, point_march:init()),
    case point_march:get_role_march(PMarch) of
        [] -> %无行军
            'ok';
        List ->
            %行军线处理
            GarrayTable = game_lib:get_table(Src, 'garray'),
            Now = time_lib:now_second(),
            RoleStations = station_db:get_role_stations(Src, RoleUid),
            F = fun(DRMarch, PUid) ->
                F1 = fun(_, PointMarch) ->
                    AMarchies = point_march:get_marchies(PointMarch),
                    OccList = point_march:get_occupy(PointMarch),
                    {AMarchs, UpA, PvpGoBack} =
                        if
                            AMarchies =:= [] ->
                                {[], [], []};
                            true ->
                                change_spoint_goback(Now, element(1, point_march:get_point_info(PointMarch)), OccList =/= [], PvpIsGoBack, AMarchies, RoleUid, NPointUid, PUid, RoleStations, {[], [], []})
                        end,
                    {GoBack, UpG} = change_spoint(Now, point_march:get_goback(PointMarch), RoleUid, NPointUid, PUid, {[], []}, true, RoleStations),
                    {PState, Timeout} = point_march:get_state(PointMarch),
                    {Occ, UpO} =
                        case PState =:= ?PSTATE_FIGHTING andalso time_lib:now_second() < Timeout of
                            true ->
                                {OccList, []};
                            false ->
                                change_spoint_occ(Now, OccList, RoleUid, NPointUid, PUid, {[], []}, false, RoleStations)
                        end,
                    NPointMarch = point_march:set_marchies(point_march:set_occupy(point_march:set_goback(PointMarch, GoBack), Occ), AMarchs),
                    DelRMarch =
                        if
                            PvpIsGoBack andalso PvpGoBack =/= [] andalso UpG =:= [] andalso UpO =:= [] ->
                                lists:duplicate(length(PvpGoBack), PUid); %多支队伍回城,则需要处理多支role_march
                            true ->
                                []
                        end,
                    {'ok', {PvpGoBack, DelRMarch, UpA, UpG, UpO, point_march:get_point_info(NPointMarch)}, NPointMarch}
                end,
                {PvpGoBacks, DelRoleMarchs, UpA1, UpG1, UpO1, EndPState} = z_db_lib:update(Table, PUid, point_march:init(), F1, []),
                point_search_db:send_back_occ_line(Src, time_lib:now_second(), RoleUid, PUid, EndPState, PvpGoBacks ++ UpG1, UpA1 ++ UpO1),
                update_fight_assist(Src, PUid, [], PvpGoBacks ++ UpG1 ++ UpA1 ++ UpO1),
                lists:foreach(fun(M) ->
                    {MRuid, MRgid} = marching:get_roleuid_gid(M),
                    set_front_lib:send_goback(Src, MRuid, {{}, {MRgid, marching:get_state(M)}, 0, 0}),
                    GFun = fun(_, Garray) ->
                        {'ok', 'ok', garray:set_state(Garray, ?IDLE)}
                    end,
                    z_db_lib:update(GarrayTable, {MRuid, MRgid}, GFun, []),
                    map_build_db:update_mb_fight_num(Src, marching:get_state(M), marching:get_epstate(M), PUid, -1)
                end, PvpGoBacks),
                {'ok', DelRoleMarchs ++ DRMarch}
            end,
            RoleMarchDels = z_lib:foreach(F, [], List),
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'point_march', OldPointUid}, {'point_march', NPointUid, point_march:init()}]),
            HFun = fun(_, [{Index1, OPm}, {Index2, NPm}]) ->
                OR = (point_march:get_role_march(OPm) ++ point_march:get_role_march(NPm))--RoleMarchDels,
                OPMarch = point_march:check_del(point_march:set_role_march(OPm, [])),
                {'ok', OPMarch, [{Index1, OPMarch}, {Index2, point_march:set_role_march(NPm, OR)}]}
            end,
            OPCheck = z_db_lib:handle(TableName, HFun, [], TableKeys),
            if
                OPCheck =:= 'delete' ->
                    point_search_db:del_marching(Src, OldPointUid);%point_search_fight未删除bug
                true ->
                    ok
            end,
            point_search_db:add_marching(Src, [NPointUid], point_lib:point2search_point(NPointUid))%需要将自己加入战斗表中,否则看不到线
    end.


%% ----------------------------------------------------
%% @doc
%%      切换所有行军为新的出发点
%% @end
%% ----------------------------------------------------
change_spoint(_Now, [], _, _, _, {Value, ChangeValue}, _Bool, _RoleStations) ->
    {lists:reverse(Value), ChangeValue};
change_spoint(Now, [Marching | T], RoleUid, NewPoint, EndPoint, {Value, ChangeValue}, Bool, RoleStations) ->
    {MRoleUid, GId} = marching:get_roleuid_gid(Marching),
    case MRoleUid =:= RoleUid andalso lists:keyfind(GId, station:get_gid_index(), RoleStations) =:= 'false' of
        true ->
            NMarch = marching:change_spoint(Now, Marching, NewPoint, EndPoint, Bool),
            change_spoint(Now, T, RoleUid, NewPoint, EndPoint, {[NMarch | Value], [NMarch | ChangeValue]}, Bool, RoleStations);
        false ->
            change_spoint(Now, T, RoleUid, NewPoint, EndPoint, {[Marching | Value], ChangeValue}, Bool, RoleStations)
    end.

%% ----------------------------------------------------
%% @doc
%%      切换所有行军为新的出发点
%% @end
%% ----------------------------------------------------
change_spoint_occ(_Now, [], _, _, _, {Value, ChangeValue}, _Bool, _RoleStations) ->
    {lists:reverse(Value), ChangeValue};
change_spoint_occ(Now, [Marching | T], RoleUid, NewPoint, EndPoint, {Value, ChangeValue}, Bool, RoleStations) ->
    {MRoleUid, GId} = marching:get_roleuid_gid(Marching),
    RoleStation = lists:keyfind(GId, station:get_gid_index(), RoleStations),
    case MRoleUid =:= RoleUid andalso (RoleStation =:= 'false' orelse station:get_puid(RoleStation) =:= EndPoint) of
        true ->
            NMarch = marching:change_spoint(Now, Marching, NewPoint, EndPoint, Bool),
            change_spoint(Now, T, RoleUid, NewPoint, EndPoint, {[NMarch | Value], [NMarch | ChangeValue]}, Bool, RoleStations);
        false ->
            change_spoint(Now, T, RoleUid, NewPoint, EndPoint, {[Marching | Value], ChangeValue}, Bool, RoleStations)
    end.

%% ----------------------------------------------------
%% @doc
%%      切换所有行军为新的出发点,并判断是否直接返回
%% @end
%% ----------------------------------------------------
change_spoint_goback(_Now, _PState, _OccNull, _PvpIsGoBack, [], _, _, _, _, {Value, ChangeValue, PvpGoBack}) ->
    {lists:reverse(Value), ChangeValue, PvpGoBack};
change_spoint_goback(Now, PState, OccNull, PvpIsGoBack, [Marching | T], RoleUid, NewPoint, EndPoint, RoleStations, {Value, ChangeValue, PvpGoBack}) ->
    {MRoleUid, GId} = marching:get_roleuid_gid(Marching),
    case MRoleUid =:= RoleUid andalso lists:keyfind(GId, station:get_gid_index(), RoleStations) =:= 'false' of
        true ->
            MState = marching:get_state(Marching),
            if
                MState =:= ?ON_THE_INVESTIGATE ->
                    NMarch = marching:change_spoint(Now, Marching, NewPoint, EndPoint, true),
                    change_spoint_goback(Now, PState, OccNull, PvpIsGoBack, T, RoleUid, NewPoint, EndPoint, RoleStations, {[NMarch | Value], [NMarch | ChangeValue], PvpGoBack});
                PvpIsGoBack andalso (((PState =:= ?ROLE orelse PState =:= ?STATION) andalso MState =/= ?ON_THE_CASTLE_MARCHING) %攻打玩家
                    orelse (PState =:= ?TOWN andalso (MState =/= ?ON_THE_LOOK_MARCHING andalso MState =/= ?ON_THE_TOWN_GARRISON_MARCHING)) %寻访,驻防不直接回城
                    orelse (OccNull andalso (MState =:= ?ON_THE_MARCHING orelse MState =:= ?ON_THE_FIGHT_MB_MARCHING))) ->
                    %直接到家的线给前台推送,否则前台未删除该线
                    change_spoint_goback(Now, PState, OccNull, PvpIsGoBack, T, RoleUid, NewPoint, EndPoint, RoleStations, {Value, ChangeValue, [marching:set_etime(Marching, marching:get_stime(Marching)) | PvpGoBack]});
                true ->
                    NMarch = marching:change_spoint(Now, Marching, NewPoint, EndPoint, true),
                    change_spoint_goback(Now, PState, OccNull, PvpIsGoBack, T, RoleUid, NewPoint, EndPoint, RoleStations, {[NMarch | Value], [NMarch | ChangeValue], PvpGoBack})
            end;
        false ->
            change_spoint_goback(Now, PState, OccNull, PvpIsGoBack, T, RoleUid, NewPoint, EndPoint, RoleStations, {[Marching | Value], ChangeValue, PvpGoBack})
    end.

%% ----------------------------------------------------
%% @doc
%%      对城池发起进攻的时候在聊天频道发出消息
%% @end
%% ----------------------------------------------------
town_fight_notice(Src, TownDetail, Town, AttackCorpsUid, AttackCorps, DefenseCorpsUid, _IsChief) ->
    {X, Y} = point_lib:int2xy(town_detail:get_point(TownDetail)),
    TownName = town_detail:get_name(TownDetail),
    TownLevel = town:get_lv(Town, TownDetail),
    ACountry = corps:get_country(AttackCorps),
    AttackCorpsName = get_country_color(ACountry, corps:get_name(AttackCorps)),
    AttackCountry = get_country_name(ACountry),
    TownTypeName = get_town_type_name(town_detail:get_type(TownDetail)),
    {CfgName, Args} =
        if
            DefenseCorpsUid =/= 0 -> %该城池属于其他军团
                DCorps = corps_db:get_corps(Src, DefenseCorpsUid),
                DCountry = corps:get_country(DCorps),
                DefenseCorpsName = get_country_color(DCountry, corps:get_name(DCorps)),
                DCountryName = get_country_name(DCountry),
                chat_lib:notice_corps(Src, 'corps_town_fight_attack', [DCountryName, DefenseCorpsName, TownTypeName, TownLevel, TownName, X, Y], AttackCorpsUid),
                chat_lib:notice_corps(Src, 'corps_town_fight_defense', [TownTypeName, TownLevel, TownName, X, Y, AttackCountry, AttackCorpsName], DefenseCorpsUid),
                {'corps_town_fight', [AttackCountry, AttackCorpsName, DCountryName, DefenseCorpsName, TownTypeName, TownLevel, TownName, X, Y]};
            true ->     %该城池无人占领
                chat_lib:notice_corps(Src, 'begin_town_fight_corps', [TownTypeName, TownLevel, TownName, X, Y], AttackCorpsUid),
                {'begin_town_fight', [AttackCountry, AttackCorpsName, TownTypeName, TownLevel, TownName, X, Y]}
        end,
    chat_lib:notice_world(Src, CfgName, Args).

%%    lists:foreach(fun(C) -> chat_lib:notice_country(Src, CfgName, Args, C) end, ?ALL_COUNTRY).%压测过程时候内存会飙升

%% ----------------------------------------------------
%% @doc
%%     根据国家获取,军团名字颜色
%% @end
%% ----------------------------------------------------
get_country_color(Country, Name) ->
    string_lib:content(game_lib:get_language({'country_color', Country}), [Name]).

%% ----------------------------------------------------
%% @doc
%%      获取国家
%% @end
%% ----------------------------------------------------
get_country_name(Country) ->
    game_lib:get_language({'country', Country}).

%% ----------------------------------------------------
%% @doc
%%      获取城类型名字
%% @end
%% ----------------------------------------------------
get_town_type_name(TownType) ->
    game_lib:get_language({'town_type', TownType}).
%% ----------------------------------------------------
%% @doc
%%      推送袭击信息
%% @end
%% ----------------------------------------------------
send_assault_info(Src, MapId, RoleUid, Marching, EndPoint) ->
    View = {list_to_tuple(marching:marching_to_lines(EndPoint, 0, Marching)), {{point_lib:xyz2view(marching:get_s_point(Marching)), {format_assault(Src, Marching)}}}},
    case login_db:get_online(Src, RoleUid) of
        none ->
            if
                MapId > 0 ->%%跨服的消息需要发送到本服
                    CenterSrc = game_lib:get_center_src(),
                    cross_server_msg:send_cast(CenterSrc, RoleUid, {'cross_battle_rpc', 'send_assault_info', {RoleUid, View}});
                true -> %%本服的消息发送到跨服
                    server_cross_msg:send_cast(Src, "cb_area", RoleUid, {'cross_battle_area_rpc', 'send_assault_info', {RoleUid, View}})
            end;
        _Session -> %%在线不处理
            ok
    end.

%% ----------------------------------------------------
%% @doc
%%      跨服获取袭击信息
%% @end
%% ----------------------------------------------------
cross_get_assault_info(Src, RoleUid) ->
    Now = time_lib:now_second(),
    Table = game_lib:get_table(Src, 'point_march'),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    RolePoint = role_show:get_point(RoleShow),
    RoleStations = station_db:get_role_stations(Src, RoleUid),

    Fun = fun(STable, PUid, PointState) ->
        case z_db_lib:get(STable, PUid, 'none') of
            'none' ->
                [];
            RolePMarch ->
                AMarchies = point_march:get_marchies(RolePMarch),
                ArrMarchies = lists:filter(fun(M) ->
                    Now < marching:get_etime(M)
                end, AMarchies),
                SPoins = z_lib:foreach(fun(Points, M) ->
                    SPoint = marching:get_s_point(M),
                    case lists:member(SPoint, Points) of
                        true ->
                            {ok, Points};
                        false ->
                            {ok, [SPoint | Points]}
                    end
                end, [], ArrMarchies),
                [{"line", marching:marching_to_lines(PUid, PointState, ArrMarchies)}, {"spoint", SPoins}, {"epoint", [PUid]}]
        end
    end,
    RoleCastleArrLinesSpoinsEPoints = Fun(Table, RolePoint, {?ROLE, RoleUid}),
    StationsArrLinesSpoinsEPoints = z_lib:foreach(fun(Acc, Station) ->
        {ok, merage_tuple_list(Acc, Fun(Table, station:get_puid(Station), {?STATION, RoleUid}))}
    end, [], RoleStations),

    %%    个人建筑
    MapBuild = z_db_lib:get(game_lib:get_table(Src, 'map_build'), {role, RoleUid}, map_build:init()),
    Builds = map_build:get_build(MapBuild),
    RoleBuildArrLinesSpoinsEPoints = z_lib:foreach(fun(Acc, Build) ->
        Point = map_build:get_v_point_uid(Build),
        {ok, merage_tuple_list(Acc, Fun(Table, Point, {?MAP_BUILD_ROLE, RoleUid}))}
    end, [], Builds),

    LinesSPointsEPoints1 = merage_tuple_list(RoleCastleArrLinesSpoinsEPoints, StationsArrLinesSpoinsEPoints),
    LinesSPointsEPoints2 = merage_tuple_list(LinesSPointsEPoints1, RoleBuildArrLinesSpoinsEPoints),

    StartPoints = z_lib:get_value(LinesSPointsEPoints2, "spoint", []),
    EndPoints = z_lib:get_value(LinesSPointsEPoints2, "epoint", []),
    AllLines = z_lib:get_value(LinesSPointsEPoints2, "line", []),

    Views =
        z_lib:foreach(fun(R, PUid) ->
            case z_db_lib:get(game_lib:get_table(Src, 'point_march'), PUid, 'none') of
                'none' ->
                    {ok, R};
                EndPMarch ->
                    Marchies = point_march:get_marchies(EndPMarch),
                    NR = z_lib:foreach(fun(R1, PUid1) ->
                        MList = lists:filter(fun(M) -> marching:get_s_point(M) =:= PUid1 end, Marchies),
                        {ok, [{point_lib:xyz2view(PUid1), list_to_tuple([format_assault(Src, M) || M <- MList])} | R1]}
                    end, R, StartPoints),
                    {ok, NR}
            end
        end, [], EndPoints),
    {ok, {list_to_tuple(AllLines), list_to_tuple(Views)}}.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%      行军加速,修改marching
%% @end
%% ----------------------------------------------------
-spec marching_speed(Marching, Percent) -> marching:marching() when
    Marching :: marching:marching(),
    Percent :: integer().
marching_speed(Marching, Percent) ->
    Now = time_lib:now_second(),
    ETime = marching:get_etime(Marching),
    HaveTime = ETime - Now,
    NewTime = HaveTime - (HaveTime * Percent div 10000),
    NETime = Now + max(NewTime, 0),
    marching:set_etime(Marching, NETime).

%% ----------------------------------------------------
%% @doc
%%      获取队伍列表中有行军信息的队伍
%% @end
%% ----------------------------------------------------
-spec get_role_march_garray(NGIdArrays :: [{integer(), garray:garray()}]) -> {list(), list(), list()}.
get_role_march_garray(NGIdArrays) ->
    F = fun({A1, A2, A3}, {GId, Garray}) ->
        GState = garray:get_state(Garray),
        if
            GState > ?ON_THE_CASTLE ->
                %(有行军和返回行军都是存pointuid,只有空闲和主城驻防才会存point.hrl对应的宏)空闲和主城驻防都没有行军信息;
                %%友军驻防的需要计算一次,是否有被上阵且被打,如果失败则返回
                {'ok', {[{GId, Garray} | A1], [GState | A2], A3}};
            true ->
                {'ok', {A1, A2, [garray_format_def(GId, Garray) | A3]}}
        end
    end,
    z_lib:foreach(F, {[], [], []}, NGIdArrays).

%% ----------------------------------------------------
%% @doc
%%      没出征的队伍状态信息
%%      {队伍id,队伍详细信息(garray.erl),队伍状态/0空闲/1行军中/2返回城堡中/3主城驻守/4盟友主城驻守/5采集中/8寻访中/17驻守新资源点中/18寻访行军中,起点uid,终点uid,速度,开始时间,结束时间,使用加速次数,类型,资源点sid/友军uid/土匪sid/城池sid,战斗次数}}
%% @end
%% ----------------------------------------------------
-spec garray_format_def(GId :: integer(), Garray :: garray:garray()) -> tuple().
garray_format_def(GId, Garray) ->
    {GId, erlang:delete_element(1, Garray), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}.

%% ----------------------------------------------------
%% @doc
%%      驻防状态(需要将终点给予对方)
%% @end
%% ----------------------------------------------------
-spec garray_format_castle(GId :: integer(), Garray :: garray:garray(), EndPoint :: integer(), Sid :: integer(), StartTime :: integer(), FightNum :: integer()) -> tuple().
garray_format_castle(GId, Garray, State, Sid, StartTime, FightNum) ->
    {GId, erlang:delete_element(1, Garray), State, 0, point_lib:xyz2view(garray:get_state(Garray)), 0, StartTime, 0, 0, ?ROLE, Sid, FightNum, 0}.

%% ----------------------------------------------------
%% @doc
%%      出征的队伍状态信息
%% @end
%% ----------------------------------------------------
-spec garray_format_ext(GId, Garray, EndPUid, Marching, PointInfo) -> tuple() when
    GId :: integer(),
    Garray :: garray:garray(),
    EndPUid :: integer(),
    Marching :: marching:marching(),
    PointInfo :: tuple().
garray_format_ext(GId, Garray, EndPUid, Marching, PointInfo) ->
    BearLoad = marching:get_extra_bearload(marching:get_extra(Marching)),
    Type = element(1, PointInfo),
    PStateInfoSid =
        if
            Type =:= ?TOWN ->
                point_lib:sid2view(element(2, PointInfo));
            true ->
                element(2, PointInfo)
        end,
    %%TODO 跨服ios,特殊处理
    NState = case marching:get_state(Marching) of
        ?ON_THE_LOOK_GOBACK_NORMAL ->
            ?ON_THE_TOWN_GOBACK;
        ?ON_THE_LOOK_GOBACK_CONSUME ->
            ?ON_THE_TOWN_GOBACK;
        ?ON_THE_LOOK_GOBACK_DEAD ->
            ?ON_THE_TOWN_GOBACK;
        ?ON_THE_LOOK_GOBACK_TOWN ->
            ?ON_THE_TOWN_GOBACK;
        ?ON_THE_LOOK_GOBACK_LEAVE_CORPS ->
            ?ON_THE_TOWN_GOBACK;
        ?ON_THE_LOOK_GOBACK_MAX_UPPER ->
            ?ON_THE_TOWN_GOBACK;
        ?ON_THE_LOOK_GOBACK_MARCH_ARRIVE_NOT_CORPS ->
            ?ON_THE_TOWN_GOBACK;
        ?ON_THE_LOOK_MARCHING ->
            ?ON_THE_MARCHING;
        Other ->
            Other
    end,
    {GId, erlang:delete_element(1, Garray),
        NState,
        point_lib:xyz2view(marching:get_s_point(Marching)),
        point_lib:xyz2view(EndPUid),
        marching:get_speed(Marching),
        marching:get_stime(Marching),
        marching:get_etime(Marching),
        marching:get_add_speed_times(Marching),
        Type,
        PStateInfoSid,
        marching:get_fight_num(Marching),
        BearLoad
    }.

%%-------------------------------------------------------------------
%% @doc
%%      城池驻防返回
%% @end
%%-------------------------------------------------------------------
-spec town_occ_marching_back(atom(), integer()) -> term().
town_occ_marching_back(Src, RoleUid) ->
    TableName = game_lib:get_table(Src, 'point_march'),
    RolePointUid = role_show:get_point(role_db:get_role_show(Src, RoleUid)),
    MapId = point_lib:xyz2mapid(RolePointUid),
    RolePMarch = z_db_lib:get(TableName, RolePointUid, point_march:init()),
    TownPoints = lists:filter(fun(PUid) ->
        zm_config:get(point_lib:mapid2cfgname('point_check_town', MapId), point_lib:xyz2view(PUid)) =/= 'none' end, point_march:get_role_march(RolePMarch)),
    if
        TownPoints =:= [] ->
            ok;
        true ->
            PMarchs = z_db_lib:gets(TableName, TownPoints, point_march:init()),
            Now = time_lib:now_second(),
            lists:foreach(fun({PointUid, PMarch1}) ->
                HasGoBack = lists:any(fun(Marching) ->
                    marching:get_roleuid(Marching) =:= RoleUid end, point_march:get_occupy(PMarch1)),
                if
                    HasGoBack ->
                        Fun = fun(_, PMarch2) ->
                            {ToGoBackMarchins, NOccMarchings} = lists:partition(fun(Marching) ->
                                marching:get_roleuid(Marching) =:= RoleUid end, point_march:get_occupy(PMarch2)),
                            AddGobackMarchings =
                                [begin
                                    State = marching:get_state(M),
                                    LookState = look_fight:looking_state(State),
                                    if
                                        LookState ->
                                            marching:change_goback(M, PointUid, Now, ?ON_THE_LOOK_GOBACK_LEAVE_CORPS);
                                        true ->
                                            marching:change_goback_byetime(M, PointUid, Now)
                                    end
                                end || M <- ToGoBackMarchins],
                            NPMarch2 = point_march:set_occupy(point_march:set_goback(PMarch2, AddGobackMarchings ++ point_march:get_goback(PMarch2)), NOccMarchings),
                            {ok, {ok, AddGobackMarchings}, NPMarch2}
                        end,
                        {ok, AddGobackMarchings} = z_db_lib:update(TableName, PointUid, point_march:init(), Fun, []),
                        TownSid = element(2, point_march:get_point_info(PMarch1)),
                        point_search_db:send_back_occ_line(Src, Now, RoleUid, PointUid, {?TOWN, TownSid}, AddGobackMarchings, []);
                    true ->
                        'ok'
                end
            end, lists:zip(TownPoints, PMarchs))
    end.

%% ----------------------------------------------------
%% @doc
%%     城池归属变化
%% @end
%% ----------------------------------------------------
town_occ_marching_back_corps(Src, TownSid, PointUids, CorpsUid, FightCUids, ISchief) ->
    TableName = game_lib:get_table(Src, 'point_march'),
    Now = time_lib:now_second(),
    lists:foreach(fun(PointUid) ->
        Fun = fun(_, 'none') ->
            {'ok', []};
            (_, PMarch2) ->
                {ToGoBackMarchins, NOccMarchings} =
                    lists:partition(fun(Marching) ->
                        RoleUid = marching:get_roleuid(Marching),
                        RoleShow = role_db:get_role_show(Src, RoleUid),
                        RShowCorpsUid = role_show:get_corps_uid(RoleShow),
                        RShowCorpsUid =:= CorpsUid orelse RShowCorpsUid =:= 0 %军团长解散时候已经没有军团了
                    end, point_march:get_occupy(PMarch2)),
                AddGobackMarchings =
                    [begin
                        State = marching:get_state(M),
                        LookState = look_fight:looking_state(State),
                        if
                            LookState ->
                                marching:change_goback(M, PointUid, Now, ?ON_THE_LOOK_GOBACK_TOWN);
                            true ->
                                marching:change_goback_byetime(M, PointUid, Now)
                        end
                    end || M <- ToGoBackMarchins],
                NPMarch2 = point_march:set_occupy(point_march:set_goback(PMarch2, AddGobackMarchings ++ point_march:get_goback(PMarch2)), NOccMarchings),
                {ok, AddGobackMarchings, NPMarch2}
        end,
        GobackMarchings = z_db_lib:update(TableName, PointUid, 'none', Fun, []),
        point_search_db:send_back_occ_line(Src, Now, 0, PointUid, {?TOWN, TownSid}, GobackMarchings, [])
    end, PointUids),
    town_fight:clear_corps_fighting(Src, TownSid, FightCUids, ISchief).%放弃等情况,城池进入保护状态,需要清除所有军团的战斗状态,否则该状态一直存在

%%%% ----------------------------------------------------
%%%% @doc
%%%%     立即回城处理
%%%% @end
%%%% ----------------------------------------------------
%%-spec goback_im_1(tuple(), list()) -> tuple().
%%goback_im_1({_Src, RoleUid, GId, EndRoleUid, EndPoint, InjureMax}, [{Index1, Garray}, {Index2, Garrison}, {Index3, EndGarrison}, {Index4, PointMarch}, {Index5, EndPointMarch}, {Index6, Barracks}]) ->
%%    State = garray:get_state(Garray),
%%    if
%%        State =:= ?ON_THE_CASTLE ->
%%            EndFriendGarrays = garrison:get_friend_garrays(EndGarrison),
%%            RGId = {RoleUid, GId},
%%            case lists:keyfind(RGId, garrison:get_friend_roleuid_gid_index(), EndFriendGarrays) of
%%                false ->
%%                    RGIndex = marching:get_roleuid_gid_index(),
%%                    EndMarchings = lists:keydelete(RGId, RGIndex, point_march:get_marchies(EndPointMarch)),
%%                    Gobacks = point_march:get_goback(EndPointMarch),
%%                    EndGobacks = lists:keydelete(RGId, RGIndex, Gobacks),
%%                    NEndPointMarch = point_march:set_goback(point_march:set_marchies(EndPointMarch, EndMarchings), EndGobacks),
%%                    NPointMarch = point_march:set_role_march(PointMarch, lists:delete(EndPoint, point_march:get_role_march(PointMarch))),
%%                    NGarrison = garrison:set_dispatchs(Garrison, lists:keydelete(EndRoleUid, 1, garrison:get_dispatchs(Garrison))),
%%                    NGarray = garray:set_state(Garray, ?IDLE),
%%                    {DeadNum, InjuredNum} =
%%                        case lists:keyfind(RGId, RGIndex, Gobacks) of
%%                            false ->
%%                                {0, 0};
%%                            M ->
%%                                {marching:get_dead(M), marching:get_injured(M)}
%%                        end,
%%                    {Injure2Dead, NBarracks} = barracks:fight_over(Barracks, GId, DeadNum, InjuredNum, InjureMax),
%%                    {ok, {ok, ?ON_THE_CASTLE, true, Injure2Dead, 0}, [{Index1, NGarray}, {Index2, NGarrison}, {Index4, point_march:check_del(NPointMarch)},
%%                        {Index5, point_march:check_del(NEndPointMarch)}, {Index6, NBarracks}]};
%%                GarrisonFriend ->
%%                    DeadNum = garrison:get_friend_dead(GarrisonFriend),
%%                    InjuredNum = garrison:get_friend_injured(GarrisonFriend),
%%                    Feats = garrison:get_friend_feats(GarrisonFriend),
%%                    NEndGarrison = garrison:set_friend_garrays(EndGarrison, lists:keydelete(RGId, garrison:get_friend_roleuid_gid_index(), EndFriendGarrays)),
%%                    NPointMarch = point_march:set_role_march(PointMarch, lists:delete(EndPoint, point_march:get_role_march(PointMarch))),
%%                    NGarrison = garrison:set_dispatchs(Garrison, lists:keydelete(EndRoleUid, 1, garrison:get_dispatchs(Garrison))),
%%                    NGarray = garray:set_state(Garray, ?IDLE),
%%                    {Injure2Dead, NBarracks} = barracks:fight_over(Barracks, GId, DeadNum, InjuredNum, InjureMax),
%%                    {ok, {ok, ?ON_THE_CASTLE, false, Injure2Dead, Feats}, [{Index1, NGarray}, {Index2, NGarrison}, {Index3, NEndGarrison},
%%                        {Index4, point_march:check_del(NPointMarch)}, {Index6, NBarracks}]}
%%            end;
%%        true ->
%%            {ok, {ok, State, false}}
%%    end.

%%%% ----------------------------------------------------
%%%% @doc
%%%%     立即回城处理
%%%% @end
%%%% ----------------------------------------------------
%%-spec goback_im_2(tuple(), list()) -> tuple().
%%goback_im_2({_Src, RoleUid, GId, EndPoint}, [{Index1, Garray}, {Index2, PointMarch}, {Index3, EndPointMarch}]) ->
%%    State = garray:get_state(Garray),
%%    if
%%        State > ?ON_THE_CASTLE ->
%%            NGarray = garray:set_state(Garray, ?IDLE),
%%            NPointMarch = point_march:set_role_march(PointMarch, lists:delete(EndPoint, point_march:get_role_march(PointMarch))),
%%            RGIndex = marching:get_roleuid_gid_index(),
%%            RGId = {RoleUid, GId},
%%            EndMarchings = lists:keydelete(RGId, RGIndex, point_march:get_marchies(EndPointMarch)),
%%            EndGobacks = lists:keydelete(RGId, RGIndex, point_march:get_goback(EndPointMarch)),
%%            NEndMarchings = lists:keydelete(RGId, RGIndex, EndMarchings),
%%            NEndGobacks = lists:keydelete(RGId, RGIndex, EndGobacks),
%%            NEndPointMarch = point_march:set_occupy(point_march:set_goback(point_march:set_marchies(EndPointMarch, EndMarchings), EndGobacks), []),
%%            {ok, {EndMarchings =/= NEndMarchings orelse EndGobacks =:= NEndGobacks, point_march:get_occupy(EndPointMarch)},
%%                [{Index1, NGarray}, {Index2, NPointMarch}, {Index3, NEndPointMarch}]};
%%        true ->
%%            {ok, false}
%%    end.


%% ----------------------------------------------------
%% @doc
%%    兵营数据不一致,上线处理
%% @end
%% ----------------------------------------------------
deal_barracks_occupy(Src, RoleUid, GarrayIds) ->
    TableName = game_lib:get_table(Src),
    GInit = garray:init(),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'barracks', RoleUid, barracks:init()} | [{'garray', {RoleUid, Gid}, GInit} || Gid <- GarrayIds]]),
    Fun1 = fun(_, [{Index1, Barracks} | T]) ->
        {Bool, NBarracks, AllNum} = z_lib:foreach(fun({B, BarracksAcc, Num}, {GId, {_, Garray}}) ->
            case garray:check_idle(Garray) of
                true ->
                    case barracks:get_gid_marching_dj(BarracksAcc, GId) of
                        {0, 0} ->
                            {ok, {B, BarracksAcc, garray:get_garray_soldiers(Garray) + Num}};
                        {DNum, INum} ->
                            NBarracksAcc1 = barracks:update_gid_marching_dj(BarracksAcc, GId, -DNum, -INum),
                            Occupy = max(barracks:get_occupy(NBarracksAcc1) - DNum - INum, 0),
                            NBarracksAcc = barracks:set_occupy(NBarracksAcc1, Occupy),
                            {ok, {B, NBarracksAcc, garray:get_garray_soldiers(Garray) + Num}}
                    end;
                false ->
                    {ok, {false, BarracksAcc, Num}}
            end
        end, {true, Barracks, 0}, lists:zip(GarrayIds, T)),
        if
            Bool ->
                case barracks:get_occupy(NBarracks) =:= AllNum of
                    true ->
                        throw("ok");
                    false ->
                        NewBarracks = barracks:set_occupy(NBarracks, AllNum),
                        {ok, {Barracks, NewBarracks, T}, [{Index1, NewBarracks}]}
                end;
            true ->
                {ok, ok, [{Index1, NBarracks}]}
        end
    end,
    case z_db_lib:handle(TableName, Fun1, {}, TableKeys) of
        {Ob, Nb, Garrays} ->
            zm_log:warn(?MODULE, ?MODULE, 'deal_barracks_occupy', "barracks_error", [{role_uid, RoleUid},
                {'old_barracks', Ob},
                {'new_barracks', Nb},
                {'garrays', [Gview || {_, Gview} <- Garrays, Gview =/= GInit]}]);
        _ ->
            ok
    end.

%% ----------------------------------------------------
%% @doc
%%     辅助战斗信息新增
%% @end
%% ----------------------------------------------------
add_fight_assist(Src, EndPointUid, Marching) ->
    add_fight_assist(Src, EndPointUid, Marching, false).

add_fight_assist(Src, EndPointUid, Marching, CheckBool) ->
    STime = marching:get_stime(Marching),
    ETime = marching:get_etime(Marching),
    if
        CheckBool orelse (ETime - STime > 10) ->%10s内的线就不使用辅助了
            Table = game_lib:get_table(Src, 'point_march_tmp'),
            z_db_lib:update(Table, {marching:get_etime(Marching) + ?FAILOVER_TIME, EndPointUid}, 0);
        true ->
            ok
    end.

%% ----------------------------------------------------
%% @doc
%%     到达的行军信息去掉
%% @end
%% ----------------------------------------------------
update_fight_assist(Src, EndPointUid, ArrMarches, AddGoBacks) ->
    Table = game_lib:get_table(Src, 'point_march_tmp'),
    lists:foreach(fun(Marching) ->
        z_db_lib:delete(Table, {marching:get_etime(Marching) + ?FAILOVER_TIME, EndPointUid})
    end, ArrMarches),
    lists:foreach(fun(Marching) ->
        add_fight_assist(Src, EndPointUid, Marching, true)
    end, AddGoBacks).


%% ----------------------------------------------------
%% @doc
%%     返程奖励日志
%% @end
%% ----------------------------------------------------
add_goback_award_log(Src, Marching) ->
    MRUid = marching:get_roleuid_gid(Marching),
    z_db_lib:update(game_lib:get_table(Src, 'fight_award_log'), MRUid, Marching).

%% ----------------------------------------------------
%% @doc
%%    删除返程日志
%% @end
%% ----------------------------------------------------
del_goback_award_log(Src, Marching) ->
    MRUid = marching:get_roleuid_gid(Marching),
    z_db_lib:delete(game_lib:get_table(Src, 'fight_award_log'), MRUid).

%% ----------------------------------------------------
%% @doc
%%    处理返程日志奖励
%% @end
%% ----------------------------------------------------
award_goback_award_log(Src) ->
    Table = game_lib:get_table(Src, 'fight_award_log'),
    Fun = fun(_, Key, _, R) ->
        case z_db_lib:delete1(Table, Key) of
            'ok' ->
                {'ok', R};
            Marching ->
                Award = marching:get_award(Marching),
                if
                    is_tuple(Award) ->
                        awarder_game:give_award(Award);
                    true ->
                        awarder_game:give_award(Src, marching:get_roleuid(Marching), ?MODULE, lists:keydelete('feats', 1, Award))
                end,
                {'ok', R}
        end
    end,
    z_db_lib:table_iterate(Src, Table, Fun, [], []).


%% ----------------------------------------------------
%% @doc
%%     行军消耗
%% @end
%% ----------------------------------------------------
marching_consume(Src, MapId, EndPInfo, MarchRole, Restore, ConsumePer) ->
    {_, {GameConsume, CrossConsume}} = zm_config:get('fight_info', 'march_consume'),
    if
        MapId > 0 ->
            marching_consume_(Src, CrossConsume, EndPInfo, MarchRole, Restore, [], ConsumePer);
        true ->
            marching_consume_(Src, GameConsume, EndPInfo, MarchRole, Restore, [], ConsumePer)
    end.
marching_consume_(_Src, [], _EndPInfo, MarchRole, Restore, Cs, _ConsumePer) ->
    {ok, Cs, {MarchRole, Restore}};
marching_consume_(Src, [{pvp, Pvp} | T], EndPInfo, MarchRole, Restore, Cs, ConsumePer) ->
    NeedPvp = get_consume_pvp(EndPInfo, Pvp),
    HavePvp = restore_lib:get_value(Restore, 'pvp'),
    if
        HavePvp >= NeedPvp ->
            NRestore = restore_lib:update(Restore, time_lib:now_second(), restore_lib:get_max(Src, MarchRole, 'pvp'), 'pvp', -NeedPvp),
            BiCs = [{'pvp', NeedPvp, restore_lib:get_value(NRestore, 'pvp')} | Cs],
            marching_consume_(Src, T, EndPInfo, MarchRole, NRestore, BiCs, ConsumePer);
        true ->
            "pvp_not_enough"
    end;
marching_consume_(Src, [{cb_forage, Cf} | T], EndPInfo, MarchRole, Restore, Cs, ConsumePer) -> %CF为每百兵消耗
    NeedCf = game_lib:ceil(Cf * ConsumePer / 100),
    case role_lib:deduct_cb_forage(MarchRole, NeedCf) of
        {BiCs, NRole} ->
            marching_consume_(Src, T, EndPInfo, NRole, Restore, BiCs ++ Cs, ConsumePer);
        Err ->
            Err
    end.
get_consume_pvp(EndPInfo, Pvp) ->
    case EndPInfo of
        {?BOSS, MUid} ->
            MonCfg = monster_detail:get_cfg(monster_db:muid_2_msid(MUid)),
            monster_detail:get_cpvp(MonCfg);
        {?MONSTER, MUid} ->
            MonCfg = monster_detail:get_cfg(monster_db:muid_2_msid(MUid)),
            case monster_detail:is_elite(MonCfg) of
                true ->
                    monster_detail:get_cpvp(MonCfg);
                false ->
                    Pvp
            end;
        _ ->
            Pvp
    end.

%% ----------------------------------------------------
%% @doc
%%     合并
%% @end
%% ----------------------------------------------------
merage_tuple_list(List1, []) ->
    List1;
merage_tuple_list(List1, [H | T]) ->
    NList1 = merage_tuple_list(List1, H),
    merage_tuple_list(NList1, T);
merage_tuple_list(List, {Type, Value}) ->
    case lists:keyfind(Type, 1, List) of
        false ->
            [{Type, Value} | List];
        {_, V} ->
            lists:keystore(Type, 1, List, {Type, Value ++ V})
    end.