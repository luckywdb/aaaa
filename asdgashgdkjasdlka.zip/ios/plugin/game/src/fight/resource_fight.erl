-module(resource_fight).

%%%=======================STATEMENT====================
-description("资源点战斗").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    fighting/5,
    collect_achieve/4,
    get_collect_value/3,
    refresh_occ_marching/2
]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").
-include("../include/report.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        
%% @end
%% ----------------------------------------------------
-spec fighting(Src, Now, EndPoint, {?RESOURCE, RSid}, {ArrMarch, Occ}) -> {[marching:marching()], list()} when
    Src :: atom(),
    Now :: integer(),
    EndPoint :: integer(),
    RSid :: integer(),
    ArrMarch :: [marching:marching()],
    Occ :: [marching:marching()].
fighting(Src, Now, EndPoint, {?RESOURCE, ResourceSid}, {ArrMarch, Occ}) ->
    {NOcc, AddBackMarchings} = do_fighting(Src, Now, EndPoint, ResourceSid, ArrMarch, Occ, []),
    {NOcc, AddBackMarchings}.

%% ----------------------------------------------------
%% @doc
%%     资源累积任务
%% @end
%% ----------------------------------------------------
-spec collect_achieve(Src, RoleUid, ResType, AwardList) -> 'ok' when
    Src :: atom(),
    RoleUid :: integer(),
    ResType :: atom(),%%资源类型
    AwardList :: [{atom(), integer()}].
collect_achieve(Src, RoleUid, ResType, AwardList) ->
    Number = z_lib:get_value(AwardList, ResType, 0),
    if
        Number > 0 ->
            task_event:notify(Src, RoleUid, [{'collect_number', Number}]),
            zm_event:notify(Src, achieve, {RoleUid, {argu, [{'collect_number', Number}, {{'collect_number', ResType}, Number}]}});
        true ->
            ok
    end.

%%%===================LOCAL FUNCTIONS==================
do_fighting(_Src, _Now, _EndPoint, _ResourceSid, [], Occ, BackMarchs) ->
    {Occ, BackMarchs};
do_fighting(Src, Now, EndPoint, ResourceSid, [Marching | Marchings], Occ, BackMarchs) ->
    MarchingState = marching:get_state(Marching),
    {MarchRoleUid, MarchGId} = marching:get_roleuid_gid(Marching),
    if
        MarchingState =:= ?ON_THE_COLLECTION ->%资源点有玩家采集中
            ETime = marching:get_etime(Marching),
            if
                ETime =< Now ->
                    Value = get_collect_value(Marching, ResourceSid, ETime),
                    ResourceDetail = resource_detail:get_cfg(ResourceSid),
                    RType = resource_detail:get_type(ResourceDetail),
                    OldAward = marching:get_award(Marching),
                    AwardList = if
                        Value > 0 ->
                            [{RType, Value} | OldAward];
                        true ->
                            OldAward
                    end,
                    BMarching2 = marching:init(MarchRoleUid, MarchGId, marching:get_s_point(Marching), EndPoint,
                        marching:get_speed(Marching), marching:get_sptype(Marching), marching:get_epstate(Marching)),
                    BMarching1 = marching:set_stime(marching:set_etime(BMarching2, ETime + marching:get_etime(BMarching2) - marching:get_stime(BMarching2)), ETime),
                    BackMarching = marching:fight_result(BMarching1, marching:get_injured(Marching), marching:get_dead(Marching), AwardList),
                    NAddGoBack = marching:set_state(marching:set_extra(BackMarching, marching:get_extra(Marching)), ?ON_THE_COLLECTION_GOBACK),
                    do_fighting(Src, Now, EndPoint, ResourceSid, Marchings, [], [NAddGoBack | BackMarchs]);
                true ->
                    do_fighting(Src, Now, EndPoint, ResourceSid, Marchings, Occ, BackMarchs)
            end;
        true ->%资源点没有被采集
            ETime = marching:get_etime(Marching),
            case Occ of
                [] ->%资源点怪物 -- 取消了资源点怪物
                    ResourceDetail = resource_detail:get_cfg(ResourceSid),
                    case resource_detail:get_npc_array(ResourceDetail) of
                        [] ->
                            {NOccMarching, _} = refresh_occ_marching(ResourceSid, marching:set_state(marching:set_stime(Marching, ETime), ?ON_THE_COLLECTION)),
                            task_event:notify(Src, MarchRoleUid, [{'fight_times', ?RESOURCE, ResourceSid}, {'fight_win_times', ?RESOURCE, ResourceSid}]),
                            zm_event:notify(Src, achieve, {MarchRoleUid, {argu, [{fight_times, ?RESOURCE, ResourceSid, 1}]}}),
                            NMarchings = lists:keysort(marching:get_etime_index(), [NOccMarching | Marchings]),
                            do_fighting(Src, Now, EndPoint, ResourceSid, NMarchings, [NOccMarching], BackMarchs);
                        MNpcArray ->
                            MarchFightRole = fighter:init_role(Src, MarchRoleUid, MarchGId, 0, garray_db:get_garray(Src, MarchRoleUid, MarchGId)),
                            FightType = match_lib:get_fight_type(?MODULE),
                            Sid = fighting:get_fight_scene('resource'),
                            FightArgs = [
                                {'auto', 1},
                                {'time', ETime},
                                {'fight_type', FightType},
                                {'duplicate_sid', Sid},
                                {'seed', game_lib:get_seed()},
                                {'fight_role', MarchFightRole},
                                {'role_uid', MarchRoleUid},
                                {'point_int', EndPoint}],

                            FightNpc = fighter:init_npc(MNpcArray),
                            NFightArgs = [{'ma', {'fighting', []}}, {'fight_enemy', FightNpc}, {'resource_sid', ResourceSid} | FightArgs],
                            case match:auto_result(Src, MarchRoleUid, NFightArgs) of
                                {Winner, Result} ->
                                    Dead = result:get_dead(Result),
                                    Injured = result:get_injured(Result),
                                    RoleChange = result:get_queue(Result),
                                    AllCardExp = result:get_allexp(Result),
                                    WaveInfos = result:get_waves(Result),
                                    {SoldierBearLoad, MarchiQueue, GarrayInjured, _, _DeductSosldierNum} =
                                        fighting:update_garray_after_fight(Src, RoleChange, {MarchRoleUid, MarchGId}),
                                    OneCardExp = garray_db:award_card_allexp(Src, MarchRoleUid, MarchGId, AllCardExp, Sid),%武将加经验
                                    NMarchingExtra = marching:set_extra_soldier_bearload(marching:get_extra(Marching), SoldierBearLoad),
                                    set_front_lib:send_map_result(Src, MarchRoleUid,
                                        {ETime, EndPoint, ?RESOURCE, ?MONSTER, Winner, MarchGId, {MarchiQueue, Dead, Injured, GarrayInjured}, OneCardExp}),
                                    {NMarchings, NewOcc1, NBackMarchs} = if
                                        Winner =:= 0 ->
                                            NOcc1 = marching:fight_result(marching:set_state(marching:set_stime(marching:set_extra(Marching, NMarchingExtra), ETime), ?ON_THE_COLLECTION), Injured, Dead, []),
                                            {NOccMarching, _} = refresh_occ_marching(ResourceSid, NOcc1),
                                            task_event:notify(Src, MarchRoleUid, [{'fight_times', ?RESOURCE, ResourceSid}, {'fight_win_times', ?RESOURCE, ResourceSid}]),
                                            zm_event:notify(Src, achieve, {MarchRoleUid, {argu, [{fight_times, ?RESOURCE, ResourceSid, 1}]}}),
                                            {lists:keysort(marching:get_etime_index(), [NOccMarching | Marchings]), [NOccMarching], BackMarchs};
                                        true ->
                                            BackMarching = marching:fight_result(marching:change_goback(marching:set_extra(Marching, NMarchingExtra), EndPoint), Injured, Dead, []),
                                            task_event:notify(Src, MarchRoleUid, [{'fight', ?RESOURCE, ResourceSid}]),
                                            zm_event:notify(Src, achieve, {MarchRoleUid, {argu, [{fight_times, ?RESOURCE, ResourceSid, 0}]}}),
                                            {Marchings, Occ, [BackMarching | BackMarchs]}
                                    end,
                                    zm_event:notify(Src, 'fight_monster_report', [
                                        {'winner', Winner},
                                        {'time', ETime},
                                        {'sid', ResourceSid},
                                        {'award_list', {[], [{'card_exp', OneCardExp}]}},
                                        {'wave_infos', WaveInfos},
                                        {'report_type', ?REPORT_FIGHT_RESOURCE_MONSTER} | NFightArgs]),
                                    do_fighting(Src, Now, EndPoint, ResourceSid, NMarchings, NewOcc1, NBackMarchs);
                                WebErr ->
                                    %错误直接goback,返回
                                    zm_log:warn(?MODULE, ?MODULE, 'fighting', "web_error", [{'error', WebErr}, {'point_uid', EndPoint}, {'marching', Marching}]),
                                    BackMarching = marching:change_goback(Marching, EndPoint),
                                    do_fighting(Src, Now, EndPoint, ResourceSid, Marchings, Occ, [BackMarching | BackMarchs])
                            end
                    end;
                [OccMarching | RestOccList] ->
                    {ORoleUid, OGid} = marching:get_roleuid_gid(OccMarching),
                    if
                        MarchRoleUid =:= ORoleUid ->
                            BackMarching = marching:change_goback(Marching, EndPoint),
                            do_fighting(Src, Now, EndPoint, ResourceSid, Marchings, Occ, [BackMarching | BackMarchs]);
                        true ->
                            MarchCorpUid = role_show:get_corps_uid(role_db:get_role_show(Src, MarchRoleUid)),
                            OCorpUid = role_show:get_corps_uid(role_db:get_role_show(Src, ORoleUid)),
                            MarchCorpUid = role_show:get_corps_uid(role_db:get_role_show(Src, MarchRoleUid)),
                            IsAlly = corps_db:is_ally(Src, MarchCorpUid, OCorpUid),
                            if
                                MarchCorpUid > 0 andalso MarchCorpUid =:= OCorpUid ->
                                    zm_event:notify(Src, 'fight_null_report', [
                                        {'role_uid', MarchRoleUid},
                                        {'point_int', EndPoint},
                                        {'time', ETime},
                                        {'r_type', ?REPORT_NULL_SAME_CORPS},
                                        {'id', ORoleUid}]),
                                    BackMarching = marching:change_goback(Marching, EndPoint),
                                    do_fighting(Src, Now, EndPoint, ResourceSid, Marchings, Occ, [BackMarching | BackMarchs]);
                                IsAlly ->
                                    zm_event:notify(Src, 'fight_null_report', [
                                        {'role_uid', MarchRoleUid},
                                        {'point_int', EndPoint},
                                        {'time', ETime},
                                        {'r_type', ?REPORT_NULL_ALLY_CORPS},
                                        {'id', ORoleUid}]),
                                    BackMarching = marching:change_goback(Marching, EndPoint),
                                    do_fighting(Src, Now, EndPoint, ResourceSid, Marchings, Occ, [BackMarching | BackMarchs]);
                                true ->
                                    MarchFightRole = fighter:init_role(Src, MarchRoleUid, MarchGId, 0, garray_db:get_garray(Src, MarchRoleUid, MarchGId)),
                                    FightType = match_lib:get_fight_type(?MODULE),
                                    Sid = fighting:get_fight_scene('resource'),
                                    FightArgs = [
                                        {'auto', 1},
                                        {'time', ETime},
                                        {'fight_type', FightType},
                                        {'duplicate_sid', Sid},
                                        {'seed', game_lib:get_seed()},
                                        {'fight_role', MarchFightRole},
                                        {'role_uid', MarchRoleUid},
                                        {'point_int', EndPoint}],

                                    OFighterRole = fighter:init_role(Src, ORoleUid, OGid, 1, garray_db:get_garray(Src, ORoleUid, OGid)),
                                    NFightArgs = [{'ma', {'fighting', []}},
                                        {'fight_enemy', [OFighterRole]},
                                        {'ruid', ORoleUid},
                                        {'sid', ResourceSid} | FightArgs],
                                    case match:auto_result(Src, MarchRoleUid, NFightArgs) of %攻打玩家不会获得武将经验
                                        {Winner, Result} ->%返回 result/6的结果,表示web一切正常
                                            Dead = result:get_dead(Result),
                                            Injured = result:get_injured(Result),
                                            RoleChange = result:get_queue(Result),
                                            RoleAddFeats1 = result:get_role_feats(Result),
                                            [EnemyAddFeats1] = result:get_enemy_feats_list(Result),
                                            RoleAddFeats = role_db:award_feats(Src, MarchRoleUid, RoleAddFeats1),
                                            EnemyAddFeats = role_db:award_feats(Src, ORoleUid, EnemyAddFeats1),
                                            Feats = [{MarchRoleUid, RoleAddFeats}, {ORoleUid, EnemyAddFeats}],
                                            WaveInfos = result:get_waves(Result),
                                            [{_, {ODead, OInjured, TargetChange}} | _] = WaveInfos,
                                            {SoldierBearLoad, MarchQueue, GarrayInjured, _, _} =
                                                fighting:update_garray_after_fight(Src, RoleChange, {MarchRoleUid, MarchGId}),
                                            {OSoldierBearLoad, OQueue, OGarrayInjured, _, _} =
                                                fighting:update_garray_after_fight(Src, TargetChange, {ORoleUid, OGid}),
                                            OccMarchingExtra = marching:get_extra(OccMarching),
                                            NOccMarchingExtra = marching:set_extra_soldier_bearload(OccMarchingExtra, OSoldierBearLoad),
                                            {NOccMarching, NETime} = refresh_occ_marching(ResourceSid, marching:set_extra(OccMarching, NOccMarchingExtra)),
                                            set_front_lib:send_map_result(Src, MarchRoleUid,
                                                {ETime, EndPoint, ?RESOURCE, ?ROLE, Winner, MarchGId, {MarchQueue, Dead, Injured, GarrayInjured}, 0}),
                                            set_front_lib:send_map_result(Src, ORoleUid,
                                                {ETime, EndPoint, ?RESOURCE, ?ROLE, Winner, OGid, {OQueue, ODead, OInjured, OGarrayInjured}, 1}),
                                            OccFeatsAward = if
                                                EnemyAddFeats > 0 ->
                                                    [{'feats', EnemyAddFeats}];
                                                true ->
                                                    []
                                            end,
                                            MarchingFeatsAward = if
                                                RoleAddFeats > 0 ->
                                                    [{'feats', RoleAddFeats}];
                                                true ->
                                                    []
                                            end,
                                            zm_event:notify(Src, 'bi_fight_attack_role', [{'role_uid', MarchRoleUid}, {'be_role_uid', ORoleUid}, {'type', ?RESOURCE}, {'dead', Dead},
                                                {'injured', Injured}, {'be_dead', result:get_enemy_total_dead(Result)}, {'be_injured', result:get_enemy_total_injure(Result)},
                                                {'award_list', []}, {'win', Winner}]),
                                            if
                                                Winner =:= 0 ->%进攻方玩家胜利
                                                    BMarching = marching:change_goback(marching:set_etime(NOccMarching, ETime), EndPoint),
                                                    OccBackMarching = marching:fight_result(BMarching, OInjured, ODead, OccFeatsAward),%失败方,只有功勋奖励,且不修改状态为采集回城
                                                    MarchingExtra = marching:get_extra(Marching),
                                                    Value = get_collect_value(OccMarching, ResourceSid, ETime),%使用Occ计算当前采集量
                                                    NMarchingExtra = marching:set_extra_soldier_bearload(marching:set_extra_collext_plunder(MarchingExtra, Value), SoldierBearLoad),
                                                    MarchingToOcc1 = marching:set_extra(marching:set_state(marching:set_stime(Marching, ETime), ?ON_THE_COLLECTION), NMarchingExtra),
                                                    {MarchingToOcc2, NewEndTime} = refresh_occ_marching(ResourceSid, MarchingToOcc1),
                                                    {NewAwardList, NAwardList} = if
                                                        Value > 0 ->
                                                            ResourceDetail = resource_detail:get_cfg(ResourceSid),
                                                            RType = resource_detail:get_type(ResourceDetail),
                                                            {[{RType, Value} | MarchingFeatsAward], [{RType, Value}]};
                                                        true ->
                                                            {MarchingFeatsAward, []}
                                                    end,
                                                    MarchingToOcc = marching:fight_result(MarchingToOcc2, Injured, Dead, MarchingFeatsAward),
                                                    zm_event:notify(Src, 'fight_role_resource_report', [
                                                        {'winner', Winner},
                                                        {'award_list', NAwardList},
                                                        {'wave_infos', WaveInfos},
                                                        {'feats', Feats} | NFightArgs]),
                                                    task_event:notify(Src, MarchRoleUid, [{'fight_times', ?RESOURCE, ResourceSid}, {'fight_win_times', ?RESOURCE, ResourceSid}]),
                                                    zm_event:notify(Src, achieve, {MarchRoleUid, {argu, [{fight_times, ?RESOURCE, ResourceSid, 1}, {'collect_plunder_times', 1}]}}),
                                                    if
                                                        NewEndTime =< ETime ->%掠夺方,攻击胜利后直接达到负重,返回城堡
                                                            NAddGoBack = marching:set_award(marching:set_state(marching:change_goback_byetime(MarchingToOcc, EndPoint, ETime), ?ON_THE_COLLECTION_GOBACK), NewAwardList),
                                                            NMarchings = lists:keydelete({ORoleUid, OGid}, marching:get_roleuid_gid_index(), Marchings),
                                                            do_fighting(Src, Now, EndPoint, ResourceSid, NMarchings, RestOccList, [OccBackMarching, NAddGoBack | BackMarchs]);
                                                        true ->
                                                            NMarchings = lists:keysort(marching:get_etime_index(), [MarchingToOcc | lists:keydelete({ORoleUid, OGid}, marching:get_roleuid_gid_index(), Marchings)]),
                                                            do_fighting(Src, Now, EndPoint, ResourceSid, NMarchings, [MarchingToOcc | RestOccList], [OccBackMarching | BackMarchs])
                                                    end;
                                                true ->
                                                    zm_event:notify(Src, 'fight_role_resource_report', [
                                                        {'winner', Winner},
                                                        {'award_list', []},
                                                        {'wave_infos', WaveInfos},
                                                        {'feats', Feats} | NFightArgs]),
                                                    task_event:notify(Src, MarchRoleUid, [{'fight_times', ?RESOURCE, ResourceSid}]),
                                                    zm_event:notify(Src, achieve, {MarchRoleUid, {argu, [{fight_times, ?RESOURCE, ResourceSid, 0}]}}),
                                                    BackMarching = marching:fight_result(marching:change_goback(Marching, EndPoint), Injured, Dead, MarchingFeatsAward),%进攻方失败,直接回城,不发送采集战报
                                                    case NETime =< ETime of %被攻击方,胜利,但是达到负重,回城,发送采集战报
                                                        true ->
                                                            Value = get_collect_value(OccMarching, ResourceSid, ETime),%使用Occ计算当前采集量
                                                            AwardList = if
                                                                Value > 0 ->
                                                                    ResourceDetail = resource_detail:get_cfg(ResourceSid),
                                                                    RType = resource_detail:get_type(ResourceDetail),
                                                                    OccFeatsAward ++ [{RType, Value}];
                                                                true -> OccFeatsAward
                                                            end,
                                                            OccBackMarching = marching:change_goback(marching:set_etime(NOccMarching, ETime), EndPoint),
                                                            NMarchings = lists:keydelete({ORoleUid, OGid}, marching:get_roleuid_gid_index(), Marchings),
                                                            NAddGoBack = marching:set_state(marching:fight_result(OccBackMarching, OInjured, ODead, AwardList), ?ON_THE_COLLECTION_GOBACK),
                                                            do_fighting(Src, Now, EndPoint, ResourceSid, NMarchings, [], [NAddGoBack, BackMarching | BackMarchs]);
                                                        false ->
                                                            NNOccMarching = marching:fight_result(NOccMarching, OInjured, ODead, OccFeatsAward),
                                                            NMarchings = lists:keysort(marching:get_etime_index(), lists:keyreplace({ORoleUid, OGid}, marching:get_roleuid_gid_index(), Marchings, NNOccMarching)),
                                                            do_fighting(Src, Now, EndPoint, ResourceSid, NMarchings, [NNOccMarching | RestOccList], [BackMarching | BackMarchs])
                                                    end
                                            end;
                                        WebErr ->
                                            zm_log:warn(?MODULE, ?MODULE, 'fighting', "web_error", [{'error', WebErr}, {'point_uid', EndPoint}, {'marching', Marching}]),
                                            BackMarching = marching:change_goback(Marching, EndPoint),
                                            do_fighting(Src, Now, EndPoint, ResourceSid, Marchings, Occ, [BackMarching | BackMarchs])
                                    end
                            end
                    end
            end
    end.


%% ----------------------------------------------------
%% @doc  
%%      刷新计算正在采集的行军信息
%% @end
%% ----------------------------------------------------
-spec refresh_occ_marching(integer(), marching:marching()) -> {marching:marching(), integer()}.
refresh_occ_marching(ResourceSid, Marching) ->
    MarchingExtra = marching:get_extra(Marching),
    BearLoad = marching:get_extra_bearload(MarchingExtra),
    CollectSpeedAdd = marching:get_extra_collect_speed_add(MarchingExtra),
    PlunderV = marching:get_extra_collect_plunder(MarchingExtra),
    BeginTime = marching:get_stime(Marching),
    ResourceDetail = resource_detail:get_cfg(ResourceSid),
    BaseSpeed = resource_detail:get_speed(ResourceDetail),
    T = resource_detail:get_time(ResourceDetail),
    Speed = BaseSpeed * (10000 + CollectSpeedAdd) div 10000,
    EndTime = game_lib:ceil((BearLoad - PlunderV) / Speed * T) + BeginTime,
    {marching:set_etime(Marching, EndTime), EndTime}.

%% ----------------------------------------------------
%% @doc
%%      获取当前采集量
%% @end
%% ----------------------------------------------------
-spec get_collect_value(marching:marching(), integer(), integer()) -> integer().
get_collect_value(Marching, ResourceSid, EndTimeTmp) ->
    EndTime = min(EndTimeTmp, marching:get_etime(Marching)),
    MarchingExtra = marching:get_extra(Marching),
    CollectSpeedAdd = marching:get_extra_collect_speed_add(MarchingExtra),
    PlunderV = marching:get_extra_collect_plunder(MarchingExtra),
    BearLoad = marching:get_extra_bearload(MarchingExtra),
    BeginTime = marching:get_stime(Marching),
    ResourceDetail = resource_detail:get_cfg(ResourceSid),
    BaseSpeed = resource_detail:get_speed(ResourceDetail),
    T = resource_detail:get_time(ResourceDetail),
    Speed = BaseSpeed * (10000 + CollectSpeedAdd) div 10000,
    erlang:min(erlang:trunc((EndTime - BeginTime) / T * Speed), BearLoad - PlunderV) + PlunderV.
