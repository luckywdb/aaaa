-module(town_fight).

%%%=======================STATEMENT====================
-description("攻城战").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    check_refresh/2,
    check_over/4,
    fighting/6,
    get_npc_len/2,
    over/5,
    chk_over_goback/6,
    get_fight_npc/4,
    fighting_chk_over/2,
    do_over/7,
    clear_corps_fighting/4,
    get_weapon_lv/2,
    get_cycle_num/2,
    get_cycle_hp_add/2
]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").
-include("../include/report.hrl").
-include("../include/corps.hrl").
%%%=======================DEFINE======================
-define(DAY_AND_NIGHT, 5).
%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      前台通知刷新npc,检测是否需要刷新
%% @end
%% ----------------------------------------------------
-spec check_refresh(Src :: atom(), TownSid :: integer()) -> 'ok'.
check_refresh(Src, TownSid) ->
    Now = time_lib:now_second(),
    {_, Time} = zm_config:get('fight_info', 'town_npc_refresh'),
    Town = z_db_lib:get(game_lib:get_table(Src, 'town'), TownSid, town:init(TownSid)),
    case town:get_points_owner(Town) of
        [] ->
            'ok';
        POwners ->
            RefreshTimes = town:get_npc_refresh_time(Town),
            F = fun(Args, {Uid, _}) ->
                LastRTime = z_lib:get_value(RefreshTimes, Uid, 0),
                if
                    Now - LastRTime + ?FAILOVER_TIME > Time ->
                        {'ok', [Uid | Args]};
                    true ->
                        {'ok', Args}
                end
            end,
            FUids = z_lib:foreach(F, [], POwners),
            if
                FUids =:= [] ->
                    'ok';
                true ->
                    zm_event:notify(Src, 'around_fight', [{'pm_uids', FUids}])
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      判断是否战斗倒计时结束(刷新npc,前台直接发送所有点到达)
%%      新增城池城墙血量是否为0的判断,为0之后才走以往流程
%% @end
%% ----------------------------------------------------
-spec check_over(Src :: atom(), TownSid :: integer(), EndPoint :: integer(), MRoleUids :: [integer()]) -> 'ok'|{integer(), town:town()}.
check_over(Src, TownSid, EndPoint, MRoleUids) ->
    Now = time_lib:now_second(),
    TownDetail = town_detail:get_cfg(TownSid),
    TownTmp = z_db_lib:get(game_lib:get_table(Src, 'town'), TownSid, town:init(TownDetail)),
    FightLv = town:get_fight_lv(TownTmp),
    FightBool = town:chk_fight(TownTmp),
    if
        FightBool orelse FightLv > 0 ->%战斗中
            DelWallHp = town:get_del_wall_hp(TownTmp),
            TownLv = if
                FightLv > 0 ->
                    FightLv;
                true ->
                    town:get_lv(TownTmp, TownDetail)
            end,
            WallHpAdd = town:get_wall_hp_add(TownTmp),
            WallHp = town_detail:get_wall_hp(Src, TownLv, WallHpAdd, TownDetail),
            {TState1, _STime1, ETime1} = town:get_state(TownTmp),
            LastTime1 = town:get_over_time(TownTmp),
            ReplyTime =
                if
                    ETime1 > 0 andalso FightBool ->
                        min(ETime1, Now);%如果停服很久,传出去当前时间直接用战斗结束时间
                    true ->
                        Now
                end,
            if
                ((TState1 =:= ?STATE_FIGHT orelse TState1 =:= ?STATE_FIGHT_WALL) andalso Now + ?FAILOVER_TIME >= ETime1) %战斗时间结束
                    orelse (Now > LastTime1 andalso (TState1 =:= ?STATE_FIGHT_AHEAD_OVER
                    orelse TState1 =:= ?STATE_FIGHT_OVER
                    orelse TState1 =:= ?STATE_FIGHT_OVER_FIGHTING)) -> %结算超时
                    UpFun = fun(_, Town) ->
                        {TState, STime, ETime} = town:get_state(Town),
                        LastTime = town:get_over_time(Town),
                        if
                            ((TState =:= ?STATE_FIGHT orelse TState =:= ?STATE_FIGHT_WALL) andalso Now + ?FAILOVER_TIME >= ETime)
                                orelse (Now > LastTime andalso (TState =:= ?STATE_FIGHT_OVER orelse TState =:= ?STATE_FIGHT_OVER_FIGHTING)) ->%战斗到结束;或结束超时
                                Town1 = town:set_over_time(town:set_state(Town, {?STATE_FIGHT_OVER, STime, ETime}), Now + ?PMARCH_FIGHT_TIMEOUT),
                                {'ok', {0, ETime, Town1, false}, Town1};
                            TState =:= ?STATE_FIGHT_AHEAD_OVER andalso Now > LastTime ->%战斗提前结算,结算超时
                                Town1 = town:set_over_time(Town, Now + ?PMARCH_FIGHT_TIMEOUT),
                                {'ok', {0, ETime, Town1, true}, Town1};
                            true ->%战斗/冷却/等有行军,行军返回等信息,结束中,提前结束中
                                {'ok', {1, Town}}
                        end
                    end,
                    case z_db_lib:update(game_lib:get_table(Src, 'town'), TownSid, town:init(TownDetail), UpFun, []) of
                        {0, TTime, Town1, Ahead} ->
                            over(Src, TownSid, TTime, Town1, Ahead),
                            'ok';
                        {1, NewTown} ->
                            log_lib:log_gm(?MODULE, 'ahead_over_timeout', [{line, ?LINE}, {'town_sid', TownSid}, {time, time_lib:now_second()}, {town, NewTown}]),
                            {ReplyTime, NewTown};
                        _ ->%结束中,提前结束中
                            'ok'
                    end;
                (WallHp > DelWallHp andalso TState1 =:= ?STATE_FIGHT_WALL andalso (LastTime1 =< 0 orelse Now >= LastTime1)) %城墙战斗中
                    orelse (TState1 =:= ?STATE_PROTECT orelse TState1 =:= ?STATE_NOR) andalso Now + ?FAILOVER_TIME >= ETime1 ->%在城池结束前发起的行军,在结束后到达;如果失败后,冷却保护时间比较短,则到达直接进入战斗,或者处理寻访信息
                    UpFun = fun(_, Town) ->
                        {TState, _STime, ETime} = town:get_state(Town),
                        LastTime = town:get_over_time(Town),
                        NDHp = town:get_del_wall_hp(Town),
                        if
                            ((TState =:= ?STATE_PROTECT orelse TState =:= ?STATE_NOR) andalso Now + ?FAILOVER_TIME >= ETime) %在城池结束前发起的行军,在结束后到达;如果失败后,冷却保护时间比较短,则到达直接进入战斗,或者处理寻访信息
                                orelse (WallHp > NDHp andalso TState =:= ?STATE_FIGHT_WALL andalso Now + ?FAILOVER_TIME > LastTime) ->%城墙扣血;或扣血超时
                                Town1 = town:set_over_time(Town, Now + ?PMARCH_FIGHT_TIMEOUT),%计算中,则=1;计算结束了修改为-1
                                {'ok', Town1, Town1};
                            true ->%血已扣完 或寻访信息
                                {'ok', {'ok', Town}}
                        end
                    end,
                    case z_db_lib:update(game_lib:get_table(Src, 'town'), TownSid, town:init(TownDetail), UpFun, []) of
                        {'ok', NewTown} ->
                            {ReplyTime, NewTown};
                        Town2 ->
                            del_wall_hp(Src, ReplyTime, TownSid, EndPoint, TownDetail, MRoleUids, true, get_town_corps_builds(Src, TownSid, Town2))
                    end;
                TState1 =:= ?STATE_FIGHT_WALL -> %城墙战斗中,不能在返回战斗信息数据,城墙战斗中会继续抛出战斗信息
                    'ok';
                TState1 =:= ?STATE_FIGHT_OVER_FIGHTING ->%结束战斗,全部点跑战斗中
                    'ok';
                TState1 =:= ?STATE_FIGHT_OVER ->%结束中
                    'ok';
                TState1 =:= ?STATE_FIGHT_AHEAD_OVER ->%提前结束中
                    'ok';
                true ->%战斗/冷却/等有行军,行军返回等信息
                    {ReplyTime, TownTmp}
            end;
        true ->%未战斗,寻访等处理
%%            del_wall_hp(Src, Now, TownSid, EndPoint, TownDetail, MRoleUids, true)
            {TState1, _STime1, ETime1} = town:get_state(TownTmp),
            if
                TState1 =:= ?STATE_PROTECT andalso Now + ?FAILOVER_TIME < ETime1 ->
                    {Now, TownTmp};
                true ->
                    %TODO 多个点同时未开战,然后到达的,可能出现point_search_db中format_townhp时候fightlv=0的情况.
                    del_wall_hp(Src, Now, TownSid, EndPoint, TownDetail, MRoleUids, true, get_town_corps_builds(Src, TownSid, TownTmp))
            end
    end.


%% ----------------------------------------------------
%% @doc
%%     城池战斗 返回 {AddGoBack, NewOcc, UpPointNpcState, UpPointOwner, NpcRefreshTime,AddFightCUids}
%% @end
%% ----------------------------------------------------
fighting(Src, Now, EndPoint, {?TOWN, TownSid}, {IsChief, Town, ArrMarchies, Occupy}, MRoleUids) ->
    {Tstate, Stime, _Etime} = town:get_state(Town),
    {LookArrs, FightArrs} = lists:partition(fun(M) -> marching:get_state(M) =:= ?ON_THE_LOOK_MARCHING end, ArrMarchies),
    {LookOcc, FightOcc} = lists:partition(fun(M) -> MState = marching:get_state(M),
        look_fight:looking_state(MState) end, Occupy),
    TCountry = town:get_country(Town),
    TCorpsUid = town:get_corps_uid(Town),
    TownDetail = town_detail:get_cfg(TownSid),
    FightLv = town:get_fight_lv(Town),
    TownLv = if
        FightLv > 0 ->
            FightLv;
        true ->
            town:get_lv(Town, TownDetail)
    end,
    %寻访信息
    {LookGoBack, NewLookOcc} =
        look_fight:fighting(Src, Now, EndPoint, TCorpsUid, town_lib:town_lv_looksid(TownLv), TownSid, LookArrs, LookOcc, MRoleUids),
    %战斗信息
    {AddGoBack, NewOcc, UpPointNpcState, UpPointOwner, NpcRefreshTime, NFightCUids} =
        if
            Tstate =:= ?STATE_PROTECT ->%冷却保护中
                do_fight_protect(Src, IsChief, EndPoint, TownSid, Town, FightArrs, FightOcc, length(FightOcc), []);
            true ->
                NpcHpStates = z_lib:get_value(town:get_npc_state(Town), EndPoint, default_npc_state()),
                {_, IntervalTime} = zm_config:get('fight_info', 'town_npc_refresh'),
                RefreshTime = z_lib:get_value(town:get_npc_refresh_time(Town), EndPoint, Stime),
                PoitOwner = z_lib:get_value(town:get_points_owner(Town), EndPoint, TCorpsUid),
                FightType = match_lib:get_fight_type(?MODULE),
                %攻打npc时候前台战报显示用
                ReportView =
                    if TCorpsUid =:= 0 ->
                        {TCountry, 0, "", 0};
                        true ->
                            Corps = corps_db:get_corps(Src, TCorpsUid),
                            {TCountry, TCorpsUid, corps:get_name(Corps), corps:get_banner(Corps)}
                    end,
                FightArgs = [
                    {'ma', {'fighting', []}},
                    {'auto', 1},%是否自动释放技能自动战斗 1:自动,0:手动
                    {'fight_type', FightType},
                    {'duplicate_sid', fighting:get_fight_scene('town')},
                    {'point_int', EndPoint},
                    {'sid', TownSid},
                    {'town_lv', TownLv},
                    {'point_owner', PoitOwner},
                    {'town_owner', TCorpsUid},
                    {'view', ReportView}],
                First = town_db:check_firt(Src, TownSid),
                do_fight(Src, First, Now, EndPoint, Town, TownDetail, IsChief, IntervalTime, FightArgs, FightArrs,
                    FightOcc, TCorpsUid, PoitOwner, NpcHpStates, RefreshTime, [], [], get_town_corps_builds(Src, TownSid, Town))
        end,
    {LookGoBack ++ AddGoBack, NewLookOcc ++ NewOcc, UpPointNpcState, UpPointOwner, NpcRefreshTime, NFightCUids}.

%% ----------------------------------------------------
%% @doc
%%     城池保护中,{AddGoBack, NewOcc, UpPointNpcState, UpPointOwner, NpcRefreshTime}
%% @end
%% ----------------------------------------------------
do_fight_protect(Src, IsChief, EndPoint, TownSid, Town, ArrMarchies, Occupy, OccLen, FCUids) ->
    {ChiefNum, NorNum} = element(2, zm_config:get('fight_info', 'defend_queue_len')),
    TCorpsUid = town:get_corps_uid(Town),
    F = fun({Len1, AddGoBack, NewOcc, FCUids1}, Marching) ->
        MRoleUid = marching:get_roleuid(Marching),
        MRoleShow = role_db:get_role_show(Src, MRoleUid),
        MCorpsUid = role_show:get_corps_uid(MRoleShow),
        if
            MCorpsUid =:= 0 ->
                null_report(Src, EndPoint, Marching, ?REPORT_NULL_TOWN_NOT_CORPS, {TownSid, town:get_lv(Town, town_detail:get_cfg(TownSid))}),
                {'ok', {Len1, [marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_TOWN_GOBACK) | AddGoBack], NewOcc, FCUids1}};
            TCorpsUid =:= MCorpsUid ->
                case marching:get_state(Marching) =:= ?ON_THE_TOWN_GARRISON_MARCHING of
                    true ->
                        if
                            ((IsChief andalso Len1 >= ChiefNum) orelse (not IsChief andalso Len1 >= NorNum)) ->
                                null_report(Src, EndPoint, Marching, ?REPORT_NULL_TOWN_UPPER, {TownSid, town:get_lv(Town, town_detail:get_cfg(TownSid))}),
                                {'ok', {Len1, [marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_TOWN_GOBACK) | AddGoBack], NewOcc, FCUids1}};
                            true ->
                                {'ok', {Len1 + 1, AddGoBack, [marching:change_occ(Marching, marching:get_etime(Marching), ?ON_THE_TOWN_GARRISON) | NewOcc], FCUids1}}
                        end;
                    false ->
                        null_report(Src, EndPoint, Marching, ?REPORT_NULL_POINT_CANT_FIGHTING, {TownSid, town:get_lv(Town, town_detail:get_cfg(TownSid))}),
                        {'ok', {Len1, [marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_TOWN_GOBACK) | AddGoBack], NewOcc, FCUids1}}
                end;
            true ->
                null_report(Src, EndPoint, Marching, ?REPORT_NULL_TOWN_PROTECT, {TownSid, town:get_lv(Town, town_detail:get_cfg(TownSid))}),
                {'ok', {Len1, [marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_TOWN_GOBACK) | AddGoBack], NewOcc, [MCorpsUid | FCUids1]}}
        end
    end,
    {_, AddGoBack, NewOcc, NFCUids} = z_lib:foreach(F, {OccLen, [], Occupy, FCUids}, ArrMarchies),
    NpcHpStates = z_lib:get_value(town:get_npc_state(Town), EndPoint, default_npc_state()),
    RefreshTime = z_lib:get_value(town:get_npc_refresh_time(Town), EndPoint, element(2, town:get_state(Town))),
    PoitOwner = z_lib:get_value(town:get_points_owner(Town), EndPoint, TCorpsUid),
    {AddGoBack, NewOcc, NpcHpStates, PoitOwner, RefreshTime, NFCUids}.

%% ----------------------------------------------------
%% @doc
%%     城池所属,当前城池所属 {AddGoBack, NewOcc, UpPointNpcState, UpPointOwner, NpcRefreshTime}
%% @end
%% ----------------------------------------------------
do_fight(_Src, _First, _Now, _EndPoint, _Town, _TownDetail, _IsChief, _IntervalTime, _FightArgs, [], [], _Owners, PoitOwners,
        NpcHpStates, RefreshTime, AddGoBack, FCUids, _) ->%没有到达,也没有防守(整个城池战斗结束,但是还有返回部队未到达自己城池的信息)
    {AddGoBack, [], NpcHpStates, PoitOwners, RefreshTime, FCUids};
do_fight(Src, First, Now, EndPoint, TownTmp, TownDetail, _IsChief, IntervalTime, FightArgs, [], Occupy, Owners, PoitOwner,
        NpcHpStates, RefreshTime, AddGoBack, FCUids, {EndCorps, MapBuildVLists}) ->%战斗完后再次确认是否刷新npc;所属变了,刷新npc
    Rtimes = (Now + ?FAILOVER_TIME - RefreshTime) div IntervalTime,
    if
        Rtimes > 0 ->
            if
                Owners =:= PoitOwner ->%所属没变,直接刷新npc
                    {AddGoBack, Occupy, default_npc_state(), PoitOwner, RefreshTime + Rtimes * IntervalTime, FCUids};
                true ->%所属变化,刷新npc并战斗
                    {Winner, NewOCC, FAddGoBack, NFHpState} = npc_fight_occ(Src, First, PoitOwner, Now, EndPoint, TownTmp,
                        TownDetail, Occupy, FightArgs, default_npc_state(), {?WINNER, []}, RefreshTime + IntervalTime),
                    if
                        Winner =:= 0 ->%occ胜利，npc失败;不切换所属
                            do_fight(Src, First, Now, EndPoint, TownTmp, TownDetail, _IsChief, IntervalTime, FightArgs, [], NewOCC, Owners, PoitOwner,
                                NFHpState, RefreshTime + IntervalTime, FAddGoBack ++ AddGoBack, FCUids, {EndCorps, MapBuildVLists});
                        true ->%npc胜利,切换所属
                            {FAddGoBack ++ AddGoBack, [], NFHpState, Owners, RefreshTime + IntervalTime, FCUids}
                    end
            end;
        true ->
            {AddGoBack, Occupy, NpcHpStates, PoitOwner, RefreshTime, FCUids}
    end;
do_fight(Src, First, Now, EndPoint, TownTmp, TownDetail, IsChief, IntervalTime, FightArgs, [Marching | ArrMarchies], Occupy, Owners, PointOwner,
        NpcHpStates, RefreshTime, AddGoBack, FCUids, {EndCorps, MapBuildVLists}) ->
    ETime = marching:get_etime(Marching),
    NpcRnums = (ETime + ?FAILOVER_TIME - RefreshTime) div IntervalTime,
    if
        NpcRnums > 0 ->%刷新npc
            if
                Owners =:= PointOwner ->
                    do_fight(Src, First, Now, EndPoint, TownTmp, TownDetail, IsChief, IntervalTime, FightArgs, [Marching | ArrMarchies], Occupy, Owners, PointOwner,
                        default_npc_state(), RefreshTime + NpcRnums * IntervalTime, AddGoBack, FCUids, {EndCorps, MapBuildVLists});
                true ->
                    NRefreshTime = RefreshTime + IntervalTime,
                    {Winner, NewOCC, FAddGoBack, NFHpState} = npc_fight_occ(Src, First, PointOwner, NRefreshTime, EndPoint, TownTmp, TownDetail, Occupy, FightArgs,
                        default_npc_state(), {?WINNER, []}, NRefreshTime),
                    NPointOwner =
                        if
                            Winner =:= 0 ->%occ胜利，npc失败;不切换所属
                                PointOwner;
                            true ->
                                Owners
                        end,
                    do_fight(Src, First, Now, EndPoint, TownTmp, TownDetail, IsChief, IntervalTime, FightArgs, [Marching | ArrMarchies], NewOCC, Owners,
                        NPointOwner, NFHpState, NRefreshTime, FAddGoBack ++ AddGoBack, FCUids, {EndCorps, MapBuildVLists})
            end;
        true ->
            MRoleUid = marching:get_roleuid(Marching),
            MRoleShow = role_db:get_role_show(Src, MRoleUid),
            MCorpsUid = role_show:get_corps_uid(MRoleShow),
            TownSid = town_detail:get_sid(TownDetail),
            TownLv = town:get_fight_lv(TownTmp),
            if
                MCorpsUid =:= 0 ->
                    null_report(Src, EndPoint, Marching, ?REPORT_NULL_TOWN_NOT_CORPS, {TownSid, TownLv}),
                    NewAddGoBack = [marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_TOWN_GOBACK) | AddGoBack],
                    do_fight(Src, First, Now, EndPoint, TownTmp, TownDetail, IsChief, IntervalTime, FightArgs, ArrMarchies, Occupy, Owners, PointOwner,
                        NpcHpStates, RefreshTime, NewAddGoBack, FCUids, {EndCorps, MapBuildVLists});
                true ->
                    CurLen = length(Occupy),
                    LenNum =
                        if
                            IsChief ->
                                element(1, element(2, zm_config:get('fight_info', 'defend_queue_len')));
                            true ->
                                element(2, element(2, zm_config:get('fight_info', 'defend_queue_len')))
                        end,
                    CurState = marching:get_state(Marching),
                    {NewArrMarchies, NewOccupy, NewPoitOwners, NewNpcHpStates, NewAddGoBack} =
                        if
                            MCorpsUid =:= PointOwner andalso CurLen >= LenNum ->%到达与当前占领者同盟,超过驻防上限
                                case CurState =:= ?ON_THE_TOWN_GARRISON_MARCHING of
                                    true ->
                                        null_report(Src, EndPoint, Marching, ?REPORT_NULL_TOWN_UPPER, {TownSid, TownLv});
                                    false ->
                                        null_report(Src, EndPoint, Marching, ?REPORT_NULL_POINT_CANT_FIGHTING, {TownSid, TownLv})
                                end,
                                {ArrMarchies, Occupy, PointOwner, NpcHpStates, [marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_TOWN_GOBACK) | AddGoBack]};
                            MCorpsUid =:= PointOwner ->%到达与当前占领者同盟,没有达到驻防上限
                                case CurState =:= ?ON_THE_TOWN_GARRISON_MARCHING of
                                    true ->
                                        OccMarch = marching:change_occ(Marching, ETime, ?ON_THE_TOWN_GARRISON),
                                        {ArrMarchies, [OccMarch | Occupy], PointOwner, NpcHpStates, AddGoBack};
                                    false ->
                                        null_report(Src, EndPoint, Marching, ?REPORT_NULL_POINT_CANT_FIGHTING, {TownSid, TownLv}),
                                        {ArrMarchies, Occupy, PointOwner, NpcHpStates, [marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_TOWN_GOBACK) | AddGoBack]}
                                end;
                            true ->%到达者与当前占领者不是同盟;战斗
                                case CurState =:= ?ON_THE_TOWN_GARRISON_MARCHING of
                                    true ->  %%  367行，PointOwner，之前是Owner，会出现城战过程中，被玩家占领的点，切换时变成守军占领
                                        null_report(Src, EndPoint, Marching, ?REPORT_NULL_POINT_CANT_GARRISON, {TownSid, TownLv}),
                                        {ArrMarchies, Occupy, PointOwner, NpcHpStates, [marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_TOWN_GOBACK) | AddGoBack]};
                                    false ->
                                        case not IsChief orelse MCorpsUid =:= Owners orelse (IsChief andalso point_db:check_fight_chief(Src, MCorpsUid, role_show:get_country(MRoleShow), TownDetail)) of
                                            true ->
                                                %%战斗之前先扣箭塔伤害
                                                {NMarchings, AddGobackTmps} =
                                                    case MCorpsUid =:= Owners orelse marching:get_fight_num(Marching) > 0 of
                                                        true ->
                                                            {[Marching], []};
                                                        false ->
                                                            TownPointUid = town_detail:get_point(TownDetail),
                                                            map_build_db:map_build_damage(Src, Marching, EndPoint, EndCorps, MapBuildVLists, TownPointUid)
                                                    end,
                                                case NMarchings of
                                                    [NMarching] ->
                                                        if
                                                            Owners =:= PointOwner ->%当前所属没变化,进攻方攻打防守方
                                                                %先攻打玩家,后攻打npc
                                                                {Winner, NewOcc, FAddGoBack} =
                                                                    do_role_fighting(Src, TownSid, First, MCorpsUid, Now, EndPoint, PointOwner, NMarching, Occupy, FightArgs, {?WINNER, []}),
                                                                if
                                                                    Winner =:= 0 ->%进攻方胜利,NewOcc为进攻方的marching信息
                                                                        Dead = chk_npc_dead(TownTmp, NpcHpStates), %攻打npc,如果npc已经死亡则
                                                                        if
                                                                            Dead ->%没有npc存活,切换占有者(如果城池配置没有npc,所以默认修改为胜利)
                                                                                {ArrMarchies, [], MCorpsUid, NpcHpStates, [marching:change_goback_bystate(Nb, EndPoint, ?ON_THE_TOWN_GOBACK) || Nb <- NewOcc] ++ FAddGoBack ++ AddGoBack};
                                                                            true ->%npc还有未死亡的
                                                                                {Winner1, NewFMarching, FAddGoBack1, NewFHpState} =
                                                                                    do_npc_fighting(Src, First, MCorpsUid, Now, EndPoint, TownTmp, TownDetail, hd(NewOcc), FightArgs, NpcHpStates, ?REPORT_FIGHT_TOWN_MONSTER),
                                                                                if
                                                                                    Winner1 =:= 0 ->%进攻方胜利，npc失败，切换占有者
                                                                                        {ArrMarchies, [], MCorpsUid, NewFHpState,
                                                                                                FAddGoBack1 ++ FAddGoBack ++ [marching:change_goback_bystate(NewFMarching, EndPoint, ?ON_THE_TOWN_GOBACK) | AddGoBack]};
                                                                                    true ->
                                                                                        {ArrMarchies, [], PointOwner, NewFHpState, FAddGoBack1 ++ FAddGoBack ++ AddGoBack}
                                                                                end
                                                                        end;
                                                                    true ->%当前进攻方已经失败，继续下一个到达的人员计算
                                                                        {ArrMarchies, NewOcc, PointOwner, NpcHpStates, FAddGoBack ++ AddGoBack}
                                                                end;
                                                            true ->%当前所属已变化,需要刷新npc，则刷新npc与当前occ战斗，然后再到达的与之战斗
                                                                NpcDead = chk_npc_dead(TownTmp, NpcHpStates),
                                                                if
                                                                    NpcDead ->
                                                                        %npc没有刷新，直接战斗
                                                                        {NWinner, NewROcc, NFAddGoBack} =
                                                                            do_role_fighting(Src, TownSid, First, MCorpsUid, Now, EndPoint, PointOwner, NMarching, Occupy, FightArgs, {?WINNER, []}),%(如果点没有)
                                                                        if
                                                                            NWinner =:= 0 ->%进攻方胜利，且防守已经没有人，切换占有者
                                                                                {ArrMarchies, [], MCorpsUid, NpcHpStates, [marching:change_goback_bystate(Nb, EndPoint, ?ON_THE_TOWN_GOBACK) || Nb <- NewROcc] ++ NFAddGoBack ++ AddGoBack};
                                                                            true ->%当前进攻方已经失败，继续下一个到达的人员计算
                                                                                {ArrMarchies, NewROcc, PointOwner, NpcHpStates, NFAddGoBack ++ AddGoBack}
                                                                        end;
                                                                    true ->
                                                                        if
                                                                            Occupy =:= [] ->%刷新没人防守，则直接切换拥有着
                                                                                {[NMarching | ArrMarchies], [], Owners, NpcHpStates, AddGoBack};
                                                                            true ->%切换occ攻打npc
                                                                                {Winner, NewOCC, FAddGoBack, NFHpState} =
                                                                                    npc_fight_occ(Src, First, PointOwner, Now, EndPoint, TownTmp, TownDetail, Occupy, FightArgs, NpcHpStates, {?WINNER, []}, RefreshTime),
                                                                                if
                                                                                    Winner =:= 0 ->%occ胜利，npc失败,则继续走战斗流程
                                                                                        {[NMarching | ArrMarchies], NewOCC, PointOwner, NFHpState, FAddGoBack ++ AddGoBack};
                                                                                    true ->%npc胜利,切换
                                                                                        {[NMarching | ArrMarchies], [], Owners, NpcHpStates, FAddGoBack ++ AddGoBack}
                                                                                end
                                                                        end
                                                                end
                                                        end;
                                                    _ ->
                                                        {ArrMarchies, Occupy, Owners, NpcHpStates, AddGobackTmps ++ AddGoBack}
                                                end;
                                            false ->
                                                null_report(Src, EndPoint, Marching, ?REPORT_NULL_TOWN_NUM, {TownSid, TownLv}),
                                                {ArrMarchies, Occupy, PointOwner, NpcHpStates, [marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_TOWN_GOBACK) | AddGoBack]}
                                        end
                                end
                        end,
                    FCUids1 = if
                        MCorpsUid > 0 andalso MCorpsUid =/= PointOwner ->
                            [MCorpsUid | FCUids];
                        true ->
                            FCUids
                    end,
                    do_fight(Src, First, Now, EndPoint, TownTmp, TownDetail, IsChief, IntervalTime, FightArgs, NewArrMarchies, NewOccupy, Owners,
                        NewPoitOwners, NewNpcHpStates, RefreshTime, NewAddGoBack, FCUids1, {EndCorps, MapBuildVLists})
            end
    end.


%% ----------------------------------------------------
%% @doc
%%     玩家打驻守的npc,战斗  %%{Winner, NewFMarching, FAddGoBack, NewFHpState} =
%% @end
%% ----------------------------------------------------
do_npc_fighting(Src, First, MCorpsUid, Now, EndPoint, TownTmp, TownDetail, Marching, FightArgs, {OLastLen, OLastHp} = LastHpState, FightType) ->%npc战斗
    %npc独立先战斗,不管当前npc是否还有3波,也不补全role3波进行战斗,再战斗结束后,再去和玩家战斗
    Etime = marching:get_etime(Marching),
    {MRoleUid, MGId} = marching:get_roleuid_gid(Marching),
    case get_fight_npc(Src, TownTmp, TownDetail, LastHpState) of
        [] ->
            {?WINNER, Marching, [], LastHpState};
        FightNpc ->
            FightRole = fighter:init_role(Src, MRoleUid, MGId, 0, garray_db:get_garray(Src, MRoleUid, MGId)),
            NFightArgs = [
                {'time', Etime},
                {'seed', game_lib:get_seed()},
                {'fight_role', FightRole},
                {'fight_enemy', FightNpc} | FightArgs],
            case match:auto_result(Src, MRoleUid, NFightArgs) of
                {Winner, Result} ->
                    Dead = result:get_dead(Result),
                    Injured = result:get_injured(Result),
                    RoleChange = result:get_queue(Result),
                    AllCardExp = result:get_allexp(Result),
                    WaveInfos = result:get_waves(Result),
                    AllKillNum = result:get_enemy_total_dead(Result),
                    TownSid = town_detail:get_sid(TownDetail),
                    town_db:add_npchp(TownSid, MCorpsUid, MRoleUid, AllKillNum),
                    {LastLen, LastHp} = result:get_enemy_last_hps(Result),
                    {_, MarchiQueue, GarrayInjured, _, _DeductSosldierNum} =
                        fighting:update_garray_after_fight(Src, RoleChange, {MRoleUid, MGId}),
                    AddOneCardExp = garray_db:award_card_allexp(Src, MRoleUid, MGId, AllCardExp, TownSid),%武将加经验
                    set_front_lib:send_map_result(Src, MRoleUid,
                        {Etime, EndPoint, ?TOWN, ?MONSTER, Winner, MGId, {MarchiQueue, Dead, Injured, GarrayInjured}, AddOneCardExp, FightType}),
                    zm_event:notify(Src, 'fight_town_monster_report', [
                        {'role_uid', MRoleUid},
                        {'winner', Winner},
                        {'award_list', {[], [{'card_exp', AddOneCardExp}]}},
                        {'wave_infos', WaveInfos}, {'report_type', FightType} | NFightArgs]),
                    if
                        Winner =:= 0 ->%进攻方玩家胜利
                            NewLHpState = {LastLen + OLastLen, []},
                            NFightMarch = marching:fight_result(Marching, Injured, Dead, []),
                            NpcDead = chk_npc_dead(TownTmp, NewLHpState),
                            if
                                NpcDead ->%npc已经全部dead
                                    {Winner, NFightMarch, [], NewLHpState};
                                true ->
                                    do_npc_fighting(Src, First, MCorpsUid, Now, EndPoint, TownTmp, TownDetail, NFightMarch, FightArgs, NewLHpState, FightType)
                            end;
                        true ->%防守方npc胜利
                            NewLHpState = {LastLen + OLastLen - 1, LastHp},
                            BackMarching = marching:fight_result(marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_TOWN_GOBACK), Injured, Dead, []),
                            {Winner, BackMarching, [BackMarching], NewLHpState}
                    end;
                WebErr ->
                    zm_log:warn(?MODULE, ?MODULE, 'do_npc_fighting', "web_error", [{'error', WebErr}, {'point_uid', EndPoint}, {'marching', Marching}]),
                    case fighter:get_fighters(FightRole) =:= [] of
                        true ->
                            BackMarching = marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_TOWN_GOBACK),
                            {?LOSE, BackMarching, [BackMarching], {OLastLen, OLastHp}};
                        false ->
                            case lists:filter(fun(F) -> fighter:get_fighters(F) =:= [] end, FightNpc) of
                                [] ->
                                    BackMarching = marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_TOWN_GOBACK),
                                    {?LOSE, BackMarching, [BackMarching], {OLastLen, OLastHp}};
                                _ ->%%npc怪已经死亡
                                    do_npc_fighting(Src, First, MCorpsUid, Now, EndPoint, TownTmp, TownDetail, Marching, FightArgs, {OLastLen + 1, []}, FightType)
                            end
                    end
            end
    end.

%% ----------------------------------------------------
%% @doc
%%     到达的与,所有驻防的role战斗 {Winner, NewOcc, FAddGoBack}
%% @end
%% ----------------------------------------------------
do_role_fighting(_Src, _TownSid, _First, _MCorpsUid, _Now, _EndPoint, _PointOwner, Marching, [], _FightArgs, {Winner, AddGoBack}) ->
    ETime = marching:get_etime(Marching),
    {Winner, [marching:change_occ(Marching, ETime, ?ON_THE_TOWN_GARRISON)], AddGoBack};
do_role_fighting(Src, TownSid, First, MCorpsUid, Now, EndPoint, PointOwner, Marching, Occupy, FightArgs, {_, NewAddGoBack}) ->%到达者，递归与防守方战斗，直到战斗结束
    Etime = marching:get_etime(Marching),
    %npc独立先战斗,不管当前npc是否还有3波,也不补全role3波进行战斗,再战斗结束后,再去和玩家战斗
    {FightOcc, RestOcc1} = game_lib:list_split(?ONE_FIGHT_ROLE_NUM, lists:reverse(Occupy)),
    RestOcc = lists:reverse(RestOcc1),
    {MRoleUid, MGId} = marching:get_roleuid_gid(Marching),
    FightRole = fighter:init_role(Src, MRoleUid, MGId, 0, garray_db:get_garray(Src, MRoleUid, MGId)),
    case fighter:get_fighters(FightRole) of
        [] ->
            BackMarching = marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_TOWN_GOBACK),
            {?LOSE, Occupy, [BackMarching | NewAddGoBack]};
        _ ->
            {FightEnemy, EnemyUids1, AddGoBack} = z_lib:foreach(fun({A1, A2, A3}, FM) ->
                {PMRoleuid, PMGid} = marching:get_roleuid_gid(FM),
                NF = fighter:init_role(Src, PMRoleuid, PMGid, 1, garray_db:get_garray(Src, PMRoleuid, PMGid), role_addition:get_town_add_attr(Src, PointOwner)),
                case fighter:get_fighters(NF) of
                    [] ->
                        {'ok', {A1, A2, [FM | A3]}};
                    _ ->
                        {'ok', {[NF | A1], [PMRoleuid | A2], A3}}
                end
            end, {[], [], []}, FightOcc),
            if
                FightEnemy =:= [] ->
                    do_role_fighting(Src, TownSid, First, MCorpsUid, Now, EndPoint, PointOwner, Marching, RestOcc, FightArgs, {?WINNER, AddGoBack ++ NewAddGoBack});
                true ->
                    NFightArgs = [
                        {'time', Etime},
                        {'seed', game_lib:get_seed()},
                        {'fight_role', FightRole},
                        {'fight_enemy', FightEnemy} | FightArgs],
                    case match:auto_result(Src, MRoleUid, NFightArgs) of
                        {Winner, Result} ->%攻打玩家不会获得武将经验
                            Dead = result:get_dead(Result),
                            Injured = result:get_injured(Result),
                            RoleChange = result:get_queue(Result),
                            RoleAddFeats1 = result:get_role_feats(Result),
                            EnemyAddFeats1 = result:get_enemy_feats_list(Result),
                            RoleAddFeats = role_db:award_feats(Src, MRoleUid, RoleAddFeats1),
                            EnemyUids = lists:sublist(EnemyUids1, length(EnemyAddFeats1)),
                            EnemyAddFeats = lists:map(fun({RUid, AddFeats}) ->
                                role_db:award_feats(Src, RUid, AddFeats) end, lists:zip(EnemyUids, EnemyAddFeats1)),
                            WaveInfos = result:get_waves(Result),
                            {_MarchBearLoad, MarchQueue, GarrayInjured, _, _DeductSosldierNum} =
                                fighting:update_garray_after_fight(Src, RoleChange, {MRoleUid, MGId}),
                            AllKillNum = result:get_enemy_total_dead(Result),
                            town_db:add_npchp(TownSid, MCorpsUid, MRoleUid, AllKillNum),
                            lists:foreach(fun({EUid, {MDInfos, _}}) ->
                                EKillNum = element(1, MDInfos),
                                town_db:add_npchp(TownSid, PointOwner, EUid, EKillNum)
                            end, lists:zip(EnemyUids, WaveInfos)),
                            set_front_lib:send_map_result(Src, MRoleUid, {Etime, EndPoint, ?TOWN, ?ROLE, Winner, MGId, {MarchQueue, Dead, Injured, GarrayInjured}, 0}),
                            NAwardView = if
                                RoleAddFeats > 0 ->
                                    [{'feats', RoleAddFeats}];
                                true ->
                                    []
                            end,
                            UidFeatsList = [{MRoleUid, RoleAddFeats} | lists:zip(EnemyUids, EnemyAddFeats)],
                            zm_event:notify(Src, 'fight_role_town_report', [
                                {'role_uid', MRoleUid},
                                {'ruids', EnemyUids},
                                {'winner', Winner},
                                {'award_list', []},%战报里面,功勋会加
                                {'wave_infos', WaveInfos},
                                {'feats', UidFeatsList} | NFightArgs]),%玩家失败
                            if
                                Winner =:= 0 ->%进攻方胜利
                                    NFightMarch = marching:fight_result(Marching, Injured, Dead, NAwardView),
                                    EUidFeatsWList = lists:zip3(EnemyUids, EnemyAddFeats, WaveInfos),
                                    Adds = lists:map(fun(EMarching) ->
                                        {ERUid, EGid} = marching:get_roleuid_gid(EMarching),
                                        {_, EFeats, {_, {ODead, OInjured, TargetChange}}} = lists:keyfind(ERUid, 1, EUidFeatsWList),
                                        {_, EMarchQueue, GarrayInjured2, _, _DeductSosldierNum} =
                                            fighting:update_garray_after_fight(Src, TargetChange, {ERUid, EGid}),
                                        set_front_lib:send_map_result(Src, ERUid, {Etime, EndPoint, ?TOWN, ?ROLE, Winner, EGid, {EMarchQueue, ODead, OInjured, GarrayInjured2}, 1}),
                                        EFeatsAward = if
                                            EFeats > 0 -> [{'feats', EFeats}];
                                            true -> []
                                        end,
                                        marching:change_goback_byetime_state(marching:fight_result(EMarching, OInjured, ODead, EFeatsAward), EndPoint, Etime, ?ON_THE_TOWN_GOBACK)
                                    end, FightOcc),
                                    do_role_fighting(Src, TownSid, First, MCorpsUid, Now, EndPoint, PointOwner, NFightMarch, RestOcc, FightArgs, {Winner, Adds ++ NewAddGoBack});
                                true ->%防守方胜利
                                    BackMarching = marching:fight_result(marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_TOWN_GOBACK), Injured, Dead, NAwardView),
                                    {NProtectList, AddPGo} = refresh_protect(Src, EndPoint, Winner, FightOcc, WaveInfos, UidFeatsList, Etime),
                                    {Winner, RestOcc ++ lists:reverse(NProtectList), [BackMarching | AddPGo ++ NewAddGoBack]}
                            end;
                        WebErr ->
                            zm_log:warn(?MODULE, ?MODULE, 'fighting', "web_error", [{'error', WebErr}, {'point_uid', EndPoint}, {'marching', Marching}]),
                            BackMarching = marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_TOWN_GOBACK),
                            {?LOSE, Occupy, [BackMarching | NewAddGoBack]}
                    end
            end
    end.

%% ----------------------------------------------------
%% @doc
%%     刷新的npc与occ战斗 {Winner, NewOCC, FAddGoBack, NFHpState}
%% @end
%% ----------------------------------------------------
npc_fight_occ(_Src, _First, _CorpsUid, _Now, _EndPoint, _TownTmp, _TownDetail, [], _FightArgs, FHpState, {Winner, AddGoBack}, _FightTime) ->%npc胜利
    {Winner, [], AddGoBack, FHpState};
npc_fight_occ(Src, First, CorpsUid, Now, EndPoint, TownTmp, TownDetail, Occ, FightArgs, FHpState, {Winner, AddGoBack}, FightTime) ->%递归与npc战斗，直到结果产生
    [Marching | RestOcc1] = lists:reverse(Occ),
    RestOcc = lists:reverse(RestOcc1),
    NpcDead = chk_npc_dead(TownTmp, FHpState),
    if
        NpcDead ->
            {Winner, Occ, AddGoBack, FHpState};
        true ->
            {NewWinner, NewFMarching, FAddGoBack, NewFHpState} =
                do_npc_fighting(Src, First, CorpsUid, Now, EndPoint, TownTmp, TownDetail, marching:set_etime(Marching, FightTime), FightArgs, FHpState, ?REPORT_FIGHT_MONSTER_TOWN_ROLE),
            if
                NewWinner =:= 0 ->%玩家胜利
                    NAddGoBack = marching:change_goback_bystate(NewFMarching, EndPoint, ?ON_THE_TOWN_GOBACK),
                    {NewWinner, RestOcc, [NAddGoBack | FAddGoBack], NewFHpState};
                true ->%npc胜利
                    npc_fight_occ(Src, First, CorpsUid, Now, EndPoint, TownTmp, TownDetail, RestOcc, FightArgs, NewFHpState, {NewWinner, FAddGoBack ++ AddGoBack}, FightTime)
            end
    end.

%% ----------------------------------------------------
%% @doc
%%     城战结束,清除玩家战斗中现象
%% @end
%% ----------------------------------------------------
clear_corps_fighting(Src, TownSid, CorpsUids, ISchief) ->
    Table = game_lib:get_table(Src, 'corps_town'),
    lists:foreach(fun(CorpsUid) ->
        Fun = fun(_, 'none') ->
            throw("ok");
            (_, CorpsTown) ->
                {'ok', 'ok', corps_town:del_flist(CorpsTown, TownSid, ISchief)}
        end,
        z_db_lib:update(Table, CorpsUid, 'none', Fun, [])
    end, CorpsUids).

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%      城墙扣血
%% @end
%% ----------------------------------------------------
del_wall_hp(Src, Now, TownSid, EndPoint, TownDetail, MRoleUids, EventBool, {EndCorps, MapBuildVList}) ->
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'town', TownSid, town:init(TownDetail)},
        {'point_march', EndPoint, point_march:init()}]),
    Fun = fun(_, [{_Index1, Town}, {Index2, PMarch1}]) ->
        DelHp = town:get_del_wall_hp(Town),
        FightLv = town:get_fight_lv(Town),
        TownLv1 = if
            FightLv > 0 ->
                FightLv;
            true ->
                town:get_lv(Town, TownDetail)
        end,
        WallHpAdd = town:get_wall_hp_add(Town),
        WallHp1 = town_detail:get_wall_hp(Src, TownLv1, WallHpAdd, TownDetail),
        if
            DelHp >= WallHp1 ->
                {'ok', {'ok', Town}};
            true ->
                {Locc, SOcc} = lists:partition(fun(Pm) ->
                    look_fight:looking_state(marching:get_state(Pm)) end, point_march:get_occupy(PMarch1)),
                {AddGoback, Nocc} = look_fight:check_occ_goback(Src, EndPoint, TownSid, MRoleUids, Now, [], Locc),
                PMarch = point_march:set_occupy(point_march:set_goback(PMarch1, AddGoback ++ point_march:get_goback(PMarch1)), Nocc ++ SOcc),
                {ArrMList1, NArrMList1} = point_march:get_arrive(point_march:get_marchies(PMarch), Now),
                {ArrGoBack, NotGoBack} = point_march:get_arrive(point_march:get_goback(PMarch), Now),
                NPMarch1 = point_march:set_goback(point_march:set_marchies(PMarch, NArrMList1), NotGoBack),
                {'ok', {'ok', ArrMList1, ArrGoBack, DelHp, Town, point_march:get_point_info(PMarch), WallHp1, length(Nocc), length(SOcc), AddGoback, TownLv1}, [{Index2, NPMarch1}]}
        end
    end,
    case z_db_lib:handle(TableName, Fun, [], TableKeys) of
        {'ok', ArrList, DealGoBack, NDelHp, NTown, PInfo, WallHp, LookNum, GarrisonNum, AddSednGoBack, TownLv} ->
            IsChief = town_detail:chk_chief(TownDetail),
            GarrisonMaxNum =
                if
                    IsChief ->
                        element(1, element(2, zm_config:get('fight_info', 'defend_queue_len')));
                    true ->
                        element(2, element(2, zm_config:get('fight_info', 'defend_queue_len')))
                end,
            {_, OWallHpCoe} = zm_config:get('fight_info', 'ordnance_wall_hp'),
            TCorpsUid = town:get_corps_uid(NTown),
            ReportView = {town:get_country(NTown), TCorpsUid, corps:get_name(EndCorps), corps:get_banner(EndCorps)},
            LookSid = town_lib:town_lv_looksid(TownLv),
            LookDetail = look_detail:get_cfg(LookSid),
            MaxNum = look_detail:get_max_num(LookDetail, TownDetail),
            F = fun({{DHp, AList, OList, GList, LookNum1, GarrisonNum1}, FCUids}, Marching) ->
                {RoleUid, GId} = marching:get_roleuid_gid(Marching),
                RoleShow = role_db:get_role_show(Src, RoleUid),
                MCorpsUid = role_show:get_corps_uid(RoleShow),
                MEtime = marching:get_etime(Marching),
                MState = marching:get_state(Marching),
                DAOGLG =
                    if
                        MCorpsUid =:= 0 ->
                            GState =
                                if
                                    MState =:= ?ON_THE_LOOK_MARCHING ->
                                        look_fight:null_report(Src, TownSid, Marching, EndPoint, ?REPORT_NULL_LOOK_NOCORPS),
                                        ?ON_THE_LOOK_GOBACK_MARCH_ARRIVE_NOT_CORPS;
                                    true ->
                                        null_report(Src, EndPoint, Marching, ?REPORT_NULL_TOWN_NOT_CORPS, {TownSid, TownLv}),
                                        ?ON_THE_TOWN_GOBACK
                                end,
                            GMarching = marching:change_goback_bystate(Marching, EndPoint, GState),
                            {DHp, AList, OList, [GMarching | GList], LookNum1, GarrisonNum1};
                        MCorpsUid =:= TCorpsUid ->
                            {NOList, NGList, NLNum, NGNum} =
                                if
                                    MState =:= ?ON_THE_LOOK_MARCHING ->
                                        if
                                            LookNum1 >= MaxNum ->
                                                look_fight:null_report(Src, TownSid, Marching, EndPoint, ?REPORT_NULL_LOOK_UPPER),
                                                GMarching = marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_LOOK_GOBACK_MAX_UPPER),
                                                {OList, [GMarching | GList], LookNum1, GarrisonNum1};
                                            true ->
                                                OccMarching = marching:look_marching(LookSid, LookDetail, Marching, TownLv),
                                                {[OccMarching | OList], GList, LookNum1 + 1, GarrisonNum1}
                                        end;
                                    MState =:= ?ON_THE_TOWN_GARRISON_MARCHING ->
                                        if
                                            GarrisonNum1 >= GarrisonMaxNum ->
                                                null_report(Src, EndPoint, Marching, ?REPORT_NULL_TOWN_UPPER, {TownSid, TownLv}),
                                                GMarching = marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_TOWN_GOBACK),
                                                {OList, [GMarching | GList], LookNum1, GarrisonNum1};
                                            true ->
                                                AOccMarching = marching:change_occ(Marching, marching:get_etime(Marching), ?ON_THE_TOWN_GARRISON),
                                                {[AOccMarching | OList], GList, LookNum1, GarrisonNum1 + 1}
                                        end;
                                    true -> %玩家攻击过来的,达到时候属于自己本军团,返回
                                        null_report(Src, EndPoint, Marching, ?REPORT_NULL_POINT_CANT_FIGHTING, {TownSid, TownLv}),
                                        GMarching = marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_TOWN_GOBACK),
                                        {OList, [GMarching | GList], LookNum1, GarrisonNum1}
                                end,
                            {DHp, AList, NOList, NGList, NLNum, NGNum};
                        DHp >= WallHp ->
                            {WallHp, [Marching | AList], OList, GList, LookNum1, GarrisonNum1};
                        true ->
                            if
                                MState =:= ?ON_THE_TOWN_GARRISON_MARCHING ->%玩家驻防过来,到达时候不属于自己军团
                                    null_report(Src, EndPoint, Marching, ?REPORT_NULL_POINT_CANT_GARRISON, {TownSid, TownLv}),
                                    GMarching = marching:change_goback_bystate(Marching, EndPoint, ?ON_THE_TOWN_GOBACK),
                                    {DHp, AList, OList, [GMarching | GList], LookNum1, GarrisonNum1};
                                true ->
                                    %城池战斗开始后,出发的行军,在城战结束后到达的情况,重新开始战斗
                                    {AddTCUid, NRTown} =
                                        case town:get_state(NTown) of
                                            {OSTate, _PStime, PEtime} when (OSTate =:= ?STATE_PROTECT orelse OSTate =:= ?STATE_NOR) andalso PEtime =< MEtime ->
                                                RDtown = z_db_lib:update(game_lib:get_table(Src, 'town'), TownSid, town:init(TownDetail), fun(_, T) ->
                                                    case town:get_corps_uid(T) =/= MCorpsUid andalso town:get_fight_lv(T) =:= 0 of
                                                        true ->
                                                            Country = town:get_country(T),
                                                            {TownMaxHpAdd, TownNpcAttrs} = role_addition:get_country_add_town_addition(Src, Country),
                                                            NT = town:start_fight(Src, TownSid, TownDetail, T, TownMaxHpAdd, TownNpcAttrs, MEtime),
                                                            {'ok', NT, NT};
                                                        false ->
                                                            {'ok', 'ok'}
                                                    end
                                                end, []),
                                                if
                                                    RDtown =:= 'ok' ->
                                                        {[], NTown};
                                                    true ->
                                                        fight_db:add_fight_assist(Src, EndPoint, marching:set_etime(Marching, element(3, town:get_state(RDtown)))),
                                                        zm_event:notify(Src, 'bi_fight_town_start', [{'town_sid', TownSid}, {'town', RDtown}]),
                                                        point_search_db:update_towninfo(Src, TownSid, TownDetail, RDtown),%重新开战状态推送前台
                                                        if
                                                            Now - MEtime > 30 ->%如果重新开战时间比当前时间小10秒以上,则不推送聊天信息了(这种情况存在于有行军开始,然后停服很久(或者行军开始后离线,也无人获取才会出现))
                                                                'ok';
                                                            true ->
                                                                fight_db:town_fight_notice(Src, TownDetail, RDtown, MCorpsUid, corps_db:get_corps(Src, MCorpsUid), TCorpsUid, IsChief)
                                                        end,
                                                        if
                                                            TCorpsUid > 0 ->
                                                                {[TCorpsUid], RDtown};
                                                            true ->
                                                                {[], RDtown}
                                                        end
                                                end;
                                            _ ->
                                                {[], NTown}
                                        end,
                                    TownPointUid = town_detail:get_point(TownDetail),
                                    {NMarchings, AddBackMarchings} = map_build_db:map_build_damage(Src, Marching, EndPoint, EndCorps, MapBuildVList, TownPointUid),
                                    ReplyDAOGLG =
                                        case NMarchings of
                                            [NMarching] ->
                                                case town:get_fight_lv(NRTown) > 0 of
                                                    true ->
                                                        case not IsChief orelse (IsChief andalso point_db:check_fight_chief(Src, MCorpsUid, role_show:get_country(RoleShow), TownDetail)) of
                                                            true ->
                                                                FightRole = fighter:init_role(Src, RoleUid, GId, 0, garray_db:get_garray(Src, RoleUid, GId)),
                                                                Attack = min(get_wall_attack(Src, FightRole, OWallHpCoe, Now), WallHp - DHp),
                                                                town_db:add_wallhp(TownSid, MCorpsUid, RoleUid, Attack),
                                                                if
                                                                    DHp + Attack >= WallHp ->%城墙血量空
                                                                        wall_report(Src, TownSid, EndPoint, NMarching, 0, WallHp - DHp, FightRole, ?WINNER, ReportView, TownLv),
                                                                        {WallHp, [NMarching | AList], OList, GList, LookNum1, GarrisonNum1};
                                                                    true ->
                                                                        wall_report(Src, TownSid, EndPoint, NMarching, WallHp - (DHp + Attack), WallHp - DHp, FightRole, ?WINNER, ReportView, TownLv),%策划需求,城墙战报都为胜利
                                                                        {DHp + Attack, AList, OList, [marching:change_goback_bystate(NMarching, EndPoint, ?ON_THE_TOWN_GOBACK) | GList], LookNum1, GarrisonNum1}
                                                                end;
                                                            false ->
                                                                null_report(Src, EndPoint, NMarching, ?REPORT_NULL_TOWN_NUM, {TownSid, TownLv}),
                                                                {DHp, AList, OList, [marching:change_goback_bystate(NMarching, EndPoint, ?ON_THE_TOWN_GOBACK) | GList], LookNum1, GarrisonNum1}
                                                        end;
                                                    false ->
                                                        null_report(Src, EndPoint, NMarching, ?REPORT_NULL_TOWN_PROTECT, {TownSid, TownLv}),
                                                        {DHp, AList, OList, [marching:change_goback_bystate(NMarching, EndPoint, ?ON_THE_TOWN_GOBACK) | GList], LookNum1, GarrisonNum1}
                                                end;
                                            _ ->
                                                {DHp, AList, OList, AddBackMarchings ++ GList, LookNum1, GarrisonNum1}
                                        end,
                                    {ReplyDAOGLG, AddTCUid}
                            end
                    end,
                NFCUids = if
                    MCorpsUid > 0 andalso MCorpsUid =/= TCorpsUid ->
                        [MCorpsUid | FCUids];
                    true ->
                        FCUids
                end,
                case DAOGLG of
                    {DAOGLG1, AddTCUid1} ->
                        {'ok', {DAOGLG1, AddTCUid1 ++ NFCUids}};
                    _ ->
                        {'ok', {DAOGLG, NFCUids}}
                end
            end,
            {{RDelHp, RAList, OccList, GoBackList, _, _}, AddFCUid} = z_lib:foreach(F, {{NDelHp, [], [], [], LookNum, GarrisonNum}, []}, ArrList),%到达城池的
            if
                DealGoBack =/= [] ->
                    fighting:deal_goback(Src, EndPoint, DealGoBack, PInfo, false);%处理从城池返回到达的
                true ->
                    'ok'
            end,
            Fun1 = fun(_, [{Index1, Town}, {Index2, PMarch}]) ->
                NPMarch = point_march:update(PMarch, RAList, OccList, GoBackList),
                {Locc1, SOcc1} = lists:partition(fun(Pm) ->
                    look_fight:looking_state(marching:get_state(Pm))
                end, point_march:get_occupy(NPMarch)),
                {AddGoback1, Nocc1} = look_fight:check_occ_goback(Src, EndPoint, TownSid, MRoleUids, Now, [], Locc1),
                NewOccupy = Nocc1 ++ SOcc1,
                NewPMarch = point_march:set_occupy(point_march:set_goback(NPMarch, AddGoback1 ++ point_march:get_goback(NPMarch)), NewOccupy),
                OClen = length(SOcc1),
                NTownTmp2 =
                    if
                        not EventBool -> %%从over过来的不能够设置over_time为-1,否则,会导致结算中的状态无法锁定,同时操作town了
                            town:set_del_wall_hp(Town, RDelHp);
                        true ->
                            town:set_over_time(town:set_del_wall_hp(Town, RDelHp), ?STATE_FIGHT_WALL_EVERY_OVER)
                    end,
                FUids = town:get_fight_uids(NTownTmp2),
                NAFUids = lists:usort(AddFCUid)--FUids,
                NTownTmp1 = town:set_fight_uids(NTownTmp2, NAFUids ++ FUids),
                if
                    RDelHp >= WallHp ->
                        {_, Stime, Etime} = town:get_state(Town),
                        NTown1 = town:set_state(NTownTmp1, {?STATE_FIGHT, Stime, Etime}),
                        {'ok', {AddGoback1, NTown1, OClen, NAFUids}, [{Index1, NTown1}, {Index2, NewPMarch}]};
                    true ->
                        {'ok', {AddGoback1, NTownTmp1, OClen, NAFUids}, [{Index1, NTownTmp1}, {Index2, NewPMarch}]}
                end
            end,
            {AddSednGoBack2, NewTown, NewOccLen, SendFCUids} = z_db_lib:handle(TableName, Fun1, [], TableKeys),
            point_search_db:send_back_occ_line(Src, Now, 0, EndPoint, {?TOWN, TownSid}, AddSednGoBack2 ++ AddSednGoBack ++ GoBackList, OccList),
            case town:get_fight_lv(NewTown) > 0 of
                true ->
                    fighting:marching_town_after_fighting(Src, TownSid, TownDetail, SendFCUids, element(2, town:get_state(NewTown)));
                false ->%到达是免战状态,不能加入战斗状态中
                    ok
            end,
            case lists:filter(fun(OM1) -> marching:get_state(OM1) =:= ?ON_THE_TOWN_GARRISON end, OccList) of
                [] ->
                    'ok';
                _ ->
                    point_search_db:update_town_occlen(Src, TownSid, TownDetail, [{EndPoint, NewOccLen}])
            end,
            if
                RDelHp =:= NDelHp ->%玩家攻打城池后,到家,已修改为fight_port/goback接口(goback,arrive)
                    'ok';
                RDelHp =/= NDelHp andalso RDelHp >= WallHp ->
                    %血量变化
                    point_search_db:update_townhp(Src, TownSid, TownDetail, NewTown),
                    {Now, NewTown};
                true ->
                    if
                        EventBool ->
                            Table = game_lib:get_table(Src, 'point_march'),
                            PUid = get_min_etime_puid(Table, TownDetail, Now),
                            if
                                PUid > 0 ->
                                    zm_event:notify(Src, 'around_fight', [{'pm_uids', [PUid]}]); %战斗;
                                true ->%还继续战斗时候不推送血量变化
                                    if
                                        RDelHp =/= NDelHp ->%血量变化
                                            point_search_db:update_townhp(Src, TownSid, TownDetail, NewTown),
                                            'ok';
                                        true ->
                                            ok
                                    end
                            end;
                        true ->
                            'ok'
                    end
            end;
        {'ok', NewTown} ->
            {Now, NewTown}
    end.

%% ----------------------------------------------------
%% @doc
%%     取出1个需要战斗的点,不能添加容错的2s时间
%% @end
%% ----------------------------------------------------
get_min_etime_puid(Table, TownDetail, Now) ->
    z_lib:foreach(fun(A, Uid) ->
        get_min_etime_puid_(Table, Uid, A, Now)
    end, 0, tuple_to_list(town_detail:get_points(TownDetail, 0))).
get_min_etime_puid_(Table, Uid, A, Now) ->
    case z_db_lib:get(Table, Uid, 'none') of
        'none' ->
            {'ok', A};
        PM ->
            %%goback的不作为判断是否还继续战斗的条件,否则(很近的一个点会处理两次,血量不变化)
            case element(1, point_march:get_arrive(point_march:get_marchies(PM), Now, false)) =/= [] orelse
                element(1, point_march:get_arrive(lists:filter(fun(M) ->
                    marching:get_state(M) =/= ?ON_THE_TOWN_GARRISON end, point_march:get_occupy(PM)), Now, false)) =/= [] of
                true ->
                    {'break', Uid};
                false ->
                    {'ok', A}
            end
    end.

%% ----------------------------------------------------
%% @doc
%%     攻击城墙造成伤害
%% @end
%% ----------------------------------------------------
get_wall_attack(Src, FightRole, OWallHpCoe, Now) ->
    Attack = z_lib:foreach(fun(A, Fighter) ->
        {'ok', A + fighter:get_attack(Fighter)} end, 0, fighter:get_fighters(FightRole)),
    {OAttack, Speed} = case fighter:get_ordnance(FightRole) of
        {} -> {0, 10000};
        Ordnance ->
            {_, _, _, S} = zm_config:get('study_attrs', {fighter:get_o_sid(Ordnance), fighter:get_o_level(Ordnance)}),
            {fighter:get_o_attack(Ordnance), S}
    end,
    %speed是扩大了10000倍
    R = (Attack + ((OAttack * 10000 div Speed) * OWallHpCoe div 10000)) div 10000,
    %晚上对攻城效率的影响
    case times_set_lib:check_func_open(Src, ?DAY_AND_NIGHT) andalso role_addition:get_day_or_night(Now) =:= 'night_time' of
        true ->
            {_, Per} = zm_config:get('season', 'tiem_buff_town'),
            R * Per div 10000;
        false ->
            R
    end.

%% ----------------------------------------------------
%% @doc
%%     城墙战报
%% @end
%% ----------------------------------------------------
wall_report(Src, TownSid, EndPoint, Marching, Hp, WallHp, FightRole, Winner, ReportView, TownLv) ->
    zm_event:notify(Src, 'town_wall_report', [
        {'role_uid', marching:get_roleuid(Marching)},
        {'time', marching:get_etime(Marching)},
        {'point_int', EndPoint},
        {'town_sid', TownSid},
        {'town_lv', TownLv},
        {'winner', Winner},
        {'hp', {Hp, WallHp}},
        {'fight_role', FightRole},
        {'view', ReportView}
    ]),
    ok.

%% ----------------------------------------------------
%% @doc
%%     战斗持续时间达到，战斗结束
%% @end
%% ----------------------------------------------------
over(Src, TownSid, OverTime, _OldTown, Ahead) ->
    log_lib:log_gm(?MODULE, 'over', [{line, ?LINE}, {'town_sid', TownSid}, {'ahead', Ahead}, {time, time_lib:now_second()}, {town, _OldTown}, {bk, erlang:get_stacktrace()}]),
    TownDetail = town_detail:get_cfg(TownSid),
    Points = town_detail:get_points(TownDetail, 0),
    PointUids = tuple_to_list(Points),
    if
        Ahead ->%提前结算,其他点都不进行战斗,忽略
            'ok';
        true ->
            TownTable = game_lib:get_table(Src, 'town'),
            TInit = town:init(TownDetail),
            UpFun = fun(State, Town1) ->
                {OSTate, St, Et} = town:get_state(Town1),%%城池行军后,停服很久(保护状态,直接进入结束中(城池未开启战斗状态))
                {StartBool, Town2} =
                    case (OSTate =:= ?STATE_PROTECT orelse OSTate =:= ?STATE_NOR) andalso town:get_fight_lv(Town1) =:= 0 of%不在战斗状态
                        true ->
                            Country = town:get_country(Town1),
                            {TownMaxHpAdd, TownNpcAttrs} = role_addition:get_country_add_town_addition(Src, Country),
                            {true, town:start_fight(Src, TownSid, TownDetail, Town1, TownMaxHpAdd, TownNpcAttrs, OverTime)};
                        _ ->
                            {false, Town1}
                    end,
                NTown1 = town:set_state(Town2, {State, St, Et}),
                NTown = case State =:= ?STATE_FIGHT_OVER_FIGHTING of
                    true ->
                        town:set_over_time(NTown1, time_lib:now_second() + ?PMARCH_FIGHT_TIMEOUT * 2);
                    false ->
                        town:set_over_time(NTown1, time_lib:now_second() + ?PMARCH_FIGHT_TIMEOUT)
                end,
                {'ok', {StartBool, NTown}, NTown}
            end,
            {SBool, Town} = z_db_lib:update(TownTable, TownSid, TInit, UpFun, ?STATE_FIGHT_OVER_FIGHTING),
            if
                SBool ->
                    fight_db:add_fight_assist(Src, element(1, Points), marching:set_stime(marching:set_etime(marching:init(none, none, none, none, none, none, none), element(3, town:get_state(Town))), 0)),
                    zm_event:notify(Src, 'bi_fight_town_start', [{'town_sid', TownSid}, {'town', Town}]);
                true ->
                    ok
            end,
            FightLv = town:get_fight_lv(Town),
            FightBool = town:chk_fight(Town),
            if
                FightBool orelse FightLv > 0 ->
                    TownLv = if
                        FightLv > 0 ->
                            FightLv;
                        true ->
                            town:get_lv(Town, TownDetail)
                    end,
                    WallHpAdd = town:get_wall_hp_add(Town),
                    WallHp = town_detail:get_wall_hp(Src, TownLv, WallHpAdd, TownDetail),
                    case town:get_del_wall_hp(Town) >= WallHp of
                        true ->
                            %%全部点跑一次战斗,存在点未跑完情况,执行勒over,然后再次执行over导致状态不对
                            lists:foreach(fun(ArriveEndPoint) ->
                                fighting:town_fighting(TownSid, OverTime, ArriveEndPoint, Src, ?MODULE, 'fighting', {?TOWN, TownSid}, Town, [])
                            end, PointUids);
                        false ->
                            PMTable = game_lib:get_table(Src, 'point_march'),
                            F = fun(PointUid) ->
                                {_, PUid} = get_min_etime_puid_(PMTable, PointUid, 0, OverTime),
                                if
                                    PUid > 0 ->
                                        del_wall_hp(Src, OverTime, TownSid, PUid, TownDetail, [], false, get_town_corps_builds(Src, TownSid, Town));
                                    true ->
                                        'ok'
                                end
                            end,
                            lists:foreach(F, PointUids)
                    end;
                true ->
                    'ok'
            end,
            z_db_lib:update(TownTable, TownSid, TInit, UpFun, ?STATE_FIGHT_OVER)
    end,
    Len1 = tuple_size(Points),
    Chief = town_detail:chk_chief(TownDetail),
    First = town_db:check_firt(Src, TownSid),
    do_over(Len1, Src, TownSid, TownDetail, OverTime, Chief, First).

%% ----------------------------------------------------
%% @doc
%%      判断是否提前结束城池战斗,所有点归属同一方时候结束
%% @end
%% ----------------------------------------------------
fighting_chk_over(TownDetail, Town) ->
    Len = tuple_size(town_detail:get_points(TownDetail, 0)),
    POwners = town:get_points_owner(Town),
    Len =:= length(POwners) andalso length(ower_list(POwners)) =:= 1.

%% ----------------------------------------------------
%% @doc
%%     城池结束
%% @end
%% ----------------------------------------------------
do_over(Len1, Src, TownSid, TownDetail, OverTime, IsChief, First) ->
    TownName = town_detail:get_name(TownDetail),
    {X, Y} = point_lib:int2xy(town_detail:get_point(TownDetail)),
    Table = game_lib:get_table(Src, 'town'),
    Fun = fun(_, Town) ->
        FightLevel = town:get_fight_lv(Town),
        FightBool = town:chk_fight(Town),
        Reply =
            if
                FightBool orelse FightLevel > 0 ->
                    TownLv = if
                        FightLevel > 0 ->
                            FightLevel;
                        true ->
                            town:get_lv(Town, TownDetail)
                    end,
                    WallHpAdd = town:get_wall_hp_add(Town),
                    WallHp = town_detail:get_wall_hp(Src, TownLv, WallHpAdd, TownDetail),
                    get_own_change(Town, WallHp, Len1);
                true -> %不在战斗中
                    throw("ok")
            end,
        {'ok', {Reply, Town}}
    end,
    case z_db_lib:update(Table, TownSid, Fun, []) of
        {'nochange', OldTown} ->
            log_lib:log_gm(?MODULE, 'over_nochange', [{line, ?LINE}, {'town_sid', TownSid}, {time, time_lib:now_second()}, {town, OldTown}]),
            FightCorpsUids = town:get_fight_uids(OldTown),
            TcorpsUid = town:get_corps_uid(OldTown),
            {PMarchies, PUids} =
                z_lib:foreach(fun({Ts, Ps}, {P, Pcorpsuid}) ->
                    if
                        Pcorpsuid =:= TcorpsUid ->
                            {'ok', {Ts, Ps}};
                        true ->
                            {'ok', {[{'point_march', P, point_march:init()} | Ts], [P | Ps]}}
                    end
                end, {[], []}, town:get_points_owner(OldTown)),
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'town', TownSid} | PMarchies]),
            CorpsMembers = corps_db:get_corps_members(Src, TcorpsUid),
            F1 = fun(_, [{I1, Town1} | Marchies]) ->
                NewTown = town:lose_fight(Town1),
                {PMReply, SendGoBacks} =
                    z_lib:foreach(fun({Pma, GoList}, {PointUid, {Im, PMarch}}) ->
                        case point_march:get_occupy(PMarch) of
                            [] ->
                                {'ok', {Pma, GoList}};
                            OccList ->
                                {NOccList, GoBackList} =
                                    z_lib:foreach(fun({OccAcc, BKAcc}, Marching) ->
                                        case lists:member(marching:get_roleuid(Marching), CorpsMembers) of
                                            true ->
                                                {ok, {[Marching | OccAcc], BKAcc}};
                                            false ->
                                                Gm = marching:change_goback_byetime_state(Marching, PointUid, OverTime, ?ON_THE_TOWN_GOBACK),
                                                {ok, {OccAcc, [Gm | BKAcc]}}
                                        end
                                    end, {[], []}, OccList),
                                UpPm = [{Im, point_march:set_occupy(point_march:set_goback(PMarch, GoBackList ++ point_march:get_goback(PMarch)), lists:reverse(NOccList))} | Pma],
                                {'ok', {UpPm, [{PointUid, GoBackList} | GoList]}}
                        end
                    end, {[], []}, lists:zip(PUids, Marchies)),
                {'ok', {NewTown, SendGoBacks}, [{I1, NewTown} | PMReply]}
            end,
            {Retown, PuidGoBLines} = z_db_lib:handle(TableName, F1, [], TableKeys),
            clear_corps_fighting(Src, TownSid, lists:usort([TcorpsUid | FightCorpsUids]), IsChief),
            chat_lib:notice_corps(Src, 'town_fight_guard', [town:get_lv(OldTown, TownDetail), TownName, X, Y], TcorpsUid),
            Now = time_lib:now_second(),
            EndPState = {?TOWN, TownSid},
            lists:foreach(fun({EndPUid, GMarchings}) ->
                point_search_db:send_back_occ_line(Src, Now, 0, EndPUid, EndPState, GMarchings, [])
            end, PuidGoBLines),
            %城池未变化也推送,让前台将战斗中城池去掉
            CorpsName =
                if
                    TcorpsUid > 0 ->
                        corps:get_name(corps_db:get_corps(Src, TcorpsUid));
                    true ->
                        ""
                end,
            set_front_lib:send_town_owner(Src, TownSid, Retown, CorpsName),
            point_search_db:update_towninfo(Src, TownSid, TownDetail, Retown, [{Puid, 0} || Puid <- PUids]),
            TownLv = town:get_lv(OldTown, TownDetail),
            Country = town:get_country(OldTown),
            case TcorpsUid =/= 0 of
                true ->
                    lists:foreach(fun(CUid) ->
                        Corps = corps_db:get_corps(Src, CUid),
                        case Corps =/= 'none' of
                            true ->
                                %%因为 FightCorpsUids 中存有防守方的公会UID，所以这里要检测一次，
                                if
                                    CUid =:= TcorpsUid ->
                                        ok;
                                    true ->
                                        CorpsLog1 = corps_log:town_defend_fight(1, corps:get_name(Corps), corps:get_country(Corps), TownSid, TownLv),
                                        corps_db:insert_corps_log(Src, TcorpsUid, CorpsLog1),
                                        CorpsLog2 = corps_log:town_fight(0, CorpsName, Country, TownSid, TownLv, 0),
                                        corps_db:insert_corps_log(Src, CUid, CorpsLog2)
                                end;
                            false ->
                                ok
                        end
                    end, FightCorpsUids);
                false ->
                    lists:foreach(fun(CUid) ->
                        CorpsLog2 = corps_log:town_fight(0, CorpsName, Country, TownSid, TownLv, 0),
                        corps_db:insert_corps_log(Src, CUid, CorpsLog2)
                    end, FightCorpsUids)
            end,
            zm_event:notify(Src, 'bi_fight_town_end', [{'town_sid', TownSid}, {'win', 0}, {'town', Retown}, {'end_lv', TownLv}]),
            point_db:del_fight_town(Src, TownSid, 0),
            town_db:clear_first_rank(TownSid),
            ok;
        {NewCorpsUid, OldTown} ->
            log_lib:log_gm(?MODULE, 'over_change', [{line, ?LINE}, {'town_sid', TownSid}, {'ncorps', NewCorpsUid}, {time, time_lib:now_second()}, {town, OldTown}]),
            OldCorpsUid = town:get_corps_uid(OldTown),
            FightCorpsUids = town:get_fight_uids(OldTown),
%%            POwners = town:get_points_owner(OldTown),
            LookPUid = town_detail:get_point(TownDetail),
            %由于现在所有点都占领之后才可以城战胜利,故,不存在还有点有其他军团驻防,只需要处理寻访即可
            TPowers = [{LookPUid, OldCorpsUid}],
%%                case lists:keyfind(LookPUid, 1, POwners) of
%%                    false ->
%%                        [{LookPUid, OldCorpsUid} | POwners]; %城池归属变化之后,需要将寻访信息返回
%%                    _ ->
%%                        POwners
%%                end,
            PMInit = point_march:init(),
            {PMarchies, PUids} = z_lib:foreach(fun({Ts, Ps}, {P, _}) ->
                {'ok', {[{'point_march', P, PMInit} | Ts], [P | Ps]}} end, {[], []}, TPowers),
            CTownInit = corps_town:init(),
            TableName = game_lib:get_table(Src),
            TableKeys =
                if
                    OldCorpsUid =:= 0 ->
                        z_db_lib:transformation_tablekey(TableName, [{'town', TownSid}, {'corps_town', NewCorpsUid, CTownInit} | PMarchies]);
                    true ->
                        z_db_lib:transformation_tablekey(TableName, [{'town', TownSid}, {'corps_town', NewCorpsUid, CTownInit},
                            {'corps_town', OldCorpsUid, CTownInit} | PMarchies])
                end,
            CorpsMembers = corps_db:get_corps_members(Src, NewCorpsUid),
            Corps = corps_db:get_corps(Src, NewCorpsUid),
            F1 = fun(_, [{I1, Town1}, {I4, CTown} | RestCCity]) ->
                Country = corps:get_country(Corps),
                NowNum = corps_town:get_num(CTown) + corps_town:get_cnum(CTown),
                MaxTNum = role_addition:get_corps_town_max_num(Src, Corps),
                %%特殊处理洛阳,不受限制
                {_, CycleList} = zm_config:get('cycle_town_info', 'cycle_city'),
                CycleBool = lists:member(TownSid, CycleList),
                {NewTown, WinCorpsUid} =
                    if
                        NowNum >= MaxTNum andalso not CycleBool ->%达到上限城池归属npc,并且不是洛阳
                            {town:win_fight(Town1, TownDetail, OverTime, 0, 0), 0};
                        true ->
                            {town:win_fight(Town1, TownDetail, OverTime, Country, NewCorpsUid), NewCorpsUid}
                    end,
                {UpCityList, Marchies} =
                    if
                        OldCorpsUid =:= 0 andalso OldCorpsUid =:= WinCorpsUid ->%军团城池上限,回归npc
                            {[], RestCCity};
                        OldCorpsUid =/= 0 andalso WinCorpsUid =:= 0 ->%军团城池上限,回归npc
                            [{I5, OldCTown} | RelRestCTown] = RestCCity,
                            {[{I5, corps_town:del_olist(OldCTown, TownSid, IsChief, TownDetail)}], RelRestCTown};
                        OldCorpsUid =:= 0 ->
                            {[{I4, corps_town:add_olist(CTown, TownSid, IsChief, TownDetail, NewTown)}], RestCCity};
                        true ->
                            [{I5, OldCTown} | RelRestCTown] = RestCCity,
                            {[{I4, corps_town:add_olist(CTown, TownSid, IsChief, TownDetail, NewTown)},
                                {I5, corps_town:del_olist(OldCTown, TownSid, IsChief, TownDetail)}], RelRestCTown}
                    end,
                {PMReply, SendGoBacks} =
                    z_lib:foreach(fun({Pma, GoList}, {PointUid, {Im, PMarch}}) ->
                        case point_march:get_occupy(PMarch) of
                            [] ->
                                {'ok', {Pma, GoList}};
                            OccList ->
                                {NOcc, GoBackList} =
                                    z_lib:foreach(fun({Acc1, Acc2}, Om) ->
                                        case lists:member(marching:get_roleuid(Om), CorpsMembers) of
                                            true ->
                                                {'ok', {[Om | Acc1], Acc2}};
                                            false ->
                                                OmState = marching:get_state(Om),
                                                LookState = look_fight:looking_state(OmState),
                                                OGo = if
                                                    LookState ->
                                                        marching:change_goback(Om, PointUid, OverTime, ?ON_THE_LOOK_GOBACK_TOWN);
                                                    true ->
                                                        marching:change_goback_byetime_state(Om, PointUid, OverTime, ?ON_THE_TOWN_GOBACK)
                                                end,
                                                {'ok', {Acc1, [OGo | Acc2]}}
                                        end
                                    end, {[], []}, OccList),
                                UpPm = [{Im, point_march:set_occupy(point_march:set_goback(PMarch, GoBackList ++ point_march:get_goback(PMarch)), lists:reverse(NOcc))} | Pma],
                                {'ok', {UpPm, [{PointUid, GoBackList} | GoList]}}
                        end
                    end, {[], []}, lists:zip(PUids, Marchies)),
                {'ok', {NewTown, Country, WinCorpsUid, SendGoBacks, NowNum >= MaxTNum andalso not CycleBool}, [{I1, NewTown} | UpCityList ++ PMReply]}
            end,
            {Retown, RCountry, RCorpsUid, PuidGoBLines, IsMaxFlag} = z_db_lib:handle(TableName, F1, [], TableKeys),
            log_lib:log_gm(?MODULE, 'over_result', [{line, ?LINE}, {'town_sid', TownSid}, {'ncorps', RCorpsUid}, {'is_max', IsMaxFlag}, {time, time_lib:now_second()}, {town, Retown}]),
            clear_corps_fighting(Src, TownSid, FightCorpsUids, IsChief),%达到上限的未删除战斗中,状态,故此处直接全部战斗corpsuids传参
            Now = time_lib:now_second(),
            EndPState = {?TOWN, TownSid},
            ReplyGoBack =
                if
                    RCorpsUid > 0 ->
                        zm_event:notify(Src, {'corps_level_influence_rank', RCountry}, [{'uid', RCorpsUid}]),
                        zm_event:notify(Src, 'active_event', {'active_corps_town_score', [{'corps_uid', NewCorpsUid}]}),
                        zm_event:notify(Src, 'active_event', {'active_corps_town_rank', [{'corps_uid', NewCorpsUid}, {'town_detail', TownDetail}]}),
                        PuidGoBLines;
                    true ->
                        %达到上限,划归npc所属,所有驻防的队伍回城
                        MarchTable = game_lib:get_table(Src, 'point_march'),
                        z_lib:foreach(fun(PAcc11, Puid) ->
                            z_db_lib:update(MarchTable, Puid, none, fun(PAcc2, none) ->
                                {ok, PAcc2};
                                (PAcc2, PMarch) ->
                                    case point_march:get_occupy(PMarch) of
                                        [] ->
                                            {'ok', PAcc2};
                                        OccList ->
                                            {NOcc, GoBackList} =
                                                z_lib:foreach(fun({Acc1, Acc2}, Om) ->
                                                    OmState = marching:get_state(Om),
                                                    LookState = look_fight:looking_state(OmState),
                                                    OGo = if
                                                        LookState ->
                                                            marching:change_goback(Om, Puid, OverTime, ?ON_THE_LOOK_GOBACK_TOWN);
                                                        true ->
                                                            marching:change_goback_byetime_state(Om, Puid, OverTime, ?ON_THE_TOWN_GOBACK)
                                                    end,
                                                    {'ok', {Acc1, [OGo | Acc2]}}
                                                end, {[], []}, OccList),
                                            NPMarchBack = point_march:check_del(point_march:set_occupy(point_march:set_goback(PMarch, GoBackList ++ point_march:get_goback(PMarch)), lists:reverse(NOcc))),
                                            {'ok', [{Puid, GoBackList} | PAcc2], NPMarchBack}
                                    end
                            end, PAcc11)
                        end, PuidGoBLines, tuple_to_list(town_detail:get_points(TownDetail, 0)))
                end,
            lists:foreach(fun({EndPUid, GMarchings}) ->
                point_search_db:send_back_occ_line(Src, Now, 0, EndPUid, EndPState, GMarchings, [])
            end, ReplyGoBack),
            if
                OldCorpsUid > 0 ->
                    zm_event:notify(Src, {'corps_level_influence_rank', town:get_country(OldTown)}, [{'uid', OldCorpsUid}]),
                    zm_event:notify(Src, 'active_event', {'active_corps_town_score', [{'corps_uid', OldCorpsUid}]});
                true ->
                    ok
            end,
            CorpsName = corps:get_name(Corps),
            TownLevel = town:get_lv(Retown, TownDetail),
            if
                RCorpsUid > 0 ->
                    set_front_lib:send_town_owner(Src, TownSid, Retown, CorpsName),
                    TownType = town_detail:get_type(TownDetail),
                    TownTypeName = fight_db:get_town_type_name(TownType),
                    %% 广播
                    CfgName =
                        if
                            First ->%首次占领
                                chat_lib:notice_corps(Src, 'town_fight_win_corps_first', [TownTypeName, TownLevel, TownName, X, Y], NewCorpsUid),
                                CArgs = [fight_db:get_country_name(RCountry), fight_db:get_country_color(RCountry, CorpsName), TownTypeName, TownLevel, TownName, X, Y],
                                chat_lib:notice_world(Src, 'town_fight_win_first', CArgs),
                                chat_lib:notice_country(Src, 'town_fight_win_first', CArgs, RCountry),
                                'town_fight_win_broadcast_first';
                            true ->
                                chat_lib:notice_corps(Src, 'town_fight_win_corps', [TownTypeName, TownLevel, TownName, X, Y], NewCorpsUid),
                                CArgs = [fight_db:get_country_name(RCountry), fight_db:get_country_color(RCountry, CorpsName), TownTypeName, TownLevel, TownName, X, Y],
                                chat_lib:notice_world(Src, 'town_fight_win', CArgs),
                                chat_lib:notice_country(Src, 'town_fight_win', CArgs, RCountry),
                                'town_fight_win_broadcast'
                        end,
                    zm_event:notify(Src, 'broadcast', {'town_fight',
                        [
                            {'cfg_name', CfgName},
                            {'country', RCountry},
                            {'town_type', TownType},
                            {'corps_name', CorpsName},
                            {'town_level', TownLevel},
                            {'town_name', TownName}]}),
                    %% 聊天
                    town_db:add_town_event(Src, 'town_fight_win', TownSid, Retown, Corps);
                true ->
                    set_front_lib:send_town_owner(Src, TownSid, Retown, ""),%上限后推送军团名字错误
                    ok
            end,
            %无论是否划归自己都需要更新地图信息
            point_db:update_map_towninfo(Src, OldCorpsUid, RCorpsUid, TownSid, Retown),
            role_addition:set_corps_bufflist(OldCorpsUid, 'none'),%更新军团城池后,buff信息
            role_addition:set_corps_bufflist(RCorpsUid, 'none'),%更新军团城池后,buff信息
            if
                IsChief ->
                    ok;
                true ->
                    chk_over_goback(Src, TownSid, TownDetail, OldCorpsUid, RCorpsUid, OverTime)
            end,
            if
                First ->
                    if
                        RCorpsUid > 0 -> %达到上限后首杀,城池会划归npc处理(即,达到上限后不可获得首杀奖励)
                            FirstValue = town_db:send_first_award(Src, TownSid, RCorpsUid, Corps, TownName, TownLevel, true),
                            point_search_db:update_towninfo(Src, TownSid, TownDetail, Retown, FirstValue);
                        true ->
                            point_search_db:update_towninfo(Src, TownSid, TownDetail, Retown)
                    end;
                true ->
                    point_search_db:update_towninfo(Src, TownSid, TownDetail, Retown)
            end,
            OldCountry = town:get_country(OldTown),
            case OldCorpsUid =/= 0 of
                true ->
                    OCorpsName = corps:get_name(corps_db:get_corps(Src, OldCorpsUid)),
                    z_lib:foreach(fun(R, CUid) ->
                        CCorps = corps_db:get_corps(Src, CUid),
                        case CCorps =/= 'none' of
                            true ->
                                case CUid =/= OldCorpsUid of
                                    true ->
                                        %%城池防守失败
                                        CorpsLog1 = corps_log:town_defend_fight(0, corps:get_name(CCorps), corps:get_country(CCorps), TownSid, TownLevel),
                                        corps_db:insert_corps_log(Src, OldCorpsUid, CorpsLog1);
                                    false ->
                                        ok
                                end,
                                %%城池进攻成功失败
                                case CUid =:= NewCorpsUid of
                                    true ->
                                        FullFlag =
                                            case RCorpsUid =:= 0 of
                                                true ->
                                                    1;
                                                false ->
                                                    0
                                            end,
                                        CorpsLog2 = corps_log:town_fight(1, OCorpsName, OldCountry, TownSid, TownLevel, FullFlag),
                                        corps_db:insert_corps_log(Src, CUid, CorpsLog2);
                                    false ->
                                        case CUid =/= OldCorpsUid of
                                            true ->
                                                CorpsLog2 = corps_log:town_fight(0, OCorpsName, OldCountry, TownSid, TownLevel, 0),
                                                corps_db:insert_corps_log(Src, CUid, CorpsLog2);
                                            false ->
                                                ok
                                        end
                                end;
                            false ->
                                ok
                        end,
                        {ok, R}
                    end, [], FightCorpsUids);
                false ->
                    z_lib:foreach(fun(R, CUid) ->
                        %%城池进攻成功失败
                        case CUid =:= NewCorpsUid of
                            true ->
                                FullFlag =
                                    case RCorpsUid =:= 0 of
                                        true ->
                                            1;
                                        false ->
                                            0
                                    end,
                                CorpsLog2 = {?CORPS_LOG_TYPE_TOWN_FIGHT, 1, CorpsName, OldCountry, TownSid, TownLevel, FullFlag, Now},
                                corps_db:insert_corps_log(Src, CUid, CorpsLog2);
                            false ->
                                CorpsLog2 = {?CORPS_LOG_TYPE_TOWN_FIGHT, 0, CorpsName, OldCountry, TownSid, TownLevel, Now},
                                corps_db:insert_corps_log(Src, CUid, CorpsLog2)
                        end,
                        {ok, R}
                    end, [], FightCorpsUids)
            end,
            %%洛阳城周期占领事件
            if
                RCorpsUid > 0 ->%%城池被军团占领
                    {_, CityList} = zm_config:get(cycle_town_info, cycle_city),%%具有周期性的城池sid
                    case lists:member(TownSid, CityList) of
                        true ->
                            zm_event:notify(Src, 'cycle_town', [{'town_sid', TownSid}, {'old_corps_uid', OldCorpsUid}, {'corps_uid', RCorpsUid}]);
                        _ -> ok
                    end;
                true -> ok
            end,
            zm_event:notify(Src, 'town_owner_change', [{'town_sid', TownSid}, {'old_corps_uid', OldCorpsUid}, {'old_country', OldCountry},
                {'corps_uid', RCorpsUid}, {'country', RCountry}, {'town_detail', TownDetail}, {'town', Retown}]),%魏蜀吴王等(RCorpsUid=0表示城池上限归npc所有)
            zm_event:notify(Src, 'bi_fight_town_end', [{'town_sid', TownSid}, {'win', 1}, {'town', Retown}, {'end_lv', TownLevel}]),
            point_db:del_fight_town(Src, TownSid, 0),
            map_build_db:del_map_build(Src, TownSid, OldCorpsUid),
            %%攻城胜利的公会新增战报
            town_db:send_town_fight_mail(Src, TownSid, RCorpsUid, Corps, TownName, TownLevel),
            town_db:clear_first_rank(TownSid),
            map_build_db:clear_mb_fight_num(Src, OldCorpsUid, TownSid),
            'ok';
        _ ->%未在战斗状态
            'ok'
    end.

%% ----------------------------------------------------
%% @doc
%%     判断是否切换拥有者
%% @end
%% ----------------------------------------------------
get_own_change(Town, WallHp, Len1) ->
    case town:get_del_wall_hp(Town) < WallHp of
        true ->
            'nochange';
        false ->
            TPowers = town:get_points_owner(Town),
            Len2 = length(TPowers),
            if
                Len1 =:= Len2 ->%所有点都被占领
                    case ower_list(TPowers) of
                        [{CValue, _}] ->%目前规则修改为,只有所有点被同一军团占领则算胜利
                            CValue;
                        _ ->
                            'nochange'
                    end;
                true ->%防守方还存在占有点,则防守方胜利,所属都不变化
                    'nochange'
            end
    end.

%% ----------------------------------------------------
%% @doc
%%     如果是普通城池所属变化，需要判断郡首城池是否返回
%% @end
%% ----------------------------------------------------
chk_over_goback(Src, TownSid, TownDetail, OldOwner, NewOwner, Time) ->
    if
        OldOwner > 0 andalso NewOwner > 0 andalso OldOwner =/= NewOwner ->
            CTownSid = town_detail:get_ctown_sid(TownDetail),
            CTownDetail = town_detail:get_cfg(CTownSid),
            TownTmp = z_db_lib:get(game_lib:get_table(Src, 'town'), CTownSid, town:init(CTownDetail)),
            case lists:member(OldOwner, town:get_fight_uids(TownTmp)) of
                true ->
                    CityDetail = city_detail:get_cfg(town_detail:get_city(TownDetail)),
                    TownLv = town:get_lv(TownTmp, CTownDetail),
                    TownName = town_detail:get_name(CTownDetail),
                    {X, Y} = point_lib:int2xy(town_detail:get_point(CTownDetail)),
                    case town:get_points_owner(TownTmp) of
                        [] ->
                            'ok';
                        List ->
                            case lists:keyfind(OldOwner, 2, List) of
                                false ->
                                    ok;
                                _ ->%需要检测是否返回
                                    case point_db:check_fight_chief(Src, OldOwner, corps:get_country(corps_db:get_corps(Src, OldOwner)), CTownDetail) of
                                        false ->
                                            NeedNum = town_detail:get_normat_num(CTownDetail),
                                            TownTypeName = fight_db:get_town_type_name(town_detail:get_type(CTownDetail)),
                                            chat_lib:notice_corps(Src, 'town_fight_nor_num', [city_detail:get_name(CityDetail), NeedNum, TownTypeName, TownLv, TownName, X, Y], OldOwner),
                                            %郡首城池是否可攻打
                                            {GoBackCCUids, NewTown} =
                                                z_db_lib:update(game_lib:get_table(Src, 'town'), CTownSid, town:init(CTownDetail), fun(_, Town) ->
                                                    CCUids = town:get_points_owner(Town),
                                                    {GBList, NCCUids} = lists:partition(fun({_, CU}) ->
                                                        CU =:= OldOwner end, CCUids),
                                                    Npc = town:get_npc_state(Town),
                                                    NpcRefresh = town:get_npc_refresh_time(Town),
                                                    {NewNpc, NewRefreshNpc} = lists:foldl(fun({Puid, _}, {Acc0, Acc1}) ->
                                                        {lists:keydelete(Puid, 1, Acc0), lists:keydelete(Puid, 1, Acc1)}
                                                    end, {Npc, NpcRefresh}, GBList),
                                                    Ntown = town:set_points_owner(town:set_npc_state(town:set_npc_refresh_time(Town, NewRefreshNpc), NewNpc), NCCUids),
                                                    {ok, {GBList, Ntown}, Ntown}
                                                end, []),
                                            DelOccLen =
                                                if
                                                    GoBackCCUids =/= [] ->
                                                        Now = time_lib:now_second(),
                                                        F2 = fun(A, {PointUid, _}) ->
                                                            AddGoBackMarchings = z_db_lib:update(game_lib:get_table(Src, 'point_march'), PointUid, point_march:init(),
                                                                fun(_, PointMarch) ->
                                                                    AddList = [marching:change_goback_byetime_state(M, PointUid, Time, ?ON_THE_TOWN_GOBACK) || M <- point_march:get_occupy(PointMarch)],
                                                                    NPointMarch = point_march:set_occupy(point_march:set_goback(PointMarch, AddList ++ point_march:get_goback(PointMarch)), []),
                                                                    {ok, AddList, NPointMarch}
                                                                end, []),
                                                            point_search_db:send_back_occ_line(Src, Now, 0, PointUid, {?TOWN, TownSid}, AddGoBackMarchings, []),
                                                            {'ok', [{PointUid, 0} | A]}
                                                        end,
                                                        z_lib:foreach(F2, [], GoBackCCUids);
                                                    true ->
                                                        []
                                                end,
                                            point_search_db:update_towninfo(Src, CTownSid, CTownDetail, NewTown, DelOccLen);
                                        true ->
                                            ok
                                    end
                            end
                    end;
                false ->
                    'ok'
            end;
        true ->
            'ok'
    end.

%% ----------------------------------------------------
%% @doc
%%      战斗结束时候,按占有城池数量排序
%% @end
%% ----------------------------------------------------
-spec ower_list(POwners :: [{integer(), integer()}]) -> [{integer(), integer()}].
ower_list(POwners) ->
    F = fun(Args, {_, CValue}) ->
        times_set_lib:update(Args, {CValue, 1})
    end,
    lists:sort(fun({_, V1}, {_, V2}) -> V1 > V2 end, z_lib:foreach(F, [], POwners)).

%% ----------------------------------------------------
%% @doc
%%      空战报(保护冷却状态;守军上限回城)
%% @end
%% ----------------------------------------------------
null_report(Src, EndPoint, Marching, RType, Extra) ->
    zm_event:notify(Src, 'fight_null_report', [
        {'role_uid', marching:get_roleuid(Marching)},
        {'point_int', EndPoint},
        {'time', marching:get_etime(Marching)},
        {'r_type', RType},
        {'id', Extra}]).

%% ----------------------------------------------------
%% @doc
%%      默认npc为第一波,且没有损失血
%% @end
%% ----------------------------------------------------
default_npc_state() ->
    {1, []}.

%% ----------------------------------------------------
%% @doc
%%      判断当前npc是否死亡.
%% @end
%% ----------------------------------------------------
-spec chk_npc_dead(Town :: town:town(), NpcState :: {integer(), [{integer(), integer(), integer()}]}) -> boolean().
chk_npc_dead(Town, {Len, LastHp}) ->
    NpcArray = town:get_npc_array(Town),
    boss_fight:chk_npc_dead(NpcArray, {Len, LastHp}).

%% ----------------------------------------------------
%% @doc
%%      获取当前fight_npc
%% @end
%% ----------------------------------------------------
-spec get_fight_npc(Src :: atom(), Town :: town:town(), TownDetail :: town_detail:town_detail(), NpcState :: {integer(), [{integer(), integer(), integer()}]}) -> [fighter:battlefield()].
get_fight_npc(Src, Town, TownDetail, {Len, LastHp}) ->
    WeaPonLv = town:get_weapon_lv(Src, Town, TownDetail),
    CycleNum = town:get_cycle_num(Town),
    MFA = {fighter, addition_attrs_and_weapon, {town:get_npc_attr(Town), WeaPonLv, CycleNum}},
    boss_fight:init_fight_npc(town:get_npc_array(Town), town_detail:get_name(TownDetail), town_detail:get_exp(TownDetail), {Len, LastHp}, MFA).

%% ----------------------------------------------------
%% @doc
%%      获取城池当前npc剩余波数以及总波数
%% @end
%% ----------------------------------------------------
get_npc_len(PointUid, {_Src, TownSid, Town}) ->
    TownDetail = town_detail:get_cfg(TownSid),
    {Len, _} = z_lib:get_value(town:get_npc_state(Town), PointUid, default_npc_state()),
    CfgType = case town_detail:chk_chief(TownSid) of
        true ->
            'chief';
        false ->
            'normal'
    end,
    {_, List} = zm_config:get(town_hp, CfgType),
    {_, _, Num, _} = lists:keyfind(town:get_lv(Town, TownDetail), 1, List),
    {Num - Len + 1, Num}.


%% {NProtectList, AddPGo} = refresh_protect(Src, EndPoint, FightOcc, WaveInfos),
%% ----------------------------------------------------
%% @doc
%%     多波玩家数据更新,返回goback和新的防守信息
%% @end
%% ----------------------------------------------------
refresh_protect(Src, EndPoint, Winner, FightOcc, WaveInfos, EUidFeatsList, Etime) ->
    WaveLen = length(WaveInfos),
    {FList, RestList} = game_lib:list_split(WaveLen, FightOcc),
    F = fun(Args, {Marching, {_, {Dead, Injured, Queue}}}) ->
        {RUid, Gid} = marching:get_roleuid_gid(Marching),
        {_MarchBearLoad, MarchQueue, GarrayInjured, _, _DeductSosldierNum} =
            fighting:update_garray_after_fight(Src, Queue, {RUid, Gid}),
        Feats = z_lib:get_value(EUidFeatsList, RUid, 0),
        FeatsAward = if
            Feats > 0 ->
                [{'feats', Feats}];
            true ->
                []
        end,
        NMarching = marching:fight_result(Marching, Injured, Dead, FeatsAward),
        set_front_lib:send_map_result(Src, RUid, {Etime, EndPoint, ?TOWN, ?ROLE, Winner, Gid, {MarchQueue, Dead, Injured, GarrayInjured}, 1}),
        {'ok', [NMarching | Args]}
    end,
    [LastWave | GoBackList] = z_lib:foreach(F, [], lists:zip(FList, WaveInfos)),
    {[LastWave | RestList], [marching:change_goback_byetime_state(G, EndPoint, Etime, ?ON_THE_TOWN_GOBACK) || G <- GoBackList]}.

%% ----------------------------------------------------
%% @doc
%%    获取城池建筑军团信息
%% @end
%% ----------------------------------------------------
get_town_corps_builds(Src, TownSid, Town) ->
    CUid = town:get_corps_uid(Town),
    case CUid > 0 of %城池被占领才可能有城池建筑
        true ->
            MapBuild = map_build_db:get_map_build(Src, TownSid),
            {corps_db:get_corps(Src, CUid), map_build:get_build(MapBuild)};
        false ->
            {corps:init(0, 0, "", 0, 0), []}
    end.


%% ----------------------------------------------------
%% @doc
%%     根据城池等级,获取武器等级
%% @end
%% ----------------------------------------------------
get_weapon_lv(Src, TownLv) ->
    OnlineTime = args_system:get_online_time(Src),
    {_, List} = zm_config:get('town_npc_weapon_lv', TownLv),
    {_, Time} = zm_config:get('town_npc_weapon_lv', 'time'),
    EffectTime = z_lib:localtime_to_second(Time),
    game_lib:level_value(time_lib:now_second() - max(OnlineTime, EffectTime), List).

%% ----------------------------------------------------
%% @doc
%%     %%获得这个城池被攻占的周期次数
%% @end
%% ----------------------------------------------------
get_cycle_num(Src, TownSid) ->
    z_lib:get_value(z_db_lib:get(game_lib:get_table(Src, 'cycle_town'), TownSid, []), num, 0).


%% ----------------------------------------------------
%% @doc
%%     %%获得周期城池的血量加成
%% @end
%% ----------------------------------------------------
get_cycle_hp_add(Src, TownSid) ->
    CycleNum = get_cycle_num(Src, TownSid),
    {_, Multiple, MaxMultiple, _Expand} = zm_config:get(cycle_town_info, hp),
    min(lists:sum(lists:duplicate(CycleNum, Multiple)), MaxMultiple).
