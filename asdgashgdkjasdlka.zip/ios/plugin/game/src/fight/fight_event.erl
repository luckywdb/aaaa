-module(fight_event).

%%%=======================STATEMENT====================
-description("fight_event").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    around_fight/4,
    around_fight_now/2,
    logout/4,
    town_up_level/4,
    fight_assist/3
]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").
-include("../../../include/sign_key.hrl").

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      坐标周围战斗
%% @end
%% ----------------------------------------------------
-spec around_fight(_, atom(), 'around_fight', list()) -> 'ok'.
around_fight(_, Src, 'around_fight', KVList) ->
    PMarchUids = z_lib:get_value(KVList, 'pm_uids', []),
    %处理战斗
    around_fight_now(Src, PMarchUids).

%% ----------------------------------------------------
%% @doc
%%     立即战斗
%% @end
%% ----------------------------------------------------
around_fight_now(_Src, []) ->
    'ok';
around_fight_now(Src, PMarchUids) ->
    PStates = z_db_lib:gets(game_lib:get_table(Src, 'point_state'), PMarchUids),
%%    io:format("~p~n", [{?MODULE, ?LINE, [PMarchUids, PStates]}]),
    lists:foreach(fun
        ({PMUid, PState}) ->
            PInfo = point_state_db:point_state2info(PMUid, PState),
%%            io:format("~p~n", [{?MODULE, ?LINE, [PMUid, PInfo]}]),
            fighting:arrive(Src, PMUid, PInfo, [])
    end, lists:zip(PMarchUids, PStates)).

%% ----------------------------------------------------
%% @doc
%%      玩家离线,将玩家所看的点移除出看着的列表
%% @end
%% ----------------------------------------------------
-spec logout(_, atom(), Type, list()) -> 'ok' when
    Type :: 'logout'|'relogin'.
logout(_, Src, Type, KVList) when Type =:= 'logout';Type =:= 'relogin' ->
    RoleUid = z_lib:get_value(KVList, 'role_uid', 0),
    case role_db:get_role_show(Src, RoleUid) of
        'none' ->
            'ok';
        RoleShow ->
            See = role_show:get_see(RoleShow),
            point_search_db:leave_see(Src, RoleUid, See)
    end.

%% ----------------------------------------------------
%% @doc
%%     城池等级提升
%% @end
%% ----------------------------------------------------
town_up_level(_, Src, 'town_up_level', KVList) ->
    {_, CorpsUid} = lists:keyfind('corps_uid', 1, KVList),
    {_, TownSid} = lists:keyfind('town_sid', 1, KVList),
    {_, Town} = lists:keyfind('town', 1, KVList),
    {_, TownDetail} = lists:keyfind('town_detail', 1, KVList),
    IsChief = town_detail:chk_chief(TownDetail),
    Fun = fun(_, CorpsTown) ->
        {'ok', 'ok', corps_town:update_olist(CorpsTown, TownSid, IsChief, TownDetail, Town)}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'corps_town'), CorpsUid, corps_town:init(), Fun, []), %更新军团城池等级信息
    role_addition:set_corps_bufflist(CorpsUid, 'none'),%更新军团城池升级后,buff信息
    point_db:update_map_townexp(Src, TownSid, Town), %更新小地图信息(小地图经验只有升级之后才会变更)
    ok.

%% ----------------------------------------------------
%% @doc
%%        地图无搜索,战斗辅助
%% @end
%% ----------------------------------------------------
fight_assist(Src, _Args, _Time) ->
    Bl = zm_load:server_start_ok() =:= ?KEY,
    if
        Bl ->
            Now = time_lib:now_second(),
            Table = game_lib:get_table(Src, 'point_march_tmp'),
            Fun = fun(_, {Sec, PointUid} = Key, _, R) ->
                if
                    Now >= Sec ->
                        z_db_lib:delete(Table, Key),
                        {'ok', [PointUid | R]};
                    true ->
                        {'break', R}
                end
            end,
            PointUids = z_db_lib:table_iterate(Src, Table, Fun, [], [], 'ascending'),
            around_fight_now(Src, lists:usort(PointUids));
        true ->
            ok
    end.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%
%% @end
%% ----------------------------------------------------