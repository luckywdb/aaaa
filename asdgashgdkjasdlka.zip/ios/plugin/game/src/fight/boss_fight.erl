-module(boss_fight).

%%%=======================STATEMENT====================
-description("boss_fight").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    init_fight_npc/5,
    chk_npc_dead/2,
    do_fighting/14,
    get_cur_soldiers/2,
    init_boss_data/2,
    get_curr_value/3,
    get_max_value/2
]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").
-include("../include/report.hrl").

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      土匪进行战斗 UpPmarch=[{{role_uid,gid},{奖励},{随机奖励},死亡数量,伤兵数量}]
%% @end
%% ----------------------------------------------------
do_fighting(Src, _, _, _, _, _, [], IsDead, UpGoBacks, _, LastNpcState, RankAddList, _Extra, {BossNum, AllAwardView, NWaveInfo, NFightArgs, ETime}) ->
    if
        IsDead -> %%如果土匪全部死亡，这里需要发送战报
            zm_event:notify(Src, 'new_fight_monster_report', [
                {'winner', 0},
                {'time', ETime},
                {'award_list', {[], AllAwardView}},
                {'wave_infos', NWaveInfo},
                {'boss_num', BossNum},
                {'report_type', ?NEW_REPORT_FIGHT_MONSTER} | NFightArgs]);
        true -> ok
    end,
    {IsDead, UpGoBacks, LastNpcState, RankAddList};
do_fighting(Src, Now, EndPoint, FightArgsTmp, MonsterUid, MonstInfo, [Marching | T], IsDead, UpGoBack, NpcArray, {OLastLen, _OLastHp} = LastNpcState, RankAddList, Extra, {BossNum, AllAwardView, NWaveInfo, NFightArgs1, _ETime}) ->
    {RoleUid, GId} = RoleAndGId = marching:get_roleuid_gid(Marching),
    ETime = marching:get_etime(Marching),
    MonsterSid = monster_detail:get_sid(MonstInfo),
    case init_fight_npc(NpcArray, 0, 0, LastNpcState, []) of
        [] ->
            zm_event:notify(Src, 'fight_null_report', [
                {'role_uid', RoleUid},
                {'point_int', EndPoint},
                {'time', ETime},
                {'r_type', ?REPORT_NULL_MONSTER_DEAD},
                {'id', MonsterSid}]),%已到达时间+1秒为下一个状态开始时间
            do_fighting(Src, Now, EndPoint, FightArgsTmp, MonsterUid, MonstInfo, T, IsDead, UpGoBack, NpcArray, LastNpcState, RankAddList, Extra, {BossNum + 1, AllAwardView, NWaveInfo, NFightArgs1, ETime});
        FightNpc ->
            FightArgs = [{'fight_enemy', FightNpc} | FightArgsTmp],
            if
                IsDead -> %土匪已经死亡
                    zm_event:notify(Src, 'fight_null_report', [
                        {'role_uid', RoleUid},
                        {'point_int', EndPoint},
                        {'time', ETime},
                        {'r_type', ?REPORT_NULL_MONSTER_DEAD},
                        {'id', MonsterSid}]),%已到达时间+1秒为下一个状态开始时间
                    do_fighting(Src, Now, EndPoint, FightArgs, MonsterUid, MonstInfo, T, IsDead, UpGoBack, NpcArray, LastNpcState, RankAddList, Extra, {BossNum + 1, AllAwardView, NWaveInfo, NFightArgs1, ETime});
                true ->
                    Garray = garray_db:get_garray(Src, RoleUid, GId),
                    FighterRole = fighter:init_role(Src, RoleUid, GId, 0, Garray),%出发前已经检测过阵型
                    NFightArgs = [
                        {'seed', game_lib:get_seed()},
                        {'fight_role', FighterRole},
                        {'role_uid', RoleUid} | FightArgs],
                    case match:auto_result(Src, RoleUid, NFightArgs) of
                        {Winner, Result} ->%返回 result/6的结果,表示web一切正常
                            {NIsDead1, NUpGoBack1, NNpcState1, NAddRankList1, NewT, AwardView1, NWaveInfo1} =
                                try
                                    Dead = result:get_dead(Result),
                                    Injured = result:get_injured(Result),
                                    WebRoleResult = result:get_queue(Result),
                                    AllCardExp = result:get_allexp(Result),
                                    WaveInfo = result:get_waves(Result),
                                    {LastLen, LastHp} = result:get_enemy_last_hps(Result),
                                    {_, MarchiQueue, GarrayInjured, _AutoAddSoldier, _DeductSosldierNum} =
                                        fighting:update_garray_after_fight(Src, WebRoleResult, RoleAndGId),
                                    OneCardExp = garray_db:award_card_allexp(Src, RoleUid, GId, AllCardExp, z_lib:get_value(FightArgs, 'duplicate_sid', 0)),%武将加经验
                                    set_front_lib:send_map_result(Src, RoleUid, {ETime, EndPoint, ?MONSTER, ?MONSTER, Winner, GId, {MarchiQueue, Dead, Injured, GarrayInjured}, OneCardExp, MonsterSid}),
                                    {AwardView, NIsDead, NUpGoBack, NNpcState, NewT1} =
                                        if
                                            Winner =:= 0 ->%玩家胜利,土匪死亡
                                                NewLHpState = {LastLen + OLastLen, []},
                                                NpcDead = chk_npc_dead(NpcArray, NewLHpState),
                                                if
                                                    NpcDead ->
                                                        AwardSid = monster_detail:get_award(MonstInfo),
                                                        ActiveMonsterDrops = active_monster_drop:get_active_monster_drops(Src, MonsterSid),
                                                        Multi = active_addition:get_monster_drop_multi(Src),
                                                        AwardList = awarder_game:award_percent(ActiveMonsterDrops, Multi) ++ awarder_game:award_percent(AwardSid, Multi),
                                                        {AView, Award} = awarder_game:get_advance_award(Src, RoleUid, ?MODULE, AwardList),
                                                        monster_db:monster_dead(Src, MonsterUid, EndPoint, MonstInfo, Extra),%土匪死亡
                                                        {AView, true, [{RoleAndGId, Award, Dead + marching:get_dead(Marching), Injured + marching:get_injured(Marching)} | UpGoBack], NewLHpState, T};
                                                    true ->
                                                        {[], IsDead, UpGoBack, NewLHpState, [marching:fight_result(Marching, Injured, Dead, []) | T]} %marching已经是累加的死亡和伤兵
                                                end;
                                            true ->
                                                NewLHpState = {LastLen + OLastLen - 1, LastHp},
                                                {[], IsDead, [{RoleAndGId, {}, Dead + marching:get_dead(Marching), Injured + marching:get_injured(Marching)} | UpGoBack], NewLHpState, T}
                                        end,
                                    %%南蛮入侵战报修改为：胜利只发最后一波的数据的战报，加上一共打了多少次的波数
                                    if
                                        Winner =:= 0 ->%玩家胜利,土匪死亡。
                                            ok;
                                        true ->
                                            %%这里检查波数，如果一波都没打过，那就只发送失败战报，
                                            %%如果打过了一波，那么只发送胜利战报
                                            if
                                                BossNum > 0 ->
                                                    zm_event:notify(Src, 'new_fight_monster_report', [
                                                        {'winner', Winner},
                                                        {'time', ETime},
                                                        {'award_list', {[], AllAwardView}},
                                                        {'wave_infos', WaveInfo},
                                                        {'boss_num', BossNum},
                                                        {'report_type', ?NEW_REPORT_FIGHT_MONSTER} | NFightArgs]);
                                                true ->%%一波都没打过
                                                    zm_event:notify(Src, 'fight_monster_report', [
                                                        {'winner', Winner},
                                                        {'time', ETime},
                                                        {'award_list', {[], AwardView}},
                                                        {'wave_infos', WaveInfo},
                                                        {'report_type', ?REPORT_FIGHT_MONSTER} | NFightArgs])
                                            end,
                                            ok
                                    end,
                                    {NIsDead, NUpGoBack, NNpcState, [{RoleUid, result:get_enemy_total_dead(Result) + result:get_enemy_total_injure(Result)} | RankAddList], NewT1, AwardView, WaveInfo}
                                catch
                                    E1:E2 ->
                                        zm_log:warn(?MODULE, ?MODULE, 'fighting', "handle_error", [{'e1', E1}, {'e2', E2}, {'point_uid', EndPoint},
                                            {'marching', Marching}, {'stacktrace', erlang:get_stacktrace()}]),
                                        {IsDead, UpGoBack, LastNpcState, RankAddList, T, AllAwardView, NWaveInfo}
                                end,
                            do_fighting(Src, Now, EndPoint, FightArgs, MonsterUid, MonstInfo, NewT, NIsDead1, NUpGoBack1, NpcArray, NNpcState1, NAddRankList1, Extra, {BossNum + 1, award_lib:merger(AwardView1, AllAwardView), NWaveInfo1, NFightArgs, ETime});
                        WebErr ->
                            zm_log:warn(?MODULE, ?MODULE, 'fighting', "web_error", [{'error', WebErr}, {'point_uid', EndPoint}, {'marching', Marching}]),
                            do_fighting(Src, Now, EndPoint, FightArgs, MonsterUid, MonstInfo, T, IsDead, UpGoBack, NpcArray, LastNpcState, RankAddList, Extra, {BossNum, AllAwardView, NWaveInfo, NFightArgs, ETime})
                    end
            end
    end.


%% ----------------------------------------------------
%% @doc
%%      计血战boss
%% @end
%% ----------------------------------------------------
init_fight_npc(NpcArray, Name, Lv, {Len, LastHp}, AddAttrs) ->
    init_fight_npc(NpcArray, Name, Lv, {Len, LastHp}, true, AddAttrs).

init_fight_npc(NpcArray, Name, Lv, {Len, LastHp}, Bool, AddAttrs) ->
    NpcLen = length(NpcArray),
    if
        Len > NpcLen ->
            [];
        true ->
            if
                LastHp =:= [] ->
                    case lists:sublist(NpcArray, Len, ?ONE_FIGHT_ROLE_NUM) of
                        [] ->
                            [];
                        FightNpcArray ->
                            fighter:init_npc(FightNpcArray, Name, Lv, AddAttrs)
                    end;
                true ->
                    case lists:sublist(NpcArray, Len, ?ONE_FIGHT_ROLE_NUM + 1) of
                        [] ->
                            [];
                        FightNpcArray ->
                            [FightBattle | Rest] = fighter:init_npc(FightNpcArray, Name, Lv, AddAttrs),
                            Fighters =
                                z_lib:foreach(fun(NewFighters, F) ->
                                    %如果第一次6个土匪,web返回6个怪的hp,死亡一个;第二次之后只会给web5个土匪,web返回也只有5个,故不存在里面的直接死亡
                                    case lists:keyfind(fighter:get_uid(F), 1, LastHp) of
                                        false ->
                                            if
                                                Bool ->
                                                    {'ok', NewFighters};
                                                true ->%世界boss显示总血量上限(显示当前全部存活的,包括伤兵)
                                                    {'ok', [F | NewFighters]}
                                            end;
                                        {_, CurHp, MaxHp} ->
                                            OldCurHp = fighter:get_hp(F),
                                            OldWeaponNum = fighter:get_weapon_num(F),
                                            if
                                                CurHp =< 0 orelse MaxHp =< 0 ->
                                                    if
                                                        Bool ->
                                                            {'ok', NewFighters};
                                                        true ->%世界boss显示总血量上限(显示当前全部存活的,包括伤兵)
                                                            {'ok', [fighter:set_hp(F, MaxHp) | NewFighters]}
                                                    end;
                                                true ->
                                                    SetMax = if
                                                        Bool ->
                                                            OneHp = fighter:get_max_hp(F) div fighter:get_max_soldier_num(F),
                                                            NewF = fighter:set_max_soldier_num(F, MaxHp div OneHp),
                                                            fighter:set_weapon_num(fighter:set_max_hp(fighter:set_hp(NewF, CurHp), MaxHp), OldWeaponNum * CurHp div (OldCurHp));
                                                        true ->%世界boss显示总血量上限(显示当前全部存活的,包括伤兵)
                                                            fighter:set_hp(F, MaxHp)
                                                    end,
                                                    {'ok', [SetMax | NewFighters]}
                                            end
                                    end
                                end, [], fighter:get_fighters(FightBattle)),
                            case Fighters of
                                [] ->
                                    Rest;
                                _ ->
                                    [fighter:set_fighters(FightBattle, lists:reverse(Fighters))]
                            end
                    end
            end

    end.

%% ----------------------------------------------------
%% @doc
%%  获取当前波次剩余带兵量,总带兵量
%% @end
%% ----------------------------------------------------
get_cur_soldiers(NpcArray, {Len, LastHp}) ->
    case init_fight_npc(NpcArray, 0, 0, {Len, LastHp}, false, []) of
        [] ->
            {0, 0};
        List ->
            Fun = fun({Cur, Max} = A, Fb) ->
                case fighter:get_fighters(Fb) of
                    [] ->
                        {ok, A};
                    Fighters ->
                        z_lib:foreach(fun({Cur1, Max1}, Fight) ->
                            Max2 = fighter:get_max_soldier_num(Fight),
                            MaxHp = fighter:get_max_hp(Fight),
                            CurHp = fighter:get_hp(Fight),
                            {ok, {Cur1 + CurHp div (MaxHp div Max2), Max1 + Max2}}
                        end, {Cur, Max}, Fighters)
                end
            end,
            z_lib:foreach(Fun, {0, 0}, List)
    end.

%% ----------------------------------------------------
%% @doc
%%      获取当前总兵力
%% @end
%% ----------------------------------------------------
get_cur_total_soldiers(NpcArray, {Len, LastHp}) ->
    MaxLen = length(NpcArray),
    case Len > MaxLen of
        true ->
            0;
        false ->
            {Curr, Max} = get_cur_soldiers(NpcArray, {Len, LastHp}),
            (MaxLen - Len) * Max + Curr
    end.

%% ----------------------------------------------------
%% @doc
%%      获取最大总兵力
%% @end
%% ----------------------------------------------------
get_max_total_soldiers(NpcArray) ->
    MaxLen = length(NpcArray),
    {_, Max} = get_cur_soldiers(NpcArray, {1, []}),
    Max * MaxLen.

%% ----------------------------------------------------
%% @doc
%%      获取当前总血量
%% @end
%% ----------------------------------------------------
get_cur_total_hp(NpcArray, {Len, LastHp}) ->
    MaxLen = length(NpcArray),
    case Len > MaxLen of
        true ->
            0;
        false ->
            List = init_fight_npc(NpcArray, 0, 0, {Len, LastHp}, false, []),
            Fun = fun({Cur, Max} = A, Fb) ->
                case fighter:get_fighters(Fb) of
                    [] ->
                        {ok, A};
                    Fighters ->
                        z_lib:foreach(fun({Cur1, Max1}, Fight) ->
                            MaxHp = fighter:get_max_hp(Fight),
                            CurHp = fighter:get_hp(Fight),
                            {ok, {Cur1 + CurHp, Max1 + MaxHp}}
                        end, {Cur, Max}, Fighters)
                end
            end,
            {CurrHp, MaxHP} = z_lib:foreach(Fun, {0, 0}, List),
            ((MaxLen - Len) * MaxHP + CurrHp) div 10000
    end.

%% ----------------------------------------------------
%% @doc
%%      获取最大总血量
%% @end
%% ----------------------------------------------------
get_max_total_hp(NpcArray) ->
    List = init_fight_npc(NpcArray, 0, 0, {1, []}, false, []),
    Fun = fun({Cur, Max} = A, Fb) ->
        case fighter:get_fighters(Fb) of
            [] ->
                {ok, A};
            Fighters ->
                z_lib:foreach(fun({Cur1, Max1}, Fight) ->
                    MaxHp = fighter:get_max_hp(Fight),
                    CurHp = fighter:get_hp(Fight),
                    {ok, {Cur1 + CurHp, Max1 + MaxHp}}
                end, {Cur, Max}, Fighters)
        end
    end,
    {_, MaxHP} = z_lib:foreach(Fun, {0, 0}, List),
    MaxHP * length(NpcArray).

%% ----------------------------------------------------
%% @doc
%%      获取最大值
%% @end
%% ----------------------------------------------------
get_max_value(NpcArray, Extra) ->
    case Extra of
        {'active', _} ->
            get_max_total_soldiers(NpcArray);
        _ ->
            get_max_total_hp(NpcArray)
    end.

%% ----------------------------------------------------
%% @doc
%%      获取当前值
%% @end
%% ----------------------------------------------------
get_curr_value(NpcArray, {Len, LastHp}, Extra) ->
    case Extra of
        {'active', _} ->
            get_cur_total_soldiers(NpcArray, {Len, LastHp});
        _ ->
            get_cur_total_hp(NpcArray, {Len, LastHp})
    end.

%% ----------------------------------------------------
%% @doc
%%      初始化boss数据
%% @end
%% ----------------------------------------------------
init_boss_data(MonsterSid, Extra) ->
    BD = boss_data:init(),
    MonsterDetail = monster_detail:get_cfg(MonsterSid),
    NpcArray = monster_detail:get_npc(MonsterDetail),
    Max = get_max_value(NpcArray, Extra),
    boss_data:set_extra(boss_data:set_curr_value(boss_data:set_max_value(BD, Max), Max), Extra).

%% ----------------------------------------------------
%% @doc
%%      判断当前npc是否死亡.
%% @end
%% ----------------------------------------------------
chk_npc_dead(NpcArray, {Len, LastHp}) ->
    NpcLen = length(NpcArray),
    NpcLen =:= 0 orelse (Len > NpcLen andalso (LastHp =:= [] orelse (LastHp =/= [] andalso lists:all(fun({_, Hp, _}) ->
        Hp =< 0 end, LastHp)))).
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
