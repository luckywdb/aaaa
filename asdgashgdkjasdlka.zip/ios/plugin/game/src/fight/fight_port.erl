-module(fight_port).

%%%=======================STATEMENT====================
-description("行军端口").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    marching/5,
    marching_res/5,
    marching_role/5,
    marching_town/5,
    recall/5,
    arrive/5,
    speed_up/5,
    collect_recall/5,
    assault_info/5,
    town_refresh_over/5,
    town_recall/5,
    goback/5,
    occ_recall/5,
    marching_spy/5
]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").
-include("../include/corps.hrl").

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      侦查行军
%% @end
%% ----------------------------------------------------
marching_spy([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    MarchRoleUid = role_lib:get_uid(Attr),
    EndPointTmp = list_to_integer(z_lib:get_value(Msg, "point_uid", "0")),
    CheckVaild = valid_lib:check_valib([{'ge', EndPointTmp, 0}]),
    if
        CheckVaild ->
            MapId = role_lib:get_mapid(Attr),
            EndPoint = point_lib:xyaddmapid(EndPointTmp, MapId),
            MarchRoleShow = role_db:get_role_show(Src, MarchRoleUid),
            MarchPoint = role_show:get_point(MarchRoleShow),
            if
                MarchPoint =:= EndPoint ->
                    {'ok', [], Info, [{'msg', "input_error"}]};
                true ->
                    PState = case point_state_db:get_point_info(Src, EndPoint) of
                        'none' ->
                            MapType = point_lib:mapid2type(MapId),
                            case zm_config:get(point_lib:maptype2cfgname('point_check_rivers', MapType), EndPointTmp) =:= 'none' of
                                true ->
                                    {?NULL, 0};
                                false ->
                                    'none'
                            end;
                        V ->
                            V
                    end,
                    case PState =/= 'none' of
                        true ->
                            PType = element(1, PState),
                            case PType =/= ?RES andalso PType =/= ?RESOURCE andalso PType =/= ?TOWN of
                                true ->
                                    {_, MarchSpeed} = zm_config:get('map_spy_info', 'spy_marching_speed'),
                                    EndPInfo = {?NULL, 0}, %侦查只能是空地
                                    Marching1 = marching:init(MarchRoleUid, time_lib:now_second(), MarchPoint, EndPoint, MarchSpeed, ?ROLE, EndPInfo),
                                    Marching = marching:set_state(Marching1, ?ON_THE_INVESTIGATE),
                                    TableName = game_lib:get_table(Src),
                                    TableKeys = z_db_lib:transformation_tablekey(TableName, [
                                        {'map_spy', MarchRoleUid, map_spy:spy_init()},
                                        {'point_march', MarchPoint, point_march:init()},
                                        {'point_march', EndPoint, point_march:init()}
                                    ]),
                                    Reply = case z_db_lib:handle(TableName, {M, F, A}, {Src, MarchRoleUid, EndPoint, {?ROLE, MarchRoleUid}, EndPInfo, Marching}, TableKeys) of
                                        {'ok', _ConsumeLogs, NewMarching} ->
                                            MarchLine = marching:marching_to_lines(EndPoint, EndPInfo, NewMarching),
                                            point_search_db:send_march_line(Src, MarchPoint, EndPoint, MarchLine, []),
                                            fight_db:add_fight_assist(Src, EndPoint, NewMarching),
                                            "ok";
                                        Err ->
                                            Err
                                    end,
                                    {'ok', [], Info, [{'msg', Reply}]};
                                false ->
                                    {'ok', [], Info, [{'msg', "input_error"}]}
                            end;
                        false ->
                            {'ok', [], Info, [{'msg', "input_error"}]}
                    end
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      行军开始,战斗开始(占领资源,攻打土匪)
%% @end
%% ----------------------------------------------------
marching([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    MarchRoleUid = role_lib:get_uid(Attr),
    MarchGId = z_lib:get_value(Msg, "gid", 0),
    EndPointTmp = list_to_integer(z_lib:get_value(Msg, "point_uid", "0")),
    HaveBuild = z_lib:get_value(Msg, "have_build", 0),%0没有建筑,1表示有建筑
    CheckVaild = valid_lib:check_valib([{'ge', EndPointTmp, 0}, {'range', MarchGId, {1, garray_lib:get_max_gid()}}, {'range', HaveBuild, {0, 1}}]),
    if
        CheckVaild ->
            MapId = role_lib:get_mapid(Attr),
            EndPoint = point_lib:xyaddmapid(EndPointTmp, MapId),
            EndPInfo = case zm_config:get(point_lib:mapid2cfgname('point_check_resource', MapId), EndPointTmp) of
                'none' ->
                    point_state_db:get_point_info(Src, EndPoint);
                {_, RSid, _} ->
                    {?RESOURCE, RSid}
            end,
            MarchRoleShow = role_db:get_role_show(Src, MarchRoleUid),
            MarchBool = case EndPInfo of
                'none' ->
                    "point_null";
                {?MONSTER, MUid} ->
                    MonCfg = monster_detail:get_cfg(monster_db:muid_2_msid(MUid)),
                    case monster_detail:is_elite(MonCfg) of
                        true ->     %是精英怪直接攻打，没有等级判断
                            {'ok', MonCfg};
                        false ->
                            MonsterLv = monster_detail:get_level(MonCfg),
                            if
                                MonsterLv =:= 1 ->%1级怪直接可以攻打
                                    {'ok', MonCfg};
                                MapId > 0 ->%跨服怪可以直接打
                                    {'ok', MonCfg};
                                true ->
                                    TimesSet = z_db_lib:get(game_lib:get_table(Src, 'times_set'), MarchRoleUid, []),
                                    KillMLvList = z_lib:get_value(TimesSet, 'monster', []),%1级土匪可以直接打
                                    KillMLv = z_lib:get_value(KillMLvList, monster_detail:get_type(MonCfg), 0),
                                    if
                                        KillMLv >= MonsterLv - 1 ->
                                            {'ok', MonCfg};
                                        true ->
                                            "monster_lv_limit"
                                    end
                            end
                    end;
                {?BOSS, MUid} ->
                    MSid = monster_db:muid_2_msid(MUid),
                    {_, MinLv, MaxLv} = zm_config:get('attack_boss_condition', MSid),
                    RoleLv = role_show:get_level(MarchRoleShow),
                    if
                        MinLv =< RoleLv andalso RoleLv =< MaxLv ->
                            {'ok', monster_detail:get_cfg(MSid)};
                        true ->
                            "role_maxlv_limit"
                    end;
                {?RESOURCE, ReSid} ->
                    if
                        MapId > 0 ->%策划取消,超限制限制出行
                            {ok, resource_detail:get_cfg(ReSid)};
%%                            {_, MaxList} = zm_config:get('cross_battle_info', 'res_upper'),
%%                            MaxWood = z_lib:get_value(MaxList, 'cb_wood', 0),
%%                            case role:get_cb_wood(role_db:get_role(Src, MarchRoleUid)) >= MaxWood of
%%                                true ->
%%                                    "cb_wood_upper";
%%                                false ->
%%                                    {ok, resource_detail:get_cfg(ReSid)}
%%                            end;
                        true ->
                            ResCfg = resource_detail:get_cfg(ReSid),
                            NeedRLv = resource_detail:get_role_lv(ResCfg),
                            case role_show:get_level(MarchRoleShow) >= NeedRLv of
                                true ->
                                    {'ok', ResCfg};
                                false ->
                                    "role_lv_limit"
                            end
                    end;
                {PType, _, Key} when PType =:= ?MAP_BUILD_CORPS orelse PType =:= ?MAP_BUILD_TOWN orelse PType =:= ?MAP_BUILD_ROLE ->
                    CorpsUid = role_show:get_corps_uid(MarchRoleShow),
                    case PType =:= ?MAP_BUILD_ROLE orelse CorpsUid > 0 of
                        true ->
                            CUId = case PType of
                                ?MAP_BUILD_CORPS ->
                                    Key;
                                ?MAP_BUILD_TOWN ->
                                    town:get_corps_uid(z_db_lib:get(game_lib:get_table(Src, 'town'), Key, town:init(Key)));
                                ?MAP_BUILD_ROLE ->
                                    role_show:get_corps_uid(role_db:get_role_show(Src, element(2, Key)))
                            end,
                            FightFlag = z_lib:get_value(Msg, "flag", 0),
                            case FightFlag =:= 0 of
                                true ->
                                    case CorpsUid =:= CUId of
                                        true ->
                                            {ok, ok};
                                        false ->
                                            "not_in_same_corps"
                                    end;
                                false ->
                                    case CorpsUid =/= CUId of
                                        true ->
                                            {ok, ok};
                                        false ->
                                            "input_error"
                                    end
                            end;
                        false ->
                            "not_in_same_corps"
                    end;
                {?MAP_SPY, RUid} ->
                    CorpsUid = role_show:get_corps_uid(MarchRoleShow),
                    CUid = role_show:get_corps_uid(role_db:get_role_show(Src, RUid)),
                    FightFlag = z_lib:get_value(Msg, "flag", 0),
                    case FightFlag =:= 0 of
                        true ->%%驻防
                            case CorpsUid =:= CUid of
                                true ->
                                    {ok, ok};
                                false ->
                                    "not_in_same_corps"
                            end;
                        false ->%%攻打
                            case CorpsUid =/= CUid of
                                true ->
                                    {ok, ok};
                                false ->
                                    "input_error"
                            end
                    end;
                _ ->
                    {ok, ok}
            end,
            case MarchBool of
                {'ok', MonResInfo} ->
                    RoleStations = station_db:get_role_stations(Src, MarchRoleUid),
                    {MarchPInfo, MarchPoint, IsStation} =
                        case lists:keyfind(MarchGId, station:get_gid_index(), RoleStations) of
                            false ->
                                {{?ROLE, MarchRoleUid}, role_show:get_point(MarchRoleShow), false};
                            Station ->
                                {{?STATION, MarchRoleUid}, station:get_puid(Station), true}
                        end,
                    PointType = element(1, EndPInfo),
                    MarchSpeed = role_addition:get_marching_speed(Src, MarchRoleUid, MarchPoint, map_build_lib:check_station_marchg(IsStation, HaveBuild)),
                    Marching1 = marching:init(MarchRoleUid, MarchGId, MarchPoint, EndPoint, MarchSpeed, element(1, MarchPInfo), EndPInfo),
                    {MarchState, MProtectTime} = role_show:get_state(MarchRoleShow),
                    Now = time_lib:now_second(),

                    {Marching, AddCastleTable} =
                        if
                            PointType =:= ?RESOURCE ->      %% 攻打资源
                                ResourceType = resource_detail:get_type(MonResInfo),
                                %{总加成百分比，活动加成百分比，军团占领城池buff加成百分比，军团占领城池科技加成百分比}
                                {CollectSpeedAdd, ActiveAdd, TownBuffAdd, TownScienceAdd} = role_addition:get_collect_speed_add(Src, MarchRoleUid, ResourceType, EndPoint),
                                {SoldierBearLoad, OrdnanceBearLoad} = garray_db:get_garray_bearload(Src, MarchRoleUid, MarchGId),
                                Study = building_db:get_study(Src, MarchRoleUid),
                                BearLoadAdd = role_addition:get_bear_load_add(Study),
                                AddCastleTable1 = if
                                    MarchState =:= ?STATE_PROTECT andalso MProtectTime >= Now ->
                                        [{'castle', MarchRoleUid}];
                                    true -> []
                                end,
                                MarchingExtra =
                                    if
                                        MapId > 0 ->
                                            {_, BPer} = zm_config:get('cross_battle_info', 'bearload_per'),
                                            marching:init_resource_extra(SoldierBearLoad div BPer, OrdnanceBearLoad div BPer, BearLoadAdd,
                                                CollectSpeedAdd, ActiveAdd, {TownBuffAdd, TownScienceAdd});
                                        true ->
                                            marching:init_resource_extra(SoldierBearLoad, OrdnanceBearLoad, BearLoadAdd,
                                                CollectSpeedAdd, ActiveAdd, {TownBuffAdd, TownScienceAdd})
                                    end,
                                {marching:set_extra(Marching1, MarchingExtra), AddCastleTable1};
                            PointType =:= ?MAP_BUILD_CORPS orelse PointType =:= ?MAP_BUILD_TOWN orelse PointType =:= ?MAP_BUILD_ROLE ->
                                case z_lib:get_value(Msg, "flag", 0) =:= 0 of
                                    true ->
                                        {marching:set_state(Marching1, ?ON_THE_MB_MARCHING), []};
                                    false ->
                                        AddCastleTable1 = if
                                            MarchState =:= ?STATE_PROTECT andalso MProtectTime >= Now ->
                                                [{'castle', MarchRoleUid}];
                                            true -> []
                                        end,
                                        {marching:set_state(Marching1, ?ON_THE_FIGHT_MB_MARCHING), AddCastleTable1}
                                end;
                            PointType =:= ?MAP_YS_POINT ->
                                {marching:set_state(Marching1, ?ON_THE_FIGHT_YS), []};
                            PointType =:= ?MAP_SPY ->
                                case z_lib:get_value(Msg, "flag", 0) =:= 0 of
                                    true ->
                                        {marching:set_state(Marching1, ?ON_THE_GARRISON_SPY_MARCHING), []};
                                    false ->
                                        {marching:set_state(Marching1, ?ON_THE_FIGHT_SPY_MARCHING), []}
                                end;
                            true ->
                                {Marching1, []}
                        end,
                    TableName = game_lib:get_table(Src),
                    TableKeys = z_db_lib:transformation_tablekey(TableName, [
                        {'role', MarchRoleUid},
                        {'garray', {MarchRoleUid, MarchGId}, 'none'},
                        {'point_march', MarchPoint, point_march:init()},
                        {'point_march', EndPoint, point_march:init()},
                        {'role_restore', MarchRoleUid} | AddCastleTable
                    ]),
                    restore_db:restore(Src, MarchRoleUid),
                    Reply = case z_db_lib:handle(TableName, {M, F, A}, {Src, MapId, MarchPoint, EndPoint, Marching, EndPInfo, MarchPInfo, IsStation}, TableKeys) of
                        {'ok', MarchPMarch, EndPMarch, BiCs, Bool, OcRoleUid} ->
                            %bi
                            zm_event:notify(Src, 'bi_fight_marching', [{'role_uid', MarchRoleUid}, {'orole_uid', OcRoleUid}, {'consumes', BiCs}, {'gid', MarchGId}, {'type', PointType}, {'monster_info', MonResInfo}]),
                            MarchLine = marching:marching_to_lines(EndPoint, EndPInfo, Marching),
                            OccRUids = lists:usort([marching:get_roleuid(Om) || Om <- point_march:get_occupy(EndPMarch)]),
                            RUids =
                                case PointType of
                                    ?MAP_BUILD_ROLE ->
                                        [element(2, element(3, EndPInfo)), MarchRoleUid | OccRUids];
                                    ?MAP_SPY ->
                                        [element(2, EndPInfo), MarchRoleUid | OccRUids];
                                    _ ->
                                        [MarchRoleUid | OccRUids]
                                end,
                            point_search_db:send_march_line(Src, MarchPoint, EndPoint, MarchLine, RUids),
                            if
                                Bool ->
                                    zm_event:notify(Src, 'update_role_show', {MarchRoleUid, {'castle_state', {?STATE_NOR, 0}}});
                                true ->
                                    'ok'
                            end,
                            if
                                OcRoleUid > 0 andalso PointType =:= ?RESOURCE ->
                                    Sid = element(2, EndPInfo),
                                    ResourceDetail = resource_detail:get_cfg(Sid),
                                    push_message_lib:push(Src, OcRoleUid, 2, [resource_detail:get_level(ResourceDetail), resource_detail:get_name(ResourceDetail), role_show:get_name(MarchRoleShow)]);%资源点,推送;
                                true ->
                                    ok
                            end,
                            fight_db:add_fight_assist(Src, EndPoint, Marching),
                            station_db:update_station_occ_num(Src, MarchPoint, MarchPMarch, IsStation),
                            map_build_db:update_mb_fight_num(Src, marching:get_state(Marching), EndPInfo, EndPoint, 1),
                            NOccRUids = if
                                PointType =:= ?MAP_BUILD_ROLE ->
                                    OwnerRoleUid = element(2, element(3, EndPInfo)),
                                    [OwnerRoleUid | OccRUids];
                                true ->
                                    OccRUids
                            end,
                            lists:foreach(fun(RoleUidTmp) ->
                                fight_db:send_assault_info(Src, MapId, RoleUidTmp, Marching, EndPoint) end, NOccRUids),
                            "ok";
                        Err ->
                            Err
                    end,
                    {'ok', [], Info, [{'msg', Reply}]};
                MErr ->
                    {'ok', [], Info, [{'msg', MErr}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.
%% ----------------------------------------------------
%% @doc
%%      行军开始,战斗开始(占领新资源)
%%      type = 1:攻占
%%           = 2:驻防
%% @end
%% ----------------------------------------------------
marching_res([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    MarchRoleUid = role_lib:get_uid(Attr),
    MarchGId = z_lib:get_value(Msg, "gid", 0),
    EndPointTmp = list_to_integer(z_lib:get_value(Msg, "point_uid", "0")),
    Type = z_lib:get_value(Msg, "type", 0),
    HaveBuild = z_lib:get_value(Msg, "have_build", 0),%0没有建筑,1表示有建筑
    CheckVaild = valid_lib:check_valib([{'ge', EndPointTmp, 0}, {'range', Type, {1, 2}}, {'range', MarchGId, {1, garray_lib:get_max_gid()}}, {'range', HaveBuild, {0, 1}}]),
    if
        CheckVaild ->
            MapId = role_lib:get_mapid(Attr),
            EndPoint = point_lib:xyaddmapid(EndPointTmp, MapId),
            case zm_config:get(point_lib:mapid2cfgname('point_check_res', MapId), EndPointTmp) of
                'none' ->
                    {'ok', [], Info, [{'msg', "input_error"}]};
                {_, ResSid, _} ->
                    ORoleUid = z_db_lib:get(game_lib:get_table(Src, 'res'), EndPoint, 0),
                    if
                        (ORoleUid =:= MarchRoleUid andalso Type =:= 1) orelse (ORoleUid =/= MarchRoleUid andalso Type =:= 2) ->
                            {'ok', [], Info, [{'msg', "input_error"}]};
                        true ->
                            ResDetail = res_detail:get_cfg(ResSid),
                            ResLv = res_detail:get_level(ResDetail),
                            case MapId > 0 orelse ResLv =:= 1 orelse z_lib:get_value(z_db_lib:get(game_lib:get_table(Src, 'times_set'), MarchRoleUid, []), 'res', 0) >= ResLv - 1 of
                                true ->
                                    RoleRes = res_db:get_role_res(Src, MarchRoleUid),
                                    MarchRoleShow = role_db:get_role_show(Src, MarchRoleUid),
                                    Lv = role_show:get_level(MarchRoleShow),
                                    MaxCount = game_lib:level_value(Lv, element(2, zm_config:get('res_info', 'role_level_res_count'))),
                                    CurCount = length(role_res:get_psids(RoleRes)),
                                    if
                                        Type =:= 1 andalso CurCount >= MaxCount ->
                                            {'ok', [], Info, [{'msg', "res_count_limit"}]};
                                        true ->
                                            restore_db:restore(Src, MarchRoleUid),
                                            RoleStations = station_db:get_role_stations(Src, MarchRoleUid),
                                            {MarchPInfo, MarchPoint, IsStation} =
                                                case lists:keyfind(MarchGId, station:get_gid_index(), RoleStations) of
                                                    false ->
                                                        {{?ROLE, MarchRoleUid}, role_show:get_point(MarchRoleShow), false};
                                                    Station ->
                                                        {{?STATION, MarchRoleUid}, station:get_puid(Station), true}
                                                end,
                                            MarchSpeed = role_addition:get_marching_speed(Src, MarchRoleUid, MarchPoint, map_build_lib:check_station_marchg(IsStation, HaveBuild)),
                                            EndPInfo = {?RES, ResSid},
                                            Marching1 = marching:init(MarchRoleUid, MarchGId, MarchPoint, EndPoint, MarchSpeed, element(1, MarchPInfo), EndPInfo),
                                            {SoldierBearLoad, OrdnanceBearLoad} = garray_db:get_garray_bearload(Src, MarchRoleUid, MarchGId),
                                            Study = building_db:get_study(Src, MarchRoleUid),
                                            BearLoadAdd = role_addition:get_bear_load_add(Study),
                                            MarchingExtra = marching:init_extra(SoldierBearLoad, OrdnanceBearLoad, BearLoadAdd),
                                            Marching = marching:set_extra(marching:set_state(Marching1, element(Type, {?ON_THE_MARCHING_FIGHT_RES, ?ON_THE_MARCHING_GARRISON_RES})), MarchingExtra),
                                            {MarchState, MProtectTime} = role_show:get_state(MarchRoleShow),
                                            Now = time_lib:now_second(),
                                            AddCastleTable = if
                                                ORoleUid > 0 andalso Type =:= 1 andalso MarchState =:= ?STATE_PROTECT andalso MProtectTime >= Now ->
                                                    [{'castle', MarchRoleUid}];
                                                true -> []
                                            end,
                                            TableName = game_lib:get_table(Src),
                                            TableKeys = z_db_lib:transformation_tablekey(TableName, [
                                                {'role', MarchRoleUid},
                                                {'garray', {MarchRoleUid, MarchGId}, 'none'},
                                                {'point_march', MarchPoint, point_march:init()},
                                                {'point_march', EndPoint, point_march:init()},
                                                {'role_restore', MarchRoleUid} | AddCastleTable
                                            ]),
                                            Reply = case z_db_lib:handle(TableName, {M, F, A}, {Src, MapId, MarchPoint, EndPoint, Marching, EndPInfo, MarchPInfo, IsStation}, TableKeys) of
                                                {'ok', MarchPMarch, _EndPMarch, BiCs, Bool, _} ->
                                                    %bi
                                                    zm_event:notify(Src, 'bi_fight_marching', [{'role_uid', MarchRoleUid}, {'consumes', BiCs}, {'gid', MarchGId}, {'type', ?RES}]),
                                                    MarchLine = marching:marching_to_lines(EndPoint, EndPInfo, Marching),
                                                    AddSeeList = case ORoleUid > 0 andalso Type =:= 1 of
                                                        true ->
                                                            ResDetail = res_detail:get_cfg(ResSid),
                                                            push_message_lib:push(Src, ORoleUid, 2, [res_detail:get_level(ResDetail), res_detail:get_name(ResDetail), role_show:get_name(MarchRoleShow)]),%资源点,推送;
                                                            [ORoleUid];
                                                        false ->
                                                            []
                                                    end,
                                                    point_search_db:send_march_line(Src, MarchPoint, EndPoint, MarchLine, [MarchRoleUid | AddSeeList]),
                                                    if
                                                        Bool ->
                                                            zm_event:notify(Src, 'update_role_show', {MarchRoleUid, {'castle_state', {?STATE_NOR, 0}}});
                                                        true ->
                                                            'ok'
                                                    end,
                                                    fight_db:add_fight_assist(Src, EndPoint, Marching),
                                                    station_db:update_station_occ_num(Src, MarchPoint, MarchPMarch, IsStation),
                                                    %获取发起行军的军团Uid和其盟军
                                                    CorpsUids = case role_show:get_corps_uid(MarchRoleShow) of
                                                        0 ->
                                                            [];
                                                        CorpsUid ->
                                                            AllyCorpsUids = corps_db:get_ally_corps_uids(Src, CorpsUid),
                                                            [CorpsUid | AllyCorpsUids]
                                                    end,
                                                    %%判断已经在里面的是否是友军
                                                    lists:foreach(fun(RoleUidTmp) ->
                                                        CUid = role_show:get_corps_uid(role_db:get_role_show(Src, RoleUidTmp)),
                                                        case lists:member(CUid, CorpsUids) of
                                                            true ->
                                                                ok;
                                                            false ->
                                                                fight_db:send_assault_info(Src, MapId, RoleUidTmp, Marching, EndPoint)
                                                        end
                                                    end, AddSeeList),
                                                    "ok";
                                                Err ->
                                                    Err
                                            end,
                                            {'ok', [], Info, [{'msg', Reply}]}
                                    end;
                                false ->
                                    {'ok', [], Info, [{'msg', "res_lv_limit"}]}
                            end
                    end
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      行军开始,战斗开始(攻打玩家)
%% @end
%% ----------------------------------------------------
marching_role([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    MarchRoleUid = role_lib:get_uid(Attr),
    MarchGId = z_lib:get_value(Msg, "gid", 0),
    EndPointUidTmp = list_to_integer(z_lib:get_value(Msg, "point_uid", "0")),%被攻击玩家uid
    HaveBuild = z_lib:get_value(Msg, "have_build", 0),%0没有建筑,1表示有建筑
    CheckVaild = valid_lib:check_valib([{'ge', EndPointUidTmp, 1}, {'range', MarchGId, {1, garray_lib:get_max_gid()}}, {'range', HaveBuild, {0, 1}}]),
    if
        CheckVaild ->
            MapId = role_lib:get_mapid(Attr),
            EndPointUid = point_lib:xyaddmapid(EndPointUidTmp, MapId),
            case point_state_db:get_point_info(Src, EndPointUid) of
                {PointType, EndRoleUid} = EndPInfo when PointType =:= ?ROLE orelse PointType =:= ?STATION ->
                    MarchRoleShow = role_db:get_role_show(Src, MarchRoleUid),
                    case EndRoleUid =/= role_show:get_point(MarchRoleShow) of
                        true ->
                            EndRoleShow = role_db:get_role_show(Src, EndRoleUid),
                            {State, ProtectTime} = role_show:get_state(EndRoleShow),
                            Now = time_lib:now_second(),
                            if
                                PointType =:= ?ROLE andalso State =:= ?STATE_PROTECT andalso ProtectTime >= Now ->
                                    {'ok', [], Info, [{'msg', "role_protected"}]};
                                true ->
                                    restore_db:restore(Src, MarchRoleUid),
                                    RoleStations = station_db:get_role_stations(Src, MarchRoleUid),
                                    {MarchPInfo, MarchPoint, IsStation} =
                                        case lists:keyfind(MarchGId, station:get_gid_index(), RoleStations) of
                                            false ->
                                                {{?ROLE, MarchRoleUid}, role_show:get_point(MarchRoleShow), false};
                                            Station ->
                                                {{?STATION, MarchRoleUid}, station:get_puid(Station), true}
                                        end,
                                    MarchSpeed = role_addition:get_marching_speed(Src, MarchRoleUid, MarchPoint, map_build_lib:check_station_marchg(IsStation, HaveBuild)),
                                    Marching1 = marching:init(MarchRoleUid, MarchGId, MarchPoint, EndPointUid, MarchSpeed, element(1, MarchPInfo), EndPInfo),

                                    {SoldierBearLoad, OrdnanceBearLoad} = garray_db:get_garray_bearload(Src, MarchRoleUid, MarchGId),
                                    Study = building_db:get_study(Src, MarchRoleUid),
                                    BearLoadAdd = role_addition:get_bear_load_add(Study),
                                    PlunderAdd = role_addition:get_plunder_add(Src, MarchRoleUid),
                                    MarchingExtra = marching:init_role_extra(SoldierBearLoad, OrdnanceBearLoad, BearLoadAdd, PlunderAdd),
                                    Marching = marching:set_extra(Marching1, MarchingExtra),%攻打玩家

                                    TableName = game_lib:get_table(Src),
                                    {MarchState, MProtectTime} = role_show:get_state(MarchRoleShow),
                                    AddCastleTable = if
                                        MarchState =:= ?STATE_PROTECT andalso MProtectTime >= Now ->
                                            [{'castle', MarchRoleUid}];
                                        true -> []
                                    end,
                                    TableKeys = z_db_lib:transformation_tablekey(TableName, [
                                        {'role', MarchRoleUid},
                                        {'garray', {MarchRoleUid, MarchGId}, 'none'},
                                        {'point_march', MarchPoint, point_march:init()},
                                        {'point_march', EndPointUid, point_march:init()},
                                        {'role_restore', MarchRoleUid} | AddCastleTable]),
                                    Reply = case z_db_lib:handle(TableName, {M, F, A}, {Src, MapId, MarchPoint, EndPointUid, Marching, EndPInfo, MarchPInfo, IsStation}, TableKeys) of
                                        {'ok', MarchPMarch, _EndPMarch, BiCs, Bool, _} ->
                                            %bi
                                            zm_event:notify(Src, 'bi_fight_marching_role', [{'role_uid', MarchRoleUid}, {'consumes', BiCs}, {'gid', MarchGId}]),
                                            MarchLine = marching:marching_to_lines(EndPointUid, EndPInfo, Marching),
                                            point_search_db:send_march_line(Src, MarchPoint, EndPointUid, MarchLine, [MarchRoleUid, EndRoleUid]),
                                            %update_rolesho
                                            if
                                                Bool ->
                                                    zm_event:notify(Src, 'update_role_show', {MarchRoleUid, {'castle_state', {?STATE_NOR, 0}}});
                                                true ->
                                                    'ok'
                                            end,
                                            push_message_lib:push(Src, EndRoleUid, 1, []),%攻打玩家,推送
                                            fight_db:add_fight_assist(Src, EndPointUid, Marching),
                                            station_db:update_station_occ_num(Src, MarchPoint, MarchPMarch, IsStation),
                                            fight_db:send_assault_info(Src, MapId, EndRoleUid, Marching, EndPointUid),
                                            "ok";
                                        Err ->
                                            Err
                                    end,
                                    {'ok', [], Info, [{'msg', Reply}]}
                            end;
                        false ->
                            {'ok', [], Info, [{'msg', "not_fight_self"}]}
                    end;
                _ ->
                    {'ok', [], Info, [{'msg', "input_error"}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      行军开始,(城池行军)
%% @end
%% ----------------------------------------------------
marching_town([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    MarchRoleUid = role_lib:get_uid(Attr),
    MarchGId = z_lib:get_value(Msg, "gid", 0),
    EndPointTmp = list_to_integer(z_lib:get_value(Msg, "point_uid", "0")),
    HaveBuild = z_lib:get_value(Msg, "have_build", 0),%0没有建筑,1表示有建筑
    CheckVaild = valid_lib:check_valib([{'ge', EndPointTmp, 0}, {'range', MarchGId, {1, garray_lib:get_max_gid()}}, {'range', HaveBuild, {0, 1}}]),
    if
        CheckVaild ->
            MapId = role_lib:get_mapid(Attr),
            case zm_config:get(point_lib:mapid2cfgname('point_check_town', MapId), EndPointTmp) of
                'none' ->
                    {'ok', [], Info, [{'msg', "input_error"}]};
                {_, TownSidTmp} ->
                    TownSid = point_lib:sidaddmapid(TownSidTmp, MapId),
                    EndPoint = point_lib:xyaddmapid(EndPointTmp, MapId),
                    EndPInfo = {?TOWN, TownSid},
                    MarchRoleShow = role_db:get_role_show(Src, MarchRoleUid),
                    CorpsUid = role_show:get_corps_uid(MarchRoleShow),
                    case corps_db:get_corps(Src, CorpsUid) of
                        'none' ->
                            {'ok', [], Info, [{'msg', "no_corps"}]};
                        Corps ->
                            TownDetail = town_detail:get_cfg(TownSid),
                            CorpsLv = corps:get_level(Corps),
                            NeedCorpsLv = town_detail:get_corps_lv(TownDetail),
                            CheckFightTown = cross_town_fight:check_fight_wunest(Src, MapId, TownSidTmp),
                            if
                                CheckFightTown ->
                                    if
                                        CorpsLv >= NeedCorpsLv ->
                                            Town = z_db_lib:get(game_lib:get_table(Src, 'town'), TownSid, town:init(TownDetail)),
                                            TCorpsUid = town:get_corps_uid(Town),
                                            {TownState, _, TownTime} = town:get_state(Town),
                                            Now = time_lib:now_second(),
                                            IsChief = town_detail:chk_chief(TownDetail),
                                            if
                                                TownState =:= ?STATE_PROTECT andalso TownTime >= Now andalso TCorpsUid =/= CorpsUid ->
                                                    {'ok', [], Info, [{'msg', "town_protect"}]};
                                                true ->
                                                    case IsChief andalso (TCorpsUid =/= CorpsUid) andalso point_db:check_fight_chief(Src, CorpsUid, corps:get_country(Corps), TownDetail) =:= false of
                                                        true ->
                                                            {'ok', [], Info, [{'msg', "normal_town_limit"}]};
                                                        false ->
                                                            restore_db:restore(Src, MarchRoleUid),
                                                            RoleStations = station_db:get_role_stations(Src, MarchRoleUid),
                                                            {MarchPInfo, MarchPoint, IsStation} =
                                                                case lists:keyfind(MarchGId, station:get_gid_index(), RoleStations) of
                                                                    false ->
                                                                        {{?ROLE, MarchRoleUid}, role_show:get_point(MarchRoleShow), false};
                                                                    Station ->
                                                                        {{?STATION, MarchRoleUid}, station:get_puid(Station), true}
                                                                end,
                                                            MarchSpeed = role_addition:get_marching_speed(Src, MarchRoleUid, MarchPoint, map_build_lib:check_station_marchg(IsStation, HaveBuild)),
                                                            Marching = marching:init(MarchRoleUid, MarchGId, MarchPoint, EndPoint, MarchSpeed, element(1, MarchPInfo), EndPInfo),
                                                            Towners = town:get_points_owner(Town),
                                                            Powner = z_lib:get_value(Towners, EndPoint, TCorpsUid),
                                                            TableName = game_lib:get_table(Src),
                                                            {AddCastleTable, NMarching} =
                                                                if
                                                                    Powner =:= 0 orelse Powner =/= CorpsUid ->%有所属,且不同所属,清除保护罩,并攻击状态 -->jira:8221(npc城池也取消)
                                                                        {MarchState, MProtectTime} = role_show:get_state(MarchRoleShow),
                                                                        if
                                                                            MarchState =:= ?STATE_PROTECT andalso MProtectTime >= Now ->
                                                                                {[{'castle', MarchRoleUid}], Marching};
                                                                            true ->
                                                                                {[], Marching}
                                                                        end;
%%                                                            Powner =:= 0 ->%城池没有所属时候,攻击
%%                                                                {[], Marching};
                                                                    true ->
                                                                        {[], marching:set_state(Marching, ?ON_THE_TOWN_GARRISON_MARCHING)}
                                                                end,
                                                            TableKeys = z_db_lib:transformation_tablekey(TableName, [
                                                                {'role', MarchRoleUid},
                                                                {'garray', {MarchRoleUid, MarchGId}, 'none'},
                                                                {'point_march', MarchPoint, point_march:init()},
                                                                {'point_march', EndPoint, point_march:init()},
                                                                {'role_restore', MarchRoleUid} | AddCastleTable]),
                                                            Reply = case z_db_lib:handle(TableName, {M, F, A}, {Src, MapId, MarchPoint, EndPoint, NMarching, EndPInfo, MarchPInfo, IsStation}, TableKeys) of
                                                                {'ok', MarchPMarch, _EndPMarch, BiCs, Bool, _} ->
                                                                    %城池进入有行军攻打状态
                                                                    %bi
                                                                    zm_event:notify(Src, 'bi_fight_marching_town', [{'town_sid', TownSid}, {'role_uid', MarchRoleUid}, {'consumes', BiCs}, {'gid', MarchGId}]),
                                                                    MarchLine = marching:marching_to_lines(EndPoint, EndPInfo, NMarching),
                                                                    point_search_db:send_march_line(Src, MarchPoint, EndPoint, MarchLine, [MarchRoleUid]),
                                                                    if
                                                                        Bool ->
                                                                            zm_event:notify(Src, 'update_role_show', {MarchRoleUid, {'castle_state', {?STATE_NOR, 0}}});
                                                                        true ->
                                                                            'ok'
                                                                    end,
                                                                    fight_db:add_fight_assist(Src, EndPoint, NMarching),
                                                                    station_db:update_station_occ_num(Src, MarchPoint, MarchPMarch, IsStation),
                                                                    "ok";
                                                                Err ->
                                                                    Err
                                                            end,
                                                            {'ok', [], Info, [{'msg', Reply}]}
                                                    end
                                            end;
                                        true ->
                                            {'ok', [], Info, [{'msg', "corps_lv_limit"}]}
                                    end;
                                true ->
                                    {'ok', [], Info, [{'msg', "town_fight_time_limit"}]}
                            end
                    end
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      行军召回
%% @end
%% ----------------------------------------------------
recall([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    MarchRoleUid = role_lib:get_uid(Attr),
    MarchGId = z_lib:get_value(Msg, "gid", 0),
    EndPointTmp = list_to_integer(z_lib:get_value(Msg, "point_uid", "0")),
    Type = z_lib:get_value(Msg, "type", 0),%0=道具,1=rmb
    RecallTime = z_lib:get_value(Msg, "recall_time", 0),
    CheckVaild = valid_lib:check_valib([{'ge', EndPointTmp, 0}, {'ge', RecallTime, 0}]),
    if
        CheckVaild ->
            MapId = role_lib:get_mapid(Attr),
            EndPoint = point_lib:xyaddmapid(EndPointTmp, MapId),
            TableName = game_lib:get_table(Src),
            TableKeys = if
                Type =:= 0 ->
                    z_db_lib:transformation_tablekey(TableName, [{'point_march', EndPoint, 'none'}, {'goods', MarchRoleUid}]);
                true ->
                    z_db_lib:transformation_tablekey(TableName, [{'point_march', EndPoint, 'none'}, {'rmb', MarchRoleUid}])
            end,
            case z_db_lib:handle(TableName, {M, F, A}, {MarchRoleUid, MarchGId, Type, RecallTime, EndPoint}, TableKeys) of
                {'ok', EndPState, GoBackMarch, BiCs, OldMarching, NewMarching, OccMarchings} ->
                    zm_log:info(Src, ?MODULE, 'recall', "fight_recall", [{'roleuid', MarchRoleUid}, {'gid', MarchGId}, {'end_point', EndPoint},
                        {'point_state', EndPState}, {'consume', BiCs}, {'goback_marching', GoBackMarch}]),
                    zm_event:notify(Src, 'bi_fight_recall', [{'role_uid', MarchRoleUid}, {'consumes', BiCs}, {'gid', MarchGId}]),
                    PType = element(1, EndPState),
                    RUids =
                        if
                            PType =:= ?STATION orelse PType =:= ?ROLE ->
                                [element(2, EndPState)];
                            PType =:= ?RESOURCE ->
                                [marching:get_roleuid(OccMarching) || OccMarching <- OccMarchings];
                            true ->
                                []
                        end,
                    point_search_db:send_back_occ_line(Src, time_lib:now_second(), [MarchRoleUid | RUids], EndPoint, EndPState, [GoBackMarch], []),
                    fight_db:update_fight_assist(Src, EndPoint, [OldMarching], [NewMarching]),
                    map_build_db:update_mb_fight_num(Src, marching:get_state(OldMarching), EndPState, EndPoint, -1),
                    lists:foreach(fun(RoleUidTmp) ->
                        fight_db:send_assault_info(Src, MapId, RoleUidTmp, NewMarching, EndPoint) end, RUids),
                    {'ok', [], Info, [{'msg', "ok"}]};
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      行军达到,进行战斗(资源点/土匪/玩家,开始战斗)
%% @end
%% ----------------------------------------------------
arrive(_, _, Attr, Info, Msg) ->
%%    io:format("arrive:~p~n",[Msg]),
    EndPoint = list_to_integer(z_lib:get_value(Msg, "point_uid", "0")),
    CheckVaild = valid_lib:check_valib([{'ge', EndPoint, 0}]),
    if
        CheckVaild ->
            MapId = role_lib:get_mapid(Attr),
            Src = z_lib:get_value(Info, 'src', 'none'),
            zm_event:notify(Src, 'around_fight', [{'pm_uids', [point_lib:xyaddmapid(EndPoint, MapId)]}]),%战斗
            {'ok', [], Info, [{'msg', "ok"}]};
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      行军加速
%% @end
%% ----------------------------------------------------
speed_up([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    MarchRoleUid = role_lib:get_uid(Attr),
    MarchGId = z_lib:get_value(Msg, "gid", 0),
    EndPointTmp = list_to_integer(z_lib:get_value(Msg, "point_uid", "0")),%该条行军终点
    Type = z_lib:get_value(Msg, "type", 0),%0=道具,1=rmb
    CheckVaild = valid_lib:check_valib([{'ge', EndPointTmp, 0}]),
    if
        CheckVaild ->
            MapId = role_lib:get_mapid(Attr),
            {_, {GameSid, CrossSid}} = zm_config:get('fight_info', 'speed_goods_sid'),
            Sid = if
                MapId > 0 ->
                    CrossSid;
                true ->
                    GameSid
            end,
            case prop_kit_lib:get_prop(Sid) of
                'none' ->
                    {'ok', [], Info, [{'msg', "input_error"}]};
                Prop ->
                    Record = prop_kit_lib:get_prop_record(Prop),
                    EndPoint = point_lib:xyaddmapid(EndPointTmp, MapId),
                    case marching_speed_goods:is_marching_speed_goods(Record) of
                        false ->
                            {'ok', [], Info, [{'msg', "input_error"}]};
                        true ->
                            Percent = marching_speed_goods:get_percent(Record),
                            TableName = game_lib:get_table(Src),
                            {TableKeys, Consume} = if
                                Type =:= 0 ->
                                    {z_db_lib:transformation_tablekey(TableName, [{'point_march', EndPoint, 'none'}, {'goods', MarchRoleUid}]), [{Sid, 1}]};
                                true ->
                                    NeedRmb = element(2, zm_config:get('fight_info', 'speed_up')),
                                    {z_db_lib:transformation_tablekey(TableName, [{'point_march', EndPoint, 'none'}, {'rmb', MarchRoleUid}]), NeedRmb}
                            end,
                            MarchRole = role_db:get_role(Src, MarchRoleUid),
                            case z_db_lib:handle(TableName, {M, F, A}, {MarchRoleUid, MarchRole, MarchGId, Consume, Percent, Type}, TableKeys) of
                                {'ok', GoBackFlag, OldMarching, Marching, BiCs, EndPState, OccMarchings} ->
                                    zm_log:info(Src, ?MODULE, 'speed_up', "fight_speed_up", [{'roleuid', MarchRoleUid}, {'gid', MarchGId}, {'end_point', EndPoint},
                                        {'sid', Sid}, {'consume', BiCs}, {'marching', Marching}]),
                                    zm_event:notify(Src, 'bi_fight_speed_up', [{'role_uid', MarchRoleUid}, {'consumes', BiCs}, {'gid', MarchGId}]),
                                    {GList, OList} =
                                        if
                                            GoBackFlag ->
                                                {[Marching], []};
                                            true ->
                                                {[], [Marching]}
                                        end,
                                    PType = element(1, EndPState),
                                    RUids =
                                        if
                                            PType =:= ?STATION orelse PType =:= ?ROLE ->
                                                [element(2, EndPState)];
                                            PType =:= ?RESOURCE ->
                                                [marching:get_roleuid(OccMarching) || OccMarching <- OccMarchings];
                                            true ->
                                                []
                                        end,
                                    point_search_db:send_back_occ_line(Src, time_lib:now_second(), [MarchRoleUid | RUids], EndPoint, EndPState, GList, OList),
                                    fight_db:update_fight_assist(Src, EndPoint, [OldMarching], [Marching]),
                                    lists:foreach(fun(RoleUidTmp) ->
                                        fight_db:send_assault_info(Src, MapId, RoleUidTmp, Marching, EndPoint) end, RUids),
                                    {'ok', [], Info, [{'msg', "ok"}]};
                                Err ->
                                    {'ok', [], Info, [{'msg', Err}]}
                            end
                    end
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.


%%-------------------------------------------------------------------
%% @doc
%%      玩家采集中召回
%% @end
%%-------------------------------------------------------------------
collect_recall([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    MarchRoleUid = role_lib:get_uid(Attr),
    MarchGId = z_lib:get_value(Msg, "gid", 0),
    EndPointTmp = list_to_integer(z_lib:get_value(Msg, "point_uid", "0")),
    CheckVaild = valid_lib:check_valib([{'ge', EndPointTmp, 0}, {'range', MarchGId, {1, garray_lib:get_max_gid()}}]),
    if
        CheckVaild ->
            TableName = game_lib:get_table(Src),
            MapId = role_lib:get_mapid(Attr),
            EndPoint = point_lib:xyaddmapid(EndPointTmp, MapId),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'point_march', EndPoint, 'none'}]),
            case z_db_lib:handle(TableName, {M, F, A}, {{MarchRoleUid, MarchGId}, time_lib:now_second()}, TableKeys) of
                {OldMarching, NewMarching} ->
                    zm_event:notify(Src, 'around_fight', [{'pm_uids', [EndPoint]}]),
                    fight_db:update_fight_assist(Src, EndPoint, [OldMarching], NewMarching),
                    {'ok', [], Info, [{'msg', "ok"}]};
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      通用occ召回
%% @end
%% ----------------------------------------------------
occ_recall([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    MarchRoleUid = role_lib:get_uid(Attr),
    MarchGId = z_lib:get_value(Msg, "gid", 0),
    EndPointTmp = list_to_integer(z_lib:get_value(Msg, "point_uid", "0")),
    CheckVaild = valid_lib:check_valib([{'ge', EndPointTmp, 0}, {'range', MarchGId, {1, garray_lib:get_max_gid()}}]),
    if
        CheckVaild ->
            MapId = role_lib:get_mapid(Attr),
            EndPoint = point_lib:xyaddmapid(EndPointTmp, MapId),
            Reply = fight_db:occ_recall(Src, MarchRoleUid, MarchGId, EndPoint, M, F, A),
            {'ok', [], Info, [{'msg', Reply}]};
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%%-------------------------------------------------------------------
%% @doc
%%      获取袭击者信息
%% @end
%%-------------------------------------------------------------------
assault_info(_, _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    MapId = role_lib:get_mapid(Attr),
    MarchPoints = [point_lib:xyaddmapid(list_to_integer(PointUid), MapId) || PointUid <- string:tokens(z_lib:get_value(Msg, "point_uids", ""), ",")],
    OPUids = [point_lib:xyaddmapid(list_to_integer(PointUid), MapId) || PointUid <- string:tokens(z_lib:get_value(Msg, "o_uids", ""), ",")],
    if
        MarchPoints =:= [] orelse OPUids =:= [] ->
            {'ok', [], Info, [{'msg', "input_error"}]};
        true ->
            Views =
                z_lib:foreach(fun(R, PUid) ->
                    case z_db_lib:get(game_lib:get_table(Src, 'point_march'), PUid, 'none') of
                        'none' ->
                            {ok, R};
                        EndPMarch ->
                            Marchies = point_march:get_marchies(EndPMarch),
                            NR = z_lib:foreach(fun(R1, PUid1) ->
                                MList = lists:filter(fun(M) -> marching:get_s_point(M) =:= PUid1 end, Marchies),
                                {ok, [{point_lib:xyz2view(PUid1), list_to_tuple([fight_db:format_assault(Src, M) || M <- MList])} | R1]}
                            end, R, MarchPoints),%%数据要继续传下去
                            {ok, NR}
                    end
                end, [], OPUids),
            {'ok', [], Info, [{'msg', list_to_tuple(Views)}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      城池战斗倒计时结束/npc刷新 type=0刷新/over=1
%% @end
%% ----------------------------------------------------
town_refresh_over(_, _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    Type = z_lib:get_value(Msg, "type", 0),
    TownSidTmp = list_to_integer(z_lib:get_value(Msg, "town_sid", "0")),
    if
        TownSidTmp < 0 ->
            {'ok', [], Info, [{'msg', "input_error"}]};
        true ->
            MapId = role_lib:get_mapid(Attr),
            if
                MapId > 0 ->
                    if
                        Type =:= 0 ->
                            'ok';
                        true ->
                            TownSid = point_lib:sidaddmapid(TownSidTmp, MapId),
                            cross_town_fight:check_over(Src, TownSid, point_lib:xyaddmapid(town_detail:get_point(town_detail:get_cfg(TownSidTmp)), MapId), [])
                    end;
                true ->
                    if
                        Type =:= 0 ->
                            town_fight_server:check_refresh(Src, TownSidTmp);
%%                            town_fight:check_refresh(Src, TownSidTmp);
                        true ->
                            town_fight_server:check_over(Src, TownSidTmp)
%%                            town_fight:check_over(Src, TownSidTmp, town_detail:get_point(town_detail:get_cfg(TownSidTmp)), [])
                    end
            end,
            {'ok', [], Info, [{'msg', "ok"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     城池驻防中召回
%% @end
%% ----------------------------------------------------
town_recall(_, _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    MarchRoleUid = role_lib:get_uid(Attr),
    MarchGId = z_lib:get_value(Msg, "gid", 0),
    EndPointTmp = list_to_integer(z_lib:get_value(Msg, "point_uid", "0")),
    CheckVaild = valid_lib:check_valib([{'ge', EndPointTmp, 0}, {'range', MarchGId, {1, garray_lib:get_max_gid()}}]),
    if
        CheckVaild ->
            MapId = role_lib:get_mapid(Attr),
            EndPoint = point_lib:xyaddmapid(EndPointTmp, MapId),
            Fun = fun(_, 'none') ->
                throw("input_error");
                (_, EndPMarch) ->
                    {PState, _PTime} = point_march:get_state(EndPMarch),
                    if
                        PState =:= ?PSTATE_FIGHTING ->%战斗中,忽略
                            throw("ok");
                        true ->
                            Marchies = point_march:get_occupy(EndPMarch),
                            case lists:keytake({MarchRoleUid, MarchGId}, marching:get_roleuid_gid_index(), Marchies) of
                                false ->
                                    throw("input_error");
                                {value, Marching, NMarchies} ->
                                    GoBackList = point_march:get_goback(EndPMarch),
                                    GoBack = marching:change_goback_byetime_state(Marching, EndPoint, time_lib:now_second(), ?ON_THE_TOWN_GOBACK),
                                    NGoBackList = [GoBack | GoBackList],
                                    OccLen = length(lists:filter(fun(M) ->
                                        marching:get_state(M) =:= ?ON_THE_TOWN_GARRISON end, NMarchies)),
                                    {'ok', {'ok', point_march:get_point_info(EndPMarch), GoBack, OccLen},
                                        point_march:set_goback(point_march:set_occupy(EndPMarch, NMarchies), NGoBackList)}
                            end
                    end
            end,
            case z_db_lib:update(game_lib:get_table(Src, 'point_march'), EndPoint, 'none', Fun, []) of
                {'ok', EndPState, Marching, NewOccLen} ->
                    zm_log:info(Src, ?MODULE, 'town_recall', "town_recall", [{'roleuid', MarchRoleUid}, {'gid', MarchGId}, {'end_point', EndPoint},
                        {'point_state', EndPState}, {'goback_marching', Marching}]),
                    point_search_db:send_back_occ_line(Src, time_lib:now_second(), MarchRoleUid, EndPoint, EndPState, [Marching], []),
                    TownSidTmp = element(2, EndPState),
                    TownDetail = town_detail:get_cfg(TownSidTmp),
                    point_search_db:update_town_occlen(Src, point_lib:sidaddmapid(TownSidTmp, MapId), TownDetail, [{EndPoint, NewOccLen}]),
                    {'ok', [], Info, [{'msg', "ok"}]};
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      城池,寻访回玩家主城
%% @end
%% ----------------------------------------------------
goback(_, _, Attr, Info, Msg) ->
    EndPointTmp = list_to_integer(z_lib:get_value(Msg, "point_uid", "0")),
    CheckVaild = valid_lib:check_valib([{'ge', EndPointTmp, 0}]),
    if
        CheckVaild ->
            Src = z_lib:get_value(Info, 'src', 'none'),
            MapId = role_lib:get_mapid(Attr),
            EndPoint = point_lib:xyaddmapid(EndPointTmp, MapId),
            Reply = fight_db:goback(Src, EndPoint),
            {'ok', [], Info, [{'msg', Reply}]};
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%
%% @end
%% ----------------------------------------------------

