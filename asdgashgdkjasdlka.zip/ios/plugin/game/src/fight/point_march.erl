-module(point_march).

%%%=======================STATEMENT====================
-description("point_uid对应各种行军信息").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    init/0,
    arrive/3,
    arrive_resource/3,
    arrive_res/3,
    arrive_town/3,
    check_del/1,
    get_arrive/2,
    get_arrive/3,
    check_arrive/2
]).
-export([
    get_role_march/1,
    get_marchies/1,
    get_goback/1,
    get_occupy/1,
    get_point_info/1,
    get_state/1,
    get_march_num_by_type/2

]).
-export([
    set_role_march/2,
    set_marchies/2,
    set_goback/2,
    set_occupy/2,
    set_point_info/2,
    set_state/2,
    update/4,
    check_fighting/1
]).

-export_type([point_march/0]).
%%%=======================INCLUDE======================
-include("../include/point.hrl").
%%%=======================DEFINE======================


%%%=======================RECORD=======================
%point_uid对应各种行军信息
-record(point_march, {
    role_march = [] :: [integer()],%玩家自身行军信息记录 point_uid
    marchies = [] :: [marching:marching()],%行军信息 {marching_uid,状态(行军/占领/返回),当前状态结束时间}
    goback = [] :: [marching:marching()],%返回中的队列信息
    occupy = [] :: [marching:marching()],%占领者行军信息(资源点需要);(注意,防守方按先后到达顺序反着存,先到的在列表最后)
    point_info = {0, 0} :: tuple(),%原先点对应point_state里面存储的信息
    state = {?PSTATE_DEFAULT, 0} :: {integer(), integer()}%point.hrl中
}).

%%%=======================TYPE=========================
-type point_march() :: #point_march{}.


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      获得指定行军类型的行军数量
%% @end
%% ----------------------------------------------------
get_march_num_by_type(#point_march{marchies = Marchies, goback = GoBack}, Type) ->
    Fun = fun(Marching, Num) ->
        Bl = marching:get_state(Marching) =:= Type,
        if
            Bl ->
                Num + 1;
            true ->
                Num
        end
    end,
    Num1 = lists:foldl(Fun, 0, Marchies),
    lists:foldl(Fun, Num1, GoBack).
%% ----------------------------------------------------
%% @doc
%%      获取玩家行军信息
%% @end
%% ----------------------------------------------------
-spec get_role_march(point_march()) -> [integer()].
get_role_march(#point_march{role_march = RMarch}) -> RMarch.

%% ----------------------------------------------------
%% @doc
%%      获取所有行军信息
%% @end
%% ----------------------------------------------------
-spec get_marchies(point_march()) -> [marching:marching()].
get_marchies(#point_march{marchies = Marches}) -> Marches.

%% ----------------------------------------------------
%% @doc
%%      获取所有返回的行军信息
%% @end
%% ----------------------------------------------------
-spec get_goback(point_march()) -> [marching:marching()].
get_goback(#point_march{goback = GoBack}) -> GoBack.

%% ----------------------------------------------------
%% @doc
%%      获取占领者信息
%% @end
%% ----------------------------------------------------
-spec get_occupy(point_march()) -> [marching:marching()].
get_occupy(#point_march{occupy = Occupy}) -> Occupy.

%% ----------------------------------------------------
%% @doc
%%      获取行军终点类型
%% @end
%% ----------------------------------------------------
-spec get_point_info(point_march()) -> tuple().
get_point_info(#point_march{point_info = PInfo}) -> PInfo.

%% ----------------------------------------------------
%% @doc
%%      获取最近的状态
%% @end
%% ----------------------------------------------------
-spec get_state(point_march()) -> {integer(), integer()}.
get_state(#point_march{state = State}) -> State.

%% ----------------------------------------------------
%% @doc
%%      设置玩家行军信息
%% @end
%% ----------------------------------------------------
-spec set_role_march(point_march(), [integer()]) -> point_march().
set_role_march(PMarch, RMarch) ->
    PMarch#point_march{role_march = RMarch}.

%% ----------------------------------------------------
%% @doc
%%      设置行军信息
%% @end
%% ----------------------------------------------------
-spec set_marchies(point_march(), [marching:marching()]) -> point_march().
set_marchies(PMarch, Marchies) ->
    PMarch#point_march{marchies = lists:keysort(marching:get_etime_index(), Marchies)}.

%% ----------------------------------------------------
%% @doc
%%      设置返回的行军信息
%% @end
%% ----------------------------------------------------
-spec set_goback(point_march(), [marching:marching()]) -> point_march().
set_goback(PMarch, GoBack) ->
    PMarch#point_march{goback = lists:keysort(marching:get_etime_index(), GoBack)}.

%% ----------------------------------------------------
%% @doc
%%      设置占领者行军信息
%% @end
%% ----------------------------------------------------
-spec set_occupy(point_march(), [marching:marching()]) -> point_march().
set_occupy(PMarch, Occupy) ->
    PMarch#point_march{occupy = Occupy}.

%% ----------------------------------------------------
%% @doc
%%      设置行军终点信息
%% @end
%% ----------------------------------------------------
-spec set_point_info(point_march(), tuple()) -> point_march().
set_point_info(PMarch, PointState) ->
    PMarch#point_march{point_info = PointState}.

%% ----------------------------------------------------
%% @doc
%%      设置行军最近处理状态
%% @end
%% ----------------------------------------------------
-spec set_state(point_march(), {integer(), integer()}) -> point_march().
set_state(PMarch, State) ->
    PMarch#point_march{state = State}.

%% ----------------------------------------------------
%% @doc
%%      初始化行军信息
%% @end
%% ----------------------------------------------------
-spec init() -> point_march().
init() ->
    #point_march{}.

%% ----------------------------------------------------
%% @doc
%%      初始化行军信息
%% @end
%% ----------------------------------------------------
-spec arrive(point_march(), integer(), integer()) -> {[marching:marching()], point_march()}.
arrive(PMarch, PointUid, Now) ->
    #point_march{marchies = Marchies, goback = GoBack} = PMarch,
    {ArrMarch, NotArrMarch} = get_arrive(Marchies, Now),%派遣友军的 也要 加入返回队列
    Index = marching:get_etime_index(),
    ArrMarchToGoback = lists:filter(fun marching:filter/1, ArrMarch),
    NPMarch = PMarch#point_march{marchies = lists:keysort(Index, NotArrMarch),
        goback = lists:keysort(Index, marching:change_goback(ArrMarchToGoback, PointUid) ++ GoBack)},
    {ArrMarch, NPMarch}.

%% ----------------------------------------------------
%% @doc
%%      初始化资源点行军到达信息
%% @end
%% ----------------------------------------------------
arrive_resource(PMarch, PointUid, Now) ->
    MapId = point_lib:xyz2mapid(PointUid),
    if
        MapId =:= 0 ->%游戏服
            #point_march{marchies = Marchies, occupy = Occupy, goback = Gobacks} = PMarch,
            {ArrMarch, NotArrMarch} = get_arrive(Marchies, Now),
            Index = marching:get_etime_index(),
            %%occ时间需要动态计算
            case Occupy =/= [] andalso marching:get_etime(hd(Occupy)) =< Now + ?FAILOVER_TIME of
                true ->
                    NArrMarch = lists:keysort(Index, [hd(Occupy) | ArrMarch]),
                    NGobacks = lists:keysort(Index, marching:change_goback(NArrMarch, PointUid) ++ Gobacks),
                    {NArrMarch, PMarch#point_march{marchies = NotArrMarch, occupy = [], goback = NGobacks}};
                false ->
                    NGobacks = lists:keysort(Index, marching:change_goback(ArrMarch, PointUid) ++ Gobacks),
                    {ArrMarch, PMarch#point_march{marchies = NotArrMarch, goback = NGobacks}}
            end;
        true ->%跨服,occ不做处理
            #point_march{marchies = Marchies, occupy = Occupy, goback = Gobacks} = PMarch,
            {ArrMarch, NotArrMarch} = get_arrive(Marchies, Now),
            Index = marching:get_etime_index(),
            Reply = Occupy ++ ArrMarch,
            NGobacks = lists:keysort(Index, marching:change_goback(Reply, PointUid, Now) ++ Gobacks),
            {Reply, PMarch#point_march{marchies = NotArrMarch, occupy = [], goback = NGobacks}}
    end.

%% ----------------------------------------------------
%% @doc
%%      初始化新资源点行军到达信息
%% @end
%% ----------------------------------------------------
-spec arrive_res(point_march(), integer(), integer()) -> {[marching:marching()], point_march()}.
arrive_res(PMarch, PointUid, Now) ->
    #point_march{marchies = Marchies, occupy = Occupy, goback = Gobacks} = PMarch,
    {ArrMarch, NotArrMarch} = get_arrive(Marchies, Now),
    Index = marching:get_etime_index(),
    %%occ时间需要动态计算
    case Occupy =/= [] andalso marching:get_etime(hd(Occupy)) =< Now + ?FAILOVER_TIME of
        true ->
            NArrMarch = lists:keysort(Index, [hd(Occupy) | ArrMarch]),
            NGobacks = lists:keysort(Index, marching:change_goback(NArrMarch, PointUid) ++ Gobacks),
            {NArrMarch, PMarch#point_march{marchies = NotArrMarch, occupy = [], goback = NGobacks}};
        false ->
            NGobacks = lists:keysort(Index, marching:change_goback(ArrMarch, PointUid) ++ Gobacks),
            {ArrMarch, PMarch#point_march{marchies = NotArrMarch, goback = NGobacks}}
    end.

%% ----------------------------------------------------
%% @doc
%%      城池有到达(将所有到达的,先加入goback,以免中途错误,玩家队伍无法回归问题)
%% @end
%% ----------------------------------------------------
-spec arrive_town(point_march(), integer(), integer()) -> {[marching:marching()], point_march()}.
arrive_town(PMarch, PointUid, Now) ->
    #point_march{marchies = Marchies, goback = GoBack} = PMarch,
    {ArrMarch, NotArrMarch} = get_arrive(Marchies, Now),
    AddGobacks = z_lib:foreach(fun(Acc, Marching) ->
        case marching:get_state(Marching) =/= ?ON_THE_YS_MARCHING of
            true ->
                {ok, [marching:change_goback_bystate(Marching, PointUid, ?ON_THE_TOWN_GOBACK) | Acc]};
            false ->
                {ok, Acc}
        end
    end, [], ArrMarch),
    Index = marching:get_etime_index(),
    NPMarch = PMarch#point_march{marchies = lists:keysort(Index, NotArrMarch),
        goback = lists:keysort(Index, AddGobacks ++ GoBack)},
    {ArrMarch, NPMarch}.

%% ----------------------------------------------------
%% @doc
%%      根据信息判断是否删除该数据信息
%% @end
%% ----------------------------------------------------
-spec check_del(point_march()) -> 'delete'|point_march().
check_del(PMarch) ->
    #point_march{role_march = RMarch, marchies = March, goback = GoBack, occupy = Occupy} = PMarch,
    case RMarch =:= [] andalso March =:= [] andalso GoBack =:= [] andalso Occupy =:= [] of
        true ->
            'delete';
        _ ->
            PMarch
    end.

%% ----------------------------------------------------
%% @doc
%%      行军到达的队列(因为队列是按照etime排序了的,所以不满足就直接break)
%% @end
%% ----------------------------------------------------
get_arrive(Marchies, Now) ->
    get_arrive(Marchies, Now, true).

%% ----------------------------------------------------
%% @doc
%%      行军到达的队列(因为队列是按照etime排序了的,所以不满足就直接break)
%% @end
%% ----------------------------------------------------
get_arrive(Marchies, Now, Bool) ->
    if
        Bool ->%是否增加2秒的容错处理
            get_arrive_1(Marchies, Now + ?FAILOVER_TIME, []);
        true ->
            get_arrive_1(Marchies, Now, [])
    end.

%% ----------------------------------------------------
%% @doc
%%      检测是否存在行军到达的队列(因为队列是按照etime排序了的,所以不满足就直接break)
%% @end
%% ----------------------------------------------------
-spec check_arrive(Marchies :: [marching:marching()], Now :: integer()) -> boolean().
check_arrive(Marchies, Now) ->
    F1 = fun(_, Marching) ->
        ETime = marching:get_etime(Marching),
        if
            ETime =< Now + ?FAILOVER_TIME ->%设置5秒的容错时间
                {'break', true};
            true ->
                {'break', false}
        end
    end,
    z_lib:foreach(F1, false, Marchies).

%% ----------------------------------------------------
%% @doc
%%      更新各队列
%% @end
%% ----------------------------------------------------
-spec update(point_march(), [marching:marching()], [marching:marching()], [marching:marching()]) -> point_march().
update(PMarch, AList, OList, GList) ->
    Index = marching:get_etime_index(),
    #point_march{marchies = MList, occupy = OccList, goback = GobackList} = PMarch,
    PMarch#point_march{marchies = lists:keysort(Index, AList ++ MList), occupy = OList ++ OccList, goback = lists:keysort(Index, GList ++ GobackList)}.


%% ----------------------------------------------------
%% @doc
%%      是否战斗中(战斗中会throw错误字符串)
%% @end
%% ----------------------------------------------------
check_fighting(PointMarch) ->
    {PState, Timeout} = point_march:get_state(PointMarch),
    case PState =:= ?PSTATE_FIGHTING andalso time_lib:now_second() < Timeout of
        true ->
            throw("point_fight");
        false ->
            ok
    end.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%      行军到达的队列,并得到派遣援助的队列(因为队列是按照etime排序了的)
%% @end
%% ----------------------------------------------------
-spec get_arrive_1(Marchies, CheckTime, Acc) -> {[marching:marching()], [marching:marching()]} when
    Marchies :: [marching:marching()],
    CheckTime :: integer(),
    Acc :: [marching:marching()].
get_arrive_1([Marching | Marchies] = Reply, CheckTime, Acc) ->
    ETime = marching:get_etime(Marching),
    if
        ETime =< CheckTime ->
            get_arrive_1(Marchies, CheckTime, [Marching | Acc]);
        true ->
            {lists:reverse(Acc), Reply}
    end;
get_arrive_1([], _Now, Acc) ->
    {lists:reverse(Acc), []}.



