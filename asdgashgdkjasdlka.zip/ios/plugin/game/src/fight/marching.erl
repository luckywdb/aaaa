-module(marching).

%%%=======================STATEMENT====================
-description("行军记录").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    init/7,
    get_etime_index/0,
    get_roleuid_gid_index/0,
    get_s_point_index/0,
    get_stime_index/0,
    fight_result/4,
    change_goback/2,
    change_goback/3,
    change_goback/4,
    change_goback/5,
    change_goback_byetime/3,
    change_goback_byetime_state/4,
    change_goback_bystate/3,
    change_recall/4,
    change_occ/3,
    marching_to_lines/3,
    look_marching/4
]).
-export([
    get_roleuid_gid/1,
    get_roleuid/1,
    get_gid/1,
    get_s_point/1,
    get_stime/1,
    get_etime/1,
    get_injured/1,
    get_dead/1,
    get_award/1,
    get_speed/1,
    get_extra/1,
    get_state/1,
    get_add_speed_times/1,
    get_fight_num/1,
    get_epstate/1,
    get_sptype/1
]).
-export([
    set_spoint/2,
    set_award/2,
    set_stime/2,
    set_etime/2,
    set_extra/2,
    set_state/2,
    set_add_speed_times/2,
    change_spoint/5,
    set_injured/2,
    set_dead/2,
    set_epstate/2,
    set_fight_num/2,
    set_sptype/2,
    set_gid/2
]).

-export([
    init_extra/3,
    init_resource_extra/6,
    init_role_extra/4,
    init_look_extra/2,
    init_station_extra/1,
    init_mb_extra/2,
    init_mb_cc_extra/2,
    get_extra_bearload/1,
    get_extra_soldier_bearload/1,
    get_extra_ordnance_bearload/1,
    get_extra_bearload_add/1,
    get_extra_collect_active_add/1,
    get_extra_collect_plunder/1,
    get_extra_collect_speed_add/1,
    get_extra_collect_town_add/1,
    get_extra_role_plunder_add/1,
    get_extra_looksid/1,
    get_extra_look_townlv/1,
    get_extra_occ_time/1,
    get_extra_station_leisure_num/1,
    get_extra_mb_speed/1,
    get_extra_mb_const/1,
    get_extra_mb_cc_corpsname/1,
    get_extra_mb_cc_country/1,

    set_extra_occ_time/2,
    set_extra_collext_plunder/2,
    set_extra_soldier_bearload/2,
    set_extra_mb_speed/2
]).
-export_type([marching/0, marching_extra/0]).
-export([filter/1]).
%%%=======================INCLUDE======================
-include("../include/point.hrl").

%%%=======================RECORD======================
%%v1,v2,v7, occ_time必须为大于等于0整数数字
-record(marching_extra, {
    v1 = 0 :: any(), %%
    v2 = 0 :: any(), %%
    v3 = 0 :: any(),%%
    v4 = 0 :: any(), %%
    v5 = 0 :: any(),%%
    v6 = 0 :: any(),%% {integer(), integer()}->资源点加层使用
    v7 = 0 :: any(),%%
    occ_time = 0 :: integer()%驻防时间
}).
%行军具体信息
-record(marching, {
    roleuid_gid :: {integer(), integer()},%发起行军{玩家uid,gid}
    s_point :: integer(),%起点(玩家坐标)
    speed :: integer(),%当前速度
    stime :: integer(),%开始时间
    etime :: integer(),%到达目的地时间
    injured = 0 :: integer(), %战斗产生伤兵数量
    dead = 0 :: integer(),%战斗死亡兵数量
    award = [] :: list()|tuple(),%奖励信息
    extra = #marching_extra{} :: marching_extra(),%%资源点采集信息 {最大负重(所有兵负重相加),科技负重加成万分比,采集速度加成万分比,掠夺的量,resource_sid,活动增加万分比,城池增加万分比}/攻打玩家{最大负重,科技加成,采集加成,掠夺功勋加成}
    state = 0 :: integer(), %状态,默认普通状态(往军团其他城堡驻防行军使用)
    add_speed_times = 0 :: integer(), %% 加速次数
    fight_num = 0 :: integer(), %%战斗次数
    epstate = {} :: tuple(), %%终点状态
    sptype = 0 :: integer()%%起点类型
}).


%%%=======================DEFINE=======================

%%%=======================TYPE=========================
-type marching() :: #marching{}.
-type marching_extra() :: #marching_extra{}.


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      获取行军{roleuid,gid}
%% @end
%% ----------------------------------------------------
-spec get_roleuid_gid(marching()) -> {integer(), integer()}.
get_roleuid_gid(#marching{roleuid_gid = Role}) -> Role.
%% ----------------------------------------------------
%% @doc
%%      获取行军roleuid
%% @end
%% ----------------------------------------------------
-spec get_roleuid(marching()) -> integer().
get_roleuid(#marching{roleuid_gid = {RoleUid, _}}) -> RoleUid.
%% ----------------------------------------------------
%% @doc
%%      获取行军玩家阵型gid
%% @end
%% ----------------------------------------------------
-spec get_gid(marching()) -> integer().
get_gid(#marching{roleuid_gid = {_, GId}}) -> GId.
%% ----------------------------------------------------
%% @doc
%%      获取行军起始点
%% @end
%% ----------------------------------------------------
-spec get_s_point(marching()) -> integer().
get_s_point(#marching{s_point = SPoint}) -> SPoint.
%% ----------------------------------------------------
%% @doc
%%      获取行军当前状态开始时间
%% @end
%% ----------------------------------------------------
-spec get_stime(marching()) -> integer().
get_stime(#marching{stime = STime}) -> STime.
%% ----------------------------------------------------
%% @doc
%%      获取行军当前状态结束时间
%% @end
%% ----------------------------------------------------
-spec get_etime(marching()) -> integer().
get_etime(#marching{etime = ETime}) -> ETime.
%% ----------------------------------------------------
%% @doc
%%      获取行军产生的伤兵
%% @end
%% ----------------------------------------------------
-spec get_injured(marching()) -> integer().
get_injured(#marching{injured = Injured}) -> Injured.
%% ----------------------------------------------------
%% @doc
%%      获取行军死亡兵数量
%% @end
%% ----------------------------------------------------
-spec get_dead(marching()) -> integer().
get_dead(#marching{dead = Dead}) -> Dead.

%% ----------------------------------------------------
%% @doc
%%      获取奖励
%% @end
%% ----------------------------------------------------
-spec get_award(marching()) -> list()|tuple().
get_award(#marching{award = Award}) -> Award.

%% ----------------------------------------------------
%% @doc
%%      获取速度
%% @end
%% ----------------------------------------------------
-spec get_speed(marching()) -> integer().
get_speed(#marching{speed = Speed}) -> Speed.

%% ----------------------------------------------------
%% @doc
%%      获取额外信息
%% @end
%% ----------------------------------------------------
-spec get_extra(marching()) -> marching_extra().
get_extra(#marching{extra = V}) -> V.
%% ----------------------------------------------------
%% @doc
%%      获取状态(是否为派遣给友军)
%% @end
%% ----------------------------------------------------
-spec get_state(marching()) -> integer().
get_state(#marching{state = State}) -> State.
%% ----------------------------------------------------
%% @doc
%%      获取增加速度次数
%% @end
%% ----------------------------------------------------
-spec get_add_speed_times(marching()) -> integer().
get_add_speed_times(#marching{add_speed_times = Times}) -> Times.

%%-------------------------------------------------------------------
%% @doc
%%    战斗次数
%% @end
%%-------------------------------------------------------------------
get_fight_num(#marching{fight_num = V}) -> V.


%% ----------------------------------------------------
%% @doc
%%      起点类型
%% @end
%% ----------------------------------------------------
get_sptype(#marching{sptype = V}) -> V.
%% ----------------------------------------------------
%% @doc
%%    获取终点信息
%% @end
%% ----------------------------------------------------
get_epstate(#marching{epstate = V}) -> V.
%% ----------------------------------------------------
%% @doc
%%      设置奖励
%% @end
%% ----------------------------------------------------
-spec set_award(marching(), Award) -> marching() when
    Award :: list().
set_award(Marching, Award) ->
    Marching#marching{award = Award}.

%% ----------------------------------------------------
%% @doc
%%      设置gid
%% @end
%% ----------------------------------------------------
set_gid(#marching{roleuid_gid = {RoleUid, _}} = Marching, Gid) ->
    Marching#marching{roleuid_gid = {RoleUid, Gid}}.

%% ----------------------------------------------------
%% @doc
%%      设置起点
%% @end
%% ----------------------------------------------------
set_spoint(Marching, SPoint) ->
    Marching#marching{s_point = SPoint}.
%% ----------------------------------------------------
%% @doc
%%      设置开始时间
%% @end
%% ----------------------------------------------------
-spec set_stime(marching(), integer()) -> marching().
set_stime(Marching, STime) ->
    Marching#marching{stime = STime}.

set_sptype(Marching, SPType) ->
    Marching#marching{sptype = SPType}.
set_epstate(Marching, EPState) ->
    Marching#marching{epstate = EPState}.
%% ----------------------------------------------------
%% @doc
%%      设置结束时间
%% @end
%% ----------------------------------------------------
-spec set_etime(marching(), integer()) -> marching().
set_etime(Marching, ETime) ->
    Marching#marching{etime = ETime}.

%% ----------------------------------------------------
%% @doc
%%      设置采集信息
%% @end
%% ----------------------------------------------------
-spec set_extra(marching(), marching_extra()) -> marching().
set_extra(Marching, Extra) ->
    Marching#marching{extra = Extra}.

%% ----------------------------------------------------
%% @doc
%%      设置状态
%% @end
%% ----------------------------------------------------
-spec set_state(marching(), integer()) -> marching().
set_state(Marching, State) ->
    Marching#marching{state = State}.

%% ----------------------------------------------------
%% @doc
%%      设置增加速度次数
%% @end
%% ----------------------------------------------------
-spec set_add_speed_times(marching(), integer()) -> marching().
set_add_speed_times(Marching, Times) ->
    Marching#marching{add_speed_times = Times}.

set_injured(Marching, Injured) ->
    Marching#marching{injured = Injured}.

set_dead(Marching, DeadNum) ->
    Marching#marching{dead = DeadNum}.

set_fight_num(Marching, FNum) ->
    Marching#marching{fight_num = FNum}.
%% ----------------------------------------------------
%% @doc
%%      设置行军起点坐标
%% @end
%% ----------------------------------------------------
-spec change_spoint(integer(), marching(), integer(), integer(), boolean()) -> marching().
change_spoint(Now, Marching, SPoint, EndPoint, Bool) ->
    #marching{speed = Speed, add_speed_times = STimes} = Marching,
    if
        Bool ->
            DisTenctTime = point_lib:get_2point_time(SPoint, EndPoint, trunc(Speed * math:pow(2, STimes))),
            NEtime = Now + DisTenctTime,
            Marching#marching{s_point = SPoint, stime = Now, etime = NEtime};
        true ->
            Marching#marching{s_point = SPoint}
    end.

%% ----------------------------------------------------
%% @doc
%%      初始化行军详细信息
%% @end
%% ----------------------------------------------------
-spec init(MarchRoleUid, MarchGId, MarchRolePoint, EndPoint, MarchSpeed, SPType, EndPState) -> marching() when
    MarchRoleUid :: integer(),
    MarchGId :: integer(),
    MarchRolePoint :: integer(),
    EndPoint :: integer(),
    MarchSpeed :: integer(),
    SPType :: integer(),
    EndPState :: tuple().
init(MarchRoleUid, MarchGId, MarchRolePoint, EndPoint, MarchSpeed, SPType, EndPState) ->%{MarchRoleUid,MarchGId}的点MarchRolePoint使用MarchSpeed速度往EndPoint行军
    NeedTime = point_lib:get_2point_time(MarchRolePoint, EndPoint, MarchSpeed),
    Now = time_lib:now_second(),
    #marching{roleuid_gid = {MarchRoleUid, MarchGId}, speed = MarchSpeed,
        state = ?ON_THE_MARCHING, sptype = SPType,
        stime = Now, etime = Now + NeedTime, s_point = MarchRolePoint, epstate = EndPState}.

%%-------------------------------------------------------------------
%% @doc
%%      初始玩家额外数据
%% @end
%%-------------------------------------------------------------------
init_role_extra(SoldierBearLoad, OrdnanceBearLoad, BearLoadAdd, PlunderAdd) ->
    #marching_extra{
        v1 = SoldierBearLoad, v2 = BearLoadAdd, v3 = PlunderAdd, v7 = OrdnanceBearLoad
    }.

%%-------------------------------------------------------------------
%% @doc
%%      初始玩家寻访额外数据
%% @end
%%-------------------------------------------------------------------
init_look_extra(LookSid, TownLv) -> #marching_extra{v1 = LookSid, v2 = TownLv}.

%%-------------------------------------------------------------------
%% @doc
%%      初始资源点额外数据
%% @end
%%-------------------------------------------------------------------
init_resource_extra(SoldierBearLoad, OrdnanceBearLoad, BearLoadAdd, SpeedAdd, ActiveAdd, TownAdd) ->
    #marching_extra{
        v1 = SoldierBearLoad, v2 = BearLoadAdd, v3 = SpeedAdd,
        v5 = ActiveAdd, v6 = TownAdd, v7 = OrdnanceBearLoad
    }.

%% ----------------------------------------------------
%% @doc
%%    驻扎额外数据
%% @end
%% ----------------------------------------------------
init_station_extra(LeisureNum) ->
    #marching_extra{v1 = LeisureNum}.

get_extra_bearload(#marching_extra{v1 = SoldierBearLoad, v2 = BearLoadAdd, v7 = OrdnanceBearLoad}) ->
    SoldierBearLoad * (10000 + BearLoadAdd) div 10000 + OrdnanceBearLoad.

init_mb_extra(Speed, Const) ->
    #marching_extra{v1 = Speed, v3 = Const}.

get_extra_soldier_bearload(MarchingExtra) -> MarchingExtra#marching_extra.v1.
set_extra_soldier_bearload(MarchingExtra, SoldierBearLoad) -> MarchingExtra#marching_extra{v1 = SoldierBearLoad}.
get_extra_ordnance_bearload(MarchingExtra) -> MarchingExtra#marching_extra.v7.
get_extra_bearload_add(MarchingExtra) -> MarchingExtra#marching_extra.v2.
get_extra_collect_speed_add(MarchingExtra) -> MarchingExtra#marching_extra.v3.
get_extra_collect_plunder(MarchingExtra) -> MarchingExtra#marching_extra.v4.
get_extra_collect_active_add(MarchingExtra) -> MarchingExtra#marching_extra.v5.
get_extra_collect_town_add(MarchingExtra) -> MarchingExtra#marching_extra.v6.
get_extra_role_plunder_add(MarchingExtra) -> MarchingExtra#marching_extra.v3.
get_extra_looksid(MarchingExtra) -> MarchingExtra#marching_extra.v1.
get_extra_look_townlv(MarchingExtra) -> MarchingExtra#marching_extra.v2.
get_extra_occ_time(MarchingExtra) -> MarchingExtra#marching_extra.occ_time.
get_extra_station_leisure_num(MarchingExtra) -> MarchingExtra#marching_extra.v1.
get_extra_mb_speed(MarchingExtra) -> MarchingExtra#marching_extra.v1.
get_extra_mb_const(MarchingExtra) -> MarchingExtra#marching_extra.v3.
set_extra_occ_time(MarchingExtra, OccTime) -> MarchingExtra#marching_extra{occ_time = OccTime}.
set_extra_collext_plunder(MarchingExtra, Plunder) -> MarchingExtra#marching_extra{v4 = Plunder}.
set_extra_mb_speed(MarchingExtra, SoldierNum) -> MarchingExtra#marching_extra{v1 = SoldierNum}.

init_mb_cc_extra(CorpsName, Country) ->
    #marching_extra{v2 = Country, v3 = CorpsName}.

get_extra_mb_cc_corpsname(#marching_extra{v3 = V}) -> V.
get_extra_mb_cc_country(#marching_extra{v2 = V}) -> V.


init_extra(SoldierBearLoad, OrdnanceBearLoad, BearLoadAdd) ->
    #marching_extra{
        v1 = SoldierBearLoad, v2 = BearLoadAdd, v7 = OrdnanceBearLoad
    }.

%% ----------------------------------------------------
%% @doc
%%      获取etime的索引位置
%% @end
%% ----------------------------------------------------
-spec get_etime_index() -> integer().
get_etime_index() -> #marching.etime.

%% ----------------------------------------------------
%% @doc
%%      获取{roleuid,gid}的索引位置
%% @end
%% ----------------------------------------------------
-spec get_roleuid_gid_index() -> integer().
get_roleuid_gid_index() -> #marching.roleuid_gid.

%% ----------------------------------------------------
%% @doc
%%      获取s_point的索引位置
%% @end
%% ----------------------------------------------------
-spec get_s_point_index() -> integer().
get_s_point_index() -> #marching.s_point.

%% ----------------------------------------------------
%% @doc
%%      获取开始时间索引
%% @end
%% ----------------------------------------------------
-spec get_stime_index() -> integer().
get_stime_index() -> #marching.stime.

%% ----------------------------------------------------
%% @doc
%%      进行战斗后,信息修改
%% @end
%% ----------------------------------------------------
-spec fight_result(marching(), integer(), integer(), list()) -> marching().
fight_result(Marching, Injured, Dead, Award) ->
    #marching{injured = OldInjured, dead = OldDead, award = OldAward, fight_num = FightNum} = Marching,
    NAward = if
        is_list(Award) ->
            awarder_game:merger(Award, OldAward);
        true ->
            Award
    end,
    Marching#marching{injured = OldInjured + Injured, dead = OldDead + Dead, award = NAward, fight_num = FightNum + 1}.

%% ----------------------------------------------------
%% @doc
%%      行军到达的队列,改变行军时间,(行军到达,立即返回的)
%% @end
%% ----------------------------------------------------
-spec change_goback(Marchies :: [marching()] | marching(), EndPoint :: integer()) -> [marching()] | marching().
change_goback(Marching, EndPoint) when is_record(Marching, 'marching') ->
    MState = goback_state(marching:get_state(Marching)),
    change_goback(Marching, EndPoint, 0, MState);
change_goback(Marchings, EndPoint) ->
    [
        begin
            MState = goback_state(marching:get_state(M)),
            change_goback(M, EndPoint, 0, MState)
        end || M <- Marchings].


change_goback(Marching, EndPoint, STime) when is_record(Marching, 'marching') ->
    MState = goback_state(marching:get_state(Marching)),
    change_goback(Marching, EndPoint, STime, MState);
change_goback(Marchings, EndPoint, STime) ->
    [
        begin
            MState = goback_state(marching:get_state(M)),
            change_goback(M, EndPoint, STime, MState)
        end || M <- Marchings].
%% ----------------------------------------------------
%% @doc
%%      行军到达的队列,改变行军时间(行军到达后,驻守很久之后,返回开始时间传入进来)
%% @end
%% ----------------------------------------------------
-spec change_goback_byetime(Marchies :: [marching()] | marching(), EndPoint :: integer(), LineSTime :: integer()) -> [marching()] | marching().
change_goback_byetime(Marching, EndPoint, LineSTime) ->
    change_goback(Marching, EndPoint, LineSTime, ?ON_THE_GOBACK).

%% ----------------------------------------------------
%% @doc
%%      行军到达的队列,改变行军时间(行军到达后,驻守很久之后,返回开始时间传入进来)
%% @end
%% ----------------------------------------------------
-spec change_goback_byetime_state(Marchies :: [marching()] | marching(), EndPoint :: integer(), LineSTime :: integer(), State :: integer()) -> [marching()] | marching().
change_goback_byetime_state(Marching, EndPoint, LineSTime, State) ->
    change_goback(Marching, EndPoint, LineSTime, State).

%% ----------------------------------------------------
%% @doc
%%      行军到达的队列,改变行军时间(行军到达后,驻守很久之后,返回开始时间传入进来)
%% @end
%% ----------------------------------------------------
-spec change_goback_bystate(Marchies :: [marching()] | marching(), EndPoint :: integer(), State :: integer()) -> [marching()] | marching().
change_goback_bystate(Marching, EndPoint, State) ->
    change_goback(Marching, EndPoint, 0, State).

%% ----------------------------------------------------
%% @doc
%%     指定返回类型
%% @end
%% ----------------------------------------------------
change_goback(Marching, EndPoint, LineSTime, State) ->
    #marching{s_point = SPointUid} = Marching,
    change_goback(Marching, SPointUid, EndPoint, LineSTime, State).
%% ----------------------------------------------------
%% @doc
%%     指定返回类型和起点
%% @end
%% ----------------------------------------------------
change_goback(Marching, SPointUid, EndPoint, LineSTime, State) ->
    #marching{speed = Speed, etime = ETime, stime = STime, extra = Extra} = Marching,
    NewSTime = if
        LineSTime > 0 ->
            LineSTime;
        true ->
            ETime
    end,
    DisTenctTime = point_lib:get_2point_time(SPointUid, EndPoint, Speed),
    NExtra = set_extra_occ_time(Extra, NewSTime - STime),
    Marching#marching{s_point = SPointUid, stime = NewSTime, etime = NewSTime + DisTenctTime, add_speed_times = 0, state = State, extra = NExtra}.
%% ----------------------------------------------------
%% @doc
%%      行军召回,改变行军时间(行军中召回)
%% @end
%% ----------------------------------------------------
-spec change_recall(Marchies :: marching(), Now :: integer(), RecallPUid :: integer(), EndPoint :: integer()) -> {marching(), marching()}.
change_recall(Marching, Now, RecallTime, EndPoint) ->
    #marching{stime = STime, s_point = SPoint, speed = Speed, state = State} = Marching,
    OldNeedTime = point_lib:get_2point_time(SPoint, EndPoint, Speed),
    %%行军时间不能比原行军时间还要长
    NeedTime = if
        RecallTime > OldNeedTime ->
            Now - STime;
        true ->
            max(Now - STime, RecallTime)
    end,
    NState =
        if
            State =:= ?ON_THE_LOOK_MARCHING ->
                ?ON_THE_LOOK_GOBACK_RECALL;
            State =:= ?ON_THE_CASTLE_MARCHING ->
                ?ON_THE_CASTLE_GOBACK;
            State =:= ?ON_THE_INVESTIGATE ->
                ?ON_THE_INVESTIGATE_GOBACK;
            true ->
                ?ON_THE_GOBACK
        end,
    {Marching#marching{stime = Now, etime = Now + NeedTime, add_speed_times = 0, state = NState},
        Marching#marching{stime = Now - (OldNeedTime - NeedTime), etime = Now + NeedTime, add_speed_times = 0, state = NState}}.

%% ----------------------------------------------------
%% @doc
%%      occ开始时间结束时间,状态(各驻防状态设置 etime=-1)
%% @end
%% ----------------------------------------------------
change_occ(Marching, STime, State) ->
    Marching#marching{stime = STime, state = State}.

%% ----------------------------------------------------
%% @doc
%%     将行军信息转换为线信息(注意:如果是返回中,则起点和终点前台要切换位置)
%% @end
%% ----------------------------------------------------
-spec marching_to_lines(EndPoint, EndPState, Marching) -> list() when
    EndPoint :: integer(),
    EndPState :: tuple(),
    Marching :: marching()|[marching()].
marching_to_lines(EndPoint, _EndPState, Marching) when is_record(Marching, 'marching') ->
    #marching{roleuid_gid = {RoleUid, GId}, s_point = MarchPoint, speed = Speed, stime = STime,
        etime = ETime, state = State, add_speed_times = AddSpeedTimes, sptype = SPType, epstate = EPState} = Marching,
    NETime =
        if
            State =:= ?ON_THE_CASTLE -> %各驻防没有结束时间的给前台 -1
                -1;
            State =:= ?ON_THE_CASTLE_OTHER ->
                -1;
            State =:= ?ON_THE_TOWN_GARRISON ->
                -1;
            State =:= ?ON_THE_GARRISON_RES ->
                -1;
            State =:= ?ON_THE_STATION ->
                -1;
            State =:= ?ON_THE_MB ->
                -1;
            State =:= ?ON_THE_GARRISON_SPY ->
                -1;
            true ->
                ETime
        end,
    BearLoad = marching:get_extra_bearload(marching:get_extra(Marching)),
    ViewPState =
        case EPState of
            {?TOWN, TSid} ->
                {?TOWN, point_lib:sid2view(TSid)};
            _ ->
                EPState
        end,
    %%TODO 跨服ios,特殊处理
    NState = case State of
        ?ON_THE_LOOK_GOBACK_NORMAL ->
            ?ON_THE_TOWN_GOBACK;
        ?ON_THE_LOOK_GOBACK_CONSUME ->
            ?ON_THE_TOWN_GOBACK;
        ?ON_THE_LOOK_GOBACK_DEAD ->
            ?ON_THE_TOWN_GOBACK;
        ?ON_THE_LOOK_GOBACK_TOWN ->
            ?ON_THE_TOWN_GOBACK;
        ?ON_THE_LOOK_GOBACK_LEAVE_CORPS ->
            ?ON_THE_TOWN_GOBACK;
        ?ON_THE_LOOK_GOBACK_MAX_UPPER ->
            ?ON_THE_TOWN_GOBACK;
        ?ON_THE_LOOK_GOBACK_MARCH_ARRIVE_NOT_CORPS ->
            ?ON_THE_TOWN_GOBACK;
        ?ON_THE_LOOK_MARCHING ->
            ?ON_THE_MARCHING;
        Other ->
            Other
    end,
    [{GId, NState, point_lib:xyz2view(MarchPoint), point_lib:xyz2view(EndPoint), ViewPState,
        Speed, STime, NETime, RoleUid, AddSpeedTimes, BearLoad, SPType}];
marching_to_lines(EndPoint, EndPState, Marchings) when is_list(Marchings) ->
    lists:foldl(fun(M, Acc0) ->
        [Line] = marching_to_lines(EndPoint, EndPState, M),
        [Line | Acc0] end, [], Marchings).

%% ----------------------------------------------------
%% @doc
%%     设置寻访信息
%% @end
%% ----------------------------------------------------
look_marching(LookSid, LookDetail, Marching, TownLv) ->
    MExtra = init_look_extra(LookSid, TownLv),
    ETime = get_etime(Marching),
    Marching#marching{stime = ETime, etime = ETime + look_detail:get_occ_sec(LookDetail), state = ?ON_THE_LOOK, extra = MExtra}.
%% ----------------------------------------------------
%% @doc
%%     无返回行军过滤器
%% @end
%% ----------------------------------------------------
filter(Marching) ->
    MState = marching:get_state(Marching),
    MState =/= ?ON_THE_MB_CC andalso MState =/= ?ON_THE_INVESTIGATE andalso MState =/= ?ON_THE_PATROL andalso MState =/= ?ON_THE_YS_MARCHING.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%     返回状态
%% @end
%% ----------------------------------------------------
goback_state(MState) ->
    z_lib:get_value(?MARCHING_STATA_TO_GOBACK_STATE, MState, ?ON_THE_GOBACK).