-module(null_fight).

%%%=======================STATEMENT====================
-description("null_fight").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([fighting/5]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        
%% @end
%% ----------------------------------------------------
fighting(Src, Now, EndPoint, EndPInfo, Marchings) ->
    fighting(Src, Now, EndPoint, EndPInfo, Marchings, []).

fighting(Src, Now, EndPoint, EndPInfo, [Marching | TailMarchings], GoBackAcc) ->
    MState = marching:get_state(Marching),
    case MState of
        ?ON_THE_MARCHING_STATION ->
            OccMarching = marching:set_etime(marching:change_occ(Marching, Now, ?ON_THE_STATION), -1),
            UpGoBackList = fighting:mrole_endpoint_change(Src, EndPoint, TailMarchings),
            {UpGoBackList ++ GoBackAcc, [OccMarching]};
        _ ->
            UpGoBackList = fighting:mrole_endpoint_change(Src, EndPoint, [Marching]),
            fighting(Src, Now, EndPoint, EndPInfo, TailMarchings, UpGoBackList ++ GoBackAcc)
    end;
fighting(_Src, _Now, _EndPoint, _EndPInfo, [], GoBackAcc) ->
    {GoBackAcc, []}.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
