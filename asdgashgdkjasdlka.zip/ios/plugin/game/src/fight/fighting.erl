-module(fighting).

%%%=======================STATEMENT====================
-description("大地图战斗").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    arrive/4,
    do_fighting/5,
    update_garray_after_fight/3,
    update_garray_after_fight/4,
    update_garray_after_fight_build/3,
    deal_goback/4,
    deal_goback/5,
    deal_goback_/3,
    injure2dead_mail/3,
    town_fighting/9,
    marching_town_after_fighting/5
]).

-export([
    fight_format/2,
    get_fight_scene/1,
    result/6,
    get_json_value/3,
    web_analysis/3,
    chk_del_psfight/3,
    mrole_endpoint_change/3,
    deal_goback_weapons/3
]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      土匪/玩家/资源点/npc城池行军到达
%% @end
%% ----------------------------------------------------
-spec arrive(Src, EndPoint, PointState, MRoleUids) -> 'ok'|string() when
    Src :: atom(),
    EndPoint :: integer(),
    PointState :: 'none'|tuple(),
    MRoleUids :: [integer()].
arrive(Src, EndPoint, 'none', MRoleUids) ->
%%    case z_db_lib:get(game_lib:get_table(Src, 'point_march'), EndPoint, 'none') of
%%        'none' ->
%%            'ok';
%%        EndPMarch ->
%%            EndPState = point_march:get_point_info(EndPMarch),
%%            case element(1, EndPState) =:= ?NULL of
%%                true ->
    arrive(Src, EndPoint, {?NULL, 0}, MRoleUids);
%%                false ->
%%                    arrive(Src, EndPoint, setelement(2, EndPState, 'none'), MRoleUids)%用于设置坐标终点状态改变
%%            end
%%    end;
arrive(Src, EndPoint, EndPState, MRoleUids) ->
    MapId = point_lib:xyz2mapid(EndPoint),
    if
        MapId =:= 0 ->%游戏服
            case element(1, EndPState) of
                ?MONSTER ->
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'monster_fight', 'fighting'});
                ?BOSS ->%boss也由monster模块接入
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'monster_fight', 'fighting'});
                ?RESOURCE ->
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'resource_fight', 'fighting'});
                ?ROLE ->
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'role_fight', 'fighting'});
                ?TOWN ->
                    town_fight_server:arrive(Src, EndPoint, EndPState, MRoleUids);
%%                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'town_fight', 'fighting'});
                ?RES ->
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'res_fight', 'fighting'});
                ?NULL ->
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'null_fight', 'fighting'});
                ?STATION ->
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'station_fight', 'fighting'});
                ?MAP_BUILD_CORPS ->
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'map_build_fight', 'fighting'});
                ?MAP_BUILD_TOWN ->
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'map_build_fight', 'fighting'});
                ?MAP_BUILD_ROLE ->
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'map_build_fight', 'fighting'})
            end;
        true ->%跨服
            case element(1, EndPState) of
                ?MONSTER -> %运粮队
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'cross_monster_fight', 'fighting'});
                ?BOSS ->%boss也由monster模块接入
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'cross_monster_fight', 'fighting'});
                ?RESOURCE ->%跨服资源点
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'cross_resource_fight', 'fighting'});
                ?ROLE ->%跨服玩家
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'cross_role_fight', 'fighting'});
                ?TOWN ->%跨服,粮仓,城池
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'cross_town_fight', 'fighting'});
                ?RES ->%跨服个人公共资源
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'res_fight', 'fighting'});
                ?NULL ->
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'cross_null_fight', 'fighting'});
                ?MAP_SPY ->
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'cross_spy_fight', 'fighting'});
                ?STATION ->
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'station_fight', 'fighting'});
                ?MAP_BUILD_CORPS ->%跨服军团建筑
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'cross_map_build_fight', 'fighting'});
                ?MAP_BUILD_TOWN ->%跨服城池建筑
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'cross_map_build_fight', 'fighting'});
                ?MAP_BUILD_ROLE ->%%个人建筑
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'cross_map_build_fight', 'fighting'});
                ?MAP_YS_POINT ->%%袁绍反攻据点
                    do_fighting(Src, EndPoint, EndPState, MRoleUids, {'map_ys_point_fight', 'fighting'})
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      土匪/玩家/资源点/npc城池战斗
%% @end
%% ----------------------------------------------------
-spec do_fighting(Src, EndPoint, NEndPState, MRoleUids, {M, F}) -> 'ok'|{?MONSTER, integer(), point_march:point_march()} when
    Src :: atom(),
    EndPoint :: integer(),
    NEndPState :: tuple(),
    MRoleUids :: [integer()],
    M :: atom(),
    F :: atom().
do_fighting(Src, EndPoint, {?RES, ResSid} = NEndPInfo, _MRoleUids, {M, F}) ->
    Now = time_lib:now_second(),
    case do_select_arrive(Src, Now, EndPoint, NEndPInfo, fun point_march:arrive_res/3) of
        {ArrMarch, Occ, NewPMarch, _} ->
            ORoleUid = z_db_lib:get(game_lib:get_table(Src, 'res'), EndPoint, 0),
            if
                NewPMarch =/= 'delete' ->
                    {NOcc, AddGoBackList, NORoleUid} = M:F(Src, Now, EndPoint, NEndPInfo, {ArrMarch, Occ, ORoleUid}),
                    case after_fighting(Src, EndPoint, Now, ?RES, {NOcc, ArrMarch, AddGoBackList}) of
                        {'ok', ArrGoBack, EndPstate, OPMDFlag} ->
                            case NORoleUid =/= ORoleUid of
                                true ->
                                    res_db:capture_res(Src, NORoleUid, EndPoint, ResSid);
                                false ->
                                    GId1 = case NOcc =/= [] of
                                        true ->
                                            marching:get_gid(hd(NOcc));
                                        false ->
                                            0
                                    end,
                                    GId2 = case Occ =/= [] of
                                        true ->
                                            marching:get_gid(hd(Occ));
                                        false ->
                                            0
                                    end,
                                    case GId1 =/= GId2 of
                                        true ->
                                            point_search_db:update_res(Src, ResSid, EndPoint, ORoleUid);
                                        false ->
                                            ok
                                    end
                            end,
                            chk_del_psfight(Src, EndPoint, OPMDFlag),
                            deal_goback(Src, EndPoint, ArrGoBack, EndPstate);
                        _ ->
                            'ok'
                    end;
                true ->
                    ok
            end;
        Info ->
            Info
    end;
do_fighting(Src, EndPoint, {?RESOURCE, ResourceSid} = NEndPInfo, _MRoleUids, {M, F}) ->
    Now = time_lib:now_second(),
    case do_select_arrive(Src, Now, EndPoint, NEndPInfo, fun point_march:arrive_resource/3) of
        {ArrMarch, Occ, NewPMarch, _} ->
            if
                NewPMarch =/= 'delete' ->
                    {NOcc, AddGoBackList} = M:F(Src, Now, EndPoint, NEndPInfo, {ArrMarch, Occ}),%%战斗
                    case after_fighting(Src, EndPoint, Now, ?RESOURCE, {NOcc, ArrMarch, AddGoBackList}) of
                        {'ok', ArrGoBack, EndPstate, OPMDFlag} ->
                            if
                                Occ =/= NOcc ->

                                    point_search_db:update_resource_occ(Src, ResourceSid, EndPoint, Occ, NOcc);
                                true ->
                                    ok
                            end,
                            chk_del_psfight(Src, EndPoint, OPMDFlag),
                            deal_goback(Src, EndPoint, ArrGoBack, EndPstate);
                        _ ->
                            'ok'
                    end;
                true ->
                    ok
            end;
        Info ->
            Info
    end;
do_fighting(Src, EndPoint, {?TOWN, TownSid} = NEndPInfo, MRoleUids, {M, F}) ->
    case M:check_over(Src, TownSid, EndPoint, MRoleUids) of
        {Now, Town} ->
            town_fighting(TownSid, Now, EndPoint, Src, M, F, NEndPInfo, Town, MRoleUids);
        _ ->
            'ok'
    end;
do_fighting(Src, EndPoint, {?ROLE, EndRoleUid} = NEndPInfo, MRoleUids, {M, F}) ->
    Now = time_lib:now_second(),
    case do_select_arrive(Src, Now, EndPoint, NEndPInfo, fun point_march:arrive/3) of
        {ArrMarch, OccMarchings, _NEndPMarch, _} ->
            if
                ArrMarch =/= [] ->%%可能有击飞行军线
                    {UpGoBackList, NOccMarchings, MoveFlag, BreachNamePUid, PlunderTime} =
                        M:F(Src, Now, EndPoint, NEndPInfo, ArrMarch, OccMarchings),
                    case after_fighting(Src, EndPoint, Now, NEndPInfo, {ArrMarch, UpGoBackList, NOccMarchings}) of
                        {'ok', ArrGoBack, OPMDFlag} ->
                            RgidIndex = marching:get_roleuid_gid_index(),
                            SendGarrisonList = lists:filter(fun(Nom) ->
                                marching:get_state(Nom) =:= ?ON_THE_CASTLE_OTHER andalso
                                    lists:keyfind(marching:get_roleuid_gid(Nom), RgidIndex, ArrMarch) =/= false
                            end, NOccMarchings),
                            if
                                SendGarrisonList =/= [] ->
                                    V = list_to_tuple(lists:map(fun(Mc) ->
                                        RUid = marching:get_roleuid(Mc),
                                        RGId = marching:get_gid(Mc),
                                        RShow = role_db:get_role_show(Src, RUid),
                                        {RUid, role_show:get_name(RShow), RGId, attrs:get_garray_power(Src, RUid, RGId)}
                                    end, SendGarrisonList)),
                                    set_front_lib:send_garrison_add_friend_garray(Src, EndRoleUid, V);%协防推送
                                true ->
                                    ok
                            end,
                            chk_del_psfight(Src, EndPoint, OPMDFlag),
                            deal_goback(Src, EndPoint, ArrGoBack, NEndPInfo);
                        _ ->
                            'ok'
                    end,
                    if
                        MoveFlag ->
                            zm_event:notify(Src, 'building_flourish_zero', [{'role_uid', element(2, NEndPInfo)},
                                {'breach_puid_name', BreachNamePUid},
                                {'role_onlines', MRoleUids},
                                {'plunder_time', PlunderTime},
                                {'map_id', point_lib:xyz2mapid(EndPoint)}]);%繁荣度降低为0或者冲车击飞,随机飞
                        true ->
                            'ok'
                    end;
                true ->
                    ok
            end;
        Info ->
            Info
    end;
do_fighting(Src, EndPoint, {?NULL, _} = NEndPInfo, _MRoleUids, {M, F}) ->
    Now = time_lib:now_second(),
    case do_select_arrive(Src, Now, EndPoint, NEndPInfo, fun point_march:arrive/3) of
        {ArrMarch, OccMarchings, _NEndPMarch, _} ->
            case length(OccMarchings) > 0 of
                true ->
                    AddGoBacks = mrole_endpoint_change(Src, EndPoint, ArrMarch),
                    case after_fighting(Src, EndPoint, Now, element(1, NEndPInfo), {ArrMarch, AddGoBacks, OccMarchings}) of
                        {'ok', ArrGoBack, OPMDFlag} ->
                            chk_del_psfight(Src, EndPoint, OPMDFlag),
                            deal_goback(Src, EndPoint, ArrGoBack, NEndPInfo);
                        _ ->
                            'ok'
                    end;
                false ->
%%                    if
%%                        NEndPMarch =/= 'delete' ->
                    {UpGoBackList, NOccMarchings, _DeleteGMarchings} =
                        case point_lib:xyz2mapid(EndPoint) > 0 of
                            true ->
                                {UpGoBackList1, NOccMarchings1, SpyMarching} = M:F(Src, Now, EndPoint, NEndPInfo, ArrMarch),
                                case SpyMarching of
                                    'none' ->
                                        {UpGoBackList1, NOccMarchings1, []};
                                    _ ->
                                        case map_spy_db:spy_arrive(Src, EndPoint, SpyMarching) of
                                            ok ->
                                                {UpGoBackList1, NOccMarchings1, [SpyMarching]};
                                            _Error ->
                                                mrole_endpoint_change(Src, EndPoint, SpyMarching),
                                                {UpGoBackList1, NOccMarchings1, []}
                                        end
                                end;
                            false ->
                                {UpGoBackList1, NOccMarchings1} = M:F(Src, Now, EndPoint, NEndPInfo, ArrMarch),
                                %%放在after_fighting之前(after_fighting中会解锁)
                                case NOccMarchings1 of
                                    [OccMarching | _] ->
                                        station_db:station_arrive(Src, EndPoint, OccMarching);
                                    _ ->
                                        ok
                                end,
                                {UpGoBackList1, NOccMarchings1, []}
                        end,
                    case after_fighting(Src, EndPoint, Now, element(1, NEndPInfo), {ArrMarch, UpGoBackList, NOccMarchings}) of
                        {'ok', ArrGoBack, OPMDFlag} ->
                            chk_del_psfight(Src, EndPoint, OPMDFlag),
                            deal_goback(Src, EndPoint, ArrGoBack, NEndPInfo);
                        _ ->
                            'ok'
                    end
%%                        true ->
%%                            ok
%%                    end
            end;
        Other ->
            Other
    end;
do_fighting(Src, EndPoint, {?STATION, RoleUid} = NEndPInfo, _MRoleUids, {M, F}) ->
    Now = time_lib:now_second(),
    case do_select_arrive(Src, Now, EndPoint, NEndPInfo, fun point_march:arrive/3) of
        {ArrMarch, OccMarchings, _NEndPMarch, _} ->
            if
                ArrMarch =/= [] ->
                    RoleStations = station_db:get_role_stations(Src, RoleUid),
                    Station = lists:keyfind(EndPoint, station:get_puid_index(), RoleStations),
                    case Station =/= false of
                        true ->
                            SGId = station:get_gid(Station),
                            station_db:check_barracks_over(Src, RoleUid, SGId),
                            {IsStationOver, NStation, UpGoBackList, NOccMarchings} =
                                M:F(Src, Now, EndPoint, NEndPInfo, ArrMarch, station:get_gid(Station), OccMarchings, Station),
                            station_db:station_fight_after(Src, RoleUid, NStation, IsStationOver, length(NOccMarchings)),
                            case after_fighting(Src, EndPoint, Now, NEndPInfo, {ArrMarch, UpGoBackList, NOccMarchings}) of
                                {'ok', ArrGoBack, OPMDFlag} ->
                                    chk_del_psfight(Src, EndPoint, OPMDFlag),
                                    deal_goback(Src, EndPoint, ArrGoBack, NEndPInfo);
                                _ ->
                                    station_db:station_fight_after(Src, RoleUid, NStation, IsStationOver, length(NOccMarchings))
                            end;
                        false ->
                            %%空战报
                            mrole_endpoint_change(Src, EndPoint, ArrMarch),
                            case after_fighting(Src, EndPoint, Now, NEndPInfo, {ArrMarch, [], OccMarchings}) of
                                {'ok', ArrGoBack, OPMDFlag} ->
                                    chk_del_psfight(Src, EndPoint, OPMDFlag),
                                    deal_goback(Src, EndPoint, ArrGoBack, NEndPInfo);
                                _ ->
                                    ok
                            end
                    end;
                true ->
                    ok
            end;
        Info ->
            Info
    end;
do_fighting(Src, EndPoint, {PointType, _, Key} = NEndPInfo, _MRoleUids, {M, F}) when
    PointType =:= ?MAP_BUILD_CORPS orelse PointType =:= ?MAP_BUILD_TOWN orelse PointType =:= ?MAP_BUILD_ROLE ->
    Now = time_lib:now_second(),
    case do_select_arrive(Src, Now, EndPoint, NEndPInfo, fun point_march:arrive/3) of
        {ArrMarch, OccMarchings, NEndPMarch, NullArrMarch} ->
            lists:foreach(fun(Marching) ->
                map_build_db:update_mb_fight_num(Src, marching:get_state(Marching), NEndPInfo, EndPoint, -1)
            end, NullArrMarch ++ ArrMarch),
            if
                NEndPMarch =/= 'delete' ->
                    MapBuild = map_build_db:get_map_build(Src, Key),
                    MapBuildVs = map_build:get_build(MapBuild),
                    MapBuildV = lists:keyfind(EndPoint, map_build:get_v_point_uid_index(), MapBuildVs),
                    case MapBuildV =/= false of
                        true ->
                            {IsMBOver, NOccMarchings, NMapBuildV, UpGoBackList} =
                                M:F(Src, Now, EndPoint, NEndPInfo, ArrMarch, OccMarchings, MapBuildV, MapBuildVs),
                            case after_fighting(Src, EndPoint, Now, NEndPInfo, {ArrMarch, NOccMarchings, UpGoBackList}) of
                                {'ok', ArrGoBack, OPMDFlag} ->
                                    map_build_db:update_map_build(Src, Key, NMapBuildV, IsMBOver, NOccMarchings, NEndPInfo),
                                    chk_del_psfight(Src, EndPoint, OPMDFlag),
                                    deal_goback(Src, EndPoint, ArrGoBack, NEndPInfo);
                                _ ->
                                    map_build_db:update_map_build(Src, Key, NMapBuildV, IsMBOver, NOccMarchings, NEndPInfo)
                            end;
                        false ->
                            %%空战报
                            mrole_endpoint_change(Src, EndPoint, ArrMarch),
                            case after_fighting(Src, EndPoint, Now, NEndPInfo, {ArrMarch, OccMarchings, []}) of
                                {'ok', ArrGoBack, OPMDFlag} ->
                                    chk_del_psfight(Src, EndPoint, OPMDFlag),
                                    deal_goback(Src, EndPoint, ArrGoBack, NEndPInfo);
                                _ ->
                                    'ok'
                            end
                    end;
                true ->
                    ok
            end;
        {ok, NullArrMarch} ->
            lists:foreach(fun(Marching) ->
                map_build_db:update_mb_fight_num(Src, marching:get_state(Marching), NEndPInfo, EndPoint, -1)
            end, NullArrMarch);
        Info ->
            Info
    end;
do_fighting(Src, EndPoint, {?MAP_YS_POINT, TSid} = NEndPInfo, _MRoleUids, {M, F}) ->
    Now = time_lib:now_second(),
    case do_select_arrive(Src, Now, EndPoint, NEndPInfo, fun point_march:arrive/3) of
        {ArrMarch, _OccMarchings, NEndPMarch, _} ->
            if
                NEndPMarch =/= 'delete' ->
                    MapYsPoints = map_ys_point_db:get_map_ys_point(Src, TSid),
                    PIndex = map_ys_point:get_point_uid_index(),
                    case lists:keyfind(EndPoint, PIndex, MapYsPoints) of
                        false ->
                            %%空战报
                            mrole_endpoint_change(Src, EndPoint, ArrMarch),
                            case after_fighting(Src, EndPoint, Now, NEndPInfo, {ArrMarch, []}) of
                                {'ok', ArrGoBack, OPMDFlag} ->
                                    chk_del_psfight(Src, EndPoint, OPMDFlag),
                                    deal_goback(Src, EndPoint, ArrGoBack, NEndPInfo);
                                _ ->
                                    'ok'
                            end;
                        MapYsPoint ->
                            {UpGoBackList, NMapYsPoint} = M:F(Src, Now, EndPoint, TSid, ArrMarch, MapYsPoint),
                            case after_fighting(Src, EndPoint, Now, NEndPInfo, {ArrMarch, UpGoBackList}) of
                                {'ok', ArrGoBack, OPMDFlag} ->
                                    map_ys_point_db:fight_after_update(Src, TSid, EndPoint, NMapYsPoint),
                                    chk_del_psfight(Src, EndPoint, OPMDFlag),
                                    deal_goback(Src, EndPoint, ArrGoBack, NEndPInfo);
                                _ ->
                                    map_ys_point_db:fight_after_update(Src, TSid, EndPoint, NMapYsPoint)
                            end
                    end;
                true ->
                    ok
            end;
        Info ->
            Info
    end;
do_fighting(Src, EndPoint, {?MAP_SPY, RoleUid} = NEndPInfo, _MRoleUids, {M, F}) ->
    Now = time_lib:now_second(),
    case do_select_arrive(Src, Now, EndPoint, NEndPInfo, fun point_march:arrive/3) of
        {ArrMarch, OccMarchings, _NEndPMarch, _} ->
            if
                ArrMarch =/= [] ->
                    MapSpy = map_spy_db:get_map_spy(Src, RoleUid),
                    PIndex = map_spy:get_build_point_uid_index(),
                    case lists:keyfind(EndPoint, PIndex, map_spy:get_builds(MapSpy)) of
                        false ->
                            %%空战报
                            mrole_endpoint_change(Src, EndPoint, ArrMarch),
                            case after_fighting(Src, EndPoint, Now, NEndPInfo, {ArrMarch, [], OccMarchings}) of
                                {'ok', ArrGoBack, OPMDFlag} ->
                                    chk_del_psfight(Src, EndPoint, OPMDFlag),
                                    deal_goback(Src, EndPoint, ArrGoBack, NEndPInfo);
                                _ ->
                                    'ok'
                            end;
                        MapSpyBuild ->
                            {UpdateGobackList, NOccMarchings, NMapSpyBuild, IsOver} =
                                M:F(Src, Now, EndPoint, NEndPInfo, ArrMarch, OccMarchings, MapSpyBuild),
                            map_spy_db:update_fight_after(Src, RoleUid, NMapSpyBuild, IsOver, length(NOccMarchings)),
                            case after_fighting(Src, EndPoint, Now, NEndPInfo, {ArrMarch, UpdateGobackList, NOccMarchings}) of
                                {'ok', ArrGoBack, OPMDFlag} ->
                                    chk_del_psfight(Src, EndPoint, OPMDFlag),
                                    deal_goback(Src, EndPoint, ArrGoBack, NEndPInfo);
                                _ ->
                                    'ok'
                            end
                    end;
                true ->
                    ok
            end;
        Info ->
            Info
    end;
do_fighting(Src, EndPoint, NEndPInfo, _MRoleUids, {M, F}) ->%%monster,boss
    Now = time_lib:now_second(),
    case do_select_arrive(Src, Now, EndPoint, NEndPInfo, fun point_march:arrive/3) of
        {ArrMarch, _OccMarchings, NEndPMarch, _} ->
            if
                NEndPMarch =/= 'delete' ->
                    AfterFight = M:F(Src, Now, EndPoint, NEndPInfo, ArrMarch),
                    case after_fighting(Src, EndPoint, Now, element(1, NEndPInfo), {ArrMarch, AfterFight}) of
                        {'ok', ArrGoBack, OPMDFlag} ->
                            chk_del_psfight(Src, EndPoint, OPMDFlag),
                            deal_goback(Src, EndPoint, ArrGoBack, NEndPInfo);
                        _ ->
                            'ok'
                    end;
                true ->
                    ok
            end;
        Info ->
            Info
    end.

%% ----------------------------------------------------
%% @doc
%%     城池战斗
%% @end
%% ----------------------------------------------------
-spec town_fighting(TownSid, Now, EndPoint, Src, M, F, NEndPInfo, Town, MRoleUids) -> tuple()|string() when
    TownSid :: integer(),
    Now :: integer(),
    EndPoint :: integer(),
    Src :: atom(),
    M :: atom(),
    F :: atom(),
    NEndPInfo :: {integer(), integer()},
    Town :: town:town(),
    MRoleUids :: [integer()].
town_fighting(TownSid, Now, EndPoint, Src, M, F, NEndPInfo, Town, MRoleUids) ->
    TownDetail = town_detail:get_cfg(TownSid),
    IsChief = town_detail:chk_chief(TownDetail),
    case do_select_arrive(Src, Now, EndPoint, NEndPInfo, fun point_march:arrive_town/3) of
        {AMarchies1, _OccMarchings, NewEndPMarch1, _} ->
            if
                NewEndPMarch1 =:= 'delete' ->
                    M:F(Src, Now, EndPoint, NEndPInfo, {IsChief, Town, AMarchies1, []}, MRoleUids),
                    'ok';
                true ->
                    FightResult = M:F(Src, Now, EndPoint, NEndPInfo, {IsChief, Town, AMarchies1, point_march:get_occupy(NewEndPMarch1)}, MRoleUids),
                    case after_fighting(Src, EndPoint, Now, {?TOWN, TownSid}, {IsChief, NEndPInfo, TownDetail, AMarchies1, FightResult}) of
                        {'ok', ArrGoBack, EndPState, Ahead, NewEndPMarch} ->
                            chk_del_psfight(Src, EndPoint, NewEndPMarch),
                            deal_goback(Src, EndPoint, ArrGoBack, EndPState),
                            if
                                Ahead ->%提前结束
                                    M:over(Src, TownSid, Now, NEndPInfo, true);
                                true ->
                                    'ok'
                            end;
                        _ ->
                            'ok'
                    end
            end;
        Info ->
            Info
    end.

%% ----------------------------------------------------
%% @doc
%%      战斗之后修改队伍信息
%% @end
%% ----------------------------------------------------
update_garray_after_fight(Src, NCardSoldiers, RUidGid) ->
    update_garray_after_fight(Src, NCardSoldiers, RUidGid, true).
update_garray_after_fight(Src, NCardSoldiers, {RoleUid, GId} = RUidGid, BarracksBool) ->%%新手战,自己主城驻防不更新
    UFun = fun(_, [{Index1, Garray}, {Index2, Barracks}]) ->
        Queue = garray:get_queue(Garray),
        Weapons = garray:get_weapon(Garray),
        F = fun(A, _N, {0, _}) ->
            {'ok', A};
            ({BLoad, Q, I, DN, IN, GWeapons, AccDeadWeapons} = A, N, {CUid, _SNum}) ->
                case lists:keyfind(CUid, 1, NCardSoldiers) of
                    false ->
                        {'ok', A};
                    {CUid, _Sid, Star, DeadNumTemp, Injured, CurSoldier, WeaponSid, WeaponDeadNum, LeisureWeaponNum, OccWeaponNum} ->%%soldier_analysis返回,伤兵也需要计算负重
                        BL = attrs:get_soldier_bear_load(Star),
                        NRWeapon = setelement(N, GWeapons, {WeaponSid, OccWeaponNum}),
                        %%garray上injured字段更新
                        {InjuredSoilder, IWeaponNum} = element(N, I),
                        NewInjured = setelement(N, I, {InjuredSoilder + Injured, IWeaponNum + LeisureWeaponNum}),
                        NAccDeadWeapons =
                            if
                                WeaponDeadNum > 0 ->
                                    case lists:keyfind(WeaponSid, 1, AccDeadWeapons) of
                                        false ->
                                            [{WeaponSid, -WeaponDeadNum} | AccDeadWeapons];
                                        {_, Num} ->
                                            lists:keyreplace(WeaponSid, 1, AccDeadWeapons, {WeaponSid, Num - WeaponDeadNum})
                                    end;
                                true ->
                                    AccDeadWeapons
                            end,
                        {'ok', {BLoad + (CurSoldier + Injured) * BL div 10000, setelement(N, Q, {CUid, CurSoldier}), NewInjured, DN + DeadNumTemp, IN + Injured,
                            NRWeapon, NAccDeadWeapons}}
                end
        end,
        {BearLoad, NQueue, NGarrayInjured, DeadNumber1, InjuredNumber1, NWeapons, DeadWeapons} = z_lib:tuple_foreach(Queue, F, {0, Queue, garray:get_injured(Garray), 0, 0, Weapons, []}),
        NG = garray:set_weapon(garray:set_injured(garray:set_queue(Garray, NQueue), NGarrayInjured), NWeapons),
        UpdateT =
            if
                BarracksBool ->
                    NBarracks = barracks:update_gid_marching_dj(Barracks, GId, DeadNumber1, InjuredNumber1),
                    [{Index2, NBarracks}];
                true ->
                    []
            end,
        Reply = {BearLoad, {NQueue, NWeapons}, NGarrayInjured, garray:get_auto_add_soldier(Garray), DeadNumber1, DeadWeapons},
        {'ok', Reply, [{Index1, NG} | UpdateT]}
    end,
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'garray', RUidGid, garray:init()},
        {'barracks', RoleUid, barracks:init()}
    ]),
    {BL, NQ, GI, AutoAddSoldier, DeadNumber, DeadWeapons} = z_db_lib:handle(TableName, UFun, [], TableKeys),
    zm_event:notify(Src, 'active_event', {'active_consume_target', [{'role_uid', RoleUid}, {'consumes', [{'soldier', DeadNumber}]}]}),
    zm_event:notify(Src, 'bi_consume_weapon', [{'role_uid', RoleUid}, {'weapons', DeadWeapons}]),
    {BL, NQ, GI, AutoAddSoldier, 0}.%最后一个字段无用,故传递0

%% ----------------------------------------------------
%% @doc
%%      箭塔等建筑 战斗之后修改队伍信息
%% @end
%% ----------------------------------------------------
update_garray_after_fight_build(Src, {RoleUid, GId} = RUidGid, Percent) -> %Percent >=10000 全死
    UFun = fun(_, [{Index1, Garray}, {Index2, Barracks}]) ->
        Queue = garray:get_queue(Garray),
        Weapons = garray:get_weapon(Garray),
        F = fun(A, _N, {0, _}) ->
            {'ok', A};
            ({RQueue, RGarrayInjured, RDeadNum, RWeapons, SAcc, AccDeadWeapons}, N, {CUid, SNum}) ->
                %兵器
                {OWeaponSid, OWeaponNum} = element(N, RWeapons),
                DeadWeaponNum = min(OWeaponNum, game_lib:ceil(OWeaponNum * Percent / 10000)),
                NRWeapons = setelement(N, RWeapons, {OWeaponSid, OWeaponNum - DeadWeaponNum}),
                %士兵
                DeadNumTemp = min(SNum, game_lib:ceil(SNum * Percent / 10000)),
                NSAcc = [{CUid, DeadNumTemp, 0, OWeaponSid, DeadWeaponNum, 0} | SAcc],
                NAccDeadWeapons =
                    if
                        DeadWeaponNum > 0 ->
                            case lists:keyfind(OWeaponSid, 1, AccDeadWeapons) of
                                false ->
                                    [{OWeaponSid, -DeadWeaponNum} | AccDeadWeapons];
                                {_, Num} ->
                                    lists:keyreplace(OWeaponSid, 1, AccDeadWeapons, {OWeaponSid, Num - DeadWeaponNum})
                            end;
                        true ->
                            AccDeadWeapons
                    end,
                {'ok', {setelement(N, RQueue, {CUid, SNum - DeadNumTemp}), RGarrayInjured, RDeadNum + DeadNumTemp, NRWeapons, NSAcc, NAccDeadWeapons}}
        end,
        {NQueue, NGarrayInjured, DeadNumber1, NWeapons, Soldiers, DeadWeapons} = z_lib:tuple_foreach(Queue, F, {Queue, garray:get_injured(Garray), 0, Weapons, [], []}),
        NG = garray:set_weapon(garray:set_injured(garray:set_queue(Garray, NQueue), NGarrayInjured), NWeapons),
        NBarracks = barracks:update_gid_marching_dj(Barracks, GId, DeadNumber1, 0),
        Reply = {NG, {NQueue, NWeapons}, NGarrayInjured, DeadNumber1, Soldiers, DeadWeapons},
        {'ok', Reply, [{Index1, NG}, {Index2, NBarracks}]}
    end,
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'garray', RUidGid, garray:init()},
        {'barracks', RoleUid, barracks:init()}
    ]),
    {NGarray, ReplyQueue, ReplyGarrayInjure, DeadNumber, Soldiers, DeadWeapons} = z_db_lib:handle(TableName, UFun, [], TableKeys),
    zm_event:notify(Src, 'active_event', {'active_consume_target', [{'role_uid', RoleUid}, {'consumes', [{'soldier', DeadNumber}]}]}),
    zm_event:notify(Src, 'bi_consume_weapon', [{'role_uid', RoleUid}, {'weapons', DeadWeapons}]),
    {NGarray, ReplyQueue, garray_lib:calc_injured(ReplyGarrayInjure), ReplyGarrayInjure, DeadNumber, Soldiers}.

%% ----------------------------------------------------
%% @doc
%%      选取到达
%% @end
%% ----------------------------------------------------
%%do_select_arrive(Src, Now, EndPoint, NEndPInfo, MarchiesArriveFun) ->
%%    Fun = fun(_, 'none') ->
%%        throw("ok");
%%        (_, EndPMarch) ->
%%            {PMState, Timeout} = point_march:get_state(EndPMarch),
%%            EndPInfo = point_march:get_point_info(EndPMarch),
%%            if
%%                NEndPInfo =/= EndPInfo ->
%%                    {AMarchies, NPMarch} = MarchiesArriveFun(EndPMarch, EndPoint, Now),
%%                    case AMarchies =:= [] of
%%                        true ->
%%                            case point_march:get_goback(EndPMarch) of
%%                                [] ->
%%                                    throw("ok");
%%                                GoBacks ->
%%                                    {GArr, NotAttr} = point_march:get_arrive(GoBacks, Now),
%%                                    NewEndPMarch = point_march:check_del(point_march:set_goback(EndPMarch, NotAttr)),
%%                                    {'ok', {'ok', GArr, EndPInfo, NewEndPMarch}, NewEndPMarch}
%%                            end;
%%                        false ->
%%                            NewEndPMarch = point_march:check_del(point_march:set_state(NPMarch, {?PSTATE_FIGHTING, Now + ?PMARCH_FIGHT_TIMEOUT})),
%%                            {'ok', {?UNNEED_FIGHT, AMarchies, point_march:get_occupy(EndPMarch), NewEndPMarch, EndPInfo}, NewEndPMarch}
%%                    end;
%%                PMState =:= ?PSTATE_DEFAULT orelse (PMState =:= ?PSTATE_FIGHTING andalso Now >= Timeout) ->
%%                    {AMarchies, NPMarch} = MarchiesArriveFun(EndPMarch, EndPoint, Now),
%%                    case AMarchies =:= [] of
%%                        true ->
%%                            case point_march:get_goback(EndPMarch) of
%%                                [] ->
%%                                    throw("ok");
%%                                GoBacks ->
%%                                    {GArr, NotAttr} = point_march:get_arrive(GoBacks, Now),
%%                                    NewEndPMarch = point_march:check_del(point_march:set_goback(EndPMarch, NotAttr)),
%%                                    {'ok', {'ok', GArr, EndPInfo, NewEndPMarch}, NewEndPMarch}
%%                            end;
%%                        false ->
%%                            NewEndPMarch = point_march:check_del(point_march:set_state(NPMarch, {?PSTATE_FIGHTING, Now + ?PMARCH_FIGHT_TIMEOUT})),
%%                            {'ok', {?NEED_FIGHT, AMarchies, point_march:get_occupy(EndPMarch), NewEndPMarch, EndPInfo}, NewEndPMarch}
%%                    end;
%%                true ->
%%                    throw("ok")
%%            end
%%    end,
%%    case z_db_lib:update(game_lib:get_table(Src, 'point_march'), EndPoint, 'none', Fun, []) of
%%        {'ok', GoBackArrives, EndPInfo, NewEndPMarch} ->
%%            chk_del_psfight(Src, EndPoint, NewEndPMarch),
%%            deal_goback(Src, EndPoint, GoBackArrives, EndPInfo, false),
%%            "ok";
%%        {FightFlag, ArrMarch, Occ, NewEndPMarch, EndPInfo} = R ->
%%            chk_del_psfight(Src, EndPoint, NewEndPMarch),
%%            case FightFlag =:= ?UNNEED_FIGHT orelse point_state_db:get_point_info(Src, EndPoint) =/= NEndPInfo of
%%                true ->
%%                    AddGoBacks = mrole_endpoint_change(Src, EndPoint, EndPInfo, ArrMarch),
%%                    Index = marching:get_roleuid_gid_index(),
%%                    Fun1 = fun(_, 'none') ->
%%                        throw("ok");
%%                        (_, EndPMarch) ->
%%                            NGoBack = marchings_del_update(point_march:get_goback(EndPMarch), Occ, AddGoBacks),
%%                            {ArriveGoBacks, NotAttr} = point_march:get_arrive(NGoBack, Now),
%%                            NEndPMarch = point_march:set_goback(EndPMarch, NotAttr),
%%                            NEndPMarch1 = point_march:check_del(point_march:set_state(NEndPMarch, {?PSTATE_DEFAULT, 0})),
%%                            {'ok', {point_march:get_point_info(EndPMarch), ArriveGoBacks, NGoBack, NEndPMarch1}, NEndPMarch1}
%%                    end,
%%                    case z_db_lib:update(game_lib:get_table(Src, 'point_march'), EndPoint, 'none', Fun1, []) of
%%                        {EndPState1, ArriveGoBacks, AllGoBacks, NEndPMarch1} ->
%%                            chk_del_psfight(Src, EndPoint, NEndPMarch1),
%%                            SendGoBacks = lists:filter(fun(Gm) ->
%%                                lists:keyfind(marching:get_roleuid_gid(Gm), Index, ArrMarch) =/= false end, AllGoBacks),
%%                            point_search_db:send_back_occ_line(Src, Now, 0, EndPoint, EndPState1, SendGoBacks, []),
%%                            deal_goback(Src, EndPoint, ArriveGoBacks, EndPInfo),
%%                            "ok";
%%                        Other ->
%%                            Other
%%                    end;
%%                false ->
%%                    erlang:delete_element(1, R)
%%            end;
%%        Other ->
%%            Other
%%    end.
do_select_arrive(Src, Now, EndPoint, NEndPInfo, MarchiesArriveFun) ->
    Fun = fun(_, 'none') ->
        throw("ok");
        (_, EndPMarch) ->
            {PMState, Timeout} = point_march:get_state(EndPMarch),
            if
                PMState =:= ?PSTATE_DEFAULT orelse (PMState =:= ?PSTATE_FIGHTING andalso Now >= Timeout) ->
                    case PMState =:= ?PSTATE_FIGHTING andalso Now >= Timeout of
                        true ->
                            zm_log:warn(?MODULE, ?MODULE, 'do_select_arrive', "timeout", [{'point_march', EndPMarch}, {'point_uid', EndPoint}]);
                        false ->
                            ok
                    end,
                    {AMarchies1, NPMarch} = MarchiesArriveFun(EndPMarch, EndPoint, Now),

                    {AMarchies, AddNullGobacks} = lists:partition(fun(Marching) ->
                        marching:get_epstate(Marching) =:= NEndPInfo
                    end, AMarchies1),
                    if
                        AMarchies =:= [] ->
                            GoBacks = point_march:get_goback(NPMarch),
                            {GArr, NotAttr} = point_march:get_arrive(GoBacks, Now),
                            NewEndPMarch = point_march:check_del(point_march:set_goback(NPMarch, NotAttr)),
                            {'ok', {'ok', GArr, AddNullGobacks, NewEndPMarch}, NewEndPMarch};
                        true ->
                            NewEndPMarch = point_march:check_del(point_march:set_state(NPMarch, {?PSTATE_FIGHTING, Now + ?PMARCH_FIGHT_TIMEOUT})),
                            {'ok', {AMarchies, AddNullGobacks, point_march:get_occupy(EndPMarch), NewEndPMarch}, NewEndPMarch}
                    end;
                true ->
                    throw("ok")
            end
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'point_march'), EndPoint, 'none', Fun, []) of
        {'ok', GoBackArrives, AddNullGobacks1, NewEndPMarch} ->
            cross_null_fight:spy_marching_null_report(Src, AddNullGobacks1, EndPoint),
            AddNullGobacks = lists:filter(fun marching:filter/1, AddNullGobacks1),
            chk_del_psfight(Src, EndPoint, NewEndPMarch),
            case AddNullGobacks =/= [] of
                true ->
                    Index = marching:get_roleuid_gid_index(),
                    AddGoBacks = mrole_endpoint_change(Src, EndPoint, AddNullGobacks),
                    fight_db:update_fight_assist(Src, EndPoint, [], AddGoBacks),
                    SendGoBacks = lists:filter(fun(Gm) ->
                        lists:keyfind(marching:get_roleuid_gid(Gm), Index, GoBackArrives) =:= false end, AddGoBacks),
                    %%OldPState change
                    point_search_db:send_back_occ_line(Src, Now, 0, EndPoint, NEndPInfo, SendGoBacks, []);
                false ->
                    ok
            end,
            deal_goback(Src, EndPoint, GoBackArrives, NEndPInfo, false),
            fight_db:update_fight_assist(Src, EndPoint, GoBackArrives, []),
            case NewEndPMarch =/= 'delete' andalso element(1, NEndPInfo) =:= ?TOWN of
                true ->%%处理寻访召回等
                    OccList = point_march:get_occupy(NewEndPMarch),
                    {[], OccList, NewEndPMarch, AddNullGobacks};
                false ->
                    {ok, AddNullGobacks}
            end;
        {ArrMarch, AddNullGobacks1, Occ, NewEndPMarch} ->
            cross_null_fight:spy_marching_null_report(Src, AddNullGobacks1, EndPoint),
            AddNullGobacks = lists:filter(fun marching:filter/1, AddNullGobacks1),
            chk_del_psfight(Src, EndPoint, NewEndPMarch),
            %%再取一次，防止在update方法之前已经改变
            NewEndPInfo =
                case point_state_db:get_point_info(Src, EndPoint) of
                    'none' ->
                        {?NULL, 0};
                    V ->
                        V
                end,
            case NewEndPInfo =:= NEndPInfo of
                true ->
                    %%只发空战宝
                    mrole_endpoint_change(Src, EndPoint, AddNullGobacks),
                    {ArrMarch, Occ, NewEndPMarch, AddNullGobacks};
                false ->
                    AddGoBacks1 = mrole_endpoint_change(Src, EndPoint, AddNullGobacks),
                    cross_null_fight:spy_marching_null_report(Src, ArrMarch, EndPoint),
                    NArrMarch = lists:filter(fun marching:filter/1, ArrMarch),
                    AddGoBacks2 = mrole_endpoint_change(Src, EndPoint, NArrMarch),
                    Fun1 = fun(_, EndPMarch) ->
                        GoBacks = point_march:get_goback(EndPMarch),
                        {GArr, NotAttr} = point_march:get_arrive(GoBacks, Now),
                        NEndPMarch1 = point_march:set_goback(EndPMarch, NotAttr),
                        NEndPMarch2 = point_march:check_del(point_march:set_state(NEndPMarch1, {?PSTATE_DEFAULT, 0})),
                        {'ok', {ok, GArr, NotAttr, NEndPMarch2}, NEndPMarch2}
                    end,
                    case z_db_lib:update(game_lib:get_table(Src, 'point_march'), EndPoint, point_march:init(), Fun1, []) of
                        {ok, GArr, AllGoBacks, NewEndPMarch1} ->
                            chk_del_psfight(Src, EndPoint, NewEndPMarch1),
                            Index = marching:get_roleuid_gid_index(),
                            SendGoBacks = lists:filter(fun(Gm) ->
                                lists:keyfind(marching:get_roleuid_gid(Gm), Index, AddGoBacks1) =/= false orelse
                                    lists:keyfind(marching:get_roleuid_gid(Gm), Index, AddGoBacks2) =/= false
                            end, AllGoBacks),
                            point_search_db:send_back_occ_line(Src, Now, 0, EndPoint, NewEndPInfo, SendGoBacks, []),
                            deal_goback(Src, EndPoint, GArr, NewEndPInfo, false),
                            {ok, AddNullGobacks ++ NArrMarch};
                        Other ->
                            Other
                    end
            end;
        Other ->
            Other
    end.


%% ----------------------------------------------------
%% @doc
%%     终点变化,直接返回
%% @end
%% ----------------------------------------------------
mrole_endpoint_change(Src, EndPoint, ArrMarch) ->
    Fun = fun(Args, Marching) ->
        case marching:filter(Marching) of
            true ->
                EndPinfo = marching:get_epstate(Marching),
                Rtype = element(1, EndPinfo),
                EndUid = element(2, EndPinfo),
                MState = marching:get_state(Marching),
                {RType, ID} =
                    if
                        MState =:= ?ON_THE_INVESTIGATE ->
                            {?REPORT_NULL_SPY_NOT_NULL, 0};
                        Rtype =:= ?MONSTER orelse Rtype =:= ?BOSS ->
                            {?REPORT_NULL_MONSTER_DEAD, monster_db:muid_2_msid(EndUid)};
                        Rtype =:= ?STATION ->
                            case MState =:= ?ON_THE_CASTLE_MARCHING of
                                true ->
                                    {?REPORT_NULL_GARRISON_STATION_MOVE, EndUid};
                                false ->
                                    {?REPORT_NULL_FIGHT_STATION_MOVE, EndUid}
                            end;
                        Rtype =:= ?NULL ->
                            if
                                MState =:= ?ON_THE_MARCHING_STATION ->
                                    {?REPORT_NULL_STATION_NOT_NULL, 0}
                            %%有其他类型可在此处添加
                            end;
                        Rtype =:= ?MAP_BUILD_CORPS orelse Rtype =:= ?MAP_BUILD_TOWN orelse Rtype =:= ?MAP_BUILD_ROLE ->
                            case MState =:= ?ON_THE_MB_MARCHING of
                                true ->
                                    {?REPORT_NULL_MB_GARRISON_NULL_MB, EndUid};
                                false ->
                                    {?REPORT_NULL_FIGHT_NULL_MB, EndUid}
                            end;
                        Rtype =:= ?MAP_YS_POINT ->
                            Level = town_db:get_town_lv(Src, EndUid),
                            {?REPORT_NULL_FIGHT_NULL_YS, Level};
                        true ->
                            case MState =:= ?ON_THE_CASTLE_MARCHING of
                                true ->
                                    {?REPORT_NULL_GARRISON_CASTLE_MOVE, EndUid};
                                false ->
                                    {?REPORT_NULL_FIGHT_CASTLE_MOVE, EndUid}
                            end
                    end,
                zm_event:notify(Src, 'fight_null_report', [
                    {'role_uid', marching:get_roleuid(Marching)},
                    {'point_int', EndPoint},
                    {'time', marching:get_etime(Marching)},
                    {'r_type', RType},
                    {'id', ID}]),
                {'ok', [marching:change_goback(Marching, EndPoint) | Args]};
            false ->
                {'ok', Args}
        end
    end,
    z_lib:foreach(Fun, [], ArrMarch).

%% ----------------------------------------------------
%% @doc
%%      返回到达城堡.
%% @end
%% ----------------------------------------------------
deal_goback(Src, EndPoint, ArrGoBack, EndPState) ->
    deal_goback(Src, EndPoint, ArrGoBack, EndPState, true).
%% ----------------------------------------------------
%% @doc
%%      Bool:如果前台发送到达的为false;否则其他地方true(因为2秒容错,满速只有1格距离的秒到达,不给前台推送导致队伍状态错误)
%% @end
%% ----------------------------------------------------
deal_goback(Src, EndPoint, ArrGoBack, _EndPState, Bool) ->
    TableName = game_lib:get_table(Src),
    Fun = fun(Marching) ->
        fight_db:add_goback_award_log(Src, Marching),
        EndPState = marching:get_epstate(Marching),
        MarchRoleUid = marching:get_roleuid(Marching),
        GId = marching:get_gid(Marching),
        MarchRolePoint = marching:get_s_point(Marching),
        InjureMax = building_db:get_injure_max(Src, MarchRoleUid),
        MState = marching:get_state(Marching),
        RoleShow = role_db:get_role_show(Src, MarchRoleUid),
        RoleCastlePointUid = role_show:get_point(RoleShow),
        TableKeys =
            if
                MState =:= ?ON_THE_CASTLE_GOBACK ->
                    z_db_lib:transformation_tablekey(TableName, [
                        {'garray', {MarchRoleUid, GId}},
                        {'point_march', MarchRolePoint, 'none'},
                        {'barracks', MarchRoleUid},
                        {'station', MarchRoleUid, []},
                        {'garrison', MarchRoleUid, garrison:init()}]);
                MState =:= ?ON_THE_INVESTIGATE_GOBACK ->
                    z_db_lib:transformation_tablekey(TableName, [
                        {'map_spy', MarchRoleUid, map_spy:spy_init()},
                        {'point_march', MarchRolePoint, 'none'}]);
                true ->
                    z_db_lib:transformation_tablekey(TableName, [
                        {'garray', {MarchRoleUid, GId}},
                        {'point_march', MarchRolePoint, 'none'},
                        {'barracks', MarchRoleUid},
                        {'station', MarchRoleUid, []}])
            end,
        case z_db_lib:handle(TableName, {?MODULE, deal_goback_, []}, {EndPoint, Marching, GId, InjureMax, MarchRolePoint, RoleCastlePointUid, MState}, TableKeys) of
            {'ok', BMarchingPStateList} ->
                if
                    Bool ->
                        %由于满buff等属性,之后到达等只需要1s,就没给前台推送导致状态不对,故取消该限制条件
                        %after之后判断的到达,需要推送给前台一次
                        Line = marching:marching_to_lines(EndPoint, EndPState, Marching),
                        %%前台主动调用arrive的不需要推送,只有后台do_fighting时候,直接判断到达的才需要推送(那种极限只需要1s就返回的情况)
                        set_front_lib:send_map_state(Src, [MarchRoleUid], Line);
                    true ->
                        ok
                end,
                %%通知新添加返回
                AddBackMarchings = lists:map(fun({BackMarching, EndPInfo}) ->
                    MarchLine = marching:marching_to_lines(MarchRolePoint, EndPInfo, BackMarching),
                    point_search_db:send_march_line(Src, marching:get_s_point(BackMarching), MarchRolePoint, MarchLine, [marching:get_roleuid(BackMarching)]),
                    BackMarching
                end, BMarchingPStateList),
                fight_db:update_fight_assist(Src, EndPoint, [], AddBackMarchings),
                ok;
            {'ok', NMarchPMarch, NGarray, Injured, DeadNum, Injure2Dead, NBarracks, AutoAddSoldier, BMarchingPStateList, IsStation} ->
                ETime = marching:get_etime(Marching),
                MState = marching:get_state(Marching),
                LookGobackState = look_fight:lookgoback_state(MState),
                MarchAward1 = marching:get_award(Marching),
                %%行军到家统一处理资源上限
                MarchAward =
                    case is_list(MarchAward1) of
                        true ->
                            MapId = point_lib:xyz2mapid(EndPoint),
                            if
                                MapId > 0 ->
                                    cross_resource_fight:overflow_res_award(Src, MarchRoleUid, lists:keydelete('feats', 1, MarchAward1));
                                true ->
                                    building_db:overflow_res_award(Src, MarchRoleUid, lists:keydelete('feats', 1, MarchAward1))
                            end;
                        false ->
                            MarchAward1
                    end,
                RelAward =
                    if
                        LookGobackState ->%寻访返回
                            Extra = marching:get_extra(Marching),
                            OccTime = marching:get_extra_occ_time(Extra),
                            TownLv = marching:get_extra_look_townlv(Extra),
                            {_, TownSid} = EndPState,
                            LookLogs = z_db_lib:delete1(game_lib:get_table(Src, 'look'), {MarchRoleUid, GId, EndPoint}, look_logs:init(marching:get_stime(Marching), NGarray)),

                            AwardList = look_logs:get_awards(LookLogs),
                            {AView, Award} = awarder_game:get_advance_award(Src, MarchRoleUid, ?MODULE, AwardList),
                            zm_event:notify(Src, 'look_report', [
                                {'role_uid', MarchRoleUid},
                                {'time', ETime},
                                {'award_list', [{'card_exp', look_logs:get_card_exp(LookLogs)} | AView]},
                                {'point_int', EndPoint},
                                {'look_sid', TownSid},
                                {'look_logs', LookLogs},
                                {'goback_type', MState},
                                {'gid', GId},
                                {'occ_time', OccTime},
                                {'town_sid', TownSid},
                                {'town_lv', TownLv}
                            ]),
                            %%记录任务
                            zm_event:notify(Src, achieve, {MarchRoleUid, {argu, {'look_times', 1}}}),
                            Award;
                        MState =:= ?ON_THE_COLLECTION_GOBACK ->%采集返回
                            {_, RSid} = EndPState,
                            ResDetail = resource_detail:get_cfg(RSid),
                            RandAward = resource_detail:get_randomaward(ResDetail),
                            NAwardList = MarchAward ++ awarder_game:get_award_list(RandAward),
                            {AView, Award} = awarder_game:get_advance_award(Src, MarchRoleUid, ?MODULE, NAwardList),
                            resource_fight:collect_achieve(Src, MarchRoleUid, resource_detail:get_type(ResDetail), AView),
                            zm_event:notify(Src, 'collect_report', [
                                {'role_uid', MarchRoleUid},
                                {'time', ETime},
                                {'award_list', AView},
                                {'point_int', EndPoint},
                                {'resource_sid', RSid}
                            ]),
                            zm_event:notify(Src, 'active_event', {'active_collect_resource_rank', [{'role_uid', MarchRoleUid}, {'award_list', NAwardList}]}),
                            Award;
                        true ->
                            case is_tuple(MarchAward) of
                                true ->
                                    MarchAward;
                                false ->
                                    element(2, awarder_game:get_advance_award(Src, MarchRoleUid, ?MODULE, lists:keydelete('feats', 1, MarchAward)))
                            end
                    end,
                AwardLog = awarder_game:give_award(RelAward),
                injure2dead_mail(Src, MarchRoleUid, Injure2Dead),
                fight_db:del_goback_award_log(Src, Marching),
                if
                    Bool ->
                        %由于满buff等属性,之后到达等只需要1s,就没给前台推送导致状态不对,故取消该限制条件
                        %after之后判断的到达,需要推送给前台一次
                        Line = marching:marching_to_lines(EndPoint, EndPState, Marching),
                        %%前台主动调用arrive的不需要推送,只有后台do_fighting时候,直接判断到达的才需要推送(那种极限只需要1s就返回的情况)
                        set_front_lib:send_map_state(Src, [MarchRoleUid], Line);
                    true ->
                        ok
                end,
                set_front_lib:send_goback(Src, MarchRoleUid, {AwardLog, {GId, marching:get_state(Marching)}, Injured, DeadNum}),
                if
                    (Injured =/= 0 orelse DeadNum =/= 0) andalso AutoAddSoldier =:= 1 ->
                        Study = building_db:get_study(Src, MarchRoleUid),
                        OfficailAttr = official_db:get_attrs(Src, MarchRoleUid),
                        CardStorage = storage_db:get_storage('card', Src, MarchRoleUid),
                        Political = building_db:get_political(Src, MarchRoleUid),
                        garray_db:auto_add_soldiers(Src, MarchRoleUid, GId, Study, CardStorage, Political, OfficailAttr, true, true, true, true);
                    true ->
                        ok
                end,
                if
                    NMarchPMarch =:= 'delete' ->
                        point_search_db:del_marching(Src, MarchRolePoint);
                    true ->
                        'ok'
                end,
                zm_log:info(Src, ?MODULE, 'deal_goback', "fight_deal_goback", [
                    {'time', z_lib:second_to_localtime(ETime)},
                    {'roleuid', MarchRoleUid},
                    {'gid', GId},
                    {'end_point', EndPoint},
                    {'injure2dead', Injure2Dead},
                    {'marching', Marching},
                    {'award', AwardLog},
                    {'barracks', NBarracks}]),
                zm_event:notify(Src, 'bi_fight_deal_goback', [{'role_uid', MarchRoleUid}, {'gid', GId}, {'award', AwardLog}, {'point_state', EndPState}]),
                %%通知新添加返回
                lists:foreach(fun({BackMarching, EndPInfo}) ->
                    MarchLine = marching:marching_to_lines(MarchRolePoint, EndPInfo, BackMarching),
                    point_search_db:send_march_line(Src, marching:get_s_point(BackMarching), MarchRolePoint, MarchLine, [marching:get_roleuid(BackMarching)])
                end, BMarchingPStateList),
                MarchingState = marching:get_state(Marching),
                if
                    MarchingState =:= ?ON_THE_GOBACK ->
                        %土匪行军返回,攻击玩家行军返回,  行军过程召回(非(寻访,友军协防召回返回)返回),都由前台添加推送
                        ok;
                    true ->
                        push_message_lib:push(Src, MarchRoleUid, 6, []) %到家推送
                end,
                station_db:update_station_occ_num(Src, MarchRolePoint, NMarchPMarch, IsStation),
                'ok';
            'none_goback' ->
                zm_log:warn(?MODULE, ?MODULE, 'deal_goback_', "none_deal_goback_", [
                    {'role_uid', MarchRoleUid},
                    {'gid', GId},
                    {'end_point', EndPoint},
                    {'marching', Marching}]),
                Fun = fun(_, Barracks) ->
                    {DNum, INum} = barracks:get_gid_marching_dj(Barracks, GId),
                    NBarracks1 = barracks:update_gid_marching_dj(Barracks, GId, -DNum, -INum),
                    Occupy = max(barracks:get_occupy(NBarracks1) - DNum - INum, 0),
                    NBarracks = barracks:set_occupy(NBarracks1, Occupy),
                    {ok, ok, NBarracks}
                end,
                z_db_lib:update(game_lib:get_table(Src, 'barracks'), MarchRoleUid, barracks:init(), Fun, []);
            _ ->
                'ok'
        end
    end,
    lists:foreach(Fun, ArrGoBack).

%% ----------------------------------------------------
%% @doc
%%      返回到达城堡事务数据处理.
%% @end
%% ----------------------------------------------------
deal_goback_(_, _, [_, {_, 'none'} | _]) ->
    {ok, 'none_goback'};
deal_goback_(_, {EndPoint, _Marching, _GId, _InjureMax, _MarchRolePoint, _RoleCastlePointUid, MState},
        [{Index1, MapSpy}, {Index2, MarchPMarch}]) when MState =:= ?ON_THE_INVESTIGATE_GOBACK ->
    RoleMarch = point_march:get_role_march(MarchPMarch),
    NMarchPMarch = point_march:check_del(point_march:set_role_march(MarchPMarch, lists:delete(EndPoint, RoleMarch))),
    MPoints = lists:delete(EndPoint, map_spy:get_mpoints(MapSpy)),
    {_, Conditions} = zm_config:get('map_spy_info', 'investigate'),
    NeedSpyBarracks = z_lib:get_value(Conditions, 'soldier_num', 0),
    NMapSpy1 = map_spy:update_leisure(MapSpy, NeedSpyBarracks),
    NMapSpy = map_spy:set_mpoints(NMapSpy1, MPoints),
    {'ok', 'ok', [{Index1, NMapSpy}, {Index2, NMarchPMarch}]};
deal_goback_(_, {EndPoint, Marching, GId, InjureMax, MarchRolePoint, RoleCastlePointUid, MState},
        [{Index1, Garray}, {Index2, MarchPMarch}, {Index3, Barracks}, {_Index4, RoleStations} | T]) ->
    RoleMarch = point_march:get_role_march(MarchPMarch),
    {RoleUid, GId} = marching:get_roleuid_gid(Marching),
    BStations = barracks:get_stations(Barracks),
    BSGIdIndex = barracks:get_station_gid_index(),
    Bs = lists:keyfind(GId, BSGIdIndex, BStations),
    Station = lists:keyfind(GId, station:get_gid_index(), RoleStations),
    if
        (MState =:= ?ON_THE_STATION_GOBACK orelse (Station =:= false andalso Bs =/= false)) andalso
            MarchRolePoint =/= RoleCastlePointUid ->%%驻扎队伍返回的不是主城
            NGarray = garray:set_state(Garray, MarchRolePoint),
            AddGobackMarching = marching:set_sptype(marching:change_spoint(marching:get_etime(Marching), Marching, RoleCastlePointUid, MarchRolePoint, true), ?ROLE),
            NMarchPMarch = point_march:set_goback(MarchPMarch, [AddGobackMarching | point_march:get_goback(MarchPMarch)]),
            {'ok', {'ok', [{AddGobackMarching, {?ROLE, marching:get_roleuid(Marching)}}]},
                [{Index1, NGarray}, {Index2, NMarchPMarch}]};
        MState =:= ?ON_THE_STATION_GOBACK orelse (Station =:= false andalso Bs =/= false) -> %%驻扎队伍返回的是主城
            NGarray = garray:set_injured_init(garray:set_state(Garray, ?IDLE)),
            RoleMarch = point_march:get_role_march(MarchPMarch),
            NMarchPMarch = point_march:check_del(point_march:set_role_march(MarchPMarch, lists:delete(EndPoint, RoleMarch))),
            GId = marching:get_gid(Marching),
            SLeisure = barracks:get_station_leisure(Bs),
            SInjured = barracks:get_station_injured(Bs),
            Leisure = barracks:get_leisure(Barracks),
            Weapon = game_lib:merge_kv(barracks:get_station_weapon(Bs), barracks:get_weapon(Barracks)),
            Barracks1 = barracks:set_stations(barracks:set_weapon(barracks:set_leisure(Barracks, SLeisure + Leisure), Weapon), lists:keydelete(GId, BSGIdIndex, BStations)),
            Barracks2 = deal_goback_weapons(Garray, 0, Barracks1),
            {Injured, DeadNum, Injure2Dead, NBarracks, _UpdateT, AutoAddSoldier} =
                deal_goback_2(Marching, GId, Barracks2, InjureMax, ?ON_THE_STATION_GOBACK, [], Garray, SInjured),
            {'ok', {'ok', NMarchPMarch, NGarray, Injured, DeadNum, Injure2Dead, NBarracks, AutoAddSoldier, [], false},
                [{Index1, NGarray}, {Index2, NMarchPMarch}, {Index3, NBarracks}]};
        Station =/= false ->%%是驻扎点
            NGarray = garray:set_injured_init(garray:set_state(Garray, MarchRolePoint)),
            OccMarching1 = marching:set_add_speed_times(marching:change_spoint(marching:get_etime(Marching), Marching, RoleCastlePointUid, MarchRolePoint, false), 0),
            OccMarching2 = marching:set_award(marching:set_injured(marching:set_dead(marching:set_etime(marching:set_state(OccMarching1, ?ON_THE_STATION), -1), 0), 0), []),
            OccMarching = marching:set_epstate(OccMarching2, {?STATION, RoleUid}),
            %%排序自己在最后
            OccMarchings = point_march:get_occupy(MarchPMarch) ++ [OccMarching],
            NMarchPMarch1 = point_march:set_role_march(MarchPMarch, lists:delete(EndPoint, RoleMarch)),
            NMarchPMarch = point_march:set_occupy(NMarchPMarch1, OccMarchings),
            Barracks1 = deal_goback_weapons(Garray, GId, Barracks),
            {Injured, DeadNum, Injure2Dead, NBarracks, UpdateT, _AutoAddSoldier} =
                deal_goback_2(Marching, GId, Barracks1, InjureMax, MState, T, Garray, 0),
            %%默认返回自动设置兵
            {'ok', {'ok', NMarchPMarch, NGarray, Injured, DeadNum, Injure2Dead, NBarracks, 1, [{OccMarching, {?STATION, RoleUid}}], true},
                [{Index1, NGarray}, {Index2, NMarchPMarch}, {Index3, NBarracks} | UpdateT]};
        true ->
            case RoleCastlePointUid =:= MarchRolePoint of
                true ->
                    NGarray = garray:set_injured_init(garray:set_state(Garray, ?IDLE)),
                    RoleMarch = point_march:get_role_march(MarchPMarch),
                    NMarchPMarch = point_march:check_del(point_march:set_role_march(MarchPMarch, lists:delete(EndPoint, RoleMarch))),
                    Barracks1 = deal_goback_weapons(Garray, 0, Barracks),
                    {Injured, DeadNum, Injure2Dead, NBarracks, UpdateT, AutoAddSoldier} =
                        deal_goback_2(Marching, GId, Barracks1, InjureMax, MState, T, Garray, 0),
                    {'ok', {'ok', NMarchPMarch, NGarray, Injured, DeadNum, Injure2Dead, NBarracks, AutoAddSoldier, [], false},
                        [{Index1, NGarray}, {Index2, NMarchPMarch}, {Index3, NBarracks} | UpdateT]};
                false ->
                    NGarray = garray:set_state(Garray, MarchRolePoint),
                    AddGobackMarching = marching:set_sptype(marching:change_spoint(marching:get_etime(Marching), Marching, RoleCastlePointUid, MarchRolePoint, true), ?ROLE),
                    RoleMarch = point_march:get_role_march(MarchPMarch),
                    NMarchPMarch1 = point_march:set_role_march(MarchPMarch, lists:delete(EndPoint, RoleMarch)),
                    NMarchPMarch = point_march:set_goback(NMarchPMarch1, [AddGobackMarching | point_march:get_goback(MarchPMarch)]),
                    {'ok', {'ok', [{AddGobackMarching, {?ROLE, marching:get_roleuid(Marching)}}]},
                        [{Index1, NGarray}, {Index2, NMarchPMarch}]}
            end
    end.

deal_goback_2(_Marching, GId, Barracks, InjureMax, MState, T, Garray, StationInjured) ->
    {DeadNum, Injured} = barracks:get_gid_marching_dj(Barracks, GId),
    NBarracks1 = barracks:update_gid_marching_dj(Barracks, GId, -DeadNum, -Injured),
    {Injure2Dead, NBarracks} = barracks:fight_over(NBarracks1, GId, DeadNum, Injured, StationInjured, InjureMax),
    UpdateT =
        if
            MState =:= ?ON_THE_CASTLE_GOBACK ->
                [{Index5, Garrison} | _] = T,
                Dispatchs = garrison:get_dispatchs(Garrison),
                NDispatchs = lists:keydelete(GId, 1, Dispatchs),
                NGarrison = garrison:set_dispatchs(Garrison, NDispatchs),
                [{Index5, NGarrison}];
            true ->
                []
        end,
    AutoAddSoldier = garray:get_auto_add_soldier(Garray),
    {Injured, DeadNum, Injure2Dead, NBarracks, UpdateT, AutoAddSoldier}.

%% ----------------------------------------------------
%% @doc
%%      战斗信息format
%% @end
%% ----------------------------------------------------
-spec fight_format(atom(), FightArgs) -> tuple()|string() when
    FightArgs :: 'none'|list().
fight_format(_Src, 'none') ->
    throw("no_normal");
fight_format(_Src, FightArgs) ->
    Seed = z_lib:get_value(FightArgs, 'seed', 0),
    FightRole = z_lib:get_value(FightArgs, 'fight_role', 'none'),
    FightType = z_lib:get_value(FightArgs, 'fight_type', 0),
    Auto = z_lib:get_value(FightArgs, 'auto', 1),
    FighterNpc = z_lib:get_value(FightArgs, 'fight_enemy', 'none'),
    Sid = z_lib:get_value(FightArgs, 'duplicate_sid', 0),
    {{'seed', Seed}, {'auto', Auto}, {'fight_role', FightRole},
        {'fight_enemy', FighterNpc}, {'fight_type', FightType},
        {'duplicate_sid', Sid}}.

%% ----------------------------------------------------
%% @doc
%%     获取战斗场景sid
%% @end
%% ----------------------------------------------------
-spec get_fight_scene(Type :: atom()) -> integer().
get_fight_scene(Type) ->
    {_, List} = zm_config:get('fight_info', 'scene_sid'),
    z_lib:get_value(List, Type, 0).

%%-------------------------------------------------------------------
%% @doc
%%      进行战斗结果处理
%% @end
%%-------------------------------------------------------------------
-spec result(Src, _A, RoleUid, _Msg, FightArgs, Result) -> {integer(), result:result()} when
    Src :: atom(),
    _A :: list(),
    RoleUid :: integer(),
    _Msg :: [{string(), term()}],
    FightArgs :: [{term(), term()}],
    Result :: [{string(), term()}].
result(_, _A, _, _Msg, FightArgs, Result) ->
    Winner = z_lib:get_value(Result, "winner", 1),%0进攻方胜利,1进攻方失败
    HpResult = z_lib:get_value(Result, "result", {0, []}),
    FightRole = z_lib:get_value(FightArgs, 'fight_role', 'none'),
    EnemyBattle = z_lib:get_value(FightArgs, 'fight_enemy', []),
    {Winner, web_analysis(HpResult, FightRole, EnemyBattle)}.

%%-------------------------------------------------------------------
%% @doc
%%      伤兵超出上限转换死亡兵,发送邮件
%% @end
%%-------------------------------------------------------------------
-spec injure2dead_mail(Src :: atom(), RoleUid :: integer(), Injure2Dead :: integer()) -> 'ok'.
injure2dead_mail(_Src, _RoleUid, 0) ->
    'ok';
injure2dead_mail(Src, RoleUid, Injure2Dead) ->
    Time = time_lib:now_second(),
    Mail = mail:init({award_source:get_source(?MODULE), Time, 0, {6}, {6, Injure2Dead}, []}),
    mail_db:send(Src, RoleUid, Mail),
    zm_event:notify(Src, 'active_event', {'active_consume_target', [{'role_uid', RoleUid}, {'consumes', [{'soldier', Injure2Dead}]}]}),
%%    zm_log:info(Src, ?MODULE, 'send_mail', "send_mail", [{'role_uid', RoleUid}, {'injure2dead', Injure2Dead}]),
    'ok'.

%% ----------------------------------------------------
%% @doc
%%    检测是否删除,point_search_fight
%% @end
%% ----------------------------------------------------
chk_del_psfight(Src, EndPoint, PMarch) ->
    if
        PMarch =:= 'delete' ->
            point_search_db:del_marching(Src, EndPoint);
        true ->
            'ok'
    end.

%% ----------------------------------------------------
%% @doc
%%      到主城兵器还到兵器库
%% @end
%% ----------------------------------------------------
deal_goback_weapons(Garray, GId, Barracks) ->
    InjuredWeaponNum = garray:get_injured(Garray),%%{{伤病数,空闲兵器数}...}
    Weapons = garray:get_weapon(Garray),
    Fun = fun(RIWeapons, _N, {0, _}) ->
        {ok, RIWeapons};
        (RIWeapons, N, {Sid, _Num}) ->
            {_, IWeaponNum} = element(N, InjuredWeaponNum),
            {ok, game_lib:merge_kv(RIWeapons, [{Sid, IWeaponNum}])}
    end,
    IWeapons = z_lib:tuple_foreach(Weapons, Fun, []),
    %%获得的空闲兵器加到兵营中
    lists:foldl(fun({Sid, Num}, CBarracks) ->
        barracks:update_weapons(CBarracks, GId, Sid, Num)
    end, Barracks, IWeapons).

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%      战斗之后修改(伤兵,死亡兵,奖励等信息)
%% @end
%% ----------------------------------------------------
after_fighting(Src, EndPoint, Now, Type, {NOccMarching, Arrives, AddGoBackList}) when Type =:= ?RESOURCE;Type =:= ?RES ->
    Fun = fun(_, 'none') ->
        zm_log:warn(?MODULE, ?MODULE, 'res', "timeout", [{'point_uid', EndPoint}, {'r', NOccMarching, Arrives, AddGoBackList}]),
        throw("ok");
        (_, PMarch) ->
            Gobacks1 = marchings_del_update(point_march:get_goback(PMarch), NOccMarching, AddGoBackList),
            NGoBack = lists:keysort(marching:get_etime_index(), Gobacks1),
            {GArr, NotAttr} = point_march:get_arrive(NGoBack, Now),
            NPMarch = point_march:set_occupy(point_march:set_goback(PMarch, NotAttr), NOccMarching),
            NPMarch1 = point_march:check_del(point_march:set_state(NPMarch, {?PSTATE_DEFAULT, 0})),
            {'ok', {'ok', point_march:get_point_info(PMarch), GArr, NotAttr, NPMarch1}, NPMarch1}
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'point_march'), EndPoint, 'none', Fun, []) of
        {'ok', EndPState1, GoBackArr, GoBackList, DealPMarch} ->
            Index = marching:get_roleuid_gid_index(),
            SendGoBacks1 = lists:filter(fun(Gm) ->
                lists:keyfind(marching:get_roleuid_gid(Gm), Index, Arrives) =/= false end, GoBackList),
            SendGoBacks = z_lib:foreach(fun(Acc, Gm) ->
                lists:keystore(marching:get_roleuid_gid(Gm), Index, Acc, Gm)
            end, SendGoBacks1, AddGoBackList),
            SendOcc = lists:filter(fun(Am) ->
                lists:keyfind(marching:get_roleuid_gid(Am), Index, Arrives) =/= false end, NOccMarching),
            point_search_db:send_back_occ_line(Src, Now, 0, EndPoint, EndPState1, SendGoBacks, SendOcc),
            fight_db:update_fight_assist(Src, EndPoint, Arrives, NOccMarching ++ AddGoBackList),
            {'ok', GoBackArr, EndPState1, DealPMarch};
        Info ->
            Info
    end;
after_fighting(Src, EndPoint, Now, {?TOWN, TownSid}, {IsChief, NEndPInfo, TownDetail, ArrMarchies, {AddGoBack, NewOcc, UpPointNpcState, UpPointOwner, NpcRefreshTime, NAddFCUids}}) ->
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'town', TownSid, town:init(TownDetail)},
        {'point_march', EndPoint, point_march:set_point_info(point_march:init(), NEndPInfo)}]),
    Index = marching:get_roleuid_gid_index(),
    Fun = fun(_, [{Index1, Town}, {Index2, PMarch}]) ->
        NewGoBack = marchings_del_update(point_march:get_goback(PMarch), NewOcc, AddGoBack),
        NAddGoBackList1 = lists:keysort(marching:get_etime_index(), NewGoBack),
        {Arr1, NotGoBackList} = point_march:get_arrive(NAddGoBackList1, Now),
        NewTown = town:fight_update(Town, IsChief, EndPoint, UpPointNpcState, UpPointOwner, NpcRefreshTime),
        {Ahead, NewTown1} =
            case town_fight:fighting_chk_over(TownDetail, NewTown) andalso element(1, town:get_state(NewTown)) =:= ?STATE_FIGHT of %刚好时间距离结束2s容错左右时候,前台会有over调用,可能锁不住 (增加一个战斗状态才修改)
                true ->%提前结束战斗
                    {_, STime, _} = town:get_state(NewTown),
                    {true, town:set_over_time(town:set_state(NewTown, {?STATE_FIGHT_AHEAD_OVER, STime, Now + ?PMARCH_FIGHT_TIMEOUT}), Now + ?PMARCH_FIGHT_TIMEOUT)};
                false ->
                    {false, NewTown}
            end,
        NPMarch = point_march:set_occupy(point_march:set_goback(PMarch, NotGoBackList), NewOcc),
        NPMarch1 = point_march:check_del(point_march:set_state(NPMarch, {?PSTATE_DEFAULT, 0})),
        OOcclen = length(lists:filter(fun(Om1) ->
            marching:get_state(Om1) =:= ?ON_THE_TOWN_GARRISON end, point_march:get_occupy(PMarch))),
        FUids = town:get_fight_uids(NewTown1),
        NAFUids = lists:usort(NAddFCUids)--FUids,
        NewTown2 = town:set_fight_uids(NewTown1, NAFUids ++ FUids),
        {'ok', {'ok', point_march:get_point_info(PMarch), Arr1, Town, NewTown2, Ahead, OOcclen, NAFUids, NPMarch1}, [{Index1, NewTown2}, {Index2, NPMarch1}]}
    end,
    case z_db_lib:handle(TableName, Fun, [], TableKeys) of
        {'ok', EndPState1, ArrGoBack, OldTown, ReplyTown, AHeaded, OldOccLen, NAFUids1, OPMarch} ->
            NewOccLen = length(lists:filter(fun(Om1) -> marching:get_state(Om1) =:= ?ON_THE_TOWN_GARRISON end, NewOcc)),
            NPOwer = town:get_points_owner(ReplyTown),
            OPOwer = town:get_points_owner(OldTown),
            case NPOwer -- OPOwer =:= [] andalso OPOwer -- NPOwer =:= [] of
                true ->
                    if
                        NewOccLen =/= OldOccLen ->
                            point_search_db:update_town_occlen(Src, TownSid, TownDetail, [{EndPoint, NewOccLen}]);
                        true ->
                            ok
                    end;
                false ->
                    %视野
                    case point_lib:xyz2mapid(EndPoint) > 0 of
                        true ->
                            TownOwner = town:get_corps_uid(OldTown),
                            AddH = NPOwer -- OPOwer,
                            DelH = OPOwer -- NPOwer,
                            lists:foreach(fun({Pu, C}) ->
                                if
                                    C > 0 ->
                                        point_horizon:add_town_grid_horizon(Src, C, Pu),
                                        if
                                            TownOwner > 0 ->
                                                point_horizon:delete_horizon(Src, TownOwner, Pu);
                                            true ->
                                                ok
                                        end;
                                    true ->
                                        ok
                                end end, AddH),
                            lists:foreach(fun({Pu, C}) ->
                                if
                                    C > 0 ->
                                        point_horizon:delete_horizon(Src, C, Pu),
                                        if
                                            C =/= TownOwner andalso TownOwner > 0 ->
                                                point_horizon:add_town_grid_horizon(Src, TownOwner, Pu);
                                            true ->
                                                ok
                                        end;
                                    true ->
                                        ok
                                end end, DelH);
                        false ->
                            'ok'
                    end,
                    point_search_db:update_towninfo(Src, TownSid, TownDetail, ReplyTown, [{EndPoint, NewOccLen}])
            end,
            SendGoBack = lists:ukeysort(marching:get_roleuid_gid_index(), AddGoBack),
            SendOcc = lists:filter(fun(Am) ->
                lists:keyfind(marching:get_roleuid_gid(Am), Index, ArrMarchies) =/= false end, NewOcc),
            point_search_db:send_back_occ_line(Src, Now, 0, EndPoint, EndPState1, SendGoBack, SendOcc),
            case town:get_fight_lv(OldTown) > 0 of
                true ->
                    marching_town_after_fighting(Src, TownSid, TownDetail, NAFUids1, element(2, town:get_state(OldTown)));
                false ->
                    ok
            end,
            fight_db:update_fight_assist(Src, EndPoint, ArrMarchies, NewOcc ++ AddGoBack),
            {'ok', ArrGoBack, EndPState1, AHeaded, OPMarch};
        Info ->
            Info
    end;
after_fighting(Src, EndPoint, Now, {?ROLE, RoleUid}, {Arrives, UpGoBack, OccMarchings}) ->
    Index = marching:get_roleuid_gid_index(),
    Fun = fun(_, 'none') ->
        case lists:all(fun marching:filter/1, Arrives) of
            true ->
                zm_log:warn(?MODULE, ?MODULE, 'role', "timeout", [{'point_uid', EndPoint}, {'r', Arrives, UpGoBack, OccMarchings}]);
            false ->
                ok
        end,
        throw("ok");
        (_, EndPMarch) ->
            NGoBack1 = marchings_del_update(point_march:get_goback(EndPMarch), OccMarchings, UpGoBack),
            NGoBack = lists:keysort(marching:get_etime_index(), NGoBack1),
            {Arr, NotAttr} = point_march:get_arrive(NGoBack, Now),
            NEndPMarch1 = point_march:set_goback(EndPMarch, NotAttr),
            NEndPMarch2 = point_march:set_occupy(NEndPMarch1, OccMarchings),
            NEndPMarch = point_march:check_del(point_march:set_state(NEndPMarch2, {?PSTATE_DEFAULT, 0})),
            {'ok', {point_march:get_point_info(EndPMarch), Arr, NGoBack, NEndPMarch}, NEndPMarch}
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'point_march'), EndPoint, 'none', Fun, []) of
        {EndPState1, NewArr, GoBackList, OPMarch} ->
            SendGoBacks1 = lists:filter(fun(Gm) ->
                lists:keyfind(marching:get_roleuid_gid(Gm), Index, Arrives) =/= false end, GoBackList),
            SendGoBacks = z_lib:foreach(fun(Acc, Gm) ->
                lists:keystore(marching:get_roleuid_gid(Gm), Index, Acc, Gm)
            end, SendGoBacks1, UpGoBack),
            SendOcc = lists:filter(fun(Am) ->
                lists:keyfind(marching:get_roleuid_gid(Am), Index, Arrives) =/= false end, OccMarchings),
            point_search_db:send_back_occ_line(Src, Now, RoleUid, EndPoint, EndPState1, SendGoBacks, SendOcc),
            fight_db:update_fight_assist(Src, EndPoint, Arrives, OccMarchings ++ UpGoBack),
            {'ok', NewArr, OPMarch};
        Other ->
            Other
    end;
after_fighting(Src, EndPoint, Now, {?STATION, RoleUid}, {Arrives, UpGoBackList, NOccMarchings}) ->
    Index = marching:get_roleuid_gid_index(),
    Fun = fun(_, 'none') ->
        case lists:all(fun marching:filter/1, Arrives) of
            true ->
                zm_log:warn(?MODULE, ?MODULE, 'station', "timeout", [{'point_uid', EndPoint}, {'r', Arrives, UpGoBackList, NOccMarchings}]);
            false ->
                ok
        end,
        throw("ok");
        (_, EndPMarch) ->
            NGoBack1 = marchings_del_update(point_march:get_goback(EndPMarch), NOccMarchings, UpGoBackList),
            NGoBack = lists:keysort(marching:get_etime_index(), NGoBack1),
            {Arr, NotAttr} = point_march:get_arrive(NGoBack, Now),
            NEndPMarch = point_march:set_goback(EndPMarch, NotAttr),
            %%回来
            OccMarchings = point_march:get_occupy(EndPMarch),
            AddOccMarchings = lists:filter(fun(M) ->
                MRGid = marching:get_roleuid_gid(M),
                lists:keyfind(MRGid, Index, UpGoBackList) =:= false andalso lists:keyfind(MRGid, Index, NOccMarchings) =:= false
            end, OccMarchings),
            NEndPMarch1 = point_march:set_occupy(NEndPMarch, NOccMarchings ++ AddOccMarchings),
            NEndPMarch2 = point_march:check_del(point_march:set_state(NEndPMarch1, {?PSTATE_DEFAULT, 0})),
            {'ok', {point_march:get_point_info(EndPMarch), Arr, NotAttr, NEndPMarch2}, NEndPMarch2}
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'point_march'), EndPoint, 'none', Fun, []) of
        {EndPState1, NewArr, AllGoBack, OPMarch} ->
            SendGoBacks1 = lists:filter(fun(Gm) ->
                lists:keyfind(marching:get_roleuid_gid(Gm), Index, Arrives) =/= false end, AllGoBack),
            SendGoBacks = z_lib:foreach(fun(Acc, Gm) ->
                lists:keystore(marching:get_roleuid_gid(Gm), Index, Acc, Gm)
            end, SendGoBacks1, UpGoBackList),
            SendOcc = lists:filter(fun(Am) ->
                lists:keyfind(marching:get_roleuid_gid(Am), Index, Arrives) =/= false end, NOccMarchings),
            point_search_db:send_back_occ_line(Src, Now, RoleUid, EndPoint, EndPState1, SendGoBacks, SendOcc),
            fight_db:update_fight_assist(Src, EndPoint, Arrives, NOccMarchings ++ UpGoBackList),
            {'ok', NewArr, OPMarch};
        Other ->
            Other
    end;
after_fighting(Src, EndPoint, Now, ?NULL, {Arrives, UpGoBack, NOccMarchings}) ->
    Index = marching:get_roleuid_gid_index(),
    Fun = fun(_, 'none') ->
        case lists:all(fun marching:filter/1, Arrives) of
            true ->
                zm_log:warn(?MODULE, ?MODULE, 'null', "timeout", [{'point_uid', EndPoint}, {'r', Arrives, UpGoBack, NOccMarchings}]);
            false ->
                ok
        end,
        throw("ok");
        (_, EndPMarch) ->
            NGoBack1 = marchings_del_update(point_march:get_goback(EndPMarch), NOccMarchings, UpGoBack),
            NGoBack = lists:keysort(marching:get_etime_index(), NGoBack1),
            {Arr, NotAttr} = point_march:get_arrive(NGoBack, Now),
            NEndPMarch = point_march:set_goback(EndPMarch, NotAttr),
            NEndPMarch1 = point_march:set_occupy(NEndPMarch, NOccMarchings),
            NEndPMarch2 = point_march:check_del(point_march:set_state(NEndPMarch1, {?PSTATE_DEFAULT, 0})),
            {'ok', {point_march:get_point_info(EndPMarch), Arr, NotAttr, NEndPMarch2}, NEndPMarch2}
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'point_march'), EndPoint, 'none', Fun, []) of
        {EndPState1, NewArr, AllGoBack, OPMarch} ->
            SendGoBacks1 = lists:filter(fun(Gm) ->
                lists:keyfind(marching:get_roleuid_gid(Gm), Index, Arrives) =/= false end, AllGoBack),
            SendGoBacks = z_lib:foreach(fun(Acc, Gm) ->
                lists:keystore(marching:get_roleuid_gid(Gm), Index, Acc, Gm)
            end, SendGoBacks1, UpGoBack),
            SendOcc = lists:filter(fun(Am) ->
                lists:keyfind(marching:get_roleuid_gid(Am), Index, Arrives) =/= false end, NOccMarchings),
            point_search_db:send_back_occ_line(Src, Now, 0, EndPoint, EndPState1, SendGoBacks, SendOcc),
            fight_db:update_fight_assist(Src, EndPoint, Arrives, NOccMarchings ++ UpGoBack),
            {'ok', NewArr, OPMarch};
        Other ->
            Other
    end;
after_fighting(Src, EndPoint, Now, {PointType, _, _}, {Arrives, NOccMarchings, UpGoBackList}) when
    PointType =:= ?MAP_BUILD_CORPS orelse PointType =:= ?MAP_BUILD_TOWN orelse PointType =:= ?MAP_BUILD_ROLE ->
    Index = marching:get_roleuid_gid_index(),
    Fun = fun(_, 'none') ->
        zm_log:warn(?MODULE, ?MODULE, 'mb', "timeout", [{'point_uid', EndPoint}, {'r', Arrives, UpGoBackList, NOccMarchings}]),
        throw("ok");
        (_, EndPMarch) ->
            NGoBack1 = marchings_del_update(point_march:get_goback(EndPMarch), NOccMarchings, UpGoBackList),
            NGoBack = lists:keysort(marching:get_etime_index(), NGoBack1),
            {Arr, NotAttr} = point_march:get_arrive(NGoBack, Now),
            NEndPMarch = point_march:set_goback(EndPMarch, NotAttr),
            NEndPMarch1 = point_march:set_occupy(NEndPMarch, NOccMarchings),
            NEndPMarch2 = point_march:check_del(point_march:set_state(NEndPMarch1, {?PSTATE_DEFAULT, 0})),
            {'ok', {point_march:get_point_info(EndPMarch), Arr, NotAttr, NEndPMarch2}, NEndPMarch2}
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'point_march'), EndPoint, 'none', Fun, []) of
        {EndPState1, NewArr, AllGoBack, OPMarch} ->
            SendGoBacks1 = lists:filter(fun(Gm) ->
                lists:keyfind(marching:get_roleuid_gid(Gm), Index, Arrives) =/= false end, AllGoBack),
            SendGoBacks = z_lib:foreach(fun(Acc, Gm) ->
                lists:keystore(marching:get_roleuid_gid(Gm), Index, Acc, Gm)
            end, SendGoBacks1, UpGoBackList),
            SendOcc = lists:filter(fun(Am) ->
                lists:keyfind(marching:get_roleuid_gid(Am), Index, Arrives) =/= false end, NOccMarchings),
            point_search_db:send_back_occ_line(Src, Now, 0, EndPoint, EndPState1, SendGoBacks, SendOcc),
            fight_db:update_fight_assist(Src, EndPoint, Arrives, NOccMarchings ++ UpGoBackList),
            {'ok', NewArr, OPMarch};
        Other ->
            Other
    end;
after_fighting(Src, EndPoint, Now, {?MAP_YS_POINT, _}, {Arrives, UpGoBackList}) ->
    Index = marching:get_roleuid_gid_index(),
    Fun = fun(_, 'none') ->
        zm_log:warn(?MODULE, ?MODULE, 'mb', "timeout", [{'point_uid', EndPoint}, {'r', Arrives, UpGoBackList}]),
        throw("ok");
        (_, EndPMarch) ->
            NGoBack1 = marchings_del_update(point_march:get_goback(EndPMarch), [], UpGoBackList),
            NGoBack = lists:keysort(marching:get_etime_index(), NGoBack1),
            {Arr, NotAttr} = point_march:get_arrive(NGoBack, Now),
            NEndPMarch1 = point_march:set_goback(EndPMarch, NotAttr),
            NEndPMarch2 = point_march:check_del(point_march:set_state(NEndPMarch1, {?PSTATE_DEFAULT, 0})),
            {'ok', {point_march:get_point_info(EndPMarch), Arr, NotAttr, NEndPMarch2}, NEndPMarch2}
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'point_march'), EndPoint, 'none', Fun, []) of
        {EndPState1, NewArr, AllGoBack, OPMarch} ->
            SendGoBacks = lists:filter(fun(Gm) ->
                lists:keyfind(marching:get_roleuid_gid(Gm), Index, Arrives) =/= false end, AllGoBack),
            point_search_db:send_back_occ_line(Src, Now, 0, EndPoint, EndPState1, SendGoBacks, []),
            fight_db:update_fight_assist(Src, EndPoint, Arrives, UpGoBackList),
            {'ok', NewArr, OPMarch};
        Other ->
            Other
    end;
after_fighting(Src, EndPoint, Now, {?MAP_SPY, _}, {Arrives, UpGoBackList, NOccMarchings}) ->
    Index = marching:get_roleuid_gid_index(),
    Fun = fun(_, 'none') ->
        case lists:all(fun marching:filter/1, Arrives) of
            true ->
                zm_log:warn(?MODULE, ?MODULE, 'role', "timeout", [{'point_uid', EndPoint}, {'r', Arrives, UpGoBackList, NOccMarchings}]);
            false ->
                ok
        end,
        throw("ok");
        (_, EndPMarch) ->
            NGoBack1 = marchings_del_update(point_march:get_goback(EndPMarch), NOccMarchings, UpGoBackList),
            NGoBack = lists:keysort(marching:get_etime_index(), NGoBack1),
            {Arr, NotAttr} = point_march:get_arrive(NGoBack, Now),
            NEndPMarch = point_march:set_goback(EndPMarch, NotAttr),
            NEndPMarch1 = point_march:set_occupy(NEndPMarch, NOccMarchings),
            NEndPMarch2 = point_march:check_del(point_march:set_state(NEndPMarch1, {?PSTATE_DEFAULT, 0})),
            {'ok', {point_march:get_point_info(EndPMarch), Arr, NotAttr, NEndPMarch2}, NEndPMarch2}
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'point_march'), EndPoint, 'none', Fun, []) of
        {EndPState1, NewArr, AllGoBack, OPMarch} ->
            SendGoBacks1 = lists:filter(fun(Gm) ->
                lists:keyfind(marching:get_roleuid_gid(Gm), Index, Arrives) =/= false end, AllGoBack),
            SendGoBacks = z_lib:foreach(fun(Acc, Gm) ->
                lists:keystore(marching:get_roleuid_gid(Gm), Index, Acc, Gm)
            end, SendGoBacks1, UpGoBackList),
            SendOcc = lists:filter(fun(Am) ->
                lists:keyfind(marching:get_roleuid_gid(Am), Index, Arrives) =/= false end, NOccMarchings),
            point_search_db:send_back_occ_line(Src, Now, 0, EndPoint, EndPState1, SendGoBacks, SendOcc),
            fight_db:update_fight_assist(Src, EndPoint, Arrives, NOccMarchings ++ UpGoBackList),
            {'ok', NewArr, OPMarch};
        Other ->
            Other
    end;
after_fighting(Src, EndPoint, Now, _, {Arrives, UpGoBack}) ->
    Index = marching:get_roleuid_gid_index(),
    Fun = fun(_, 'none') ->
        zm_log:warn(?MODULE, ?MODULE, 'other', "timeout", [{'point_uid', EndPoint}, {'r', Arrives, UpGoBack}]),
        throw("ok");
        (_, EndPMarch) ->
            F = fun({GoBack, AccGo}, {Key, Award, Dead, Injured}) ->
                case lists:keyfind(Key, Index, GoBack) of
                    false ->
                        {'ok', {GoBack, AccGo}};
                    Marching ->
                        NMarching = marching:fight_result(Marching, Injured, Dead, Award),
                        {'ok', {lists:keyreplace(Key, Index, GoBack, NMarching), [NMarching | AccGo]}}
                end
            end,
            {NGoBack2, AddGo} = z_lib:foreach(F, {point_march:get_goback(EndPMarch), []}, UpGoBack),
            NGoBack = lists:keysort(marching:get_etime_index(), NGoBack2),
            {Arr, NotAttr} = point_march:get_arrive(NGoBack, Now),
            NEndPMarch = point_march:set_goback(EndPMarch, NotAttr),
            NEndPMarch1 = point_march:check_del(point_march:set_state(NEndPMarch, {?PSTATE_DEFAULT, 0})),
            {'ok', {point_march:get_point_info(EndPMarch), Arr, NotAttr, NEndPMarch1, AddGo}, NEndPMarch1}
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'point_march'), EndPoint, 'none', Fun, []) of
        {EndPState1, NewArr, AllGoBack, OPMarch, AddGoBack} ->
            %由于满buff等属性,之后到达等只需要1s,就没给前台推送导致状态不对,故取消该限制条件
            Index = marching:get_roleuid_gid_index(),
            SendGoBacks = lists:filter(fun(Gm) ->
                lists:keyfind(marching:get_roleuid_gid(Gm), Index, Arrives) =/= false end, AllGoBack),
            point_search_db:send_back_occ_line(Src, Now, 0, EndPoint, EndPState1, SendGoBacks, []),
            fight_db:update_fight_assist(Src, EndPoint, Arrives, AddGoBack),
            {'ok', NewArr, OPMarch};
        Other ->
            Other
    end.

%% ----------------------------------------------------
%% @doc
%%      返回web每一波对应的战斗结果 {进攻方最后信息,[每回合信息]};
%%      ({{死亡数,伤兵数,[{武将uid,sid,star,当前兵力}]},战斗获得经验,[ {死亡数,伤兵数,[{武将uid,sid,star,当前兵力}]}.. ]}
%% @end
%% ----------------------------------------------------
-spec web_analysis({WaveLen, HpResult}, FightRole, FightEnemy) -> result:result() when
    WaveLen :: integer(),
    HpResult :: list(),
    FightRole :: fighter:battlefield(),
    FightEnemy :: [fighter:battlefield()].
web_analysis({WaveLen, HpResult}, FightRole, FightEnemy) ->
    %web约定返回每一波进攻方和防守方的数据,故固定=2
    WaveInfos = [{RoleList, EnemyList} || {2, [RoleList, EnemyList | _]} <- HpResult],
    WaveEnemy = lists:sublist(FightEnemy, WaveLen),
    FatsTuple = element(2, zm_config:get('card_info', 'feats')),
    Fun = fun({{LastDead, LastInjure, _, _}, Exp, Feats, EnemyFeatsList, Args, EnemyWaves, RWaves, TDead, TInjure}, {{RoleHp, EnemyHp}, BattleEnemy}) ->
        {{CurDead, CurInjure, RoleFeats, CurInfos} = RoleChange, NRHp} = soldier_analysis(FightRole, RoleHp, FatsTuple),
        {{EDead, EInjure, ECardExpOrFeats, EInfos}, NewEnemyHp} = soldier_analysis(BattleEnemy, EnemyHp, FatsTuple),
        IsRole = fighter:get_is_role(BattleEnemy),
        {NExp, NFeats, NEnemyFeats} = if
            IsRole ->
                {Exp, Feats + ECardExpOrFeats, [RoleFeats | EnemyFeatsList]};
            true ->
                {Exp + ECardExpOrFeats, Feats, [0 | EnemyFeatsList]}
        end,
        {'ok', {RoleChange, NExp, NFeats, NEnemyFeats,
            [{{CurDead - LastDead, CurInjure - LastInjure, CurInfos},
                {EDead, EInjure, EInfos}} | Args], [NewEnemyHp | EnemyWaves], [NRHp | RWaves], TDead + EDead, TInjure + EInjure}}
    end,
    {RoleReply, AddEXP, AddFeats, EnemyAddFeatsList, ReplyList, NewEnemyWaves, NewFWaves, EnemyTotalDead, EnemyTotalInjure} =
        z_lib:foreach(Fun, {{0, 0, 0, []}, 0, 0, [], [], [], [], 0, 0}, lists:zip(WaveInfos, WaveEnemy)),
    ELastHp = if
        NewEnemyWaves =:= [] ->
            [];
        true ->
            element(2, hd(NewEnemyWaves))
    end,
    RLastHp = if
        NewFWaves =:= [] ->
            [];
        true ->
            element(2, hd(NewFWaves))
    end,
    WLen = length(WaveInfos),
    result:init({RoleReply, AddEXP, AddFeats, lists:reverse(EnemyAddFeatsList), lists:reverse(ReplyList), {WLen, ELastHp}, EnemyTotalDead, EnemyTotalInjure, {WLen, RLastHp}}).

%%-------------------------------------------------------------------
%% @doc
%%      战斗前数据,战斗结果(整理每一回合{死亡,伤兵数,死亡小兵+伤兵产生的经验,[{武将uid,sid,star,当前回合死亡数,伤数,当前带兵数}]})
%% @END
%%-------------------------------------------------------------------
-spec soldier_analysis(FightRole, RoleHp, FeatsTuple) -> {{integer(), integer(), integer(), [{integer(), integer()}]}, tuple()} when
    FightRole :: fighter:battlefield(),
    RoleHp :: tuple(),
    FeatsTuple :: tuple().
soldier_analysis(FightRole, {Len, RoleHpList}, FeatsTuple) ->
    Fighters = fighter:get_fighters(FightRole),
    IsRole = fighter:get_is_role(FightRole),
    F = fun({{DeadNum, InjureNum, Exp, CardSoliders}, RHpList} = A, Fight) ->
        Pos = fighter:get_position(Fight),
        if
            Pos =:= ?WALL_INDEX ->
                {'ok', A};
            true ->
                MaxSolider = fighter:get_max_soldier_num(Fight),%最大带兵量
                MaxHp = fighter:get_max_hp(Fight),
                Hp = fighter:get_hp(Fight),
                Uid = fighter:get_uid(Fight),
                OneSHp = MaxHp div MaxSolider,
                {{CurHp, CurMaxHp}, NRHPlist} = get_json_value(Uid, RHpList, OneSHp),%%web传递回来数据都必须乘以10000的数据(因为后台都扩大了10000倍的属性)
                SoldierNum = Hp div OneSHp,%当前带兵量
                CurSoldier = max(CurHp div OneSHp, 0),
                DeadNum1 = max(MaxHp - CurMaxHp, 0) div OneSHp,
                InjureNum1 = max(SoldierNum - DeadNum1 - CurSoldier, 0),
                Sid = fighter:get_sid(Fight),
                NewStar = fighter:get_new_star(Fight), %%新的星级影响小兵属性
                %经验,功勋
                CardExpOrFeats = if
                    IsRole ->
                        (DeadNum1 + InjureNum1) * element(fighter:get_level(Fight), FeatsTuple) div 10000;%武将所带小兵功勋
                    true ->
                        (DeadNum1 + InjureNum1) * fighter:get_card_exp(Fight) div 10000 %武将所带小兵经验
                end,

                %%兵器结算
                WeaponSid = fighter:get_weapon_sid(Fight),
                WeaponNum = fighter:get_weapon_num(Fight),
                OccWeaponNum = WeaponNum * CurSoldier div SoldierNum,
                DeadWeaponNum = min(WeaponNum * DeadNum1 div SoldierNum, DeadNum1),
                LeisureWeaponNum = WeaponNum - OccWeaponNum - DeadWeaponNum,

                TotalWeaponNum = OccWeaponNum + LeisureWeaponNum,
                NOccWeaponNum = min(TotalWeaponNum, CurSoldier),
                NLeisureWeaponNum = TotalWeaponNum - NOccWeaponNum,

                {'ok', {{DeadNum + DeadNum1, InjureNum + InjureNum1, Exp + CardExpOrFeats,
                    [{Uid, Sid, NewStar, DeadNum1, InjureNum1, CurSoldier, WeaponSid, DeadWeaponNum, NLeisureWeaponNum, NOccWeaponNum} | CardSoliders]}, NRHPlist}} %sid+star用于计算资源采集负重
        end
    end,
    {Reply, NewRoleHpList} = z_lib:foreach(F, {{0, 0, 0, []}, RoleHpList}, Fighters),
    {Reply, {Len, NewRoleHpList}}.

%%-------------------------------------------------------------------
%% @doc
%%      获取web返回的,武将对应血量信息json格式解析
%% @end
%%-------------------------------------------------------------------
-spec get_json_value(Uid, RoleHp, OneHp) -> tuple() when
    Uid :: integer(),
    RoleHp :: [{integer(), list()}],
    OneHp :: integer().
get_json_value(Uid, RoleHpList, OneHp) ->
    F = fun({_, NRHplist}, {Len, [Uid1, Hp, MaxHp]}) when Uid1 =:= Uid ->
        CHp = Hp-(Hp rem OneHp),
        CMHp = MaxHp - (MaxHp rem OneHp),
        {'ok', {{CHp, CMHp}, [{Len, [Uid1, CHp, CMHp]} | NRHplist]}};
        ({Acc0, Acc1}, LUhp) ->
            {'ok', {Acc0, [LUhp | Acc1]}}
    end,
    z_lib:foreach(F, {{0, 0}, []}, RoleHpList).


%% ----------------------------------------------------
%% @doc
%%     新增城池战斗
%% @end
%% ----------------------------------------------------
marching_town_after_fighting(Src, TownSid, TownDetail, CorpsUids, FightStime) ->
    IsChief = town_detail:chk_chief(TownDetail),
    Table = game_lib:get_table(Src, 'corps_town'),
    CTInit = corps_town:init(),
    Fun = fun(CorpsUid) ->
        add_corps_town_fight(Src, TownSid, IsChief, Table, CorpsUid, CTInit, FightStime)
    end,
    lists:foreach(Fun, CorpsUids).

%% ----------------------------------------------------
%% @doc
%%     军团增加战斗中状态
%% @end
%% ----------------------------------------------------
add_corps_town_fight(Src, TownSid, IsChief, Table, CorpsUid, CTInit, STime) ->
    TFun = fun(_, CorpsTown) ->
        {NCorpsTown, IsFightingNotify1} = corps_town:add_flist(CorpsTown, TownSid, IsChief),
        if
            IsFightingNotify1 ->
                {'ok', 'ok', NCorpsTown};
            true ->
                {'ok', 'error'}
        end
    end,
    case z_db_lib:update(Table, CorpsUid, CTInit, TFun, []) of
        'ok' ->
            RUids2 = corps_db:get_corps_members(Src, CorpsUid),
            push_message_lib:push(Src, RUids2, 3, []),%城池,推送
            set_front_lib:send_corps_fight(Src, RUids2, TownSid, CorpsUid, 1, STime);
        _ ->
            'ok'
    end.


%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
marchings_del_update(Marchings, DelMarchings, UpMarchigns) ->
    RGIndex = marching:get_roleuid_gid_index(),
    DelF = fun(Acc, Marching) -> {ok, lists:keydelete(marching:get_roleuid_gid(Marching), RGIndex, Acc)} end,
    NMarchings = z_lib:foreach(DelF, Marchings, DelMarchings),
    UpFun = fun(Acc, Marching) -> {ok, lists:keystore(marching:get_roleuid_gid(Marching), RGIndex, Acc, Marching)} end,
    z_lib:foreach(UpFun, NMarchings, UpMarchigns).