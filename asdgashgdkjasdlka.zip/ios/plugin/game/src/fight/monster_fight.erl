-module(monster_fight).

%%%=======================STATEMENT====================
-description("土匪战斗").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    fighting/5,
    first_fight/3
]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").
-include("../include/report.hrl").

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      土匪战斗
%% @end
%% ----------------------------------------------------
-spec fighting(Src, Now, PointUid, {_, MUid}, ArrMarch) -> list() when
    Src :: atom(),
    Now :: integer(),
    PointUid :: integer(),
    MUid :: integer(),
    ArrMarch :: [marching:marching()].
fighting(Src, Now, EndPoint, EndPInfo, ArrMarch) ->%需要战斗
    MUid = element(2, EndPInfo),
    MSid = monster_db:muid_2_msid(MUid),
    MonstInfo = monster_detail:get_cfg(MSid),
    MNpcArray = monster_detail:get_npc(MonstInfo),
    FightType = match_lib:get_fight_type(?MODULE),
    FightArgs = [
        {'ma', {'fighting', []}},
        {'auto', 1},%是否自动释放技能自动战斗 1:自动,0:手动
        {'fight_type', FightType},
        {'duplicate_sid', fighting:get_fight_scene('monster')},
        {'sid', MSid},
        {'point_int', EndPoint}],
    case monster_detail:is_boss(MonstInfo) of
        false ->
            FightNpc = fighter:init_npc(MNpcArray),
            {_, UpGoBack} = do_fighting(Src, Now, EndPoint, [{'fight_enemy', FightNpc} | FightArgs], MUid, MonstInfo, ArrMarch, false, []),
            UpGoBack;
        true ->
            BossDataTable = game_lib:get_table(Src, 'boss_data'),
            BossData = z_db_lib:get(BossDataTable, MUid, boss_data:init()),
            NpcArray = monster_detail:get_npc(MonstInfo),
            NpcState = boss_data:get_npc_state(BossData),
            Extra = boss_data:get_extra(BossData),
            {IsDead, UpGoBack, NewNpcState, NewAddRank} = boss_fight:do_fighting(Src, Now, EndPoint, FightArgs, MUid, MonstInfo, ArrMarch, false, [], NpcArray, NpcState, [], Extra, {0, [], [], [], 0}),
            NCurrValue = boss_fight:get_curr_value(MNpcArray, NewNpcState, Extra),
            UFun = fun(_, NBData) ->
                NBossData = boss_data:set_curr_value(boss_data:set_npc_state(NBData, NewNpcState), NCurrValue),
                {ok, {ok, NBossData}, NBossData}
            end,
            {ok, NBossData} = z_db_lib:update(BossDataTable, MUid, BossData, UFun, []),
            case NCurrValue =/= 0 andalso NCurrValue =/= boss_data:get_curr_value(BossData) of
                true ->
                    point_search_db:update_boss(Src, EndPoint, MUid, NBossData);
                false ->
                    ok
            end,
            case Extra of
                {'active', ActiveSid} ->
                    zm_event:notify(Src, 'active_event', {'active_corps_boss_score', [{'score', monster_detail:get_score(MonstInfo)}, {'add_rank', NewAddRank},
                        {'active_sid', ActiveSid}, {'monster_uid', MUid}, {'dead', IsDead}, {'monster_deail', MonstInfo}, {'monster_uid', MUid}]});
                _ ->
                    ok
            end,
            UpGoBack
    end.

%% ----------------------------------------------------
%% @doc
%%      土匪进行战斗 UpPmarch=[{{role_uid,gid},{奖励},{随机奖励},死亡数量,伤兵数量}]
%% @end
%% ----------------------------------------------------
do_fighting(_, _, _, _, _, _, [], IsDead, UpGoBacks) ->
    {IsDead, UpGoBacks};
do_fighting(Src, Now, EndPoint, FightArgs, MonsterUid, MonstInfo, [Marching | T], IsDead, UpGoBack) ->
    {RoleUid, GId} = RoleAndGId = marching:get_roleuid_gid(Marching),
    ETime = marching:get_etime(Marching),
    MonsterSid = monster_detail:get_sid(MonstInfo),
    if
        IsDead -> %土匪已经死亡
            zm_event:notify(Src, 'fight_null_report', [
                {'role_uid', RoleUid},
                {'point_int', EndPoint},
                {'time', ETime},
                {'r_type', ?REPORT_NULL_MONSTER_DEAD},
                {'id', MonsterSid}]),%已到达时间+1秒为下一个状态开始时间
            do_fighting(Src, Now, EndPoint, FightArgs, MonsterUid, MonstInfo, T, IsDead, UpGoBack);
        true ->
            Garray = garray_db:get_garray(Src, RoleUid, GId),
            FighterRole = fighter:init_role(Src, RoleUid, GId, 0, Garray),%出发前已经检测过阵型
            NFightArgs = [
                {'seed', game_lib:get_seed()},
                {'fight_role', FighterRole},
                {'role_uid', RoleUid} | FightArgs],
            case match:auto_result(Src, RoleUid, NFightArgs) of
                {Winner, Result} ->%返回 result/6的结果,表示web一切正常
                    {NIsDead1, NUpGoBack1} =
                        try
                            Dead = result:get_dead(Result),
                            Injured = result:get_injured(Result),
                            WebRoleResult = result:get_queue(Result),
                            AllCardExp = result:get_allexp(Result),
                            WaveInfo = result:get_waves(Result),
                            {_, MarchiQueue, GarrayInjured, _AutoAddSoldier, _DeductSosldierNum} =
                                fighting:update_garray_after_fight(Src, WebRoleResult, RoleAndGId),
                            OneCardExp = garray_db:award_card_allexp(Src, RoleUid, GId, AllCardExp, z_lib:get_value(FightArgs, 'duplicate_sid', 0)),%武将加经验
                            set_front_lib:send_map_result(Src, RoleUid, {ETime, EndPoint, ?MONSTER, ?MONSTER, Winner, GId, {MarchiQueue, Dead, Injured, GarrayInjured}, OneCardExp, MonsterSid}),
                            CorpsUid = role_show:get_corps_uid(role_db:get_role_show(Src, RoleUid)),
                            AddCorpsExp = case CorpsUid =:= 0 of
                                true ->
                                    0;
                                false ->
                                    EnemyTotalDead = result:get_enemy_total_dead(Result),
                                    EnemyTotalInjure = result:get_enemy_total_injure(Result),
                                    {_, MSCorpsExpRateList} = zm_config:get('fight_info', 'monster_solider_corps_exp_rate'),
                                    MonsterDetail = monster_detail:get_cfg(MonsterSid),
                                    MSCorpsExpRate = z_lib:get_value(MSCorpsExpRateList, monster_detail:get_level(MonsterDetail), 0),
                                    game_lib:ceil(MSCorpsExpRate * (EnemyTotalDead + EnemyTotalInjure) / 10000)
                            end,
                            {Faward, AwardView, NIsDead, NUpGoBack} =
                                if
                                    Winner =:= 0 ->%玩家胜利,土匪死亡
                                        AwardSid = monster_detail:get_award(MonstInfo),
                                        ActiveMonsterDrops = active_monster_drop:get_active_monster_drops(Src, MonsterSid),
                                        Multi = active_addition:get_monster_drop_multi(Src),
                                        AwardList = awarder_game:award_percent(ActiveMonsterDrops, Multi) ++ awarder_game:award_percent(AwardSid, Multi),
                                        MonsterLv = monster_detail:get_level(MonstInfo),
                                        MonsetType = monster_detail:get_type(MonstInfo),
                                        TFun = fun(_, TimeSet1) ->
                                            KillLvList = z_lib:get_value(TimeSet1, 'monster', []),
                                            KLv = z_lib:get_value(KillLvList, MonsetType, 0),
                                            if
                                                MonsterLv > KLv ->
                                                    NMKList = lists:keystore(MonsetType, 1, KillLvList, {MonsetType, MonsterLv}),
                                                    {'ok', awarder_game:get_award_list(monster_detail:get_first_award(MonstInfo)), lists:keystore('monster', 1, TimeSet1, {'monster', NMKList})};
                                                true ->
                                                    {'ok', []}
                                            end
                                        end,
                                        FirstAward = z_db_lib:update(game_lib:get_table(Src, 'times_set'), RoleUid, times_set_lib:roleuid_key_init(), TFun, []),
                                        NAwardList = case AddCorpsExp > 0 of
                                            true ->
                                                awarder_game:merger([{'corps_exp', AddCorpsExp}], FirstAward ++ AwardList);
                                            false ->
                                                FirstAward ++ AwardList
                                        end,
                                        {AView, Award} = awarder_game:get_advance_award(Src, RoleUid, ?MODULE, NAwardList),
                                        NAView =
                                            case CorpsUid =/= 0 of
                                                true ->
                                                    AView;
                                                false ->
                                                    lists:keydelete('corps_exp', 1, AView)
                                            end,
                                        monster_db:monster_dead(Src, MonsterUid, EndPoint, MonstInfo),%土匪死亡
                                        task_event:notify(Src, RoleUid, [{'fight_times', ?MONSTER, MonsterSid}, {'fight_win_times', ?MONSTER, MonsterSid}]),
                                        zm_event:notify(Src, 'active_event', {'active_kill_monster', [{'role_uid', RoleUid}, {'monster_sid', MonsterSid}]}),
                                        zm_event:notify(Src, achieve, {RoleUid, {argu, [{fight_times, ?MONSTER, MonsterSid, 1}]}}),
                                        {FirstAward, NAView--FirstAward, true, [{RoleAndGId, Award, Dead, Injured} | UpGoBack]};
                                    true ->
                                        task_event:notify(Src, RoleUid, [{'fight_times', ?MONSTER, MonsterSid}]),
                                        zm_event:notify(Src, achieve, {RoleUid, {argu, [{fight_times, ?MONSTER, MonsterSid, 0}]}}),
                                        {AView, Award} =
                                            case AddCorpsExp > 0 of
                                                true ->
                                                    awarder_game:get_advance_award(Src, RoleUid, ?MODULE, [{'corps_exp', AddCorpsExp}]);
                                                false ->
                                                    {[], []}
                                            end,
                                        {[], AView, IsDead, [{RoleAndGId, Award, Dead, Injured} | UpGoBack]}
                                end,
                            zm_event:notify(Src, 'fight_monster_report', [
                                {'winner', Winner},
                                {'time', ETime},
                                {'award_list', {Faward, [{'card_exp', OneCardExp} | AwardView]}},
                                {'wave_infos', WaveInfo},
                                {'report_type', ?REPORT_FIGHT_MONSTER} | NFightArgs]),
                            {NIsDead, NUpGoBack}
                        catch
                            E1:E2 ->
                                zm_log:warn(?MODULE, ?MODULE, 'fighting', "handle_error", [{'e1', E1}, {'e2', E2}, {'point_uid', EndPoint},
                                    {'marching', Marching}, {'stacktrace', erlang:get_stacktrace()}]),
                                {IsDead, UpGoBack}
                        end,
                    do_fighting(Src, Now, EndPoint, FightArgs, MonsterUid, MonstInfo, T, NIsDead1, NUpGoBack1);
                WebErr ->
                    zm_log:warn(?MODULE, ?MODULE, 'fighting', "web_error", [{'error', WebErr}, {'point_uid', EndPoint}, {'marching', Marching}]),
                    do_fighting(Src, Now, EndPoint, FightArgs, MonsterUid, MonstInfo, T, IsDead, UpGoBack)
            end
    end.


%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
-spec first_fight(atom(), integer(), integer()) -> string() | {tuple(), integer(), integer(), tuple(), tuple(), integer()}.
first_fight(Src, RoleUid, MonsterSid) ->
    TSet = z_db_lib:get(game_lib:get_table(Src, 'times_set'), RoleUid, times_set_lib:roleuid_key_init()),
    KillLvList = z_lib:get_value(TSet, 'monster', []),
    case KillLvList =:= [] of
        true ->
            Now = time_lib:now_second(),
            GId = 1,
            EndPoint = point_lib:xy2int({255, 675}),
            MonsterDetail = monster_detail:get_cfg(MonsterSid),
            MNpcArray = monster_detail:get_npc(MonsterDetail),
            FightType = match_lib:get_fight_type(?MODULE),
            FightNpc = fighter:init_npc(MNpcArray),
            FightArgs = [
                {'ma', {'fighting', []}},
                {'auto', 1},%是否自动释放技能自动战斗 1:自动,0:手动
                {'fight_type', FightType},
                {'duplicate_sid', fighting:get_fight_scene('monster')},
                {'fight_enemy', FightNpc},
                {'sid', MonsterSid},
                {'point_int', EndPoint}],
            Garray = garray_db:get_garray(Src, RoleUid, GId),
            FighterRole = fighter:init_role(Src, RoleUid, GId, 0, Garray),%出发前已经检测过阵型
            NFightArgs = [
                {'seed', 99999},
                {'fight_role', FighterRole},
                {'role_uid', RoleUid} | FightArgs],
            case match:auto_result(Src, RoleUid, NFightArgs) of
                {Winner, Result} ->%返回 result/6的结果,表示web一切正常
                    Dead = result:get_dead(Result),
                    Injured = result:get_injured(Result),
                    WebRoleResult = result:get_queue(Result),
                    AllCardExp = result:get_allexp(Result),
                    WaveInfo = result:get_waves(Result),
                    {_, MarchiQueue, GarrayInjured, _AutoAddSoldier, _DeductSosldierNum} =
                        fighting:update_garray_after_fight(Src, WebRoleResult, {RoleUid, GId}, false),
                    OneCardExp = garray_db:award_card_allexp(Src, RoleUid, GId, AllCardExp, z_lib:get_value(FightArgs, 'duplicate_sid', 0)),%武将加经验
                    {Faward, AwardView, Award} =
                        if
                            Winner =:= 0 ->%玩家胜利,土匪死亡
                                AwardSid = monster_detail:get_award(MonsterDetail),
                                Multi = active_addition:get_monster_drop_multi(Src),
                                ActiveMonsterDrops = active_monster_drop:get_active_monster_drops(Src, MonsterSid),
                                AwardList = awarder_game:award_percent(ActiveMonsterDrops, Multi) ++ awarder_game:award_percent(AwardSid, Multi),
                                MonsterLv = monster_detail:get_level(MonsterDetail),
                                MonsetType = monster_detail:get_type(MonsterDetail),
                                TFun = fun(_, TimeSet1) ->
                                    KillLvList1 = z_lib:get_value(TimeSet1, 'monster', []),
                                    KLv = z_lib:get_value(KillLvList1, MonsetType, 0),
                                    if
                                        MonsterLv > KLv ->
                                            NMKList = lists:keystore(MonsetType, 1, KillLvList1, {MonsetType, MonsterLv}),
                                            {'ok', awarder_game:get_award_list(monster_detail:get_first_award(MonsterDetail)), lists:keystore('monster', 1, TimeSet1, {'monster', NMKList})};
                                        true ->
                                            {'ok', []}
                                    end
                                end,
                                FirstAward = z_db_lib:update(game_lib:get_table(Src, 'times_set'), RoleUid, times_set_lib:roleuid_key_init(), TFun, []),
                                {AView, Award1} = awarder_game:get_advance_award(Src, RoleUid, ?MODULE, FirstAward ++ AwardList),
                                task_event:notify(Src, RoleUid, [{'fight_times', ?MONSTER, MonsterSid}, {'fight_win_times', ?MONSTER, MonsterSid}]),
                                zm_event:notify(Src, 'active_event', {'active_kill_monster', [{'role_uid', RoleUid}, {'monster_sid', MonsterSid}]}),
                                zm_event:notify(Src, achieve, {RoleUid, {argu, [{fight_times, ?MONSTER, MonsterSid, 1}]}}),
                                {FirstAward, lists:keydelete('corps_exp', 1, AView)--FirstAward, Award1};
                            true ->
                                task_event:notify(Src, RoleUid, [{'fight_times', ?MONSTER, MonsterSid}]),
                                zm_event:notify(Src, achieve, {RoleUid, {argu, [{fight_times, ?MONSTER, MonsterSid, 0}]}}),
                                {[], [], {}}
                        end,
                    InjureMax = building_db:get_injure_max(Src, RoleUid),
                    AwardLog = awarder_game:give_award(Award),
                    %%更新军营数据
                    WeaponsResult = web_role_result_weapon_(WebRoleResult),
                    Fun = fun(_, Barracks) ->
                        {Injure2Dead, NBarracks} = barracks:fight_over(Barracks, GId, Dead, Injured, InjureMax),
                        Fun1 = fun(CBarracks, {WeaponSid, LeisureWeaponNum}) ->
                            {ok, barracks:update_weapons(CBarracks, WeaponSid, LeisureWeaponNum)}
                        end,
                        NBarracks1 = z_lib:foreach(Fun1, NBarracks, WeaponsResult),
                        {'ok', Injure2Dead, NBarracks1}
                    end,
                    Injure2Dead = z_db_lib:update(game_lib:get_table(Src, 'barracks'), RoleUid, barracks:init(), Fun, []),

                    fighting:injure2dead_mail(Src, RoleUid, Injure2Dead),
                    zm_event:notify(Src, 'bi_fight_deal_goback', [{'role_uid', RoleUid}, {'award', AwardLog}, {'gid', GId},
                        {'point_state', {?MONSTER, MonsterDetail}}]),
                    zm_event:notify(Src, 'fight_monster_report_sync', [
                        {'winner', Winner},
                        {'time', Now},
                        {'award_list', {Faward, [{'card_exp', OneCardExp} | AwardView]}},
                        {'wave_infos', WaveInfo},
                        {'report_type', ?REPORT_FIGHT_MONSTER} | NFightArgs]),
                    {AwardLog, {MarchiQueue, Dead, Injured, GarrayInjured}, OneCardExp, MonsterSid};
                WebErr ->
                    zm_log:warn(?MODULE, ?MODULE, 'fighting', "web_error", [{'error', WebErr}, {'point_uid', EndPoint}]),
                    "web_error"
            end;
        false ->%%这里给一个默认的返回值，防止前台报错后卡死引导阶段
            {{}, {{0, 0}, 0, 0, 0}, 0, MonsterSid}
        %"not_first_fight"
    end.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
web_role_result_weapon_(WebRoleResult) ->
    F = fun({_CUid, _Sid, _Star, _DeadNumTemp, _Injured, _CurSoldier, WeaponSid, _WeaponDeadNum, LeisureWeaponNum, _OccWeaponNum}) ->
        {WeaponSid, LeisureWeaponNum}
    end,
    lists:map(F, WebRoleResult).