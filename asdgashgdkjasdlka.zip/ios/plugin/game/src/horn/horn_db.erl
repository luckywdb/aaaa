-module(horn_db).

%%%=======================STATEMENT====================
-description("horn_db").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([send_horn/3]).
-export([add_horn_alone/2, del_horn_alone/2, check_horn_alone/2]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%     发送喇叭
%% @end
%% ----------------------------------------------------
send_horn(_, {_Src, Conditons, Consumes, RoleShow}, [{Index1, TimesSet}, {Index2, Goods}]) ->
    Now = time_lib:now_second(),
    case game_lib:checks({'horn_lib', 'check'}, {TimesSet, Goods, Now, RoleShow}, 'send_horn', Conditons ++ Consumes) of
        true ->
            {BiCS, {NGoods}} = game_lib:consumes({'horn_lib', 'consume'}, {Goods}, 'send_horn', Consumes),
            NTimesSet = lists:keystore('horn_time', 1, TimesSet, {'horn_time', Now}),
            {ok, {ok, BiCS}, [{Index1, NTimesSet}, {Index2, NGoods}]};
        Err ->
            throw(Err)
    end.


%%-------------------------------------------------------------------
%% @doc
%%      单机发言
%% @end
%%-------------------------------------------------------------------
add_horn_alone(Src, UserId) ->
    case z_db_lib:get(game_lib:get_table(Src, 'horn_alone'), UserId, 'none') of
        'none' ->
            z_db_lib:update(game_lib:get_table(Src, 'horn_alone'), UserId, 0);
        _ ->
            'ok'
    end.

%%-------------------------------------------------------------------
%% @doc
%%      解除单机发言
%% @end
%%-------------------------------------------------------------------
del_horn_alone(Src, UserId) ->
    z_db_lib:delete(game_lib:get_table(Src, 'horn_alone'), UserId).

%%-------------------------------------------------------------------
%% @doc
%%      检测禁言,0表示没有被禁言，1表示被禁言
%% @end
%%-------------------------------------------------------------------
check_horn_alone(Src, UserId) ->
    case z_db_lib:get(game_lib:get_table(Src, 'horn_alone'), UserId, 'none') of
        'none' ->
            0;
        _ ->
            1
    end.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
