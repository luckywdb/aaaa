-module(horn_lib).

%%%=======================STATEMENT====================
-description("horn_lib").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([check/3, consume/3]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        
%% @end
%% ----------------------------------------------------
check({_TimesSet, Goods, _Now, _RoleShow}, 'send_horn', {'prop', {Sid, Value}}) ->
    storage_lib:exist_by_sid(Goods, {Sid, Value});
check({TimesSet, _Goods, Now, _RoleShow}, 'send_horn', {'cd', Sec}) ->
    {_, HornTime} = times_set_lib:get(TimesSet, 'horn_time', {'horn_time', 0}),
    Now >= HornTime + Sec;
check({_TimeSets, _Goods, _Now, RoleShow}, 'send_horn', {'vip_level', VipLevel}) ->
    role_show:get_vip_level(RoleShow) >= VipLevel;
check({_TimeSets, _Goods, _Now, RoleShow}, 'send_horn', {'role_level', RoleLevel}) ->
    role_show:get_level(RoleShow) >= RoleLevel;
check(_, _, _) ->
    false.

consume({Goods}, 'send_horn', {'prop', {Sid, Value}}) ->
    {Cs, NGoods} = storage_lib:deduct_by_sid(Goods, {Sid, Value}),
    {Cs, {NGoods}};
consume(Table, _, _) ->%外部条件不需处理
    {'none', Table}.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
