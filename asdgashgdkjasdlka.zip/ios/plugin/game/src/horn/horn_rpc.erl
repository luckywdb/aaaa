-module(horn_rpc).

%%%=======================STATEMENT====================
-description("horn_rpc").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([send/2]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        
%% @end
%% ----------------------------------------------------
send(Src, HornList) ->
    ServerNames = args_db:get_all_servernames(Src),
    List = z_lib:foreach(fun(Acc, {ServerMd5Name, ServerName, RoleName, Content}) ->
        case lists:member(ServerMd5Name, ServerNames) of
            false ->
                {ok, [{ServerName, RoleName, Content}]};
            true ->
                {ok, Acc}
        end
    end, [], HornList),
    case List =/= [] of
        true ->
            set_front_lib:send_horn(Src, [], List);
        false ->
            ok
    end.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
