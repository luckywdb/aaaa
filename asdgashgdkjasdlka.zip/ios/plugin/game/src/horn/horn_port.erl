-module(horn_port).

%%%=======================STATEMENT====================
-description("horn_port").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([send_horn/5]).

%%%=======================INCLUDE======================
-include("../include/chat.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      发送喇叭
%% @end
%% ----------------------------------------------------
send_horn([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    Content = z_lib:get_value(Msg, "str", ""),
    CheckVaild = is_list(Content) andalso Content =/= "",
    if
        CheckVaild ->
            Size = string_lib:compute_size(Content),
            {_, MaxSize} = zm_config:get('horn_info', 'content_max_size'),
            case Size =< MaxSize of
                true ->
                    case string_lib:check_str(Src, Content) of
                        false ->
                            case chat_db:check_shutup(Src, RoleUid) of
                                false ->
                                    GUser = user_db:get_user(Src, RoleUid),
                                    DeviceId = guser:get_device_id(GUser),
                                    Username = element(3, user_db:get_user_name(Src, RoleUid)),
                                    case horn_db:check_horn_alone(Src, Username) =:= 1 of
                                        true ->
                                            {ok, [], Info, [{msg, "horn_alone"}]};
                                        false ->
                                            ServerMd5Name = args_system:get_server_name_bypsid(Src, {uid_lib:get_pid(RoleUid), uid_lib:get_sid(RoleUid)}),
                                            case server_cross_db:get_server_cross(Src, "lb", ServerMd5Name) of
                                                'none' ->
                                                    {ok, [], Info, [{msg, "horn_cross_error"}]};
                                                ServerCorss ->
                                                    RoleShow = role_db:get_role_show(Src, RoleUid),
                                                    {_, Conditons, Consumes} = zm_config:get('horn_info', 'send_conditions'),
                                                    TableName = game_lib:get_table(Src),
                                                    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'times_set', RoleUid, []}, {'goods', RoleUid, {}}]),
                                                    case z_db_lib:handle(TableName, {M, F, A}, {Src, Conditons, Consumes, RoleShow}, TableKeys) of
                                                        {ok, BiCS} ->
                                                            zm_event:notify(Src, 'bi_hero_send', [{'role_uid', RoleUid}, {'consume', BiCS}]),
                                                            RoleName = role_show:get_name(RoleShow),
                                                            ServerName = server_cross:get_src_sname(ServerCorss),
                                                            set_front_lib:send_horn(Src, [RoleUid], [{ServerName, RoleName, Content}]),
                                                            server_cross_msg:send_cast(Src, "lb", ServerMd5Name, {'center_horn_rpc', 'add_horn', {ServerMd5Name, ServerName, RoleName, Content}}),

                                                            RoleShow = role_db:get_role_show(Src, RoleUid),
                                                            RoleLv = role_show:get_level(RoleShow),
                                                            MonitorChat = {integer_to_list(RoleUid), RoleName, Content, RoleLv, DeviceId},
                                                            monitor_lib:set_chat(Src, RoleUid, Username, ?HORN, MonitorChat),
                                                            {ok, [], Info, [{msg, "ok"}]};
                                                        Err ->
                                                            {ok, [], Info, [{msg, Err}]}
                                                    end
                                            end
                                    end;
                                true ->
                                    {ok, [], Info, [{msg, "shutup"}]}
                            end;
                        _ ->
                            {'ok', [], Info, [{'msg', "have_mask_word"}]}
                    end;
                false ->
                    {ok, [], Info, [{msg, "size_limit"}]}
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
