-module(cash_db).
-description("cash_db").
-copyright({seasky, 'www.seasky.cn'}).
-author({wkl, 'wangkeli@youkia.net'}).
-vsn(1).
%%%=======================EXPORT=======================
-export([
    get_order/2,
    add_cash_order/3,
    get_cash/2,
    buy_rmb/5,
    cash_award/3,
    format/2,
    buy_activity_giftbag/5,
    add_giftbag_order/3,
    reset_cash_item/1
]).
%%%=======================INCLUDE======================

%%%=======================DEFINE=======================

%%%=======================RECORD=======================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%     获得所有充值订单
%% @end
%% ----------------------------------------------------
get_order(Src, RoleUid) ->
    z_db_lib:get(game_lib:get_table(Src, order), RoleUid, []).

%% ----------------------------------------------------
%% @doc
%%     得到充值信息
%% @end
%% ----------------------------------------------------
get_cash(Src, RoleUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'cash'), RoleUid, {0, []}).

%% ----------------------------------------------------
%% @doc
%%     成功充值
%% @end
%% ----------------------------------------------------
add_cash_order(_, {_Src, UserName, Item, AddCash, A}, [{Index1, Role}, {Index2, OldRmb}, {Index3, none}, {Index4, {Cash, ItemList}}, {Index5, TimesSet}]) ->
    {_, Value} = lists:keyfind('value', 1, A),
    %% 检测每档首冲多倍
    {First, AddRmb, NItemList} = case lists:member(Item, ItemList) of
        false ->%% 该档位是首次充值
            {1, Value + element(2, lists:keyfind('first_value', 1, A)), [Item | ItemList]};
        _ ->
            {0, Value + element(2, lists:keyfind('normal_value', 1, A)), ItemList}
    end,
    %% 兑换比例
%%    {_, ExRmb, ExExp} = zm_config:get('cash_list', 'cash_exchange'),
    %% 该档位消耗现金
%%    ItemCash = element(2, lists:keyfind('cash', 1, A)),
    %% 该档位的配置经验
    ItemVipExp = element(2, lists:keyfind('exp', 1, A)),
    %% 增加vip经验
    VipExp = ItemVipExp, %%(AddCash - ItemCash) div ExExp + ItemVipExp,
    NewRole = role:set_vipexp(Role, role:get_vipexp(Role) + VipExp),
    %% 最终增加元宝
    V1 = 0,%%(AddCash - ItemCash) div ExRmb,
    NAddRmb = AddRmb + V1,
    {AwardLog, NewRmb} = rmb_lib:add_buy_rmb(OldRmb, NAddRmb),
    NCash = Cash + AddCash,
    NewOrder = {time_lib:now_second(), UserName, Item, AddCash, NAddRmb, rmb_lib:get_rmb(NewRmb)},
    {ok, {ok, First, NAddRmb, OldRmb, NewRmb, NCash, VipExp, NewRole, {AwardLog}, Role, Value + V1},
        [{Index1, NewRole}, {Index2, NewRmb}, {Index3, NewOrder}, {Index4, {NCash, NItemList}}, {Index5, times_set_lib:update(TimesSet, {'cash', AddCash})}]};
add_cash_order(_, _, _) ->
    throw("order_id_error").

%% ----------------------------------------------------
%% @doc
%%     充值购买钻石
%% @end
%% ----------------------------------------------------
buy_rmb(A, Src, RoleUid, _Msg, Info) ->
    UserName = element(2, lists:keyfind('user_name', 1, A)),%% 玩家用户名
    Item = element(2, lists:keyfind('ext', 1, A)),%% 充值档位
    Cash = list_to_integer(element(2, lists:keyfind('rmb', 1, A))),%% 花费人民币
    OrderId = element(2, lists:keyfind('orderid', 1, A)),%% 账单号
    BiPlatform = element(2, lists:keyfind('platform', 1, A)),%% 平台渠道id
    Bi = z_lib:get_value(A, 'bi', 1),%% 是否记录BI 0和1  1是 记录
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'role', RoleUid}, {'rmb', RoleUid, rmb_lib:init()}, {'order', OrderId, 'none'},
        {'cash', RoleUid, {0, []}}, {'times_set', {RoleUid, 5}, []}]),
    case z_db_lib:handle(TableName, {?MODULE, 'add_cash_order', []}, {Src, UserName, Item, Cash, A}, TableKeys) of
        {'ok', First, IncrRmb, OldRmb, NewRmb, NCash, VipExp, Role, AwardLog, OldRole, CashRmb} ->
            set_front_lib:send_cash(Src, RoleUid, [{'rmb', rmb_lib:get_rmb(NewRmb)}, {'vipexp', role:get_vipexp(Role)}, {'first', First}, {'cash', NCash div 100}, {'iteam', Item}]),
            %% 充值成功(充值日志)
            log_lib:log_cash(?MODULE, "http_incr_cash_ok", [{'username', UserName}, {'role_uid', RoleUid}, {'order', OrderId},
                {'item_id', Item}, {'first', First}, {'rmb', OldRmb, NewRmb}, {'award', AwardLog},
                {'cash', NCash, Cash}, {'cash_rmb', CashRmb}, {'vip_exp', role:get_vipexp(Role)}, {'info', Info}]),
            zm_event:notify(Src, 'update_role_show', {role:get_uid(Role), {'vip_level', game_lib:get_level('vip', Role)}}),

            zm_event:notify(Src, 'cash_ok', [{'role_uid', RoleUid}, {'orderid', OrderId}, {'item_id', Item}, {'incr_rmb', IncrRmb}, {'award', AwardLog},
                {'vip_exp', role:get_vipexp(Role), VipExp}, {'cash', Cash div 100}, {'cash_rmb', CashRmb}, {'first', First},
                {'role', OldRole, Role}, {'platform', BiPlatform}, {'bi', Bi}, {'cash_a', A}, {'bi_cash', Cash}]),
            %%task_event:notify(Src, RoleUid, [{'one_cash', Cash div 100}]), %TODO 开服活动
            1;
        Reason ->
            zm_log:warn(Src, ?MODULE, 'http_incr_cash', "add_cash_order_error", [{'username', UserName}, {'role_uid', RoleUid}, {'order', OrderId},
                {'item_id', Item}, {'cash', Cash}, {'reason', Reason}, {'info', Info}]),
            -4 %%订单重复
    end.
%% ----------------------------------------------------
%% @doc
%%  购买活动礼包
%% @end
%% ----------------------------------------------------
buy_activity_giftbag(A, Src, RoleUid, _Msg, Info) ->
    UserName = element(2, lists:keyfind('user_name', 1, A)),%% 玩家用户名
    Item = element(2, lists:keyfind('ext', 1, A)),%% 充值档位
    Cash = list_to_integer(element(2, lists:keyfind('rmb', 1, A))),%% 花费人民币
    OrderId = element(2, lists:keyfind('orderid', 1, A)),%% 账单号
    BiPlatform = element(2, lists:keyfind('platform', 1, A)),%% 平台渠道id
    ActiveItemSid = element(2, lists:keyfind('active_item_sid', 1, A)),
    Bi = z_lib:get_value(A, 'bi', 1),%% 是否记录BI 0和1  1是 记录
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'rmb', RoleUid, rmb_lib:init()}, {'order', OrderId, 'none'}, {'cash', RoleUid, {0, []}}]),
    case z_db_lib:handle(TableName, {?MODULE, 'add_giftbag_order', []}, {Src, UserName, Item, Cash, A}, TableKeys) of
        {'ok', NCash} ->
            %% 充值成功(充值日志)
            log_lib:log_cash(?MODULE, "http_incr_cash_giftbag_ok", [{'username', UserName}, {'role_uid', RoleUid}, {'order', OrderId},
                {'item_id', Item}, {'cash', NCash, Cash}, {'info', Info}, {active_item_sid, ActiveItemSid}]),

            zm_event:notify(Src, 'cash_giftbag_ok', [{'role_uid', RoleUid}, {'orderid', OrderId}, {'item_id', Item},
                {'cash', Cash div 100}, {'platform', BiPlatform}, {'bi', Bi}, {'active_item_sid', ActiveItemSid}, {'bi_cash', Cash}]),
            1;
        Reason ->
            zm_log:warn(Src, ?MODULE, 'http_incr_cash_giftbag', "add_cash_giftbag_order_error", [{'username', UserName}, {'role_uid', RoleUid}, {'order', OrderId},
                {'item_id', Item}, {'cash', Cash}, {'reason', Reason}, {'info', Info}]),
            -4 %%订单重复
    end.


%% ----------------------------------------------------
%% @doc
%%     成功充值
%% @end
%% ----------------------------------------------------
add_giftbag_order(_, {_Src, UserName, Item, AddCash, _A}, [{_Index2, Rmb}, {Index3, none}, {Index4, {Cash, ItemList}}]) ->
    NCash = Cash + AddCash,
    NItemList = case lists:member(Item, ItemList) of
        true ->
            ItemList;
        false ->
            [Item | ItemList]
    end,
    NewOrder = {time_lib:now_second(), UserName, Item, AddCash, 0, rmb_lib:get_rmb(Rmb)},
    {ok, {ok, NCash},
        [{Index3, NewOrder}, {Index4, {NCash, NItemList}}]};
add_giftbag_order(_, _, _) ->
    throw("order_id_error").

%% ----------------------------------------------------
%% @doc
%%      充值领奖(支持首充领奖)
%% @end
%% ----------------------------------------------------
cash_award(Src, RoleUid, Sid) ->
    case zm_config:get('cash_award', Sid) of
        none ->
            "input_error";
        {_, AwardList, Conditions} ->
            Fun = fun(_, TimesSet) ->
                {_, Value} = times_set_lib:get(TimesSet, Sid, {Sid, 0}),
                if
                    Value =:= 0 ->
                        case game_lib:checks({'cash_lib', 'check'}, TimesSet, 'cash_award', Conditions) of
                            true ->
                                NTimesSet = times_set_lib:update(TimesSet, {Sid, 1}),
                                {'ok', {TimesSet, NTimesSet}, NTimesSet};
                            Err ->
                                throw(Err)
                        end;
                    true ->
                        throw("already_get")
                end
            end,
            case z_db_lib:update(game_lib:get_table(Src, 'times_set'), {RoleUid, 5}, [], Fun, []) of
                {TimesSet, NTimesSet} ->
                    AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, AwardList),
                    zm_log:info(Src, ?MODULE, 'cash_award', "cash_award", [{'role_uid', RoleUid}, {'sid', Sid}, {'award', AwardLog}, {'times_set', TimesSet, NTimesSet}]),
                    zm_event:notify(Src, 'cash_award', [{'role_uid', RoleUid}, {'sid', Sid}, {'award', AwardLog}]),
                    AwardLog;
                Err ->
                    Err
            end
    end.

%% ----------------------------------------------------
%% @doc
%%     充值相关信息序列化
%% @end
%% ----------------------------------------------------
format(Src, RoleUid) ->
    {Cash, Items} = get_cash(Src, RoleUid),%玩家所有充值档位金额之和
    TimesSet = z_db_lib:get(game_lib:get_table(Src, 'times_set'), {RoleUid, 5}, []),
    Sid = case [V || {V, _} <- TimesSet, is_integer(V)] of
        [] ->
            0;
        List ->
            lists:max(List)
    end,
    {_, CashValue} = times_set_lib:get(TimesSet, 'cash', {'cash', 0}),%玩家具体充值金额
    {Cash div 100, Sid, CashValue div 100, list_to_tuple(Items)}.
%% ----------------------------------------------------
%% @doc
%%  重置玩家每个档位首充信息
%% @end
%% ----------------------------------------------------
reset_cash_item(Src) ->
    Table = game_lib:get_table(Src, 'cash'),
    UpdateFun = fun(_RoleUid, {Cash, _ItemList}) ->
%%        log_lib:log_cash(?MODULE, "reset_cash_item", [{'role_uid', RoleUid}, {'item_list', ItemList}]),  %todo 去掉日志
        {ok, ok, {Cash, []}};
        (_, _) ->
            {ok, ok}
    end,
    Fun = fun(_Src, Key, _, _) ->
        z_db_lib:update(Table, Key, [], UpdateFun, Key),
        ok
    end,
    z_db_lib:table_iterate(Src, Table, Fun, [], []),
    set_front_lib:send_first_cash_state(Src).
%%%======================LOC FUNCTIONS=================

