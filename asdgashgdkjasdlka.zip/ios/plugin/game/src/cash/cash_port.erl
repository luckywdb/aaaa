-module(cash_port).
-description("cash_port").
-copyright({seasky, 'www.seasky.cn'}).
-author({hzh, 'huangzhenghan@youkia.net'}).
-vsn(1).
%%%=======================EXPORT=======================
-export([
    get_cash_list/5,
    get_first_cash/5,
    cash_award/5,
    http_incr_cash/5,
    get_keyinfo/5
]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%     得到充值条目
%% @end
%% ----------------------------------------------------
get_first_cash(_, _, Attr, Info, _Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    {ok, [], Info, [{msg, {active_lib:get_fixed_active_sequence('first_cash'), cash_db:format(Src, RoleUid)}}]}.

%% ----------------------------------------------------
%% @doc
%%     获得已经首充过的档位
%% @end
%% ----------------------------------------------------
get_cash_list(_, _, Attr, Info, _) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    {_, List} = cash_db:get_cash(Src, RoleUid),
    {ok, [], Info, [{msg, list_to_tuple(List)}]}.

%% ----------------------------------------------------
%% @doc
%%      充值领奖(支持首充领奖)
%% @end
%% ----------------------------------------------------
cash_award(_, _, Attr, Info, Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, 'src', 'none'),
    Sid = z_lib:get_value(Msg, "sid", 0),
    if
        Sid < 1 ->
            {ok, [], Info, [{msg, "input_error"}]};
        true ->
            {ok, [], Info, [{msg, cash_db:cash_award(Src, RoleUid, Sid)}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     充值(该方法只供测试,以后要删)
%% @end
%% ----------------------------------------------------
http_incr_cash([CashSrc], _, Attr, Info, Msg) ->
    case init:get_argument('statue') of
        {ok, [["network"]]} ->
            Src = z_lib:get_value(Info, 'src', 'none'),
            RoleUid = role_lib:get_uid(Attr),
            Item = z_lib:get_value(Msg, "ext", "100"),
            CashItem = zm_config:get('cash_list', Item),
            if
                is_list(Item) andalso CashItem =/= 'none' ->
                    {_ID, _Name, Cash, [_M, _F, A]} = CashItem,
                    Rmb = integer_to_list(Cash),
                    NMsg = lists:keystore("rmb", 1, Msg, {"rmb", Rmb}),
                    {Pid, Sid, UserId} = z_db_lib:get(game_lib:get_table(Src, 'uid_psu'), RoleUid, none),
                    Amount = z_lib:get_value(A, cash, 0),
                    OrderId = integer_to_list(uid_lib:create_orderuid(Src)),
                    Sign = sign_lib:sign_compute(UserId, lists:concat([UserId, OrderId, Amount, Rmb, Item])),
                    ServerName = args_system:get_server_name_bypsid(Src, {Pid, Sid}),
                    NInfo = lists:keyreplace(src, 1, Info, {src, CashSrc}),
                    cash_http_port:http_incr_cash([Src], 'none', 'none', NInfo,
                        [{"server_name", ServerName},
                            {"userid", UserId}, {"rmb", Rmb},
                            {"amount", Amount}, {"sig2", Sign}, {"bi", 0}, {"orderid", OrderId} | NMsg]);
                true ->
                    {ok, [], Info, [{msg, "input_error"}]}
            end;
        _ ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     获取充值条目
%% @end
%% ----------------------------------------------------
get_keyinfo(_, _, _Attr, Info, Msg) ->
    case zm_config:get(cash_keyinfo, z_lib:get_value(Msg, "key", 1)) of
        none ->
            {ok, [], Info, [{msg, "info null"}]};
        {_, Value} ->
            {ok, [], Info, [{msg, {Value}}]}
    end.
