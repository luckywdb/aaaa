%%充值工具
-module(cash_lib).
-description("cash_lib").
-copyright({seasky, 'www.seasky.cn'}).
-author({hzh, 'huangzhenghan@youkia.net'}).
-vsn(1).
%%%=======================EXPORT=======================
-export([
    verify_item/2,
    check_order/2,
    check/3
]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=================EXPORTED FUNCTIONS=================
%-------------------------------------------------------------------
% Func:verify_item/2
% description:认证最正确的充值档位
% Return:
%-------------------------------------------------------------------
verify_item(Item, _Cash) ->
    Item.
%%    case zm_config:get('cash_list', Item) of
%%        {_, _, Cash, _} ->%% 充值金额一样
%%            Item;
%%        {_, _, ICash, ['month_card_db', _, _]} ->%% 月卡
%%            if
%%                Cash >= ICash ->
%%                    Item;
%%                true ->
%%                    {_, Values} = zm_config:get('cash_list', 'cash_key'),
%%                    game_lib:level_value(Cash, Values)
%%            end;
%%        _ ->%% 其他档位
%%            {_, Values} = zm_config:get('cash_list', 'cash_key'),
%%            game_lib:level_value(Cash, Values)
%%    end.

%-------------------------------------------------------------------
% Func:check_order/2
% description:检查该账单是否成功
% Return:
%-------------------------------------------------------------------
check_order(Sign, {PId, OrderId, Amount, Rmb, Ext}) ->
    Sign =:= sign_lib:sign_compute(PId, lists:concat([PId, OrderId, Amount, Rmb, Ext])).

%% ----------------------------------------------------
%% @doc
%%     检验条件
%% @end
%% ----------------------------------------------------
%% 充值奖励,充值数检查
check(TimesSet, 'cash_award', {'cash', Value}) -> %配置单位为分
    {_, Cash} = times_set_lib:get(TimesSet, 'cash', {'cash', 0}),
    Cash >= Value;
check(_Tables, _Arg, _H) ->
    false.

