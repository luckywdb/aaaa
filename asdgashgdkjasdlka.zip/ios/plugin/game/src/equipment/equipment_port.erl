-module(equipment_port).

%%%=======================STATEMENT====================
-description("装备端口").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([off_equipment/5, put_equipment/5, up_streng/5, exchange_equipment/5]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================
-define(UPSTRENG_MAX_NUM, 200).
%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%     脱装备
%% @end
%% ----------------------------------------------------
off_equipment([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    CardUid = erlang:list_to_integer(z_lib:get_value(Msg, "card_uid", "0")),
    Index = z_lib:get_value(Msg, "index", 0),
    CheckVaild = valid_lib:check_valib([{'ge', CardUid, 1}, {'range', Index, {1, 4}}]),
    if
        CheckVaild ->
            case storage_lib:find_by_uid(storage_db:get_storage('card', Src, RoleUid), CardUid) of%%是不是自己的卡片
                CardUid ->
                    {ok, [], Info, [{msg, "no_card"}]};
                {_, Prop} ->
                    TableName = game_lib:get_table(Src),
                    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'equipment', RoleUid, {}},
                        {'card_put_prop', CardUid, card_put_prop:init()}]),%%初穿装数据
                    case z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, Index}, TableKeys) of
                        {EquipLog, OldC, NewC} ->
                            %% 记录武将脱装备日志
                            zm_log:info(Src, ?MODULE, 'off_equipment', "off_equipment", [{'roleuid', RoleUid}, {'card_uid', CardUid}, {'card', Prop},
                                {'equipment', EquipLog}, {'index', Index},
                                {'old_put', OldC}, {'new_put', NewC}]),
                            %% 脱装备事件
                            Card = prop_kit_lib:get_prop_record(Prop),
                            GId = card:get_state(Card),
                            if
                                GId > 0 ->
                                    Country = role_lib:get_country(Attr),
                                    zm_event:notify(Src, {'power_change', Country}, [{'uid', RoleUid}, {'gid', GId}, {'country', Country}]);
                                true ->
                                    'ignore'
                            end,
                            {ok, [], Info, [{msg, "ok"}]};
                        Err ->
                            {ok, [], Info, [{msg, Err}]}
                    end
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     穿装备
%% @end
%% ----------------------------------------------------
put_equipment([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    CardUid = erlang:list_to_integer(z_lib:get_value(Msg, "card_uid", "0")),
    EquipmentUid = erlang:list_to_integer(z_lib:get_value(Msg, "equipment_uid", "0")),
    CheckVaild = valid_lib:check_valib([{'ge', CardUid, 1}, {'ge', EquipmentUid, 1}]),
    if
        CheckVaild ->
            case storage_lib:find_by_uid(storage_db:get_storage(card, Src, RoleUid), CardUid) of%%是不是自己的卡片
                CardUid ->
                    {ok, [], Info, [{msg, "no_card"}]};
                {_, Prop} ->
                    Card = prop_kit_lib:get_prop_record(Prop),
                    TableName = game_lib:get_table(Src),
                    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'equipment', RoleUid, {}},
                        {'card_put_prop', CardUid, card_put_prop:init()}]),%%初穿装数据
                    case z_db_lib:handle(TableName, {M, F, A}, {Src, role_db:get_role(Src, RoleUid), EquipmentUid, Card}, TableKeys) of
                        {Equipment, OldC, NewC} ->
                            %% 记录武将穿装备日志
                            zm_log:info(Src, ?MODULE, 'put_equipment', "put_equipment", [{'roleuid', RoleUid}, {'card_uid', CardUid}, {'card', Card},
                                {'equipment', Equipment}, {'old_put', OldC}, {'new_put', NewC}, {'equipment_uid', EquipmentUid}]),
                            %% 穿装备影响战斗力
                            GId = card:get_state(Card),
                            if
                                GId > 0 ->
                                    Country = role_lib:get_country(Attr),
                                    zm_event:notify(Src, {'power_change', Country}, [{'uid', RoleUid}, {'gid', GId}, {'country', Country}]);
                                true ->
                                    'ignore'
                            end,
                            {ok, [], Info, [{msg, "ok"}]};
                        Err ->
                            {ok, [], Info, [{msg, Err}]}
                    end
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     装备强化
%% @end
%% ----------------------------------------------------
up_streng([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    EquipUid = erlang:list_to_integer(z_lib:get_value(Msg, "equipment_uid", "0")),
    Number = z_lib:get_value(Msg, "number", 1),%%强化次
    CheckVaild = valid_lib:check_valib([{'range', Number, {1, ?UPSTRENG_MAX_NUM}}, {'ge', EquipUid, 1}]),
    if
        CheckVaild ->
            TableName = game_lib:get_table(Src),
            CardUid = case z_lib:get_value(Msg, "card_uid", []) of
                [] ->
                    0;
                Cuid ->
                    erlang:list_to_integer(Cuid)
            end,
            Tables = if
                CardUid =< 0 ->
                    %包裹内强化
                    [{'role', RoleUid}, {'equipment', RoleUid, {}}];
                true ->
                    [{'role', RoleUid}, {'card', RoleUid}, {'card_put_prop', CardUid, card_put_prop:init()}]
            end,
            TableKeys = z_db_lib:transformation_tablekey(TableName, Tables),
            Reply = case z_db_lib:handle(TableName, {M, F, A}, {Src, EquipUid, CardUid, Number}, TableKeys) of
                {Sid, OldE, NewE, BiCS, GId} ->
                    %%记录消耗
                    %% 记录武将装备强化日志
                    zm_log:info(Src, ?MODULE, 'up_streng', "equipment_up_streng", [{'roleuid', RoleUid}, {'consume', BiCS},
                        {'old_equipment', OldE}, {'new_equipment', NewE},
                        {'number', Number}, {'equipment_uid', EquipUid}]),
                    zm_event:notify(Src, 'achieve', {RoleUid, {'argu', 'equipment_up_streng'}}),
                    %% 装备强化事件
                    zm_event:notify(Src, 'equipment_up_streng', [{'role_uid', RoleUid}, {'equipment', NewE},
                        {'consume', BiCS}, {'number', Number}, {'uid', EquipUid}, {'sid', Sid}]),
                    if
                        GId > 0 andalso CardUid > 0 ->
                            Country = role_lib:get_country(Attr),
                            zm_event:notify(Src, {'power_change', Country}, [{'uid', RoleUid}, {'gid', GId}, {'country', Country}]);
                        true ->
                            'ok'
                    end,
                    {equipment:get_streng(NewE)};
                Other ->
                    Other
            end,
            {ok, [], Info, [{msg, Reply}]};
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.


%% ----------------------------------------------------
%% @doc
%%     装备交换
%% @end
%% ----------------------------------------------------
exchange_equipment([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    CardUid = list_to_integer(z_lib:get_value(Msg, "card_uid", "0")),
    TargetCardUid = list_to_integer(z_lib:get_value(Msg, "target_card_uid", "0")),
    CheckVaild = valid_lib:check_valib([{'ge', CardUid, 1}, {'ge', TargetCardUid, 1}]),
    if
        CheckVaild ->
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'card', RoleUid, {}}, {'card_put_prop', CardUid, card_put_prop:init()},
                {'card_put_prop', TargetCardUid, card_put_prop:init()}]),
            case z_db_lib:handle(TableName, {M, F, A}, {CardUid, TargetCardUid}, TableKeys) of
                {'ok', GIds} ->
                    zm_log:info(Src, ?MODULE, 'exchange_equipment', "equipment_exchange_equipment", [{'roleuid', RoleUid}, {'card_uid', CardUid},
                        {'target_card_uid', TargetCardUid}]),
                    Country = role_lib:get_country(Attr),
                    zm_event:notify(Src, {'power_change', Country}, [{'uid', RoleUid}, {'gid', GIds}, {'country', Country}]),
                    {ok, [], Info, [{msg, "ok"}]};
                R ->
                    {ok, [], Info, [{msg, R}]}
            end;
        true ->
            {ok, [], Info, [{msg, "carduid_error"}]}
    end.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
