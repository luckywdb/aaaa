-module(equipment_lib).

%%%=======================STATEMENT====================
-description("装备工具").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([off_equipment/4, check/3, consume/3, get_up_max/2, up_streng/4]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%     脱指定装备
%% @end
%% ----------------------------------------------------
-spec off_equipment(Src, RoleUid, EquipmentStorage, Equipment) -> {tuple(), tuple(), list()} when
    Src :: atom(),
    RoleUid :: integer(),
    EquipmentStorage :: tuple(),
    Equipment :: tuple()|list().
off_equipment(Src, RoleUid, EquipmentStorage, Equipment) when is_tuple(Equipment) ->
    off_equipment(Src, RoleUid, EquipmentStorage, [Equipment]);
off_equipment(_Src, _RoleUid, EquipmentStorage, []) ->
    {EquipmentStorage, {}, []};
off_equipment(Src, RoleUid, EquipmentStorage, [E | _] = Equipments) ->
    LimitSize = storage_lib:get_limit_size(Src, RoleUid, prop_kit_lib:get_prop_type(E)),
    {NStorage, AddProps, OverFlowProps} = storage_lib:add(LimitSize, Equipments, EquipmentStorage),
    {NStorage, list_to_tuple([storage_lib:format_equipment(P) || P <- AddProps]), OverFlowProps}.

%% ----------------------------------------------------
%% @doc
%%     检测条件
%% @end
%% ----------------------------------------------------
-spec check(term(), term(), tuple()) -> boolean().
check({Role, _Card}, 'put_equipment', {'role_level', Level}) ->%穿装备检验主公等级
    game_lib:get_level('role', Role) >= Level;
check({_Role, Card}, 'put_equipment', {'card_level', Level}) ->%穿装备检验武将等级
    game_lib:get_level('card', Card) >= Level;
check(Role, 'up_streng', {'money', Value}) ->%强化扣钱
    role:get_money(Role) >= Value;
check(Role, 'up_streng', {'iron', Value}) ->%强化扣铁
    role:get_iron(Role) >= Value;
check(_, _, _) ->
    false.

%% ----------------------------------------------------
%% @doc
%%     消耗
%% @end
%% ----------------------------------------------------
-spec consume(term(), term(), tuple()) -> {'none'|tuple(), tuple()}.
consume(Role, 'up_streng', {'money', Value}) ->%强化扣钱
    {BiCs, Role1} = role_lib:deduct_money(Role, Value),
    {BiCs, Role1};
consume(Role, 'up_streng', {'iron', Value}) ->%强化扣铁
    {BiCs, Role1} = role_lib:deduct_iron(Role, Value),
    {BiCs, Role1};
consume(Table, _, _) ->%外部条件不需处理
    {'none', Table}.

%% ----------------------------------------------------
%% @doc
%%     装备最大强化等级
%% @end
%% ----------------------------------------------------
-spec get_up_max(role:role(), equipment:equipment()) -> integer().
get_up_max(Role, Equipment) ->
    %强化等级受主公等级影响, 以倍数影响
    RoleLv = game_lib:get_level('role', Role),
    Max = RoleLv * element(2, zm_config:get(equipment_up_streng, role_level_multiple)),
    Quality = equipment:get_quality(Equipment),
    {_, QualityMax} = zm_config:get('equipment_up_streng', Quality),
    min(Max, QualityMax).

%% ----------------------------------------------------
%% @doc
%%     装备强化出的等级
%% @end
%% ----------------------------------------------------
-spec up_streng(Equipment, Role, Number, Max) -> {equipment:equipment(), role:role(), list()} when
    Equipment :: equipment:equipment(),
    Role :: role:role(),
    Number :: integer(),
    Max :: integer().
up_streng(Equipment, Role, Number, Max) ->
    up_streng_(Equipment, Role, Number, Max, []).
up_streng_(Equipment, Role, Number, Max, BiCs) when Number > 0 ->
    Streng = equipment:get_streng(Equipment),
    if
        Streng >= Max ->
            {Equipment, Role, BiCs};
        true ->
            {_, Conditions} = zm_config:get('equipment_up_streng', {equipment:get_quality(Equipment), Streng + 1}),
            case game_lib:checks({?MODULE, 'check'}, Role, 'up_streng', Conditions) of
                true ->
                    {CS, NRole} = game_lib:consumes({?MODULE, 'consume'}, Role, 'up_streng', Conditions),
                    up_streng_(equipment:set_streng(Equipment, Streng + 1),
                        NRole, Number - 1, Max, CS ++ BiCs);
                Err ->
                    throw(Err)
            end
    end;
up_streng_(Equipment, Role, _Number, _Max, Cs) ->
    {Equipment, Role, Cs}.
%%%===================LOCAL FUNCTIONS==================
