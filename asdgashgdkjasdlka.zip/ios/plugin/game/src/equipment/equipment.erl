-module(equipment).

%%%=======================STATEMENT====================
-description("装备").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_name/1, get_pos/1, get_streng/1, get_quality/1, get_condition/1, get_base_attrs/1]).
-export([set_streng/2]).

-export_type([equipment/0]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(equipment, {
    record_type :: atom(),
    name :: string(),%名称
    pos :: integer(),%类型部位 武器=1,头盔=2,战甲=3,靴子=4
    streng :: integer(),%强化等级
    quality :: integer(),%品质
    condition :: list(),%穿戴条件
    base_attrs :: list(),%装备基础属性
    info = [] :: list() %扩展
}).

%%%=======================TYPE=========================
-type equipment() :: #equipment{}.


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      获取名称
%% @end
%% ----------------------------------------------------
-spec get_name(equipment()) -> string().
get_name(#equipment{name = V}) -> game_lib:get_language_package(V).

%% ----------------------------------------------------
%% @doc
%%      获取类型部位
%% @end
%% ----------------------------------------------------
-spec get_pos(equipment()) -> integer().
get_pos(#equipment{pos = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      获取强化等级
%% @end
%% ----------------------------------------------------
-spec get_streng(equipment()) -> integer().
get_streng(#equipment{streng = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      获取品质
%% @end
%% ----------------------------------------------------
-spec get_quality(equipment()) -> integer().
get_quality(#equipment{quality = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      获取穿戴条件
%% @end
%% ----------------------------------------------------
-spec get_condition(equipment()) -> list().
get_condition(#equipment{condition = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      获取装备基础属性
%% @end
%% ----------------------------------------------------
-spec get_base_attrs(equipment()) -> list().
get_base_attrs(#equipment{base_attrs = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      设置强化等级
%% @end
%% ----------------------------------------------------
-spec set_streng(Equipment :: equipment(), Value :: integer()) -> equipment().
set_streng(Equipment, Value) -> Equipment#equipment{streng = Value}.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
