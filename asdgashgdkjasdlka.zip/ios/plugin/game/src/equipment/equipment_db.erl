-module(equipment_db).

%%%=======================STATEMENT====================
-description("装备db").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get/2, gets/2, off_equipment/3, put_equipment/3, up_streng/3, exchange_equipment/3,
    get_mount/2, gets_mount/2]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%     获取武将穿戴装备信息
%% @end
%% ----------------------------------------------------
-spec get(Src :: atom(), Uid :: integer()) -> tuple().
get(Src, Uid) ->
    z_db_lib:get(game_lib:get_table(Src, 'card_put_prop'), Uid, card_put_prop:init()).

%% ----------------------------------------------------
%% @doc
%%     获取武将穿戴装备信息
%% @end
%% ----------------------------------------------------
-spec gets(Src :: atom(), Uids :: [integer()]) -> [tuple()].
gets(Src, Uids) ->
    z_db_lib:gets(game_lib:get_table(Src, 'card_put_prop'), Uids, card_put_prop:init()).

%% ----------------------------------------------------
%% @doc
%%     获取坐骑穿戴装备信息
%% @end
%% ----------------------------------------------------
-spec get_mount(Src :: atom(), Uid :: integer()) -> tuple().
get_mount(Src, Uid) ->
    z_db_lib:get(game_lib:get_table(Src, 'mount_put_prop'), Uid, mount_put_prop:init()).

%% ----------------------------------------------------
%% @doc
%%     获取坐骑穿戴装备信息
%% @end
%% ----------------------------------------------------
-spec gets_mount(Src :: atom(), Uids :: [integer()]) -> [tuple()].
gets_mount(Src, Uids) ->
    z_db_lib:gets(game_lib:get_table(Src, 'mount_put_prop'), Uids, mount_put_prop:init()).

%% ----------------------------------------------------
%% @doc  
%%     脱装备
%% @end
%% ----------------------------------------------------
-spec off_equipment(term(), tuple(), list()) -> string()|tuple().
off_equipment(_, {Src, RoleUid, Index}, [{Index1, EStorage}, {Index2, CardPutProp}]) ->
    Equipments = card_put_prop:get_equipments(CardPutProp),
    case erlang:element(Index, Equipments) of
        0 ->
            throw("no_equipment");
        Equip ->
            {NEStorage, EquipLog, OverFlowProps} = equipment_lib:off_equipment(Src, RoleUid, EStorage, Equip),
            if
                length(OverFlowProps) > 0 ->
                    throw("storage_full");
                true ->
                    ok
            end,
            NCardPutProp = card_put_prop:set_equipments(CardPutProp, erlang:setelement(Index, Equipments, 0)),
            {ok, {EquipLog, CardPutProp, NCardPutProp}, [{Index1, NEStorage}, {Index2, NCardPutProp}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     穿装备
%% @end
%% ----------------------------------------------------
-spec put_equipment(term(), tuple(), list()) -> string()|tuple().
put_equipment(_, {_Src, Role, EquipUid, Card}, [{Index1, EStorage}, {Index2, CardPutProp}]) ->
    case storage_lib:find_by_uid(EStorage, EquipUid, 'encode') of
        EquipUid ->
            throw("no_equipment");
        {PropIndex, Prop} ->%%找到要上阵的装备
            Equipment = prop_kit_lib:get_prop_record(Prop),
            Index = equipment:get_pos(Equipment),%%不可装备相同类型的如两把武器
            case game_lib:checks({'equipment_lib', 'check'}, {Role, Card}, 'put_equipment', equipment:get_condition(Equipment)) of
                true ->
                    Equipments = card_put_prop:get_equipments(CardPutProp),
                    NEStorage = case erlang:element(Index, Equipments) of
                        0 ->%%这个位置没有上阵的装备
                            element(2, storage_lib:deduct_by_index(EStorage, PropIndex));
                        Equip ->%%找到这个位置已经上阵的装备
                            Uid = prop_kit_lib:get_prop_uid(Equip),
                            if
                                Uid =:= EquipUid ->
                                    throw("already_put_the_equipment");
                                true ->
                                    storage_lib:update_by_index(EStorage, PropIndex, Equip)
                            end
                    end,
                    %%新的装备上阵
                    NCardPutProp = card_put_prop:set_equipments(CardPutProp, erlang:setelement(Index, Equipments, Prop)),
                    {ok, {Prop, CardPutProp, NCardPutProp}, [{Index1, NEStorage}, {Index2, NCardPutProp}]};
                Err ->
                    throw(Err)
            end
    end.

%% ----------------------------------------------------
%% @doc
%%     装备强化
%% @end
%% ----------------------------------------------------
-spec up_streng(term(), tuple(), list()) -> string()|tuple().
up_streng(_, {_Src, EquipUid, _, Number}, [{Index1, Role}, {Index2, EStorage}]) ->
    case storage_lib:find_by_uid(EStorage, EquipUid) of
        EquipUid ->
            throw("no_equipment");
        {Index, Prop} ->
            Equipment = prop_kit_lib:get_prop_record(Prop),
            NMax = equipment_lib:get_up_max(Role, Equipment),
            Bool = equipment:get_streng(Equipment) >= NMax,
            if
                Bool ->
                    throw("equipment_already_max");
                true ->
                    {NEquipment, NRole, BiCS} = equipment_lib:up_streng(Equipment, Role, Number, NMax),
                    NProp = prop_kit_lib:set_prop_record(Prop, NEquipment),
                    NEStorage = storage_lib:update_by_index(EStorage, Index, NProp),
                    {ok, {prop_kit_lib:get_prop_sid(Prop), Equipment, NEquipment, BiCS, 0},
                        [{Index1, NRole}, {Index2, NEStorage}]}
            end
    end;
up_streng(_, {_Src, EquipUid, CardUid, Number}, [{Index1, Role}, {_Index2, CardStorage}, {Index3, CardPutProp}]) ->
    case storage_lib:find_by_uid(CardStorage, CardUid) of
        CardUid ->
            throw("no_card");
        {_, CardProp} ->
            Equipments = card_put_prop:get_equipments(CardPutProp),
            F = fun
                (A, _N, 0) ->
                    {'ok', A};
                (A, N, EProp) ->
                    case prop_kit_lib:get_prop_uid(EProp) =:= EquipUid of
                        true ->
                            {'break', {N, EProp}};
                        false ->
                            {'ok', A}
                    end
            end,
            case z_lib:tuple_foreach(Equipments, F, 'none') of
                'none' ->
                    throw("no_equipment");
                {Index, Prop} ->
                    Equipment = prop_kit_lib:get_prop_record(Prop),
                    NMax = equipment_lib:get_up_max(Role, Equipment),
                    Bool = equipment:get_streng(Equipment) >= NMax,
                    if
                        Bool ->
                            throw("equipment_already_max");
                        true ->
                            Card = prop_kit_lib:get_prop_record(CardProp),
                            {NEquipment, NRole, BiCS} = equipment_lib:up_streng(Equipment, Role, Number, NMax),
                            NProp = prop_kit_lib:set_prop_record(Prop, NEquipment),
                            NEquipments = erlang:setelement(Index, Equipments, NProp),
                            {ok, {prop_kit_lib:get_prop_sid(Prop), Equipment, NEquipment, BiCS, card:get_state(Card)},
                                [{Index1, NRole}, {Index3, card_put_prop:set_equipments(CardPutProp, NEquipments)}]}
                    end
            end
    end.

%% ----------------------------------------------------
%% @doc
%%     装备交换
%% @end
%% ----------------------------------------------------
-spec exchange_equipment(term(), tuple(), list()) -> string()|tuple().
exchange_equipment(_, {CardUid, TargetCardUid}, [{_, CardStorage}, {Index2, CardPutProp}, {Index3, TargetCardPutProp}]) ->
    Props = storage_lib:find_by_uid(CardStorage, [CardUid, TargetCardUid]),
    F = fun(Args, {_, Prop}) ->
        Card = prop_kit_lib:get_prop_record(Prop),
        NArgs = case card:get_state(Card) of
            0 ->
                Args;
            GId ->
                [GId | Args]
        end,
        {'ok', NArgs};
        (_, _) ->
            throw("no_card")
    end,
    GIds = z_lib:foreach(F, [], Props),
    {ok, {'ok', GIds}, [{Index2, TargetCardPutProp}, {Index3, CardPutProp}]}.

%%%===================LOCAL FUNCTIONS==================

