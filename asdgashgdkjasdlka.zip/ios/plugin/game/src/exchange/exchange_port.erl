-module(exchange_port).

%%%=======================STATEMENT====================
-description("兑换,合成端口").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([exchange/5]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%      兑换,合成(合成装备等)
%% @end
%% ----------------------------------------------------
-spec exchange(list(), term(), term(), term(), term()) -> tuple().
exchange([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    Sid = list_to_integer(z_lib:get_value(Msg, "sid", "0")),
    case zm_config:get('exchange_info', Sid) of
        none ->
            {ok, [], Info, [{msg, "input_error"}]};
        {_, Award, Consumes} ->
            TableName = game_lib:get_table(Src),
            {Key, Tables} = exchange_lib:get_tables(RoleUid, Consumes),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{role, RoleUid} | Tables]),
            Reply = case z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, Consumes, Key}, TableKeys) of
                {ok, BiCs} ->
                    AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, Award),
                    %% 兑换日志
                    zm_log:info(Src, ?MODULE, 'exchange', "exchange", [{'roleuid', RoleUid}, {'sid', Sid},
                        {'consume', BiCs}, {'award', AwardLog}]),
                    %% 兑换事件触发
                    zm_event:notify(Src, 'exchange', [{'role_uid', RoleUid}, {'sid', Sid}, {'consume', BiCs},
                        {'award', AwardLog}]),
                    zm_event:notify(Src, 'broadcast', {'compound', [{'role_uid', RoleUid}, {'award', AwardLog}]}),
                    AwardLog;
                Err ->
                    Err
            end,
            {ok, [], Info, [{msg, Reply}]}
    end.


%%%===================LOCAL FUNCTIONS==================
