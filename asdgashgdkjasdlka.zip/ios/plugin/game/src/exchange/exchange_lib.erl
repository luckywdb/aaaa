-module(exchange_lib).

%%%=======================STATEMENT====================
-description("兑换,合成工具").
-copyright('youkia,www.youkia.net').
-author("yhr,yuanhairong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([check/3, consume/3, get_tables/2]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%     检测兑换,合成是否满足条件
%% @end
%% ----------------------------------------------------
-spec check(tuple(), term(), tuple()) -> boolean().
check({Role, _List}, 'exchange', {'money', Value}) ->
    role:get_money(Role) >= Value;
check({_Role, List}, 'exchange', {'prop', {Sid, Value}}) ->
    Type = prop_kit_lib:get_prop_type(prop_kit_lib:get_prop(Sid)),
    {_, {_, Storage}} = lists:keyfind(Type, 1, List),
    storage_lib:exist_by_sid(Storage, {Sid, Value});
check(_, _, _) ->
    false.

%%-------------------------------------------------------------------
%% @doc
%%      消耗
%% @end
%%-------------------------------------------------------------------
-spec consume(tuple(), term(), term()) -> {term(), term()}.
consume({Role, List}, 'exchange', {'money', Num}) ->
    {Cs, NRole} = role_lib:deduct_money(Role, Num),
    {Cs, {NRole, List}};
consume({Role, List}, 'exchange', {'prop', {Sid, Value}}) ->
    Type = prop_kit_lib:get_prop_type(prop_kit_lib:get_prop(Sid)),
    {_, {Index, Storage}} = lists:keyfind(Type, 1, List),
    {Cs, NStorage} = storage_lib:deduct_by_sid(Storage, {Sid, Value}),
    {Cs, {Role, lists:keyreplace(Type, 1, List, {Type, {Index, NStorage}})}};
consume(Tables, _, _) ->
    {'none', Tables}.

%% ----------------------------------------------------
%% @doc
%%      获取包裹类型
%% @end
%% ----------------------------------------------------
%{[a],[{a,1},{b,2}]}
get_tables(RoleUid, Consumes) ->
    List = get_table(Consumes, []),
    {List, [{X, RoleUid, {}} || X <- List]}.

get_table([{prop, {Sid, _Value}} | T], Acc0) ->
    Type = prop_kit_lib:get_prop_type(prop_kit_lib:get_prop(Sid)),
    NAcc0 = case lists:member(Type, Acc0) of
        true -> Acc0;
        false -> [Type | Acc0]
    end,
    get_table(T, NAcc0);
get_table([_Item | T], Acc0) ->
    get_table(T, Acc0);
get_table([], Acc0) ->
    Acc0.
%%%===================LOCAL FUNCTIONS==================