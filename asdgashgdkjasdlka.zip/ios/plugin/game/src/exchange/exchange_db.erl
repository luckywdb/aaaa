-module(exchange_db).

%%%=======================STATEMENT====================
-description("兑换,合成工具").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([exchange/3]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%     检测兑换,合成是否满足条件
%% @end
%% ----------------------------------------------------
-spec exchange(list(), tuple(), list()) -> tuple().
exchange(_, {_Src, _RoleUid, Consumes, Key}, [{Index1, Role} | List]) ->
    NList = lists:zip(Key, List),
    case game_lib:checks({exchange_lib, check}, {Role, NList}, 'exchange', Consumes) of
        true ->
            {Cs, {NRole, KList}} = game_lib:consumes({'exchange_lib', 'consume'}, {Role, NList}, 'exchange', Consumes),
            {_, FList} = lists:unzip(KList),
            {ok, {ok, Cs}, [{Index1, NRole} | FList]};
        Err ->
            throw(Err)
    end.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------

