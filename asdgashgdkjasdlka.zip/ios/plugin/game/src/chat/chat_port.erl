%%聊天系统通讯端口
-module(chat_port).
-description("chat_port").
-copyright({seasky, 'www.seasky.cn'}).
-author({wkl, 'wangkeli@youkia.net'}).
-vsn(1).
%%%=======================EXPORT=======================
-export([chat/5, get_chat_info/5, add_chat_blanck/5, delete_chat_blanck/5, get_chat_blanck/5]).
%%%=======================INCLUDE======================
-include("../include/chat.hrl").
-include("../include/role.hrl").

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      聊天
%% @end
%% ----------------------------------------------------
chat([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    Time = time_lib:now_second(),
    case chat_db:check_shutup(Src, RoleUid) of
        false ->
            Channel = z_lib:get_value(Msg, "channel", 0),
            GUser = user_db:get_user(Src, RoleUid),
            DeviceId = guser:get_device_id(GUser),
            Username = element(3, user_db:get_user_name(Src, RoleUid)),
            case chat_db:check_chat_alone(Src, DeviceId, Username) =:= 1 of
                true ->
                    {ok, [], Info, [{msg, Channel}]};
                false ->
                    Content = z_lib:get_value(Msg, "str", none),
                    case string_lib:check_str(Src, Content) of
                        false ->
                            %%非屏蔽字
                            RoleShow = role_db:get_role_show(Src, RoleUid),
                            TargetUid = chat_lib:get_uid(Src, RoleUid, Msg, Channel),
                            {_, Conditions, ConsumeList} = zm_config:get('chat_info', Channel),
                            Reply = case chat_lib:limit_check(Src, RoleUid, Content, Channel, Conditions) of
                                true ->
                                    case (Channel =:= ?CORPS andalso role_show:get_corps_uid(RoleShow) =:= 0) orelse
                                        (Channel =:= ?COUNTRY andalso role_show:get_country(RoleShow) =:= 0) orelse
                                        (Channel =:= ?PRIVATE andalso (RoleUid =:= TargetUid orelse TargetUid =< 0 orelse role_db:get_role_show(Src, TargetUid) =:= 'none')) of
                                        true ->
                                            "no_chat";
                                        false ->
                                            TableName = game_lib:get_table(Src),
                                            TableKeys = chat_lib:get_table_keys(TableName, RoleUid, TargetUid, Channel),
                                            case z_db_lib:handle(TableName, {M, F, A}, {Channel, Src, RoleUid, TargetUid, Time, Content, ConsumeList}, TableKeys) of
                                                {Channel, SkinSid, Cs} ->
                                                    if
                                                        Cs =/= [] ->
                                                            zm_event:notify(Src, 'bi_world_chat', [{'role_uid', RoleUid}, {'consume', Cs}]);
                                                        true ->
                                                            ok
                                                    end,
                                                    RoleLv = role_show:get_level(RoleShow),
                                                    if
                                                        Channel =:= ?PRIVATE ->
                                                            RoleName = role_show:get_name(RoleShow),
                                                            ChatContent = {Channel, RoleUid, role_show:get_style(RoleShow), RoleName, role_show:get_country(RoleShow), role_show:get_corps_uid(RoleShow),
                                                                role_show:get_corps_name(RoleShow), RoleLv, role_show:get_vip_level(RoleShow), Time, Content, SkinSid},
                                                            set_front_lib:set_chat(Src, [TargetUid], 0, {ChatContent});
                                                        true ->
                                                            {ChannelName, ChannelUid} = if
                                                                Channel =:= ?CORPS ->
                                                                    CorpsUid = role_show:get_corps_uid(RoleShow),
                                                                    {?SCORPS, CorpsUid};
                                                                Channel =:= ?COUNTRY ->
                                                                    Country = role_show:get_country(RoleShow),
                                                                    {?SCOUNTRY, Country};
                                                                Channel =:= ?CROSS ->
                                                                    {?SCROSS, role_lib:get_mapid(Attr)};
                                                                true ->
                                                                    {?SWORLD, 0}
                                                            end,
                                                            RoleName = role_show:get_name(RoleShow),
                                                            ChatContent = {Channel, RoleUid, role_show:get_style(RoleShow), RoleName, role_show:get_country(RoleShow), role_show:get_corps_uid(RoleShow),
                                                                role_show:get_corps_name(RoleShow), RoleLv, role_show:get_vip_level(RoleShow), Time, Content, SkinSid},
                                                            if
                                                                Channel =:= ?WORLD ->
                                                                    chat_server:send(Src, ChannelName, ChatContent);
                                                                true ->
                                                                    chat_server:send(Src, ChannelName, ChannelUid, ChatContent)
                                                            end
                                                    end,
                                                    MonitorChat = {integer_to_list(RoleUid), RoleName, Content, RoleLv, DeviceId},
                                                    monitor_lib:set_chat(Src, RoleUid, Username, Channel, MonitorChat),
                                                    Channel;
                                                Other ->
                                                    Other
                                            end
                                    end;
                                Error ->
                                    Error
                            end,
                            {ok, [], Info, [{msg, Reply}]};
                        _ ->
                            {'ok', [], Info, [{'msg', "have_mask_word"}]}
                    end
            end;
        true ->
            {ok, [], Info, [{msg, "shutup"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      获取聊天信息
%% @end
%% ----------------------------------------------------
get_chat_info(_, _, Attr, Info, _) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    Reply = chat_db:get_chat_info(Src, RoleUid, role_lib:get_mapid(Attr)),
    Country = role_lib:get_country(Attr),
    monarch_lib:king_online_chat_notify(Src, RoleUid, Country),
    {ok, [], Info, [{msg, Reply}]}.

%% ----------------------------------------------------
%% @doc
%%      删除黑名单
%% @end
%% ----------------------------------------------------
add_chat_blanck(_, _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    RUid = list_to_integer(z_lib:get_value(Msg, "uid", "0")),
    CheckVaild = valid_lib:check_valib([{'gt', RUid, 0}, {'unequal', RUid, RoleUid}]),
    if
        CheckVaild ->
            {ok, [], Info, [{msg, chat_db:add_chat_blanck(Src, RoleUid, RUid)}]};
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      添加黑名单
%% @end
%% ----------------------------------------------------
delete_chat_blanck(_, _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    RUid = list_to_integer(z_lib:get_value(Msg, "uid", "0")),
    CheckVaild = valid_lib:check_valib([{'gt', RUid, 0}]),
    if
        CheckVaild ->
            {ok, [], Info, [{msg, chat_db:delete_chat_blanck(Src, RoleUid, RUid)}]};
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      获取黑名单
%% @end
%% ----------------------------------------------------
get_chat_blanck(_, _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    BlanckList = lists:map(fun(RUid) ->
        RoleShow = role_db:get_role_show(Src, RUid),
        Style = role_show:get_style(RoleShow),
        RoleName = role_show:get_name(RoleShow),
        Country = role_show:get_country(RoleShow),
        CorpsUid = role_show:get_corps_uid(RoleShow),
        CorpsName = role_show:get_corps_name(RoleShow),
        Official = official_db:get_official(Src, RUid),
        {RUid, RoleName, Style, Country, CorpsUid, CorpsName, official:get_oid(Official), role_show:get_vip_level(RoleShow)}
    end, chat_db:get_chat_blanck_list(Src, RoleUid)),
    {ok, [], Info, [{msg, list_to_tuple(BlanckList)}]}.