-module(chat_event).

%%%=======================STATEMENT====================
-description("chat_event").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([notify/4]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        
%% @end
%% ----------------------------------------------------
notify(_, Src, 'chat_delete_private', Args) ->
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, RUids} = lists:keyfind('ruids', 1, Args),
    Fun = fun(_, {PrivateUids, BlanckList}) ->
        {ok, ok, {PrivateUids -- RUids, BlanckList}}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'chat_uids'), RoleUid, {[], []}, Fun, []),
    PTableName = game_lib:get_table(Src, 'private_record'),
    lists:foreach(fun(RUid) ->
        Key = chat_lib:get_private_chat_key(RoleUid, RUid),
        z_db_lib:delete(PTableName, Key)
    end, RUids).
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
