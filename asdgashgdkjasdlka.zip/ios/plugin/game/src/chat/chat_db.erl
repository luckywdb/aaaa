%%聊天系统数据逻辑操作
-module(chat_db).
-description("chat_db").
-copyright({seasky, 'www.seasky.cn'}).
-author({wkl, 'wangkeli@youkia.net'}).
-vsn(1).
%%%=======================EXPORT=======================
-export([chat/3, get_chat_info/3, get_chat_blanck_list/2, add_chat_blanck/3, delete_chat_blanck/3]).
-export([add_shutup/3, del_shutup/2, check_shutup/2, add_chat_alone/2, del_chat_alone/3, check_chat_alone/3]).
%%%=======================INCLUDE======================
-include("../include/chat.hrl").
%%%=======================DEFINE======================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      聊天，发送消息 Type(?ROLE)=1玩家2gm,Channel=频道:1世界,2私聊,3军团,4国家,5,收费,Content=内容,CD=[{类型,时间}],Time=当前时间（秒）
%% @end
%% ----------------------------------------------------
-spec chat(_, {Type, Src, RoleUid, TargetUid, Time, Content, ConsumeList}, TableKeys) ->
    string()|{'ok', Reply, list()} when
    Type :: integer(),
    Src :: atom(),
    RoleUid :: integer(),
    TargetUid :: integer(),
    Time :: integer(),
    Content :: string(),
    ConsumeList :: list(),
    TableKeys :: list(),
    Reply :: integer()|{integer(), list()}|'ok'.
chat(_, {Type, Src, RoleUid, _TargetUid, Time, _Content, ConsumeList}, [{Index1, ChatCD}, {Index2, TimeSet}, {Index3, Rmb}])
    when Type =:= ?WORLD;Type =:= ?CORPS;Type =:= ?COUNTRY;Type =:= ?CROSS ->%% 世界,国家,军团频道
    case chat_lib:check_time(ChatCD, Type) of
        false ->
            throw("chat_channel_cd");
        true ->
            {Res1, TimeSet1} = case time_refresh_lib:check(TimeSet, 'chat', {'time', Type}) of
                {true, NowTime} ->
                    {ok, times_set_lib:update(TimeSet, {{'time', Type}, NowTime, 1})};
                {false, _} ->
                    {_, OldTime, Count} = times_set_lib:get(TimeSet, {'time', Type}),
                    MaxCount = z_lib:get_value(?MAX_CHAT, Type, 999),
                    if
                        Count >= MaxCount ->
                            throw("chat_max_times");
                        true ->
                            Res = if
                                Type =:= ?WORLD ->
                                    chat_lib:check(Src, RoleUid, Count, Rmb, ConsumeList);
                                true ->
                                    ok
                            end,
                            {Res, times_set_lib:update(TimeSet, {{'time', Type}, OldTime, 1})}
                    end
            end,
            ChatSkin3 = z_lib:get_value(ChatCD, 'skin', 0),
            {Cs, NRmb} = case Res1 of
                ok ->
                    {[], Rmb};
                {ok, {Cs1, NRmb1}} ->
                    {Cs1, NRmb1}
            end,
            {ok, {Type, ChatSkin3, Cs}, [{Index1, chat_lib:set_cd(ChatCD, Type, Time)}, {Index2, TimeSet1}, {Index3, NRmb}]}
    end;
chat(_, {Type, _Src, RoleUid, RUid, Time, Content, _ConsumeList}, [{Index1, ChatCD}, {Index2, {PrivateUids1, BlanckList1}}, {Index3, {PrivateUids2, BlanckList2}}, {Index4, {_, PrivateRecords}}])
    when Type =:= ?PRIVATE ->%% 私聊
    case chat_lib:check_time(ChatCD, Type) of
        false ->
            throw("chat_channel_cd");
        true ->
            case lists:member(RUid, BlanckList1) of
                true ->
                    throw("chat_role_in_blanck");
                false ->
                    NPrivateUids1 =
                        case lists:member(RUid, PrivateUids1) of
                            true ->
                                PrivateUids1;
                            false ->
                                [RUid | PrivateUids1]
                        end,
                    NPrivateUids2 =
                        case lists:member(RoleUid, PrivateUids2) orelse lists:member(RoleUid, BlanckList2) of
                            true ->
                                PrivateUids2;
                            false ->
                                [RoleUid | PrivateUids2]
                        end,
                    ChatSkin3 = z_lib:get_value(ChatCD, 'skin', 0),
                    NPrivateRecords = lists:sublist([{RoleUid, Time, Content, ChatSkin3} | PrivateRecords], 20),
                    {ok, {Type, ChatSkin3, []}, [{Index1, chat_lib:set_cd(ChatCD, Type, Time)},
                        {Index2, {NPrivateUids1, BlanckList1}},
                        {Index3, {NPrivateUids2, BlanckList2}},
                        {Index4, {Time, NPrivateRecords}}]}
            end
    end.


%% ----------------------------------------------------
%% @doc
%%      获取最近聊天信息
%% @end
%% ----------------------------------------------------
get_chat_info(Src, RoleUid, MapId) ->
    %% 检查并更新聊天次数
%%    Fun = fun(_, TimeSet) ->
%%        F = fun({Args, NTimeSet}, {Type, MaxCount}) ->
%%            case time_refresh_lib:check(TimeSet, 'chat', {'time', Type}) of
%%                {true, NowTime} ->
%%                    {ok, {[{Type, MaxCount} | Args], times_set_lib:update(NTimeSet, {{'time', Type}, NowTime, 0})}};
%%                {false, _} ->
%%                    {_, _, Count} = times_set_lib:get(TimeSet, {'time', Type}),
%%                    {ok, {[{Type, MaxCount - Count} | Args], NTimeSet}}
%%            end
%%        end,
%%        {RTimes, RTimeSet} = z_lib:foreach(F, {[], TimeSet}, ?MAX_CHAT),
%%        {'ok', RTimes, RTimeSet}
%%    end,
%%    RTimes = z_db_lib:update(game_lib:get_table(Src, 'chat'), {times, RoleUid}, [], Fun, 0),
    %%聊天次数
    Fun1 = fun({{time, Type}, _Time, Times}) ->
        {Type, Times}
    end,
    RTimes = lists:map(Fun1, z_db_lib:get(game_lib:get_table(Src, 'chat'), {times, RoleUid}, chat_lib:chat_times_init())),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    %% 世界频道信息
    WorldChat =
        if
            MapId > 0 ->
                chat_server:recently_msg(?SCROSS, MapId);
            true ->
                chat_server:recently_msg(?SWORLD)
        end,
    %% 军团频道信息
    CorpsUid = role_show:get_corps_uid(RoleShow),
    CorpsChat =
        if
            CorpsUid =:= 0 ->
                {};
            true ->
                chat_server:recently_msg(?SCORPS, CorpsUid)
        end,
    %% 国家频道信息
    CountryChat = chat_server:recently_msg(?SCOUNTRY, role_show:get_country(RoleShow)),
    %% 私聊信息和黑名单列表
    {PrivateRUids1, BlanckList} = z_db_lib:get(game_lib:get_table(Src, 'chat_uids'), RoleUid, {[], []}),
    PrivateRUids = lists:sublist(PrivateRUids1, 5),
    PrivateKeys = [chat_lib:get_private_chat_key(RoleUid, RUid) || RUid <- PrivateRUids],
    PrivateChatList =
        if
            PrivateKeys =/= [] ->
                PrivateRecordsList = z_db_lib:gets(game_lib:get_table(Src, 'private_record'), PrivateKeys, {0, []}),
                Sec = time_lib:now_second() - ?PRIVATE_CHAT_TIMEOUT,
                {RemoveRUids, PRecords} = lists:foldl(fun({RUid, {LastUpdateTime, PrivateRecords}}, {Acc1, Acc2}) ->
                    if
                        LastUpdateTime > Sec ->
                            RShow = role_db:get_role_show(Src, RUid),
                            Style = role_show:get_style(RShow),
                            RoleName = role_show:get_name(RShow),
                            Country = role_show:get_country(RShow),
                            CUid = role_show:get_corps_uid(RShow),
                            CName = role_show:get_corps_name(RShow),
                            RoleLevel = role_show:get_level(RShow),
                            VipLevel = role_show:get_vip_level(RShow),
                            {Acc1, [{RUid, Style, RoleName, Country, CUid, CName, RoleLevel, VipLevel, list_to_tuple(PrivateRecords)} | Acc2]};
                        true ->
                            {[RUid | Acc1], Acc2}
                    end
                end, {[], []}, lists:zip(PrivateRUids, PrivateRecordsList)),
                if
                    RemoveRUids =/= [] ->
                        zm_event:notify(Src, 'chat_delete_private', [{'role_uid', RoleUid}, {'ruids', RemoveRUids}]);
                    true ->
                        ok
                end,
                lists:reverse(PRecords);
            true ->
                []
        end,
    %获取聊天皮肤
    ChatCD = z_db_lib:get(game_lib:get_table(Src, 'chat'), RoleUid, []),
    ChatSkin2 = z_lib:get_value(ChatCD, 'skin', 0),
    Username = element(3, user_db:get_user_name(Src, RoleUid)),
    ChatAloneType = chat_db:check_chat_alone(Src, guser:get_device_id(user_db:get_user(Src, RoleUid)), Username),%%获得是否是单机发言的状态，0表示没有被禁言，1表示被禁言
    {list_to_tuple(RTimes), WorldChat, CorpsChat, CountryChat, list_to_tuple(PrivateChatList), list_to_tuple(BlanckList), ChatSkin2, ChatAloneType}.


%%-------------------------------------------------------------------
%% @doc
%%      禁言
%% @end
%%-------------------------------------------------------------------
-spec add_shutup(atom(), integer(), integer()) -> ok.
add_shutup(Src, RoleUid, EndTime) ->
    Fun = fun(_, _) ->
        {ok, ok, EndTime}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'chat'), {'shutup', RoleUid}, 0, Fun, []).

%%-------------------------------------------------------------------
%% @doc
%%      解除禁言
%% @end
%%-------------------------------------------------------------------
-spec del_shutup(atom(), integer()) -> ok.
del_shutup(Src, RoleUid) ->
    z_db_lib:delete(game_lib:get_table(Src, 'chat'), {'shutup', RoleUid}).

%%-------------------------------------------------------------------
%% @doc
%%      检测禁言
%% @end
%%-------------------------------------------------------------------
-spec check_shutup(atom(), integer()) -> boolean().
check_shutup(Src, RoleUid) ->
    EndTime = z_db_lib:get(game_lib:get_table(Src, 'chat'), {'shutup', RoleUid}, 0),
    time_lib:now_second() =< EndTime.


%% ----------------------------------------------------
%% @doc
%%      获取聊天黑名单列表
%% @end
%% ----------------------------------------------------
-spec get_chat_blanck_list(Src :: atom(), RoleUid :: integer()) -> [integer()].
get_chat_blanck_list(Src, RoleUid) ->
    {_, BlanckList} = z_db_lib:get(game_lib:get_table(Src, 'chat_uids'), RoleUid, {[], []}),
    BlanckList.

%% ----------------------------------------------------
%% @doc
%%      删除黑名单
%% @end
%% ----------------------------------------------------
-spec add_chat_blanck(Src :: atom(), RoleUid :: integer(), RUid :: integer()) -> 'ok'.
add_chat_blanck(Src, RoleUid, RUid) ->
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'chat_uids', RoleUid, {[], []}},
        {'chat_uids', RUid, {[], []}},
        {'private_record', chat_lib:get_private_chat_key(RoleUid, RUid), {0, []}}
    ]),
    Fun = fun(_, [{Index1, {PrivateUids1, BlanckList1}}, {_Index2, {PrivateUids2, _BlanckList2}}, {Index3, _}]) ->
        case lists:member(RUid, BlanckList1) of
            true ->
                {ok, ok};
            false ->
                NBlanckList1 = [RUid | BlanckList1],
                NPrivateUids1 = lists:delete(RUid, PrivateUids1),
                case lists:member(RoleUid, PrivateUids2) of
                    true ->
                        {ok, ok, [{Index1, {NPrivateUids1, NBlanckList1}}]};
                    false ->
                        {ok, ok, [{Index1, {NPrivateUids1, NBlanckList1}}, {Index3, 'delete'}]}
                end
        end
    end,
    z_db_lib:handle(TableName, Fun, [], TableKeys).

%% ----------------------------------------------------
%% @doc
%%      添加黑名单
%% @end
%% ----------------------------------------------------
-spec delete_chat_blanck(Src :: atom(), RoleUid :: integer(), RUid :: integer()) -> 'ok'.
delete_chat_blanck(Src, RoleUid, RUid) ->
    Fun = fun(_, {PrivateUids, BlanckList}) ->
        {ok, ok, {PrivateUids, lists:delete(RUid, BlanckList)}}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'chat_uids'), RoleUid, {[], []}, Fun, []).

%%-------------------------------------------------------------------
%% @doc
%%      单机发言
%% @end
%%-------------------------------------------------------------------
add_chat_alone(Src, UserId) ->
    case z_db_lib:get(game_lib:get_table(Src, 'chat'), UserId, 'none') of
        'none' ->
            z_db_lib:update(game_lib:get_table(Src, 'chat'), UserId, 0);
        _ ->
            'ok'
    end.

%%-------------------------------------------------------------------
%% @doc
%%      解除单机发言
%% @end
%%-------------------------------------------------------------------
del_chat_alone(Src, DeviceId, UserId) ->
    z_db_lib:delete(game_lib:get_table(Src, 'chat'), DeviceId),
    z_db_lib:delete(game_lib:get_table(Src, 'chat'), UserId).

%%-------------------------------------------------------------------
%% @doc
%%      检测禁言,0表示没有被禁言，1表示被禁言
%% @end
%%-------------------------------------------------------------------
check_chat_alone(Src, DeviceId, UserId) ->
    case z_db_lib:get(game_lib:get_table(Src, 'chat'), UserId, 'none') of
        'none' ->
            case z_db_lib:get(game_lib:get_table(Src, 'chat'), DeviceId, 'none') of
                'none' ->
                    0;
                _ ->
                    1
            end;
        _ ->
            1
    end.

%%%===================LOCAL FUNCTIONS 模块内部调用==================
%% ----------------------------------------------------
%% @doc
%%      获得在线玩家session
%% @end
%% ----------------------------------------------------
%% get_receiver(Src, _RoleUid, _Target, ?WORLD) ->
%%     login_db:get_all_online_uid(Src);
%% %%获得好友session
%% get_receiver(Src, _RoleUid, FriendUid, ?PRIVATE) ->
%%     case FriendUid of
%%         0 ->
%%             0;
%%         _ ->
%%             case login_db:get_online(Src, FriendUid) of%%对方是否在线
%%                 none ->%%不在线
%%                     1;
%%                 _ ->%%在线
%%                     [FriendUid]
%%             end
%%     end.

