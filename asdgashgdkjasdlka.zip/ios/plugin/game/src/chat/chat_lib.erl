%%聊天系统数据处理
-module(chat_lib).
-description("chat_lib").
-copyright({seasky, 'www.seasky.cn'}).
-author({wkl, 'wangkeli@youkia.net'}).
-vsn(1).
%%%=======================EXPORT=======================
-export([get_private_chat_key/2, send_msg/4, get_uid/4, get_table_keys/4, set_cd/3, check_time/2, limit_check/5]).
-export([notice_world/3, notice_country/4, notice_corps/4, notice_mapid/4]).
-export([check/5, chat_times_init/0]).
%%%=======================INCLUDE======================
-include("../include/chat.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      获取私聊key
%% @end
%% ----------------------------------------------------
-spec get_private_chat_key(RoleUid1 :: integer(), RoleUid2 :: integer()) -> {integer(), integer()}.
get_private_chat_key(RoleUid1, RoleUid2) when RoleUid1 > RoleUid2 ->
    {RoleUid1, RoleUid2};
get_private_chat_key(RoleUid1, RoleUid2) ->
    {RoleUid2, RoleUid1}.

%% ----------------------------------------------------
%% @doc
%%      根据类型获取对应目标uid
%% @end
%% ----------------------------------------------------
-spec get_uid(_, _, Msg, Type) -> integer() when
    Msg :: list(),
    Type :: integer().
get_uid(_Src, _RoleUid, Msg, ?PRIVATE) ->
    case z_lib:get_value(Msg, "uid", "0") of
        [] ->
            0;
        Uid ->
            list_to_integer(Uid)
    end;
get_uid(_, _, _, _) ->
    0.

%% ----------------------------------------------------
%% @doc
%%      根据类型获取要修改的表
%% @end
%% ----------------------------------------------------
-spec get_table_keys(TableName, RoleUid, Uid, Type) -> tuple() when
    TableName :: atom(),
    RoleUid :: integer(),
    Uid :: integer(),
    Type :: integer().
get_table_keys(TableName, RoleUid, _Uid, Type) when Type =:= ?WORLD;Type =:= ?CORPS;Type =:= ?COUNTRY;Type =:= ?CROSS ->
    z_db_lib:transformation_tablekey(TableName, [{'chat', RoleUid, []},
        {'chat', {times, RoleUid}, []}, {'rmb', RoleUid, rmb_lib:init()}]);
get_table_keys(TableName, RoleUid, Uid, Type) when Type =:= ?PRIVATE ->
    z_db_lib:transformation_tablekey(TableName, [
        {'chat', RoleUid, []},
        {'chat_uids', RoleUid, {[], []}},
        {'chat_uids', Uid, {[], []}},
        {'private_record', get_private_chat_key(RoleUid, Uid), {0, []}}
    ]).

%% ----------------------------------------------------
%% @doc
%%      根据类型设置cd时间
%% @end
%% ----------------------------------------------------
-spec set_cd(CD, Type, Time) -> list() when
    CD :: list(),
    Type :: integer(),
    Time :: integer().
set_cd(CD, Type, Time) ->
    lists:keystore(Type, 1, CD, {Type, Time}).

%% ----------------------------------------------------
%% @doc
%%      能否发言,CD=[{type,lasttime}]*,true冷却，可以发言
%% @end
%% ----------------------------------------------------
-spec check_time(CD, Type) -> boolean() when
    CD :: list(),
    Type :: integer().
check_time(CD, Type) ->
    LastTime = z_lib:get_value(CD, Type, 0),
    CDTime = z_lib:get_value(?TYPE_CD, Type, 0),
    LastTime + CDTime =< time_lib:now_second().

%% ----------------------------------------------------
%% @doc
%%      聊天消息基础条件检查
%% @end
%% ----------------------------------------------------
-spec limit_check(Src, RoleUid, Content, Channel, Conditions) -> string()|true when
    Src :: atom(),
    RoleUid :: integer(),
    Content :: string(),
    Channel :: integer(),
    Conditions :: list().
limit_check(Src, RoleUid, Content, Channel, Conditions) ->
    case limit_check(Src, RoleUid, Content, Conditions) of
        true ->
            true;
        Err ->
            Err ++ "_" ++ integer_to_list(Channel)
    end.
limit_check(Src, RoleUid, Content, [H | T]) ->
    case check(Src, RoleUid, Content, H) of
        false ->
            string_lib:to_string(element(1, H));
        _ ->
            limit_check(Src, RoleUid, Content, T)
    end;
limit_check(_Src, _RoleUid, _Content, []) ->
    true.

%% ----------------------------------------------------
%% @doc
%%      GM发送公告_世界频道
%% @end
%% ----------------------------------------------------
-spec notice_world(Src, CfgName, Args) -> none | ok | string() when
    Src :: atom(),
    CfgName :: atom()|{atom(), integer()},
    Args :: list().
notice_world(Src, CfgName, Args) ->
    Time = time_lib:now_second(),
    Content = game_lib:get_language(CfgName, Args),
    ChatContent = {?WORLD, -1, 0, 0, 0, 0, 0, 0, 0, Time, Content, 0},
    chat_server:send(Src, ?SWORLD, ChatContent).

%% ----------------------------------------------------
%% @doc
%%      GM发送公告_国家频道
%% @end
%% ----------------------------------------------------
-spec notice_country(Src, CfgName, Args, Country) -> none | ok | string() when
    Src :: atom(),
    CfgName :: atom(),
    Args :: list(),
    Country :: integer().
notice_country(Src, CfgName, Args, Country) ->
    Time = time_lib:now_second(),
    Channel = ?COUNTRY,
    Content = game_lib:get_language(CfgName, Args),
    ChatContent = {Channel, -1, 0, 0, Country, 0, 0, 0, 0, Time, Content, 0},
    chat_server:send(Src, ?SCOUNTRY, Country, ChatContent).

%% ----------------------------------------------------
%% @doc
%%      GM发送公告_军团频道
%% @end
%% ----------------------------------------------------
-spec notice_corps(Src, CfgName, Args, CorpsUid) -> none | ok | string() when
    Src :: atom(),
    CfgName :: atom(),
    Args :: list(),
    CorpsUid :: integer().
notice_corps(Src, CfgName, Args, CorpsUid) ->
    Time = time_lib:now_second(),
    Channel = ?CORPS,
    Content = game_lib:get_language(CfgName, Args),
    ChatContent = {Channel, -1, 0, 0, 0, CorpsUid, 0, 0, 0, Time, Content, 0},
    chat_server:send(Src, ?SCORPS, CorpsUid, ChatContent).

%% ----------------------------------------------------
%% @doc
%%      跨服频道
%% @end
%% ----------------------------------------------------
notice_mapid(Src, CfgName, Args, MapId) ->
    Time = time_lib:now_second(),
    Channel = ?CROSS,
    Content = game_lib:get_language(CfgName, Args),
    ChatContent = {Channel, -1, 0, 0, 0, MapId, 0, 0, 0, Time, Content, 0},
    chat_server:send(Src, ?SCROSS, MapId, ChatContent).

%% ----------------------------------------------------
%% @doc
%%      发送聊天消息
%% @end
%% ----------------------------------------------------
send_msg(_, _, _, []) ->
    'ok';
send_msg(_A, Src, ?SWORLD, MsgList) ->
    set_front_lib:set_chat_new(Src, login_db:get_all_online(Src), list_to_tuple(MsgList));
send_msg(_A, Src, ?SCOUNTRY, List) ->
    Fun = fun({_, []}) ->
        'ok';
        ({Country, MsgList}) ->
            set_front_lib:set_chat_new(Src, login_db:get_country_online(Src, Country), list_to_tuple(MsgList))
    end,
    lists:foreach(Fun, List);
send_msg(_A, Src, ?SCORPS, List) ->
    Fun = fun({_, []}) ->
        'ok';
        ({CorpsUid, MsgList}) ->
            RUids = corps_db:get_corps_members(Src, CorpsUid),
            Sessions = z_lib:foreach(fun(Acc, RUid) ->
                case login_db:get_online(Src, RUid) of
                    none ->
                        Acc;
                    Session ->
                        [Session | Acc]
                end
            end, [], RUids),
            if
                Sessions =:= [] ->
                    ok;
                true ->
                    set_front_lib:set_chat_new(Src, Sessions, list_to_tuple(MsgList))
            end
    end,
    lists:foreach(Fun, List);
send_msg(_A, Src, ?SCROSS, List) ->
    Fun = fun({_, []}) ->
        'ok';
        ({MapId, MsgList}) ->
            set_front_lib:set_chat_new(Src, login_db:get_country_online(Src, MapId), list_to_tuple(MsgList))
    end,
    lists:foreach(Fun, List).
%% ----------------------------------------------------
%% @doc
%%      发送聊天消息消耗检查
%% @end
%% ----------------------------------------------------
check(_Src, _RoleUid, _Count, _Rmb, []) ->
    ok;
check(Src, RoleUid, Count, Rmb, ConsumeList) ->
    VipTimes = vip_lib:get_world_chat_times(role_db:get_role(Src, RoleUid)),
    Fun = fun(Bool1, {'free_times', MaxFreeTimes}) -> %% 次数消耗
        if
            MaxFreeTimes + VipTimes > Count ->
                {'break', {'free_times', 1}};
            true ->
                {ok, Bool1}
        end;
        (Bool1, {'rmb', Value}) -> %% rmb消耗
            %%校验rmb是否足够
            case rmb_lib:get_rmb(Rmb) >= Value of
                true ->
                    {'break', {'rmb', Value}};
                false ->
                    {ok, Bool1}

            end;
        (Bool1, _) -> %% 其他过滤
            {ok, Bool1}
    end,
    %% 按配置先后顺序进行验证
    case z_lib:foreach(Fun, 'false', ConsumeList) of
        {'free_times', _} ->
            ok;
        {'rmb', V} ->
            {Cs, NRmb} = rmb_lib:reduct_rmb(Rmb, V),
            {ok, {Cs, NRmb}};
        _ ->
            throw("consume_limit")
    end.
%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
chat_times_init() ->
    [{{time, ?WORLD}, 0, 0}, {{time, ?CORPS}, 0, 0}, {{time, ?COUNTRY}, 0, 0}].
%%%=====================LOC FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      检查方法
%% @end
%% ----------------------------------------------------
check(_Src, _Uid, Content, {'size_limit', Limit}) ->
    string_lib:compute_size(Content) =< Limit;
check(Src, Uid, _Content, {'level_limit', Level}) ->
    RoleShow = role_db:get_role_show(Src, Uid),
    role_show:get_level(RoleShow) >= Level;
check(_, _, _, _) ->
    true.