%% 聊天场景管理器
-module(chat_server).

-description("chat_server").
-copyright({'seasky', 'www.seasky.cn'}).
-author({'cb', 'chenbin@seaskyjoy.com'}).
-vsn(1).

%%%=======================EXPORT=======================
-export([send/3, send/4, recently_msg/1, recently_msg/2]).
-export([start_link/2, stop/1]).
%% MFA
-export([init_normal_chat/3, init_group_chat/3, add_normal_chat/4, add_group_chat/4,
    format_normal_chat/2, format_group_chat/2, recently_normal_chat/3, recently_group_chat/3]).
%% ----------------------------------------------------
%% gen_server callbacks
%% ----------------------------------------------------
-behaviour(gen_server).
-export([init/1, handle_call/3, handle_cast/2, handle_info/2, terminate/2, code_change/3]).
%%%=======================DEFINE=======================
%% 休眠时间
-define(HIBERNATE_TIMEOUT, 3000).
%% 广播消息频率
-define(SEND_FREQUENCY, 1000).
%% 广播一次的消息条数上限
-define(SEND_COUNT, 100).
%% 广播一次的数据大小, 必须小于等于65535
-define(SEND_SIZE, 65000).
%% 存储最近聊天信息最大条数
-define(RECENTLY_COUNT, 20).
%%%=======================RECORD=======================
-record(state,
{
    src,              %% src源
    uid,              %% 当前消息最大uid
    channel,          %% 聊天频道
    ets               %% {消息表,最近消息表} | {消息表,消息组消息映射表,最近消息表}
}).
%%%=======================INCLUDE======================
-include("../include/chat.hrl").
%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% Func: send/2
%% Description: 发送公共频道信息
%% Returns: ok | none
%% ----------------------------------------------------
send(Src, Channel, Message) when is_atom(Channel) ->
    send(Src, Channel, 0, Message).
%% ----------------------------------------------------
%% Func: send/3
%% Description: 发送聊天组信息(军团等)
%% Returns: ok | none
%% ----------------------------------------------------
send(Src, Channel, ChatGroupUid, Message) when is_atom(Channel) ->
    %%是否有频道线程
    case whereis(Channel) of
        Pid when is_pid(Pid) ->
            gen_server:cast(Channel, {'chat_msg', ChatGroupUid, Message});
        'undefined' ->
            %%创建频道线程
            case zm_pid:create(Channel, fun() -> chat_server:start_link(Src, Channel) end) of
                {'ok', _} ->
                    gen_server:cast(Channel, {'chat_msg', ChatGroupUid, Message});
                _ ->
                    none
            end
    end.

%% ----------------------------------------------------
%% Func: recently_msg/1
%% Description: 获取公共频道最近聊天信息
%% Returns: List
%% ----------------------------------------------------
recently_msg(Channel) ->
    recently_msg(Channel, 0).
%% ----------------------------------------------------
%% Func: recently_msg/1
%% Description: 获取聊天组最近聊天信息
%% Returns: tuple
%% ----------------------------------------------------
recently_msg(Channel, ChatGroupUid) ->
    case whereis(Channel) of
        Pid when is_pid(Pid) ->
            List = gen_server:call(Channel, {'recently_msg', ChatGroupUid}),
            list_to_tuple(List);
        'undefined' ->
            {}
    end.
%% ----------------------------------------------------
%% Description: 停止频道
%% ----------------------------------------------------
stop(Channel) ->
    case whereis(Channel) of
        Pid when is_pid(Pid) ->
            gen_server:cast(Pid, 'stop');
        _ ->
            none
    end.
%% ----------------------------------------------------
%% Function: start_link/2
%% Returns: pid
%% ----------------------------------------------------
start_link(Src, Channel) ->
    gen_server:start_link({local, Channel}, ?MODULE, [Src, Channel], []).
%% ----------------------------------------------------
%% Function: init/1
%% Description: Initiates the server
%% Returns: {ok, State}
%% ----------------------------------------------------
init([Src, Channel]) ->
    %% 当用户进程的堆栈大小超过16#c80000字长（100MB），就会被干掉
    erlang:process_flag(max_heap_size, #{size => 16#c80000, kill => true, error_logger => true}),

    %% 获取频道配置表
    {_, List} = zm_config:get(?MODULE, Channel),
    {_, {F, A}} = lists:keyfind(init, 1, List),
    State = ?MODULE:F(A, Src, Channel),
    {ok, State, ?HIBERNATE_TIMEOUT}.

%% ----------------------------------------------------
%% Function: handle_call/3
%% Description: Handling call messages
%% Returns: {reply, Reply, State}
%% ----------------------------------------------------
handle_call({'recently_msg', ChatGroupUid}, _From, #state{channel = Channel} = State) ->
    {_, List} = zm_config:get(?MODULE, Channel),
    {_, {F, A}} = lists:keyfind(recently_chat, 1, List),
    Reply = ?MODULE:F(A, ChatGroupUid, State),
    {reply, Reply, State, ?HIBERNATE_TIMEOUT};
handle_call(_Request, _From, State) ->
    {reply, ok, State, ?HIBERNATE_TIMEOUT}.

%% ----------------------------------------------------
%% Function: handle_cast/2
%% Description: Handling cast messages
%% Returns: {noreply, State}
%% ----------------------------------------------------
handle_cast({'chat_msg', ChatGroupUid, Message}, #state{channel = Channel} = State) ->
    {_, List} = zm_config:get(?MODULE, Channel),
    {_, {F, A}} = lists:keyfind(add, 1, List),
    NewState = ?MODULE:F(A, ChatGroupUid, Message, State),
    {noreply, NewState, ?HIBERNATE_TIMEOUT};
handle_cast('stop', State) ->
    {'stop', 'destory', State};
handle_cast(_Msg, State) ->
    {noreply, State, ?HIBERNATE_TIMEOUT}.

%% ----------------------------------------------------
%% Function: handle_info/2
%% Description: Handling all non call/cast messages
%% Returns: {noreply, State}
%% ----------------------------------------------------
handle_info({timeout, _Ref, 'chat'}, #state{src = Src, ets = EtsTuple, channel = Channel} = State) ->
    EtsSize = ets:info(element(1, EtsTuple), size),
    if
        EtsSize =:= 0 ->
            ok;
        true ->
            {_, List} = zm_config:get(?MODULE, Channel),
            {_, {F, A}} = lists:keyfind(send_format, 1, List),
            try
                Msg = ?MODULE:F(A, State),
                {_, {M1, F1, A1}} = lists:keyfind(send, 1, List),
                M1:F1(A1, Src, Channel, Msg)
            catch
                E:E1 ->
                    zm_log:warn(?MODULE, ?MODULE, 'handle_info', "error", [{'e', E}, {'e1', E1}, {'stacktrace', erlang:get_stacktrace()}])
            end,
            NewEtsSize = ets:info(element(1, EtsTuple), size),
            if
                NewEtsSize > 0 ->
                    {_, {_, A2}} = lists:keyfind(add, 1, List),
                    erlang:start_timer(z_lib:get_value(A2, 'frequency', ?SEND_FREQUENCY), self(), 'chat');
                true ->
                    'ok'
            end
    end,
    {noreply, State, ?HIBERNATE_TIMEOUT};
handle_info(timeout, State) ->
    {noreply, State, hibernate};
handle_info(_Info, State) ->
    {noreply, State, ?HIBERNATE_TIMEOUT}.

%% ----------------------------------------------------
%% Function: terminate/2
%% Description: Shutdown the server
%% Returns: any (ignored by gen_server)
%% ----------------------------------------------------
terminate(_Reason, #state{} = State) ->
    State.

%% ----------------------------------------------------
%% Function: code_change/3
%% Purpose: Convert process state when code is changed
%% Returns: {ok, NewState}
%% ----------------------------------------------------
code_change(_OldVsn, State, _Extra) ->
    {ok, State}.

%%%====================MFA FUNCTION====================
%% 初始化公共聊天(世界聊天)
init_normal_chat(_A, Src, Channel) ->
    Ets = ets:new('chat_ets', ['protected', 'ordered_set']),
    VEts = ets:new('view_ets', ['protected', 'ordered_set']),
    #state{src = Src, uid = 0, channel = Channel, ets = {Ets, VEts}}.
%% 初始化聊天组聊天(军团聊天)
init_group_chat(_A, Src, Channel) ->
    Ets = ets:new('chat_ets', ['protected', 'ordered_set']),
    GroupEts = ets:new('group_ets', ['protected']),
    VEts = ets:new('view_ets', ['protected', 'ordered_set']),
    #state{src = Src, uid = 0, channel = Channel, ets = {Ets, GroupEts, VEts}}.

%% 添加公共聊天(世界聊天)
add_normal_chat(A, _ChatGroupUid, Message, #state{uid = Uid, ets = {Ets, VEts}} = State) ->
    %% 启动推送定时器
    [erlang:start_timer(z_lib:get_value(A, 'frequency', ?SEND_FREQUENCY), self(), 'chat') || ets:info(Ets, size) =:= 0],
    %% 加入新消息
    ets:insert(Ets, {Uid + 1, Message}),
    %% 加入最近消息列表
    VSize = ets:info(VEts, 'size'),
    RecentlyCount = z_lib:get_value(A, 'recently_count', ?RECENTLY_COUNT), %% 最近消息条数
    if
        VSize >= RecentlyCount ->
            ets:delete(VEts, ets:first(VEts));
        true ->
            'ok'
    end,
    ets:insert(VEts, {Uid + 1, Message}),
    State#state{uid = Uid + 1}.
%% 添加聊天组聊天(军团聊天)
add_group_chat(A, ChatGroupUid, Message, #state{uid = Uid, ets = {Ets, GroupEts, VEts}} = State) ->
    %% 启动推送定时器
    [erlang:start_timer(z_lib:get_value(A, 'frequency', ?SEND_FREQUENCY), self(), 'chat') || ets:info(Ets, size) =:= 0],
    %% 加入新消息
    ets:insert(Ets, {Uid + 1, Message}),
    %% 加入消息组
    case ets:lookup(GroupEts, ChatGroupUid) of
        [{ChatGroupUid, MsgUids}] ->
            ets:insert(GroupEts, {ChatGroupUid, [Uid + 1 | MsgUids]});
        _ ->
            ets:insert(GroupEts, {ChatGroupUid, [Uid + 1]})
    end,
    %% 加入最近消息列表
    case ets:lookup(VEts, ChatGroupUid) of
        [{ChatGroupUid, MsgList}] ->
            RecentlyCount = z_lib:get_value(A, 'recently_count', ?RECENTLY_COUNT), %% 最近消息条数
            ets:insert(VEts, {ChatGroupUid, lists:sublist([Message | MsgList], RecentlyCount)});
        _ ->
            ets:insert(VEts, {ChatGroupUid, [Message]})
    end,
    State#state{uid = Uid + 1}.

%% 整理公共聊天(世界聊天)数据
format_normal_chat(A, #state{ets = {Ets, _VEts}}) ->
    %% 每次发送数据上限
    MaxCount = z_lib:get_value(A, 'count', ?SEND_COUNT),
    %% 每次发送数据大小上限
    MaxSize = z_lib:get_value(A, 'size', ?SEND_SIZE),
    Fun = fun
        ({Size, Count, List} = Args, {_Uid, Message}) ->
            Bin = term_to_binary(Message, [{minor_version, 1}]),
            TotalSize = Size + byte_size(Bin),
            %% 检查是否超过指定数量和指定总大小
            if
                TotalSize > MaxSize orelse Count >= MaxCount ->
                    {'break', Args};
                true ->
                    %% 取出数据后进行删除
                    {'delete', {TotalSize, Count + 1, [Message | List]}}
            end
    end,
    element(3, z_lib:ets_select(Ets, Fun, {0, 0, []})).
%% 整理聊天组聊天(军团聊天)数据
format_group_chat(A, #state{ets = {Ets, GroupEts, _VEts}}) ->
    %% 每次发送数据上限
    MaxCount = z_lib:get_value(A, 'count', ?SEND_COUNT),
    %% 每次发送数据大小上限
    MaxSize = z_lib:get_value(A, 'size', ?SEND_SIZE),
    %% 拿到所有聊天组
    F = fun
        ({Size, Count, DelUids, List}, Uid) ->
            case ets:lookup(Ets, Uid) of
                [{_Uid, Message}] ->
                    Bin = term_to_binary(Message, [{minor_version, 1}]),
                    TotalSize = Size + byte_size(Bin),
                    %% 检查是否超过指定数量和指定总大小
                    if
                        TotalSize > MaxSize orelse Count >= MaxCount ->
                            {'break', {Size, Count, DelUids, List}};
                        true ->
                            ets:delete(Ets, Uid),
                            {TotalSize, Count + 1, [Uid | DelUids], [Message | List]}
                    end;
                _ ->
                    {Size, Count, DelUids, List}
            end
    end,
    Fun = fun
        ({GroupUid, []}, Acc) ->
            ets:delete(GroupEts, GroupUid),
            Acc;
        ({GroupUid, ChatUids}, Acc) ->
            {_, _, DelUids, List} = z_lib:foreach(F, {0, 0, [], []}, lists:reverse(ChatUids)),
            case ChatUids -- DelUids of
                [] ->
                    ets:delete(GroupEts, GroupUid);
                NowUids ->
                    ets:insert(GroupEts, {GroupUid, NowUids})
            end,
            [{GroupUid, List} | Acc]
    end,
    lists:foldl(Fun, [], ets:tab2list(GroupEts)).

%% 获得公共聊天(世界聊天)最近消息
recently_normal_chat(_A, _, #state{ets = {_Ets, VEts}}) ->
    [Msg || {_, Msg} <- ets:tab2list(VEts)].
%% 获得聊天组聊天(军团聊天)最近消息
recently_group_chat(_A, ChatGroupUid, #state{ets = {_Ets, _GroupEts, VEts}}) ->
    case ets:lookup(VEts, ChatGroupUid) of
        [{_Uid, MessageList}] ->
            lists:reverse(MessageList);
        _ ->
            []
    end.