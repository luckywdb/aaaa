%%对应前台的ByteBuffer类
-module(byte_buffer).

%%%=======================STATEMENT====================
-description("byte_buffer").
-copyright('youkia,www.youkia.net').
-author("hzh,huangzhenghan@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([init/1, length/1]).
-export([read_boolean/1, read_byte/1, read_ubyte/1, read_short/1, read_ushort/1, read_int/1, read_long/1, read_utf/1]).
%%%=======================INCLUDE======================

%%%=======================RECORD=======================
-record(byte_buffer, {bytes, top, position}).
%%%=======================DEFINE=======================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% Func: init/1
%% Description: 初始化
%% Returns: byte_buffer()
%% ----------------------------------------------------
init(Bytes) ->
    #byte_buffer{bytes = Bytes, top = byte_size(Bytes), position = 0}.

%% ----------------------------------------------------
%% Func: length/1
%% Description: 获得当前剩余长度
%% Returns: integer()`
%% ----------------------------------------------------
length(#byte_buffer{top = Top, position = Pos}) ->
    Top - Pos.

%%%===================READ FUNCTIONS==================
%% ----------------------------------------------------
%% Func: length/1
%% Description: 获得当前剩余长度
%% Returns: {boolean(),byte_buffer()}
%% ----------------------------------------------------
read_boolean(#byte_buffer{bytes = Bytes, position = Pos} = ByteBuffer) ->
    {binary:part(Bytes, Pos, 1) =:= <<1>>, ByteBuffer#byte_buffer{position = Pos + 1}}.
%% ----------------------------------------------------
%% Func: read_byte/1
%% Description: 读取一个字节
%% Returns: {integer(),byte_buffer()}
%% ----------------------------------------------------
read_byte(#byte_buffer{bytes = Bytes, position = Pos} = ByteBuffer) ->
    <<V>> = binary:part(Bytes, Pos, 1),
    Value = if
        V >= 16#80 -> V - 16#ff - 1;
        true -> V
    end,
    {Value, ByteBuffer#byte_buffer{position = Pos + 1}}.
%% ----------------------------------------------------
%% Func: read_ubyte/1
%% Description: 读取一个无符号字节
%% Returns: {integer(),byte_buffer()}
%% ----------------------------------------------------
read_ubyte(#byte_buffer{bytes = Bytes, position = Pos} = ByteBuffer) ->
    <<Value>> = binary:part(Bytes, Pos, 1),
    {Value, ByteBuffer#byte_buffer{position = Pos + 1}}.
%% ----------------------------------------------------
%% Func: read_short/1
%% Description: 读取短整型
%% Returns: {integer(),byte_buffer()}
%% ----------------------------------------------------
read_short(#byte_buffer{bytes = Bytes, position = Pos} = ByteBuffer) ->
    <<B1, B2>> = binary:part(Bytes, Pos, 2),
    V = (B1 bsl 8) bor B2,
    Value = if
        V >= 16#8000 -> V - 16#ffff - 1;
        true -> V
    end,
    {Value, ByteBuffer#byte_buffer{position = Pos + 2}}.
%% ----------------------------------------------------
%% Func: read_ushort/1
%% Description: 读取无符号短整型
%% Returns: {integer(),byte_buffer()}
%% ----------------------------------------------------
read_ushort(#byte_buffer{bytes = Bytes, position = Pos} = ByteBuffer) ->
    <<B1, B2>> = binary:part(Bytes, Pos, 2),
    Value = (B1 bsl 8) bor B2,
    {Value, ByteBuffer#byte_buffer{position = Pos + 2}}.
%% ----------------------------------------------------
%% Func: read_int/1
%% Description: 读取整型
%% Returns: {integer(),byte_buffer()}
%% ----------------------------------------------------
read_int(#byte_buffer{bytes = Bytes, position = Pos} = ByteBuffer) ->
    <<B1, B2, B3, B4>> = binary:part(Bytes, Pos, 4),
    V = (B1 bsl 24) bor (B2 bsl 16) bor (B3 bsl 8) bor B4,
    Value = if
        V >= 16#80000000 -> V - 16#ffffffff - 1;
        true -> V
    end,
    {Value, ByteBuffer#byte_buffer{position = Pos + 4}}.
%% ----------------------------------------------------
%% Func: read_long/1
%% Description: 读取长整型
%% Returns: {integer(),byte_buffer()}
%% ----------------------------------------------------
read_long(#byte_buffer{bytes = Bytes, position = Pos} = ByteBuffer) ->
    <<B1, B2, B3, B4, B5, B6, B7, B8>> = binary:part(Bytes, Pos, 8),
    V = (B1 bsl 56) bor (B2 bsl 48) bor (B3 bsl 40) bor (B4 bsl 32) bor (B5 bsl 24) bor (B6 bsl 16) bor (B7 bsl 8) bor B8,
    Value = if
        V >= 16#8000000000000000 -> V - 16#ffffffffffffffff - 1;
        true -> V
    end,
    {Value, ByteBuffer#byte_buffer{position = Pos + 8}}.
%% ----------------------------------------------------
%% Func: read_utf/1
%% Description: 读取字符串
%% Returns: {string(),byte_buffer()}
%% ----------------------------------------------------
read_utf(#byte_buffer{bytes = Bytes} = ByteBuffer) ->
    {Length, #byte_buffer{position = Pos} = ByteBuffer1} = read_length(ByteBuffer),
    {unicode:characters_to_list(binary:part(Bytes, Pos, Length - 1), utf8), ByteBuffer1#byte_buffer{position = Pos + Length - 1}}.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% Func: read_length/1
%% Description: 读取字符串长度
%% Returns: 
%% ----------------------------------------------------
read_length(#byte_buffer{bytes = Bytes, position = Pos} = ByteBuffer) ->
    <<B1>> = binary:part(Bytes, Pos, 1),
    V = B1 band 16#ff,
    if
        V >= 16#80 ->
            {V - 16#80, ByteBuffer#byte_buffer{position = Pos + 1}};
        V >= 16#40 ->
            {Value, NByteBuffer} = read_ushort(ByteBuffer),
            {Value - 16#4000, NByteBuffer};
        V >= 16#20 ->
            {Value, NByteBuffer} = read_int(ByteBuffer),
            {Value - 16#20000000, NByteBuffer}
    end.