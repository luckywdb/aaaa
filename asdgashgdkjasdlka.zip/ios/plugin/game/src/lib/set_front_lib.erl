-module(set_front_lib).
-description("set_front_lib").
-copyright({seasky, 'www.seasky.cn'}).
-author({cb, 'chenbin@seaskyjoy.com'}).
-vsn(1).

%%%=======================EXPORT=======================
-compile(export_all).
%%%=======================INCLUDE======================

%%%=================EXPORTED FUNCTIONS=================

%%-------------------------------------------------------------------
%% @doc
%%      推送被掠夺玩家
%% @end
%%-------------------------------------------------------------------
-spec send_plunder(Src, RoleUid, PlunderAward, EnemyFlourishInfo, RoleAward) -> atom() when
    Src :: atom(),
    RoleUid :: integer(),
    PlunderAward :: list(),%%被掠夺资源
    EnemyFlourishInfo :: {'flourish', integer(), integer()},%%当前繁荣度
    RoleAward :: tuple().%%被掠夺者奖励
send_plunder(Src, RoleUid, PlunderAward, EnemyFlourishInfo, RoleAward) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'plunder', [{msg, {list_to_tuple(PlunderAward), EnemyFlourishInfo, RoleAward}}]})
    end.

%%-------------------------------------------------------------------
%% @doc
%%      推送功勋奖励
%% @end
%%-------------------------------------------------------------------
-spec send_award(atom(), integer(), tuple()) -> atom().
send_award(Src, RoleUid, AwardLog) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'award', [{msg, AwardLog}]})
    end.

%%-------------------------------------------------------------------
%% @doc
%%      城池所属发生变化
%% @end
%%-------------------------------------------------------------------
-spec send_town_owner(Src :: atom(), TowhSid :: integer(), Town :: town:town(), string()) -> string().
send_town_owner(Src, TownSid, Town, CorpsName) ->
    T = {'town_owner', [{msg, {point_lib:sid2view(TownSid), town:get_country(Town), town:get_corps_uid(Town), CorpsName, town:get_exp(Town), town:get_state(Town)}}]},
    MapId = point_lib:sid2mapid(TownSid),
    if
        MapId > 0 ->
            login_db:send_country_online(Src, MapId, T);
        true ->
            login_db:send_all_online(Src, T)
    end.


%%-------------------------------------------------------------------
%% @doc
%%      放弃城池通知
%% @end
%%-------------------------------------------------------------------
send_corps_abandon_town(Src, CorpsUid, TownSid, TownExp) ->
    T = {'corps_abandon_town', [{msg, {CorpsUid, point_lib:sid2view(TownSid), TownExp}}]},
    login_db:send_all_online(Src, T).

%%-------------------------------------------------------------------
%% @doc
%%      城池战斗中
%% @end
%%-------------------------------------------------------------------
send_country_unfight(Src, TownSid, Country) ->
    T = {'country_unfight', [{msg, {TownSid, Country}}]},
    login_db:send_all_online(Src, T).

%%-------------------------------------------------------------------
%% @doc
%%      军团城池战斗中(State 0:非战斗中 1:战斗中)
%% @end
%%-------------------------------------------------------------------
-spec send_corps_fight(Src :: atom(), RoleUids :: [integer()], TownSid :: integer(), CorpsUid :: integer(), State :: 0|1, integer()) -> ok.
send_corps_fight(Src, RoleUids, TownSid, CorpsUid, State, STime) ->
    T = {'corps_fight', [{msg, {point_lib:sid2view(TownSid), CorpsUid, State, STime}}]},
    lists:foreach(fun(RUid) ->
        case login_db:get_online(Src, RUid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, T)
        end
    end, RoleUids).

%%-------------------------------------------------------------------
%% @doc
%%      刷新开服狂欢
%% @end
%%-------------------------------------------------------------------
-spec send_task_update(Src :: atom(), RoleUid :: integer(), Value :: tuple()) -> atom().
send_task_update(Src, RoleUid, Value) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'task', [{msg, Value}]})
    end.
%% ----------------------------------------------------
%% @doc
%%      推送商店热卖或折扣改变
%% @end
%% ----------------------------------------------------
-spec send_shop_hot_dis_change(Src :: atom(), ShopName :: atom()) -> string().
send_shop_hot_dis_change(Src, ShopName) ->
    T = {'shop_hot_dis_change', [{msg, ShopName}]},
    login_db:send_all_online(Src, T).

%% ----------------------------------------------------
%% @doc
%%      推送增加友军驻守
%% @end
%% ----------------------------------------------------
-spec send_garrison_add_friend_garray(Src :: atom(), RoleUid :: integer(), tuple()) -> atom().
send_garrison_add_friend_garray(Src, RoleUid, Value) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'garrison_add_friend_garray', [{msg, Value}]})
    end.
%% ----------------------------------------------------
%% @doc
%%      推送删除友军驻守
%% @end
%% ----------------------------------------------------
-spec send_garrison_remove_friend_garray(Src :: atom(), RoleUid :: integer(), RUid :: integer(), Gid :: integer()) -> atom().
send_garrison_remove_friend_garray(Src, RoleUid, MarchRoleUid, MarchGid) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'garrison_remove_friend_garray', [{msg, {MarchRoleUid, MarchGid}}]})
    end.

%% ----------------------------------------------------
%% @doc
%%      推送驻守下阵
%% @end
%% ----------------------------------------------------
-spec send_garrison_down_garray(Src :: atom(), RoleUid :: integer(), GId :: integer()) -> atom().
send_garrison_down_garray(Src, RoleUid, GId) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'garrison_down_garray', [{msg, {RoleUid, GId}}]})
    end.

%% ----------------------------------------------------
%% @doc
%%      推送自动补兵
%% @end
%% ----------------------------------------------------
-spec send_garray_auto_add_soldiers(Src :: atom(), RoleUid :: integer(), Value :: tuple()) -> atom().
send_garray_auto_add_soldiers(Src, RoleUid, Value) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'garray_auto_add_soldiers', [{msg, Value}]})
    end.

%% ----------------------------------------------------
%% @doc
%%      推送阵型带兵变化
%% @end
%% ----------------------------------------------------
send_garray_change(Src, RoleUid, Value) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'garray_change', [{msg, Value}]})
    end.

%% ----------------------------------------------------
%% @doc
%%      推送体力,精力更新信息
%% @end
%% ----------------------------------------------------
send_restore(Src, RoleUid, Value) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'restore_update', [{'msg', Value}]})
    end.

%% ----------------------------------------------------
%% @doc
%%      刷新任务
%% @end
%% ----------------------------------------------------
-spec send_achieve(Src :: atom(), RoleUid :: integer(), Value :: tuple()) -> atom().
send_achieve(Src, RoleUid, Value) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {achieve, [{msg, Value}]})
    end.

%% ----------------------------------------------------
%% @doc
%%      军团推送申请给团长和副团长
%% @end
%% ----------------------------------------------------
-spec send_corps_request(Src :: atom(), Corps :: corps:corps(), RoleUid :: integer()) -> 'ok'.
send_corps_request(Src, Corps, RoleUid) ->
    List = [corps:get_owner(Corps) | corps:get_vice_owner_list(Corps)],
    RequestView = corps_lib:get_request_view(Src, RoleUid, 0),
    lists:foreach(fun(RUid) ->
        case login_db:get_online(Src, RUid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'corps_request', [{msg, RequestView}]})
        end
    end, List),
    ok.
%% ----------------------------------------------------
%% @doc
%%      军团推送取消申请给团长和副团长
%% @end
%% ----------------------------------------------------
-spec send_corps_cancel_request(Src :: atom(), Corps :: corps:corps(), RoleUid :: integer()) -> 'ok'.
send_corps_cancel_request(Src, Corps, RoleUid) ->
    List = [corps:get_owner(Corps) | corps:get_vice_owner_list(Corps)],
    lists:foreach(fun(RUid) ->
        case login_db:get_online(Src, RUid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'corps_cancel_request', [{msg, RoleUid}]})
        end
    end, List),
    ok.

%% ----------------------------------------------------
%% @doc
%%      军团推送拒绝申请
%% @end
%% ----------------------------------------------------
-spec send_corps_refuse_request(Src :: atom(), Corps :: corps:corps(), RoleUid :: integer(), RUid :: integer()) -> 'ok'.
send_corps_refuse_request(Src, Corps, RoleUid, RUid) ->
    List = [RUid | lists:delete(RoleUid, [corps:get_owner(Corps) | corps:get_vice_owner_list(Corps)])],
    CorpsUid = corps:get_uid(Corps),
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'corps_refuse_request', [{msg, {CorpsUid, RUid}}]})
        end
    end, List),
    ok.

%% ----------------------------------------------------
%% @doc
%%      军团推送同意申请
%% @end
%% ----------------------------------------------------
-spec send_corps_agree_request(Src :: atom(), RoleUids :: [integer()], RoleUid :: integer(), RUids :: [integer()], Corps :: corps:corps(), FTSidSTimeList :: [{integer(), integer()}]) -> 'ok'.
send_corps_agree_request(Src, RoleUids, RoleUid, RUids, Corps, FTSidSTimeList) ->
    CorpsUid = corps:get_uid(Corps),
    M1 = {'corps_agree_request_member', [{msg, list_to_tuple(RUids)}]},
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, M1)
        end
    end, RoleUids -- [RoleUid | RUids]),

    M2 = {'corps_agree_request', [{msg, {CorpsUid, list_to_tuple(FTSidSTimeList)}}]},
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, M2)
        end
    end, RUids),
    ok.

%% ----------------------------------------------------
%% @doc
%%      军团推送同意邀请
%% @end
%% ----------------------------------------------------
-spec send_corps_agree_invite(Src :: atom(), RoleUids :: [integer()], RoleUid :: integer(), Corps :: corps:corps()) -> 'ok'.
send_corps_agree_invite(Src, RoleUids, RoleUid, Corps) ->
    CorpsUid = corps:get_uid(Corps),
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'corps_agree_invite', [{msg, {CorpsUid, RoleUid}}]})
        end
    end, lists:delete(RoleUid, RoleUids)),
    ok.
%% ----------------------------------------------------
%% @doc
%%      申请后直接加入军团
%% @end
%% ----------------------------------------------------
-spec send_corps_request_enter(Src :: atom(), RoleUids :: [integer()], RoleUid :: integer(), Corps :: corps:corps()) -> 'ok'.
send_corps_request_enter(Src, RoleUids, RoleUid, Corps) ->
    CorpsUid = corps:get_uid(Corps),
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'corps_request_enter', [{msg, {CorpsUid, RoleUid}}]})
        end
    end, lists:delete(RoleUid, RoleUids)),
    ok.

%% ----------------------------------------------------
%% @doc
%%      军团推送旗帜变化
%% @end
%% ----------------------------------------------------
-spec send_corps_change_banner(Src :: atom(), RoleUids :: [integer()], Banner :: integer()) -> 'ok'.
send_corps_change_banner(Src, RoleUids, Banner) ->
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'corps_change_banner', [{msg, Banner}]})
        end
    end, RoleUids),
    ok.

%% ----------------------------------------------------
%% @doc
%%      军团改名
%% @end
%% ----------------------------------------------------
send_corps_change_name(Src, CorpsUid, Name) ->
    Msg = {'corps_change_name', [{msg, {CorpsUid, Name}}]},
    login_db:send_all_online(Src, Msg).

%% ----------------------------------------------------
%% @doc
%%      军团踢人
%% @end
%% ----------------------------------------------------
-spec send_corps_kickout(Src :: atom(), RoleUidList :: [integer()], RoleUid :: integer(), RUid :: integer()) -> 'ok'.
send_corps_kickout(Src, RoleUidList, RoleUid, RUid) ->
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'corps_kickout', [{msg, RUid}]})
        end
    end, [RUid | lists:delete(RoleUid, RoleUidList)]),
    ok.
%% ----------------------------------------------------
%% @doc
%%      军团退出
%% @end
%% ----------------------------------------------------
-spec send_corps_quit(Src :: atom(), RoleUidList :: [integer()], RoleUid :: integer()) -> 'ok'.
send_corps_quit(Src, RoleUidList, RoleUid) ->
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'corps_quit', [{msg, RoleUid}]})
        end
    end, RoleUidList),
    ok.

%% ----------------------------------------------------
%% @doc
%%      军团邀请玩家加入
%% @end
%% ----------------------------------------------------
-spec send_corps_invite(Src :: atom(), CorpsUid :: integer(), Corps :: corps:corps(), RoleUid :: integer()) -> 'ok'.
send_corps_invite(Src, CorpsUid, Corps, RoleUid) ->
    InviteView = corps_lib:format_role_invite_view(CorpsUid, Corps),
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'corps_invite', [{msg, InviteView}]})
    end,
    ok.

%% ----------------------------------------------------
%% @doc
%%      军团设置职位
%% @end
%% ----------------------------------------------------
-spec send_corps_set_position(Src :: atom(), RoleUidList :: [integer()], RUid :: integer(), Position :: integer()) -> 'ok'.
send_corps_set_position(Src, RoleUids, RUid, Position) ->
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'corps_set_position', [{msg, {RUid, Position}}]})
        end
    end, RoleUids),
    ok.
%% ----------------------------------------------------
%% @doc
%%      军团转让职位
%% @end
%% ----------------------------------------------------
-spec send_corps_trans_position(Src :: atom(), RoleUidList :: [integer()], RUid :: integer(), Position :: integer()) -> 'ok'.
send_corps_trans_position(Src, RoleUidList, RUid, Position) ->
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'corps_trans_position', [{msg, {RUid, Position}}]})
        end
    end, RoleUidList),
    ok.

%% ----------------------------------------------------
%% @doc
%%      解散军团
%% @end
%% ----------------------------------------------------
-spec send_corps_dissolve(Src :: atom(), RoleUidList :: [integer()], CorpsUid :: integer()) -> 'ok'.
send_corps_dissolve(Src, RoleUids, CorpsUid) ->
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'corps_dissolve', [{msg, CorpsUid}]})
        end
    end, RoleUids),
    ok.

%% ----------------------------------------------------
%% @doc
%%      军团经验
%% @end
%% ----------------------------------------------------
-spec send_corps_exp(Src :: atom(), RoleUidList :: [integer()], CorpsUid :: integer()) -> 'ok'.
send_corps_exp(Src, RoleUids, CorpsExp) ->
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'corps_exp', [{msg, CorpsExp}]})
        end
    end, RoleUids),
    ok.


%% ----------------------------------------------------
%% @doc
%%      军团经验
%% @end
%% ----------------------------------------------------
-spec send_corps_replace_owner(Src :: atom(), RoleUidList :: [integer()], RoleUid :: tuple()) -> 'ok'.
send_corps_replace_owner(Src, RoleUids, RoleUid) ->
%%    Msg = {RoleUid, RUid},
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'corps_replace_owner', [{msg, RoleUid}]})
        end
    end, lists:delete(RoleUid, RoleUids)),
    ok.

%% ----------------------------------------------------
%% @doc
%%      城池经验
%% @end
%% ----------------------------------------------------
send_town_exp(Src, TownSid, Exp) ->
    V = {'town_exp', [{msg, {TownSid, Exp}}]},
    login_db:send_all_online(Src, V).
%% ----------------------------------------------------
%% @doc
%%      发送有新战报通知
%% @end
%% ----------------------------------------------------
-spec send_report_new(Src :: atom(), RoleUid :: integer(), RType :: integer()) -> 'ok'.
send_report_new(Src, RoleUid, RType) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'report_new', [{msg, RType}]})
    end,
    ok.

%% ----------------------------------------------------
%% @doc
%%      推送充值
%% @end 
%% ----------------------------------------------------
send_cash(Src, RoleUid, [{_, _} | _] = Value) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'cash', [{'msg', list_to_tuple(Value)}]})
    end.

%% ----------------------------------------------------
%% @doc
%%       刷新聊天记录
%% @end 
%% ----------------------------------------------------
set_chat_new(Src, [Session | Sessions], Msg) ->%%我发世界频道 向所有人推送;嵌套过滤自己发送的消息还有黑名单(msg为多条消息)
    zm_session:send(Session, {'chat', [{'msg', Msg}]}),
    set_chat_new(Src, Sessions, Msg);
set_chat_new(_, [], _) ->
    ok.

%% ----------------------------------------------------
%% @doc
%%      刷新聊天记录
%% @end 
%% ----------------------------------------------------
set_chat(Src, [Uid | RoleUids], Uid, Msg) ->%%排除自己,不向自己推送
    set_chat(Src, RoleUids, Uid, Msg);
set_chat(Src, [H | RoleUids], Uid, Msg) ->%%我发世界频道 向所有人推送
    case login_db:get_online(Src, H) of
        none ->
            'offline';
        Session ->
            zm_session:send(Session, {'chat', [{'msg', Msg}]})
    end,
    set_chat(Src, RoleUids, Uid, Msg);
set_chat(_, [], _, _) ->
    ok;
set_chat(Src, RoleUid, _Uid, Msg) ->%%RoleUid 收信人 Uid 发件人
    case login_db:get_online(Src, RoleUid) of
        none ->
            'offline';
        Session ->
            if
                is_tuple(Msg) ->
                    zm_session:send(Session, {'chat', [{'msg', Msg}]});
                Msg =:= [] ->
                    ok;
                true ->
                    zm_session:send(Session, {'chat', [{'msg', list_to_tuple(Msg)}]})
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      刷新聊天面板的公告
%% @end 
%% ----------------------------------------------------
set_chat_notice(Sessions, Msg) ->
    [zm_session:send(Session, {chat_notice, [{msg, Msg}]}) || Session <- Sessions, Session =/= none],
    ok.

%% ----------------------------------------------------
%% @doc
%%      推送已发物品溢出邮件消息
%% @end  
%% ----------------------------------------------------
send_prop_mail(Src, RoleUid, Type) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'prop_mail', [{'msg', Type}]})
    end.

%% ----------------------------------------------------
%% @doc
%%       邮件
%% @end 
%% ----------------------------------------------------
send_mail(Src, RoleUid, Mail) when is_integer(RoleUid) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'mail', [{msg, mail:get_type(Mail)}]})
    end;
%%新系统邮件时候,符合收取该邮件的玩家才推送
send_mail(Src, Conditions, SysMail) when is_list(Conditions) ->
    Conds = system_mail:get_condition(SysMail),
    Uids =
        case z_lib:get_value(Conds, 'member_uid', []) of
            [] ->
                login_db:get_all_online_uid(Src);
            OtherList ->
                OtherList
        end,
    MailType = mail:get_type(system_mail:get_mail(SysMail)),
    T = {'mail', [{msg, MailType}]},
    lists:foreach(fun(Uid) ->
        case mail_lib:sysmail_condition(Src, Uid, user_db:get_user_platform(Src, Uid), Conds) of
            true ->
                Session = login_db:get_online(Src, Uid),
                if
                    Session =/= 'none' ->
                        zm_session:send(Session, T);
                    true ->
                        ok
                end;
            false ->
                ok
        end
    end, Uids).

%% ----------------------------------------------------
%% @doc
%%       扣除每日功勋,告知玩家
%% @end 
%% ----------------------------------------------------
send_feats_change(Src, RoleUid, Value) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'feats_change', [{'msg', Value}]})
    end.

%% ----------------------------------------------------
%% @doc
%%       官职变换
%% @end
%% ----------------------------------------------------
send_official_change(Src, RoleIdList, NOid) ->
    lists:foreach(fun(RoleUid) ->
        case login_db:get_online(Src, RoleUid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'official_change', [{'msg', NOid}]})
        end end, RoleIdList).

%% ----------------------------------------------------
%% @doc
%%      刷新开启的活动
%% @end 
%% ----------------------------------------------------
send_active(Src, Tuple) ->
    T = {'send_active', [{'msg', Tuple}]},
    login_db:send_all_online(Src, T).

send_active_total_cash(Src, Uid, Value) ->
    case login_db:get_online(Src, Uid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'active_total_cash', [{'msg', Value}]})
    end.

send_active_one_cash(Src, Uid, Value) ->
    case login_db:get_online(Src, Uid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'active_one_cash', [{'msg', Value}]})
    end.

send_active_ervery_cash(Src, Uid, Value) ->
    case login_db:get_online(Src, Uid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'active_ervery_cash', [{'msg', Value}]})
    end.

send_active_cash_award(Src, RoleUid, ItemSid, AwardLog) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'active_cash_award', [{'msg', {ItemSid, AwardLog}}]})
    end.

send_active_delete(_Src, []) ->
    ok;
send_active_delete(Src, DeleteActiveSids) ->
    Tuple = list_to_tuple(DeleteActiveSids),
    login_db:send_all_online(Src, {'active_delete', [{'msg', Tuple}]}).

%% ----------------------------------------------------
%% @doc
%%      推送开服基金信息
%% @end 
%% ----------------------------------------------------
send_funds_msg(Src, Uid, Msg) ->
    case login_db:get_online(Src, Uid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'send_funds_msg', [{'msg', Msg}]})
    end.

%% ----------------------------------------------------
%% @doc
%%      发送限时抽卡积分奖励
%% @end {index,score,awardlog}
%% ----------------------------------------------------
send_active_ld_award(Src, RoleUid, Reply) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'active_ld_award', [{msg, Reply}]})
    end.

%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
send_active_score_award(Src, RoleUid, Reply) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'active_score_award', [{msg, Reply}]})
    end.

%% ----------------------------------------------------
%% @doc
%%      大地图信息更新 对应point.hrl中类型 [{pointuid,{1,玩家}/{2,资源}/{3,土匪}/{4,npc城池}}]/ 土匪死亡,玩家迁城 value=[{puid,{0}}]
%% @end
%% ----------------------------------------------------
-spec send_mapinfo_change(Src :: atom(), RoleUids :: [integer()], Value :: list()) -> 'offline'|'ok'.
send_mapinfo_change(_, [], _) ->
    'ok';
send_mapinfo_change(Src, [H | RoleUids], Value) ->
    case login_db:get_online(Src, H) of
        none ->
            'offline';
        Session ->
            zm_session:send(Session, {'mapinfo_change', [{'msg', list_to_tuple(Value)}]})
    end,
    send_mapinfo_change(Src, RoleUids, Value).

%% ----------------------------------------------------
%% @doc
%%      大地图,战斗之后信息更新用(资源点占领,行军信息) % /{{puid,行军},{puid,行军},...}
%% @end
%% ----------------------------------------------------
-spec send_map_state(Src :: atom(), RoleUids :: integer()|[integer()], Value :: list()|tuple()) -> 'offline'|'ok'.
send_map_state(_, _, []) ->
    'ok';
send_map_state(_, [], _) ->
    'ok';
send_map_state(Src, RoleUid, Lines) when is_integer(RoleUid) ->
    SendValue =
        if
            is_list(Lines) ->
                list_to_tuple(Lines);
            true ->
                Lines
        end,
    case login_db:get_online(Src, RoleUid) of
        none ->
            'offline';
        Session ->
            zm_session:send(Session, {'map_state', [{'msg', SendValue}]})
    end;
send_map_state(Src, RoleUids, Lines) when is_list(Lines) ->
    send_map_state(Src, RoleUids, list_to_tuple(point_db:get_line_max(Lines)));
send_map_state(Src, [H | RoleUids], SendLines) when is_tuple(SendLines) ->
    send_map_state(Src, H, SendLines),
    send_map_state(Src, RoleUids, SendLines).

%% ----------------------------------------------------
%% @doc
%%      大地图,战斗结果 winner=0进攻方胜利,=1防守方胜利
%%      {Point,1,1,winner,另一方roleuid,0=进攻/1=防守/=2协防},
%%      {Point,3,3,Winner,土匪sid,AddCardExp(参加战斗的每个武将增加的经验)}
%%      资源点打怪{Point,2,3,Winner,资源点sid,AddCardExp(参加战斗的每个武将增加的经验)}
%%      资源点打玩家或防守{Point,2, 1,Winner,资源点sid,另一方roleuid, 0=进攻/1=防守,}
%% @end
%% ----------------------------------------------------
-spec send_map_result(Src :: atom(), RoleUid :: integer(), Value :: tuple()) -> 'offline'|'ok'.
send_map_result(Src, RoleUid, Value) ->
    NValue = erlang:setelement(2, Value, point_lib:xyz2view(element(2, Value))),
    case login_db:get_online(Src, RoleUid) of
        none ->
            'offline';
        Session ->
            zm_session:send(Session, {'map_result', [{'msg', NValue}]})
    end.

%% ----------------------------------------------------
%% @doc
%%      大地图,部队返回城堡,推送战报对应奖励和兵营信息 {AwardLog,GId, 状态,Injured, DeadNum}
%% @end
%% ----------------------------------------------------
-spec send_goback(Src :: atom(), RoleUid :: integer(), Value :: tuple()) -> 'offline'|'ok'.
send_goback(Src, RoleUid, Value) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            'offline';
        Session ->
            zm_session:send(Session, {'map_goback', [{'msg', Value}]})
    end.

send_capture_res(Src, RoleUid, Value) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            'offline';
        Session ->
            zm_session:send(Session, {'capture_res', [{'msg', Value}]})
    end.

%%-------------------------------------------------------------------
%% @doc
%%      推送名将录个数
%% @end
%%-------------------------------------------------------------------
send_card_record_num(Src, RoleUid, CardRecordNum) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            'offline';
        Session ->
            zm_session:send(Session, {'card_record_num', [{'msg', CardRecordNum}]})
    end.

%%-------------------------------------------------------------------
%% @doc
%%      推送被人攻打后随机飞城坐标
%% @end
%%-------------------------------------------------------------------
send_random_move_point(Src, RoleUid, NPointUid) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            'offline';
        Session ->
            zm_session:send(Session, {'random_move_castle', [{'msg', NPointUid}]})
    end.

%% ----------------------------------------------------
%% @doc
%%      城池血量推送,{townsid,curhp}
%% @end
%% ----------------------------------------------------
send_town_hp(_, [], _) ->
    'ok';
send_town_hp(Src, [H | RoleUids], Value) ->
    case login_db:get_online(Src, H) of
        none ->
            'offline';
        Session ->
            zm_session:send(Session, {'map_town_hp', [{'msg', Value}]})
    end,
    send_town_hp(Src, RoleUids, Value).

%% ----------------------------------------------------
%% @doc
%%      point_occ_len推送,{{puid,len},..}
%% @end
%% ----------------------------------------------------
send_town_occ_len(_, [], _) ->
    'ok';
send_town_occ_len(Src, [H | RoleUids], Value) ->
    case login_db:get_online(Src, H) of
        none ->
            'offline';
        Session ->
            zm_session:send(Session, {'town_occ_change_num', [{'msg', Value}]})
    end,
    send_town_occ_len(Src, RoleUids, Value).

%% ----------------------------------------------------
%% @doc
%%      推送军团公告修改时间
%% @end
%% ----------------------------------------------------
send_private_notice_time(Src, RoleUids, Value) ->
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'corps_private_notice_time', [{msg, Value}]})
        end
    end, RoleUids),
    ok.
%% ----------------------------------------------------
%% @doc
%%      推送军团招募公告修改时间
%% @end
%% ----------------------------------------------------
send_publice_notice_time(Src, RoleUids, Value) ->
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'corps_public_notice_time', [{msg, Value}]})
        end
    end, RoleUids),
    ok.


send_buy_tmp_queue(Src, RoleUid, MonthCardQId, STime, ETime) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'buy_tmp_queue', [{msg, {MonthCardQId, STime, ETime}}]})
    end.

%% ----------------------------------------------------
%% @doc
%%    功能开放,
%% @end
%% ----------------------------------------------------
send_func_not_open(Src, Func) ->
    T = {'func_not_open', [{msg, Func}]},
    login_db:send_all_online(Src, T).

%% ----------------------------------------------------
%% @doc
%%      喇叭发送
%% @end
%% ----------------------------------------------------
send_horn(Src, RUids, HornList) ->
    Msg = {'horn', [{msg, list_to_tuple(HornList)}]},
    NRUids = login_db:get_all_online_uid(Src) -- RUids,
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, Msg)
        end
    end, NRUids).

%% ----------------------------------------------------
%% @doc
%%      新增羁绊
%% @end
%% ----------------------------------------------------
send_fetter(Src, RoleUid, FetterList) ->
    Msg = {'fetter_list', [{msg, list_to_tuple(FetterList)}]},
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, Msg)
    end.
%% ----------------------------------------------------
%% @doc
%%      推送互助请求
%% @end
%% ----------------------------------------------------
send_request_help(Src, RoleUids, Msg) ->
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'request_help', [{msg, Msg}]})
        end
    end, RoleUids),
    ok.

%% ----------------------------------------------------
%% @doc
%%      帮助别人
%% @end
%% ----------------------------------------------------
send_complete_help(Src, RoleUids, Msg) ->
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'complete_help', [{msg, Msg}]})
        end
    end, RoleUids),
    ok.


%% ----------------------------------------------------
%% @doc
%%      推送国家的国王玩家Uid
%% @end
%% ----------------------------------------------------
send_monarch_king(Src, Country, RUid) ->
    Msg = {'monarch_king', [{'msg', {Country, RUid}}]},
    login_db:send_all_online(Src, Msg).

%% ----------------------------------------------------
%% @doc
%%      推送玩家官职
%% @end
%% ----------------------------------------------------
send_monarch_role_official(Src, RUid, Official) ->
    Msg = {'monarch_role_official', [{'msg', Official}]},
    case login_db:get_online(Src, RUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, Msg)
    end.

%% ----------------------------------------------------
%% @doc
%%      推送国策
%% @end
%% ----------------------------------------------------
send_monarch_country_police(Src, ACountry, PoliceId, State) ->
    Msg = {'monarch_country_police', [{'msg', {PoliceId, State, ACountry}}]},
    login_db:send_all_online(Src, Msg).

%% ----------------------------------------------------
%% @doc
%%      推送诏令
%% @end
%% ----------------------------------------------------
send_monarch_corps_police(Src, CUid, PoliceId, State) ->
    Msg = {'monarch_corps_police', [{'msg', {CUid, PoliceId, State}}]},
    login_db:send_all_online(Src, Msg).

%% ----------------------------------------------------
%% @doc
%%      推送单机发言
%% @end
%% ----------------------------------------------------
send_chat_alone(Src, RoleUid, Value) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'chat_alone', [{msg, Value}]})
    end,
    ok.

%% ----------------------------------------------------
%% @doc
%%      驻扎点被打爆
%% @end
%% ----------------------------------------------------
send_station_over(Src, RoleUid, GId) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'station_over', [{msg, GId}]})
    end,
    ok.
%% ----------------------------------------------------
%% @doc
%%      推送推送礼包奖励信息
%% @end
%% ----------------------------------------------------
send_push_gift_active_award(Src, RoleUid, AwardLog) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'push_gift_active_award', [{msg, AwardLog}]})
    end,
    ok.
%% ----------------------------------------------------
%% @doc
%%      推送推送礼包下一条目信息
%% @end
%% ----------------------------------------------------
send_push_gift_active_next_itme(Src, RoleUid, Format) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'push_gift_active_next_itme', [{msg, Format}]})
    end,
    ok.
%% ----------------------------------------------------
%% @doc
%%      推送推送礼包下一条目信息
%% @end
%% ----------------------------------------------------
send_push_gift_active(Src, RoleUid, Format) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'push_gift_active', [{msg, Format}]})
    end,
    ok.

%% ----------------------------------------------------
%% @doc
%%      推送玩家首充状态
%% @end
%% ----------------------------------------------------
send_first_cash_state(Src) ->
    Msg = {'first_cash_state', [{msg, {}}]},
    login_db:send_all_online(Src, Msg).

%% ----------------------------------------------------
%% @doc
%%      推送城池放弃的信息，
%% @end
%% ----------------------------------------------------
send_corps_abandoning_town(Src, RoleUids, Msg) ->
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'corps_abandoning_town', [{msg, Msg}]})
        end
    end, RoleUids),
    ok.

%% ----------------------------------------------------
%% @doc
%%      推送城池首坐标点，
%% @end
%% ----------------------------------------------------
send_castle_point(Src, RoleUid, Msg) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'new_castle_point', [{msg, Msg}]})
    end.


%% ----------------------------------------------------
%% @doc
%%      建筑攻击中
%%      MBKey为CorpsUid或者TownSid
%% @end
%% ----------------------------------------------------
send_map_build_fight(Src, RoleUids, MBKey, RedFlag) ->
    Msg = {'map_build_fight', [{msg, {MBKey, RedFlag}}]},
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, Msg)
        end
    end, RoleUids).

%% ----------------------------------------------------
%% @doc
%%      周期城池状态改变给全服所有在线玩家推送
%% @end
%% ----------------------------------------------------
send_cycle_town(Src, Msg) ->
    T = {'cycle_town_change', [{msg, Msg}]},
    login_db:send_all_online(Src, T).
%% ----------------------------------------------------
%% @doc
%%      申请结盟推送给被邀请结盟的军团长
%% @end
%% ----------------------------------------------------
send_ally_request(Src, RoleUids, Msg) ->
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'ally_request', [{msg, Msg}]})
        end
    end, RoleUids),
    ok.
%% ----------------------------------------------------
%% @doc
%%      同意结盟之后推送
%% @end
%% ----------------------------------------------------
send_ally_reply(Src, RoleUids, Msg) ->
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'ally_reply', [{msg, Msg}]})
        end
    end, RoleUids),
    ok.
%% ----------------------------------------------------
%% @doc
%%      解散推送
%% @end
%% ----------------------------------------------------
send_ally_delete(Src, RoleUids, Msg) ->
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'ally_delete', [{msg, Msg}]})
        end
    end, RoleUids),
    ok.

%% ----------------------------------------------------
%% @doc
%%      捐献次数达到最大给全军团推送
%% @end
%% ----------------------------------------------------
send_donate_max(Src, RoleUids, Msg) ->
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'donate_max', [{msg, Msg}]})
        end
    end, RoleUids),
    ok.
%% ----------------------------------------------------
%% @doc
%%      盟军成员增加
%% @end
%% ----------------------------------------------------
send_ally_add_member(Src, RoleUids, Msg) ->
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'ally_add_member', [{msg, Msg}]})
        end
    end, RoleUids),
    ok.
%% ----------------------------------------------------
%% @doc
%%      盟军成员减少
%% @end
%% ----------------------------------------------------
send_ally_delete_member(Src, RoleUids, Msg) ->
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'ally_delete_member', [{msg, Msg}]})
        end
    end, RoleUids),
    ok.


%% ----------------------------------------------------
%% @doc
%%      推送跨服战状态
%% @end
%% ----------------------------------------------------
send_cross_battle_state(Src, Wheel, State, StartTime, ContinueTime) ->
    Msg = {'cross_battle_state', [{'msg', {Wheel, State, StartTime, ContinueTime}}]},
    login_db:send_all_online(Src, Msg).

%% ----------------------------------------------------
%% @doc
%%     跨服视野新增
%% @end
%% ----------------------------------------------------
send_add_horizon(Src, RoleUids, PuidVertes) ->
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'add_horizon', [{msg, PuidVertes}]})
        end
    end, RoleUids).

%% ----------------------------------------------------
%% @doc
%%     删除视野
%% @end
%% ----------------------------------------------------
send_del_horizon(Src, RoleUids, PuidVertes) ->
    lists:foreach(fun(Uid) ->
        case login_db:get_online(Src, Uid) of
            none ->
                offline;
            Session ->
                zm_session:send(Session, {'del_horizon', [{msg, PuidVertes}]})
        end
    end, RoleUids).
%% ----------------------------------------------------
%% @doc
%%      有 友军协防/兵临城下
%% @end
%% ----------------------------------------------------
send_assault(Src, RoleUid, Msg) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'assault_info', [{msg, Msg}]})
    end.

%% ----------------------------------------------------
%% @doc
%%      侦查点结束
%% @end
%% ----------------------------------------------------
send_map_spy_build_change(Src, RoleUid, PointUid, ETime) ->
    case login_db:get_online(Src, RoleUid) of
        none ->
            offline;
        Session ->
            zm_session:send(Session, {'map_spy_build_change', [{msg, {PointUid, ETime}}]})
    end.

%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
send_map_ys_state(Src, State, STime) ->
    Msg = {'cmap_ys_state', [{'msg', {State, STime}}]},
    login_db:send_all_online(Src, Msg).