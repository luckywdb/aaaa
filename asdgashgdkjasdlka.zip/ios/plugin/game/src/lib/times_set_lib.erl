%%%=======================notice======================
%% 表名: times_set 各键值:
%%{RoleUid,1}  任务星级奖励领取
%%{RoleUid,2}  副本星级奖励领取
%%{RoleUid,3}  副本奖励宝箱领取
%%{RoleUid,4}  修改名字次数
%%{RoleUid,5}  充值奖励
%%{RoleUid,ShopName} 各商店记录信息
%%{args_system:get_pid(Src), args_system:get_sid(Src), 'shop'} 商品服务器购买信息
%% {args_system:get_pid(Src), args_system:get_sid(Src), 'active'} active_ld中各活动的奖励发放情况
%%{RoleUid,monster} 土匪等级列表
%% RoleUid为键值的 :有等级奖励key=level_award
%% {args_system:get_pid(Src), args_system:get_sid(Src), 'func_not_open'} 不开放的功能id列表
%% {args_system:get_pid(Src), args_system:get_sid(Src), 'recommend_country2'} 变换阵营推荐国家
-module(times_set_lib).
-description("times_set_lib").
-copyright({seasky, 'www.seasky.cn'}).
-author({cb, 'chenbin@youkia.net'}).
-vsn(1).
%%%=======================EXPORT=======================
-export([get/2, get/3, get_value/3, clear/2, update/2]).
-export([get_by_roleuid_key/2, format_by_roleuid_key/1, roleuid_key_init/0]).
-export([get_func_open/1, check_func_open/2]).
-export([server_start_init/1]).
-export([get_recommend_country2/1]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      得到指定类型的操作集合
%% @end
%%-------------------------------------------------------------------
-spec get(TimesSet, Key) -> 'none'|term() when
    TimesSet :: list(),
    Key :: term().
get(TimesSet, Key) ->
    get(TimesSet, Key, 'none').
get(TimesSet, Key, Default) ->
    case lists:keyfind(Key, 1, TimesSet) of
        false ->
            Default;
        R ->
            R
    end.

%%-------------------------------------------------------------------
%% @doc
%%      得到当日/周次数值
%% @end
%%-------------------------------------------------------------------
-spec get_value(TimesSet, Key, 'day' | 'week') -> integer() when
    TimesSet :: list(),
    Key :: term().
get_value(TimesSet, Key, 'day') ->
    Day = time_lib:get_date_by_type('day_of_year'),
    case times_set_lib:get(TimesSet, Key) of
        {_, D1, T1} when D1 =:= Day ->
            T1;
        {_, T1} ->
            T1;
        _ ->
            0
    end;
get_value(TimesSet, Key, 'week') ->
    Day = time_lib:get_date_by_type('week_of_year'),
    case times_set_lib:get(TimesSet, Key) of
        {_, D1, T1} when D1 =:= Day ->
            T1;
        {_, T1} ->
            T1;
        _ ->
            0
    end.

%%-------------------------------------------------------------------
%% @doc
%%      更新指定类型的操作集合
%% @end
%%-------------------------------------------------------------------
-spec update(TimesSet, KV) -> list() when
    TimesSet :: list(),
    KV :: {term(), integer()}|{term(), integer()|atom(), integer()}.
update(TimesSet, {Key, Number}) ->%个人次数
    case get(TimesSet, Key) of
        none ->
            [{Key, Number} | TimesSet];
        {Key, N} ->
            z_lib:list_replace({Key, N}, TimesSet, {Key, Number + N})
    end;
update(TimesSet, {Key, Date, Number} = R) ->%%周期次数
    case get(TimesSet, Key) of
        none ->
            [R | TimesSet];
        {Key, Date, N1} = R1 ->
            z_lib:list_replace(R1, TimesSet, {Key, Date, Number + N1});
        R1 ->
            z_lib:list_replace(R1, TimesSet, R)
    end.

%%-------------------------------------------------------------------
%% @doc
%%      清除更新指定类型的操作集合
%% @end
%%-------------------------------------------------------------------
-spec clear(TimesSet, Key) -> list() when
    TimesSet :: list(),
    Key :: term().
clear(TimesSet, Key) ->
    case get(TimesSet, Key) of
        none ->
            TimesSet;
        _ ->
            lists:keydelete(Key, 1, TimesSet)
    end.


%% ----------------------------------------------------
%% @doc
%%     times_set以RoleUid作为键值数据
%%     等级奖励 [{level_award,等级}]
%%     土匪首杀 [{monster,[土匪sid...]}]
%%     改名字  [{update_name,{上一次修改时间,修改次数}}]
%%     资源点 [{res,等级}]
%%     前台自己存的数据  [{data,int数据}]
%%     分享[{day_share,{int分享时间，int分享次数}}]
%%      喇叭发送时间 [{horn_time,Time}]
%%      是否uc特权用户 [{uc_launch,0}]
%% @end
%% ----------------------------------------------------
get_by_roleuid_key(Src, RoleUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'times_set'), RoleUid, roleuid_key_init()).

%% ----------------------------------------------------
%% @doc
%%     times_set以RoleUid作为键值数据
%%     等级奖励 [{level_award,等级}]
%%     土匪首杀 [{monster,[{土匪类型,等级}]}]
%%     改名字  [{update_name,{上一次修改时间,修改次数}}]
%%     资源点 [{res,等级}]
%%     前台自己存的数据  [{data,int数据}]
%%     分享[{day_share,{int分享时间，int分享次数}}]
%%      喇叭发送时间 [{horn_time,Time}]
%%      是否uc特权用户 [{uc_launch,0}]
%% @end
%% ----------------------------------------------------
format_by_roleuid_key(TimesSet) ->
    list_to_tuple([begin
        NewValue =
            if
                is_list(Value) ->
                    list_to_tuple(Value);
                true ->
                    Value
            end,
        {Key, NewValue}
    end || {Key, Value} <- TimesSet]).

%% ----------------------------------------------------
%% @doc
%%     times_set以RoleUid作为键值数据初始值
%% @end
%% ----------------------------------------------------
roleuid_key_init() ->
    [{'monster', []}, {'res', 0}, {'level_award', 1}, {'update_name', {0, 0}}, {'data', 0}, {'day_share', {0, 0}}].

%% ----------------------------------------------------
%% @doc
%%     功能屏蔽
%% @end
%% ----------------------------------------------------
get_func_open(Src) ->
    Reply = z_db_lib:get(game_lib:get_table(Src, 'times_set'), game_lib:get_server_key(Src, 'func_not_open'), []),
    list_to_tuple(Reply).

%% ----------------------------------------------------
%% @doc
%%     检查功能是否开放
%% @end
%% ----------------------------------------------------
check_func_open(Src, Func) ->
    NotOpen = z_db_lib:get(game_lib:get_table(Src, 'times_set'), game_lib:get_server_key(Src, 'func_not_open'), []),
    not lists:member(Func, NotOpen).

%% ----------------------------------------------------
%% @doc
%%    开服,检测是否需要屏蔽的功能模块
%% @end
%% ----------------------------------------------------
server_start_init(Src) ->
    try
        Fun = fun(_, 'none') ->
            {_, List} = zm_config:get('function_open', 'not_open'),
            {ok, ok, List};
            (_, _) ->
                {ok, ok}
        end,
        z_db_lib:update(game_lib:get_table(Src, 'times_set'), game_lib:get_server_key(Src, 'func_not_open'), 'none', Fun, [])
    catch
        Type:Error ->
            zm_log:warn(?MODULE, ?MODULE, 'init', "error", [{'type', Type}, {'error', Error}, {'stacktrace', erlang:get_stacktrace()}]),
            throw("init_error")
    end.
%% ----------------------------------------------------
%% @doc
%%     获取变换阵营推荐国家
%% @end
%% ----------------------------------------------------
get_recommend_country2(Src) ->
    z_db_lib:get(game_lib:get_table(Src, 'times_set'), game_lib:get_server_key(Src, 'recommend_country2'), 0).