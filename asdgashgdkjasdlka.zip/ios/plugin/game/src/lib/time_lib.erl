%%时间工具
-module(time_lib).

%%%======================STATEMENT=====================
-description("time_lib").
-copyright({seasky, 'www.seasky.cn'}).
-author({zhj, 'zhoujie@youkia.net'}).
-vsn(1).

%%%=======================EXPORT=======================
-export([get_date_by_type/1, get_date_by_type/2, get_current_hour/0, get_current_second/0, get_current_second/1, get_format_time/1]).
-export([get_current_minutes/0, get_current_seconds/0]).
-export([get_week_by_year/0]).
%% 时间相关
-export([date/0, time/0]).
-export([now_minute/0, now_second/0, now_millisecond/0, now_second/1, now_millisecond/1]).
%%
-export([day_two_date/2, day_two_second/2, get_two_days_second/1, get_two_days_second/2, get_zero_time/1, get_time_week/2]).

-export([reset_difference_time/0, get_difference_time/0, set_difference_time/1]).

-export([show/1]).
%%%=======================INCLUDE======================

%%%=======================RECORD=======================

%%%=======================DEFINE=======================
-define(WEEKEND, 7).
-define(MINUTE_SECOND, 60).
-define(DIFFERENCE_TIME, server_difference_time).%差异时间

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%     获取传入时间的当天0点秒数
%% @end
%% ----------------------------------------------------
get_zero_time(Now) ->
    {_, {H, M, S}} = z_lib:second_to_localtime(Now),%%获得日期
    Now - (H * 60 * 60 + M * 60 + S).

%% ----------------------------------------------------
%% @doc
%%  获取传入time后第一个周Week时间戳
%% @end
%% ----------------------------------------------------
get_time_week(Time, Week) ->
    {Date, _} = z_lib:second_to_localtime(Time),
    CurWeek = calendar:day_of_the_week(Date),
    if
        CurWeek < Week ->
            get_zero_time(Time) + (Week - CurWeek) * 86400;
        true ->
            get_zero_time(Time) + (7 - CurWeek + Week) * 86400
    end.

%% ----------------------------------------------------
%% @doc
%%      获得周期时间
%% @end
%% ----------------------------------------------------
get_date_by_type(Type) ->
    {Y, M, D} = time_lib:date(),
    get_date_by_type_(Type, Y, M, D).
get_date_by_type(Type, Sce) ->
    {{Y, M, D}, _} = z_lib:second_to_localtime(Sce),
    get_date_by_type_(Type, Y, M, D).
get_date_by_type_('day_of_year', Y, M, D) ->
    zm_dtimer:day_of_year(Y, M, D);
get_date_by_type_('day_of_week', Y, M, D) ->
    calendar:day_of_the_week({Y, M, D});
get_date_by_type_('week_of_year', Y, M, D) ->
    zm_dtimer:week_of_year(Y, M, D);
get_date_by_type_('year', Y, _M, _D) ->
    Y;
get_date_by_type_('month', _Y, M, _D) ->
    M;
get_date_by_type_('day', _Y, _M, D) ->
    D.

%% ----------------------------------------------------
%% @doc
%%     获得服务器当前小时
%% @end
%% ----------------------------------------------------
get_current_hour() ->
    {_, {Hour, _, _}} = z_lib:second_to_localtime(now_second()),
    Hour.

%% ----------------------------------------------------
%% @doc
%%     获得服务器当前分
%% @end
%% ----------------------------------------------------
get_current_minutes() ->
    {_, {_, Value, _}} = z_lib:second_to_localtime(now_second()),
    Value.

%% ----------------------------------------------------
%% @doc
%%     获得服务器当前秒
%% @end
%% ----------------------------------------------------
get_current_seconds() ->
    {_, {_, _, Value}} = z_lib:second_to_localtime(now_second()),
    Value.

%% ----------------------------------------------------
%% @doc
%%     获得服务器当前秒数(0点开始计算)
%% @end
%% ----------------------------------------------------
get_current_second() ->
    {_, {H, M, S}} = z_lib:second_to_localtime(now_second()),
    (H * 60 + M) * 60 + S.

%% ----------------------------------------------------
%% @doc
%%     根据该时间,获得当前秒数(0点开始计算)
%% @end
%% ----------------------------------------------------
get_current_second(Second) ->
    {_, {H, M, S}} = z_lib:second_to_localtime(Second),
    (H * 60 + M) * 60 + S.

%% ----------------------------------------------------
%% @doc
%%     获得格式化时间，小于10的月日时分补0
%% @end
%% ----------------------------------------------------
get_format_time(T) ->
    if
        T < 10 ->
            binary_to_list(list_to_binary(["0", integer_to_list(T)]));
        true ->
            T
    end.

%% ----------------------------------------------------
%% @doc
%%     获得日期
%% @end
%% ----------------------------------------------------
date() ->
    element(1, z_lib:second_to_localtime(now_second())).

%% ----------------------------------------------------
%% @doc
%%    获得时间
%% @end
%% ----------------------------------------------------
time() ->
    element(2, z_lib:second_to_localtime(now_second())).

%% ----------------------------------------------------
%% @doc
%%     获得时间(分)
%% @end
%% ----------------------------------------------------
now_minute() ->
    now_second() div ?MINUTE_SECOND.

%% ----------------------------------------------------
%% @doc
%%      获得时间(秒)
%% @end
%% ----------------------------------------------------
now_second() ->
    z_lib:now_second() + get_difference_time().

%% ----------------------------------------------------
%% @doc
%%      获得时间(毫秒)
%% @end
%% ----------------------------------------------------
now_millisecond() ->
    z_lib:now_millisecond() + get_difference_time() * 1000.

%% ----------------------------------------------------
%% @doc
%%      获得时间(秒)
%% @end
%% ----------------------------------------------------
now_second(Time) ->
    Time + get_difference_time().

%% ----------------------------------------------------
%% @doc
%%      获得时间(毫秒)
%% @end
%% ----------------------------------------------------
now_millisecond(Time) ->
    Time + get_difference_time() * 1000.

%% ----------------------------------------------------
%% @doc
%%      获取两个日期之间的天数(绝对值) 包含两个临界点
%% @end
%% ----------------------------------------------------
day_two_date({Date1, _}, {Date2, _}) ->
    day_two_date(Date1, Date2);
day_two_date({Y, M, D} = Date1, {Y1, M1, D1} = Date2) when Date1 > Date2 ->
    day_two_date_({Y1, M1}, {Y, M}, D - D1 + 1);
day_two_date({Y, M, D}, {Y1, M1, D1}) ->
    day_two_date_({Y, M}, {Y1, M1}, D1 - D + 1).

day_two_date_({Y, M}, {Y, M}, Day) ->
    Day;
day_two_date_({Y, M}, {Y1, M1}, Day) when M1 > 1 ->
    day_two_date_({Y, M}, {Y1, M1 - 1}, calendar:last_day_of_the_month(Y1, M1 - 1) + Day);
day_two_date_({Y, M}, {Y1, _}, Day) ->
    day_two_date_({Y, M}, {Y1 - 1, 12}, calendar:last_day_of_the_month(Y1 - 1, 12) + Day).

%% ----------------------------------------------------
%% @doc
%%      获取两个秒钟时间之间的天数(绝对值) 包含两个临界点
%% @end
%% ----------------------------------------------------
day_two_second(Time1, Time2) ->
    day_two_date(element(1, z_lib:second_to_localtime(Time1)), element(1, z_lib:second_to_localtime(Time2))).

%% ----------------------------------------------------
%% @doc
%%      今天所在星期是一年中的第几个星期
%% @end
%% ----------------------------------------------------
get_week_by_year() ->
    Year = get_date_by_type('year'),
    Week = calendar:day_of_the_week(Year, 1, 1),
    Days = get_date_by_type('day_of_year'),
    string_lib:ceil((Days - Week + 1) / ?WEEKEND) + 1.

%% ----------------------------------------------------
%% @doc
%%      获取两个日期之间的差异秒 后一个-前一个
%% @end
%% ----------------------------------------------------
get_two_days_second(Day1, Day2) when is_integer(Day1) andalso is_integer(Day2) ->
    Day2 - Day1;
get_two_days_second(Day1, Day2) when is_integer(Day1) andalso is_tuple(Day2) ->
    z_lib:localtime_to_second(Day2) - Day1;
get_two_days_second(Day1, Day2) when is_tuple(Day1) andalso is_tuple(Day2) ->
    z_lib:localtime_to_second(Day2) - z_lib:localtime_to_second(Day1);
get_two_days_second(Day1, Day2) ->
    Day2 - z_lib:localtime_to_second(Day1).
%%目标日期和今天的差异秒
get_two_days_second(Day2) when is_integer(Day2) ->
    Day2 - now_second();
get_two_days_second(Day2) ->
    z_lib:localtime_to_second(Day2) - now_second().

%% ----------------------------------------------------
%% @doc
%%     重置差异时间
%% @end
%% ----------------------------------------------------
-spec reset_difference_time() -> integer().
reset_difference_time() ->
    zm_config:set(?MODULE, {?DIFFERENCE_TIME, 0}),
    time_lib:now_second().

%% ----------------------------------------------------
%% @doc
%%     设置差异时间
%% @end
%% ----------------------------------------------------
-spec set_difference_time(Time :: integer()) -> integer().
set_difference_time(Time) ->
    zm_config:set(?MODULE, {?DIFFERENCE_TIME, get_difference_time() + Time}),
    time_lib:now_second().

%% ----------------------------------------------------
%% @doc
%%     获得差异时间
%% @end
%% ----------------------------------------------------
-spec get_difference_time() -> integer().
get_difference_time() ->
    case zm_config:get(?MODULE, ?DIFFERENCE_TIME) of
        none ->
            0;
        {_, Time} ->
            Time
    end.

%% ----------------------------------------------------
%% @doc
%%     格式化时间显示
%%     "2014-01-31 00:00:00" | "2014-01-31 00:00:00 560"
%% @end
%% ----------------------------------------------------
show(Time) when is_integer(Time) ->
    show(z_lib:second_to_localtime(Time));
show({{Y, M, D}, {H, Min, S}}) ->
    lists:concat([z_lib:integer_to_list(Y, 4),
        "-", z_lib:integer_to_list(M, 2),
        "-", z_lib:integer_to_list(D, 2),
        " ", z_lib:integer_to_list(H, 2),
        ":", z_lib:integer_to_list(Min, 2),
        ":", z_lib:integer_to_list(S, 2)]).

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------