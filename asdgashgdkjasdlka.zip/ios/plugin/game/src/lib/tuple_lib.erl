%%元组工具
-module(tuple_lib).
-description("tuple_lib").
-copyright({seasky, 'www.seasky.cn'}).
-author({cb, 'chenbin@youkia.net'}).
-vsn(1).

%%%=======================EXPORT=======================
-export([tuple_member/2, tuple_delete/2, tuple_index/2, middle_search/3, check_all_element/2]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD====================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% Func: tuple_member/2
%% Description: elem是否在元组中
%% Returns: ture | false
%% ----------------------------------------------------
tuple_member(Elem, Tuple) ->
    0 =/= tuple_index(Elem, Tuple).

%% ----------------------------------------------------
%% Func: tuple_delete/2
%% Description: 删除元组中elem
%% Returns: tuple
%% ----------------------------------------------------
tuple_delete(Elem, Tuple) ->
    case tuple_index(Elem, Tuple) of
        0 ->
            Tuple;
        Index ->
            erlang:delete_element(Index, Tuple)
    end.

%% ----------------------------------------------------
%% Func: tuple_index/2
%% Description: elem在元组中位置
%% Returns: 0 | integer
%% ----------------------------------------------------
tuple_index(Elem, Tuple) ->
    tuple_index(Elem, 1, size(Tuple), Tuple).
tuple_index(Elem, Min, Max, Tuple) when Min =< Max ->
    case erlang:element(Min, Tuple) of
        Elem ->
            Min;
        _ ->
            tuple_index(Elem, Min + 1, Max, Tuple)
    end;
tuple_index(_Elem, _Min, _Max, _Tuple) ->
    0.

%% ----------------------------------------------------
%% Func: middle_search/3
%% Description: 二分法查找
%% @param Tuple 有序的元组(从小到大或从大到小)
%% @param Sign 检验值(在Fun方法的第一位,和取出值相比)
%% @param Fun 判断方法(两参,检验值在1,比较值在2),返还值为(从小到大(0相等,-1小于,1大于),从大到小(0相等,-1大于,1小于))
%% Returns:index(Sign在元组中的位置,(若有相同值,是相同值的位置,若无相同值,则是该值排序的插入位置))
%% ----------------------------------------------------
middle_search(Tuple, Sign, Fun) when is_function(Fun) ->
    middle_search(Tuple, 1, tuple_size(Tuple), Sign, Fun).

middle_search(Tuple, Low, High, Sign, Fun) when Low >= High ->
    Max = tuple_size(Tuple),
    Low1 = if
        Low =< 1 ->
            1;
        true ->
            Low - 1
    end,
    High1 = if
        High >= Max ->
            Max;
        true ->
            High + 1
    end,
    sequence_search(Tuple, Low1, High1, Sign, Fun);
middle_search(Tuple, Low, High, Sign, Fun) ->
    Mid = (High + Low) div 2,
    V = element(Mid, Tuple),
    case Fun(Sign, V) of
        0 -> %% 等于
            Mid;
        1 ->%% 后半段
            middle_search(Tuple, Mid + 1, High, Sign, Fun);
        -1 ->%% 前半段
            middle_search(Tuple, Low, Mid - 1, Sign, Fun)
    end.

%% ----------------------------------------------------
%% Func: sequence_search/5
%% Description: 顺序查找(所在位置或者该放位置)
%% Returns:index
%% ----------------------------------------------------
sequence_search(_, Low, High, _, _) when Low > High ->
    Low;
sequence_search(Tuple, Low, High, Sign, Fun) ->
    V = element(Low, Tuple),
    case Fun(Sign, V) of
        1 ->
            sequence_search(Tuple, Low + 1, High, Sign, Fun);
        _ ->
            Low
    end.

%% ----------------------------------------------------
%% Func: check_all_element/2
%% Description: 校验tuple中所有都是element元素
%% Returns: bool
%% ----------------------------------------------------
check_all_element(Tuple, Element) ->
    check_all_element(Tuple, size(Tuple), Element).
check_all_element(Tuple, Min, Element) when Min > 0 ->
    case erlang:element(Min, Tuple) =:= Element of
        false ->
            false;
        _ ->
            check_all_element(Tuple, Min - 1, Element)
    end;
check_all_element(_, _, _) ->
    true.