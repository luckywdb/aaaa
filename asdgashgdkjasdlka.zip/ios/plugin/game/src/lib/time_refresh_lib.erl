-module(time_refresh_lib).

%%%=======================STATEMENT====================
-description("游戏周期时间更新类").
-copyright('youkia,www.youkia.net').
-author("zjx,zhaojunxian@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([check/3, check/5]).
%%%=======================INCLUDE======================

%%%=======================RECORD=======================

%%%=======================DEFINE=======================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      根据类型,在timeSet中检查,是否可以刷新  {true,nowTime}|{false,oldTime}
%% @end
%% ----------------------------------------------------
-spec check(TimeSet, Type, TimeKey) -> {boolean(), integer()} when
    TimeSet :: list(),
    Type :: atom(),
    TimeKey :: term().
check(TimeSet, Type, TimeKey) ->
    case times_set_lib:get(TimeSet, TimeKey) of
        none ->
            {true, time_lib:now_second()};
        Times ->
            OldTime = case Times of
                {_, Time1} ->
                    Time1;
                {_, Time2, _} ->
                    Time2
            end,
            {OldYMD, _} = z_lib:second_to_localtime(OldTime),
            {_, TimeAxle} = zm_config:get('time_refresh_config', Type),
            check(OldYMD, OldTime, TimeAxle, time_lib:date(), time_lib:now_second())
    end.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%      校验是否进行刷新（分小时段）
%% @end
%% ----------------------------------------------------
-spec check(OldYMD, OldTime, TimeAxle, NowYMD, NowTime) -> {boolean(), integer()} when
    OldYMD :: {integer(), integer(), integer()},
    OldTime :: integer(),
    TimeAxle :: list(),
    NowYMD :: {integer(), integer(), integer()},
    NowTime :: integer().
check(YMD, OldTime, TimeAxle, YMD, NowTime) ->
    I1 = check_(time_lib:get_current_second(OldTime), TimeAxle, 1),
    I2 = check_(time_lib:get_current_second(NowTime), TimeAxle, 1),
    if
        I1 =:= I2 ->
            {false, OldTime};
        true ->
            {true, NowTime}
    end;
check(OldYMD, OldTime, TimeAxle, _NowYMD, NowTime) ->
    I1 = check_(time_lib:get_current_second(OldTime), TimeAxle, 1),
    Bool = (length(TimeAxle) + 1) =/= I1,%%是否为当时的最后一个节点
    if
        Bool -> %% 不是，说明可以进行更新
            {true, NowTime};
        true -> %% 查看当前的时间是否过原抽取时第二天第一个节点
            {H, M, S} = lists:nth(1, TimeAxle),
            %% 当前时间是否比上次更新时间后一天的第一个节点时间大
            Bool1 = NowTime > (z_lib:localtime_to_second({OldYMD, {H, M, S}}) + 24 * 3600),
            if
                Bool1 ->
                    {true, NowTime};
                true ->
                    {false, OldTime}
            end
    end.

check_(Time, [{H, M, S} | T], Index) ->
    if
        Time < H * 60 * 60 + M * 60 + S ->
            Index;
        true ->
            check_(Time, T, Index + 1)
    end;
check_(_Time, [], Index) ->
    Index.
