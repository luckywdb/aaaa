-module(push_message_lib).

%%%=======================STATEMENT====================
-description("推送通知").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([push/4, push_str/4, notify_push_event/4]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================
-define(TIME_OUT, 7000).
-define(UNKNOWN, 0).%未知
-define(ANDROID, 1).%android
-define(IOS, 2).%ios
-define(ANDROID_URL, "/game_app/android_push/insert_push?").
-define(IOS_URL, "/game_app/ios_push/insert_push?").

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%     推送消息
%%      玩家离线在线都推送,是否显示该通知由sdk来决定;由于玩家将游戏切换到后台之后玩家socket是没有断的,
%%      后台服务器上玩家一直在线的,但这种情况策划是需要推送的,所以由sdk去处理
%% @end
%% ----------------------------------------------------
push(Src, RoleUid, PushType, PushArgs) when is_integer(RoleUid) ->
    push(Src, [RoleUid], PushType, PushArgs);
push(Src, RoleUids, PushType, PushArgs) when is_list(RoleUids) ->
    zm_event:notify(Src, 'push_message', [
        {'pushtype', PushType},
        {'pushArgs', PushArgs},
        {'roleUids', RoleUids}]).

%%-------------------------------------------------------------------
%% @doc
%%     推送字符串消息
%% @end
%%-------------------------------------------------------------------
push_str(Src, RoleUid, Msg, Pids) when is_integer(RoleUid) ->
    push_str(Src, [RoleUid], Msg, Pids);
push_str(Src, RoleUids, Msg, Pids) when is_list(RoleUids) ->
    zm_event:notify(Src, 'push_message', [
        {'str', Msg},
        {'pids', Pids},
        {'roleUids', RoleUids}]).

notify_push_event(_, Src, _Type, Args) ->
    StrMsg = z_lib:get_value(Args, 'str', 'none'),
    {_, RoleUids} = lists:keyfind('roleUids', 1, Args),
    {AndroidMsgs, IosMsgs} =
        case StrMsg =:= 'none' of
            true ->
                {_, PushType} = lists:keyfind('pushtype', 1, Args),
                {_, PushArgs} = lists:keyfind('pushArgs', 1, Args),
                lists:foldl(fun(RoleUid, {Acc0, Acc1}) ->
                    case drama_db:chk_push_setting(Src, RoleUid, PushType) of
                        true ->
                            GUser = user_db:get_user(Src, RoleUid),
                            OSystem = guser:get_o_system(GUser),
                            RoleShow = role_db:get_role_show(Src, RoleUid),
                            RoleName = role_show:get_name(RoleShow),
                            if
                                OSystem =:= ?ANDROID ->
                                    {[{RoleUid, game_lib:get_language({'push', PushType}, [RoleName | PushArgs])} | Acc0], Acc1};
                                OSystem =:= ?IOS ->
                                    case guser:get_push_id(GUser) of
                                        0 ->
                                            {Acc0, Acc1};
                                        "(null)" ->
                                            {Acc0, Acc1};
                                        DId ->
                                            {Acc0, [{DId, game_lib:get_language({'push', PushType}, [RoleName | PushArgs])} | Acc1]}
                                    end;
                                true ->
                                    {Acc0, Acc1}
                            end;
                        false ->
                            {Acc0, Acc1}
                    end
                end, {[], []}, RoleUids);
            false ->
                {_, Pids} = lists:keyfind('pids', 1, Args),
                lists:foldl(fun(RoleUid, {Acc0, Acc1}) ->
                    GUser = user_db:get_user(Src, RoleUid),
                    OSystem = guser:get_o_system(GUser),
                    Pid = guser:get_platform_id(GUser),
                    RoleShow = role_db:get_role_show(Src, RoleUid),
                    RoleName = role_show:get_name(RoleShow),
                    case Pids =:= [] orelse lists:member(Pid, Pids) of
                        true ->
                            if
                                OSystem =:= ?ANDROID ->
                                    {[{RoleUid, lists:concat([RoleName, ":", StrMsg])} | Acc0], Acc1};
                                OSystem =:= ?IOS ->
                                    case guser:get_push_id(GUser) of
                                        0 ->
                                            {Acc0, Acc1};
                                        "(null)" ->
                                            {Acc0, Acc1};
                                        DId ->
                                            {Acc0, [{DId, lists:concat([RoleName, ":", StrMsg])} | Acc1]}
                                    end;
                                true ->
                                    {Acc0, Acc1}
                            end;
                        false ->
                            {Acc0, Acc1}
                    end
                end, {[], []}, RoleUids)
        end,
    if
        AndroidMsgs =/= [] ->
            PushAndroidUrl = args_expend:get_push_url(Src) ++ ?ANDROID_URL,
            DataAndroid = [{'role_msgs', AndroidMsgs}],
            send_push(PushAndroidUrl, DataAndroid);
        true ->
            'ok'
    end,
    if
        IosMsgs =/= [] ->
            PushIosUrl = args_expend:get_push_url(Src) ++ ?IOS_URL,
            DataIos = [{'role_msgs', IosMsgs}],
            send_push(PushIosUrl, DataIos);
        true ->
            'ok'
    end.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%      android推送消息
%% @end
%% ----------------------------------------------------
send_push(PushUrl, Data) ->
    try
        case zm_communicator:request('http_connect_asyn_binary', 'post', [PushUrl, term_to_binary(Data)], ?TIME_OUT) of
            {{_, _, "OK"}, _, Result} ->
                Reply = match_lib:analysis(Result),
                if
                    Reply =:= "ok" ->
                        'ok';
                    true ->
                        zm_log:warn(?MODULE, ?MODULE, 'result', "web_error1", [{'error', Reply}, {'data', Data}]),
                        "error"
                end;
            Other ->
                zm_log:warn(?MODULE, ?MODULE, 'result', "web_error2", [{'error', Other}, {'data', Data}]),
                "web_error"
        end
    catch
        Type:Error ->
            zm_log:warn(?MODULE, ?MODULE, 'push', "error", [{e, Type}, {e1, Error}, {'data', Data},
                {'stacktrace', erlang:get_stacktrace()}]),
            "handle_error"
    end.