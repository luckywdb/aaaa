-module(game_types).

%%%=======================STATEMENT====================
-description("通用模块types").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export_type([session/0, attr/0, kv/0, port_reply/0]).
%%%=======================INCLUDE======================

%%%=======================RECORD======================

%%%=======================DEFINE=======================

%%%=======================TYPE=========================
-type session() :: 'none'|'nil'|tuple().%session结构
-type attr() :: 'none'|'nil'|tuple().%Attr结构
-type kv() :: {atom() | string() | integer(), term()}.  %kv结构type
-type port_reply() :: {'ok'|'break', list(), list(), [{'msg', term()}]|list()}.%port端口返回

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
