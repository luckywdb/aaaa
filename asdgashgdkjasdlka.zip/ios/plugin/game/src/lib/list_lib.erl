%%列表工具
-module(list_lib).
-description("list_lib").
-copyright({seasky, 'www.seasky.cn'}).
-author({cb, 'chenbin@youkia.net'}).
-vsn(1).

%%%=======================EXPORT=======================
-export([list_index/2, list_key_index/3, random_pool_value/2, list_key_index_value/3]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD====================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% Func: list_index/2
%% Description: 查找元素在list中的index
%% Returns: integer
%% ----------------------------------------------------
list_index({'team', Key, _Team}, List) ->
    list_index(Key, List, 0);
list_index(Elem, List) ->
    list_index(Elem, List, 0).
list_index(Elem, [Elem | _], Index) ->
    Index + 1;
list_index(Elem, [_ | T], Index) ->
    list_index(Elem, T, Index + 1);
list_index(_, [], _) ->
    0.

%% ----------------------------------------------------
%% Func: list_key_index/3
%% Description: 查找以tuple为元素的list中第N位为key的index
%% Returns: integer
%% ----------------------------------------------------
list_key_index(Key, N, List) ->
    list_key_index(Key, N, List, 0).
list_key_index(Key, N, [Elem | T], Index) ->
    case element(N, Elem) of
        Key ->
            Index + 1;
        _ ->
            list_key_index(Key, N, T, Index + 1)
    end;
list_key_index(_, _, [], _) ->
    0.

%% ----------------------------------------------------
%% Func: list_key_index_value/3
%% Description: 查找以tuple为元素的list中第N位为key的index和值
%% Returns: integer
%% ----------------------------------------------------
list_key_index_value(Key, {N, M}, List) ->
    list_key_index_value(Key, {N, M}, List, 0).
list_key_index_value(Key, {N, M}, [Elem | T], Index) ->
    case element(N, Elem) of
        Key ->
            {Index + 1, element(M, Elem)};
        _ ->
            list_key_index_value(Key, {N, M}, T, Index + 1)
    end;
list_key_index_value(_, _, [], _) ->
    {0, 0}.

%% ----------------------------------------------------
%% Func: random_pool_value/2
%% Description: 随机times次 池中的值
%% Returns: integer
%% ----------------------------------------------------
random_pool_value(List, Times) ->
    random_pool_value(List, Times, []).
random_pool_value(List, Times, R) when Times > 0 ->
    Value = game_lib:random_value(List),
    case filter(List, Value, []) of
        [] ->
            [Value | R];
        L ->
            random_pool_value(L, Times - 1, [Value | R])
    end;
random_pool_value(_, _, R) ->
    R.

filter([_, Value | T], Value, R) ->
    lists:reverse(R, T);
filter([Weight, Value | T], V, R) ->
    filter(T, V, [Value, Weight | R]);
filter([], _, R) ->
    R.
