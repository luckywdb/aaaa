-module(network_server).

%%%=======================STATEMENT====================
-description("network_server").
-copyright('youkia,www.youkia.net').
-author("lb,luobo@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([init/1, code_change/3, handle_call/3, handle_cast/2, handle_info/2, handle_notify/4, start_link/1, terminate/2]).
-export([event_notify/4]).
%%%=======================INCLUDE======================
%%%=======================RECORD=======================
-record(state, {src}).
%%%=======================DEFINE=======================
-define(SNAPSHOT_TABLE_LIST, snapshot_table_list_net_work). %快照缓存表名字
%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% Func: 
%% Description: 
%% Returns: 
%% ----------------------------------------------------
start_link(Src) ->
    case init:get_argument(statue) of
        {ok, [["network"]]} ->%只有内网的服务器才执行此功能
            error_logger:tty(false),%关闭控制台的GM错误提醒
            gen_server:start_link({local, ?MODULE}, ?MODULE, [Src], []);
        Other ->
            zm_log:warn(Src, ?MODULE, ?MODULE, "server_close", [Other])
    end.

init([Src]) ->
    timer_update_erl(),
    timer_snapshot(),
    {ok, #state{src = Src}}.

handle_call(_Request, _From, State) ->
    Reply = ok,
    {reply, Reply, State, 3000}.

handle_cast(_Msg, State) ->
    {noreply, State, 3000}.

handle_info(timer_snapshot, #state{src = Src} = State) ->%每天快照
    try
        %先将所有的数据库进行缓存
        lists:foreach(fun({Tablename, _, List}) ->
            case lists:keyfind(type, 1, List) of
                {_, file} ->
                    zm_config:set(?SNAPSHOT_TABLE_LIST, {Tablename, running});
                _ ->
                    ok
            end
        end, zm_db:list()),
        %然后执行快照
        snapshot(zm_db_server:table_status())
    catch E1:E2 ->
        timer_snapshot(),
        zm_log:warn(Src, ?MODULE, ?MODULE, "timer_update_erl_error", [E1, E2, erlang:get_stacktrace()])
    end,
    {noreply, State, hibernate};
handle_info(timer_update_erl, #state{src = Src} = State) ->%更新代码的定时器
    try
        code_lib:dynamic_update(Src, 1),
        timer_update_erl()
    catch E1:E2 ->
        timer_update_erl(),
        zm_log:warn(Src, ?MODULE, ?MODULE, "timer_update_erl_error", [E1, E2, erlang:get_stacktrace()])
    end,
    {noreply, State, hibernate};
handle_info(timeout, State) ->
    {noreply, State, hibernate};
handle_info(_Info, State) ->
    {noreply, State, 3000}.

terminate(_Reason, _State) ->
    ok.

code_change(_OldVsn, State, _Extra) ->
    {ok, State}.
%% -----------------------------------------------------------------
%% Function: handle_notify/4
%% Purpose: server exit message
%% Returns: {ok,pid}
%% -----------------------------------------------------------------
handle_notify([Src], zm_pid, pid_exit, {{?MODULE, _}, _} = Msg) ->
    zm_log:warn(Src, ?MODULE, server_notify, pid_exit, [{error, Msg}]),
    zm_pid:create(?MODULE, fun() -> ?MODULE:start_link(Src) end);
handle_notify(_, zm_pid, pid_exit, _) ->
    ok.

%%%===================LOCAL FUNCTIONS==================
%半小时更新一次代码
timer_update_erl() ->
    timer:send_after(1800000, timer_update_erl).
%每天执行一次快照,并且捡走数据库
timer_snapshot() ->
    zm_log:warn(yxzh, ?MODULE, ?MODULE, "timer_snapshot", []),
    timer:send_after(86400000, timer_snapshot).


%% ----------------------------------------------------
%% Func: event_notify/4
%% Description: 接收底层数据库在快照完成时抛出的事件
%% Returns: 
%% ----------------------------------------------------
event_notify(_, Src, snapshot_ok, TableName) ->
    case init:get_argument(statue) of
        {ok, [["network"]]} ->%只有内网的服务器才执行此功能
            %删除已经快照完成表的缓存信息
            zm_config:delete(?SNAPSHOT_TABLE_LIST, TableName),
            Result = zm_config:get(?SNAPSHOT_TABLE_LIST),
            if
                length(Result) =< 0 ->%快照完成
                    zm_log:warn(Src, ?MODULE, ?MODULE, "snapshot_ok_start", []),
                    os:cmd("sh ../delete_db.sh"),%清理多余数据
                    zm_log:warn(Src, ?MODULE, ?MODULE, "snapshot_ok_end", []),
                    timer_snapshot();%重新定时快照
                true ->
                    ok
            end;
        Other ->
            zm_log:warn(Src, ?MODULE, ?MODULE, "snapshot_ok_lose", [Other])
    end.
%% ----------------------------------------------------
%% Func: snapshot/1
%% Description: 每张数据库表执行快照
%% Returns: 
%% ----------------------------------------------------
snapshot([H | T]) ->
    {_, Pid} = lists:keyfind(pid, 1, H),
    case zm_db_table:get_storage(Pid) of
        {'zm_storage_memory', _} ->
            snapshot(T);
        {M, A} ->
            M:snapshot(A),
            timer:sleep(100),
            snapshot(T)
    end;
snapshot([]) ->
    ok.
%% ----------------------------------------------------
%% Func: 
%% Description: 
%% Returns: 
%% ----------------------------------------------------