%%字符串工具
-module(string_lib).
-description("string_lib").
-copyright({seasky, 'www.seasky.cn'}).
-author({cb, 'chenbin@youkia.net'}).
-vsn(1).

%%%=======================EXPORT=======================
-export([to_atom/1, to_atom/2, content/2, compute_size/1, to_string/1, to_unicode/1, ceil/1]).
-export([check_str/2, check_content/1, replace/2, handle_mask/1]). %%剔除非法字符
-export([delete_list/2, string_with_start/2, string_with_end/2, string_with_exist/2, string_cutting/2, string_cutting/3]).
-export([convert_string/1, tokens/2]).
-export([string_to_term/1, str_check_to_term/1, term_to_string/1]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD====================

%%%=================EXPORTED FUNCTIONS=================
%-------------------------------------------------------------------
% Func:delete_list/2
% description: 将List1从List2中删除
% Return:
%-------------------------------------------------------------------
delete_list([H | T], List2) ->
    delete_list(T, lists:delete(H, List2));
delete_list([], List) ->
    List.
%-------------------------------------------------------------------
% Func:ceil/1
% description: 向上取整
% Return:
%-------------------------------------------------------------------
ceil(N) ->
    T = trunc(N),
    case N == T of
        true -> T;
        false -> 1 + T
    end.
%-------------------------------------------------------------------
% Func:to_atom/1 | to_atom/2
% description: 将数据转成原子
% Return:
%-------------------------------------------------------------------
to_atom(Value) ->
    try
        erlang:list_to_existing_atom(Value)
    catch
        _:_ ->
            erlang:list_to_atom(Value)
    end.
to_atom(A1, A2) when is_atom(A1), is_atom(A2) ->
    to_atom(atom_to_list(A1) ++ atom_to_list(A2));
to_atom(A1, A2) when is_atom(A1), is_list(A2) ->
    to_atom(atom_to_list(A1) ++ A2);
to_atom(A1, A2) when is_atom(A1), is_integer(A2) ->
    to_atom(atom_to_list(A1) ++ integer_to_list(A2));
to_atom(A1, A2) when is_list(A1), is_atom(A2) ->
    to_atom(A1 ++ atom_to_list(A2));
to_atom(A1, A2) when is_integer(A1), is_atom(A2) ->
    to_atom(integer_to_list(A1) ++ atom_to_list(A2));
to_atom(A1, A2) when is_list(A1), is_list(A2) ->
    to_atom(A1 ++ A2);
to_atom(A1, A2) when is_list(A1), is_integer(A2) ->
    to_atom(A1 ++ integer_to_list(A2));
to_atom(A1, A2) when is_integer(A1), is_list(A2) ->
    to_atom(integer_to_list(A1) ++ A2);
to_atom(A1, A2) when is_integer(A1), is_integer(A2) ->
    to_atom(integer_to_list(A1) ++ integer_to_list(A2)).
%-------------------------------------------------------------------
% Func:content/2
% description:替换变量 Str需要替换的原始语句,Args变量值
% Return:
%-------------------------------------------------------------------
content(String, Args) ->
    content(String, Args, []).
content([$$, $v, $a, $r | String], Args, List) ->
    case Args of
        [] ->
            content(String, Args, [$r, $a, $v, $$ | List]);
        [A | AT] when is_list(A) ->
            content(String, AT, content_(A, List));
        [A | AT] when is_number(A) ->
            content(String, AT, content_(erlang:integer_to_list(A), List));
        [A | AT] when is_atom(A) ->
            content(String, AT, content_(erlang:atom_to_list(A), List))
    end;
content([H | String], Args, List) ->
    content(String, Args, [H | List]);
content([], _Args, List) ->
    lists:reverse(List).
content_([H | T], List) ->
    content_(T, [H | List]);
content_([], List) ->
    List.
%-------------------------------------------------------------------
% Func: compute_size/1
% description: 计算字符串长度，中文算2个长度
% notice: X >= 16#4e00 andalso X =< 16#9fff ->%%判断中文
% Return:
%-------------------------------------------------------------------
compute_size(Str) ->
    lists:foldl(fun(X, Sum) ->
        if
            X >= 128 ->
                Sum + 2;
            true ->
                Sum + 1
        end
    end, 0, Str).
%% ----------------------------------------------------
%% Func: to_string/1 
%% Description: key转成sql string
%% Returns:
%% ----------------------------------------------------
to_string(Term) ->
    binary_to_list(list_to_binary(z_lib:string(Term))).

%% ----------------------------------------------------
%% Func: to_unicode/1 
%% Description: 强转unicode
%% Returns:
%% ----------------------------------------------------
to_unicode(Term) ->
    try
        xmerl_ucs:to_unicode(Term, 'utf-8')
    catch
        _:_ ->
            Term
    end.

%% ----------------------------------------------------
%% Func: check_content/1
%% Description: 检查屏蔽字
%% Returns: true是屏蔽字 | false 不是屏蔽字
%% ----------------------------------------------------
check_content(Input) ->
    {_, MaskWordS} = zm_config:get('mask_word', mask),
    lists:all(fun(MaskWord) -> string_with_exist(string:strip(Input), MaskWord) end, MaskWordS).

%% ----------------------------------------------------
%% Func: check_str/1
%% Description: 检查屏蔽字
%% Returns: true是有屏蔽字在内
%% ----------------------------------------------------
check_str(Src, S) ->
    check_str1(Src, string:to_lower(S)).
check_str1(Src, [H | T] = S) ->
    case z_db_lib:get(game_lib:get_table(Src, 'handled_mask'), [H], none) of%%检测是否有以H开头的屏蔽词关键字
        none ->
            check_str1(Src, T);
        MaskList ->
            case check_str1(S, [], MaskList) of
                false ->
                    check_str1(Src, T);
                true ->
                    true
            end
    end;
check_str1(_, []) ->
    false.
check_str1([H | T], Str, List) ->
    Str1 = [H | Str],
    Bool = lists:member(lists:reverse(Str1), List),
    if
        Bool ->
            true;
        true ->
            check_str1(T, Str1, List)
    end;
check_str1([], _, _) ->
    false.

%% ----------------------------------------------------
%% Func: replace/2
%% Description: 替换string中存在的ReplaceString（要替换的字符串） 替换以*代替换
%% Returns: string
%% ----------------------------------------------------
replace(ReplaceString, String) when is_list(ReplaceString), is_list(String) ->
    replace(ReplaceString, String, []).
replace(ReplaceString, [H | T] = String, R) ->
    case prefix(ReplaceString, String) of
        false ->
            replace(ReplaceString, T, [H | R]);
        {true, NT} ->
            replace(ReplaceString, NT, [$* | R])
    end;
replace(_ReplaceString, [], R) ->
    to_unicode(lists:reverse(R)).

%% ----------------------------------------------------
%% Func: string_with_exist/2
%% Description: ExistString 是否存在于String中
%% Returns: bool
%% ----------------------------------------------------
string_with_exist(ExistString, String) when is_list(ExistString), is_list(String) ->
    string_with_exist_(ExistString, String).
string_with_exist_(ExistString, [_ | T] = String) ->
    case prefix(ExistString, String) of
        false ->
            string_with_exist_(ExistString, T);
        _ ->
            true
    end;
string_with_exist_(_, []) ->
    false.

%% ----------------------------------------------------
%% Func: handle_mask/1
%% Description: 处理屏蔽字原始数据,去重,去超过长度的
%% Returns: list
%% ----------------------------------------------------
handle_mask(Src) ->
    [{_, MWs}] = zm_config:get('mask_word'),
    handle_mask_(Src, MWs, []).
handle_mask_(Src, [Htmp | T], R) ->
    H = string:to_lower(Htmp),
    [H1 | _] = H,
    case lists:keyfind([H1], 1, R) of
        {_, H1List} ->
            case lists:member(H, H1List) of%%去除重复的屏蔽字
                true ->
                    handle_mask_(Src, T, R);
                false ->
                    handle_mask_(Src, T, lists:keyreplace([H1], 1, R, {[H1], [H | H1List]}))
            end;
        false ->
            NR = lists:keystore([H1], 1, R, {[H1], [H]}),
            handle_mask_(Src, T, NR)
    end;
handle_mask_(Src, [], R) ->
    [z_db_lib:update(game_lib:get_table(Src, 'handled_mask'), K, V) || {K, V} <- R].

%-------------------------------------------------------------------
% Func: string_with_start/2
% description: 校验是否把指定字符串开头
% Return:  bool
%-------------------------------------------------------------------
string_with_start([S | T1], [S | T2]) ->
    string_with_start(T1, T2);
string_with_start([], _) ->
    true;
string_with_start(_, _) ->
    false.

%-------------------------------------------------------------------
% Func: string_with_end/2
% description: 校验是否把指定字符串结束
% Return:  bool
%-------------------------------------------------------------------
string_with_end(Start, String) ->
    string_with_start(lists:reverse(Start), lists:reverse(String)).

%-------------------------------------------------------------------
% Func: string_cutting/2 |  string_cutting/3
% description: 以某个字符串为标示去切指定字符串所以位后的字符串 (2参默认为第1个, 没有就为[])
%%如	A = "123_456_12_78_45_90"  
%%		string_lib:string_cutting(A,1,"12")
%%		"3_456_12_78_45_90"
% Return:  List
%-------------------------------------------------------------------
string_cutting([_ | T] = String, Character) ->
    case prefix(Character, String) of
        false ->
            string_cutting(T, Character);
        {true, NT} ->
            NT
    end;
string_cutting([], _Character) ->
    [].
string_cutting(String, Number, Character) when Number > 0 ->
    string_cutting_(String, 0, Number, Character).
string_cutting_(String, Number, Number, _Character) ->
    String;
string_cutting_(String, N, Number, Character) ->
    case string_cutting(String, Character) of
        [] ->
            [];
        NT ->
            string_cutting_(NT, N + 1, Number, Character)
    end.

%% 将列表转换成String
convert_string(List) ->
    convert_string_(List, []).

%% ----------------------------------------------------
%% Func: tokens/1
%% Description: 字符批分，批分占位
%% Returns: list
%% ----------------------------------------------------
tokens(S, Seps) ->
    tokens1(S, Seps, []).

%% ----------------------------------------------------
%% Func: string_append/1
%% Description: 指定数据拼接
%% Returns:
%% ----------------------------------------------------
string_append(Value) ->
    binary_to_list(list_to_binary([string_lib:to_string(Value), string_lib:to_string(",")])).
string_append(Value, Split) ->
    case Split of
        none -> binary_to_list(list_to_binary([string_lib:to_string(Value)]));
        _ ->
            binary_to_list(list_to_binary([string_lib:to_string(Value), string_lib:to_string(Split)]))
    end.
%%%=================LOC FUNCTIONS=================
%%前辍
prefix([C | Pre], [C | String]) ->
    prefix(Pre, String);
prefix([], String) ->
    {true, String};
prefix(_, _) ->
    false.

% 将列表转换成String
convert_string_([H | T], Result) ->
    case T of
        [] ->
            convert_string_(T, binary_to_list(list_to_binary([Result, string_append(H, none)])));
        _ ->
            convert_string_(T, binary_to_list(list_to_binary([Result, string_append(H)])))
    end;
convert_string_([], Result) ->
    string_append(Result, none).

%% 字符批分
tokens1([C | [C | _] = S], Seps, Toks) ->
    case lists:member(C, Seps) of
        true -> tokens1(S, Seps, ["none"] ++ Toks);
        false -> tokens2(S, Seps, Toks, [C])
    end;
tokens1([C | S], Seps, Toks) ->
    case lists:member(C, Seps) of
        true -> tokens1(S, Seps, Toks);
        false -> tokens2(S, Seps, Toks, [C])
    end;
tokens1([], _Seps, Toks) ->
    lists:reverse(Toks).

tokens2([C | [C | _] = S], Seps, Toks, Cs) ->
    case lists:member(C, Seps) of
        true -> tokens1(S, Seps, ["none"] ++ [lists:reverse(Cs) | Toks]);
        false -> tokens2(S, Seps, Toks, [C | Cs])
    end;
tokens2([C | S], Seps, Toks, Cs) ->
    case lists:member(C, Seps) of
        true -> tokens1(S, Seps, [lists:reverse(Cs) | Toks]);
        false -> tokens2(S, Seps, Toks, [C | Cs])
    end;
tokens2([], _Seps, Toks, Cs) ->
    lists:reverse([lists:reverse(Cs) | Toks]).

%% ----------------------------------------------------
%% Func: string_to_term/1
%% Description: 字符串强转成erl
%% Returns:
%% ----------------------------------------------------
string_to_term(String) ->
    case erl_scan:string(String ++ ".") of
        {ok, Tokens, _} ->
            case erl_parse:parse_term(Tokens) of
                {ok, Term} ->
                    Term;
                _ ->
                    undefined
            end;
        _ ->
            undefined
    end.
%% -----------------------------------------------------------------
%% Func: term_to_string/1
%% Description: key转成sql string
%% Returns:
%% -----------------------------------------------------------------
term_to_string(Term) when is_atom(Term) ->
    atom_to_list(Term);
term_to_string(Term) when is_integer(Term) ->
    integer_to_list(Term);
term_to_string(Term) when is_float(Term) ->
    float_to_list(Term);
term_to_string(Term) when is_tuple(Term) ->
    list_to_binary([unicode:characters_to_binary(io_lib:format("~p", [Term]))]);
term_to_string(Term) when is_list(Term) ->
    try
        list_to_binary([unicode:characters_to_binary(xmerl_ucs:to_unicode(Term, 'utf-8'))])
    catch
        _:_ ->
            list_to_binary([unicode:characters_to_binary(Term)])
    end;
term_to_string(Term) when is_binary(Term) ->
    binary_to_list(term_to_binary(Term)).
%% ----------------------------------------------------
%% Func: str_check_to_term/1
%% Description: 检查字符串能否强转成erl，只对list和tuple格式有效
%% Returns: true|{false,错误字符,位置,错误字符,位置}|{false,错误字符,位置}
%% ----------------------------------------------------
str_check_to_term(String) when is_list(String) ->
    {ok, Tokens, _} = erl_scan:string(String ++ "."),
    str_check_to_term_(Tokens, 1, []).
str_check_to_term_([{Type, _} | T], I, R) when Type =:= '[' orelse Type =:= '{' ->
    str_check_to_term_(T, I + 1, [{Type, I} | R]);
str_check_to_term_([{Type1, _} | T], I, [{Type2, _} | R]) when (Type1 =:= ']' andalso Type2 =:= '[')
    orelse (Type1 =:= '}' andalso Type2 =:= '{') ->
    case T of
        [{',', _}, H2 | T2] when element(1, H2) =/= ']' andalso element(1, H2) =/= '}' ->
            str_check_to_term_([H2 | T2], I + 2, R);
        [H1 | _] when element(1, H1) =/= ']' andalso element(1, H1) =/= '}' andalso element(1, H1) =/= 'dot' ->
            {false, {element(1, H1), I + 1}};
        _ ->
            str_check_to_term_(T, I + 1, R)
    end;
str_check_to_term_([{Type, _} | _], I, [{H1, H2} | _]) when Type =:= ']' orelse Type =:= '}' ->
    {false, {H1, H2, Type, I}};
str_check_to_term_([{Type, _} | _], I, _) when Type =:= ']' orelse Type =:= '}' ->
    {false, {Type, I}};
str_check_to_term_([{'-', _}, {Type, _, _}, {',', _} | T], I, R) when Type =:= 'integer' orelse Type =:= 'float' ->
    case T of
        [H | _] when element(1, H) =/= ']' andalso element(1, H) =/= '}' ->
            str_check_to_term_(T, I + 3, R);
        _ ->
            {false, {',', I + 2}}
    end;
str_check_to_term_([{'-', _}, {Type, _, _} | T], I, R) when Type =:= 'integer' orelse Type =:= 'float' ->
    str_check_to_term_(T, I + 2, R);
str_check_to_term_([{Type, _, _}, {',', _} | T], I, R) when Type =:= 'atom' orelse Type =:= 'integer'
    orelse Type =:= 'string' orelse Type =:= 'float' ->
    case T of
        [H | _] when element(1, H) =/= ']' andalso element(1, H) =/= '}' ->
            str_check_to_term_(T, I + 2, R);
        _ ->
            {false, {',', I + 1}}
    end;
str_check_to_term_([{Type, _, _} | T], I, R) when Type =:= 'atom' orelse Type =:= 'integer'
    orelse Type =:= 'string' orelse Type =:= 'float' ->
    str_check_to_term_(T, I + 1, R);
str_check_to_term_([{'dot', _} | T], I, R) ->
    str_check_to_term_(T, I + 1, R);
str_check_to_term_([H | _], I, _) ->
    {false, {element(1, H), I}};
str_check_to_term_([], _, [H | _]) ->
    {false, H};
str_check_to_term_(_, _, _) ->
    true.