-module(server_type_port).

%%%=======================STATEMENT====================
-description("server_type_port").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    check_game_server/5,
    check_cross_game_server/5,
    check_game_center_server/5,
    check_cross_game_center_server/5
]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%        检测是否是游戏服务器
%% @end
%% ----------------------------------------------------
check_game_server(_, _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    if
        Attr =:= 'nil' ->%断线后未走登录流程
            {'break', [], Info, [{'msg', "no_login"}]};
        true ->
            case args_system:is_game_server(Src) of
                false ->
                    %TODO
                    zm_log:warn(Src, ?MODULE, ?MODULE, "check_game_server", [{line, ?LINE}, {msg, Msg}]),
                    {'break', [], Info, [{'msg', "server_type_error"}]};
                true ->
                    {'ok', [], Info, Msg}
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      检测是否是游戏服务器并且在某个跨服中
%% @end
%% ----------------------------------------------------
check_cross_game_server([CrossType], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    if
        Attr =:= 'nil' ->%断线后未走登录流程
            {'break', [], Info, [{'msg', "no_login"}]};
        true ->
            case args_system:is_game_server(Src) of
                false ->
                    zm_log:warn(Src, ?MODULE, ?MODULE, "check_cross_game_server", [{line, ?LINE}, {msg, Msg}]),
                    {'break', [], Info, [{'msg', "server_type_error"}]};
                true ->
                    RoleUid = role_lib:get_uid(Attr),
                    ServerCorss = server_cross_db:get_server_cross(Src, CrossType, RoleUid),
                    case ServerCorss =/= 'none' of
                        true ->
                            {'ok', [], Info, Msg ++ [{'server_cross', ServerCorss}]};
                        false ->
                            zm_log:warn(Src, ?MODULE, ?MODULE, "check_cross_game_server", [{line, ?LINE}, {msg, Msg}]),
                            {'break', [], Info, [{'msg', "server_type_error"}]}
                    end
            end
    end.


%% ----------------------------------------------------
%% @doc
%%      检测是否是游戏服中控服服务器
%% @end
%% ----------------------------------------------------
check_game_center_server(_, _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    if
        Attr =:= 'nil' ->%断线后未走登录流程
            {'break', [], Info, [{'msg', "no_login"}]};
        true ->
            case args_system:is_game_center_server(Src) of
                false ->
                    zm_log:warn(Src, ?MODULE, ?MODULE, "check_game_center_server", [{line, ?LINE}, {msg, Msg}]),
                    {'break', [], Info, [{'msg', "server_type_error"}]};
                true ->
                    {'ok', [], Info, Msg}
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      检测是否是游戏服中控服服务器并且在某个跨服中
%% @end
%% ----------------------------------------------------
check_cross_game_center_server([CrossType], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    if
        Attr =:= 'nil' ->%断线后未走登录流程
            {'break', [], Info, [{'msg', "no_login"}]};
        true ->
            case args_system:is_game_center_server(Src) of
                false ->
                    zm_log:warn(Src, ?MODULE, ?MODULE, "check_cross_game_center_server", [{line, ?LINE}, {msg, Msg}]),
                    {'break', [], Info, [{'msg', "server_type_error"}]};
                true ->
                    case cross_battle_area_db:get_cross_battle_area(Src, CrossType) of
                        'none' ->
                            zm_log:warn(Src, ?MODULE, ?MODULE, "check_cross_game_center_server", [{line, ?LINE}, {msg, Msg}]),
                            {'break', [], Info, [{'msg', "server_type_error"}]};
                        CrossBattleArea ->
                            {'ok', [], Info, Msg ++ [{'cb_area', CrossBattleArea}]}
                    end
            end
    end.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
