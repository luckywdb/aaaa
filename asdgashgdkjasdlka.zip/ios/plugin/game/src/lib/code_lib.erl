%%动态代码更新
-module(code_lib).
%%%=======================STATEMENT====================
-description("code_lib").
-copyright('youkia,www.youkia.net').
-author("zhs,zhanghaishan@youkia.net").
-vsn(1).
%%%=======================EXPORT=======================
-export([dynamic_update/2, webserver_update/2, format/1]).
%%%=======================INCLUDE=======================

%%%=======================RECORD=======================

%%%=======================DEFINE========================

%%%=================EXPORTED FUNCTIONS===================
%% ----------------------------------------------------
%% Func: dynamic_update/2
%% Description: 动态更新（0查看,1更新）
%% Returns: String
%% ----------------------------------------------------
dynamic_update(_Src, 0) ->
    case zm_config:get('$code_messages', 'code_update') of
        none ->
            none;
        {_, Dynamic} ->
            S = case zm_config:get('$code_messages', 'code_update_result') of
                none ->
                    format("==============code_update_resule=========================\nwait\n");
                {_, Info} ->
                    Info
            end,
            Dynamic ++ S
    end;
dynamic_update(_Src, 1) ->
    zm_config:delete('$code_messages', 'code_update_result'),
    Res = update("cd .. \n sh svn_dynamic_update.sh"),
    zm_config:set('$code_messages', {'code_update', Res}),
    Res.

%% ----------------------------------------------------
%% Func: webserver_update/2
%% Description: web动态更新（0查看,1更新）
%% Returns: String
%% ----------------------------------------------------
webserver_update(_Src, 0) ->
    case zm_config:get('$code_messages', 'web_update') of
        none ->
            none;
        {_, Dynamic} ->
            Dynamic
    end;
webserver_update(_Src, 1) ->
    Res = update("cd .. \n sh svn_webserver_update.sh"),
    zm_config:set('$code_messages', {'web_update', Res}),
    Res.

%%%===================LOCAL FUNCTIONS==================
%%更新
update(SH) ->
    case os:type() of
        {unix, _} ->
            String = os:cmd(SH),
            format(String);
        _ ->
            {{Y, M, D}, {HH, MM, SS}} = z_lib:second_to_localtime(z_lib:now_second()),
            "<div style='background-color:#E8E8E8;text-align:left;color:red'>"
                ++ "<b style='color:blue'>TIME:&nbsp"
                ++ integer_to_list(Y) ++ "-" ++ integer_to_list(M) ++ "-" ++ integer_to_list(D)
                ++ "&nbsp"
                ++ integer_to_list(HH) ++ ":" ++ integer_to_list(MM) ++ ":" ++ integer_to_list(SS)
                ++ "</b><br>Unknow OS<br>No Update</div>"
    end.

%%格式化
format(String) ->
    format(String, []).
format([$\n | T], Str) ->
    format(T, [62, 114, 98, 60 | Str]);
format([32 | T], Str) ->
    format(T, [112, 115, 98, 110, 38 | Str]);
format([H | T], Str) ->
    format(T, [H | Str]);
format([], Str) ->
    {{Y, M, D}, {HH, MM, SS}} = z_lib:second_to_localtime(z_lib:now_second()),
    "<div style='background-color:#E8E8E8;text-align:left;color:black'>"
        ++ "<b style='color:blue'>TIME:&nbsp"
        ++ integer_to_list(Y) ++ "-" ++ integer_to_list(M) ++ "-" ++ integer_to_list(D)
        ++ "&nbsp"
        ++ integer_to_list(HH) ++ ":" ++ integer_to_list(MM) ++ ":" ++ integer_to_list(SS)
        ++ "</b></br>"
        ++ lists:reverse(Str)
        ++ "</div>".