%% 断线重连工具，需要断线重连的通讯，先使用msg_start做检查，返回时再使用msg_end做数据记录，msg_end会原样返回上个端口的数据
-module(reconnect_lib).

%%%=======================STATEMENT====================
-description("reconnect_lib").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([msg_start/5, msg_end/5, delete/2]).

%%%=======================INCLUDE======================

%%%=======================RECORD=======================

%%%=======================DEFINE=======================
%%如果存在多个断线重连表需要加这里
-define(RECONNECT_DBS, ['reconnect1']).

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      通讯开始，检查是否直接返回上一次数据
%% @end
%% ----------------------------------------------------
-spec msg_start([Table], _, Attr, Info, Msg) -> game_types:port_reply() when
    Table :: atom(),
    Attr :: game_types:attr(),
    Info :: list(),
    Msg :: list().
msg_start([Table], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    if
        Attr =:= 'nil' ->%断线后未走登录流程
            {'break', [], Info, [{'msg', "no_login"}]};
        true ->
            RoleUid = role_lib:get_uid(Attr),
            [{_, SerialNumber} | _] = Msg,
            case z_db_lib:get(game_lib:get_table(Src, Table), RoleUid) of
                {SerialNumber, LastMsg} ->
                    {'break', [], Info, [{'recon', 1} | LastMsg]}; %%断线重连，后台已完成处理，新增一组kv ,如果数据位后台send推送过去的,则前台根据{recon, 1} 标记,发送新的端口取获取后台存储的send信息
                _ ->
                    {'ok', [], [{'serial_number', SerialNumber} | Info], Msg}
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      通讯结束,存储本次返回数据
%% @end
%% ----------------------------------------------------
-spec msg_end([Table], _, Attr, Info, Msg) -> game_types:port_reply() when
    Table :: atom(),
    Attr :: game_types:attr(),
    Info :: list(),
    Msg :: list().
msg_end([Table], _, Attr, Info, Msg) ->
    try
        Src = z_lib:get_value(Info, 'src', 'none'),
        RoleUid = role_lib:get_uid(Attr),
        case z_lib:get_value(Info, 'serial_number', 'none') of
            'none' ->
                'ok';
            SerialNumber ->
                z_db_lib:update(game_lib:get_table(Src, Table), RoleUid, {SerialNumber, Msg})
        end
    catch
        _:_ ->
            'ok'
    end,
    {'ok', [], Info, Msg}.

%% ----------------------------------------------------
%% @doc
%%      清理指定玩家数据
%% @end
%% ----------------------------------------------------
-spec delete(atom(), integer()) -> list().
delete(Src, RoleUid) ->
    [z_db_lib:delete(game_lib:get_table(Src, T), RoleUid) || T <- ?RECONNECT_DBS].
%%%===================LOCAL FUNCTIONS==================