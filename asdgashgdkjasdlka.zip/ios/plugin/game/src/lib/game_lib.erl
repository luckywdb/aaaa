%%game游戏工具
-module(game_lib).
-description("game_lib").
-copyright({seasky, 'www.seasky.cn'}).
-author({cb, 'chenbin@seaskyjoy.com'}).
-vsn(1).

%%%=======================EXPORT=========================
-export([get_table/1, get_table/2, get_level/2, get_max_exp/2, get_max_level/2, get_exps/2, get_exp_by_level/3]).
-export([merge_kv/2, get_language/1, get_language/2, arrange_award_logs/1, arrange_prop_bi/2]).
-export([random_list/2, random_order/1, random_value/1, tuple_random_value/1, get_seed/0, level_value/2]).
-export([check_state/2, add_state/2, remove_state/2, get_error_code/1, parse_props/1, ceil/1,floor/1]).
-export([checks/4, consumes/4]).
-export([get_server_key/2, get_server_key/3, list_split/2]).
-export([get_client_version/0, to_string2/1]).
-export([draw/3]).
-export([get_game_src/0, get_center_src/0]).
-export([get_language_package/1]).
%%%====================DEFIND==============================
-define(FORLET_TARGET, "target").
-define(METHOD_ARGU, "argu").
-define(DB_SUFFIX, ".table").
%% dtimer开关Key
-define(DTIMER_STATUS_KEY, dtimer_status).
%% 开启
-define(OPEN, 0).
%% 关闭
-define(CLOSE, 1).

%% game游戏工具config记录
-define(GAME_LIB_CONFIG, 'game_lib_config').

%%%====================EXPORT FUNCTION====================
get_game_src() ->
    'game'.
get_center_src() ->
    'game_center'.
%% ----------------------------------------------------
%% @doc
%%      kv进行合并
%% @end
%% ----------------------------------------------------
-spec merge_kv(list({term(), integer()}), list({term(), integer()})) -> list({term(), integer()}).
merge_kv([{Key, Value} | T], Attrs) ->
    merge_kv(T, merge_kv_({Key, Value}, Attrs, []));
merge_kv([], Attrs) ->
    Attrs.
merge_kv_({K1, V1}, [{K1, V2} | T], List) ->
    lists:reverse(List, [{K1, V1 + V2} | T]);
merge_kv_({K1, V1}, [Item | T], List) ->
    merge_kv_({K1, V1}, T, [Item | List]);
merge_kv_(Item = {_, _}, [], List) ->
    lists:reverse([Item | List]).

%% ----------------------------------------------------
%% @doc
%%      得到所有的数据库表
%% @end
%% ----------------------------------------------------
-spec get_table(Src :: atom()) -> atom().
get_table(Src) ->
    string_lib:to_atom(get_table_(lists:reverse(atom_to_list(Src)), ?DB_SUFFIX)).
%% ----------------------------------------------------
%% @doc
%%      得到指定数据库表
%% @end
%% ----------------------------------------------------
-spec get_table(Src :: atom(), K :: atom()) -> atom().
get_table(Src, K) ->
    element(2, zm_config:get(get_table(Src), K)).
get_table_([H | T], R) ->
    get_table_(T, [H | R]);
get_table_([], R) ->
    R.

%% ----------------------------------------------------
%% @doc
%%      进行奖励格式化整理
%% @end
%% ----------------------------------------------------
-spec arrange_award_logs(List :: list()) -> tuple();
        (Tuple :: tuple()) -> tuple().
arrange_award_logs(List) when is_tuple(List) ->
    arrange_award_logs(erlang:tuple_to_list(List), []);
arrange_award_logs(List) when is_list(List) ->
    arrange_award_logs(lists:flatten(List), []).
arrange_award_logs([Item | T], List) ->
    arrange_award_logs(T, arrange_award_logs_(Item, List, []));
arrange_award_logs([], List) ->
    erlang:list_to_tuple(List).

arrange_award_logs_({'card_part', Sid, V1}, [{'card_part', Sid, V2} | T], List) ->
    lists:reverse(List, [{'card_part', Sid, V1 + V2} | T]);
arrange_award_logs_({'equipment_part', Sid, V1}, [{'equipment_part', Sid, V2} | T], List) ->
    lists:reverse(List, [{'equipment_part', Sid, V1 + V2} | T]);
arrange_award_logs_({'goods', Sid, V1}, [{'goods', Sid, V2} | T], List) ->
    lists:reverse(List, [{'goods', Sid, V1 + V2} | T]);
arrange_award_logs_({'treasure_material', Sid, V1}, [{'treasure_material', Sid, V2} | T], List) ->
    lists:reverse(List, [{'treasure_material', Sid, V1 + V2} | T]);
arrange_award_logs_({'treasure_draw', Sid, V1}, [{'treasure_draw', Sid, V2} | T], List) ->
    lists:reverse(List, [{'treasure_draw', Sid, V1 + V2} | T]);
arrange_award_logs_({'card_exp', V1}, [{'card_exp', V2} | T], List) ->
    lists:reverse(List, [{'card_exp', V1 + V2} | T]);
arrange_award_logs_({'rmb', V1}, [{'rmb', V2} | T], List) ->
    lists:reverse(List, [{'rmb', V1 + V2} | T]);
arrange_award_logs_({'buy_rmb', V1}, [{'buy_rmb', V2} | T], List) ->
    lists:reverse(List, [{'buy_rmb', V1 + V2} | T]);
arrange_award_logs_({'money', V1}, [{'money', V2} | T], List) ->
    lists:reverse(List, [{'money', V1 + V2} | T]);
arrange_award_logs_({'exp', V1}, [{'exp', V2} | T], List) ->
    lists:reverse(List, [{'exp', V1 + V2} | T]);
arrange_award_logs_({'wood', V1}, [{'wood', V2} | T], List) ->
    lists:reverse(List, [{'wood', V1 + V2} | T]);
arrange_award_logs_({'forage', V1}, [{'forage', V2} | T], List) ->
    lists:reverse(List, [{'forage', V1 + V2} | T]);
arrange_award_logs_({'mineral', V1}, [{'mineral', V2} | T], List) ->
    lists:reverse(List, [{'mineral', V1 + V2} | T]);
arrange_award_logs_({'iron', V1}, [{'iron', V2} | T], List) ->
    lists:reverse(List, [{'iron', V1 + V2} | T]);
arrange_award_logs_(Item, [H | T], List) ->
    arrange_award_logs_(Item, T, [H | List]);
arrange_award_logs_(Item, [], List) ->
    lists:reverse([Item | List]).

%% ----------------------------------------------------
%% @doc
%%      物品bi格式化整理
%% @end
%% ----------------------------------------------------
-spec arrange_prop_bi(List :: list(), Storage :: tuple()) -> list();
        (Tuple :: tuple(), Storage :: tuple()) -> list().
arrange_prop_bi(List, Storage) when is_list(List) ->
    arrange_prop_bi(List, Storage, []);
arrange_prop_bi(Tuple, Storage) when is_tuple(Tuple) ->
    arrange_prop_bi(tuple_to_list(Tuple), Storage, []).

arrange_prop_bi([List1 | T], Storage, List) when is_list(List1) ->
    arrange_prop_bi(T, Storage, arrange_prop_bi(List1, Storage, List));
arrange_prop_bi([Item | T], Storage, List) ->
    arrange_prop_bi(T, Storage, arrange_prop_bi_(Item, Storage, List));
arrange_prop_bi([], _, List) ->
    List.

arrange_prop_bi_({'card_part', Sid, Num}, Storage, List) ->
    [{'card_part', Sid, storage_lib:get_count(Storage, Sid), Num} | List];
arrange_prop_bi_({'equipment_part', Sid, Num}, Storage, List) ->
    [{'equipment_part', Sid, storage_lib:get_count(Storage, Sid), Num} | List];
arrange_prop_bi_({'goods', Sid, Num}, Storage, List) ->
    [{'goods', Sid, storage_lib:get_count(Storage, Sid), Num} | List];
arrange_prop_bi_({'treasure_material', Sid, Num}, Storage, List) ->
    [{'treasure_material', Sid, storage_lib:get_count(Storage, Sid), Num} | List];
arrange_prop_bi_({'treasure_draw', Sid, Num}, Storage, List) ->
    [{'treasure_draw', Sid, storage_lib:get_count(Storage, Sid), Num} | List];
arrange_prop_bi_({'card', Cards}, Storage, List) ->
    F = fun(Args, {Sid, _}) ->
        case lists:keyfind(Sid, 1, Args) of
            false ->
                [{Sid, 1} | Args];
            {_, Num} ->
                lists:keyreplace(Sid, 1, Args, {Sid, Num + 1})
        end
    end,
    List1 = [{'card', Sid, storage_lib:get_count(Storage, Sid), Num} || {Sid, Num} <- z_lib:foreach(F, [], tuple_to_list(Cards))],
    lists:reverse(List1, List);
arrange_prop_bi_({'equipment', Equipmens}, Storage, List) ->
    F = fun(Args, {Sid, _}) ->
        case lists:keyfind(Sid, 1, Args) of
            false ->
                [{Sid, 1} | Args];
            {_, Num} ->
                lists:keyreplace(Sid, 1, Args, {Sid, Num + 1})
        end
    end,
    List1 = [{'equipment', Sid, storage_lib:get_count(Storage, Sid), Num} || {Sid, Num} <- z_lib:foreach(F, [], tuple_to_list(Equipmens))],
    lists:reverse(List1, List);
arrange_prop_bi_({'treasure', Treasures}, Storage, List) ->
    F = fun(Args, {Sid, _}) ->
        case lists:keyfind(Sid, 1, Args) of
            false ->
                [{Sid, 1} | Args];
            {_, Num} ->
                lists:keyreplace(Sid, 1, Args, {Sid, Num + 1})
        end
    end,
    List1 = [{'treasure', Sid, storage_lib:get_count(Storage, Sid), Num} || {Sid, Num} <- z_lib:foreach(F, [], tuple_to_list(Treasures))],
    lists:reverse(List1, List);
arrange_prop_bi_(_, _, List) ->
    List.

%% ----------------------------------------------------
%% @doc
%%      根据经验获取等级
%% @end
%% ----------------------------------------------------
-spec get_level(Type, Value :: term()) -> integer() when
    Type :: atom()|{atom(), integer()}.
get_level(Type, Value) ->
    {_, InitLevel, {M, F}, {M1, F1, A1}} = zm_config:get('level', Type),
    Exp = M:F(Value),
    Exps = M1:F1(A1, Value),
    Fun = fun(V1, V2) ->
        if
            V1 < V2 ->
                -1;
            V1 > V2 ->
                1;
            true ->
                0
        end
    end,
    Index = tuple_lib:middle_search(Exps, Exp, Fun),
    Index1 = if
        Index > size(Exps) ->
            size(Exps);
        true ->
            Index
    end,
    Bool = element(Index1, Exps) =:= Exp,
    Level = if
        Bool ->
            Index;
        true ->
            Index - 1
    end,
    Level + InitLevel.

%% ----------------------------------------------------
%% @doc
%%      得到经验表
%% @end
%% ----------------------------------------------------
-spec get_exps(Type :: atom(), term()) -> tuple().
get_exps(Type, _) ->
    {_, Exps} = zm_config:get(level, Type),
    Exps.
%% ----------------------------------------------------
%% @doc
%%      获取满级经验
%% @end
%% ----------------------------------------------------
-spec get_max_exp(Type :: atom()|tuple(), Value :: term()) -> integer().
get_max_exp(Type, Value) ->
    {_, _, _, {M1, F1, A1}} = zm_config:get('level', Type),
    Exps = M1:F1(A1, Value),
    element(size(Exps), Exps).
%% ----------------------------------------------------
%% @doc
%%      获取最大等级
%% @end
%% ----------------------------------------------------
-spec get_max_level(Type :: atom(), Value :: term()) -> integer().
get_max_level(Type, Value) ->
    {_, InitLevel, _, {M1, F1, A1}} = zm_config:get('level', Type),
    Exps = M1:F1(A1, Value),
    size(Exps) + InitLevel.
%% ----------------------------------------------------
%% @doc
%%      获取指定等级的经验
%% @end
%% ----------------------------------------------------
-spec get_exp_by_level(Type :: atom(), Value :: term(), Level :: integer()) -> integer().
get_exp_by_level(Type, Value, Level) ->
    {_, InitLevel, _, {M1, F1, A1}} = zm_config:get('level', Type),
    Exps = M1:F1(A1, Value),
    G = Level - InitLevel,
    if
        G < 1 ->
            0;
        G >= size(Exps) ->
            element(size(Exps), Exps);
        true ->
            element(G, Exps)
    end.

%% ----------------------------------------------------
%% @doc
%%      获取language信息
%% @end
%% ----------------------------------------------------
-spec get_language(Type) -> string() when
    Type :: atom() | tuple().
get_language(Type) ->
    {_, Language} = zm_config:get('language', Type),
    Language.
%% ----------------------------------------------------
%% @doc
%%      获取language信息（可进行信息替换）
%% @end
%% ----------------------------------------------------
-spec get_language(Type, Args) -> string() when
    Type :: atom() | tuple(),
    Args :: list().
get_language(Type, Args) ->
    string_lib:content(get_language(Type), Args).

%% ----------------------------------------------------
%% @doc
%%      得到错误码
%% @end
%% ----------------------------------------------------
-spec get_error_code({Module :: module(), Fun :: atom(), Type :: atom()}) -> string()|tuple().
get_error_code({Module, Fun, Type} = Key) ->
    case zm_config:get(?GAME_LIB_CONFIG, Key) of
        none ->
            ErrorCode = string_lib:to_string(Module) ++ "_" ++ string_lib:to_string(Fun) ++ "_" ++ string_lib:to_string(Type),
            zm_config:set(?GAME_LIB_CONFIG, {Key, ErrorCode}),
            ErrorCode;
        {_, ErrCode} ->
            ErrCode
    end.

%% ----------------------------------------------------
%% @doc
%%      乱序一个列表
%% @end
%% ----------------------------------------------------
-spec random_order(list()) -> list().
random_order(List) ->
    T = list_to_tuple(List),
    Size = tuple_size(T),
    NT = lists:foldl(fun(_, Tup) ->
        Index1 = rand:uniform(Size),
        Index2 = rand:uniform(Size),
        Tup1 = setelement(Index1, Tup, element(Index2, Tup)),
        setelement(Index2, Tup1, element(Index1, Tup))
    end, T, List),
    tuple_to_list(NT).

%% ----------------------------------------------------
%% @doc
%%      从列表List中随机选取SelectNum个元素，组成新的列表，新列表的元素排列顺序与其在List中顺序相同
%% @end
%% ----------------------------------------------------
-spec random_list(list(), integer()) -> list().
random_list(List, SelectNum) ->
    Len = length(List),
    if Len =< SelectNum ->
        List;
        true ->
            random_list(List, SelectNum, Len, [])
    end.


%% ----------------------------------------------------
%% @doc
%%      传入格式为[random,value,...]格式的列表,根据random值和为分母,random为单个值分子,返回随机获得的value
%% @end
%% ----------------------------------------------------
-spec random_value(L :: list()) -> term().
random_value(L) ->
    random_value(L, L, 0).
random_value(L, [Weight, _ | T], C) ->
    random_value(L, T, Weight + C);
random_value(L, [], C) ->
    random_value(L, z_lib:random(1, C)).
random_value([Weight, _ | T], C) when Weight < C ->
    random_value(T, C - Weight);
random_value([_Weight, Value | _T], _C) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%      传入格式为[{random,value},...]格式的列表,根据random值和为分母,random为单个值分子,返回随机获得的value
%% @end
%% ----------------------------------------------------
-spec tuple_random_value(L :: list({integer(), term()})) -> term().
tuple_random_value(L) ->
    tuple_random_value(L, L, 0).
tuple_random_value(L, [{Weight, _} | T], C) ->
    tuple_random_value(L, T, Weight + C);
tuple_random_value(L, [], C) ->
    tuple_random_value(L, z_lib:random(1, C)).
tuple_random_value([{Weight, _} | T], C) when Weight < C ->
    tuple_random_value(T, C - Weight);
tuple_random_value([{_Weight, Value} | _T], _C) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%      等级取值 [10,Term,20,Term]
%% @end
%% ----------------------------------------------------
%% ----------------------------------------------------
%% Func: level_value/2
%% Description:  等级取值 [10,Term,20,Term]
%% Returns: term
%% ----------------------------------------------------
level_value(Level, [L1, _, L2 | _] = Values) when L1 > L2 ->
    level_value2(Level, Values);
level_value(Level, Values) ->
    level_value1(Level, Values).

%% 列表比较值,从小到大
level_value1(Level, [L, Value | _]) when Level =< L ->
    Value;
level_value1(_Level, [_L, Value]) ->
    Value;
level_value1(Level, [_, _ | T]) ->
    level_value1(Level, T);
level_value1(_, []) ->
    [].

%% 列表比较值,从大到小
level_value2(Level, [L, Value | _]) when Level >= L ->
    Value;
level_value2(_Level, [_L, Value]) ->
    Value;
level_value2(Level, [_, _ | T]) ->
    level_value2(Level, T);
level_value2(_, []) ->
    [].

%% ----------------------------------------------------
%% @doc
%%      获得随机种子
%% @end
%% ----------------------------------------------------
-spec get_seed() -> integer().
get_seed() ->
    {_, S, MS} = os:timestamp(),
    z_lib:random(S * 1000 + MS div 1000).

%%-------------------------------------------------------------------
%% @doc
%%      检查状态(如果含有该状态值,返还true,否则返还false)
%% @end
%%-------------------------------------------------------------------
-spec check_state(State :: integer(), Value :: integer()) -> boolean().
check_state(State, Value) ->
    (State band Value) > 0.

%%-------------------------------------------------------------------
%% @doc
%%      增加状态(位运算)
%% @end
%%-------------------------------------------------------------------
-spec add_state(State :: integer(), Value :: integer()) -> integer().
add_state(State, Value) ->
    State bor Value.

%%-------------------------------------------------------------------
%% @doc
%%      减少状态(位运算)
%% @end
%%-------------------------------------------------------------------
-spec remove_state(State :: integer(), Value :: integer()) -> integer().
remove_state(State, Value) ->
    (State bor Value) bxor Value.

%%-------------------------------------------------------------------
%% @doc
%%      解析前台传入道具，"sid,num,sid,num"
%% @end
%%-------------------------------------------------------------------
-spec parse_props(Str :: string()) -> list().
parse_props(Str) ->
    parse_props_(string:tokens(Str, ","), []).
parse_props_([Sid, Num | T], R) ->
    parse_props_(T, [{list_to_integer(Sid), list_to_integer(Num)} | R]);
parse_props_([], R) -> %%合并一次,key相同的值
    merge_kv(lists:reverse(R), []);
parse_props_(_, _) -> %%格式不正确返回[]
    [].

%%-------------------------------------------------------------------
%% @doc
%%      向上去整
%% @end
%%-------------------------------------------------------------------
ceil(Number) ->
    Int = trunc(Number),
    if
        Number > Int andalso Number > 0 ->
            Int + 1;
        true ->
            Int
    end.

%%-------------------------------------------------------------------
%% @doc
%%      向下取整
%% @end
%%-------------------------------------------------------------------
floor(Number) ->
    Int = trunc(Number),
    if
        Number =:= Int ->
            Int;
        true ->
            if
                Number > 0 ->
                    Int;
                true ->
                    Int-1
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      检验条件
%% @end
%% ----------------------------------------------------
-spec checks(MF :: {module(), atom()}, Tables :: term(), Args :: term(), list()) -> Reply when
    Reply :: true|tuple()|string().
checks({M, F} = MF, Tables, Args, [H | T]) ->
    case M:F(Tables, Args, H) of
        false ->
            Type = if
                is_tuple(H) ->
                    element(1, H);
                is_atom(H) ->
                    H;
                true ->
                    'limit'
            end,
            Fun = if
                is_tuple(Args) ->
                    element(1, Args);
                is_atom(Args) ->
                    Args;
                true ->
                    F
            end,
            get_error_code({M, Fun, Type});
        _ ->
            checks(MF, Tables, Args, T)
    end;
checks(_MF, _Tables, _Args, []) ->
    true.
%% ----------------------------------------------------
%% @doc
%%      消耗
%% @end
%% ----------------------------------------------------
-spec consumes(MF :: {module(), atom()}, Tables :: term(), Args :: term(), CS :: list()) -> {list(), tuple()}.
consumes(MF, Tables, Args, CS) ->
    consumes(MF, Tables, Args, CS, []).
consumes({M, F} = MF, Tables, Args, [H | T], CS) ->
    case M:F(Tables, Args, H) of
        {'none', Tables1} ->
            consumes(MF, Tables1, Args, T, CS);
        {Consume, Tables1} when is_list(Consume) ->
            consumes(MF, Tables1, Args, T, Consume ++ CS);
        {Consume, Tables1} ->
            consumes(MF, Tables1, Args, T, [Consume | CS])
    end;
consumes(_MF, Tables, _Args, [], CS) ->
    {CS, Tables}.



random_list(_, 0, _, Result) ->
    lists:reverse(Result);
random_list([Head | Rest], SelectNum, Len, Result) ->
    case rand:uniform() =< SelectNum / Len of
        true ->
            random_list(Rest, SelectNum - 1, Len - 1, [Head | Result]);
        false ->
            random_list(Rest, SelectNum, Len - 1, Result)
    end.

%% ----------------------------------------------------
%% @doc
%%       加上pid和sid的键值
%% @end
%% ----------------------------------------------------
-spec get_server_key(Src :: atom(), Key :: term()) -> {integer(), integer(), term()}.
get_server_key(Src, Key) ->
    Pid = args_system:get_pid(Src),
    Sid = args_system:get_sid(Src),
    {Pid, Sid, Key}.

%% ----------------------------------------------------
%% @doc
%%       加上pid和sid的键值
%% @end
%% ----------------------------------------------------
-spec get_server_key(Pid :: integer(), Sid :: integer(), Key :: term()) -> {integer(), integer(), term()}.
get_server_key(Pid, Sid, Key) ->
    {Pid, Sid, Key}.

%% ----------------------------------------------------
%% @doc
%%      分割list
%% @end
%% ----------------------------------------------------
-spec list_split(N :: integer(), List :: list()) -> {list(), list()}.
list_split(N, List) ->
    {L, R} = list_split(N, List, []),
    {lists:reverse(L), R}.

list_split(N, [H | T], L) when N > 0 ->
    list_split(N - 1, T, [H | L]);
list_split(0, [], L) ->
    {L, []};
list_split(_N, [], L) ->
    {L, []};
list_split(_N, R, L) ->
    {L, R}.

%% ----------------------------------------------------
%% @doc
%%      前台client版本
%% @end
%% ----------------------------------------------------
get_client_version() ->
    element(2, zm_config:get('client_version_info', 'client_version')).

%% ----------------------------------------------------
%% @doc
%%     转成string 不能有中文 去除“{}”|"[]"，如："a,b"=to_string({a,b})=to_string([a,b])
%% @end
%% ----------------------------------------------------
to_string2([]) ->
    "[]";
to_string2({}) ->
    "{}";
to_string2(Term) when is_tuple(Term) orelse is_list(Term) ->
    [[_, T2, _]] = io_lib:format("~p", [Term]),
    binary_to_list(list_to_binary(T2));
to_string2(Term) ->
    Term.

%% ----------------------------------------------------
%% @doc
%%      根据角色等级,随机池中随机选取个数的条目(皇榜任务抽任务(代码由商店抽商品移植,但商店暂未修改为使用此方法))
%%      {game_lib,draw,{{game_lib,get_level,role},[{{1,40},[{962501,2},{962502,3}]}],mission_pool}}
%%      返回: {抽取到的信息,各个库分别抽取了哪些}
%% @end
%% ----------------------------------------------------
draw({PoolList, CfgName}, RoleLv, Choosed) ->
    case choose_pool(PoolList, RoleLv) of
        Sid when is_integer(Sid) ->
            {_, Pool} = zm_config:get(CfgName, Sid),
            {List, NkeyList} =
                case lists:keyfind(Sid, 1, Choosed) of
                    false ->
                        draw1(Pool, [], []);
                    {_, KeyList} ->
                        draw1(Pool, KeyList, [])
                end,
            {List, lists:keystore(Sid, 1, Choosed, {Sid, NkeyList})};
        Other ->
            draw_(Other, Choosed, [], CfgName)
    end.
draw_([{PoolSid, Num} | T], Choosed, List, CfgName) ->
    {_, Pool} = zm_config:get(CfgName, PoolSid),
    {L1, NkeyList} =
        case lists:keyfind(PoolSid, 1, Choosed) of
            false ->
                draw2(Pool, Num, [], []);
            {_, KeyList} ->
                draw2(Pool, Num, KeyList, [])
        end,
    draw_(T, lists:keystore(PoolSid, 1, Choosed, {PoolSid, NkeyList}), L1 ++ List, CfgName);
draw_([], Choosed, List, _CfgName) ->
    {List, Choosed}.

%% ----------------------------------------------------
%% @doc
%%     全被抽取
%% @end
%% ----------------------------------------------------
draw1([_, Item | T], _KeyList, List) ->
    draw1(T, [], [Item | List]);
draw1([], KeyList, List) ->
    {List, KeyList}.
%% ----------------------------------------------------
%% @doc
%%     根据库和数量进行抽取
%% @end
%% ----------------------------------------------------
draw2(Pool, Num, KeyList, List) when Num > 0 ->
    R = filter(Pool, KeyList, []),
    Length = length(R) div 2,
    if
        Length < 1 ->%%如果条目数等于0，则跳转到⑥(重置随机池到初始状态，清空临时表中条目)
            %%清清空临时表中条目
            draw2(Pool, Num, [], List);
        Length =:= Num ->
            %%清清空临时表中条目
            {L, _} = draw1(R, [], []),
            {L ++ List, []};
        Length < Num ->%%④.随机池中条目数小于6时，跳转到⑤(从临时表随机抽取 （6-随机池条目数） 个商品条目和随机池中剩余条目一起作为本次刷新商店列表)
            {L1, _} = draw1(Pool, [], []),
            ItemLength = length(Pool) div 2,
            %%清清空临时表中条目
            {lists:foldl(fun(_X, LL) ->
                [lists:nth(z_lib:random(1, ItemLength), L1) | LL] end, List, lists:seq(1, Num)), []};
        true ->%%开始抽
            Item = game_lib:random_value(R),
            draw2(Pool, Num - 1, [Item | KeyList], [Item | List])
    end;
draw2(_PoolSid, _Num, KeyList, List) ->
    {List, KeyList}.

%% ----------------------------------------------------
%% @doc
%%     过滤, 排除已经抽取的
%% @end
%% ----------------------------------------------------
-spec filter(L, List, R) -> list() when
    L :: list(),
    List :: list(),
    R :: list().
filter(L, [], _) ->
    L;
filter([Rankdom, Item | T], List, R) ->
    case lists:member(Item, List) of
        false ->
            filter(T, List, [Rankdom, Item | R]);
        true ->
            filter(T, List, R)
    end;
filter([], _, R) ->
    R.

%% ----------------------------------------------------
%% @doc
%%     检验选择池条件
%% @end
%% ----------------------------------------------------
choose_pool([{{Min, Max}, Pool} | T], Level) ->
    if
        Level >= Min andalso Level =< Max ->
            Pool;
        true ->
            choose_pool(T, Level)
    end;
choose_pool([{X, Pool} | T], Level) when is_integer(X) ->
    if
        X > Level ->
            choose_pool(T, Level);
        true ->
            Pool
    end;
choose_pool([], _) ->
    [].

%% ----------------------------------------------------
%% @doc
%%    获取语言包中信息
%% @end
%% ----------------------------------------------------
get_language_package(Str) ->
    case zm_config:get('language_package', Str) of
        'none' ->
            Str;
        {_, NewStr} ->
            NewStr
    end.