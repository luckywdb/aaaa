%%唯一id工具
-module(uid_lib).
-description("uid_lib").
-copyright({seasky, 'www.seasky.cn'}).
-author({cb, 'chenbin@seaskyjoy.com'}).
-vsn(1).

%%%=======================EXPORT=========================
-compile(export_all).
%%%====================DEFIND==============================
-define(USER_UID, user_uid).%用户(武将卡牌)id
-define(MAIL_UID, mail_uid).%mail唯一id
-define(SYSTEM_MAIL_UID, system_mail_uid).%系统mail唯一id
-define(ROLE_BORN, role_born).%创建角色,根据国家获取出生点
-define(EQUIPMENT_UID, equipment_uid).%装备唯一id
-define(MARCHING_UID, marching_uid).%行军唯一id
-define(CORPS_UID, corps_uid).%军团唯一id
-define(REPORT_UID, report_uid).%战报uid
-define(REFRESH_MONSTER_INDEX, report_monster_index).%%刷怪物
-define(TREASURE_UID, treasure_uid).%宝物唯一id

-define(ORDERUID, orderuid).
%%%===内存id===

%%%====================EXPORT FUNCTION====================
%% ----------------------------------------------------
%% @doc
%%      生成一个唯一的用户uid
%% @end
%% ----------------------------------------------------
-spec create_user_uid(Src :: atom(), Pid :: integer(), Sid :: integer()) -> integer().
create_user_uid(Src, Pid, Sid) ->
    {ok, Uid} = zm_unique_int:get(game_lib:get_table(Src, uid), {Pid, Sid, ?USER_UID}, 1),
    Uid.

%% ----------------------------------------------------
%% @doc
%%      根据玩家进入顺序,获取出生点index
%% @end
%% ----------------------------------------------------
-spec get_born_index(Src :: atom()) -> integer().
get_born_index(Src) ->
    Pid = args_system:get_pid(Src),
    Sid = args_system:get_sid(Src),
    {ok, PropUid} = zm_unique_int:get(game_lib:get_table(Src, uid), {Pid, Sid, ?ROLE_BORN}, 1),
    PropUid.

%% ----------------------------------------------------
%% @doc
%%      改造用户id
%% @end
%% ----------------------------------------------------
-spec get_uid(Platformid :: integer(), Serverid :: integer(), ID :: integer()) -> integer().
get_uid(Platformid, Serverid, ID) ->
    (Platformid bsl 48) bor (Serverid bsl 32) bor ID.

%% ----------------------------------------------------
%% @doc
%%      得到平台id
%% @end
%% ----------------------------------------------------
-spec get_pid(Uid :: integer()) -> integer().
get_pid(Uid) when is_integer(Uid) ->
    Uid bsr 48.

%% ----------------------------------------------------
%% @doc
%%      得到游戏server id
%% @end
%% ----------------------------------------------------
-spec get_sid(Uid :: integer()) -> integer().
get_sid(Uid) when is_integer(Uid) ->
    Uid bsr 32 - (Uid bsr 48 bsl 16).

%% ----------------------------------------------------
%% @doc
%%      得到游戏内分配id
%% @end
%% ----------------------------------------------------
-spec get_id(Uid :: integer()) -> integer().
get_id(Uid) when is_integer(Uid) ->
    Pid = Uid bsr 48,
    Sid = Uid bsr 32 - (Pid bsl 16),
    Uid - ((Pid bsl 48) bor (Sid bsl 32)).

%% ----------------------------------------------------
%% @doc
%%      生成一个唯一的武将卡片uid
%% @end
%% ----------------------------------------------------
-spec create_card_uid(Src :: atom()) -> integer().
create_card_uid(Src) ->
    Pid = args_system:get_pid(Src),
    Sid = args_system:get_sid(Src),
    get_uid(Pid, Sid, create_user_uid(Src, Pid, Sid)).

%% ----------------------------------------------------
%% @doc
%%      生成一个唯一的mail uid
%% @end
%% ----------------------------------------------------
-spec create_mail_uid(Src :: atom()) -> integer().
create_mail_uid(Src) ->
    get_src_uid(Src, ?MAIL_UID).

%% ----------------------------------------------------
%% @doc
%%      生成一个唯一的系统mail uid
%% @end
%% ----------------------------------------------------
-spec create_system_mail_uid(Src :: atom()) -> integer().
create_system_mail_uid(Src) ->
    get_src_uid(Src, ?SYSTEM_MAIL_UID).

%% ----------------------------------------------------
%% @doc
%%      生成一个唯一的装备uid
%% @end
%% ----------------------------------------------------
-spec create_equipment_uid(Src :: atom()) -> integer().
create_equipment_uid(Src) ->
    get_src_uid(Src, ?EQUIPMENT_UID).

%% ----------------------------------------------------
%% @doc
%%      生成一个唯一的军团uid
%% @end
%% ----------------------------------------------------
-spec create_corps_uid(Src :: atom()) -> integer().
create_corps_uid(Src) ->
    get_src_uid(Src, ?CORPS_UID).
%% ----------------------------------------------------
%% @doc
%%      生成一个唯一的战报uid
%% @end
%% ----------------------------------------------------
-spec create_report_uid(Src :: atom()) -> integer().
create_report_uid(Src) ->
    get_src_uid(Src, ?REPORT_UID).

create_refresh_monster_index(Src) ->
    Pid = args_system:get_pid(Src),
    Sid = args_system:get_sid(Src),
    {ok, Index} = zm_unique_int:get(game_lib:get_table(Src, uid), {Pid, Sid, ?REFRESH_MONSTER_INDEX}, 1),
    Index.

%% ----------------------------------------------------
%% @doc
%%      生成一个唯一的宝物uid
%% @end
%% ----------------------------------------------------
-spec create_treasure_uid(Src :: atom()) -> integer().
create_treasure_uid(Src) ->
    get_src_uid(Src, ?TREASURE_UID).

%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
create_orderuid(Src) ->
    get_src_uid(Src, ?ORDERUID).
%%%====================LOC FUNCTION====================
%% ----------------------------------------------------
%% @doc
%%      根据Type,生成一个唯一的uid
%% @end
%% ----------------------------------------------------
get_src_uid(Src, Type) ->
    Pid = args_system:get_pid(Src),
    Sid = args_system:get_sid(Src),
    {ok, PropUid} = zm_unique_int:get(game_lib:get_table(Src, uid), {Pid, Sid, Type}, 1),
    get_uid(Pid, Sid, PropUid).
