%%各种写日志
-module(log_lib).

%%%=======================STATEMENT====================
-description("log_lib").
-copyright("seasky,www.seasky.cn").
-author({cb, 'chenbin@youkia.net'}).
-vsn(1).

%%%=======================EXPORT=======================
-export([log_login/3, log_fight/3, log_cash/3, log_gm/3, log_warn/5]).
%%%=======================INCLUDE======================

%%%=======================RECORD=======================

%%%=======================DEFINE=======================
%%登录日志
-define(LOG_LOGIN, login_log).
%%GM操作记录
-define(LOG_GM, gm_log).
%%战报
-define(LOG_FIGHT, fight_log).
%%充值日志
-define(LOG_CASH, cash_log).
%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% Func: log_gm/3 Module产生日志的MOD,Mark日志标记信息,Info日志内容
%% Description: 写login操作日志
%% Returns: 
%% ----------------------------------------------------
log_login(Module, Mark, Info) ->
    log(?LOG_LOGIN, Module, Mark, Info).
%% ----------------------------------------------------
%% Func: log_gm/3 Module产生日志的MOD,Mark日志标记信息,Info日志内容
%% Description: 写GM操作日志
%% Returns: 
%% ----------------------------------------------------
log_gm(Module, Mark, Info) ->
    log(?LOG_GM, Module, Mark, Info).
%% ----------------------------------------------------
%% Func: log_fight/3 Module产生日志的MOD,Mark日志标记信息,Info日志内容
%% Description: 写战报日志
%% Returns: 
%% ----------------------------------------------------
log_fight(Module, Mark, Info) ->
    log(?LOG_FIGHT, Module, Mark, Info).
%% ----------------------------------------------------
%% Func: log_cash/3 Module产生日志的MOD,Mark日志标记信息,Info日志内容
%% Description: 写充值日志
%% Returns: 
%% ----------------------------------------------------
log_cash(Module, Mark, Info) ->
    log(?LOG_CASH, Module, Mark, Info).
%% ----------------------------------------------------
%% Func: log/4  Type指定类型日志,Module产生日志的MOD,Mark日志标记信息,Info日志内容
%% Description: 写日志
%% Returns:
%% ----------------------------------------------------
log(Type, Module, Mark, Info) ->
    zm_log:log(string_lib:to_atom(lists:concat(["zm_logger:", Type])),
        Module, Mark, ?MODULE, log, Info).

%% ----------------------------------------------------
%% Func: log_warn/5
%% Description: 写warn日志(gm控制开关,是否写)
%% Returns:
%% ----------------------------------------------------
log_warn(Src, Type, Mod, Code, Data) ->
    case zm_config:get('$push_log', 'flag') of
        'none' ->
            'ok';
        _ ->
            zm_log:warn(Src, Type, Mod, Code, Data)
    end.

%%%===================LOCAL FUNCTIONS==================