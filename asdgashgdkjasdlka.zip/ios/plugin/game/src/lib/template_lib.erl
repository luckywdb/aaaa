%%sid对应各模板存储和工具
-module(template_lib).

%%%=======================STATEMENT====================
-description("template_lib").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([add_template/4, get_templates/2, del_sid/3, get_sids/2, get_config/4, check_sid/3, get_key/2]).

%%%=======================INCLUDE======================

%%%=======================RECORD=======================

%%%=======================DEFINE=======================


%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% Func:add_template/2
%% description: 新增模板,{Sid,TemplateName}
%% Return:
%%-------------------------------------------------------------------
add_template(Src, Key, Sid, TemplateName) ->
    Fun = fun(_, List) ->
        {ok, ok, lists:keystore(Sid, 1, List, {Sid, TemplateName})}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'sid_template'), get_key(Src, Key), [], Fun, []).

%%-------------------------------------------------------------------
%% Func:get_templates/2
%% description: 根据key获取所有该类型的sid对应模板列表
%% Return:list
%%-------------------------------------------------------------------
get_templates(Src, Key) ->
    z_db_lib:get(game_lib:get_table(Src, 'sid_template'), get_key(Src, Key), []).

%%-------------------------------------------------------------------
%% Func:get_sids/2
%% description: 获取key对应的sid列表
%% Return:list
%%-------------------------------------------------------------------
get_sids(Src, Key) ->
    List = get_templates(Src, Key),
    [element(1, Template) || Template <- List].

%%-------------------------------------------------------------------
%% Func:del_sid/3
%% description:删除key对应的sid
%% Return:
%%-------------------------------------------------------------------
del_sid(Src, Key, Sid) ->
    Fun = fun(_, List) ->
        {ok, ok, lists:keydelete(Sid, 1, List)}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'sid_template'), get_key(Src, Key), [], Fun, []).

%%-------------------------------------------------------------------
%% Func:get_config/2
%% description: 根据sid获取对应的配置
%% Return:
%%-------------------------------------------------------------------
get_config(Src, Key, Sid, ConfigName) ->
    ConfigKey = case lists:keyfind(Sid, 1, get_templates(Src, Key)) of
        Template when is_tuple(Template) ->
            element(2, Template);
        _ ->
            Sid
    end,
    zm_config:get(ConfigName, ConfigKey).

%%-------------------------------------------------------------------
%% Func:check_sid/2
%% description: 判断sid是否存在
%% Return:
%%-------------------------------------------------------------------
check_sid(Src, Key, Sid) ->
    lists:member(Sid, get_sids(Src, Key)).

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% Func: get_key/2
%% Description: 获取key
%% Returns: 
%% ----------------------------------------------------
get_key(Src, Key) ->
    game_lib:get_server_key(Src, Key).