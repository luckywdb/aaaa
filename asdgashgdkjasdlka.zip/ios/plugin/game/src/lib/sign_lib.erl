%%密钥签名工具
-module(sign_lib).
-description("sign_lib").
-copyright({seasky, 'www.seasky.cn'}).
-author({hzh, 'huangzhenghan@youkia.net'}).
-vsn(1).
%%%=======================EXPORT=======================
-export([sign_compute/2, login_check/2]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% Func: sign_compute/2
%% Description: 密钥计算
%% Returns:
%% ----------------------------------------------------
sign_compute(_PId, Par) ->
    {key, Key} = zm_config:get(sign, key),
    Md5 = public_lib:md5_str(lists:concat([Par, Key])),
    End = 15,
    lists:append(lists:reverse(lists:sublist(Md5, End)),
        lists:reverse(lists:sublist(Md5, End + 2, length(Md5) - End - 1))).

%-------------------------------------------------------------------
% Func:login_check/2
% description:登录签名验证
% Return:true验证成功
%-------------------------------------------------------------------
login_check(Sign, {PId, Time}) ->
    Sign =:= sign_lib:sign_compute(PId, lists:concat([PId, Time])).
