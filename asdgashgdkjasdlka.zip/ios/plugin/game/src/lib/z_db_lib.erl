%%数据库工具
-module(z_db_lib).
-description("z_db_lib").
-copyright({seasky, 'www.seasky.cn'}).
-author({cb, 'chenbin@youkia.net'}).
-vsn(1).

%%%=======================EXPORT======================
-export([lock/4, get/2, get/3, gets/2, gets/3, gets/4, update/3, update/4, update/5, update/7, delete/2, delete1/2, delete1/3]).
-export([table_iterate/5, table_iterate/6, get_all_record/2, get_all_record/3, get_count/1, clear/1]).
-export([get_field/3, get_field/4, update_field/4, update_field/5, update_field/6, update_field/8]).
-export([transformation_tablekey/2, handle/4, handle/5, init_args/1, get_value/2, get_value/3]).
-export([iterate_data/2, iterate_kvdata/2, iterate_key/2, backup/0, del_db_overdue/0]).
%%%=======================INCLUDE======================

%%%=======================RECORD=======================

%%%=======================DEFINE=======================
%%超时
-define(TIME_OUT, 5000).
%%超时
-define(TRANSACTION_TIME_OUT, 7000).
%%读锁时间
-define(READ_LOCK_TIME, 7000).
%%读超时时间
-define(READ_TIME_OUT, 5000).
%%%=================EXPORTED FUNCTIONS===================
%% ----------------------------------------------------
%% Func: lock/4
%% Description: 锁方法(LockTime 大于0是进行锁，  0为解锁)
%% Returns: atom | Reason
%% ----------------------------------------------------
lock(Table, Key, LockTime, TimeOut) ->
    case zm_db_client:lock(Table, Key, ?MODULE, LockTime, TimeOut) of
        'ok' ->
            'ok';
        {error, Reason} ->
            throw(Reason)
    end.

%% ----------------------------------------------------
%% Func: clear/1
%% Description: 清除表数据
%% Returns: atom | Reason
%% ----------------------------------------------------
clear(Table) when is_atom(Table) ->
    zm_db_client:clear(Table).

%% ----------------------------------------------------
%% Func: get_count/1
%% Description: 得到表数据条数
%% Returns: integer | Reason
%% ----------------------------------------------------
get_count(Table) ->
    case zm_db_client:count(Table) of
        {'ok', Number} ->
            Number;
        Reason ->
            throw(Reason)
    end.

%% ----------------------------------------------------
%% Func: gets/2 | gets/3 | gets/4
%% Description: 获得单表多数据 | 多表多数据  
%% Returns: list | Reason
%% ----------------------------------------------------
gets(Table, Keys) ->
    gets(Table, Keys, 'none', ?READ_TIME_OUT).
gets(Table, Keys, Default) ->
    gets(Table, Keys, Default, ?READ_TIME_OUT).
gets(Table, Keys, Default, TimeOut) when is_atom(Table) ->
    case zm_db_client:reads([{Table, Key} || Key <- Keys], TimeOut) of
        {'ok', List} ->
            lists:map(fun({'$nil', _, _}) -> Default; ({Value, _, _}) -> Value end, List);
        {'error', Reason} ->
            throw(Reason)
    end;
gets([_ | _] = Tables, Keys, Default, TimeOut) ->
    case zm_db_client:reads(lists:zipwith(fun(X, Y) -> {X, Y} end, Tables, Keys), TimeOut) of
        {'ok', List} ->
            lists:map(fun({'$nil', _, _}) -> Default; ({Value, _, _}) -> Value end, List);
        {'error', Reason} ->
            throw(Reason)
    end.

%% ----------------------------------------------------
%% Func: get/2 | get/3
%% Description: 获得数据
%% Returns: '$nil' | term |Reason
%% ----------------------------------------------------
get(Table, Key) ->
    get(Table, Key, 'none').
get(Table, Key, Default) ->
    case zm_db_client:read(Table, Key, ?READ_TIME_OUT) of
        {'ok', '$nil', _Vsn, _Time} ->
            Default;
        {'ok', Args, _Vsn, _Time} ->
            Args;
        {'error', Reason} ->
            throw(Reason)
    end.

%% ----------------------------------------------------
%% Func: get_field/3 | get_field/4
%% Description: 获得数据
%% Returns: '$nil' | term |Reason
%% ----------------------------------------------------
get_field(Table, Key, Field) ->
    get_field(Table, Key, Field, 'none').
get_field(Table, Key, Field, Default) ->
    case zm_db_client:read(Table, Key, Field, ?READ_TIME_OUT) of
        {'ok', '$nil', _Vsn, _Time} ->
            Default;
        {'ok', Args, _Vsn, _Time} ->
            Args;
        {'error', Reason} ->
            throw(Reason)
    end.

%% ----------------------------------------------------
%% Func: update/3 | update/4 | update/5 | update/7
%% Description: 更新数据
%% Returns: term｜Reason
%% ----------------------------------------------------
update(Table, Key, Args) ->
    update(Table, Key, 'none', fun(A, _Value) -> {'ok', 'ok', A} end, Args, ?READ_LOCK_TIME, ?READ_TIME_OUT).
update(Table, Key, Fun, Args) ->
    update(Table, Key, 'none', Fun, Args, ?READ_LOCK_TIME, ?READ_TIME_OUT).
update(Table, Key, Default, Fun, Args) ->
    update(Table, Key, Default, Fun, Args, ?READ_LOCK_TIME, ?READ_TIME_OUT).
update(Table, Key, Default, Fun, Args, ReadLockTime, ReadTimeOut) ->
    {Value, Vsn} = case zm_db_client:read(Table, Key, ?MODULE, ReadLockTime, ReadTimeOut) of
        {'ok', '$nil', V, _} ->
            {Default, V};
        {'ok', Info, V, _} ->
            {Info, V};
        {'error', Reason1} ->
            throw(Reason1)
    end,
    try Fun(Args, Value) of
        {'ok', Reply} ->%%不返回数据处理结果,进行解锁返回来
            lock(Table, Key, 0, ?TIME_OUT),
            Reply;
        {'ok', Reply, Value} ->%%没有处理任务处理,进行解锁返回来
            lock(Table, Key, 0, ?TIME_OUT),
            Reply;
        {'ok', Reply, 'delete'} ->%%删除数据
            case zm_db_client:delete(Table, Key, Vsn, ?MODULE) of
                'ok' ->
                    Reply;
                {'error', Reason2} ->
                    lock(Table, Key, 0, ?TIME_OUT),
                    throw({'udelete_fun_error', Args, Value, Reason2, erlang:get_stacktrace()})
            end;
        {'ok', Reply, NewInfo} ->
            case zm_db_client:write(Table, Key, NewInfo, Vsn, ?MODULE, 0) of
                'ok' ->
                    Reply;
                {'error', Reason2} ->
                    lock(Table, Key, 0, ?TIME_OUT),
                    throw({'update_fun_error', Args, Value, Reason2, erlang:get_stacktrace()})
            end;
        Other ->
            lock(Table, Key, 0, ?TIME_OUT),
            throw({'update_fun_error', 'bad_return_value', Other, erlang:fun_info(Fun, module), erlang:fun_info(Fun, name)})
    catch
        throw:Reason3 when is_list(Reason3) ->
            %%业务层抛出的error,进行人工解锁
            lock(Table, Key, 0, ?TIME_OUT),
            Reason3;
        _:Reason4 ->
            lock(Table, Key, 0, ?TIME_OUT),
            throw({'update_fun_error', Args, Value, Reason4, erlang:get_stacktrace()})
    end.

%% ----------------------------------------------------
%% Func:  update_field/4 | update_field/5| update_field/6 | update_field/8
%% Description: 更新指定或数据
%% Returns: term｜Reason
%% ----------------------------------------------------
update_field(Table, Key, Field, Args) ->
    update_field(Table, Key, Field, none, fun(A, _Value) -> {'ok', 'ok', A} end, Args, ?READ_LOCK_TIME, ?READ_TIME_OUT).
update_field(Table, Key, Field, Fun, Args) ->
    update_field(Table, Key, Field, none, Fun, Args, ?READ_LOCK_TIME, ?READ_TIME_OUT).
update_field(Table, Key, Field, Default, Fun, Args) ->
    update_field(Table, Key, Field, Default, Fun, Args, ?READ_LOCK_TIME, ?READ_TIME_OUT).
update_field(Table, Key, Field, Default, Fun, Args, ReadLockTime, ReadTimeOut) ->
    {Value, Vsn} = case zm_db_client:read(Table, Key, Field, ?MODULE, ReadLockTime, ReadTimeOut) of
        {ok, '$nil', V, _} ->
            {Default, V};
        {ok, Info, V, _} ->
            {Info, V};
        {error, Reason1} ->
            throw(Reason1)
    end,
    try Fun(Args, Value) of
        {'ok', Reply} ->%%不返回数据处理结果,进行解锁返回来
            lock(Table, Key, 0, ?TIME_OUT),
            Reply;
        {'ok', Reply, Value} ->%%没有处理任务处理,进行解锁返回来
            lock(Table, Key, 0, ?TIME_OUT),
            Reply;
        {'ok', Reply, NewInfo} ->
            case zm_db_client:write(Table, Key, Field, NewInfo, Vsn, ?MODULE, 0) of
                'ok' ->
                    Reply;
                {'error', Reason2} ->
                    lock(Table, Key, 0, ?TIME_OUT),
                    throw({'update_fun_error', Args, Value, Reason2, erlang:get_stacktrace()})
            end;
        Other ->
            lock(Table, Key, 0, ?TIME_OUT),
            throw({'update_fun_error', 'bad_return_value', Other, erlang:fun_info(Fun, module), erlang:fun_info(Fun, name)})
    catch
        throw:Reason3 when is_list(Reason3) ->
            %%业务层抛出的error,进行人工解锁
            lock(Table, Key, 0, ?TIME_OUT),
            Reason3;
        _:Reason4 ->
            lock(Table, Key, 0, ?TIME_OUT),
            throw({'update_fun_error', Args, Value, Reason4, erlang:get_stacktrace()})
    end.

%% ----------------------------------------------------
%% Func: delete/2
%% Description: 删除数据(返回ok)
%% Returns: ok｜Reason
%% ----------------------------------------------------
delete(Table, Key) ->
    case zm_db_client:read(Table, Key, ?MODULE, ?READ_LOCK_TIME, ?READ_TIME_OUT) of
        {'ok', '$nil', _Vsn, _Time} ->
            lock(Table, Key, 0, ?TIME_OUT),
            'ok';
        {'ok', _Info, Vsn, _Time} ->
            case zm_db_client:delete(Table, Key, Vsn, ?MODULE) of
                'ok' ->
                    'ok';
                {'error', Reason} ->
                    lock(Table, Key, 0, ?TIME_OUT),
                    throw(Reason)
            end;
        {'error', Reason} ->
            lock(Table, Key, 0, ?TIME_OUT),
            throw(Reason)
    end.

%% ----------------------------------------------------
%% Func: delete1/2
%% Description: 删除数据(如果存在值,则返回该值)
%% Returns: ok｜Reason
%% ----------------------------------------------------
delete1(Table, Key) ->
    delete1(Table, Key, 'ok').
delete1(Table, Key, Default) ->
    case zm_db_client:read(Table, Key, ?MODULE, ?READ_LOCK_TIME, ?READ_TIME_OUT) of
        {'ok', '$nil', _Vsn, _Time} ->
            lock(Table, Key, 0, ?TIME_OUT),
            Default;
        {'ok', Info, Vsn, _Time} ->
            case zm_db_client:delete(Table, Key, Vsn, ?MODULE) of
                'ok' ->
                    Info;
                {'error', Reason} ->
                    lock(Table, Key, 0, ?TIME_OUT),
                    throw(Reason)
            end;
        {'error', Reason} ->
            lock(Table, Key, 0, ?TIME_OUT),
            throw(Reason)
    end.

%% ----------------------------------------------------
%% Func: table_iterate/6
%% Description: 数据库迭代器 Table：表，Fun(Src,Key,Args,R)：迭代的处理方法，返回{break,R}|{ok,R}|R，Args：带入参数，R：迭代结果返回
%% Returns: Reason ｜ term
%% ----------------------------------------------------
table_iterate(Src, Table, Fun, Args, R, Sort) ->
    case zm_db_client:iterate(Table, Sort, false) of
        {'ok', Iterator} ->
            case iterator(Src, Iterator, Fun, Args, R) of
                {'ok', Return} ->
                    Return;
                {'error', Reason} ->
                    throw(Reason)
            end;
        {'error', Reason} ->
            throw(Reason)
    end.

%% ----------------------------------------------------
%% Func: table_iterate/5
%% Description: 数据库迭代器 Table：表，Fun(Src,Key,Args,R)：迭代的处理方法，返回{break,R}|{ok,R}|R，Args：带入参数，R：迭代结果返回
%% Returns: Reason ｜ term
%% ----------------------------------------------------
table_iterate(Src, Table, Fun, Args, R) ->
    case zm_db_client:iterate(Table, descending, false) of
        {'ok', Iterator} ->
            case iterator(Src, Iterator, Fun, Args, R) of
                {'ok', Return} ->
                    Return;
                {'error', Reason} ->
                    throw(Reason)
            end;
        {'error', Reason} ->
            throw(Reason)
    end.
%%迭代器处理数据
iterator(Src, Iterator, Fun, Args, R) ->
    case zm_db_client:iterate_next(Iterator) of
        {'ok', {Key, _, _}, NewIterator} ->
            case Fun(Src, Key, Args, R) of
                {'break', R1} ->
                    {'ok', R1};
                {'ok', R1} ->
                    iterator(Src, NewIterator, Fun, Args, R1);
                R1 ->
                    iterator(Src, NewIterator, Fun, Args, R1)
            end;
        'over' ->
            {'ok', R};
        E ->
            E
    end.

%% ----------------------------------------------------
%% Func: get_all_record/2
%% Description: 得到整个表指定量的数据,调试中使用
%% Returns: Reason ｜ term
%% ----------------------------------------------------
get_all_record(Table, Max) ->
    get_all_record(Table, 0, Max).

%% ----------------------------------------------------
%% Func: get_all_record/2
%% Description: 得到整个表指定位置开始的指定数据量的数据,调试中使用
%% Returns:
%% ----------------------------------------------------
get_all_record(Table, Start, Max) ->
    case zm_db_client:iterate(Table, descending, false) of
        {'ok', Iterator} ->
            get_all_record_(Table, Iterator, Start, 1, 1, Max, []);
        E ->
            E
    end.
get_all_record_(Table, Iterator, Start, Index, Min, Max, L) when Index < Start ->
    case zm_db_client:iterate_next(Iterator) of
        {'ok', _, NewIterator} ->
            get_all_record_(Table, NewIterator, Start, Index + 1, Min, Max, L);
        {'error', Reason} ->
            throw(Reason)
    end;
get_all_record_(Table, Iterator, Start, Index, Min, Max, L) when Min =< Max ->
    case zm_db_client:iterate_next(Iterator) of
        {'ok', {Key, _, _}, NewIterator} ->
            case zm_db_client:read(Table, Key, ?READ_TIME_OUT) of
                {'ok', '$nil', _, _} ->
                    get_all_record_(Table, NewIterator, Start, Index + 1, Min + 1, Max, [{Min, {Key, '$nil'}} | L]);
                {'ok', Record, _, _} ->
                    get_all_record_(Table, NewIterator, Start, Index + 1, Min + 1, Max, [{Min, {Key, Record}} | L]);
                {'error', Reason} ->
                    throw(Reason)
            end;
        'over' ->
            L;
        E ->
            E
    end;
get_all_record_(_Table, _Iterator, _Start, _Index, _Min, _Max, L) ->
    L.

%-------------------------------------------------------------------
% Func: transformation_tablekey/2
% description: 将需要的数据进行转换为{table,key}, 以供事务处理
% Return: {atom,[{table,key}|_],list}
%-------------------------------------------------------------------
transformation_tablekey(TableName, List) ->
    transformation_tablekey(TableName, List, [], []).
transformation_tablekey(TableName, [{Key, Value} | T], List, Defaults) ->
    {Key, Table} = zm_config:get(TableName, Key),
    transformation_tablekey(TableName, T, [{Table, Value} | List], ['$nil' | Defaults]);
transformation_tablekey(TableName, [{Key, Value, Default} | T], List, Defaults) ->
    {Key, Table} = zm_config:get(TableName, Key),
    transformation_tablekey(TableName, T, [{Table, Value} | List], [Default | Defaults]);
transformation_tablekey(_TableName, [], List, Defaults) ->
    {'$KeyDefaults', {lists:reverse(List), lists:reverse(Defaults)}}.

%-------------------------------------------------------------------
% Func: init_args/1
% description: 构建args kv参数
% Return: tuple
%-------------------------------------------------------------------
init_args([_ | _] = Args) ->
    {'$Args', Args}.

%-------------------------------------------------------------------
% Func: get_value/2 | get_value/3
% description: 获取msg中的K对应的v值，两参为取'$Reply'值
% Return: tuple
%-------------------------------------------------------------------
get_value(Msg, Default) ->
    z_lib:get_value(Msg, '$Reply', Default).
get_value(Msg, Key, Default) ->
    z_lib:get_value(Msg, Key, Default).

%-------------------------------------------------------------------
% Func: handle/4 | handle/5
% description: 进行数据处理
% Return: Reason | term
%-------------------------------------------------------------------
handle(TableName, MFA, Args, {'$KeyDefaults', {TableKeys, Defaults}}) ->
    handle(TableName, MFA, Args, {TableKeys, Defaults}, ?TRANSACTION_TIME_OUT).
handle([{M, F, [{'$Table', _} | _] = A}], Session, Attr, Info, Msg) ->%%带的参数必须为kv
    {[{_, _} | _] = TableKeys, [_ | _] = Defaults} = z_lib:get_value(Msg, '$KeyDefaults', {[], []}),
    case handle(z_lib:get_value(A, '$Table', 'none'), {M, F, [{'session', Session}, {'attr', Attr}, {'info', Info}, {'msg', Msg} | A]},
        z_lib:get_value(Msg, '$Args', []), {TableKeys, Defaults}, z_lib:get_value(Msg, '$TimeOut', ?TRANSACTION_TIME_OUT)) of
        {'break', NAttr, Info, Reply} ->
            {'break', NAttr, Info, [{'msg', Reply}]};
        {'ok', NAttr, Info, Reply} ->
            {'ok', NAttr, Info, lists:keystore('$Reply', 1, Msg, {'$Reply', Reply})};
        Reply ->%%默认不在进行向下的mfa
            {'break', [], Info, [{'msg', Reply}]}
    end;
handle(TableName, MFA, Args, {TableKeys, Defaults}, TimeOut) ->
    case zm_db_client:transaction(TableKeys, fun transaction/2, {TableName, Defaults, {MFA, Args}}, TimeOut) of
        {'ok', Value} ->
            Value;
        {'break', Reason} ->
            Reason;
        {'error', Reason} ->
            throw(Reason)
    end.

%%%===================LOCAL FUNCTIONS 模块内部调用==================
%%参数的第一个值必定是个执行业务逻辑的MFA
transaction({TableName, Defaults, {{M, F, A}, Args}}, DBData) ->
    IndexData = add_index(DBData),
    try M:F(A, Args, add_default(IndexData, Defaults)) of%%执行自己的业务逻辑
        {ok, Msg} ->
            {'break', Msg};
        {ok, Msg, ModifyList} ->
            {'ok', Msg, arrange_modify(ModifyList, IndexData)};
        {ok, Msg, ModifyList, InsertList} ->
            {'ok', Msg, arrange_modify(ModifyList, IndexData), arrange_insert(TableName, InsertList)};
        Other ->
            throw({'tran_mfa_error', 'bad_return_value', Other, {mf, {M, F}}})
    catch
        throw:Reason when is_list(Reason) ->
            {'break', Reason};
        _:Reason ->
            throw({'tran_mfa_error', {A, Args}, Reason, erlang:get_stacktrace()})
    end;

%%参数的第一个值必定是个执行业务逻辑的function
transaction({TableName, Defaults, {F, Args}}, DBData) when is_function(F) ->
    IndexData = add_index(DBData),
    try F(Args, add_default(IndexData, Defaults)) of%%执行自己的业务逻辑
        {ok, Msg} ->
            {'break', Msg};
        {'ok', Msg, ModifyList} ->
            {'ok', Msg, arrange_modify(ModifyList, IndexData)};
        {'ok', Msg, ModifyList, InsertList} ->
            {'ok', Msg, arrange_modify(ModifyList, IndexData), arrange_insert(TableName, InsertList)};
        Other ->
            throw({'tran_mfa_error', 'bad_return_value', Other, erlang:fun_info(F, module), erlang:fun_info(F, name)})
    catch
        throw:Reason when is_list(Reason) ->
            {'break', Reason};
        _:Reason ->
            throw({'tran_fun_error', Args, Reason, erlang:get_stacktrace()})
    end.

%%增加位置标示，以后进行写数据位
add_index(List) ->
    add_index(List, 1, []).
add_index([H | T], Index, List) ->
    add_index(T, Index + 1, [{Index, H} | List]);
add_index([], _Index, List) ->
    lists:reverse(List).

%%增加默认值
add_default(List, Defaults) ->
    add_default(List, Defaults, []).
add_default([{Index, '$nil'} | T], [DH | DT], List) ->
    add_default(T, DT, [{Index, DH} | List]);
add_default([Item | T], [_ | DT], List) ->
    add_default(T, DT, [Item | List]);
add_default([], [], List) ->
    lists:reverse(List).

%%对进行修改后的数据重组为事务需要的格式
arrange_modify(ModifyList, IndexData) ->
    List = erlang:list_to_tuple(IndexData),
    arrange_modify(ModifyList, List, erlang:list_to_tuple(lists:duplicate(size(List), '$ignore'))).
arrange_modify([{Index, Value} | T], List, R) ->
    {Index, V} = erlang:element(Index, List),
    if
        Value =:= 'delete' ->%%发现是delete原子就进行删除记录
            arrange_modify(T, List, setelement(Index, R, '$nil'));
        V =/= Value ->%%发现不同的数据就进行保存
            arrange_modify(T, List, setelement(Index, R, Value));
        true ->%%发现相同数据就采用默认的方式，'$ignore'
            arrange_modify(T, List, R)
    end;
arrange_modify([], _List, R) ->
    erlang:tuple_to_list(R).

%%对插入的数据进行事务需要格式转换	格式:{table,key,value}
arrange_insert(TableName, InsertList) ->
    arrange_insert(TableName, InsertList, []).
arrange_insert(TableName, [{MappingTableKey, Key, Value} | T], List) ->
    case zm_config:get(TableName, MappingTableKey) of
        none ->
            throw({MappingTableKey, "table_no_config"});
        {MappingTableKey, MappingTable} ->
            arrange_insert(TableName, T, [{MappingTable, Key, Value} | List])
    end;
arrange_insert(_Table, [], List) ->
    List.

%% ----------------------------------------------------
%% Func: iterate_data/3
%% Description: 迭代数据库所有数据
%% Args: iterate_data(Src, Type)
%% Returns: 
%% ----------------------------------------------------
iterate_data(Src, Type) ->
    Table = game_lib:get_table(Src, Type),
    case zm_db_client:iterate(Table, descending, false) of
        {ok, Iterator} ->
            iterate_data_(Table, Iterator, []);
        {error, Reason} ->
            throw(Reason)
    end.
iterate_data_(Table, Iterator, L) ->
    case zm_db_client:iterate_next(Iterator) of
        {ok, {Key, _, _}, NewIterator} ->
            case get(Table, Key) of
                none ->
                    iterate_data_(Table, NewIterator, L);
                Data ->
                    iterate_data_(Table, NewIterator, [Data | L])
            end;
        over ->
            L;
        E ->
            E
    end.
%% ----------------------------------------------------
%% Func: iterate_kvdata/3
%% Description: 迭代数据库所有数据
%% Args: iterate_kvdata(Src, Type)
%% Returns: [{Key,Value}|_]
%% ----------------------------------------------------
iterate_kvdata(Src, Type) ->
    Table = game_lib:get_table(Src, Type),
    case zm_db_client:iterate(Table, descending, false) of
        {ok, Iterator} ->
            iterate_kvdata_(Table, Iterator, []);
        {error, Reason} ->
            throw(Reason)
    end.
iterate_kvdata_(Table, Iterator, L) ->
    case zm_db_client:iterate_next(Iterator) of
        {ok, {Key, _, _}, NewIterator} ->
            case get(Table, Key) of
                none ->
                    iterate_kvdata_(Table, NewIterator, L);
                Data ->
                    iterate_kvdata_(Table, NewIterator, [{Key, Data} | L])
            end;
        over ->
            L;
        E ->
            E
    end.

%% ----------------------------------------------------
%% Func: iterate_kvdata/3
%% Description: 迭代数据库所有key
%% Args: iterate_key(Src, Type)
%% Returns: [{Key,Value}|_]
%% ----------------------------------------------------
iterate_key(Src, Type) ->
    Table = game_lib:get_table(Src, Type),
    case zm_db_client:iterate(Table, descending, false) of
        {ok, Iterator} ->
            iterate_key_(Iterator, []);
        {error, Reason} ->
            throw(Reason)
    end.
iterate_key_(Iterator, L) ->
    case zm_db_client:iterate_next(Iterator) of
        {ok, {Key, _, _}, NewIterator} ->
            iterate_key_(NewIterator, [Key | L]);
        over ->
            L;
        E ->
            E
    end.

%% ----------------------------------------------------
%% @doc
%%       删除无效的db文件，只有符合规则的db才能用
%% @end
%% ----------------------------------------------------
del_db_overdue() ->
    P1 = "../db/",
    {_, Fs1} = file:list_dir(P1),
    io:format("Format==del_db_overdue db=~p~n", [list_to_tuple(Fs1)]),
    Fun3 = fun(F3, P3) ->
        P4 = P3 ++ F3 ++ "/",
        IsF = filelib:is_dir(P4), %%如果是快照的文件夹才删
        if
            IsF ->
                {_, Fs6} = file:list_dir(P4),
                [file:delete(P4 ++ F) || F <- Fs6], %%删除里面的文件
                file:del_dir(P4); %%删除文件夹
            true ->
                ok
        end,
        P3
    end,
    Fun2 = fun(F2, P2) ->
        P3 = P2 ++ F2 ++ "/",
        {_, Fs3} = file:list_dir(P3),
        Fs4 = [F || F <- Fs3, (F =/= ".opts.run" andalso F =/= ".opts")], %%去缓存文件
        Fs5 = case lists:reverse(lists:sort(Fs4)) of %%排序反转去头，正在使用的不能删
            [_ | T] ->
                T;
            L1 ->
                L1
        end,
        lists:foldl(Fun3, P3, Fs5),
        P2
    end,
    Fun1 = fun(F1, R1) ->
        P2 = P1 ++ F1 ++ "/",
        {_, Fs2} = file:list_dir(P2),
        lists:foldl(Fun2, P2, Fs2),
        R1
    end,
    lists:foldl(Fun1, ok, Fs1),
    io:format("Format==del_db_overdue db ok=~n"),
    ok.

%% ----------------------------------------------------
%% @doc
%%      快照备份
%% @end
%% ----------------------------------------------------
backup() ->
    backup_(zm_db_server:table_status(), snapshot).

%% ----------------------------------------------------
%% @doc
%%      快照备份
%% @end
%% ----------------------------------------------------
backup_([H | T], Type) ->
    {_, Pid} = lists:keyfind(pid, 1, H),
    case zm_db_table:get_storage(Pid) of
        {'zm_storage_memory', _} ->
            backup_(T, Type);
        {M, A} ->
            M:Type(A),
            timer:sleep(50),
            backup_(T, Type)
    end;
backup_([], _Type) ->
    ok.
