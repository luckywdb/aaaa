%%@doc http 发通信模块
%%```
%%使用模块向第三方发http通信
%%'''
%%@end


-module(http_client).

-description("http_client").
-copyright({seasky, 'www.seasky.cn'}).
-author({cb, 'chenbin@youkia.net'}).
-vsn(1).

%%%=======================EXPORT=======================
-export([open/1, is_alive/1, close/1, asyn_request/4, sync_request/4]).

%%%=======================DEFINE=======================
%%服务类型
-define(SERVICE_TYPE, httpc).
%%异步通信属性
-define(SYNC_REQUEST_ATTRIBUTE, {sync, false}).
%%连接对象
-record(con_desc, {service_name = "", httpc_pid = none, options = []}).

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc 创建一个连接
%% @spec open(Args::any()) -> return()
%% where
%%      return() = Con
%%@end
%% ----------------------------------------------------
open(Args) ->
    ResultInets = inets:start(),
    ResultSSL = ssl:start(),
    if
        (ResultInets =:= 'ok') orelse (ResultInets =:= {'error', {'already_started', 'inets'}}) orelse
            (ResultSSL =:= 'ok') orelse (ResultSSL =:= {'error', {'already_started', 'ssl'}}) ->
            Name = z_lib:get_value(Args, 'profile', none),
            ServiceName = string_lib:to_atom(lists:concat([Name, "_", pid_to_list(self()), "_", integer_to_list(z_lib:now_millisecond())])),
            case inets:start(?SERVICE_TYPE, [{'profile', ServiceName}]) of
                {ok, Pid} ->
                    Options = z_lib:get_value(Args, 'options', []),
                    #con_desc{service_name = ServiceName, httpc_pid = Pid, options = Options};
                E ->
                    E
            end;
        true ->
            [{'inets_err', ResultInets}, {'ssl_eer', ResultSSL}]
    end.

%% ----------------------------------------------------
%% @doc 检查连接是否还活着
%% @spec is_alive(Pid::pid()) -> return()
%% where
%%      return() = true | false
%%@end
%% ----------------------------------------------------
is_alive(#con_desc{httpc_pid = Pid}) ->
    check_httpc(Pid, httpc:services());
is_alive(_) ->
    false.
%%进行校验httpc pid
check_httpc(_Pid, []) ->
    false;
check_httpc(Pid, [{?SERVICE_TYPE, Pid} | _T]) when is_pid(Pid) ->
    true;
check_httpc(Pid, [{?SERVICE_TYPE, _} | T]) ->
    check_httpc(Pid, T).

%% ----------------------------------------------------
%% @doc 关闭一个连接
%% @spec close(Pid::pid()) -> return()
%% where
%%      return() = ok
%%@end
%% ----------------------------------------------------
close(Pid) ->
    inets:stop(?SERVICE_TYPE, Pid).

%% ----------------------------------------------------
%% @doc 异步请求
%% @spec asyn_request(A::list(), Type, Msg::list(), Timeout::integer()) -> return()
%% where
%%      return() = any()
%%@end
%% ----------------------------------------------------
asyn_request(#con_desc{service_name = ServiceName}, get, Msg, Timeout) ->
    {ok, ID} = httpc:request(get, {Msg, []}, [{'timeout', Timeout}], [?SYNC_REQUEST_ATTRIBUTE], ServiceName),
    receive
        {'http', {ID, Result}} ->
            Result
    after Timeout + 1000 ->
        httpc:cancel_request(ID, ServiceName),
        throw({error, access_timeout})
    end;
asyn_request(#con_desc{service_name = ServiceName, options = Options}, 'post', [Msg, Para], Timeout) ->
    {'ok', ID} = httpc:request('post', {Msg, [], Options, Para}, [{'timeout', Timeout}], [?SYNC_REQUEST_ATTRIBUTE], ServiceName),
    receive
        {'http', {ID, Result}} ->
            Result
    after Timeout + 1000 ->
        httpc:cancel_request(ID, ServiceName),
        throw({'error', 'access_timeout'})
    end.

%% ----------------------------------------------------
%% @doc 同步请求
%% @spec sync_request(Con::pid(), Type, Msg::list(), Timeout::integer()) -> return()
%% where
%%      return() = tuple()
%%@end
%% ----------------------------------------------------
sync_request(#con_desc{service_name = ServiceName} = Con, 'get', Msg, Timeout) ->
    case httpc:request('get', {Msg, []}, [{'timeout', Timeout}], [], ServiceName) of
        {'ok', Result} ->
            {Con, Result};
        Other ->
            {Con, Other}
    end;
sync_request(#con_desc{service_name = ServiceName, 'options' = Options} = Con, 'post', [Msg, Para], Timeout) ->
    case httpc:request('post', {Msg, [], Options, Para}, [{'timeout', Timeout}], [], ServiceName) of
        {'ok', Result} ->
            {Con, Result};
        Other ->
            {Con, Other}
    end.

%%%===================LOCAL FUNCTIONS==================

