%%系统统计
-module(statistics_lib).

%%%=======================STATEMENT====================
-description("statistics_lib").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([statistics_net/2]).
-export([format_net_statistics/0]).
-export([collect/3]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%      定时采集
%% @end
%% ----------------------------------------------------
-spec collect(Src :: atom(), A :: list(), Time :: integer()) -> 'ok'.
collect(Src, [Path], _T) ->
    %由于我们开服时间都会设置成开服当天0点,统计前四天
    Online = args_system:get_online_time(Src),
    Now = time_lib:now_second(),
    if
        Now - Online > 345600 ->
            'ok';
        true ->
            statistics_net(filename:join(Path, atom_to_list(node())), game_lib:get_table(Src, 'online'))
    end.

%% ----------------------------------------------------
%% @doc
%%      网关统计
%% @end
%% ----------------------------------------------------
-spec statistics_net(atom(), Table :: atom()) -> 'ok'|term().
statistics_net(Dir, Table) ->
    DateTime = z_lib:second_to_localtime(z_lib:now_second()),
    Count = z_db_lib:get_count(Table),
    Filename = get_file_name(Dir, "(" ++ integer_to_list(Count) ++ ")_statistics", DateTime) ++ ".csv",
    filelib:ensure_dir(Filename),
    Head = "online,cmd,receive_count,receive_bytes,send_count,send_bytes\n" ++ integer_to_list(Count),
    Data = Head ++ format_net_statistics(),
    ok = public_lib:write_text_to_file(Filename, Data).


%%%===================LOCAL FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%      格式化输出网络部分统计(接收个数,接收大小,发送个数,发送大小)
%% @end
%%-------------------------------------------------------------------
-spec format_net_statistics() -> iolist().
format_net_statistics() ->
    List = zm_net_server:list(),
    z_lib:foreach(
        fun(A, {Pid, _Args}) ->
            {_CurrCount, Tree, _TotalCount} = zm_net_server:statistics(Pid),
            Ls = z_lib:foreach(
                fun(R, {{Cmd, 'resp'}, {N, Bytes}}) ->
                    {_, RCount, RBytes, _, _} =
                        case lists:keyfind(Cmd, 1, R) of
                            false ->
                                {Cmd, 0, 0, 0, 0};
                            Info ->
                                Info
                        end,
                    lists:keystore(Cmd, 1, R, {Cmd, RCount, RBytes, N, Bytes});
                    (R, {{Cmd, 'req'}, {N, Bytes}}) ->
                        {_, _, _, SCount, SBytes} =
                            case lists:keyfind(Cmd, 1, R) of
                                false ->
                                    {Cmd, 0, 0, 0, 0};
                                Info ->
                                    Info
                            end,
                        lists:keystore(Cmd, 1, R, {Cmd, N, Bytes, SCount, SBytes});
                    (R, {{Cmd, 'send'}, {N, Bytes}}) ->
                        {_, RCount, RBytes, _, _} =
                            case lists:keyfind(Cmd, 1, R) of
                                false ->
                                    {Cmd, 0, 0, 0, 0};
                                Info ->
                                    Info
                            end,
                        lists:keystore(Cmd, 1, R, {Cmd, RCount, RBytes, N, Bytes})
                end, [], sb_trees:to_list(Tree)),
            case z_lib:foreach(
                fun(R, {Cmd, RCount, RBytes, SCount, SBytes}) ->
                    S1 = io_lib:format(",~p,~p,~p,~p,~p~n", [Cmd, RCount, RBytes, SCount, SBytes]),
                    {ok, [S1 | R]}
                end, [], Ls) of
                [] ->
                    {ok, A};
                SList ->
                    {ok, [SList | A]}
            end
        end, [], List).


get_file_name(Dir, File, {{Y, M, D}, {H, Mi, Sec}}) ->
    filename:join([Dir,
        lists:concat([Y, "-", z_lib:integer_to_list(M, 2),
            "-", z_lib:integer_to_list(D, 2),
            "-", z_lib:integer_to_list(H, 2),
            "-", z_lib:integer_to_list(Mi, 2),
            "-", z_lib:integer_to_list(Sec, 2), File])
    ]).