-module(cross_battle_area_event).

%%%=======================STATEMENT====================
-description("cross_battle_area_event").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    notify/4,
    patrol_timer/3,
    init_patrol_timer/1,
    clear_patrol_timer/1
]).

%%%=======================INCLUDE======================
-include("../../game/include/cross_battle.hrl").
-include("../../../include/sign_key.hrl").
-include("../../game/include/point.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%		启动服务器初始化巡逻营数据表
%% @end
%% ----------------------------------------------------
init_patrol_timer(Src) ->
    IsCenter = args_system:is_game_center_server(Src),
    if
        IsCenter ->
            Table = game_lib:get_table(Src, 'cross_battle_area_patrol_timer'),
            Fun = fun(Src_, Key, _Args, _R) ->
                PatrolTimerList = z_db_lib:get(Table, Key),
                zm_config:set('patrol_timer', {Key, PatrolTimerList}),
                zm_dtimer:set({Src_, {'patrol_timer', Key}},
                    {?MODULE, patrol_timer, [Key]}, {time, 1000, 10000})
            end,
            z_db_lib:table_iterate(Src, Table, Fun, [], []);
        true ->
            ok
    end.
%% ----------------------------------------------------
%% @doc
%%		启动服务器初始化巡逻营数据表
%% @end
%% ----------------------------------------------------
clear_patrol_timer(Src) ->
    zm_config:delete('patrol_timer'),
    Table = game_lib:get_table(Src, 'cross_battle_area_patrol_timer'),
    Fun = fun(Src_, Key, _Args, _R) ->
        zm_dtimer:delete(Src_, {'patrol_timer', Key}),
        z_db_lib:delete(Table, Key)
    end,
    z_db_lib:table_iterate(Src, Table, Fun, [], []).
%% ----------------------------------------------------
%% @doc
%%		巡逻营定时器处理
%% @end
%% ----------------------------------------------------
patrol_timer(Src, [Key], T) ->
    Bl = zm_load:server_start_ok() =:= ?KEY,
    if
        Bl ->
            case zm_config:get('patrol_timer', Key) of
                'none' ->
                    ok;
                {_, []} ->
                    ok;
                {_, PartorTimerList} ->
                    NowTime = T div 1000,
                    Fun = fun({_, NextTime, _} = PartorTimer, _) ->
                        if
                            NowTime >= NextTime ->
                                try
                                    patrol_march(Src, Key, NowTime, PartorTimer)
                                catch
                                    E  : E1 ->
                                        zm_log:warn(?MODULE, ?MODULE, 'patrol_timer', "patrol_march_error", [{'e', E}, {'e1', E1}, {'key', Key},
                                            {'patrol_timer', PartorTimer}, {'stacktrace', erlang:get_stacktrace()}]),
                                        ok
                                end;
                            true ->
                                ok
                        end
                    end,
                    lists:foldl(Fun, ok, PartorTimerList)
            end;
        true ->
            ok
    end.
%% ----------------------------------------------------
%% @doc
%%		事件处理
%% @end
%% ----------------------------------------------------
notify(_, GameSrc, 'cross_battle_area_state_change', Args) ->
    {_, State} = lists:keyfind('state', 1, Args),
    {_, NState} = lists:keyfind('nstate', 1, Args),
    {_, CrossBattleArea} = lists:keyfind('cross_battle_area', 1, Args),
    cross_battle_area_db:update_cache_cross_battle_area(CrossBattleArea),
    if
        State =/= NState andalso NState =:= ?CROSS_SERVER_STATE_SYNC_GROUP ->
            %%开始同步分组
            cross_battle_area_sync:sync_group_corps(GameSrc, CrossBattleArea);
        true ->
            if
                State =/= NState andalso NState =:= ?CROSS_SERVER_STATE_STOP ->
                    Term = cross_battle_area:get_term(CrossBattleArea),
                    Wheel = cross_battle_area:get_wheel(CrossBattleArea),
                    StartTime = cross_battle_area:get_start_time(CrossBattleArea),
                    ContinueTime = cross_battle_area:get_continue_time(CrossBattleArea),
                    %%向子服务器推送排行榜信息
                    zm_event:notify(game_lib:get_center_src(), 'cross_battle_progress', [{'cross_battle_area', CrossBattleArea}]),
                    MapIds = cross_battle_area:get_mapids(CrossBattleArea),
                    set_front_lib:send_cross_battle_state(GameSrc, Wheel, NState, StartTime, ContinueTime),
                    %%踢掉所有在线
                    OnlineSessions = login_db:get_all_online(GameSrc),
                    lists:foreach(fun(Session) ->
                        zm_session:close(Session, {'stop', 'tcp_closed'})
                    end, OnlineSessions),
                    %%结束计算一次town积分
                    lists:foreach(fun(MapId) ->
                        cross_town_fight:add_stop_score(GameSrc, Term, Wheel, MapId)
                    end, MapIds),
                    %%立即刷新相应排行榜
                    {_, RefreshRanks} = zm_config:get('cross_battle_area_rank_info', 'refresh_ranks'),
                    NewTypes = [Type || {Type, _Num} <- RefreshRanks],
                    rank_refresh:do_refresh(GameSrc, NewTypes),
                    zm_event:notify(GameSrc, 'wheel_over', [{'season', Term}, {'wheel', Wheel}, {'map_ids', MapIds}]),
                    MapIds = cross_battle_area:get_mapids(CrossBattleArea),
                    %%返回资源
                    cross_battle_area_role:init_repay_transfer_res_timer(GameSrc, CrossBattleArea);
                true ->
                    ok
            end,
            %%状态不同,立即call通知所有游戏服务器
            case State =/= NState of
                true ->
                    cross_battle_area_sync:sync_cross_battle_state(GameSrc, State, NState, CrossBattleArea);
                false ->
                    ok
            end
    end;
notify(Types, Src, 'wheel_over', Msg) ->%%当前轮次结束
    Season = z_lib:get_value(Msg, 'season', 1),
    Wheel = z_lib:get_value(Msg, 'wheel', 1),
    MapIds = z_lib:get_value(Msg, 'map_ids', []),
    over_handle(Src, Season, Wheel, MapIds, Types);
notify(_, Src, 'create_map_build', Msg) ->%%修建地图建筑
    MapBuildSid = z_lib:get_value(Msg, 'map_build_sid', 0),
    {_, PatrolSids} = zm_config:get('map_build_info', 'map_build_patrol'),
    Bool = lists:member(MapBuildSid, PatrolSids),
    if
        Bool ->
            MapId = z_lib:get_value(Msg, 'map_id', 0),
            Point = z_lib:get_value(Msg, 'point', 0),
            MapBuildDetail = map_build_detail:get_cfg(MapBuildSid),
            {_, UpNeedTime} = map_build_detail:get_level_up_cond(1, MapBuildDetail),
            update_patrol_timer(Src, MapId, time_lib:now_second(), Point, UpNeedTime);
%%            zm_dtimer:set({Src, {'patrol_timer', Point}},
%%                {?MODULE, patrol_timer, [{Point, UpNeedTime, UpNeedTime}]}, {time, UpNeedTime * 1000, 10000}),
%%            z_db_lib:update(game_lib:get_table(Src, 'cross_battle_area_patrol_timer'), Point, {time_lib:now_second() + UpNeedTime, UpNeedTime});
        true ->
            ok
    end;
notify(_, Src, 'cancel_build_destroy', Msg) ->%%取消建筑摧毁状态
    MapBuildSid = z_lib:get_value(Msg, 'map_build_sid', 0),
    {_, PatrolSids} = zm_config:get('map_build_info', 'map_build_patrol'),
    Bool = lists:member(MapBuildSid, PatrolSids),
    if
        Bool ->
            Point = z_lib:get_value(Msg, 'point', 0),
            Level = z_lib:get_value(Msg, 'level', 1),
            CorpsUid = z_lib:get_value(Msg, 'corps_uid', 0),
            MapId = z_lib:get_value(Msg, 'map_id', 0),
            MapBuildDetail = map_build_detail:get_cfg(MapBuildSid),
            {_, _, {_, LevelInfo}} = map_build_detail:get_effect(MapBuildDetail),
            {_, _, _, Cd} = lists:keyfind(Level, 1, LevelInfo),
            map_build_db:update_patrol_time(Src, CorpsUid, Point, Cd),
            update_patrol_timer(Src, MapId, time_lib:now_second(), Point, Cd);
        true ->
            ok
    end;
notify(_, Src, 'map_build_destroy', Msg) ->%%建筑在摧毁状态中
    MapBuildSid = z_lib:get_value(Msg, 'map_build_sid', 0),
    {_, PatrolSids} = zm_config:get('map_build_info', 'map_build_patrol'),
    Bool = lists:member(MapBuildSid, PatrolSids),
    if
        Bool ->
            Point = z_lib:get_value(Msg, 'point', 0),
            MapId = z_lib:get_value(Msg, 'map_id', 0),
            del_patorl_timer(Src, MapId, Point);
        true ->
            ok
    end;
notify(_, Src, 'destroy_map_build', Msg) ->%%地图建筑被摧毁
    MapBuildSid = z_lib:get_value(Msg, 'map_build_sid', 0),
    {_, PatrolSids} = zm_config:get('map_build_info', 'map_build_patrol'),
    Bool = lists:member(MapBuildSid, PatrolSids),
    if
        Bool ->
            Point = z_lib:get_value(Msg, 'point', 0),
            MapId = z_lib:get_value(Msg, 'map_id', 0),
            del_patorl_timer(Src, {'patrol_timer', MapId}, Point);
        true ->
            ok
    end;
notify(_, Src, 'cross_battle_role_point', RoleFeats) ->%%玩家积分变化
    case cross_battle_area_db:get_cache_cross_battle_area(Src) of
        'none' ->
            ok;
        CrossBattleArea ->
            Season = cross_battle_area:get_term(CrossBattleArea),
            Wheel = cross_battle_area:get_wheel(CrossBattleArea),
            Fun = fun({RoleUid, Feat}, _) when Feat > 0 ->
                cross_battle_area_lib:role_point(Src, RoleUid, Season, Wheel, Feat);
                (_, R) ->
                    R
            end,
            lists:foldl(Fun, [], RoleFeats)
    end;
notify(_, Src, 'cross_battle_corps_point', CorpsFeats) ->%%公会积分变化
    case cross_battle_area_db:get_cache_cross_battle_area(Src) of
        'none' ->
            ok;
        CrossBattleArea ->
            Season = cross_battle_area:get_term(CrossBattleArea),
            Wheel = cross_battle_area:get_wheel(CrossBattleArea),
            Fun = fun({CorpsUid, Feat}, _) when Feat > 0 ->
                cross_battle_area_lib:corps_point(Src, CorpsUid, Season, Wheel, Feat);
                (_, R) ->
                    R
            end,
            lists:foldl(Fun, [], CorpsFeats)
    end;
notify(_, Src, 'cross_battle_kill_enemy', KillEnemys) ->%%玩家杀敌变化
    case cross_battle_area_db:get_cache_cross_battle_area(Src) of
        'none' ->
            ok;
        CrossBattleArea ->
            Season = cross_battle_area:get_term(CrossBattleArea),
            Wheel = cross_battle_area:get_wheel(CrossBattleArea),
            Fun = fun({RoleUid, KillEnemy}, _) when KillEnemy > 0 ->
                cross_battle_area_lib:kill_enemy(Src, RoleUid, Season, Wheel, KillEnemy);
                (_, R) ->
                    R
            end,
            lists:foldl(Fun, [], KillEnemys)
    end;
notify(_, Src, 'cross_battle_town_point', TownPoints) ->%%玩家杀敌变化
    case cross_battle_area_db:get_cache_cross_battle_area(Src) of
        'none' ->
            ok;
        CrossBattleArea ->
            Season = cross_battle_area:get_term(CrossBattleArea),
            Wheel = cross_battle_area:get_wheel(CrossBattleArea),
            Fun = fun({RoleUid, TownPoint}, _) when TownPoint > 0 ->
                cross_battle_area_lib:town_point(Src, RoleUid, Season, Wheel, TownPoint);
                (_, R) ->
                    R
            end,
            lists:foldl(Fun, [], TownPoints)
    end.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%		结束处理
%% @end
%% ----------------------------------------------------
over_handle(Src, Season, Wheel, MapIds, [{Type, [{M, F, A} | MFAS]} | Types]) ->
    try
        M:F(A, Src, Type, Season, Wheel, MapIds)
    catch
        E : E1 ->
            zm_log:warn(Src, ?MODULE, 'over_handle', "error", [{e, E}, {e1, E1}, {type, Type}, {stacktrace, erlang:get_stacktrace()}])
    end,
    over_handle(Src, Season, Wheel, MapIds, [{Type, MFAS} | Types]);
over_handle(Src, Season, Wheel, MapIds, [{_Type, []} | Types]) ->
    over_handle(Src, Season, Wheel, MapIds, Types);
over_handle(Src, Season, Wheel, MapIds, [{M, F, A} | Types]) ->
    M:F(A, Src, Season, Wheel, MapIds),
    over_handle(Src, Season, Wheel, MapIds, Types);
over_handle(_Src, _Season, _Wheel, _MapIds, []) ->
    ok.
%% ----------------------------------------------------
%% @doc
%%		巡逻营行军
%% @end
%% ----------------------------------------------------
patrol_march(Src, TimerKey, NowTime, {Point, _DoTime, _Cd}) ->
    case point_state_db:get_point_info(Src, Point) of
        {?MAP_BUILD_TOWN, _BSid, Key} ->
            MapBuild = map_build_db:get_map_build(Src, Key),
            case map_build:get_map_build_v(MapBuild, Point) of
                'none' ->
                    del_patorl_timer(Src, TimerKey, Point);
                MapBuildV ->
                    Sid = map_build:get_v_sid(MapBuildV),
                    MPDetail = map_build_detail:get_cfg(Sid),
                    {M, F, A} = map_build_detail:get_effect(MPDetail),
                    NMapBuildV = map_build_lib:calc_map_build_v(MapBuildV, map_build:get_v_bvalue_speed(MapBuildV), NowTime),
                    case M:F(A, Src, NMapBuildV, []) of
                        NewCd when is_integer(NewCd) ->
                            map_build_db:update_patrol_time(Src, Key, Point, NewCd),
                            update_patrol_timer(Src, TimerKey, time_lib:now_second(), Point, NewCd);
                        'delete' ->
                            del_patorl_timer(Src, TimerKey, Point)
                    end
            end;
        _ ->
            ok
    end.
%% ----------------------------------------------------
%% @doc
%%		更新巡逻营信息
%% @end
%% ----------------------------------------------------
update_patrol_timer(Src, Key, Time, Point, Cd) ->
    Fun = fun(_, 'none') ->
        NextTime = Time + Cd,
        zm_dtimer:set({Src, {'patrol_timer', Key}},
            {?MODULE, patrol_timer, [Key]}, {time, 1000, 10000}),
        zm_config:set('patrol_timer', {Key, [{Point, NextTime, Cd}]}),
        {ok, ok, [{Point, NextTime, Cd}]};
        (_, PatrolTimer) ->
            NextTime = Time + Cd,
            NewPatrolTimer = lists:keystore(Point, 1, PatrolTimer, {Point, NextTime, Cd}),
            zm_config:set('patrol_timer', {Key, NewPatrolTimer}),
            {ok, ok, NewPatrolTimer}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'cross_battle_area_patrol_timer'), Key, 'none', Fun, []).
%% ----------------------------------------------------
%% @doc
%%		删除巡逻营信息
%% @end
%% ----------------------------------------------------
del_patorl_timer(Src, Key, Point) ->
    Fun = fun(_, PatrolTimerList) ->
        NewPatrolTimerList = lists:keydelete(Point, 1, PatrolTimerList),
        zm_config:set('patrol_timer', {Key, NewPatrolTimerList}),
        {ok, ok, NewPatrolTimerList}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'cross_battle_area_patrol_timer'), Key, [], Fun, []).