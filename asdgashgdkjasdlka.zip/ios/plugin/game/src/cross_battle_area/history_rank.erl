-module(history_rank).

%%%=======================STATEMENT====================
-description("history_rank").
-copyright('youkia,www.youkia.net').
-author("shusong,shusong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================

-export([init_history_rank/6, format/2, get_value/1, set_value/2, get_uid/1, get_rank_corps_uid/1]).


%%%=======================INCLUDE======================
-include("../include/rank.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================
%%跨服战个人积分排行榜｛uid,玩家名字,玩家形象,军团id,军团名字,职位,服务器名字,所在小组,积分｝
-record(battle_role_point_rank, {role_uid, name, style, corps_uid, corps_name, position, server_name, team, value}).
%%跨服战军团积分排行榜
-record(battle_corps_point_rank, {corps_uid, corps_name, server_name, team, value}).


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%        初始化历史排行榜
%% @end
%% ----------------------------------------------------
init_history_rank(Src, Season, Wheel, Type, Uid, Value) ->
    NewType = rank_lib:get_type(Type),
    if
        NewType =:= ?BATTLE_POINTS_ALL_ROLE_RANK ->
            init_battle_role_point_rank(Src, Season, Wheel, Uid, Value);
        NewType =:= ?BATTLE_POINTS_ALL_CORPS_RANK ->
            init_battle_corps_point_rank(Src, Season, Wheel, Uid, Value)
    end.
%% ----------------------------------------------------
%% @doc
%%        排行榜显示
%% @end
%% ----------------------------------------------------
format(Ranker, Rank) ->
    if
        is_record(Ranker, 'battle_role_point_rank') ->
            #battle_role_point_rank{name = RoleName, value = Value, server_name = ServerName, role_uid = Uid} = Ranker,
            {Rank, RoleName, Value, ServerName, Uid};
        is_record(Ranker, 'battle_corps_point_rank') ->
            #battle_corps_point_rank{corps_name = RoleName, value = Value, server_name = ServerName, corps_uid = Uid} = Ranker,
            {Rank, RoleName, Value, ServerName, Uid}
    end.
%% ----------------------------------------------------
%% @doc
%%        获得值
%% @end
%% ----------------------------------------------------
get_value(Ranker) ->
    if
        is_record(Ranker, 'battle_role_point_rank') ->
            get_role_value(Ranker);
        is_record(Ranker, 'battle_corps_point_rank') ->
            get_corps_value(Ranker)
    end.
%% ----------------------------------------------------
%% @doc
%%        设置值
%% @end
%% ----------------------------------------------------
set_value(Ranker, Value) ->
    if
        is_record(Ranker, 'battle_role_point_rank') ->
            set_role_value(Ranker, Value);
        is_record(Ranker, 'battle_corps_point_rank') ->
            set_corps_value(Ranker, Value)
    end.

%% ----------------------------------------------------
%% @doc
%%        获得uid
%% @end
%% ----------------------------------------------------
get_uid(Ranker) ->
    if
        is_record(Ranker, 'battle_role_point_rank') ->
            get_role_uid(Ranker);
        is_record(Ranker, 'battle_corps_point_rank') ->
            get_corps_uid(Ranker)
    end.
%% ----------------------------------------------------
%% @doc
%%        获得军团uid
%% @end
%% ----------------------------------------------------
get_rank_corps_uid(Ranker) ->
    if
        is_record(Ranker, 'battle_role_point_rank') ->
            get_role_corps_uid(Ranker);
        is_record(Ranker, 'battle_corps_point_rank') ->
            get_corps_uid(Ranker)
    end.

%%%===================LOCAL FUNCTIONS==================
get_corps_uid(#battle_corps_point_rank{corps_uid = V}) -> V.
get_corps_value(#battle_corps_point_rank{value = V}) -> V.
set_corps_value(BattleCorpsPointRank, Value) ->
    BattleCorpsPointRank#battle_corps_point_rank{value = Value}.

get_role_uid(#battle_role_point_rank{role_uid = V}) -> V.
get_role_corps_uid(#battle_role_point_rank{corps_uid = V}) -> V.
get_role_value(#battle_role_point_rank{value = V}) -> V.
set_role_value(BattleRolePointRank, Value) ->
    BattleRolePointRank#battle_role_point_rank{value = Value}.
%% ----------------------------------------------------
%% @doc
%%        初始化个人积分排行榜信息
%% @end
%% ----------------------------------------------------
init_battle_role_point_rank(Src, Season, Wheel, Uid, Value) ->
    BattleRoleInfo = cross_battle_area_db:get_battle_role_info(Src, Uid, Season, Wheel),
    Role = role_db:get_role(Src, Uid),
    RoleCorps = corps_db:get_role_corps(Src, Uid),
    #battle_role_point_rank{role_uid = Uid, name = battle_role_info:get_role_name(BattleRoleInfo), style = role:get_style(Role), corps_uid = battle_role_info:get_corps_uid(BattleRoleInfo),
        corps_name = battle_role_info:get_corps_name(BattleRoleInfo), position = role_corps:get_position(RoleCorps), server_name = battle_role_info:get_server_desc(BattleRoleInfo), team = 1, value = Value}.
%% ----------------------------------------------------
%% @doc
%%        初始化军团积分排行榜信息
%% @end
%% ----------------------------------------------------
init_battle_corps_point_rank(Src, Season, Wheel, Uid, Value) ->
    BattleCorpsInfo = cross_battle_area_db:get_battle_corps_info(Src, Uid, Season, Wheel),
    #battle_corps_point_rank{corps_uid = Uid, corps_name = battle_corps_info:get_corps_name(BattleCorpsInfo), server_name = battle_corps_info:get_server_desc(BattleCorpsInfo),
        team = battle_corps_info:get_team(BattleCorpsInfo), value = Value}.
