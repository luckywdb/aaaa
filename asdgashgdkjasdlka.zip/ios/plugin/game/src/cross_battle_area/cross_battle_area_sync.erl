-module(cross_battle_area_sync).

%%%=======================STATEMENT====================
-description("cross_battle_area_sync").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    sync_group_corps/2,
    sync_all_data/2,
    sync_data/2,
    sync_cross_battle_state/4,

    sync_corps_data/3,
    sync_role_data/3
]).

%%%=======================INCLUDE======================
-include("../include/cross_battle.hrl").
-include("../include/rank.hrl").
-include("../include/point.hrl").
%%%=======================DEFINE======================
-define(MAX_SYNC_NUM, 20).
%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        同步军团分组信息,完成后到准备状态
%% @end
%% ----------------------------------------------------
sync_group_corps(GameSrc, CrossBattleArea) ->
    ActionType = "cb_area",
    CenterSrc = game_lib:get_center_src(),
    [GroupId] = cross_server_db:get_cross_server_groupids(CenterSrc, ActionType),
    Term = cross_battle_area:get_term(CrossBattleArea),
    Wheel = cross_battle_area:get_wheel(CrossBattleArea),
    case Wheel =:= 1 of
        true ->
            WheelTime = cross_battle_area_db:get_cross_battle_area_wtime(GameSrc, Term),
            AreaNum = cross_battle_area:get_id(CrossBattleArea),
            ServerRankNum = cross_battle_area:get_server_rank_num(CrossBattleArea),
            MFA = {'cross_battle_rpc', 'sync_cross_battle_corps_rank', {AreaNum, Term, Wheel, WheelTime, ServerRankNum}},
            {GroupCNameValueList, BadNodes} = cross_server_msg:send_call2(CenterSrc, ActionType, GroupId, MFA),
            CNameValueList =
                lists:reverse(lists:keysort(3, z_lib:foreach(fun(R, {ok, AddCNameValueList}) ->
                    {ok, AddCNameValueList ++ R}
                end, [], GroupCNameValueList))),
            CNameList = [{CUid, CName} || {CUid, CName, _} <- CNameValueList],
            sync_corps_group_complete(GameSrc, CenterSrc, GroupId, ActionType, CNameList, BadNodes =:= []);
        false ->
            RankList = rank_db:get_season_history_rank(GameSrc, 9, Term, Wheel - 1, 0, 1, 0),
            RCorpsUids = [history_rank:get_uid(V) || V <- RankList],
            OCorpsUids = cross_battle_area:get_corps_uids(CrossBattleArea),
            CorpsUids = RCorpsUids ++ (OCorpsUids -- RCorpsUids),
            MFA = {'cross_battle_rpc', 'sync_cross_battle_corps_name', Wheel},
            GroupCNameList = cross_server_msg:send_call(CenterSrc, ActionType, GroupId, MFA),
            CNameList = z_lib:foreach(fun(R, {ok, AddCNameList}) ->
                {ok, AddCNameList ++ R}
            end, [], GroupCNameList),
            OCNameList = cross_battle_area:get_corps_uidnames(CrossBattleArea),
            NCNameList = lists:map(fun(CorpsUid) ->
                case lists:keyfind(CorpsUid, 1, CNameList) of
                    false ->
                        {CorpsUid, element(2, lists:keyfind(CorpsUid, 1, OCNameList))};
                    V ->
                        {CorpsUid, element(2, V)}
                end
            end, CorpsUids),
            sync_corps_group_complete(GameSrc, CenterSrc, GroupId, ActionType, NCNameList, true)
    end.

%% ----------------------------------------------------
%% @doc
%%    同步所有数据
%% @end
%% ----------------------------------------------------
sync_all_data(GameSrc, CrossBattleArea) ->
    %%由于times_set每一轮被清除,所以,被屏蔽的功能需要初始化一次
    times_set_lib:server_start_init(GameSrc),
    Bool =
        z_lib:for(fun(R, _) ->
            case sync_data(GameSrc, CrossBattleArea) of
                true ->
                    {break, true};
                false ->
                    {ok, R}
            end
        end, false, 1, 500),
    case Bool of
        false ->
            SyncList = z_db_lib:get_all_record(game_lib:get_table(GameSrc, 'cross_battle_area_sync'), 10),
            zm_log:warn(GameSrc, sync_all_data, ?MODULE, "sync_all_data error", [{'cba', CrossBattleArea}, {'syncs', SyncList}]),
            ok;
        true ->
            ok
    end,
    Bool.

%% ----------------------------------------------------
%% @doc
%%    同步数据
%% @end
%% ----------------------------------------------------
sync_data(GameSrc, CrossBattleArea) ->
    SyncTable = game_lib:get_table(GameSrc, 'cross_battle_area_sync'),
    Fun = fun(_, {'map', MapId} = Key, _, R) ->
        case init_map_data(GameSrc, MapId) of
            true ->
                z_db_lib:delete(SyncTable, Key),
                {'break', ?MAX_SYNC_NUM};
            false ->
                inc_del_area_sync_times(GameSrc, Key, 10),
                NR = R + 1,
                case NR >= ?MAX_SYNC_NUM of
                    true ->
                        {'break', NR};
                    false ->
                        {ok, NR}
                end
        end;
        (_, {'corps', CorpsUid} = Key, _, R) ->
            case sync_corps_data(GameSrc, CrossBattleArea, CorpsUid) of
                true ->
                    z_db_lib:delete(SyncTable, Key);
                false ->
                    inc_del_area_sync_times(GameSrc, Key, 10)
            end,
            NR = R + 1,
            case NR >= ?MAX_SYNC_NUM of
                true ->
                    {'break', NR};
                false ->
                    {ok, NR}
            end;
        (_, RoleUid, _, R) when is_integer(RoleUid) ->
            case sync_role_data(GameSrc, RoleUid, CrossBattleArea) of
                true ->
                    z_db_lib:delete(SyncTable, RoleUid);
                false ->
                    inc_del_area_sync_times(GameSrc, RoleUid, 10)
            end,
            NR = R + 1,
            case NR >= ?MAX_SYNC_NUM of
                true ->
                    {'break', NR};
                false ->
                    {ok, NR}
            end;
        (_, _, _, R) ->
            {ok, R}
    end,
    z_db_lib:table_iterate(GameSrc, SyncTable, Fun, [], 0),
    z_db_lib:get_count(SyncTable) =:= 0.

%% ----------------------------------------------------
%% @doc
%%    初始化地图数据
%% @end
%% ----------------------------------------------------
init_map_data(GameSrc, MapId) ->
    CMTable = game_lib:get_table(GameSrc, 'cross_battle_corps_map'),
    CorpsUids = z_db_lib:get(CMTable, MapId),
    SyncTable = game_lib:get_table(GameSrc, 'cross_battle_area_sync'),
    lists:foreach(fun(CorpsUid) ->
        z_db_lib:update(SyncTable, {'corps', CorpsUid}, 0),
        {_, N} = z_db_lib:get(CMTable, CorpsUid),
        %每个军团增加出生点视野
        point_horizon:add_born_horizon(GameSrc, CorpsUid, MapId, N)
    end, CorpsUids),
    %%初始化野怪
    spawn(fun() -> monster_db:init_monster(GameSrc, MapId, point_lib:mapid2type(MapId)) end),
    true.


%% ----------------------------------------------------
%% @doc
%%    同步军团数据
%% @end
%% ----------------------------------------------------
sync_corps_data(GameSrc, CrossBattleArea, CorpsUid) ->
    ActionType = "cb_area",
    CorpsTable = game_lib:get_table(GameSrc, 'corps'),
    CorpsMemberTable = game_lib:get_table(GameSrc, 'corps_member'),
    SyncTable = game_lib:get_table(GameSrc, 'cross_battle_area_sync'),
    CMTable = game_lib:get_table(GameSrc, 'cross_battle_corps_map'),
    CenterSrc = game_lib:get_center_src(),
    case cross_server_msg:send_call(CenterSrc, ActionType, CorpsUid, {'cross_battle_rpc', 'get_corps_cross_battle', CorpsUid}) of
        Tuple when is_tuple(Tuple) ->
            {Corps, CorpsMember, OwnerRoleName} = Tuple,
            SName = deal_sname(server_address_db:get_sdesc(CenterSrc, CorpsUid)),
            NCorps = corps:set_name(Corps, corps:get_name(Corps) ++ "(" ++ SName ++ ")"),

            z_db_lib:update(CorpsTable, CorpsUid, NCorps),
            z_db_lib:update(CorpsMemberTable, CorpsUid, CorpsMember),
            lists:foreach(fun(RoleUid) ->
                z_db_lib:update(SyncTable, RoleUid, 0)
            end, CorpsMember),
            %%排行榜初始化
            {MapId, _} = z_db_lib:get(CMTable, CorpsUid),
            Term = cross_battle_area:get_term(CrossBattleArea),
            Wheel = cross_battle_area:get_wheel(CrossBattleArea),
            cross_battle_area_rank:init_rank(GameSrc, NCorps, OwnerRoleName, MapId, Term, Wheel),
            true;
        Err when is_list(Err) ->
            false
    end.

%% ----------------------------------------------------
%% @doc
%%      同步玩家数据
%% @end
%% ----------------------------------------------------
sync_role_data(GameSrc, RoleUid, CrossBattleArea) ->
    ActionType = "cb_area",
    Pid = args_system:get_pid(GameSrc),
    Sid = args_system:get_sid(GameSrc),
    RoleTable = game_lib:get_table(GameSrc, 'role'),
    UserTable = game_lib:get_table(GameSrc, 'user'),
    CastleTable = game_lib:get_table(GameSrc, 'castle'),
    StudyTable = game_lib:get_table(GameSrc, 'study'),
    RoleCorpsTable = game_lib:get_table(GameSrc, 'role_corps'),
    RoleShowTable = game_lib:get_table(GameSrc, 'role_show'),
    PsuUidTable = game_lib:get_table(GameSrc, 'psu_uid'),
    UidPsuTable = game_lib:get_table(GameSrc, 'uid_psu'),
    GarrayTable = game_lib:get_table(GameSrc, 'garray'),
    CardTable = game_lib:get_table(GameSrc, 'card'),
    EquipTable = game_lib:get_table(GameSrc, 'equipment'),
    TreasTable = game_lib:get_table(GameSrc, 'treasure'),
    CardPutPropTable = game_lib:get_table(GameSrc, 'card_put_prop'),
    CardFetterTable = game_lib:get_table(GameSrc, 'card_fetter'),
    RoleRestoreTable = game_lib:get_table(GameSrc, 'role_restore'),
    CMTable = game_lib:get_table(GameSrc, 'cross_battle_corps_map'),
    BarracksTable = game_lib:get_table(GameSrc, 'barracks'),
    PutTreasureTable = game_lib:get_table(GameSrc, 'card_put_treasure'),

    CenterSrc = game_lib:get_center_src(),
    case cross_server_msg:send_call(CenterSrc, ActionType, RoleUid, {'cross_battle_rpc', 'get_role_cross_battle', RoleUid}) of
        Tuple when is_tuple(Tuple) ->
            {Role, Castle, Study, User, RoleCorps, NGarrays, CardStorage, EquipStorage, TreasureStorage, CardPutProps, CardFetter, PutTreasureSids, ServerName} = Tuple,
            z_db_lib:update(UserTable, RoleUid, User),
            SName = deal_sname(server_address_db:get_sdesc(CenterSrc, RoleUid)),
            RoleName = role:get_name(Role) ++ "(" ++ SName ++ ")",
            NRoleTmp = role:set_name(Role, RoleName),
            {_, {ResA, ResB, ResC, ResD}} = zm_config:get('cross_battle_info', 'init_role'),
            NRole = role:init_cross(NRoleTmp, {ResA, ResB, ResC, ResD}),
            z_db_lib:update(RoleTable, RoleUid, NRole),
            z_db_lib:update(StudyTable, RoleUid, Study),
            z_db_lib:update(RoleCorpsTable, RoleUid, RoleCorps),
            lists:foreach(fun({GId, Garray}) ->
                z_db_lib:update(GarrayTable, {RoleUid, GId}, Garray)
            end, NGarrays),
            z_db_lib:update(CardTable, RoleUid, CardStorage),
            z_db_lib:update(EquipTable, RoleUid, EquipStorage),
            z_db_lib:update(TreasTable, RoleUid, TreasureStorage),
            lists:foreach(fun({CardUid, CardPutProp}) ->
                z_db_lib:update(CardPutPropTable, CardUid, CardPutProp)
            end, CardPutProps),
            z_db_lib:update(CardFetterTable, RoleUid, CardFetter),
            z_db_lib:update(PutTreasureTable, RoleUid, PutTreasureSids),
            UserId = integer_to_list(RoleUid),
            z_db_lib:update(PsuUidTable, {Pid, Sid, UserId}, RoleUid),
            z_db_lib:update(UidPsuTable, RoleUid, {Pid, Sid, UserId}),
            z_db_lib:update(BarracksTable, RoleUid, barracks:init_cross()),

            Corps = corps_db:get_corps(GameSrc, role_corps:get_corps_uid(RoleCorps)),
            Term = cross_battle_area:get_term(CrossBattleArea),
            Wheel = cross_battle_area:get_wheel(CrossBattleArea),
            AreaNum = cross_battle_area:get_id(CrossBattleArea),
            CorpsUid = role_corps:get_corps_uid(RoleCorps),
            {MapId, N} = z_db_lib:get(CMTable, CorpsUid, 'none'),
            HisPoint = cross_battle_area_lib:get_his_rank_value(GameSrc, RoleUid, ?BATTLE_POINTS_ALL_ROLE_RANK),
            HisKillEnemy = cross_battle_area_lib:get_his_rank_value(GameSrc, RoleUid, ?BATTLE_FEATS_ALL_ROLE_RANK),
            HisTownPoint = cross_battle_area_lib:get_his_rank_value(GameSrc, RoleUid, ?BATTLE_TOWN_ALL_ROLE_RANK),
            BattleRoleInfo = battle_role_info:init(NRole, Corps, Term, Wheel, MapId, ServerName, AreaNum, HisPoint, HisKillEnemy, HisTownPoint),
            ServerDesc = server_address_db:get_sname(CenterSrc, RoleUid),
            cross_battle_area_db:update_battle_role_info(GameSrc, RoleUid, Term, Wheel, battle_role_info:set_server_desc(BattleRoleInfo, ServerDesc)),
            %%随机坐标
            NPointBorns = point_born:cross_get_born(GameSrc, MapId, N),
            TableName = game_lib:get_table(GameSrc),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'point_state', Np, 'none'} || Np <- tuple_to_list(NPointBorns)]),
            Fun = fun(_, T) ->
                ReplyBornList = [{I, {?ROLE, RoleUid}} || {I, V} <- T, V =:= 'none'],
                if
                    length(ReplyBornList) =:= length(T) ->
                        'ok';
                    true ->
                        throw("born_point_error") %取出的坐标点已经被使用了
                end,
                {ok, ok, ReplyBornList}
            end,
            ok = z_db_lib:handle(TableName, Fun, {}, TableKeys),
            NCastle = castle:set_points(Castle, NPointBorns),
            point_horizon:add_role_horizon(GameSrc, CorpsUid, NPointBorns, 0),%视野
            z_db_lib:update(CastleTable, RoleUid, NCastle),
            {_, _ChatSkinSid, CastleSkinSid} = zm_config:get('skin_info', 'default_skin'),
            RoleShow = role_show:init(NRole, NCastle, Corps, 0, CastleSkinSid),
            z_db_lib:update(RoleShowTable, RoleUid, RoleShow),
            skin_db:init_chat_skin(GameSrc, RoleUid),
            z_db_lib:update(RoleRestoreTable, RoleUid, restore_db:init(GameSrc, NRole)),
            point_search_db:init_role2search(GameSrc, RoleShow),
            map_spy_db:init_spy_soldiers_num(GameSrc, RoleUid),
            true;
        Err when is_list(Err) ->
            false
    end.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%      同步分组完成,到准备状态
%% @end
%% ----------------------------------------------------
sync_corps_group_complete(GameSrc, CenterSrc, GroupId, ActionType, CNameList, IsSyncGroupComplete) ->
    %%6个军团一个地图
    MapCNamesList = corps_group(CNameList),
    CMTable = game_lib:get_table(GameSrc, 'cross_battle_corps_map'),
    SyncTable = game_lib:get_table(GameSrc, 'cross_battle_area_sync'),
    {MapIds, MapCNameServersList} = z_lib:foreach(fun({Acc1, Acc2}, {MapId, CUidNames}) ->
        CUids = [CUid || {CUid, _} <- CUidNames],
        z_db_lib:update(CMTable, MapId, CUids),
        z_db_lib:update(SyncTable, {'map', MapId}, 0),
        CSNames = element(2, z_lib:foreach(fun({N, Acc}, {CUid, CName}) ->
            z_db_lib:update(CMTable, CUid, {MapId, N}),
            NAcc = [{CUid, CName, server_address_db:get_sname(CenterSrc, CUid)} | Acc],
            {ok, {N + 1, NAcc}}
        end, {1, []}, CUidNames)),
        {ok, {[MapId | Acc1], [{MapId, CSNames} | Acc2]}}
    end, {[], []}, MapCNamesList),
    CenterSrc = game_lib:get_center_src(),

    CrossBattleArea = cross_battle_area_db:get_cross_battle_area(GameSrc, ActionType),
    Wheel = cross_battle_area:get_wheel(CrossBattleArea),
    WheelStateTime = cross_battle_area:get_wheel_state_time(CrossBattleArea),
    ContinueTime = element(?CROSS_SERVER_STATE_PREPARE, element(Wheel, WheelStateTime)),
    StartTime = cross_battle_area:get_start_time(CrossBattleArea),
    NCrossBattleArea1 = cross_battle_area:update_state(CrossBattleArea, ?CROSS_SERVER_STATE_PREPARE, StartTime, ContinueTime),
    NCrossBattleArea2 =
        case IsSyncGroupComplete of
            false ->
                cross_battle_area:set_sync_group_state(NCrossBattleArea1, time_lib:now_second());
            true ->
                cross_battle_area:set_sync_group_state(NCrossBattleArea1, 0)
        end,
    NCrossBattleArea = cross_battle_area:set_corps_uidnames(cross_battle_area:set_mapids(NCrossBattleArea2, MapIds), CNameList),
    cross_battle_area_db:update_cross_battle_area(GameSrc, ActionType, NCrossBattleArea),

    cross_server_msg:send_call(CenterSrc, ActionType, GroupId, {'cross_battle_rpc', 'area_cross_battle_sync_mcorps', MapCNameServersList}),
    zm_event:notify(GameSrc, 'cross_battle_area_state_change', [{'state', ?CROSS_SERVER_STATE_SYNC_GROUP},
        {'nstate', ?CROSS_SERVER_STATE_PREPARE}, {'cross_battle_area', NCrossBattleArea}]).


%% ----------------------------------------------------
%% @doc
%%    同步状态
%% @end
%% ----------------------------------------------------
sync_cross_battle_state(GameSrc, State, NState, CrossBattleArea) ->
    Term = cross_battle_area:get_term(CrossBattleArea),
    Wheel = cross_battle_area:get_wheel(CrossBattleArea),
    StartTime = cross_battle_area:get_start_time(CrossBattleArea),
    ContinueTime = cross_battle_area:get_continue_time(CrossBattleArea),
    {Ip, Port} = args_expend:get_login_address(GameSrc),
    CBServerName = args_system:get_server_name(GameSrc),
    A = {Ip, Port, CBServerName, State, NState, Term, Wheel, StartTime, ContinueTime},
    CenterSrc = game_lib:get_center_src(),
    ActionType = "cb_area",
    [GroupId] = cross_server_db:get_cross_server_groupids(CenterSrc, ActionType),
    cross_server_msg:send_call(CenterSrc, ActionType, GroupId, {'cross_battle_rpc', 'area_cross_battle_update', A}).

%% ----------------------------------------------------
%% @doc
%%          分组
%% @end
%% ----------------------------------------------------
corps_group(CorpsUids) ->
    Len = length(CorpsUids),
    Num = Len div 6,
    Tup = list_to_tuple([Len - 5 * Num | lists:duplicate(5, Num)]),
    {PoolList, []} =
        z_lib:tuple_foreach(Tup, fun({GAcc, TailCAcc}, _I, N) ->
            {CList, NTailCAcc} = lists:split(N, TailCAcc),
            {ok, {[CList | GAcc], NTailCAcc}}
        end, {[], CorpsUids}),
    lists:reverse(z_lib:while(fun({MId, GAcc, PoolAcc}) ->
        case lists:any(fun(Pool) -> Pool =:= [] end, PoolAcc) of
            true ->
                AddGList = lists:append(PoolAcc),
                case AddGList =/= [] of
                    true ->
                        {'break', [{MId, AddGList} | GAcc]};
                    false ->
                        {'break', GAcc}
                end;
            false ->
                {AccGList, NPoolAcc} = z_lib:foreach(fun({GAcc1, PoolAcc1}, Pool) ->
                    [C] = game_lib:random_list(Pool, 1),
                    {ok, {[C | GAcc1], [lists:delete(C, Pool) | PoolAcc1]}}
                end, {[], []}, PoolAcc),
                {ok, {MId + 1, [{MId, AccGList} | GAcc], NPoolAcc}}
        end
    %%10001地图开始
    end, {10001, [], PoolList})).


%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
inc_del_area_sync_times(GameSrc, Key, MaxTimes) ->
    z_db_lib:update(game_lib:get_table(GameSrc, 'cross_battle_area_sync'), Key, 0, fun(_, Times) ->
        NTimes = Times + 1,
        case NTimes > MaxTimes of
            true ->
                {ok, ok, 'delete'};
            false ->
                {ok, ok, NTimes}
        end
    end, []).


%% ----------------------------------------------------
%% @doc
%%     处理服务器名字
%% @end
%% ----------------------------------------------------
deal_sname(Name) ->
    case string:tokens(Name, "-") of
        [_, Num | _] ->
            lists:concat(["S", Num]);
        _ ->
            Name
    end.