-module(battle_role_info).

%%%=======================STATEMENT====================
-description("跨服战个人信息").
-copyright('youkia,www.youkia.net').
-author("shusong,shusong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([init/10]).
-export([get_points/1, get_role_uid/1, get_corps_name/1, get_corps_uid/1, get_season/1, get_team/1, get_wheel/1, get_server_name/1, get_area_num/1,
    get_role_name/1, get_kill_enemy/1, get_town_points/1, get_server_desc/1, get_his_points/1, get_his_kill_enemy/1, get_his_town_point/1]).
-export([set_points/2, set_kill_enemy/2, set_town_points/2, set_server_desc/2, set_info/2]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
%%{玩家uid,赛区,赛季,轮次,所在小组,服务器名字,玩家名字d,公会uid,公会名字,服务器显示名称,积分,历史积分,击杀值,历史击杀值,攻城值,历史攻城值,额外数据}
-record(battle_role_info, {role_uid, area_num, season, wheel, team, server_name, role_name, corps_uid = 0, corps_name = "", server_desc = "", points = 0, his_points = 0, kill_enemy = 0, his_kill_enemy = 0, town_point = 0, his_town_point = 0, info = []}).

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%        初始化
%% @end
%% ----------------------------------------------------
init(Role, Corps, Season, Wheel, Team, ServerName, AreaNum, HisPoint, HisKillEnemy, HisTownPoint) ->
    #battle_role_info{role_uid = role:get_uid(Role), role_name = role:get_name(Role), corps_uid = corps:get_uid(Corps), corps_name = corps:get_name(Corps), season = Season,
        wheel = Wheel, team = Team, server_name = ServerName, area_num = AreaNum, his_points = HisPoint, his_kill_enemy = HisKillEnemy, his_town_point = HisTownPoint}.
%% ----------------------------------------------------
%% @doc
%%        获得玩家uid
%% @end
%% ----------------------------------------------------
get_role_uid(#battle_role_info{role_uid = Uid}) ->
    Uid.
%% ----------------------------------------------------
%% @doc
%%        获得玩家名字
%% @end
%% ----------------------------------------------------
get_role_name(#battle_role_info{role_name = RoleName}) ->
    RoleName.
%% ----------------------------------------------------
%% @doc
%%        获得积分
%% @end
%% ----------------------------------------------------
get_points(#battle_role_info{points = Points}) ->
    Points.
%% ----------------------------------------------------
%% @doc
%%        设置积分
%% @end
%% ----------------------------------------------------
set_points(BattleRoleInfo, Points) ->
    BattleRoleInfo#battle_role_info{points = Points}.
%% ----------------------------------------------------
%% @doc
%%        获得军团uid
%% @end
%% ----------------------------------------------------
get_corps_uid(#battle_role_info{corps_uid = CorpsUid}) ->
    CorpsUid.
%% ----------------------------------------------------
%% @doc
%%        获得军团名字
%% @end
%% ----------------------------------------------------
get_corps_name(#battle_role_info{corps_name = CorpsName}) ->
    CorpsName.
%% ----------------------------------------------------
%% @doc
%%        获得赛季
%% @end
%% ----------------------------------------------------
get_season(#battle_role_info{season = Season}) ->
    Season.
%% ----------------------------------------------------
%% @doc
%%        获得轮次
%% @end
%% ----------------------------------------------------
get_wheel(#battle_role_info{wheel = Wheel}) ->
    Wheel.
%% ----------------------------------------------------
%% @doc
%%        获得轮次
%% @end
%% ----------------------------------------------------
get_server_name(#battle_role_info{server_name = ServerName}) ->
    ServerName.
%% ----------------------------------------------------
%% @doc
%%        获得轮次
%% @end
%% ----------------------------------------------------
get_area_num(#battle_role_info{area_num = AreaNum}) ->
    AreaNum.
%% ----------------------------------------------------
%% @doc
%%        获得分组
%% @end
%% ----------------------------------------------------
get_team(#battle_role_info{team = Team}) ->
    Team.
%% ----------------------------------------------------
%% @doc
%%        获得杀敌积分
%% @end
%% ----------------------------------------------------
get_kill_enemy(#battle_role_info{kill_enemy = Value}) ->
    Value.
%% ----------------------------------------------------
%% @doc
%%        设置杀敌积分
%% @end
%% ----------------------------------------------------
set_kill_enemy(BattleRoleInfo, Value) ->
    BattleRoleInfo#battle_role_info{kill_enemy = Value}.
%% ----------------------------------------------------
%% @doc
%%        获得攻城积分
%% @end
%% ----------------------------------------------------
get_town_points(#battle_role_info{town_point = Points}) ->
    Points.
%% ----------------------------------------------------
%% @doc
%%        设置攻城积分
%% @end
%% ----------------------------------------------------
set_town_points(BattleRoleInfo, Points) ->
    BattleRoleInfo#battle_role_info{town_point = Points}.
%% ----------------------------------------------------
%% @doc
%%        获得服务器描述
%% @end
%% ----------------------------------------------------
get_server_desc(#battle_role_info{server_desc = Value}) ->
    Value.
%% ----------------------------------------------------
%% @doc
%%        设置服务器描述
%% @end
%% ----------------------------------------------------
set_server_desc(BattleRoleInfo, Value) ->
    BattleRoleInfo#battle_role_info{server_desc = Value}.
%% ----------------------------------------------------
%% @doc
%%        设置额外信息
%% @end
%% ----------------------------------------------------
set_info(BattleRoleInfo, Value) ->
    BattleRoleInfo#battle_role_info{info = Value}.
%% ----------------------------------------------------
%% @doc
%%        获得历史积分
%% @end
%% ----------------------------------------------------
get_his_points(#battle_role_info{his_points = Value}) ->
    Value.
%% ----------------------------------------------------
%% @doc
%%        获得历史击杀
%% @end
%% ----------------------------------------------------
get_his_kill_enemy(#battle_role_info{his_kill_enemy = Value}) ->
    Value.
%% ----------------------------------------------------
%% @doc
%%        获得历史攻城
%% @end
%% ----------------------------------------------------
get_his_town_point(#battle_role_info{his_town_point = Value}) ->
    Value.
%%%===================LOCAL FUNCTIONS==================

