%%袁绍据点
-module(map_ys_point).

%%%=======================STATEMENT====================
-description("map_ys_point").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([init/4]).
-export([get_sid/1, get_point_uid/1, get_level/1, get_bvalue/1, get_bvalue_retime/1, get_wheel/1,
    get_defense_wave_number/1, get_last_hp_state/1, get_attack_wave_number/1, get_last_attack_stime/1,
    get_create_refresh_time/1, get_wheel_etime/1, get_point_uid_index/0]).
-export([update_bvalue/3]).
-export([set_point_uid/2, set_wheel/2, set_defense_wave_number/2, set_last_hp_state/2, set_attack_wave_number/2,
    set_last_attack_stime/2, set_create_refresh_time/2,
    set_wheel_etime/2]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(map_ys_point, {
    sid = 0 :: integer(),%%粮仓sid
    point_uid :: integer(),%%点
    level = 0 :: integer(),%%等级
    bvalue = 0 :: integer(),%%当前建筑值
    bvalue_retime = 0 :: integer(),%%建筑值恢复开始时间
    wheel = 0 :: integer(),%%当前轮数
    wheel_etime = 0 :: integer(),%%轮结束时间
    attack_wave_number = 0 :: integer(),%%攻击剩余
    last_attack_stime = 0 :: integer(),%%最近一次出征的开始时间
    defense_wave_number = 0 :: integer(),%%防守剩余波数
    last_hp_state = {} :: tuple(),%%防守npc血量
    create_refresh_time = 0 :: integer()%%下一个创建刷新时间
}).
%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        
%% @end
%% ----------------------------------------------------
init(Sid, PointUid, StartTime, Level) ->
    Detail = map_ys_point_detail:get_cfg(Level),
    MaxDefenseNum = map_ys_point_detail:get_max_defense_num(Detail),
    AttackWaveNum = map_ys_point_detail:get_attack_wave_num(Detail),
    BValue = map_ys_point_detail:get_max_bvalue(Detail),
    CreateRefreshInterval = map_ys_point_detail:get_create_refresh_inteval(Detail),
    #map_ys_point{sid = Sid, level = Level, wheel = 1, point_uid = PointUid,
        defense_wave_number = MaxDefenseNum, attack_wave_number = AttackWaveNum,
        last_attack_stime = StartTime,
        bvalue = BValue, create_refresh_time = StartTime + CreateRefreshInterval
    }.

get_sid(#map_ys_point{sid = V}) -> V.
get_point_uid(#map_ys_point{point_uid = V}) -> V.
get_point_uid_index() -> #map_ys_point.point_uid.
get_level(#map_ys_point{level = V}) -> V.
get_bvalue(#map_ys_point{bvalue = V}) -> V.
get_bvalue_retime(#map_ys_point{bvalue_retime = V}) -> V.
get_wheel(#map_ys_point{wheel = V}) -> V.
get_wheel_etime(#map_ys_point{wheel_etime = V}) -> V.
get_defense_wave_number(#map_ys_point{defense_wave_number = V}) -> V.
get_last_hp_state(#map_ys_point{last_hp_state = V}) -> V.

get_attack_wave_number(#map_ys_point{attack_wave_number = V}) -> V.
get_last_attack_stime(#map_ys_point{last_attack_stime = V}) -> V.
get_create_refresh_time(#map_ys_point{create_refresh_time = V}) -> V.

set_point_uid(MapYsPoint, PointUid) -> MapYsPoint#map_ys_point{point_uid = PointUid}.
set_wheel(MapYsPoint, Wheel) -> MapYsPoint#map_ys_point{wheel = Wheel}.
set_wheel_etime(MapYsPoint, WheelETime) -> MapYsPoint#map_ys_point{wheel_etime = WheelETime}.
set_defense_wave_number(MapYsPoint, DefenseWaveNumber) -> MapYsPoint#map_ys_point{defense_wave_number = DefenseWaveNumber}.
set_attack_wave_number(MapYsPoint, AttackWaveNum) -> MapYsPoint#map_ys_point{attack_wave_number = AttackWaveNum}.
set_last_attack_stime(MapYsPoint, LastAttackSTime) -> MapYsPoint#map_ys_point{last_attack_stime = LastAttackSTime}.
set_last_hp_state(MapYsPoint, LastHpState) -> MapYsPoint#map_ys_point{last_hp_state = LastHpState}.
set_create_refresh_time(MapYsPoint, DeadTime) -> MapYsPoint#map_ys_point{create_refresh_time = DeadTime}.


%% ----------------------------------------------------
%% @doc
%%      更新bvalue
%% @end
%% ----------------------------------------------------
update_bvalue(MapYsPoint, BValue, Time) ->
    MapYsPoint#map_ys_point{bvalue = BValue, bvalue_retime = Time}.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
