-module(cross_battle_area_role).

%%%=======================STATEMENT====================
-description("cross_battle_area_role").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    init_repay_transfer_res_timer/2,
    repay_transfer_res/3
]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================
-define(REPAY_CORPS_NUM, 5).
-define(RETRY_REPLAY_MAX_NUM, 10).
%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      初始化资源返还timer数据
%% @end
%% ----------------------------------------------------
init_repay_transfer_res_timer(GameSrc, CrossBattleArea) ->
    RepayTable = game_lib:get_table(GameSrc, 'cross_battle_area_repay'),
    CorpsUids = cross_battle_area:get_corps_uids(CrossBattleArea),
    lists:foreach(fun(CorpsUid) ->
        z_db_lib:update(RepayTable, CorpsUid, 0)
    end, CorpsUids).
%% ----------------------------------------------------
%% @doc  
%%        返还划拨的
%% @end
%% ----------------------------------------------------
repay_transfer_res(GameSrc, CrossBattleArea, Flag) ->
    RepayTable = game_lib:get_table(GameSrc, 'cross_battle_area_repay'),
    Season = cross_battle_area:get_term(CrossBattleArea),
    Wheel = cross_battle_area:get_wheel(CrossBattleArea),
    case z_db_lib:get_count(RepayTable) > 0 of
        true ->
            CenterSrc = game_lib:get_center_src(),
            RankerFun = fun({RankType, Len}, {MapId, R}) ->
                {_, Actions} = rank_db:get_actions(GameSrc, RankType),
                Keys = element(2, lists:keyfind(level, 1, Actions)),
                NewRankType = rank_lib:get_type(RankType),
                Rankers = if
                    NewRankType =:= RankType ->
                        rank_get:get_size_season_rankers(RankType, 0, GameSrc, 1, Len, Keys);
                    true ->
                        rank_get:get_size_season_rankers(RankType, MapId, GameSrc, 1, Len, Keys)
                end,
                {MapId, [{RankType, Rankers} | R]}
            end,
            {_, {RoleRankTypes, CorpsRankTypes}} = zm_config:get('cross_battle_area_rank_info', 'rank_types'),
            {_, PropSids} = zm_config:get('cross_battle_info', 'transfer_goods_sids'),
            Fun = fun(_, CorpsUid, _, R) ->
                RoleUids = corps_db:get_corps_members(GameSrc, CorpsUid),
                RoleAwardList =
                    z_lib:foreach(fun(Acc, RoleUid) ->
                        Rmb = rmb_db:get_rmb(GameSrc, RoleUid),
                        Goods = storage_db:get_storage('goods', GameSrc, RoleUid),
                        AwardList1 = z_lib:foreach(fun(AwardAcc, PropSid) ->
                            Count = storage_lib:get_count(Goods, PropSid),
                            case Count > 0 of
                                true ->
                                    {ok, [{'prop', {PropSid, Count}} | AwardAcc]};
                                false ->
                                    {ok, AwardAcc}
                            end
                        end, [], PropSids),
                        V = rmb_lib:get_rmb(Rmb),
                        AwardList = case V > 0 of
                            true ->
                                [{'rmb', V} | AwardList1];
                            false ->
                                AwardList1
                        end,
                        {ok, [{RoleUid, AwardList} | Acc]}
                    end, [], RoleUids),
                BattleCorpsInfo = cross_battle_area_db:get_battle_corps_info(GameSrc, CorpsUid, Season, Wheel),
                MapId = battle_corps_info:get_team(BattleCorpsInfo),
                {_, RoleTypeRankers} = lists:foldl(RankerFun, {MapId, []}, RoleRankTypes),
                {_, CorpsTypeRankers} = lists:foldl(RankerFun, {MapId, []}, CorpsRankTypes),
                {RoleRankList, _} = z_lib:foreach(fun({Acc, TypeRankers_}, RoleUid) ->
                    {[{RoleUid, cross_battle_area_lib:get_rank(RoleUid, RoleRankTypes, TypeRankers_)} | Acc], TypeRankers_}
                end, {[], RoleTypeRankers}, RoleUids),
                CorpsRankList = cross_battle_area_lib:get_rank(CorpsUid, CorpsRankTypes, CorpsTypeRankers),
                MFA = {'cross_battle_role_rpc', 'repay_transfer_res', {CorpsUid, RoleAwardList, RoleRankList, CorpsRankList}},
                case cross_server_msg:send_call(CenterSrc, "cb_area", CorpsUid, MFA) of
                    'ok' ->
                        z_db_lib:delete(RepayTable, CorpsUid);
                    _Err ->
                        z_db_lib:update(RepayTable, CorpsUid, 0, fun(_, Times) ->
                            NTimes = Times + 1,
                            case NTimes >= ?RETRY_REPLAY_MAX_NUM of
                                true ->
                                    {ok, ok, 'delete'};
                                false ->
                                    {ok, ok, NTimes}
                            end
                        end, [])
                end,
                NR = R + 1,
                case not Flag andalso NR >= ?REPAY_CORPS_NUM of
                    true ->
                        {'break', NR};
                    false ->
                        {'ok', NR}
                end
            end,
            z_db_lib:table_iterate(GameSrc, RepayTable, Fun, [], 0);
        false ->
            ok
    end.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
