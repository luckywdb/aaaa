-module(battle_corps_info).

%%%=======================STATEMENT====================
-description("跨服战军团信息").
-copyright('youkia,www.youkia.net').
-author("shusong,shusong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([init/6]).
-export([get_points/1, get_corps_uid/1, get_corps_name/1, get_wheel/1, get_team/1, get_season/1, get_town_list/1, get_barn/1, get_owner_name/1,
    get_server_name/1, get_kill_enemy/1, get_town_points/1, get_server_desc/1, get_his_kill_enemy/1, get_his_points/1, get_his_town_point/1, update_his/4]).
-export([set_points/2, set_town_points/2, set_kill_enemy/2, update/2, set_server_desc/2, set_barn/2, set_town_list/2]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
%% {军团uid，服务器名，军团名，军团长，赛季，当前轮次，当前小组，当赛季积分，历史积分，当赛季杀敌，历史杀敌，当赛季攻城，历史攻城，占领城池列表，占领粮仓列表，额外数据}
-record(battle_corps_info, {corps_uid = 0, server_name = "", corps_name = "", owner_name = "", season, wheel, team, points = 0, his_points = 0, kill_enemy = 0, his_kill_enemy = 0, server_desc = "", town_point = 0, his_town_point = 0, town_list = [], barn = [], info = []}).
%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%       初始化
%% @end
%% ----------------------------------------------------
init(Corps, Season, Wheel, Team, ServerName, OwnerName) ->
    #battle_corps_info{corps_uid = corps:get_name(Corps), server_name = ServerName, corps_name = corps:get_name(Corps), season = Season, wheel = Wheel, team = Team, owner_name = OwnerName}.
%% ----------------------------------------------------
%% @doc
%%       初始化
%% @end
%% ----------------------------------------------------
update(BattleCorpsInfo, CorpsTown) ->
    BattleCorpsInfo#battle_corps_info{town_list = corps_town:get_cflist_townsid(CorpsTown), barn = corps_town:get_barns_sid(CorpsTown)}.
%% ----------------------------------------------------
%% @doc
%%       获得军团uid
%% @end
%% ----------------------------------------------------
get_corps_uid(#battle_corps_info{corps_uid = Uid}) ->
    Uid.
%% ----------------------------------------------------
%% @doc
%%       获得积分
%% @end
%% ----------------------------------------------------
get_points(#battle_corps_info{points = Points}) ->
    Points.
%% ----------------------------------------------------
%% @doc
%%       设置积分
%% @end
%% ----------------------------------------------------
set_points(BattleRoleInfo, Points) ->
    BattleRoleInfo#battle_corps_info{points = Points}.
%% ----------------------------------------------------
%% @doc
%%      获得军团名字
%% @end
%% ----------------------------------------------------
get_corps_name(#battle_corps_info{corps_name = CorpsName}) ->
    CorpsName.
%% ----------------------------------------------------
%% @doc
%%        获得赛季
%% @end
%% ----------------------------------------------------
get_season(#battle_corps_info{season = Season}) ->
    Season.
%% ----------------------------------------------------
%% @doc
%%        获得轮次
%% @end
%% ----------------------------------------------------
get_wheel(#battle_corps_info{wheel = Wheel}) ->
    Wheel.
%% ----------------------------------------------------
%% @doc
%%        获得分组
%% @end
%% ----------------------------------------------------
get_team(#battle_corps_info{team = Team}) ->
    Team.
%% ----------------------------------------------------
%% @doc
%%      获得占领城池
%% @end
%% ----------------------------------------------------
get_town_list(#battle_corps_info{town_list = TownList}) ->
    TownList.
%% ----------------------------------------------------
%% @doc
%%      设置占领城池
%% @end
%% ----------------------------------------------------
set_town_list(BattleCorpsTown, TownList) ->
    BattleCorpsTown#battle_corps_info{town_list = TownList}.
%% ----------------------------------------------------
%% @doc
%%      获得占领粮仓
%% @end
%% ----------------------------------------------------
get_barn(#battle_corps_info{barn = Barn}) ->
    Barn.
%% @doc
%%      设置占领粮仓
%% @end
%% ----------------------------------------------------
set_barn(BattleCorpsInfo, Barn) ->
    BattleCorpsInfo#battle_corps_info{barn = Barn}.
%% ----------------------------------------------------
%% @doc
%%      获得军团长名字
%% @end
%% ----------------------------------------------------
get_owner_name(#battle_corps_info{owner_name = OwnerName}) ->
    OwnerName.
%% ----------------------------------------------------
%% @doc
%%      获得军团长名字
%% @end
%% ----------------------------------------------------
get_server_name(#battle_corps_info{server_name = ServerName}) ->
    ServerName.
%% ----------------------------------------------------
%% @doc
%%        获得杀敌积分
%% @end
%% ----------------------------------------------------
get_kill_enemy(#battle_corps_info{kill_enemy = Value}) ->
    Value.
%% ----------------------------------------------------
%% @doc
%%        设置杀敌积分
%% @end
%% ----------------------------------------------------
set_kill_enemy(BattleCorpsInfo, Value) ->
    BattleCorpsInfo#battle_corps_info{kill_enemy = Value}.
%% ----------------------------------------------------
%% @doc
%%        获得攻城积分
%% @end
%% ----------------------------------------------------
get_town_points(#battle_corps_info{town_point = Points}) ->
    Points.
%% ----------------------------------------------------
%% @doc
%%        设置攻城积分
%% @end
%% ----------------------------------------------------
set_town_points(BattleCorpsInfo, Points) ->
    BattleCorpsInfo#battle_corps_info{town_point = Points}.
%% ----------------------------------------------------
%% @doc
%%        获得服务器描述
%% @end
%% ----------------------------------------------------
get_server_desc(#battle_corps_info{server_desc = Value}) ->
    Value.
%% ----------------------------------------------------
%% @doc
%%        设置服务器描述
%% @end
%% ----------------------------------------------------
set_server_desc(BattleCorpsInfo, Value) ->
    BattleCorpsInfo#battle_corps_info{server_desc = Value}.
%% ----------------------------------------------------
%% @doc
%%        更新历史积分信息
%% @end
%% ----------------------------------------------------
update_his(BattleCorpsInfo, HisPoint, HisKillEnemy, HisTownPoint) ->
    BattleCorpsInfo#battle_corps_info{his_points = HisPoint, his_kill_enemy = HisKillEnemy, his_town_point = HisTownPoint}.
%% ----------------------------------------------------
%% @doc
%%        获得历史积分
%% @end
%% ----------------------------------------------------
get_his_points(#battle_corps_info{his_points = Value}) ->
    Value.
%% ----------------------------------------------------
%% @doc
%%        获得历史击杀
%% @end
%% ----------------------------------------------------
get_his_kill_enemy(#battle_corps_info{his_kill_enemy = Value}) ->
    Value.
%% ----------------------------------------------------
%% @doc
%%        获得历史攻城
%% @end
%% ----------------------------------------------------
get_his_town_point(#battle_corps_info{his_town_point = Value}) ->
    Value.

%%%===================LOCAL FUNCTIONS==================
%% -----------------------------------------------------------------
%% Func: 
%% Description: 
%% Returns:
%% -----------------------------------------------------------------

