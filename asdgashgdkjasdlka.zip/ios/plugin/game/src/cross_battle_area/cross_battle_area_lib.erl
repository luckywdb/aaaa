-module(cross_battle_area_lib).

%%%=======================STATEMENT====================
-description("cross_battle_area_lib").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([calc_wheel_state/1, get_current_season_info/2, get_current_team/3, get_rank_to_child_server/5, corps_rank/7, single_rank/7, is_running/3, get_rank/3, get_his_rank_value/3]).
-export([role_point/5, corps_point/5, kill_enemy/5, corps_town_point/5, town_point/5, corps_kill_enemy/5, test_refresh_single_rank/1]).

%%%=======================INCLUDE======================
-include("../../game/include/cross_battle.hrl").
-include("../include/rank.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      积分增加
%% @end
%% ----------------------------------------------------
role_point(Src, RoleUid, Season, Wheel, Feat) ->
    BattleRoleFun = fun(_, 'none') ->
        {ok, ok};
        (_, BattleRoleInfo) ->
            NewPoint = battle_role_info:get_points(BattleRoleInfo) + Feat,
            {ok, {NewPoint, NewPoint + battle_role_info:get_his_points(BattleRoleInfo), battle_role_info:get_corps_uid(BattleRoleInfo)}, battle_role_info:set_points(BattleRoleInfo, NewPoint)}
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'battle_role_info'), {RoleUid, Season, Wheel}, 'none', BattleRoleFun, 'none') of
        {NewPoint_, TotalPoint_, _CorpsUid} ->
            %%更新个人积分排行榜
            zm_event:notify(Src, 'battle_role_points', [{uid, RoleUid}, {value, NewPoint_}, {'total_value', TotalPoint_}]);
%%            corps_point(Src, CorpsUid_, Season, Wheel, Feat);
        _ ->
            ok
    end.
%% ----------------------------------------------------
%% @doc
%%      军团积分
%% @end
%% ----------------------------------------------------
corps_point(Src, CorpsUid, Season, Wheel, Feat) ->
    BattleCorpsFun = fun(_, 'none') ->
        {ok, ok};
        (_, BattleCorpsInfo) ->
            NewCorpsPoint = battle_corps_info:get_points(BattleCorpsInfo) + Feat,
            {ok, {NewCorpsPoint, NewCorpsPoint + battle_corps_info:get_his_points(BattleCorpsInfo)}, battle_corps_info:set_points(BattleCorpsInfo, NewCorpsPoint)}
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'battle_corps_info'), {CorpsUid, Season, Wheel}, 'none', BattleCorpsFun, 'none') of
        {CorpsPoints_, TotalCorpsPoint_} ->
            %%更新军团积分排行榜
            zm_event:notify(Src, 'battle_corps_points', [{uid, CorpsUid}, {value, CorpsPoints_}, {'total_value', TotalCorpsPoint_}]);
        _ ->
            ok
    end.
%% ----------------------------------------------------
%% @doc
%%      战斗积分增加
%% @end
%% ----------------------------------------------------
kill_enemy(Src, RoleUid, Season, Wheel, KillEnemy) ->
    BattleRoleFun = fun(_, 'none') ->
        {ok, ok};
        (_, BattleRoleInfo) ->
            NewKillEnemy = battle_role_info:get_kill_enemy(BattleRoleInfo) + KillEnemy,
            {ok, {NewKillEnemy, NewKillEnemy + battle_role_info:get_his_kill_enemy(BattleRoleInfo), battle_role_info:get_corps_uid(BattleRoleInfo)}, battle_role_info:set_kill_enemy(BattleRoleInfo, NewKillEnemy)}
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'battle_role_info'), {RoleUid, Season, Wheel}, 'none', BattleRoleFun, 'none') of
        {NewKillEnemy_, TotalPoint_, CorpsUid_} ->
            zm_event:notify(Src, 'battle_role_kill_enemy', [{uid, RoleUid}, {value, NewKillEnemy_}, {'total_value', TotalPoint_}]),
            corps_kill_enemy(Src, CorpsUid_, Season, Wheel, KillEnemy);
        _ ->
            ok
    end.
%% ----------------------------------------------------
%% @doc
%%      军团战斗积分增加
%% @end
%% ----------------------------------------------------
corps_kill_enemy(Src, CorpsUid, Season, Wheel, KillEnemy) ->
    BattleCorpsFun = fun(_, 'none') ->
        {ok, ok};
        (_, BattleCorpsInfo) ->
            NewCorpsPoint = battle_corps_info:get_kill_enemy(BattleCorpsInfo) + KillEnemy,
            {ok, {NewCorpsPoint, NewCorpsPoint + battle_corps_info:get_his_kill_enemy(BattleCorpsInfo)}, battle_corps_info:set_kill_enemy(BattleCorpsInfo, NewCorpsPoint)}
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'battle_corps_info'), {CorpsUid, Season, Wheel}, 'none', BattleCorpsFun, 'none') of
        {NewCorpsPoint_, TotalPoint_} ->
            zm_event:notify(Src, 'battle_corps_kill_enemy', [{uid, CorpsUid}, {value, NewCorpsPoint_}, {'total_value', TotalPoint_}]);
        _ ->
            ok
    end.
%% ----------------------------------------------------
%% @doc
%%      战斗攻城增加
%% @end
%% ----------------------------------------------------
town_point(Src, RoleUid, Season, Wheel, TownPoint) ->
    BattleRoleFun = fun(_, 'none') ->
        {ok, ok};
        (_, BattleRoleInfo) ->
            NewTownPoint = battle_role_info:get_town_points(BattleRoleInfo) + TownPoint,
            {ok, {NewTownPoint, NewTownPoint + battle_role_info:get_his_town_point(BattleRoleInfo), battle_role_info:get_corps_uid(BattleRoleInfo)}, battle_role_info:set_town_points(BattleRoleInfo, NewTownPoint)}
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'battle_role_info'), {RoleUid, Season, Wheel}, 'none', BattleRoleFun, 'none') of
        {NewTownPoint_, TotalPoint_, CorpsUid_} ->
            %%更新个人积分排行榜
            zm_event:notify(Src, 'battle_role_town', [{uid, RoleUid}, {value, NewTownPoint_}, {'total_value', TotalPoint_}]),
            corps_town_point(Src, CorpsUid_, Season, Wheel, TownPoint);
        _ ->
            ok
    end.
%% ----------------------------------------------------
%% @doc
%%      军团攻城增加
%% @end
%% ----------------------------------------------------
corps_town_point(Src, CorpsUid, Season, Wheel, TownPoint) ->
    BattleCorpsFun = fun(_, 'none') ->
        {ok, ok};
        (_, BattleCorpsInfo) ->
            NewCorpsPoint = battle_corps_info:get_town_points(BattleCorpsInfo) + TownPoint,
            {ok, {NewCorpsPoint, NewCorpsPoint + battle_corps_info:get_his_town_point(BattleCorpsInfo)}, battle_corps_info:set_town_points(BattleCorpsInfo, NewCorpsPoint)}
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'battle_corps_info'), {CorpsUid, Season, Wheel}, 'none', BattleCorpsFun, 'none') of
        {NewCorpsPoint_, TotalPoint_} ->
            zm_event:notify(Src, 'battle_corps_town', [{uid, CorpsUid}, {value, NewCorpsPoint_}, {'total_value', TotalPoint_}]);
        _ ->
            ok
    end.
%% ----------------------------------------------------
%% @doc
%%      计算当前状态
%% @end
%% ----------------------------------------------------
calc_wheel_state(CrossBattleArea) ->
    State = cross_battle_area:get_state(CrossBattleArea),
    if
        State =:= ?CROSS_SERVER_STATE_SYNC_GROUP ->
            CrossBattleArea;
        State =:= ?CROSS_SERVER_STATE_CLOSS ->
            CrossBattleArea;
        true ->
            StartTime = cross_battle_area:get_start_time(CrossBattleArea),
            ContinueTime = cross_battle_area:get_continue_time(CrossBattleArea),
            EndTime = StartTime + ContinueTime,
            Now = time_lib:now_second(),
            case Now >= EndTime of
                true ->
                    Wheel = cross_battle_area:get_wheel(CrossBattleArea),
                    WheelStateTime = cross_battle_area:get_wheel_state_time(CrossBattleArea),
                    if
                        State =:= ?CROSS_SERVER_STATE_SYNC_DATA orelse State =:= ?CROSS_SERVER_STATE_SYNC_DATA_COMPLETE ->
                            StateTime = element(Wheel, WheelStateTime),
                            NState = ?CROSS_SERVER_STATE_OPEN,
                            cross_battle_area:update_state(CrossBattleArea, NState, EndTime, element(NState, StateTime));
                        State =/= ?CROSS_SERVER_STATE_CLEAR andalso State =/= ?CROSS_SERVER_STATE_CLEAR_COMPLETE ->
                            NState = State + 1,
                            StateTime = element(Wheel, WheelStateTime),
                            cross_battle_area:update_state(CrossBattleArea, NState, EndTime, element(NState, StateTime));
                        true ->
                            case Wheel >= tuple_size(WheelStateTime) of
                                true ->
                                    cross_battle_area:update_state(CrossBattleArea, ?CROSS_SERVER_STATE_CLOSS, EndTime, 0);
                                false ->
                                    cross_battle_area:set_wheel(cross_battle_area:update_state(CrossBattleArea, ?CROSS_SERVER_STATE_SYNC_GROUP, EndTime, 0), Wheel + 1)
                            end
                    end;
                false ->
                    CrossBattleArea
            end
    end.
%% ----------------------------------------------------
%% @doc
%%        获得当前赛季信息
%% @end
%% ----------------------------------------------------
get_current_season_info(Src, _ActionType) ->
    case cross_battle_area_db:get_cache_cross_battle_area(Src) of
        'none' ->
            {0, 0};
        CrossBattleArea ->
            {cross_battle_area:get_term(CrossBattleArea), cross_battle_area:get_wheel(CrossBattleArea)}
    end.
%% ----------------------------------------------------
%% @doc
%%        获取当前分组
%% @end
%% ----------------------------------------------------
get_current_team(Src, Uid, Type) when Type =:= ?BATTLE_POINTS_ALL_ROLE_RANK;Type =:= ?BATTLE_TOWN_ALL_ROLE_RANK;Type =:= ?BATTLE_FEATS_ALL_ROLE_RANK ->
    BattleRoleInfo = z_db_lib:get(game_lib:get_table(Src, 'battle_role_info'), Uid),
    battle_role_info:get_team(BattleRoleInfo);
get_current_team(Src, Uid, Type) when Type =:= ?BATTLE_POINTS_ALL_CORPS_RANK;Type =:= ?BATTLE_TOWN_ALL_CORPS_RANK;Type =:= ?BATTLE_FEATS_ALL_CORPS_RANK ->
    BattleCorpsInfo = z_db_lib:get(game_lib:get_table(Src, 'battle_corps_info'), Uid),
    battle_corps_info:get_team(BattleCorpsInfo).
%% ----------------------------------------------------
%% @doc
%%        中控向子服务器推排行榜
%% @end
%% ----------------------------------------------------
get_rank_to_child_server(Src, Type, Season, Wheel, MapId) ->
    case zm_config:get('cross_battle_area_rank_info', Type) of
        {_, {M, F, A}} ->
            M:F(A, Src, Season, Wheel, MapId, Type, []);
        _ ->
            []
    end.
%% ----------------------------------------------------
%% @doc
%%       判断给定赛季、轮次是否正在运行
%% @end
%% ----------------------------------------------------
is_running(Src, Season, Wheel) ->
    {CurrentSeason, CurrentWheel} = cross_battle_area_lib:get_current_season_info(Src, "cb_area"),
    CurrentSeason =:= Season andalso CurrentWheel =:= Wheel.
%% ----------------------------------------------------
%% @doc
%%       获得排名
%% @end
%% ----------------------------------------------------
get_rank(Uid, RankTypes, TypeRankers) ->
    Fun = fun({RankType, _}, R) ->
        case lists:keyfind(RankType, 1, TypeRankers) of
            {_, TypeRanker} ->
                {Rank, Value} = list_lib:list_key_index_value(Uid, {1, 2}, TypeRanker),
                [{RankType, Rank, Value} | R];
            _ ->
                [{RankType, 0, 0} | R]
        end
    end,
    lists:foldl(Fun, [], RankTypes).
%%select_rank('same_corps', Src, Uid, Rankers) ->
%%    Fun = fun(Ranker, R) ->
%%        ok
%%    end,
%%    ok.
%% ----------------------------------------------------
%% @doc
%%      军团排行榜
%% @end
%% ----------------------------------------------------
corps_rank(['all'], Src, Season, Wheel, Team, Type, _Msg) ->
    rank_get:get_cross_progress_rank(Src, Type, Season, Wheel, Team, 0, 'all');
corps_rank([Num], Src, Season, Wheel, Team, Type, _Msg) ->
    rank_get:get_cross_progress_rank(Src, Type, Season, Wheel, Team, 1, Num + 1).
%% ----------------------------------------------------
%% @doc
%%      个人排行榜
%% @end
%% ----------------------------------------------------
single_rank(['all'], Src, Season, Wheel, Team, Type, _Msg) ->
    rank_get:get_cross_progress_rank(Src, Type, Season, Wheel, Team, 0, 'all');
single_rank([Num], Src, Season, Wheel, Team, Type, _Msg) ->
    rank_get:get_cross_progress_rank(Src, Type, Season, Wheel, Team, 1, Num).
%% ----------------------------------------------------
%% @doc
%%      获得排行榜历史值
%% @end
%% ----------------------------------------------------
get_his_rank_value(Src, Uid, Type) ->
    case z_db_lib:get(game_lib:get_table(Src, 'rank_player'), {Uid, Type}, 'none') of
        'none' ->
            0;
        Rank ->
            rank:get_value(Rank)
    end.
%% ----------------------------------------------------
%% @doc
%%      测试刷新排行榜
%% @end
%% ----------------------------------------------------
test_refresh_single_rank(Src) ->
    case cross_battle_area_db:get_cache_cross_battle_area(Src) of
        'none' ->
            'none';
        CrossArea ->
            Season = cross_battle_area:get_term(CrossArea),
            Wheel = cross_battle_area:get_wheel(CrossArea),
            Table = game_lib:get_table(Src, 'battle_role_info'),
            Fun = fun(_, {RoleUid, Season1, Wheel1}, _, {Num, R}) ->
                if
                    Season =:= Season1 andalso Wheel =:= Wheel1 ->
                        io:format("=======RoleUid=~p~n", [RoleUid]),
                        if
                            Num > 100 ->
                                zm_event:notify(Src, 'cross_battle_role_point', [{RoleUid, z_lib:random(10000, 100000)} | R]),
                                {0, []};
                            true ->
                                {Num + 1, [{RoleUid, z_lib:random(10000, 100000)} | R]}
                        end;
                    true ->
                        {Num, R}
                end;
                (_, _, _, R) ->
                    R
            end,
            {_, RoleUids} = z_db_lib:table_iterate(Src, Table, Fun, [], {0, []}),
            zm_event:notify(Src, 'cross_battle_role_point', RoleUids)
    end.

%%%===================LOCAL FUNCTIONS==================
