-module(map_ys_port).

%%%=======================STATEMENT====================
-description("map_ys_port").
-copyright('youkia,www.youkia.net').
-author("ljh,lvjihong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([recruit/5, recruit_over/5, cancel/5, get_recruit_info/5]).

%%%=======================INCLUDE======================
-include("../include/building.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      招募侦察兵
%% @end
%% ----------------------------------------------------
recruit([{M, F, A}], _, Attr, Info, Msg) ->
    Num = z_lib:get_value(Msg, "num", -1),
    Type = z_lib:get_value(Msg, "type", -1),
    CheckVaild = valid_lib:check_valib([{'gt', Num, 0}, {'exist', Type, [?RMB_UP, ?NORMAL_UP]}]),
    R = if
        CheckVaild ->
            {_, OnceNum} = zm_config:get('spy_info', 'spy_soldier_once_num'),
            if
                Num =< OnceNum ->
                    Now = time_lib:now_second(),
                    RoleUid = role_lib:get_uid(Attr),
                    Src = z_lib:get_value(Info, 'src', none),
                    {_, Consume, ConsumeTime} = zm_config:get('spy_info', 'spy_soldier_recruit_consume'),
                    {_, MaxSoldierNum} = zm_config:get('spy_info', 'spy_soldier_max_num'),
                    TableName = game_lib:get_table(Src),
                    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'role', RoleUid},
                        {'map_spy', RoleUid, map_spy:spy_init()},
                        {'rmb', RoleUid, rmb_lib:init()}]),
                    case z_db_lib:handle(TableName, {M, F, A}, {Now, Consume, ConsumeTime, MaxSoldierNum, Num, Type}, TableKeys) of
                        {'ok', Cs, NeedTime, NSpy} ->
                            zm_log:info(Src, ?MODULE, 'recruit', "recruit", [{'roleuid', RoleUid}, {'consume', Cs}, {'need_time', NeedTime}, {'number', Num}, {'new_spy_soldier', NSpy}]),
%%                            zm_event:notify(Src, 'bi_cross_battle_recruit', [{'roleuid', RoleUid}, {'consume', Cs}, {'need_time', NeedTime}, {'number', Num}, {'new_spy_soldier', NSpy}]),
                            {Now, NeedTime};
                        Err ->
                            Err
                    end;
                true ->
                    "once_num_limit"
            end;
        true ->
            "input_error"
    end,
    {ok, [], Info, [{msg, R}]}.
%% ----------------------------------------------------
%% @doc
%%      招募侦察兵完成 Type = 0 普通完成/1rmb秒剩下的时间
%% @end
%% ----------------------------------------------------
recruit_over([{M, F, A}], _, Attr, Info, Msg) ->
    Type = z_lib:get_value(Msg, "type", -1),
    CheckVaild = valid_lib:check_valib([{'exist', Type, [0, 1]}]),
    R = if
        CheckVaild ->
            RoleUid = role_lib:get_uid(Attr),
            Src = z_lib:get_value(Info, 'src', none),
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'rmb', RoleUid, rmb_lib:init()}, {'map_spy', RoleUid, map_spy:spy_init()}]),
            case z_db_lib:handle(TableName, {M, F, A}, Type, TableKeys) of
                {ok, Cs, DecRmb, Number} ->
                    zm_log:info(Src, ?MODULE, 'recruit_over', "recruit_over", [{'roleuid', RoleUid}, {'consume', Cs}, {'number', Number}]),
%%                   zm_event:notify(Src, 'bi_cross_battle_recruit_over', [{'roleuid', RoleUid}, {'consume', Cs}, {'number', Number}]),
                    {Number, DecRmb};
                Err ->
                    Err
            end;
        true ->
            "input_error"
    end,
    {ok, [], Info, [{msg, R}]}.
%% ----------------------------------------------------
%% @doc
%%      取消招募侦察兵
%% @end
%% ----------------------------------------------------
cancel([{M, F, A}], _, Attr, Info, _Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, 'src', none),
    {_, Percent} = zm_config:get('spy_info', 'spy_soldier_cancel_percent'),
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'map_spy', RoleUid, map_spy:spy_init()}]),
    R = case z_db_lib:handle(TableName, {M, F, A}, Percent, TableKeys) of
        {ok, Award} ->
            AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, Award),
            zm_log:info(Src, ?MODULE, 'cancel', "cancel", [{'roleuid', RoleUid}, {'award', AwardLog}]),
            AwardLog;
        Err ->
            Err
    end,
    {ok, [], Info, [{msg, R}]}.
%% ----------------------------------------------------
%% @doc
%%      登录的时候获取招募队列
%% @end
%% ----------------------------------------------------
get_recruit_info(_, _, Attr, Info, _Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, 'src', none),
    Spy = z_db_lib:get(game_lib:get_table(Src, 'map_spy'), RoleUid, map_spy:spy_init()),
    Queue = map_spy:get_queue(Spy),
    R = case map_spy:get_state(Queue) > 0 of
        true ->
            {map_spy:get_start_time(Queue), map_spy:get_need_time(Queue), map_spy:get_num(Queue)};
        false ->
            {}
    end,
    {ok, [], Info, [{msg, {map_spy:get_leisure(Spy), R}}]}.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
