-module(map_ys_point_timer).

%%%=======================STATEMENT====================
-description("map_ys_point_timer").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([timer/3]).

%%%=======================INCLUDE======================
-include("../../../include/sign_key.hrl").
-include("../include/cross_battle.hrl").
%%%=======================DEFINE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        
%% @end
%% ----------------------------------------------------
timer(Src, _, _) ->
    Bool = zm_load:server_start_ok() =:= ?KEY andalso
           args_system:is_game_center_server(Src),
    if
        Bool ->
            case cross_battle_area_db:get_cache_cross_battle_area(Src) of
                'none' ->
                    ok;
                CrossBattleArea ->
                    case cross_battle_area:get_state(CrossBattleArea) =:= ?CROSS_SERVER_STATE_OPEN of
                        true ->
                            MapYsState = map_ys_point_db:get_map_ys_state(Src),
                            Now = time_lib:now_second(),
                            {_, STime, CTime} = zm_config:get('map_ys_point_info', 'open_time'),
                            case MapYsState of
                                {0, _} ->
                                    StartTime = cross_battle_area:get_start_time(CrossBattleArea),
                                    case Now >= StartTime + STime of
                                        true ->
                                            map_ys_point_db:update_map_ys_state(Src, {1, StartTime + STime}),
                                            %%增加创建timer
                                            Fun = fun(_, CorpsUid, _, R) ->
                                                map_ys_point_db:add_corps_create_ys(Src, CorpsUid, Now + z_lib:random(1, 60)),
                                                {ok, R}
                                                  end,
                                            z_db_lib:table_iterate(Src, game_lib:get_table(Src, 'corps'), Fun, [], []),
                                            set_front_lib:send_map_ys_state(Src, 1, StartTime + STime),
                                            %%广播
                                            lists:foreach(fun(MapId) -> chat_lib:notice_mapid(Src, 'map_ys_start', [], MapId) end, cross_battle_area:get_mapids(CrossBattleArea));
                                        false ->
                                            ok
                                    end;
                                {1, MapYsStartTime} ->
                                    case Now >= MapYsStartTime + CTime of
                                        true ->
                                            %%清除
                                            z_db_lib:clear(game_lib:get_table(Src, 'map_ys_timer')),
                                            MapYsPointTable = game_lib:get_table(Src, 'map_ys_point'),
                                            Fun = fun(_, Sid, _, R) ->
                                                MapYsPoints = map_ys_point_db:get_map_ys_point(Src, Sid),
                                                lists:foreach(fun(MapYsPoint) ->
                                                    PUid = map_ys_point:get_point_uid(MapYsPoint),
                                                    map_ys_point_db:point_over(Src, Sid, PUid)
                                                              end, MapYsPoints),
                                                {ok, R}
                                                  end,
                                            z_db_lib:table_iterate(Src, MapYsPointTable, Fun, [], []),
                                            %%增加buff
                                            {_, BuffSidList} = zm_config:get('map_ys_point_info', 'add_all_buff'),
                                            StartTime = cross_battle_area:get_start_time(CrossBattleArea),
                                            ContinueTime = cross_battle_area:get_continue_time(CrossBattleArea),
                                            role_country_buff:add_buff(Src, 'all', BuffSidList, max(StartTime + ContinueTime - Now, 0)),
                                            map_ys_point_db:update_map_ys_state(Src, {2, MapYsStartTime + CTime}),
                                            set_front_lib:send_map_ys_state(Src, 2, MapYsStartTime + STime),
                                            lists:foreach(fun(MapId) -> chat_lib:notice_mapid(Src, 'map_ys_stop', [], MapId) end, cross_battle_area:get_mapids(CrossBattleArea));
                                        false ->
                                            MapYsTimerTable = game_lib:get_table(Src, 'map_ys_timer'),
                                            Fun = fun(_, {Time, _, _} = Key, _, R) ->
                                                case Time > Now of
                                                    true ->
                                                        {'break', R};
                                                    false ->
                                                        map_ys_point_db:op_timer(Src, Key),
                                                        z_db_lib:delete(MapYsTimerTable, Key),
                                                        {ok, R}
                                                end
                                                  end,
                                            z_db_lib:table_iterate(Src, MapYsTimerTable, Fun, [], [], 'ascending')
                                    end;
                                _ ->
                                    ok
                            end;
                        false ->
                            ok
                    end
            end;
        true ->
            ok
    end.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
