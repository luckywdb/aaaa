-module(cross_battle_area).

%%%=======================STATEMENT====================
-description("center_cross_battle_area").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([init/8]).
-export([
    get_id/1,
    get_term/1,
    get_wheel/1,
    get_state/1,
    get_start_time/1,
    get_continue_time/1,
    get_corps_uids/1,
    get_corps_uidnames/1,
    get_wheel_state_time/1,
    get_mapids/1,
    get_server_rank_num/1,
    get_sync_state_time/1,
    get_sync_group_state/1
]).
-export([
    update_state/4,
    set_wheel/2,
    set_mapids/2,
    set_corps_uidnames/2,
    set_sync_state_time/2,
    set_sync_group_state/2
]).

%%%=======================INCLUDE======================
-include("../../game/include/cross_battle.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(cross_battle_area, {
    id = 0 :: integer(),%%赛区
    term = 0 :: integer(),%%当前赛季
    wheel = 1 :: integer(),%%当前轮数
    state = ?CROSS_SERVER_STATE_CLOSS :: integer(),%%状态(默认准备中),
    start_time = 0 :: integer(),%%开始时间
    continue_time = 0 :: integer(),%%持续时间
    corps_uidnames = [] :: [{integer(), string()}], %%跨服的军团uid名字列表
    wheel_state_time :: tuple(),
    mapids = [], %%地图id列表
    server_rank_num = 0 :: integer(), %%选取游戏服排行榜前几
    sync_group_state = 0 :: integer(), %%0表示同步完成 其余表示时间戳
    sync_state_time = 0 :: integer() %%状态同步时间
}).
%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        
%% @end
%% ----------------------------------------------------
init(AreaNum, Term, Wheel, State, StartTime, ContinueTime, WheelStateTime, SelectServerRankNum) ->
    #cross_battle_area{id = AreaNum, term = Term, wheel = Wheel, state = State, server_rank_num = SelectServerRankNum,
        start_time = StartTime, continue_time = ContinueTime, wheel_state_time = WheelStateTime, sync_state_time = StartTime}.

get_id(#cross_battle_area{id = V}) -> V.
get_term(#cross_battle_area{term = V}) -> V.
get_wheel(#cross_battle_area{wheel = V}) -> V.
get_state(#cross_battle_area{state = V}) -> V.
get_start_time(#cross_battle_area{start_time = V}) -> V.
get_continue_time(#cross_battle_area{continue_time = V}) -> V.
get_corps_uids(#cross_battle_area{corps_uidnames = V}) -> [CUid || {CUid, _} <- V].
get_corps_uidnames(#cross_battle_area{corps_uidnames = V}) -> V.
get_wheel_state_time(#cross_battle_area{wheel_state_time = V}) -> V.
get_mapids(#cross_battle_area{mapids = V}) -> V.
get_server_rank_num(#cross_battle_area{server_rank_num = V}) -> V.
get_sync_state_time(#cross_battle_area{sync_state_time = V}) -> V.
get_sync_group_state(#cross_battle_area{sync_group_state = V}) -> V.

update_state(CrossBattleArea, State, StartTime, ContinueTime) ->
    CrossBattleArea#cross_battle_area{state = State, start_time = StartTime, continue_time = ContinueTime}.

set_wheel(CrossBattleArea, Wheel) ->
    CrossBattleArea#cross_battle_area{wheel = Wheel}.
set_mapids(CrossBattleArea, MapIds) ->
    CrossBattleArea#cross_battle_area{mapids = MapIds}.
set_corps_uidnames(CrossBattleArea, CorpsUidNames) ->
    CrossBattleArea#cross_battle_area{corps_uidnames = CorpsUidNames}.
set_sync_state_time(CrossBattleArea, SyncStateTime) ->
    CrossBattleArea#cross_battle_area{sync_state_time = SyncStateTime}.
set_sync_group_state(CrossBattleArea, SyncGroupState) ->
    CrossBattleArea#cross_battle_area{sync_group_state = SyncGroupState}.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
