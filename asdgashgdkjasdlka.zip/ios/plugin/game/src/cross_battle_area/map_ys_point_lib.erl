-module(map_ys_point_lib).

%%%=======================STATEMENT====================
-description("map_ye_point_lib").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([calc_bvalue/2, deduct_bvalue/3]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        计算建筑值
%% @end
%% ----------------------------------------------------
calc_bvalue(Now, MapYsPoint) ->
    BValueReTime = map_ys_point:get_bvalue_retime(MapYsPoint),
    case BValueReTime > 0 of
        true ->
            BValue = map_ys_point:get_bvalue(MapYsPoint),
            Level = map_ys_point:get_level(MapYsPoint),
            Detail = map_ys_point_detail:get_cfg(Level),
            BValueReSpeed = map_ys_point_detail:get_bvalue_respeed(Detail),
            AddBValue = max((Now - BValueReTime) * BValueReSpeed div 3600, 0),
            case AddBValue > 0 of
                true ->
                    NBValue1 = BValue + AddBValue,
                    MaxBValue = map_ys_point_detail:get_max_bvalue(Detail),
                    {NBValue, NBValueReTime} =
                        case NBValue1 >= MaxBValue of
                            true ->
                                {MaxBValue, 0};
                            false ->
                                {NBValue1, Now}
                        end,
                    map_ys_point:update_bvalue(MapYsPoint, NBValue, NBValueReTime);
                false ->
                    MapYsPoint
            end;
        false ->
            MapYsPoint
    end.

%% ----------------------------------------------------
%% @doc
%%      扣建筑值
%% @end
%% ----------------------------------------------------
deduct_bvalue(OMapYsPoint, Attack, METime) ->
    MapYsPoint = calc_bvalue(METime, OMapYsPoint),
    BValue = map_ys_point:get_bvalue(MapYsPoint),
    BValueReSTime = map_ys_point:get_bvalue_retime(MapYsPoint),
    NBValue = max(BValue - Attack, 0),
    NBValueReSTime = case BValueReSTime > 0 of
        true ->
            BValueReSTime;
        false ->
            METime
    end,
    NMapYsPoint = map_ys_point:update_bvalue(MapYsPoint, NBValue, NBValueReSTime),
    {NBValue =< 0, NMapYsPoint}.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
