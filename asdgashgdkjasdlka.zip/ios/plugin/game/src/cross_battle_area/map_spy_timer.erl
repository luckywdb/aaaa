-module(map_spy_timer).

%%%=======================STATEMENT====================
-description("map_spy_timer").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
%%%=======================EXPORT=======================
-export([timer/3]).

%%%=======================INCLUDE======================
-include("../../../include/sign_key.hrl").
-include("../include/cross_battle.hrl").
%%%=======================DEFINE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
timer(Src, _, _) ->
    Bool = zm_load:server_start_ok() =:= ?KEY andalso args_system:is_game_center_server(Src),
    if
        Bool ->
            Now = time_lib:now_second(),
            MapSpyTimerTable = game_lib:get_table(Src, 'map_spy_timer'),
            Fun = fun(_, {Time, RoleUid, PointUid} = Key, _, R) ->
                case Time > Now of
                    true ->
                        {'break', R};
                    false ->
                        map_spy_db:spy_etime(Src, RoleUid, PointUid),
                        z_db_lib:delete(MapSpyTimerTable, Key),
                        {ok, R}
                end
            end,
            z_db_lib:table_iterate(Src, MapSpyTimerTable, Fun, [], [], 'ascending');

        true ->
            ok
    end.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
