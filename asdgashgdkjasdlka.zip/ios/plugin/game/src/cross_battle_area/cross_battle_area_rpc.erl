-module(cross_battle_area_rpc).

%%%=======================STATEMENT====================
-description("cross_battle_area_rpc").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    game_transfer_award_res/3,
    get_assault_info/3,
    send_assault_info/3
]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%        划拨奖励
%% @end
%% ----------------------------------------------------
game_transfer_award_res(_CenterSrc, _GroupId, {RoleUid, AwardList}) ->
    GameSrc = game_lib:get_game_src(),
    AwardLog = awarder_game:give_award(GameSrc, RoleUid, ?MODULE, AwardList),
    zm_log:info(GameSrc, ?MODULE, 'game_transfer_award_res', "game_transfer_award_res", [{'role_uid', RoleUid}, {'award_list', AwardList},
        {'award', AwardLog}]),
    zm_event:notify(GameSrc, 'bi_cb_transfer_award', [{'role_uid', RoleUid}, {'award', AwardLog}]),
    %%
    ok.
%% ----------------------------------------------------
%% @doc
%%      获取袭击信息以及协防信息
%% @end
%% ----------------------------------------------------
get_assault_info(_CenterSrc, _GroupId, RoleUid) ->
    fight_db:cross_get_assault_info(game_lib:get_game_src(), RoleUid).
%% ----------------------------------------------------
%% @doc
%%      袭击信息发送推送
%% @end
%% ----------------------------------------------------
send_assault_info(_CenterSrc, _GroupId, {RoleUid, AssaultView}) ->
    GameSrc = game_lib:get_game_src(),
    set_front_lib:send_assault(GameSrc, RoleUid, AssaultView).

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
