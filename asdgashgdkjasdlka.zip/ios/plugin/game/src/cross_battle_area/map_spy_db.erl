-module(map_spy_db).

%%%=======================STATEMENT====================
-description("cross_battle_spy_db").
-copyright('youkia,www.youkia.net').
-author("ljh,lvjihong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([init/1, init_spy_soldiers_num/2]).
-export([get_map_spy/2]).
-export([spy_arrive/3, spy_etime/3, recruit/3, recruit_over/3, cancel/3]).
-export([update_fight_after/5]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").
-include("../include/building.hrl").
%%%=======================DEFINE======================
%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      初始化
%% @end
%% ----------------------------------------------------
init(Src) ->
    TableName = game_lib:get_table(Src, 'map_spy'),
    TimerTableName = game_lib:get_table(Src, 'map_spy_timer'),
    Fun = fun(_, RoleUid, _, R) ->
        MapSpy = z_db_lib:get(TableName, RoleUid),
        RoleShow = role_db:get_role_show(Src, RoleUid),
        RoleInfo = {RoleUid, role_show:get_name(RoleShow), role_show:get_corps_uid(RoleShow), role_show:get_corps_name(RoleShow), role_show:get_country(RoleShow)},
        lists:foreach(fun(MapSpyBuild) ->
            Info = point_search_db:format_map_spy_build(MapSpyBuild, RoleInfo, 0),
            PointUid = map_spy:get_build_point_uid(MapSpyBuild),
            SearchPUid = point_lib:point2search_point(PointUid),
            point_search_db:update_search(Src, SearchPUid, {point_lib:xyz2view(PointUid), Info}),
            %%计时器
            ETime = map_spy:get_build_etime(MapSpyBuild),
            z_db_lib:update(TimerTableName, {ETime, RoleUid, PointUid}, true)
        end, map_spy:get_builds(MapSpy)),
        {ok, R}
    end,
    z_db_lib:table_iterate(Src, TableName, Fun, [], []),
    ok.
%% ----------------------------------------------------
%% @doc
%%      初始化设置侦察兵数量
%% @end
%% ----------------------------------------------------
init_spy_soldiers_num(Src, RoleUid) ->
    {_, SoldiersNum} = zm_config:get('spy_info', 'spy_soldier_default_num'),
    Fun1 = fun(_, MapSpy) ->
        {ok, ok, map_spy:update_leisure(MapSpy, SoldiersNum)}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'map_spy'), RoleUid, map_spy:spy_init(), Fun1, []).
%% ----------------------------------------------------
%% @doc
%%      超时
%% @end
%% ----------------------------------------------------
spy_etime(Src, RoleUid, PointUid) ->
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'point_state', PointUid, 'none'},
        {'map_spy', RoleUid, map_spy:spy_init()}]),
    Fun = fun(_, [{Index1, _}, {Index2, MapSpy}]) ->
        PIndex = map_spy:get_build_point_uid_index(),
        Builds = map_spy:get_builds(MapSpy),
        case lists:keyfind(PointUid, PIndex, Builds) of
            false ->
                {ok, false};
            _ ->
                NBuilds = lists:keydelete(PointUid, PIndex, Builds),
                NMapSpy = map_spy:set_builds(MapSpy, NBuilds),
                {ok, true, [{Index1, 'delete'}, {Index2, NMapSpy}]}
        end
    end,
    case z_db_lib:handle(TableName, Fun, [], TableKeys) of
        true ->
            RoleShow = role_db:get_role_show(Src, RoleUid),
            point_horizon:delete_horizon(Src, role_show:get_corps_uid(RoleShow), PointUid),
            OccMarchings = point_march:get_occupy(z_db_lib:get(game_lib:get_table(Src, 'point_march'), PointUid, point_march:init())),
            lists:foreach(fun(OccMarching) ->
                {MRUid, MGId} = marching:get_roleuid_gid(OccMarching),
                fight_db:occ_repatriate(Src, MRUid, MGId, PointUid)
            end, OccMarchings),
            point_search_db:delete_map_spy_build(Src, PointUid),
            set_front_lib:send_map_spy_build_change(Src, RoleUid, point_lib:xyz2view(PointUid), 0),
            true;
        false ->
            false
    end.
%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
get_map_spy(Src, RoleUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'map_spy'), RoleUid, map_spy:spy_init()).

%% ----------------------------------------------------
%% @doc
%%      侦查到达
%% @end
%% ----------------------------------------------------
spy_arrive(Src, PointUid, Marching) ->
    RoleUid = marching:get_roleuid(Marching),
    SPointUid = marching:get_s_point(Marching),
    TableName = game_lib:get_table(Src),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'point_state', PointUid, 'none'},
        {'map_spy', RoleUid, map_spy:spy_init()},
        {'point_march', SPointUid, point_march:init()}]),
    Fun = fun(_, [{Index1, 'none'}, {Index2, MapSpy}, {Index3, MPointMarch}]) ->
        PState = {?MAP_SPY, RoleUid},
        Now = time_lib:now_second(),
        {_, Timeout} = zm_config:get('map_spy_info', 'spy_continue_sec'),
        SpyBuild = map_spy:spy_build_init(PointUid, Now + Timeout),
        Builds = map_spy:get_builds(MapSpy),
        MPoints = map_spy:get_mpoints(MapSpy),
        NBuilds = [SpyBuild | Builds],
        NMPoints = lists:delete(PointUid, MPoints),
        NMapSpy = map_spy:set_mpoints(map_spy:set_builds(MapSpy, NBuilds), NMPoints),
        NMPointMarch = point_march:check_del(point_march:set_role_march(MPointMarch, lists:delete(PointUid, point_march:get_role_march(MPointMarch)))),
        {ok, {ok, SpyBuild, NMPointMarch}, [{Index1, PState}, {Index2, NMapSpy}, {Index3, NMPointMarch}]};
        (_, _) ->
            throw("point_not_null")
    end,
    case z_db_lib:handle(TableName, Fun, {PointUid, RoleUid}, TableKeys) of
        {ok, SpyBuild, NMPointMarch} ->
            case NMPointMarch =:= 'delete' of
                true ->
                    point_search_db:del_marching(Src, SPointUid);
                false ->
                    ok
            end,
            point_horizon:add_spy_horizon(Src, role_show:get_corps_uid(RoleShow), PointUid),
            RoleInfo = {RoleUid, role_show:get_name(RoleShow), role_show:get_corps_uid(RoleShow), role_show:get_corps_name(RoleShow), role_show:get_country(RoleShow)},
            point_search_db:init_map_spy_build(Src, SpyBuild, RoleUid, RoleInfo),
            set_front_lib:send_map_spy_build_change(Src, RoleUid, point_lib:xyz2view(PointUid), map_spy:get_build_etime(SpyBuild)),
            %%计时器
            ETime = map_spy:get_build_etime(SpyBuild),
            z_db_lib:update(game_lib:get_table(Src, 'map_spy_timer'), {ETime, RoleUid, PointUid}, true),
            ok;
        Error ->
            Error
    end.

%% ----------------------------------------------------
%% @doc
%%      战斗后处理
%% @end
%% ----------------------------------------------------
update_fight_after(Src, RoleUid, MapSpyBuild, IsOver, OccNum) ->
    PointUid = map_spy:get_build_point_uid(MapSpyBuild),
    case IsOver of
        true ->
            spy_etime(Src, RoleUid, PointUid);
        false ->
            Fun = fun(_, MapSpy) ->
                PIndex = map_spy:get_build_point_uid_index(),
                Builds = map_spy:get_builds(MapSpy),
                case lists:keyfind(PointUid, PIndex, Builds) of
                    false ->
                        {ok, false};
                    _ ->
                        NBuilds = lists:keyreplace(PointUid, PIndex, Builds, MapSpyBuild),
                        NMapSpy = map_spy:set_builds(MapSpy, NBuilds),
                        MPoints = map_spy:get_mpoints(NMapSpy),
                        NewMPoints = lists:delete(PointUid, MPoints),
                        {ok, true, map_spy:set_mpoints(NMapSpy, NewMPoints)}
                end
            end,
            case z_db_lib:update(game_lib:get_table(Src, 'map_spy'), RoleUid, map_spy:spy_init(), Fun, []) of
                true ->
                    point_search_db:update_map_spy_build_occ(Src, PointUid, OccNum);
                false ->
                    ok
            end
    end.

%% ----------------------------------------------------
%% @doc  
%%      侦察兵招募
%% @end
%% ----------------------------------------------------
recruit(_, {Now, Consume, NeedTime, MaxSoldierNum, Num, Type, MinResource}, [{Index1, Role}, {Index2, Spy}, {Inedex3, Rmb}]) ->
    case map_spy:get_state(map_spy:get_queue(Spy)) > 0 of
        false ->
            Leisure = map_spy:get_leisure(Spy),
            case Num + Leisure =< MaxSoldierNum of
                true ->
                    NeedTimes = game_lib:ceil(NeedTime * Num / 10000),%向上取整
                    Consumes = [{T, game_lib:ceil(V * Num / 10000)} || {T, V} <- Consume],
                    {CheckConsumes, ConConsume} =
                        if
                            Type =:= ?RMB_UP ->
                                C = building_lib:quick_consume(Consumes, NeedTimes),
                                {C, C};
                            true ->
                                {awarder_game:merger(Consumes, MinResource), Consumes}
                        end,
                    case game_lib:checks({'map_spy_lib', 'check'}, {Role, Rmb}, 'spy_recruit', CheckConsumes) of
                        true ->
                            {Cs, {NRole, NRmb}} = game_lib:consumes({'map_spy_lib', 'consume'}, {Role, Rmb}, 'spy_recruit', ConConsume),
                            if
                                Type =:= ?RMB_UP ->
                                    NSpy = map_spy:set_leisure(Spy, Leisure + Num),
                                    {'ok', {'ok', Cs, 0, NSpy}, [{Index1, NRole}, {Index2, NSpy}, {Inedex3, NRmb}]};
                                true ->
                                    NSpy = map_spy:queue_init(Spy, Now, NeedTimes, Num, Consumes),
                                    {'ok', {'ok', Cs, NeedTimes, NSpy}, [{Index1, NRole}, {Index2, NSpy}, {Inedex3, NRmb}]}
                            end;
                        Err ->
                            throw(Err)
                    end;
                false ->
                    throw("max_num_limit")
            end;
        true ->
            throw("recruiting")%%招募中
    end.
%% ----------------------------------------------------
%% @doc
%%      侦察兵招募完成
%% @end
%% ----------------------------------------------------
recruit_over(_, Type, [{Inedex1, Rmb}, {Index2, Spy}]) ->
    Queue = map_spy:get_queue(Spy),
    case map_spy:get_state(Queue) > 0 of
        true ->
            StartTime = map_spy:get_start_time(Queue),
            NeedTime = map_spy:get_need_time(Queue),
            {BiCs, NRmb, DecRmb} = building_db:get_quick_consume(Type, NeedTime, StartTime, 0, Rmb, 0),
            Number = map_spy:get_num(Queue),
            NSpy1 = map_spy:set_leisure(Spy, map_spy:get_leisure(Spy) + Number),
            NSpy2 = map_spy:set_queue(NSpy1, map_spy:queue_init()),
            {ok, {ok, BiCs, DecRmb, Number}, [{Inedex1, NRmb}, {Index2, NSpy2}]};
        false ->
            throw("no_recruit")%%没有在招募的
    end.

%% ----------------------------------------------------
%% @doc
%%      侦察兵 取消招募
%% @end
%% ----------------------------------------------------
cancel(_, Percent, [{Index1, Spy}]) ->
    Queue = map_spy:get_queue(Spy),
    case map_spy:get_state(Queue) > 0 of
        true ->
            Consumes = map_spy:get_consumes(Queue),
            Award = lists:foldl(fun({Type, Value}, Acc) ->
                NValue = Value * Percent div 10000,
                if
                    NValue > 0 ->
                        [{Type, NValue} | Acc];
                    true ->
                        Acc
                end
            end, [], Consumes),
            NSpy = map_spy:set_queue(Spy, map_spy:queue_init()),
            {ok, {ok, Award}, [{Index1, NSpy}]};
        false ->
            throw("no_recruit")%%没有在招募的
    end.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
