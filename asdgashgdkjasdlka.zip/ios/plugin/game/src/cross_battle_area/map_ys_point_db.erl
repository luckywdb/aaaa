-module(map_ys_point_db).

%%%=======================STATEMENT====================
-description("map_ys_point_db").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    init/1,
    get_map_ys_point/2,

    add_corps_create_ys/3,
    add_marching_timer/4,
    add_create_refresh_timer/4,
    add_next_wheel_timer/4,
    add_timer/4,
    op_timer/2,

    fight_after_update/4,

    point_over/3,
    corps_create_ys/2
]).
-export([get_map_ys_state/1, update_map_ys_state/2]).
%%%=======================INCLUDE======================
-include("../include/point.hrl").
-include("../include/cross_battle.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
init(Src) ->
    TableName = game_lib:get_table(Src, 'map_ys_point'),
    Fun = fun(_, Sid, _, _) ->
        YsPoints = z_db_lib:get(TableName, Sid, []),
        lists:foreach(fun(YsPoint) ->
            PointUid = map_ys_point:get_point_uid(YsPoint),
            Detail = map_ys_point_detail:get_cfg(map_ys_point:get_level(YsPoint)),
            WheelETime = map_ys_point:get_wheel_etime(YsPoint),
            LastAttackSTime = map_ys_point:get_last_attack_stime(YsPoint),
            if
                WheelETime > 0 ->
                    WheelInteval = map_ys_point_detail:get_wheel_inteval(Detail),
                    add_next_wheel_timer(Src, Sid, PointUid, WheelETime + WheelInteval);
                true ->
                    WaveInteval = map_ys_point_detail:get_wave_inteval(Detail),
                    add_marching_timer(Src, Sid, PointUid, LastAttackSTime + WaveInteval)
            end,
            SearchPUid = point_lib:point2search_point(PointUid),
            Info = point_search_db:format_map_ys_point(YsPoint),
            point_search_db:update_search(Src, SearchPUid, {point_lib:xyz2view(PointUid), Info}),
            CreateRefreshTime = map_ys_point:get_create_refresh_time(YsPoint),
            add_create_refresh_timer(Src, Sid, PointUid, CreateRefreshTime)
        end, YsPoints)
    end,
    z_db_lib:table_iterate(Src, TableName, Fun, [], []),
    {S, _} = get_map_ys_state(Src),
    case S =:= 1 of
        true ->
            %%重启立即刷
            Now = time_lib:now_second(),
            {_, CreateIntevalSec} = zm_config:get('map_ys_point_info', 'corps_create_inteval'),
            z_db_lib:table_iterate(Src, game_lib:get_table(Src, 'corps'), fun(_, CorpsUid, _, R) ->
                add_corps_create_ys(Src, CorpsUid, Now + CreateIntevalSec + z_lib:random(1, 60)),
                {ok, R}
            end, [], []);
        false ->
            ok
    end.

%% ----------------------------------------------------
%% @doc  
%%        获取袁绍反攻列表
%% @end
%% ----------------------------------------------------
get_map_ys_point(Src, Sid) ->
    z_db_lib:get(game_lib:get_table(Src, 'map_ys_point'), Sid, []).

%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
get_map_ys_state(Src) ->
    z_db_lib:get(game_lib:get_table(Src, 'map_ys_state'), 'map_ys_state', {0, 0}).

%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
update_map_ys_state(Src, State) ->
    z_db_lib:update(game_lib:get_table(Src, 'map_ys_state'), 'map_ys_state', State).

%% ----------------------------------------------------
%% @doc
%%    增加军团刷新据点计时器
%% @end
%% ----------------------------------------------------
add_corps_create_ys(Src, CorpsUid, Time) ->
    add_timer(Src, CorpsUid, 'corps_create_ys', Time).

%% ----------------------------------------------------
%% @doc
%%      下一轮
%% @end
%% ----------------------------------------------------
add_next_wheel_timer(Src, Sid, PointUid, Time) ->
    add_timer(Src, {Sid, PointUid}, 'next_wheel', Time).

%% ----------------------------------------------------
%% @doc
%%    增加据点波次出征计时器
%% @end
%% ----------------------------------------------------
add_marching_timer(Src, Sid, PointUid, Time) ->
    add_timer(Src, {Sid, PointUid}, 'wave_marching', Time).

%% ----------------------------------------------------
%% @doc
%%    增加据点死亡刷新计时器
%% @end
%% ----------------------------------------------------
add_create_refresh_timer(Src, Sid, PointUid, Time) ->
    add_timer(Src, {Sid, PointUid}, 'create_refresh', Time).

%% ----------------------------------------------------
%% @doc
%%      删除据点所有计时器
%% @end
%% ----------------------------------------------------
delete_map_ys_timer(Src, PointUid, MapYsPoint) ->
    Sid = map_ys_point:get_sid(MapYsPoint),
    WheelETime = map_ys_point:get_wheel_etime(MapYsPoint),
    Detail = map_ys_point_detail:get_cfg(map_ys_point:get_level(MapYsPoint)),
    case WheelETime > 0 of
        true ->
            WheelInteval = map_ys_point_detail:get_wheel_inteval(Detail),
            delete_timer(Src, {Sid, PointUid}, 'next_wheel', WheelETime + WheelInteval);
        false ->
            LastAttackSTime = map_ys_point:get_last_attack_stime(MapYsPoint),
            WaveInteval = map_ys_point_detail:get_wave_inteval(Detail),
            delete_timer(Src, {Sid, PointUid}, 'wave_marching', LastAttackSTime + WaveInteval)
    end,
    CreateRefreshTime = map_ys_point:get_create_refresh_time(MapYsPoint),
    delete_timer(Src, {Sid, PointUid}, 'create_refresh', CreateRefreshTime),
    ok.

%% ----------------------------------------------------
%% @doc
%%    添加OpCode计时器
%% @end
%% ----------------------------------------------------
add_timer(Src, Sid, OPCode, Time) ->
    z_db_lib:update(game_lib:get_table(Src, 'map_ys_timer'), {Time, Sid, OPCode}, true).

%% ----------------------------------------------------
%% @doc
%%      删除计时器
%% @end
%% ----------------------------------------------------
delete_timer(Src, Sid, OPCode, Time) ->
    z_db_lib:delete(game_lib:get_table(Src, 'map_ys_timer'), {Time, Sid, OPCode}).
%% ----------------------------------------------------
%% @doc
%%    timer
%% @end
%% ----------------------------------------------------
op_timer(Src, {_Time, CorpsUid, 'corps_create_ys'}) ->
    corps_create_ys(Src, CorpsUid);
op_timer(Src, {_Time, {Sid, PointUid}, 'next_wheel'}) ->
    next_wheel(Src, Sid, PointUid);
op_timer(Src, {_Time, {Sid, PointUid}, 'wave_marching'}) ->
    wave_marching(Src, Sid, PointUid);
op_timer(Src, {_Time, {Sid, PointUid}, 'create_refresh'}) ->
    create_refresh(Src, Sid, PointUid).

%% ----------------------------------------------------
%% @doc
%%      战斗之后处理
%% @end
%% ----------------------------------------------------
fight_after_update(Src, Sid, PointUid, FightMapYsPoint) ->
    BValue = map_ys_point:get_bvalue(FightMapYsPoint),
    case BValue =< 0 of
        true ->%%被打爆
            point_over(Src, Sid, PointUid);
        false ->
            Fun = fun(_, MapYsPoints) ->
                PIndex = map_ys_point:get_point_uid_index(),
                case lists:keyfind(PointUid, PIndex, MapYsPoints) of
                    false ->
                        {ok, false};
                    _ ->
                        NMapYsPoints = lists:keyreplace(PointUid, PIndex, MapYsPoints, FightMapYsPoint),
                        {ok, true, NMapYsPoints}
                end
            end,
            case z_db_lib:update(game_lib:get_table(Src, 'map_ys_point'), Sid, [], Fun, []) of
                true ->
                    point_search_db:update_map_ys_point(Src, FightMapYsPoint);
                false ->
                    ok
            end
    end.

%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
point_over(Src, Sid, PointUid) ->
    Fun = fun(_, [{Index1, MapYsPoints}, {Index2, _}]) ->
        PIndex = map_ys_point:get_point_uid_index(),
        case lists:keyfind(PointUid, PIndex, MapYsPoints) of
            false ->
                {ok, ok};
            MapYsPoint ->
                NMapYsPoints = lists:keydelete(PointUid, PIndex, MapYsPoints),
                {ok, {ok, MapYsPoint}, [{Index1, NMapYsPoints}, {Index2, 'delete'}]}
        end
    end,
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'map_ys_point', Sid, []},
        {'point_state', PointUid}
    ]),
    case z_db_lib:handle(TableName, Fun, [], TableKeys) of
        {ok, MapYsPoint} ->
            point_search_db:delete_map_ys_point(Src, PointUid),
            delete_map_ys_timer(Src, PointUid, MapYsPoint);
        _ ->
            ok
    end.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%    袁绍反攻据点创建
%% @end
%% ----------------------------------------------------
corps_create_ys(Src, CorpsUid) ->
    {S, _} = get_map_ys_state(Src),
    case S =:= 1 of
        true ->
            CorpsTown = corps_db:get_corps_town(Src, CorpsUid),
            {_, Per} = zm_config:get('map_ys_point_info', 'corps_town_refresh_ys_per'),
            %%遍历出要刷出据点的城
            {_, MaxNum} = zm_config:get('map_ys_point_info', 'forage_max_ys_num'),
            TownSidLevelList = lists:filter(fun({TSid, _TLevel}) ->
                town_detail:chk_forage(TSid) andalso length(get_map_ys_point(Src, TSid)) < MaxNum
            end, corps_town:get_olist(CorpsTown) ++ corps_town:get_clist(CorpsTown)),
            Num = game_lib:ceil(length(TownSidLevelList) * Per / 10000),
            RefreshTownSidLevelList = game_lib:random_list(TownSidLevelList, Num),
            lists:foreach(fun({TownSid, TLevel}) ->
                corps_create_ys(Src, CorpsUid, TownSid, TLevel)
            end, RefreshTownSidLevelList),
            Now = time_lib:now_second(),
            {_, CreateIntevalSec} = zm_config:get('map_ys_point_info', 'corps_create_inteval'),
            add_corps_create_ys(Src, CorpsUid, Now + CreateIntevalSec);
        false ->
            ok
    end.

%% ----------------------------------------------------
%% @doc
%%    袁绍反攻据点创建
%% @end
%% ----------------------------------------------------
corps_create_ys(Src, _CorpsUid, TSid, TLevel) ->
    TDetail = town_detail:get_cfg(TSid),
    case town_detail:chk_forage(TDetail) of
        true ->
            Now = time_lib:now_second(),
            MapId = point_lib:xyz2mapid(TSid),
            PointUid = town_detail:get_point(TDetail, MapId),
            PointUids = point_lib:get_search_vertex(PointUid, 2),
            {1, [PUid]} = point_db:random_point(Src, tuple_size(PointUids), PointUids, 1, MapId),
            YsPoint = map_ys_point:init(TSid, PUid, Now, TLevel),
            {_, MaxNum} = zm_config:get('map_ys_point_info', 'forage_max_ys_num'),
            Fun = fun(_, [{Index1, 'none'}, {Index2, YsPoints}]) ->
                case length(YsPoints) >= MaxNum of
                    true ->
                        {ok, false};
                    false ->
                        {ok, true, [{Index1, {?MAP_YS_POINT, TSid}}, {Index2, [YsPoint | YsPoints]}]}
                end;
                (_, _) ->
                    {ok, false}
            end,
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [
                {'point_state', PUid, 'none'},
                {'map_ys_point', TSid, []}]),
            Reply = z_db_lib:handle(TableName, Fun, [], TableKeys),
            case Reply of
                true ->
                    add_create_refresh_timer(Src, TSid, PUid, map_ys_point:get_create_refresh_time(YsPoint)),
                    add_marching_timer(Src, TSid, PUid, Now),
                    point_search_db:update_map_ys_point(Src, YsPoint);
                false ->
                    ok
            end,
            Reply;
        false ->
            false
    end.

%% ----------------------------------------------------
%% @doc
%%      下一轮
%% @end
%% ----------------------------------------------------
next_wheel(Src, Sid, PointUid) ->
    Now = time_lib:now_second(),
    Fun = fun(_, MapYsPoints) ->
        PIndex = map_ys_point:get_point_uid_index(),
        case lists:keyfind(PointUid, PIndex, MapYsPoints) of
            false ->
                {ok, ok};
            MapYsPoint ->
                Detail = map_ys_point_detail:get_cfg(map_ys_point:get_level(MapYsPoint)),
                AttackWaveNum = map_ys_point_detail:get_attack_wave_num(Detail),
                Wheel = map_ys_point:get_wheel(MapYsPoint),
                NMapYsPoint1 = map_ys_point:set_attack_wave_number(map_ys_point:set_last_attack_stime(MapYsPoint, Now), AttackWaveNum),
                NMapYsPoint = map_ys_point:set_wheel(map_ys_point:set_wheel_etime(NMapYsPoint1, 0), Wheel + 1),
                NMapYsPoints = lists:keyreplace(PointUid, PIndex, MapYsPoints, NMapYsPoint),
                {ok, {ok, NMapYsPoint}, NMapYsPoints}
        end
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'map_ys_point'), Sid, [], Fun, []) of
        {ok, MapYsPoint} ->
            point_search_db:update_map_ys_point(Src, MapYsPoint),
            add_marching_timer(Src, Sid, PointUid, Now);
        _ ->
            ok
    end.

%% ----------------------------------------------------
%% @doc
%%    袁绍反攻据点出征
%% @end
%% ----------------------------------------------------
wave_marching(Src, Sid, PointUid) ->
    Now = time_lib:now_second(),
    TDetail = town_detail:get_cfg(Sid),
    Town = z_db_lib:get(game_lib:get_table(Src, 'town'), Sid, town:init(TDetail)),
    TownCorpsUid = town:get_corps_uid(Town),
    case TownCorpsUid > 0 of
        true ->
            MapId = point_lib:xyz2mapid(Sid),
            Points = town_detail:get_points(TDetail, MapId),
            Num = erlang:trunc(math:sqrt(tuple_size(Points))),
            PointOwners = town:get_points_owner(Town),
            PointUids =
                lists:filter(fun(PUid) ->
                    case lists:keyfind(PUid, 1, PointOwners) of
                        false ->
                            true;
                        {_, CUid} ->
                            CUid =/= 0
                    end
                end, tuple_to_list(Points)),
            Fun = fun(_, YsPoints) ->
                PIndex = map_ys_point:get_point_uid_index(),
                case lists:keyfind(PointUid, PIndex, YsPoints) of
                    false ->
                        {ok, ok};
                    YsPoint ->
                        AttackWaveNum = map_ys_point:get_attack_wave_number(YsPoint),
                        NAttackWaveNum = max(AttackWaveNum - Num, 0),
                        AddNumber = AttackWaveNum - NAttackWaveNum,
                        case AttackWaveNum > 0 of
                            true ->
                                case NAttackWaveNum =< 0 of
                                    true ->
                                        NYsPoint1 = map_ys_point:set_wheel_etime(map_ys_point:set_last_attack_stime(YsPoint, 0), Now),
                                        NYsPoint = map_ys_point:set_attack_wave_number(NYsPoint1, NAttackWaveNum),
                                        NYsPoints = lists:keyreplace(PointUid, PIndex, YsPoints, NYsPoint),
                                        {ok, {true, AddNumber, NYsPoint, AttackWaveNum}, NYsPoints};
                                    false ->
                                        NYsPoint1 = map_ys_point:set_last_attack_stime(YsPoint, Now),
                                        NYsPoint = map_ys_point:set_attack_wave_number(NYsPoint1, NAttackWaveNum),
                                        NYsPoints = lists:keyreplace(PointUid, PIndex, YsPoints, NYsPoint),
                                        {ok, {false, AddNumber, NYsPoint, AttackWaveNum}, NYsPoints}
                                end;
                            false ->
                                {ok, ok}
                        end
                end
            end,
            case z_db_lib:update(game_lib:get_table(Src, 'map_ys_point'), Sid, [], Fun, []) of
                {Bool, NNum, NYsPoint, AttackWaveNum} ->
                    YsLevel = map_ys_point:get_level(NYsPoint),
                    YsPointDetail = map_ys_point_detail:get_cfg(YsLevel),
                    case Bool of
                        true ->
                            add_next_wheel_timer(Src, Sid, PointUid, Now + map_ys_point_detail:get_wheel_inteval(YsPointDetail));
                        false ->
                            add_marching_timer(Src, Sid, PointUid, Now + map_ys_point_detail:get_wave_inteval(YsPointDetail))
                    end,
                    point_search_db:update_map_ys_point(Src, NYsPoint),
                    NPointUids = game_lib:random_list(PointUids, NNum),
                    MPointUid = map_ys_point:get_point_uid(NYsPoint),
                    {_, Speed} = zm_config:get('map_ys_point_info', 'marching_speed'),
                    Wheel = map_ys_point:get_wheel(NYsPoint),
                    Uid = (point_lib:xyz2view(MPointUid) bsl 16) + (Wheel bsl 8),
                    z_lib:foreach(fun(N, EndPUid) ->
                        Marching = marching:set_state(marching:init(N, YsLevel, MPointUid, EndPUid, Speed, ?MAP_YS_POINT, {?TOWN, Sid}), ?ON_THE_YS_MARCHING),
                        fight_db:add_marching(Src, EndPUid, Marching, [], false),
                        {ok, N - 1}
                    end, Uid + AttackWaveNum, NPointUids);
                _ ->
                    ok
            end;
        false ->
            TLevel = town:get_lv(Town, TDetail),
            YsPointDetail = map_ys_point_detail:get_cfg(TLevel),
            add_marching_timer(Src, Sid, PointUid, Now + map_ys_point_detail:get_wave_inteval(YsPointDetail))
    end.

%% ----------------------------------------------------
%% @doc
%%    袁绍反攻据点刷新
%% @end
%% ----------------------------------------------------
create_refresh(Src, Sid, PointUid) ->
    OYsPoints = get_map_ys_point(Src, Sid),
    {_, MaxNum} = zm_config:get('map_ys_point_info', 'forage_max_ys_num'),
    case length(OYsPoints) < MaxNum of
        true ->
            PIndex = map_ys_point:get_point_uid_index(),
            case lists:keyfind(PointUid, PIndex, OYsPoints) of
                false ->
                    ok;
                OYsPoint ->
                    Now = time_lib:now_second(),
                    Level = map_ys_point:get_level(OYsPoint),
                    TDetail = town_detail:get_cfg(Sid),
                    MapId = point_lib:xyz2mapid(Sid),
                    TownPointUid = town_detail:get_point(TDetail, MapId),
                    RPointUids = point_lib:get_search_vertex(TownPointUid, 2),
                    %%没有找到点直接报错
                    {1, [PUid]} = point_db:random_point(Src, tuple_size(RPointUids), RPointUids, 1, MapId),
                    AddYsPoint = map_ys_point:init(Sid, PUid, Now, Level),
                    CreateRefreshTime = Now + map_ys_point_detail:get_create_refresh_inteval(map_ys_point_detail:get_cfg(Level)),
                    Fun = fun(_, [{Index1, 'none'}, {Index2, YsPoints}]) ->
                        case length(YsPoints) < MaxNum of
                            true ->
                                case lists:keyfind(PointUid, PIndex, YsPoints) of
                                    false ->
                                        {ok, false};
                                    YsPoint ->
                                        NYsPoint = map_ys_point:set_create_refresh_time(YsPoint, CreateRefreshTime),
                                        NYsPoints = lists:keyreplace(PointUid, PIndex, YsPoints, NYsPoint),
                                        {ok, true, [{Index1, {?MAP_YS_POINT, Sid}}, {Index2, [AddYsPoint | NYsPoints]}]}
                                end;
                            false ->
                                ok
                        end
                    end,
                    TableName = game_lib:get_table(Src),
                    TableKeys = z_db_lib:transformation_tablekey(TableName, [
                        {'point_state', PUid, 'none'},
                        {'map_ys_point', Sid, []}]),
                    Reply = z_db_lib:handle(TableName, Fun, [], TableKeys),
                    case Reply of
                        true ->
                            add_create_refresh_timer(Src, Sid, PointUid, CreateRefreshTime),
                            add_create_refresh_timer(Src, Sid, PUid, map_ys_point:get_create_refresh_time(AddYsPoint)),
                            add_marching_timer(Src, Sid, PUid, Now),
                            point_search_db:update_map_ys_point(Src, AddYsPoint);
                        false ->
                            ok
                    end,
                    Reply
            end;
        false ->
            ok
    end.