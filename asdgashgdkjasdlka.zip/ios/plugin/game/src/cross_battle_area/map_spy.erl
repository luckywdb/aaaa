-module(map_spy).

%%%=======================STATEMENT====================
-description("map_spy").
-copyright('youkia,www.youkia.net').
-author("ljh,lvjihong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([spy_init/0, queue_init/0, queue_init/5]).
-export([get_start_time/1, get_need_time/1, get_consumes/1, get_leisure/1, get_num/1, get_queue/1, get_state/1, get_mpoints/1]).
-export([set_start_time/2, set_need_time/2, set_consumes/2, set_leisure/2, set_num/2, set_queue/2, set_state/2, set_mpoints/2]).
-export([update_leisure/2]).

-export([spy_build_init/2]).
-export([get_builds/1, set_builds/2]).
-export([get_build_npc_state/1, set_build_npc_state/2, get_build_etime/1, get_build_point_uid/1, get_build_point_uid_index/0]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(map_ys_queue, {
    state = 0 :: integer(),%%招募状态 0空闲/1招募中
    start_time = 0 :: integer(),%%开始时间
    need_time = 0 :: integer(),%%需要时间
    num = 0 :: integer(),%%招募数量
    consumes = [] :: list()%%消耗
}).
-record(map_spy_build, {
    point_uid = 0 :: integer(),%%坐标点
    etime = 0 :: integer(),%%结束时间
    npc_state = {}%%怪
}).

-record(map_spy, {
    leisure = 0 :: integer(),%当前健康空闲士兵数量
    queue = #map_ys_queue{} :: spy_queue(),%%招募信息
    mpoints = [] :: [integer()],%%当前行军中的侦查点
    builds = [] :: list()%%当前建筑
}).

%%%=======================TYPE=========================
-type spy_queue() :: #map_ys_queue{}.
%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        初始化Spy
%% @end
%% ---------- ------------------------------------------
spy_init() -> #map_spy{}.
%% ----------------------------------------------------
%% @doc
%%        初始化侦察兵招募信息
%% @end
%% ---------- ------------------------------------------
queue_init() -> #map_ys_queue{}.
%% ----------------------------------------------------
%% @doc
%%    初始化
%% @end
%% ----------------------------------------------------
spy_build_init(PointUid, ETime) -> #map_spy_build{point_uid = PointUid, etime = ETime}.
%% ----------------------------------------------------
%% @doc
%%        初始化侦察兵招募信息
%% @end
%% ---------- ------------------------------------------
queue_init(Spy, STime, NTime, Num, Consume) ->
    Spy#map_spy{queue = #map_ys_queue{state = 1, start_time = STime, need_time = NTime, num = Num, consumes = Consume}}.
%% ----------------------------------------------------
%% @doc
%%        获取空闲侦察兵数量
%% @end
%% ---------- ------------------------------------------
get_leisure(#map_spy{leisure = V}) -> V.
%% ----------------------------------------------------
%% @doc
%%       获取招募信息
%% @end
%% ---------- ------------------------------------------
get_queue(#map_spy{queue = V}) -> V.
%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
get_mpoints(#map_spy{mpoints = V}) -> V.
%% ----------------------------------------------------
%% @doc
%%        设置空闲侦察兵数量
%% @end
%% ---------- ------------------------------------------
set_leisure(Spy, V) -> Spy#map_spy{leisure = V}.
%% ----------------------------------------------------
%% @doc
%%        设置招募信息
%% @end
%% ---------- ------------------------------------------
set_queue(Spy, V) -> Spy#map_spy{queue = V}.
%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
set_mpoints(Spy, V) -> Spy#map_spy{mpoints = V}.
%% ----------------------------------------------------
%% @doc
%%        获取开始时间
%% @end
%% ---------- ------------------------------------------
get_start_time(#map_ys_queue{start_time = V}) -> V.
%% ----------------------------------------------------
%% @doc
%%        获取需要时间
%% @end
%% ---------- ------------------------------------------
get_need_time(#map_ys_queue{need_time = V}) -> V.
%% ----------------------------------------------------
%% @doc
%%        获取招募数量
%% @end
%% ---------- ------------------------------------------
get_num(#map_ys_queue{num = V}) -> V.
%% ----------------------------------------------------
%% @doc
%%        获取消耗
%% @end
%% ---------- ------------------------------------------
get_consumes(#map_ys_queue{consumes = V}) -> V.
%% ----------------------------------------------------
%% @doc
%%        获取是否招募中
%% @end
%% ---------- ------------------------------------------
get_state(#map_ys_queue{state = V}) -> V.
%% ----------------------------------------------------
%% @doc
%%        设置开始时间
%% @end
%% ---------- ------------------------------------------
set_start_time(SpyQueue, V) -> SpyQueue#map_ys_queue{start_time = V}.
%% ----------------------------------------------------
%% @doc
%%        设置需要时间
%% @end
%% ---------- ------------------------------------------
set_need_time(SpyQueue, V) -> SpyQueue#map_ys_queue{need_time = V}.
%% ----------------------------------------------------
%% @doc
%%        设置招募数量
%% @end
%% ---------- ------------------------------------------
set_num(SpyQueue, V) -> SpyQueue#map_ys_queue{num = V}.
%% ----------------------------------------------------
%% @doc
%%        设置招募消耗
%% @end
%% ---------- ------------------------------------------
set_consumes(SpyQueue, V) -> SpyQueue#map_ys_queue{consumes = V}.
%% ----------------------------------------------------
%% @doc
%%        设置招募状态
%% @end
%% ---------- ------------------------------------------
set_state(SpyQueue, V) -> SpyQueue#map_ys_queue{state = V}.
%% ----------------------------------------------------
%% @doc
%%        更新空闲侦察兵，V>0，增加；V<0，减少
%% @end
%% ---------- ------------------------------------------
update_leisure(Spy, V) ->
    set_leisure(Spy, get_leisure(Spy) + V).

get_builds(#map_spy{builds = V}) -> V.
set_builds(Spy, V) -> Spy#map_spy{builds = V}.

get_build_point_uid_index() -> #map_spy_build.point_uid.
get_build_point_uid(#map_spy_build{point_uid = V}) -> V.
get_build_etime(#map_spy_build{etime = V}) -> V.
get_build_npc_state(#map_spy_build{npc_state = V}) -> V.
set_build_npc_state(SpyBuild, V) -> SpyBuild#map_spy_build{npc_state = V}.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
