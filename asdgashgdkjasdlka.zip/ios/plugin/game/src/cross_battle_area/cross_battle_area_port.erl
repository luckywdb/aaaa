-module(cross_battle_area_port).

%%%=======================STATEMENT====================
-description("cross_battle_area_port").
-copyright('youkia,www.youkia.net').
-author("shusong,shusong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_cross_battle_rank/5, get_cross_battle_progress/5, get_single_info/5, get_corps_rank_info/5, get_rank_uid_and_team/5]).
-export([transfer_res/5, get_transter_info/5, get_horizon/5]).
%%%=======================INCLUDE======================
-include("../include/cross_battle.hrl").
-include("../include/rank.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%       获取小地图个人军团积分排名信息
%% @end
%% ----------------------------------------------------
get_corps_rank_info([_Type], _, Attr, Info, _Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    RoleCorps = corps_db:get_role_corps(Src, RoleUid),
    case cross_battle_area_db:get_cache_cross_battle_area(Src) of
        'none' ->
            {ok, [], Info, [{msg, "not_open"}]};
        CrossBattleArea ->
            Season = cross_battle_area:get_term(CrossBattleArea),
            Wheel = cross_battle_area:get_wheel(CrossBattleArea),
            CorpsUid = role_corps:get_corps_uid(RoleCorps),
            case cross_battle_area_db:get_battle_corps_info(Src, CorpsUid, Season, Wheel) of
                none ->
                    {ok, [], Info, [{msg, "not_part_in"}]};
                BattleCorpsInfo ->
                    Points = battle_corps_info:get_points(BattleCorpsInfo),
                    Rank = rank_get:get_rank(Src, CorpsUid, ?BATTLE_POINTS_ALL_CORPS_RANK),
                    {ok, [], Info, [{msg, {Points, Rank}}]}
            end
    end.

%% ----------------------------------------------------
%% @doc
%%       获得赛区排行榜信息
%% @end
%% ----------------------------------------------------
get_cross_battle_rank(_A, _, Attr, Info, Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    Type = z_lib:get_value(Msg, "type", 1),
    SRank = z_lib:get_value(Msg, "start_rank", 1),
    ERank = z_lib:get_value(Msg, "end_rank", 100),
    Season = z_lib:get_value(Msg, "season", 0),%%所取赛季
    Wheel = z_lib:get_value(Msg, "wheel", 0),%%所取轮次
    SelectType = z_lib:get_value(Msg, "select_type", 0),%%筛选类型，1未只显示军团
    {RankUid, Team, CorpsUid} = get_rank_uid_and_team(Src, RoleUid, Type, Season, Wheel),
    Rankers = if
        SelectType =:= 1 ->
            rank_get:get_rank_by_season(Src, Type, Season, Wheel, Team, SRank, ERank, {'same_corps_uid', CorpsUid});
        true ->
            rank_get:get_rank_by_season(Src, Type, Season, Wheel, Team, SRank, ERank, 'none')
    end,
    SelfRank = rank_get:get_rank(Src, RankUid, Type),
    {ok, [], Info, [{msg, {SelfRank, list_to_tuple(Rankers)}}]}.

%% ----------------------------------------------------
%% @doc
%%       获得军团战况信息
%% @end
%% ----------------------------------------------------
get_cross_battle_progress(_A, _, Attr, Info, Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    Season = z_lib:get_value(Msg, "season", 0),%%所取赛季
    Wheel = z_lib:get_value(Msg, "wheel", 0),%%所取轮次
    Type = z_lib:get_value(Msg, "type", 0),%%显示类型：1为城池，2为粮仓
    Bl = cross_battle_area_lib:is_running(Src, Season, Wheel),
    if
        Bl ->
            %%当前赛季，直接corps_town中获取
            RoleCorps = corps_db:get_role_corps(Src, RoleUid),
            CorpsTown = corps_db:get_corps_town(Src, role_corps:get_corps_uid(RoleCorps)),
            Reply = if
                Type =:= 1 ->
                    corps_town:get_cross_townsid(CorpsTown);
                true ->
                    corps_town:get_barns_sid(CorpsTown)
            end,
            {ok, [], Info, [{msg, list_to_tuple(Reply)}]};
        true ->
            RoleCorps = corps_db:get_role_corps(Src, RoleUid),
            CorpsUid = role_corps:get_corps_uid(RoleCorps),
            case cross_battle_area_db:get_battle_corps_info(Src, CorpsUid, Season, Wheel) of
                'none' ->
                    {ok, [], Info, [{msg, "not_part_in"}]};
                BattleCorpsInfo ->
                    Reply = if
                        Type =:= 1 ->
                            battle_corps_info:get_town_list(BattleCorpsInfo);
                        true ->
                            battle_corps_info:get_barn(BattleCorpsInfo)
                    end,
                    {ok, [], Info, [{msg, list_to_tuple(Reply)}]}
            end
    end.
%% ----------------------------------------------------
%% @doc
%%       获得指定玩家/军团单个赛季每轮积分
%% @end
%% ----------------------------------------------------
get_single_info(_A, _, _Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    Season = z_lib:get_value(Msg, "season", 0),%%所取赛季
    Type = z_lib:get_value(Msg, "type", 1),%%信息类型：1为军团信息，2为个人信息
    Uid = list_to_integer(z_lib:get_value(Msg, "uid", "0")),
    FormatFun = fun(Wheel, 1) ->%%军团
        case cross_battle_area_db:get_battle_corps_info(Src, Uid, Season, Wheel) of
            'none' ->%%该轮次没数据
                {0};
            BattleCorpsInfo ->
                {battle_corps_info:get_points(BattleCorpsInfo)}
        end;
        (Wheel, _) ->%%个人
            case cross_battle_area_db:get_battle_role_info(Src, Uid, Season, Wheel) of
                'none' ->%%该轮次没数据
                    {0};
                BattleRoleInfo ->
                    {battle_role_info:get_points(BattleRoleInfo)}
            end
    end,
    Reply = [FormatFun(Wheel, Type) || Wheel <- ?CROSS_BATTLE_ALL_WHEEL],
    {ok, [], Info, [{msg, list_to_tuple(Reply)}]}.
%%    {ok, [], Info, [{msg, {{123}, {456}, {789}}}]}.

%% ----------------------------------------------------
%% @doc
%%      获取划拨信息
%% @end
%% ----------------------------------------------------
get_transter_info(_, _, Attr, Info, _Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    CenterSrc = game_lib:get_center_src(),
    case cross_server_msg:send_call(CenterSrc, "cb_area", RoleUid, {'cross_battle_role_rpc', 'get_transfer_info', RoleUid}) of
        {ok, Rmb, PropSidCounts} ->
            {ok, [], Info, [{msg, {Rmb, list_to_tuple(PropSidCounts)}}]};
        _ ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.
%% ----------------------------------------------------
%% @doc
%%      划拨资源
%% @end
%% ----------------------------------------------------
transfer_res(_, _, Attr, Info, Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    List = [list_to_integer(Str) || Str <- string:tokens(z_lib:get_value(Msg, "str", Msg), ",")],
    {_, GoodsSids} = zm_config:get('cross_battle_info', 'transfer_goods_sids'),
    case check_transfer_res(GoodsSids, [], List) of
        {ok, AwardList} ->
            CenterSrc = game_lib:get_center_src(),
            R = cross_server_msg:send_call(CenterSrc, "cb_area", RoleUid,
                {'cross_battle_role_rpc', 'transfer_consume_res', {RoleUid, AwardList}}),
            case R of
                ok ->
                    AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, AwardList),
                    zm_log:info(Src, ?MODULE, 'transfer_res', "transfer_res", [{'role_uid', RoleUid}, {'award_list', AwardList},
                        {'award', AwardLog}]),
                    zm_event:notify(Src, 'bi_cb_transfer_award', [{'role_uid', RoleUid}, {'award', AwardLog}]),
                    {ok, [], Info, [{msg, "ok"}]};
                Err ->
                    {ok, [], Info, [{msg, Err}]}
            end;
        Err ->
            {ok, [], Info, [{msg, Err}]}
    end.
%% ----------------------------------------------------
%% @doc
%%     获取军团所有视野半径点
%% @end
%% ----------------------------------------------------
get_horizon(_, _, Attr, Info, _Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    CorpsUid = role_show:get_corps_uid(role_db:get_role_show(Src, RoleUid)),
    Horizons = [{point_lib:xyz2view(Puid), Vertex} || {Puid, Vertex} <- point_horizon:get_horizon(Src, CorpsUid)],
    {ok, [], Info, [{msg, list_to_tuple(Horizons)}]}.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%      检测划拨参数
%% @end
%% ----------------------------------------------------
check_transfer_res(TGoodsSids, Acc, [Sid, Num | Tails]) ->
    case Sid =:= 0 orelse lists:member(Sid, TGoodsSids) of
        true ->
            check_transfer_res(TGoodsSids, times_set_lib:update(Acc, {Sid, Num}), Tails);
        false ->
            "input_error"
    end;
check_transfer_res(_, _Acc, [_]) ->
    "input_error";
check_transfer_res(_, Acc, []) ->
    NAcc = lists:map(fun({Sid, Num}) ->
        case Sid =:= 0 of
            true ->
                {'rmb', Num};
            false ->
                {'prop', {Sid, Num}}
        end
    end, Acc),
    {ok, NAcc}.
%% ----------------------------------------------------
%% @doc
%%       获得排行榜uid以及分组
%% @end
%% ----------------------------------------------------
get_rank_uid_and_team(Src, RoleUid, RankType, Season, Wheel) ->
    Bl = cross_battle_area_lib:is_running(Src, Season, Wheel),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    CorpsUid = role_show:get_corps_uid(RoleShow),
    NewType = rank_lib:get_type(RankType),
    if
        NewType =:= ?BATTLE_POINTS_ALL_ROLE_RANK orelse NewType =:= ?BATTLE_FEATS_ALL_ROLE_RANK orelse NewType =:= ?BATTLE_TOWN_ALL_ROLE_RANK ->
            if
                Bl ->
                    case cross_battle_area_db:get_battle_role_info(Src, RoleUid, Season, Wheel) of
                        'none' ->
                            {RoleUid, 0, CorpsUid};
                        BattleRoleInfo ->
                            {RoleUid, battle_role_info:get_team(BattleRoleInfo), CorpsUid}
                    end;
                true ->
                    {RoleUid, cross_battle_area_db:get_battle_role_his_team(Src, RoleUid, Season, Wheel), CorpsUid}
            end;
        true ->
            if
                Bl ->
                    case cross_battle_area_db:get_battle_corps_info(Src, CorpsUid, Season, Wheel) of
                        'none' ->
                            {CorpsUid, 0, CorpsUid};
                        BattleCorpsInfo ->
                            {CorpsUid, battle_corps_info:get_team(BattleCorpsInfo), CorpsUid}
                    end;
                true ->
                    {CorpsUid, cross_battle_area_db:get_battle_corps_his_team(Src, CorpsUid, Season, Wheel), CorpsUid}
            end
    end.