-module(map_spy_lib).

%%%=======================STATEMENT====================
-description("cross_battle_spy_lib").
-copyright('youkia,www.youkia.net').
-author("ljh,lvjihong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([check/3, consume/3]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        
%% @end
%% ----------------------------------------------------
check({_Role, Rmb}, 'spy_recruit', {'rmb', NeedRmb}) ->
    rmb_lib:get_rmb(Rmb) >= NeedRmb;
check({Role, _Rmb}, 'spy_recruit', {'cb_forage', V}) ->
    role:get_cb_forage(Role) >= V;
check(_, _, _) ->
    false.

%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
consume({Role, Rmb}, 'spy_recruit', {'rmb', NeedRmb}) ->
    {Cs, NRmb} = rmb_lib:reduct_rmb(Rmb, NeedRmb),
    {Cs, {Role, NRmb}};
consume({Role, Rmb}, 'spy_recruit', {'cb_forage', Value}) ->
    {Cs, Role1} = role_lib:deduct_cb_forage(Role, Value),
    {Cs, {Role1, Rmb}}.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
