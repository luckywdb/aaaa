-module(cross_battle_area_db).

%%%=======================STATEMENT====================
-description("cross_battle_db").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_cross_battle_area_st/3]).
-export([get_cross_battle_area/2, update_cross_battle_area/3]).
-export([check_login_cross_battle_server/2]).
-export([get_cross_battle_area_wtime/2, update_cross_battle_area_wtime/3]).
-export([get_battle_role_info/4, get_battle_corps_info/4, get_battle_corps_his_team/4, get_battle_role_his_team/4]).
-export([update_battle_role_info/5, update_battle_corps_info/5, update_battle_role_his_team_info/5, update_battle_corps_his_team_info/5]).
-export([clear_data/2, clear_rank/3, clear_his_info/2]).
-export([get_cross_battle_corps_map/2]).
-export([get_cross_battle_corps_by_mapid/2]).
-export([check_cross_is_open/4]).
-export([update_cache_cross_battle_area/1, get_cache_cross_battle_area/1]).
%%%=======================INCLUDE======================
-include("../include/cross_battle.hrl").
%%%=======================DEFINE======================
-define(AREA_CROSS_BATTLE_TABLE, 'area_cross_battle_table').
%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        获取
%% @end
%% ----------------------------------------------------
get_cross_battle_area(Src, CrossType) ->
    z_db_lib:get(game_lib:get_table(Src, 'cross_battle_area'), {'cross_battle_area', CrossType}, 'none').
%% ----------------------------------------------------
%% @doc
%%      更新
%% @end
%% ----------------------------------------------------
update_cross_battle_area(Src, CrossType, CrossBattleArea) ->
    z_db_lib:update(game_lib:get_table(Src, 'cross_battle_area'), {'cross_battle_area', CrossType}, CrossBattleArea).

%% ----------------------------------------------------
%% @doc
%%      获取军团地图和组
%% @end
%% ----------------------------------------------------
get_cross_battle_corps_map(Src, CorpsUid) ->
    case args_system:is_game_center_server(Src) of
        true ->
            case zm_config:get(?AREA_CROSS_BATTLE_TABLE, CorpsUid) of
                'none' ->
                    case z_db_lib:get(game_lib:get_table(Src, 'cross_battle_corps_map'), CorpsUid, 'none') of
                        'none' ->
                            'none';
                        V ->
                            zm_config:set(?AREA_CROSS_BATTLE_TABLE, {CorpsUid, V}),
                            V
                    end;
                {_, V} ->
                    V
            end;
        false ->
            0
    end.

%% ----------------------------------------------------
%% @doc
%%      获取地图id中的军团
%% @end
%% ----------------------------------------------------
get_cross_battle_corps_by_mapid(Src, MapId) ->
    case zm_config:get(?AREA_CROSS_BATTLE_TABLE, MapId) of
        'none' ->
            case z_db_lib:get(game_lib:get_table(Src, 'cross_battle_corps_map'), MapId, 'none') of
                'none' ->
                    [];
                V ->
                    zm_config:set(?AREA_CROSS_BATTLE_TABLE, {MapId, V}),
                    V
            end;
        {_, V} ->
            V
    end.
%% ----------------------------------------------------
%% @doc
%%      是否能登录
%% @end
%% ----------------------------------------------------
check_login_cross_battle_server(Src, RoleUid) ->
    case args_system:is_game_center_server(Src) of
        true ->
            CrossType = "cb_area",
            case cross_battle_area_db:get_cross_battle_area(Src, CrossType) of
                'none' ->
                    false;
                CrossBattleArea ->
                    case cross_battle_area:get_state(CrossBattleArea) =:= ?CROSS_SERVER_STATE_OPEN of
                        true ->
                            case role_db:get_role_show(Src, RoleUid) of
                                'none' ->
                                    false;
                                RoleShow ->
                                    CorpsUid = role_show:get_corps_uid(RoleShow),
                                    case lists:member(CorpsUid, cross_battle_area:get_corps_uids(CrossBattleArea)) of
                                        true ->
                                            MapId = point_lib:xyz2mapid(role_show:get_point(RoleShow)),
                                            {true, MapId};
                                        false ->
                                            false
                                    end
                            end;
                        false ->
                            false
                    end
            end;
        false ->
            {true, 0}
    end.


%% ----------------------------------------------------
%% @doc
%%      获取状态
%% @end
%% ----------------------------------------------------
get_cross_battle_area_st(Src, CorpsUid, CrossType) ->
    case get_cross_battle_area(Src, CrossType) of
        'none' ->
            {?CROSS_SERVER_STATE_CLOSS, 0, {}};
        CrossBattleArea ->
            State = cross_battle_area:get_state(CrossBattleArea),
            Wheel = cross_battle_area:get_wheel(CrossBattleArea),
            WheelStateTime = cross_battle_area:get_wheel_state_time(CrossBattleArea),
            Bool =
                if
                    State =:= ?CROSS_SERVER_STATE_CLOSS ->
                        false;
                    State =:= ?CROSS_SERVER_STATE_SYNC_GROUP ->
                        false;
                    State =:= ?CROSS_SERVER_STATE_STOP orelse State =:= ?CROSS_SERVER_STATE_CLEAR_COMPLETE ->
                        Wheel =/= tuple_size(WheelStateTime);
                    true ->
                        true
                end,
            Term = cross_battle_area:get_term(CrossBattleArea),
            case Bool of
                true ->
                    {_MapId, N} = cross_battle_area_db:get_cross_battle_corps_map(Src, CorpsUid),
                    StartTime = cross_battle_area:get_start_time(CrossBattleArea),
                    ContinueTime = cross_battle_area:get_continue_time(CrossBattleArea),
                    WheelTime = get_area_st_wheel_time(StartTime, 1, Wheel, tuple_to_list(WheelStateTime), []),
%%                    WheelTime = list_to_tuple(lists:reverse(element(2, z_lib:foreach(fun({STime, Acc}, {T1, T2, _, T3, T4, T5}) ->
%%                        STime1 = STime + T1 + T2,
%%                        STime2 = STime1 + T3 + T4 + T5,
%%                        {ok, {STime2, [{STime1, T3} | Acc]}}
%%                    end, {StartTime, []}, tuple_to_list(WheelStateTime))))),
                    MapYsState =
                        case State =:= ?CROSS_SERVER_STATE_OPEN of
                            true ->
                                map_ys_point_db:get_map_ys_state(Src);
                            false ->
                                {0, 0}
                        end,
                    {State, Term, Wheel, WheelTime, StartTime, ContinueTime, 1, N, MapYsState};
                false ->
                    {?CROSS_SERVER_STATE_CLOSS, Term, {}}
            end
    end.


%% ----------------------------------------------------
%% @doc
%%        赛季各轮开始点
%% @end
%% ----------------------------------------------------
get_cross_battle_area_wtime(Src, Term) ->
    z_db_lib:get(game_lib:get_table(Src, 'cross_battle_area_wtime'), Term, 'none').

%% ----------------------------------------------------
%% @doc
%%      赛季各轮开始点
%% @end
%% ----------------------------------------------------
update_cross_battle_area_wtime(Src, Term, WheelTime) ->
    z_db_lib:update(game_lib:get_table(Src, 'cross_battle_area_wtime'), Term, WheelTime).

%% ----------------------------------------------------
%% @doc
%%        获取玩家跨服个人数据
%% @end
%% ----------------------------------------------------
get_battle_role_info(Src, RoleUid, Season, Wheel) ->
    z_db_lib:get(game_lib:get_table(Src, 'battle_role_info'), {RoleUid, Season, Wheel}, none).
%% ----------------------------------------------------
%% @doc
%%        更新玩家跨服个人数据
%% @end
%% ----------------------------------------------------
update_battle_role_info(Src, RoleUid, Season, Wheel, BattleRoleInfo) ->
    z_db_lib:update(game_lib:get_table(Src, 'battle_role_info'), {RoleUid, Season, Wheel}, BattleRoleInfo).

%% ----------------------------------------------------
%% @doc
%%        获得玩家跨服公会数据
%% @end
%% ----------------------------------------------------
get_battle_corps_info(Src, CorpsUid, Season, Wheel) ->
    z_db_lib:get(game_lib:get_table(Src, 'battle_corps_info'), {CorpsUid, Season, Wheel}, none).
%% ----------------------------------------------------
%% @doc
%%        更新玩家跨服公会数据
%% @end
%% ----------------------------------------------------
update_battle_corps_info(Src, CorpsUid, Season, Wheel, BattleCorpsInfo) ->
    z_db_lib:update(game_lib:get_table(Src, 'battle_corps_info'), {CorpsUid, Season, Wheel}, BattleCorpsInfo).
%% ----------------------------------------------------
%% @doc
%%        获得玩家历史赛季分组
%% @end
%% ----------------------------------------------------
get_battle_role_his_team(Src, RoleUid, Season, Wheel) ->
    TeamInfo = z_db_lib:get(game_lib:get_table(Src, 'battle_role_team_info'), RoleUid, []),
    case lists:keyfind({Season, Wheel}, 1, TeamInfo) of
        {_, Team} ->
            Team;
        _ ->
            0
    end.
%% ----------------------------------------------------
%% @doc
%%        设置玩家历史赛季分组
%% @end
%% ----------------------------------------------------
update_battle_role_his_team_info(Src, RoleUid, Season, Wheel, Team) ->
    Fun = fun(_, TeamInfo) ->
        {ok, ok, lists:keystore({Season, Wheel}, 1, TeamInfo, {{Season, Wheel}, Team})}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'battle_role_team_info'), RoleUid, [], Fun, []).
%% ----------------------------------------------------
%% @doc
%%        获得军团历史赛季分组
%% @end
%% ----------------------------------------------------
get_battle_corps_his_team(Src, CorpsUid, Season, Wheel) ->
    TeamInfo = z_db_lib:get(game_lib:get_table(Src, 'battle_corps_team_info'), CorpsUid, []),
    case lists:keyfind({Season, Wheel}, 1, TeamInfo) of
        {_, Team} ->
            Team;
        _ ->
            0
    end.
%% ----------------------------------------------------
%% @doc
%%        设置军团历史赛季分组
%% @end
%% ----------------------------------------------------
update_battle_corps_his_team_info(Src, CorpsUid, Season, Wheel, Team) ->
    Fun = fun(_, TeamInfo) ->
        {ok, ok, lists:keystore({Season, Wheel}, 1, TeamInfo, {{Season, Wheel}, Team})}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'battle_corps_team_info'), CorpsUid, [], Fun, []).

%% ----------------------------------------------------
%% @doc
%%      清理所有数据
%% @end
%% ----------------------------------------------------
clear_data(GameSrc, CrossBattleArea) ->
    %%清理排行榜数据
    MapIds = cross_battle_area:get_mapids(CrossBattleArea),
    CenterWheel = cross_battle_area:get_wheel(CrossBattleArea),
    {_, CrossBattleWheelStateTime} = zm_config:get('center_cross_battle_info', 'cross_battle_wheel'),
    %%清除排行榜信息
    {_, RankClearList} = zm_config:get('center_cross_battle_info', 'clear_rank'),
    {M, F, A} = if
        CenterWheel >= size(CrossBattleWheelStateTime) ->
            z_lib:get_value(RankClearList, 'battle_over', []);
        true ->
            z_lib:get_value(RankClearList, 'wheel_over', [])
    end,
    M:F(A, GameSrc, MapIds),

    lists:foreach(fun(MapId) ->
        point_db:clear_map_allinfo(GameSrc, MapId)
    end, cross_battle_area:get_mapids(CrossBattleArea)),

    %%地图相关清理表
    ClearMapTables = [
        point_state,
        monster,
        monster_dead,
        monster_refresh,
        point_search,
        point_search_big,
        point_search_fight,
        point_search_fight_big,
        point_see,
        collect_point,
        town,
        monster_check,
        boss_data,
        monster_num,
        point_move_cd,
        town_event,
        town_first,
        cycle_town,
        corps_town,
        point_march,
        point_march_tmp,
        fight_award_log,
        horizon,
        point_search_horizon,
        res,
        role_res,
        map_build,
        map_build_destroy,
        map_build_fight,
        corps_log,
        corps_show
    ],
    lists:foreach(fun(Table) ->
        z_db_lib:clear(game_lib:get_table(GameSrc, Table))
    end, ClearMapTables),

    %游戏相关清理
    GameTableList = [
        'psu_uid', 'uid_psu',
        'role', 'user', 'castle', 'rmb', 'role_restore',
        'corps', 'corps_member', 'role_corps', 'corps_log', 'corps_mb_level',
        'role_show', 'skin',
        'role_official', 'country_official',
        'garray', 'garrison',
        'goods', 'card', 'equipment', 'treasure',
        'card_put_prop', 'card_fetter', 'card_put_treasure',
        'map_ys_point', 'map_ys_timer', 'map_ys_state',
        'role_buff', 'country_buff',
        'map_spy', 'map_spy_timer',
        'report', 'report_detail', 'mailbox', 'corps_mail', 'corps_mail_role_index',
        'queue', 'study', 'barracks', 'political',
        'cross_battle_area_sync', 'cross_battle_corps_map', 'cross_battle_area_points_award',
        'shop', 'shop_temp', 'times_set',
        'rank_update', 'power_update'
    ],
    lists:foreach(fun(Table) ->
        z_db_lib:clear(game_lib:get_table(GameSrc, Table))
    end, GameTableList),
    zm_config:delete(?AREA_CROSS_BATTLE_TABLE),
    %%清除聊天
    chat_server:stop('cross'),
    chat_server:stop('corps'),
    StartTime = cross_battle_area:get_start_time(CrossBattleArea),
    ContinueTime = cross_battle_area:get_continue_time(CrossBattleArea),
    NCrossBattleArea = cross_battle_area:update_state(CrossBattleArea, ?CROSS_SERVER_STATE_CLEAR_COMPLETE, StartTime, ContinueTime),
    cross_battle_area_db:update_cross_battle_area(GameSrc, "cb_area", NCrossBattleArea),
    %%清除积分奖励发放信息
    cross_battle_area_event:clear_patrol_timer(GameSrc),

    %%清除历史信息
    {_, MaxSaveSeason} = zm_config:get('center_cross_battle_info', 'max_save_season'),
    clear_his_info(GameSrc, cross_battle_area:get_term(CrossBattleArea) - MaxSaveSeason),

    zm_event:notify(GameSrc, 'cross_battle_area_state_change', [{'state', ?CROSS_SERVER_STATE_CLEAR},
        {'nstate', ?CROSS_SERVER_STATE_CLEAR_COMPLETE}, {'cross_battle_area', NCrossBattleArea}]).
%% ----------------------------------------------------
%% @doc
%%      清理排行榜
%% @end
%% ----------------------------------------------------
clear_rank(RankTypes, Src, MapIds) ->
    Fun = fun(RankType, _) ->
        NewRankType = rank_lib:get_type(RankType),
        if
            NewRankType =:= RankType ->
                rank_db:clear_season_rank(Src, 0, RankType);
            true ->
                lists:foreach(fun(MapId) -> rank_db:clear_season_rank(Src, MapId, RankType) end, MapIds)
        end
    end,
    lists:foldl(Fun, [], RankTypes).
%% ----------------------------------------------------
%% @doc
%%      清理历史信息
%% @end
%% ----------------------------------------------------
clear_his_info(_Src, DelSeason) when DelSeason =< 0 ->
    ok;
clear_his_info(Src, DelSeason) ->
    SeasonRankTable = game_lib:get_table(Src, 'season_rank'),
    BattleRoleTable = game_lib:get_table(Src, 'battle_role_info'),
    BattleCorpsTable = game_lib:get_table(Src, 'battle_corps_info'),
    BattleRoleTeamTable = game_lib:get_table(Src, 'battle_role_team_info'),
    BattleCorpsTeamTable = game_lib:get_table(Src, 'battle_corps_team_info'),
    %%键值包含赛季的删除方法
    DelFun1 = fun(_, {_, Season, _} = Key, Table, _) when Season =< DelSeason ->
        z_db_lib:delete(Table, Key);
        (_, _, _, _) ->
            ok
    end,
    TeamDelFun = fun(_, TeamInfo) ->
        [{{Season, Wheel}, Team} || {{Season, Wheel}, Team} <- TeamInfo, Season > DelSeason]
    end,
    DelFun2 = fun(_, Key, Table, _) ->
        z_db_lib:update(Table, Key, [], TeamDelFun, [])
    end,
    z_db_lib:table_iterate(Src, SeasonRankTable, DelFun1, SeasonRankTable, []),
    z_db_lib:table_iterate(Src, BattleRoleTable, DelFun1, BattleRoleTable, []),
    z_db_lib:table_iterate(Src, BattleCorpsTable, DelFun1, BattleCorpsTable, []),
    z_db_lib:table_iterate(Src, BattleRoleTeamTable, DelFun2, BattleRoleTeamTable, []),
    z_db_lib:table_iterate(Src, BattleCorpsTeamTable, DelFun2, BattleCorpsTeamTable, []).

%% ----------------------------------------------------
%% @doc
%%      检查是否需要获取跨服的袭击信息
%% @end
%% ----------------------------------------------------
check_cross_is_open(Src, RoleUid, MapId, ActionType) ->
    case MapId > 0 of
        true ->
            case cross_battle_area_db:get_cross_battle_area(Src, ActionType) of
                'none' ->
                    false;
                CrossBattleArea ->
                    cross_battle_area:get_state(CrossBattleArea) =:= ?CROSS_SERVER_STATE_OPEN
            end;
        false ->
            case cross_battle_db:get_cross_battle_server(Src, ActionType) of
                'none' ->
                    false;
                CrossBattleArea ->
                    RoleShow = role_db:get_role_show(Src, RoleUid),
                    CorpsUid = role_show:get_corps_uid(RoleShow),
                    case lists:member(CorpsUid, cross_battle_server:get_corps_uids(CrossBattleArea)) of
                        true ->
                            cross_battle_server:get_state(CrossBattleArea) =:= ?CROSS_SERVER_STATE_OPEN;
                        false ->
                            false
                    end
            end
    end.

%% ----------------------------------------------------
%% @doc
%%    更新area cache
%% @end
%% ----------------------------------------------------
update_cache_cross_battle_area(CrossBattleArea) ->
    zm_config:set(?AREA_CROSS_BATTLE_TABLE, {'cross_battle_area', CrossBattleArea}).

%% ----------------------------------------------------
%% @doc
%%      获取当前轮状态和开始时间
%% @end
%% ----------------------------------------------------
get_cache_cross_battle_area(Src) ->
    case zm_config:get(?AREA_CROSS_BATTLE_TABLE, 'cross_battle_area') of
        'none' ->
            CrossBattleArea = get_cross_battle_area(Src, "cb_area"),
            update_cache_cross_battle_area(CrossBattleArea),
            CrossBattleArea;
        {_, V} ->
            V
    end.

%%%===================LOCAL FUNCTIONS==================
%%计算赛区中控的每轮开启时间
get_area_st_wheel_time(StartTime, Wheel, CenterWheel, [WheelTimeTuple | WheelTimeTuples], R) ->
    get_area_st_wheel_time(StartTime, Wheel + 1, CenterWheel, WheelTimeTuples, get_area_st_wheel_time_(StartTime, Wheel, CenterWheel, WheelTimeTuple, R));
get_area_st_wheel_time(_, _, _, [], R) ->
    list_to_tuple(lists:reverse(R)).
get_area_st_wheel_time_(StartTime, Wheel, CenterWheel, {T1, T2, _, T3, T4, T5}, R) ->
    %%{T1, T2, _, T3, T4, T5} {准备时间, 同步数据时间,同步完成, 持续时间, 休息时间, 清理时间}
    [{StartTime + (T1 + T2 + T3 + T4 + T5) * (Wheel - CenterWheel), T3} | R].