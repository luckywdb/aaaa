-module(cross_battle_area_rank).

%%%=======================STATEMENT====================
-description("cross_battle_area_rank").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([init_rank/6]).
-export([rank_save/6, corps_town_save/5]).
-export([battle_role_team_save/5, battle_corps_team_save/5]).

%%%=======================INCLUDE======================
-include("../include/rank.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
init_rank(GameSrc, Corps, OwnerRoleName, MapId, Term, Wheel) ->
    CorpsUid = corps:get_uid(Corps),
    CenterSrc = game_lib:get_center_src(),
    ServerName = identity_manager:get_servername(CenterSrc, CorpsUid),
    BattleCorpsInfo = battle_corps_info:init(Corps, Term, Wheel, MapId, ServerName, OwnerRoleName),
    %%排行榜初始化
    HisPoints = cross_battle_area_lib:get_his_rank_value(GameSrc, CorpsUid, ?BATTLE_POINTS_ALL_CORPS_RANK),
    HisKillEnemy = cross_battle_area_lib:get_his_rank_value(GameSrc, CorpsUid, ?BATTLE_FEATS_ALL_CORPS_RANK),
    HisTownPoint = cross_battle_area_lib:get_his_rank_value(GameSrc, CorpsUid, ?BATTLE_TOWN_ALL_CORPS_RANK),
    NewBattleCorpsInfo = battle_corps_info:update_his(BattleCorpsInfo, HisPoints, HisKillEnemy, HisTownPoint),
    ServerDesc = server_address_db:get_sname(CenterSrc, CorpsUid),
    cross_battle_area_db:update_battle_corps_info(GameSrc, CorpsUid, Term, Wheel, battle_corps_info:set_server_desc(NewBattleCorpsInfo, ServerDesc)).
%% ----------------------------------------------------
%% @doc
%%		存排行榜
%% @end
%% ----------------------------------------------------
rank_save([Num], Src, Type, Season, Wheel, MapIds) ->
    rank_db:season_rank_save_history(Src, Type, Season, Wheel, MapIds, Num).
%% ----------------------------------------------------
%% @doc
%%		存军团占领情况
%% @end
%% ----------------------------------------------------
corps_town_save(_A, Src, Season, Wheel, _MapIds) ->
    Table = game_lib:get_table(Src, 'corps_town'),
    BattleCorpsTable = game_lib:get_table(Src, 'battle_corps_info'),
    Fun = fun(_Src, Key, _Args, _R) ->
        CorpsTown = z_db_lib:get(Table, Key),
        z_db_lib:update(BattleCorpsTable, {Key, Season, Wheel}, 'none', fun(_, 'none') ->
            ok;
            (_, BattleCorpsInfo) ->
                {ok, ok, battle_corps_info:set_town_list(battle_corps_info:set_barn(BattleCorpsInfo, corps_town:get_barns_sid(CorpsTown)), corps_town:get_cross_townsid(CorpsTown))}
        end, 'none')
    end,
    z_db_lib:table_iterate(Src, Table, Fun, [], []).

%% ----------------------------------------------------
%% @doc
%%		存个人分组新信息
%% @end
%% ----------------------------------------------------
battle_role_team_save(_A, Src, Season, Wheel, _MapIds) ->
    Table = game_lib:get_table(Src, 'battle_role_info'),
    Fun = fun(Src_, {Uid, _, _} = Key, _, R) ->
        BattleRoleInfo = z_db_lib:get(Table, Key),
        Team = battle_role_info:get_team(BattleRoleInfo),
        cross_battle_area_db:update_battle_role_his_team_info(Src_, Uid, Season, Wheel, Team),
        R
    end,
    z_db_lib:table_iterate(Src, Table, Fun, [], []).
%% ----------------------------------------------------
%% @doc
%%		存军团分组新信息
%% @end
%% ----------------------------------------------------
battle_corps_team_save(_A, Src, Season, Wheel, _MapIds) ->
    Table = game_lib:get_table(Src, 'battle_corps_info'),
    Fun = fun(Src_, {Uid, _, _} = Key, _, R) ->
        BattleCorpsInfo = z_db_lib:get(Table, Key),
        Team = battle_corps_info:get_team(BattleCorpsInfo),
        cross_battle_area_db:update_battle_corps_his_team_info(Src_, Uid, Season, Wheel, Team),
        R
    end,
    z_db_lib:table_iterate(Src, Table, Fun, [], []).
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
