%%袁绍据点
-module(map_ys_point_detail).

%%%=======================STATEMENT====================
-description("map_ys_point_detail").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    get_cfg/1,
    get_level/1,
    get_max_bvalue/1,
    get_bvalue_respeed/1,
    get_attack_npc_garray/1,
    get_defense_npc_garray/1,
    get_max_defense_num/1,
    get_attack_wave_num/1,
    get_wheel_inteval/1,
    get_wave_inteval/1,
    get_create_refresh_inteval/1
]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(map_ys_point_detail, {
    level :: integer(),%%据点等级
    max_bvalue :: integer(),%%最大建筑值
    bvalue_respeed :: integer(),%%建筑值恢复速度 1小时
    attack_npc_garray :: [integer()],%%攻击npc
    defense_npc_garray :: [integer()],%%防守
    max_defense_num :: integer(),%%最大守军数量
    attack_wave_num :: integer(),%%每波攻击数量
    wheel_inteval :: integer(),%%每轮间隔
    wave_inteval :: integer(),%%每波间隔
    create_refresh_inteval :: integer()%%刷新下一个间隔
}).

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        
%% @end
%% ----------------------------------------------------
get_cfg(Level) -> zm_config:get('map_ys_point', Level).
get_level(#map_ys_point_detail{level = V}) -> V.
get_max_bvalue(#map_ys_point_detail{max_bvalue = V}) -> V.
get_bvalue_respeed(#map_ys_point_detail{bvalue_respeed = V}) -> V.
get_attack_npc_garray(#map_ys_point_detail{attack_npc_garray = V}) -> V.
get_defense_npc_garray(#map_ys_point_detail{defense_npc_garray = V}) -> V.
get_max_defense_num(#map_ys_point_detail{max_defense_num = V}) -> V.
get_attack_wave_num(#map_ys_point_detail{attack_wave_num = V}) -> V.
get_wheel_inteval(#map_ys_point_detail{wheel_inteval = V}) -> V.
get_wave_inteval(#map_ys_point_detail{wave_inteval = V}) -> V.
get_create_refresh_inteval(#map_ys_point_detail{create_refresh_inteval = V}) -> V.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
