%%全服基金数据库操作
-module(funds_db).

%%%=======================STATEMENT====================
-description("funds_db").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_role_funds/2, buy_funds/3, funds_award/3, get_full_info/2, get_funds_info/1]).

%%%=======================INCLUDE======================

%%%=======================RECORD=======================

%%%=======================DEFINE=======================
-define(DAYTIME, 86400).
-define(DAYNUM, 7).
%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% Func: get_role_funds/2
%% Description: 得到角色购买基金详情
%% Returns: tuple
%% ----------------------------------------------------
get_role_funds(Src, RoleUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'funds'), RoleUid, funds:init_funds()).
%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% Func: get_funds_info/1
%% Description: 得到计算开服基金需要的信息
%% Returns: 
%% ----------------------------------------------------
get_funds_info(Src) ->
    z_db_lib:get(game_lib:get_table(Src, 'times_set'), funds_lib:get_timesset_key(Src), []).
%%%% ----------------------------------------------------
%%%% Func: get_buy_sum/1
%%%% Description: 开服基金购买总数(虚拟增长数)
%%%% Returns: tuple
%%%% ----------------------------------------------------
%%get_buy_sum(Src) ->
%%    TimesSet = funds_db:get_funds_info(Src),
%%    {_, Value} = times_set_lib:get(TimesSet, funds_lib:get_timesset_key(Src), {funds_lib:get_timesset_key(Src), 0}),
%%    if
%%        Value < 1 ->
%%            Value;
%%        true ->
%%            case lists:keyfind('buy_time', 1, TimesSet) of
%%                false ->
%%                    Value;%%增长规则生效之后未购买则不增长
%%                {_, Time} ->
%%                    IntervalTime = time_lib:now_second() - Time,%%从首购开始计时
%%                    Days = IntervalTime div ?DAYTIME + 1,
%%                    {_, Info} = zm_config:get('funds', 'funds_add'),
%%                    {_, BuyInfo} = lists:keyfind('buy_num', 1, TimesSet),
%%                    Fun = fun({D, TotalNum}) when D =< ?DAYNUM ->
%%                        {Interval, HopeNum} = element(D, Info),
%%                        RealNum = z_lib:get_value(BuyInfo, D, 0),%%当天没有购买即为0
%%                        Total = TotalNum + RealNum,%%当天未增长时的购买数量
%%                        if
%%                            D < Days ->
%%                                if
%%                                    Total > HopeNum ->%%实际购买大于当天期望则不增长
%%                                        {D + 1, Total};
%%                                    true ->
%%                                        {D + 1, HopeNum}%%实际购买小于期望则增长为期望值
%%                                end;
%%                            true ->%%当前的增长量不是满的，需要计算
%%                                if
%%                                    Total > HopeNum ->
%%                                        {break, Total};
%%                                    true ->
%%                                        NeedAdd = if%%当天需要增长的期望值
%%                                            Days < 2 ->
%%                                                HopeNum;
%%                                            true ->
%%                                                {_, H} = element(Days - 1, Info),
%%                                                HopeNum - H
%%                                        end,
%%                                        PerNum = string_lib:ceil(NeedAdd / (?DAYTIME div Interval)),%%单位时间增长量
%%                                        AddNum = ((IntervalTime rem ?DAYTIME) div Interval) * PerNum,%%增长量
%%                                        FinalNum = Total + AddNum,
%%                                        if
%%                                            FinalNum > HopeNum ->
%%                                                {break, HopeNum};
%%                                            true ->
%%                                                {break, FinalNum}
%%                                        end
%%                                end
%%                        end;
%%                        ({_, TotalNum}) ->
%%                            {break, TotalNum}
%%                    end,
%%                    Value1 = z_lib:while(Fun, {1, 0}),
%%                    Value - lists:sum([Number || {_, Number} <- BuyInfo]) + Value1 %%第八天开始则不使用增长规则
%%            end
%%    end.
%% ----------------------------------------------------
%% Func: get_full_info/2
%% Description: 获取基金,奖励,全服奖励等详情
%% Returns: tuple
%% ----------------------------------------------------
get_full_info(Src, RoleUid) ->
    FundsDb = get_role_funds(Src, RoleUid),
    TimesSet = funds_db:get_funds_info(Src),
    {_, Value} = times_set_lib:get(TimesSet, funds_lib:get_timesset_key(Src), {funds_lib:get_timesset_key(Src), 0}),
    {funds:get_haved_buy(FundsDb), list_to_tuple(funds:get_awarded(FundsDb)), Value}.

%% ----------------------------------------------------
%% Func: buy_funds/3
%% Description: 玩家购买基金
%% Returns: tuple
%% ----------------------------------------------------
buy_funds(_A, {Src, Role, Condtions}, [{Index1, Rmb}, {Index2, Funds}, {Index3, TimesSet}]) ->
    case game_lib:checks({'funds_lib', 'check'}, {Role, Rmb}, 'buy', Condtions) of
        true ->
            NFunds = funds:buy(Funds),
            Key = funds_lib:get_timesset_key(Src),
            NTimesSet = times_set_lib:update(TimesSet, {Key, 1}),
            NTimesSet1 = case lists:keyfind('buy_time', 1, NTimesSet) of
                false ->
                    %%当第一个人购买基金时，初始化首购时间和实际购买量
                    {_, RealNum} = times_set_lib:get(NTimesSet, Key, {Key, 0}),
                    lists:reverse([{'buy_time', time_lib:now_second()}, {'buy_num', [{1, RealNum}]}], NTimesSet);
                {_, Time} ->
                    Days = (time_lib:now_second() - Time) div ?DAYTIME + 1,
                    if
                        Days > ?DAYNUM ->%%第八天开始不使用增长规则
                            NTimesSet;
                        true ->
                            {_, BuyInfo} = lists:keyfind('buy_num', 1, NTimesSet),
                            NBuyInfo = times_set_lib:update(BuyInfo, {Days, 1}),
                            lists:keystore('buy_num', 1, NTimesSet, {'buy_num', NBuyInfo})
                    end
            end,
            {CS, {_, NRmb}} = game_lib:consumes({'funds_lib', 'consume'}, {Role, Rmb}, 'buy', Condtions),
            {ok, {ok, Funds, NFunds, CS, times_set_lib:get_value(NTimesSet1, funds_lib:get_timesset_key(Src), 'day')},
                [{Index1, NRmb}, {Index2, NFunds}, {Index3, NTimesSet1}]};
        Err ->
            throw(Err)
    end.

%% ----------------------------------------------------
%% Func: funds_award/3
%% Description: 玩家开服基金奖励领取
%% Returns: tuple
%% ----------------------------------------------------
funds_award(Src, RoleUid, Sid) ->
    Role = role_db:get_role(Src, RoleUid),
    %%修改领奖状态
    Fun = fun(_, Funds) ->
        %% 是否已领取
        case lists:member(Sid, funds:get_awarded(Funds)) of
            true ->
                throw("awarded");
            false ->
                %% 是否有该开服基金条目
                case zm_config:get('funds', Sid) of
                    none ->
                        throw("no_award");
                    {_, Conditions, Award} ->
                        %% 条件检查
                        TimesSet = funds_db:get_funds_info(Src),
                        case game_lib:checks({'funds_lib', 'check'}, {Role, Funds}, {'award', Src, TimesSet}, Conditions) of
                            true ->
                                {ok, {ok, Award}, funds:add_award(Funds, Sid)};
                            Err ->
                                throw(Err)
                        end
                end
        end
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'funds'), RoleUid, funds:init_funds(), Fun, {}) of
        {ok, Award} ->
            % 奖励
            AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, Award),
            %% 开服基金奖励日志
            zm_log:info(Src, ?MODULE, 'funds_award', "funds_award", [{'roleuid', RoleUid}, {'sid', Sid}, {'award', AwardLog}]),
            %% 开服基金奖励事件
            zm_event:notify(Src, 'funds_award', [{'role_uid', RoleUid}, {'sid', Sid}, {'award', AwardLog}]),
            "ok";
        Err ->
            Err
    end.

%%%===================LOCAL FUNCTIONS==================
