%%开服基金工具
-module(funds_lib).

%%%=======================STATEMENT====================
-description("funds_lib").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_timesset_key/1, check/3, consume/3, format/1]).

%%%=======================INCLUDE======================

%%%=======================RECORD=======================

%%%=======================DEFINE=======================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% Func: check_can_award/3
%% Description: 获取times_set中,全服购买基金数的key,times_set中使用的是3
%% Returns: list
%% ----------------------------------------------------
get_timesset_key(Src) ->
    {game_lib:get_server_key(Src, funds), 3}.
%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% Func: format/1
%% Description: 将返回给前台的数据格式化
%% Returns: list
%% ----------------------------------------------------
format(TimesSet) ->
    {z_lib:get_value(TimesSet, 'buy_time', 0), list_to_tuple(z_lib:get_value(TimesSet, 'buy_num', []))}.

%% ----------------------------------------------------
%% Func: check/3
%% Description: 判断各条件是否满足
%% Returns:
%% ----------------------------------------------------
%%vip条件判断
check({Role, _Rmb}, 'buy', {'vip', Level}) ->
    game_lib:get_level('vip', Role) >= Level;
%%校验rmb是否够
check({_Role, Rmb}, 'buy', {'rmb', NeedRmb}) ->
    rmb_lib:get_rmb(Rmb) >= NeedRmb;

%%校验角色等级是否足够
check({Role, _Funds}, {'award', _Src, _}, {'level', Level}) ->
    game_lib:get_level('role', Role) >= Level;
%%校验是否购买开服基金
check({_Role, Funds}, {'award', _Src, _}, {'funds', State}) ->
    funds:get_haved_buy(Funds) =:= State;
%%校验开服基金购买个数
check({_Role, _Funds}, {'award', Src, TimesSet}, {'buy_number', Number}) ->
    Key = funds_lib:get_timesset_key(Src),
    FadeNum = case lists:keyfind('buy_info', 1, TimesSet) of
        false ->
            0;
        {_, {_Time, _LastTime, Num}} ->
            Num
    end,
    {_, Value} = times_set_lib:get(TimesSet, Key, {Key, 0}),
    Value + FadeNum >= Number;
check(_, _, _) ->
    false.

%% ----------------------------------------------------
%% Func: consume/3
%% Description: 消耗
%% Returns: 
%% ----------------------------------------------------
%%属加扣rmb
consume({Role, Rmb}, 'buy', {'rmb', Value}) ->
    {RCS, NRmb} = rmb_lib:reduct_rmb(Rmb, Value),
    {RCS, {Role, NRmb}};
%%外部条件不需处理
consume(Table, _, _) ->
    {'none', Table}.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% Func: consume/3
%% Description:
%% Returns:
%% ----------------------------------------------------