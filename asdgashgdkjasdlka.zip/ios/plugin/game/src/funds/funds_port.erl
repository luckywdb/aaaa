-module(funds_port).

%%%=======================STATEMENT====================
-description("funds_port").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([funds_award/5, buy/5, get/5, get_funds_info/5]).

%%%=======================INCLUDE======================

%%%=======================RECORD=======================

%%%=======================DEFINE=======================


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%     获取开服基金信息,玩家已购买已领取等信息
%% @end
%% ----------------------------------------------------
get(_A, _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    Res = funds_db:get_full_info(Src, RoleUid),
    {ok, [], Info, [{msg, Res}]}.

%% ----------------------------------------------------
%% @doc
%%     购买开服基金
%% @end
%% ----------------------------------------------------
buy([{M, F, A}], _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    case funds:get_haved_buy(funds_db:get_role_funds(Src, RoleUid)) of
        0 ->
            TableName = game_lib:get_table(Src),
            Role = role_db:get_role(Src, RoleUid),
            {_, Conditions} = zm_config:get('funds', 'condition'),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'rmb', RoleUid}, {'funds', RoleUid, funds:init_funds()}, {'times_set', funds_lib:get_timesset_key(Src), []}]),
            case z_db_lib:handle(TableName, {M, F, A}, {Src, Role, Conditions}, TableKeys) of
                {ok, OFunds, NFunds, CS, Number} ->
                    %% 记录基金购买log
                    zm_log:info(Src, ?MODULE, 'buy', "funds_buy", [{'roleuid', RoleUid},
                        {'old_funds', OFunds}, {'new_funds', NFunds},
                        {'buy_sum', Number}, {'consume', CS}]),
                    %% 基金购买事件
                    zm_event:notify(Src, 'funds_buy', [{'role_uid', RoleUid}, {'consume', CS}]),
                    lists:map(fun(Uid) ->
                        set_front_lib:send_funds_msg(Src, Uid, {{'number', Number}}) end, login_db:get_all_online_uid(Src)),
                    {ok, [], Info, [{msg, "ok"}]};
                Err ->
                    {ok, [], Info, [{msg, Err}]}
            end;
        _ ->
            {ok, [], Info, [{msg, "buy_haved"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     领取购买基金奖励
%% @end
%% ----------------------------------------------------
funds_award(_A, _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    Sid = z_lib:get_value(Msg, "sid", 0),
    if
        Sid =< 0 ->
            {ok, [], Info, [{msg, "input_error"}]};
        true ->
            {ok, [], Info, [{msg, funds_db:funds_award(Src, RoleUid, Sid)}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     得到计算开服基金需要的信息
%% @end
%% ----------------------------------------------------
get_funds_info(_A, _Session, _Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    {ok, [], Info, [{msg, funds_lib:format(funds_db:get_funds_info(Src))}]}.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
