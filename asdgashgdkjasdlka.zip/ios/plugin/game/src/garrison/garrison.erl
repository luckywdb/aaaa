-module(garrison).

%%%=======================STATEMENT====================
-description("garrison").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([init/0]).
-export([get_ogid/1, get_dispatchs/1]).
-export([set_ogid/2, set_dispatchs/2]).

-export_type([garrison/0]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(garrison, {
    ogid = 0 :: integer(),%%自己上阵的阵型
    dispatchs = [] :: [{integer(), integer(), integer()}] %%派遣的列表[{GId,RUid,Pos}]
}).

%%%=======================TYPE=========================
-type garrison() :: #garrison{}.


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        驻守部队
%% @end
%% ----------------------------------------------------
-spec get_ogid(garrison()) -> integer().
get_ogid(#garrison{ogid = OGId}) -> OGId.

%% ----------------------------------------------------
%% @doc
%%        自己的派遣
%% @end
%% ----------------------------------------------------
-spec get_dispatchs(garrison()) -> [{integer(), integer(), integer()}].
get_dispatchs(#garrison{dispatchs = Dispatchs}) -> Dispatchs.

%%-------------------------------------------------------------------
%% @doc
%%
%% @end
%%-------------------------------------------------------------------
-spec set_ogid(garrison(), integer()) -> garrison().
set_ogid(Garrison, OGId) ->
    Garrison#garrison{ogid = OGId}.

%% ----------------------------------------------------
%% @doc
%%        自己的派遣
%% @end
%% ----------------------------------------------------
-spec set_dispatchs(garrison(), [{integer(), integer(), integer()}]) -> garrison().
set_dispatchs(Garrison, Dispatchs) ->
    Garrison#garrison{dispatchs = Dispatchs}.

%% ----------------------------------------------------
%% @doc
%%        初始化
%% @end
%% ----------------------------------------------------
-spec init() -> garrison().
init() ->
    #garrison{}.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
