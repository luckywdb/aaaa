-module(garrison_port).

%%%=======================STATEMENT====================
-description("garrison_port").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_garrison/5, up_garray/5, down_garray/5, dispatch/5, recall_dispatch/5, repatriate/5, change_pos/5]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%        得到驻守信息
%% @end
%% ----------------------------------------------------
get_garrison(_, _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    Garrison = garrison_db:get_garrison(Src, RoleUid),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    PointUid = role_show:get_point(RoleShow),
    {ok, [], Info, [{msg, garrison_db:format(Src, PointUid, Garrison)}]}.


%% ----------------------------------------------------
%% @doc  
%%        上阵驻防部队信息
%% @end
%% ----------------------------------------------------
up_garray([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    GarrayId = z_lib:get_value(Msg, "gid", 0),
    CheckVaild = valid_lib:check_valib([{'range', GarrayId, {1, garray_lib:get_max_gid()}}]),
    if
        CheckVaild ->
            Garrison = garrison_db:get_garrison(Src, RoleUid),
            OGId = garrison:get_ogid(Garrison),
            if
                GarrayId =:= OGId ->
                    {ok, [], Info, [{msg, "input_error"}]};
                true ->
                    RoleShow = role_db:get_role_show(Src, RoleUid),
                    PointUid = role_show:get_point(RoleShow),
                    TableName = game_lib:get_table(Src),
                    Tables =
                        if
                            OGId =/= 0 ->
                                [{'point_march', PointUid, point_march:init()},
                                    {'garrison', RoleUid, garrison:init()},
                                    {'garray', {RoleUid, OGId}, garray:init()},
                                    {'garray', {RoleUid, GarrayId}, garray:init()}];
                            true ->
                                [{'point_march', PointUid, point_march:init()},
                                    {'garrison', RoleUid, garrison:init()},
                                    {'garray', {RoleUid, GarrayId}, garray:init()}]
                        end,
                    TableKeys = z_db_lib:transformation_tablekey(TableName, Tables),
                    Reply = z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, OGId, GarrayId}, TableKeys),
                    {ok, [], Info, [{msg, Reply}]}
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%        下阵驻防部队信息
%% @end
%% ----------------------------------------------------
down_garray([{M, F, A}], _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    Garrison = garrison_db:get_garrison(Src, RoleUid),
    OGid = garrison:get_ogid(Garrison),
    if
        OGid =:= 0 ->
            {ok, [], Info, [{msg, "input_error"}]};
        true ->
            Reply = garrison_db:down_garray(Src, RoleUid, OGid, M, F, A, true),
            {ok, [], Info, [{msg, Reply}]}
    end.


%% ----------------------------------------------------
%% @doc
%%        派遣
%% @end
%% ----------------------------------------------------
dispatch([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    MarchRoleUid = role_lib:get_uid(Attr),
    PointUidTmp = list_to_integer(z_lib:get_value(Msg, "puid", "0")),
    MarchGId = z_lib:get_value(Msg, "gid", 0),
    HaveBuild = z_lib:get_value(Msg, "have_build", 0),%0没有建筑,1表示有建筑
    CheckVaild = valid_lib:check_valib([{'unequal', PointUidTmp, 0}, {'range', MarchGId, {1, garray_lib:get_max_gid()}}, {'range', HaveBuild, {0, 1}}]),
    if
        CheckVaild ->
            MarchRoleShow = role_db:get_role_show(Src, MarchRoleUid),
            MapId = role_lib:get_mapid(Attr),
            PointUid = point_lib:xyaddmapid(PointUidTmp, MapId),
            case PointUid =/= role_show:get_point(MarchRoleShow) of
                true ->
                    case point_state_db:get_point_info(Src, PointUid) of
                        {PointType, EndRoleUid} = EndPState when PointType =:= ?ROLE orelse PointType =:= ?STATION ->
                            %%不能派遣到自己主城驻防
                            case PointType =:= ?ROLE andalso EndRoleUid =:= MarchRoleUid of
                                true ->
                                    {ok, [], Info, [{msg, "input_error"}]};
                                false ->
                                    Stations = station_db:get_role_stations(Src, MarchRoleUid),
                                    StationGIdIndex = station:get_gid_index(),
                                    {MarchPState, MarchPoint, IsStation} =
                                        case lists:keyfind(MarchGId, StationGIdIndex, Stations) of
                                            false ->
                                                {{?ROLE, MarchRoleUid}, role_show:get_point(MarchRoleShow), false};
                                            Station ->
                                                {{?STATION, MarchRoleUid}, station:get_puid(Station), true}
                                        end,
                                    case MarchPoint =/= PointUid of
                                        true ->
                                            EndRoleShow = role_db:get_role_show(Src, EndRoleUid),
                                            CorpUid = role_show:get_corps_uid(MarchRoleShow),
                                            AllyCorpsUids = corps_db:get_ally_corps_uids(Src, CorpUid),
                                            RCorpUid = role_show:get_corps_uid(EndRoleShow),
                                            case EndRoleUid =:= MarchRoleUid orelse (CorpUid > 0 andalso (CorpUid =:= RCorpUid orelse lists:member(RCorpUid, AllyCorpsUids))) of
                                                true ->
                                                    MarchSpeed = role_addition:get_marching_speed(Src, MarchRoleUid, MarchPoint, map_build_lib:check_station_marchg(IsStation, HaveBuild)),
                                                    Marching = marching:set_state(marching:init(MarchRoleUid, MarchGId, MarchPoint,
                                                        PointUid, MarchSpeed, element(1, MarchPState), EndPState), ?ON_THE_CASTLE_MARCHING),
                                                    TableName = game_lib:get_table(Src),
                                                    TableKeys = z_db_lib:transformation_tablekey(TableName, [
                                                        {'role', MarchRoleUid},
                                                        {'garray', {MarchRoleUid, MarchGId}, garray:init()},
                                                        {'point_march', MarchPoint, point_march:init()},
                                                        {'point_march', PointUid, point_march:init()},
                                                        {'role_restore', MarchRoleUid},
                                                        {'garrison', MarchRoleUid, garrison:init()}
                                                    ]),
                                                    restore_db:restore(Src, MarchRoleUid),
                                                    Reply = case z_db_lib:handle(TableName, {M, F, A}, {Src, MapId, MarchPoint, PointUid, Marching, EndPState, MarchPState, IsStation}, TableKeys) of
                                                        {'ok', MarchPMarch, _EndPMarch, BiCs, _Bool, _} ->
                                                            %bi
                                                            zm_event:notify(Src, 'bi_dispatch', [{'role_uid', MarchRoleUid}, {'consumes', BiCs}, {'gid', MarchGId}]),
                                                            MarchLine = marching:marching_to_lines(PointUid, EndPState, Marching),
                                                            point_search_db:send_march_line(Src, MarchPoint, PointUid, MarchLine, [MarchRoleUid, EndRoleUid]),
                                                            fight_db:add_fight_assist(Src, PointUid, Marching),
                                                            station_db:update_station_occ_num(Src, MarchPoint, MarchPMarch, IsStation),
                                                            fight_db:send_assault_info(Src, MapId, EndRoleUid, Marching, PointUid),
                                                            "ok";
                                                        Err ->
                                                            Err
                                                    end,
                                                    {'ok', [], Info, [{'msg', Reply}]};
                                                false ->
                                                    {ok, [], Info, [{msg, "not_in_same_crops"}]}
                                            end;
                                        false ->
                                            {ok, [], Info, [{msg, "input_error"}]}
                                    end
                            end;
                        _ ->
                            {ok, [], Info, [{msg, "input_error"}]}
                    end;
                false ->
                    {ok, [], Info, [{msg, "input_error"}]}
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.


%% ----------------------------------------------------
%% @doc
%%        召回派遣(已经行军达到了的,未到达的都使用fight_port中的)
%% @end
%% ----------------------------------------------------
recall_dispatch([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    MarchRoleUid = role_lib:get_uid(Attr),
    MarchGId = z_lib:get_value(Msg, "gid", 0),
    CheckVaild = valid_lib:check_valib([{'range', MarchGId, {1, garray_lib:get_max_gid()}}]),
    if
        CheckVaild ->
            Dispatchs = garrison:get_dispatchs(garrison_db:get_garrison(Src, MarchRoleUid)),
            case lists:keyfind(MarchGId, 1, Dispatchs) of
                {_, EndRoleUid, EndPointUid} ->
                    Reply = garrison_db:recall_dispatch(Src, MarchRoleUid, MarchGId, EndRoleUid, EndPointUid, M, F, A),
                    {ok, [], Info, [{msg, Reply}]};
                false ->
                    {ok, [], Info, [{msg, "garrison_no_dispatch"}]}
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.


%% ----------------------------------------------------
%% @doc
%%        遣返
%% @end
%% ----------------------------------------------------
repatriate([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    EndRoleUid = role_lib:get_uid(Attr),
    MarchRoleUid = list_to_integer(z_lib:get_value(Msg, "ruid", "0")),
    MarchGId = z_lib:get_value(Msg, "gid", 0),
    PointUidTmp = list_to_integer(z_lib:get_value(Msg, "puid", "0")),
    CheckVaild = valid_lib:check_valib([{'unequal', MarchRoleUid, EndRoleUid}, {'unequal', MarchRoleUid, 0},
        {'range', MarchGId, {1, garray_lib:get_max_gid()}}, {'ge', PointUidTmp, 0}]),
    if
        CheckVaild ->
            RoleShow = role_db:get_role_show(Src, EndRoleUid),
            MapId = role_lib:get_mapid(Attr),
            PointUid = point_lib:xyaddmapid(PointUidTmp, MapId),
            Reply =
                case PointUid =:= role_show:get_point(RoleShow) of
                    true ->
                        garrison_db:repatriate(Src, EndRoleUid, PointUid, {?ROLE, EndRoleUid}, MarchRoleUid, MarchGId, M, F, A);
                    false ->
                        RoleStations = station_db:get_role_stations(Src, EndRoleUid),
                        case lists:keyfind(PointUid, station:get_puid_index(), RoleStations) of
                            false ->
                                "input_error";
                            _ ->
                                garrison_db:repatriate(Src, EndRoleUid, PointUid, {?STATION, EndRoleUid}, MarchRoleUid, MarchGId, M, F, A)
                        end
                end,
            {ok, [], Info, [{msg, Reply}]};
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.


%% ----------------------------------------------------
%% @doc
%%        变化位置
%% @end
%% ----------------------------------------------------
change_pos([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    Pos1 = z_lib:get_value(Msg, "pos1", 0),
    Pos2 = z_lib:get_value(Msg, "pos2", 0),
    CheckVaild = valid_lib:check_valib([{'unequal', Pos1, Pos2}, {'gt', Pos1, 0}, {'gt', Pos2, 0}]),
    if
        CheckVaild andalso is_integer(Pos1) andalso is_integer(Pos2) ->
            TableName = game_lib:get_table(Src),
            PointUid = role_show:get_point(role_db:get_role_show(Src, RoleUid)),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [
                {'point_march', PointUid, point_march:init()}
            ]),
            Reply = z_db_lib:handle(TableName, {M, F, A}, {Src, Pos1, Pos2}, TableKeys),
            {ok, [], Info, [{msg, Reply}]};
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
