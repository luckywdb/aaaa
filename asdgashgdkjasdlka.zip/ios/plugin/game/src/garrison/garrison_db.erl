-module(garrison_db).

%%%=======================STATEMENT====================
-description("garrison_db").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_garrison/2, recall_dispatch/5, recall_dispatch/8, repatriate/6, repatriate/9, down_garray/3, down_garray/7, change_pos/3]).
-export([up_garray/3, down_garray_1/3, recall_dispatch/3, repatriate/3]).
-export([get_dispatch_fightrole/2, format/3]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        获取玩家驻守信息
%% @end
%% ----------------------------------------------------
-spec get_garrison(Src :: atom(), RoleUid :: integer()) -> garrison:garrison().
get_garrison(Src, RoleUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'garrison'), RoleUid, garrison:init()).

%% ----------------------------------------------------
%% @doc
%%        上阵驻防部队信息
%% @end
%% ----------------------------------------------------
-spec up_garray(_, tuple(), list()) -> string()|{'ok', 'ok', list()}.
up_garray(_, {_Src, _RoleUid, OGId, GarrayId}, [{_, PMarch}, {Index1, Garrison}, {Index2, Garray1}, {Index3, Garray2}]) ->
    point_march:check_fighting(PMarch),
    case OGId =/= garrison:get_ogid(Garrison) of
        true ->
            throw("garray_error");
        false ->
            ok
    end,
    Bool = garray:check_march(Garray2),
    if
        Bool ->
            ok;
        true ->
            throw("garray_error")
    end,
    NGarrison = garrison:set_ogid(Garrison, GarrayId),
    NGarray1 = garray:set_state(Garray1, ?IDLE),
    NGarray2 = garray:set_state(Garray2, ?ON_THE_CASTLE),
    {ok, ok, [{Index1, NGarrison}, {Index2, NGarray1}, {Index3, NGarray2}]};
up_garray(_, {_Src, _RoleUid, OGId, GarrayId}, [{_, PMarch}, {Index1, Garrison}, {Index2, Garray}]) ->
    point_march:check_fighting(PMarch),
    case OGId =/= garrison:get_ogid(Garrison) of
        true ->
            throw("garray_error");
        false ->
            ok
    end,
    Bool = garray:check_march(Garray),
    if
        Bool ->
            ok;
        true ->
            throw("garray_error")
    end,
    NGarrison = garrison:set_ogid(Garrison, GarrayId),
    NGarray = garray:set_state(Garray, ?ON_THE_CASTLE),
    {ok, ok, [{Index1, NGarrison}, {Index2, NGarray}]}.


%% ----------------------------------------------------
%% @doc
%%        下阵驻防部队信息
%% @end
%% ----------------------------------------------------
-spec down_garray(atom(), integer(), integer()) -> string() | 'ok'.
down_garray(Src, RoleUid, Gid) ->
    down_garray(Src, RoleUid, Gid, ?MODULE, 'down_garray_1', [], false).
%% ----------------------------------------------------
%% @doc
%%        下阵驻防部队信息
%% @end
%% ----------------------------------------------------
-spec down_garray(atom(), integer(), integer(), atom(), atom(), term(), boolean()) -> string() | 'ok'.
down_garray(Src, RoleUid, Gid, M, F, A, CheckFight) ->
    RoleShow = role_db:get_role_show(Src, RoleUid),
    PointUid = role_show:get_point(RoleShow),
    TableName = game_lib:get_table(Src),
    Tables = [
        {'point_march', PointUid, point_march:init()},
        {'garrison', RoleUid, garrison:init()},
        {'garray', {RoleUid, Gid}, garray:init()}],
    TableKeys = z_db_lib:transformation_tablekey(TableName, Tables),
    z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, Gid, CheckFight}, TableKeys).

%% ----------------------------------------------------
%% @doc
%%        下阵驻防部队信息
%% @end
%% ----------------------------------------------------
-spec down_garray_1(_, tuple(), list()) -> string()|{'ok', 'ok', list()}.
down_garray_1(_, {_Src, _RoleUid, OGId, CheckFight}, [{_, PMarch}, {Index1, Garrison}, {Index2, Garray1}]) ->
    [point_march:check_fighting(PMarch) || CheckFight =:= true],
    case OGId =/= garrison:get_ogid(Garrison) of
        true ->
            {ok, ok};
        false ->
            NGarrison = garrison:set_ogid(Garrison, 0),
            NGarray1 = garray:set_state(Garray1, ?IDLE),
            {ok, ok, [{Index1, NGarrison}, {Index2, NGarray1}]}
    end.


%%-------------------------------------------------------------------
%% @doc
%%      召回
%% @end
%%-------------------------------------------------------------------
-spec recall_dispatch(Src, MarchRoleUid, MarchGId, EndRoleUid, EndPointUid) -> 'ok' | string() when
    Src :: atom(),
    MarchRoleUid :: integer(),
    MarchGId :: integer(),
    EndRoleUid :: integer(),
    EndPointUid :: integer().
recall_dispatch(Src, MarchRoleUid, MarchGId, EndRoleUid, EndPointUid) ->
    recall_dispatch(Src, MarchRoleUid, MarchGId, EndRoleUid, EndPointUid, ?MODULE, 'recall_dispatch', []).

%%-------------------------------------------------------------------
%% @doc
%%      召回
%% @end
%%-------------------------------------------------------------------
-spec recall_dispatch(Src, MarchRoleUid, MarchGId, EndRoleUid, EndPointUid, M, F, A) -> 'ok' | string() when
    Src :: atom(),
    MarchRoleUid :: integer(),
    MarchGId :: integer(),
    EndRoleUid :: integer(),
    EndPointUid :: integer(),
    M :: atom(),
    F :: atom(),
    A :: term().
recall_dispatch(Src, MarchRoleUid, MarchGId, EndRoleUid, EndPoint, M, F, A) ->
    MarchRoleShow = role_db:get_role_show(Src, MarchRoleUid),
    MarchPoint = role_show:get_point(MarchRoleShow),
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'garrison', MarchRoleUid, garrison:init()},
        {'point_march', EndPoint, point_march:init()}
    ]),
    RoleStations = station_db:get_role_stations(Src, MarchRoleUid),
    SPointUid = case lists:keyfind(MarchGId, station:get_gid_index(), RoleStations) of
        false ->
            MarchPoint;
        Station ->
            station:get_puid(Station)
    end,
    EndPState = point_state_db:get_point_info(Src, EndPoint),
    case z_db_lib:handle(TableName, {M, F, A}, {Src, MarchRoleUid, EndRoleUid, MarchGId, SPointUid, EndPoint}, TableKeys) of
        {'ok', NMarching, NOccMarchings, OldMarching} ->
            MarchLine = marching:marching_to_lines(EndPoint, EndPState, NMarching),
            point_search_db:send_march_line(Src, SPointUid, EndPoint, MarchLine, [MarchRoleUid]),
            set_front_lib:send_garrison_remove_friend_garray(Src, EndRoleUid, MarchRoleUid, MarchGId),
            case element(1, EndPState) =:= ?STATION of
                true ->
                    point_search_db:update_station_occ(Src, EndPoint, length(NOccMarchings));
                false ->
                    ok
            end,
            fight_db:update_fight_assist(Src, EndPoint, [OldMarching], [NMarching]),
            ok;
        Err ->
            Err
    end.

%% ----------------------------------------------------
%% @doc
%%        召回
%% @end
%% ----------------------------------------------------
recall_dispatch(_, {_Src, MarchRoleUid, EndRoleUid, MarchGId, SPointUid, EndPoint},
        [{_Index1, MarchGarrison}, {Index2, EndPMarch}]) ->
    point_march:check_fighting(EndPMarch),
    Dispatchs = garrison:get_dispatchs(MarchGarrison),
    case lists:keyfind(MarchGId, 1, Dispatchs) of
        false ->
            throw("garrison_no_dispatch");
        {_, RUid, PUid} ->
            case RUid =:= EndRoleUid andalso PUid =:= EndPoint of
                false ->
                    throw("garrison_no_dispatch");
                true ->
                    ok
            end
    end,
    OccMarchings = point_march:get_occupy(EndPMarch),
    case lists:keyfind({MarchRoleUid, MarchGId}, marching:get_roleuid_gid_index(), OccMarchings) of
        false ->
            throw("garrison_no_recall");
        OccMarching ->
            NOccMarchings = lists:keydelete({MarchRoleUid, MarchGId}, marching:get_roleuid_gid_index(), OccMarchings),
            NMarching = marching:change_goback(OccMarching, SPointUid, EndPoint, time_lib:now_second(), ?ON_THE_CASTLE_GOBACK),
            NEndPMarch1 = point_march:set_goback(EndPMarch, [NMarching | point_march:get_goback(EndPMarch)]),
            NEndPMarch = point_march:set_occupy(NEndPMarch1, NOccMarchings),
            {'ok', {'ok', NMarching, NOccMarchings, OccMarching}, [{Index2, NEndPMarch}]}
    end.

%% ----------------------------------------------------
%% @doc
%%        遣返
%% @end
%% ----------------------------------------------------
-spec repatriate(atom(), integer(), integer(), tuple(), integer(), integer()) -> string()|'ok'.
repatriate(Src, EndRoleUid, EndPointUid, EndPState, MarchRoleUid, MarchGId) ->
    repatriate(Src, EndRoleUid, EndPointUid, EndPState, MarchRoleUid, MarchGId, ?MODULE, 'repatriate', []).

%% ----------------------------------------------------
%% @doc
%%        遣返
%% @end
%% ----------------------------------------------------
-spec repatriate(atom(), integer(), integer(), tuple(), integer(), integer(), atom(), atom(), term()) -> string()|'ok'.
repatriate(Src, EndRoleUid, EndPointUid, EndPState, MarchRoleUid, MarchGId, M, F, A) ->
    MarchRoleShow = role_db:get_role_show(Src, MarchRoleUid),
    MarchPoint = role_show:get_point(MarchRoleShow),
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'point_march', EndPointUid, point_march:init()}
    ]),
    case z_db_lib:handle(TableName, {M, F, A}, {Src, MarchRoleUid, MarchGId, EndPointUid}, TableKeys) of
        {'ok', NMarching, NOccMarchings, OldMarching} ->
            MarchLine = marching:marching_to_lines(EndPointUid, EndPState, NMarching),
            point_search_db:send_march_line(Src, EndPointUid, MarchPoint, MarchLine, [MarchRoleUid, EndRoleUid]),
            set_front_lib:send_garrison_remove_friend_garray(Src, EndRoleUid, MarchRoleUid, MarchGId),
            case element(1, EndPState) =:= ?STATION of
                true ->
                    point_search_db:update_station_occ(Src, EndPointUid, length(NOccMarchings));
                false ->
                    ok
            end,
            fight_db:update_fight_assist(Src, EndPointUid, [OldMarching], [NMarching]),
            'ok';
        Err ->
            Err
    end.

%% ----------------------------------------------------
%% @doc
%%        遣返
%% @end
%% ----------------------------------------------------
repatriate(_, {_Src, MarchRoleUid, MarchGId, EndPoint},
        [{Index1, EndPMarch}]) ->
    point_march:check_fighting(EndPMarch),
    OccMarchings = point_march:get_occupy(EndPMarch),
    case lists:keyfind({MarchRoleUid, MarchGId}, marching:get_roleuid_gid_index(), OccMarchings) of
        false ->
            throw("garrison_no_friend_garray");
        OccMarching ->
            NOccMarchings = lists:keydelete({MarchRoleUid, MarchGId}, marching:get_roleuid_gid_index(), OccMarchings),
            NMarching = marching:change_goback(OccMarching, EndPoint, time_lib:now_second(), ?ON_THE_CASTLE_GOBACK),
            NEndPMarch1 = point_march:set_goback(EndPMarch, [NMarching | point_march:get_goback(EndPMarch)]),
            NEndPMarch = point_march:set_occupy(NEndPMarch1, NOccMarchings),
            {'ok', {'ok', NMarching, NOccMarchings, OccMarching}, [{Index1, NEndPMarch}]}
    end.

%% ----------------------------------------------------
%% @doc
%%        变化位置
%% @end
%% ----------------------------------------------------
-spec change_pos(_, tuple(), list()) -> string()|{'ok', 'ok', list()}.
change_pos(_, {_Src, Pos1, Pos2}, [{Index1, PointMarch}]) ->
    point_march:check_fighting(PointMarch),
    OccMarchingsTup = list_to_tuple(point_march:get_occupy(PointMarch)),
    Size = tuple_size(OccMarchingsTup),
    if
        Pos1 > Size orelse Pos2 > Size ->
            throw("input_error");
        true ->
            NOccMarchingsTup = setelement(Pos2, setelement(Pos1, OccMarchingsTup, element(Pos2, OccMarchingsTup)), element(Pos1, OccMarchingsTup)),
            NPointMarch = point_march:set_occupy(PointMarch, tuple_to_list(NOccMarchingsTup)),
            {ok, ok, [{Index1, NPointMarch}]}
    end.

%% ----------------------------------------------------
%% @doc
%%        防守队伍(roleuid,gid),FightEnemy,自动回复兵力
%% @end
%% ----------------------------------------------------
-spec get_dispatch_fightrole(Src, RoleUid) -> {integer(), [fighter:battlefield()], integer()} when
    Src :: atom(),
    RoleUid :: integer().
get_dispatch_fightrole(Src, RoleUid) ->
    Study = building_db:get_study(Src, RoleUid),
    BuffList = role_db:get_role_buff(Src, RoleUid),
    Garrison = get_garrison(Src, RoleUid),
    WallAddAttr = role_addition:get_city_wall_attr(Study, BuffList),
    %城墙需要特殊处理,将玩家城墙等级设置为怪物中城墙的等级
    {_, WallNpcArray} = zm_config:get('building_info', 'wall_npcarray'),
    WallLv = castle:get_buildlv(castle:get_building(castle_db:get_castle(Src, RoleUid)), building_lib:get_bsid('wall')),

    RoleShow = role_db:get_role_show(Src, RoleUid),
    FightWall = [begin
        Fighters = fighter:get_fighters(Battle),
        NFighters = [
            begin
                Index = fighter:get_position(F),
                %%城墙特殊处理,将拒马等级设置为star ,箭楼等级设置为level  ,为城墙等级new_star
                if
                    Index =:= ?WALL_INDEX ->
                        {_, {JmSid, JLSid}} = zm_config:get('building_info', 'juma_jl_sid'),
                        StarList = z_lib:get_value(Study, building_lib:get_bsid('wall'), []),
                        fighter:set_star(fighter:set_level(fighter:set_new_star(F, WallLv), z_lib:get_value(StarList, JLSid, 0)), z_lib:get_value(StarList, JmSid, 0));
                    true ->
                        F
                end end || F <- Fighters
        ],
        fighter:set_fighters(Battle, NFighters)
    end || Battle <- fighter:init_city_wall_npc(WallNpcArray, role_show:get_name(RoleShow), role_show:get_level(RoleShow), WallAddAttr)],
    case garrison:get_ogid(Garrison) of
        0 ->
            {0, FightWall, fighting:get_fight_scene('role_wall')};
        FightGId ->
            DisAddition = role_addition:get_garrison_attr(Study, BuffList),
            FightGarray = garray_db:get_garray(Src, RoleUid, FightGId),
            FighterRole = fighter:init_role(Src, RoleUid, FightGId, 1, FightGarray, DisAddition),%0:进攻方,1防守方
            {Figthers, SecenSid} =
                case fighter:get_fighters(FighterRole) =:= [] of
                    true ->
                        {FightWall, fighting:get_fight_scene('role_wall')};
                    false ->
                        {[FighterRole | FightWall], fighting:get_fight_scene('role_role')}
                end,
            {FightGId, Figthers, SecenSid}
    end.

%% ----------------------------------------------------
%% @doc
%%     前台展示
%% @end
%% ----------------------------------------------------
format(Src, PointUid, Garrison) ->
    PointMarch = z_db_lib:get(game_lib:get_table(Src, 'point_march'), PointUid, point_march:init()),
    OGId = garrison:get_ogid(Garrison),
    TFriendGarrays = lists:map(fun(OccMarching) ->
        {RUid, Gid} = marching:get_roleuid_gid(OccMarching),
        RoleShow = role_db:get_role_show(Src, RUid),
        RoleName = role_show:get_name(RoleShow),
        Power = attrs:get_garray_power(Src, RUid, Gid),
        {RUid, RoleName, Gid, Power}
    end, point_march:get_occupy(PointMarch)),
    {OGId, list_to_tuple(TFriendGarrays)}.
%%%===================LOCAL FUNCTIONS==================