%%系统广播数据库模块
-module(broadcast_db).
-description("broadcast_db").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([update/2, get/1, new/1]).

%%%=======================INCLUDE======================

%%%=======================RECORD=======================

%%%=======================DEFINE=======================
%% 系统广播唯一id
-define(BROADCAST_UID, 1).
%% 每分钟向前端推送的系统广播的最大数量
-define(BROADCAST_MAX, 15).
%% 数据库中存入的系统广播的最大数量
-define(BROADCAST_MAX_NUM, 30).

%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      写入系统广播
%% @end
%%-------------------------------------------------------------------
-spec update(atom(), {integer(), string()}) -> 'ok' | 'ignore'.
update(Src, Broadcast) ->
    Table = game_lib:get_table(Src, broadcast),
    BroadcastList = z_db_lib:get(Table, ?BROADCAST_UID, []),
    Len = length(BroadcastList),
    if
        Len >= ?BROADCAST_MAX_NUM ->
%%            zm_log:warn(Src, ?MODULE, 'update', "broadcast ignore", [{'broadcast', Broadcast}]),
            ignore;
        true ->
            z_db_lib:update(Table, ?BROADCAST_UID, [Broadcast | BroadcastList])
    end.

%%-------------------------------------------------------------------
%% @doc
%%      获取系统广播
%% @end
%%-------------------------------------------------------------------
-spec get(atom()) -> [{integer(), string()}].
get(Src) ->
    Table = game_lib:get_table(Src, broadcast),
    BroadcastList = z_db_lib:get(Table, ?BROADCAST_UID, []),
    Len = length(BroadcastList),
    if
        Len > ?BROADCAST_MAX ->
            {NewBroadcastList, BroadcastList1} = lists:split(Len - ?BROADCAST_MAX, BroadcastList),
            z_db_lib:update(Table, ?BROADCAST_UID, NewBroadcastList),
            BroadcastList1;
        true ->
            z_db_lib:delete(Table, ?BROADCAST_UID),
            BroadcastList
    end.

%%-------------------------------------------------------------------
%% @doc
%%      创建新的系统广播对象
%% @end
%%-------------------------------------------------------------------
-spec new(string()) -> {integer(), string()}.
new(Content) ->
    {time_lib:now_second(), Content}.

%%%=====================LOCAL FUNCTIONS=================