%%系统广播事件
-module(broadcast_event).
-description("broadcast_event").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).
%%%=======================EXPORT========================
-export([event_notify/4]).

%%%===================PUBLIC FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%      广播notify处理
%% @end
%%-------------------------------------------------------------------
-spec event_notify(any(), atom(), 'broadcast', {atom(), [game_types:kv()]}) -> any().
event_notify(_, Src, 'broadcast', Argu) ->
    notify(Src, Argu).


%%%===================LOCAL FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%      广播notify分类处理
%% @end
%%-------------------------------------------------------------------
-spec notify(atom(), {atom(), [game_types:kv()]}) -> any().
notify(Src, {'lucky_draw', Args}) ->%%抽卡
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, AwardLog} = lists:keyfind('award', 1, Args),
    {_, LdSid} = lists:keyfind('sid', 1, Args),
    {_, LdInfo} = zm_config:get('ld_info', LdSid),
    {_, LdName} = lists:keyfind('name', 1, LdInfo),
    {_, Q} = zm_config:get('broadcast_config', 'ld_quality'),
    {Type, List} = lists:foldl(fun
        ({'card', Tuple}, {_, Acc}) ->
            {'card', tuple_to_list(Tuple) ++ Acc};
        ({T, A, B, C}, {_, Acc}) when T =:= 'treasure_draw';T =:= 'treasure_material' ->
            {'normal_prop', [{A, B, C} | Acc]};
        ({'treasure', Tuple}, {_, Acc}) ->
            {'treasure', tuple_to_list(Tuple) ++ Acc};
        (_, R) ->
            R
    end, {ok, []}, tuple_to_list(AwardLog)),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    RoleName = role_show:get_name(RoleShow),
    VipLevel = role_show:get_vip_level(RoleShow),
    Fun = fun(Info) ->
        Sid = erlang:element(1, Info),
        Record = prop_kit_lib:get_prop_record(prop_kit_lib:get_prop(Sid)),
        Quality = Type:get_quality(Record),
        ld_broadcast_(Src, Quality, Q, RoleName, VipLevel, LdName, Type:get_name(Record), string_lib:to_atom('ld_broadcast_', Type), string_lib:to_atom(Type, '_quality_color'))
    end,
    lists:foreach(Fun, List);
notify(Src, {'compound', Args}) -> %%合成
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, AwardLog} = lists:keyfind('award', 1, Args),
    {_, CardQuality} = zm_config:get('broadcast_config', 'card_quality'),
    {_, EquipQuality} = zm_config:get('broadcast_config', 'equipment_quality'),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    RoleName = role_show:get_name(RoleShow),
    {CardList, EquipList} = lists:foldl(fun({'card', Tuple}, {CardAcc, EquipAcc}) ->
        {tuple_to_list(Tuple) ++ CardAcc, EquipAcc};
        ({'equipment', Tuple}, {CardAcc, EquipAcc}) ->
            {CardAcc, tuple_to_list(Tuple) ++ EquipAcc};
        (_, Acc) ->
            Acc
    end, {[], []}, tuple_to_list(AwardLog)),
    Fun = fun({Mod, LanguageKey, NeedQuality, ColorCfg} = A, {Sid, _, _}) ->
        Record = prop_kit_lib:get_prop_record(prop_kit_lib:get_prop(Sid)),
        Quality = Mod:get_quality(Record),
        if
            Quality >= NeedQuality ->
                Content = game_lib:get_language(LanguageKey, [RoleName, broadcast_lib:get_color(ColorCfg, Quality, Mod:get_name(Record))]),
                broadcast_db:update(Src, broadcast_db:new(Content)),
                {'ok', A};
            true ->
                {'ok', A}
        end
    end,
    z_lib:foreach(Fun, {'card', 'compound_card_broadcast', CardQuality, 'card_quality_color'}, CardList),
    z_lib:foreach(Fun, {'equipment', 'compound_equipment_broadcast', EquipQuality, 'equip_quality_color'}, EquipList);
notify(Src, {'prop_use', Args}) -> %%使用物品
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, AwardLog} = lists:keyfind('award', 1, Args),
    {_, CardQuality} = zm_config:get('broadcast_config', 'card_quality'),
    {_, EquipQuality} = zm_config:get('broadcast_config', 'equipment_quality'),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    RoleName = role_show:get_name(RoleShow),
    {CardList, EquipList} = lists:foldl(fun({'card', Tuple}, {CardAcc, EquipAcc}) ->
        {tuple_to_list(Tuple) ++ CardAcc, EquipAcc};
        ({'equipment', Tuple}, {CardAcc, EquipAcc}) ->
            {CardAcc, tuple_to_list(Tuple) ++ EquipAcc};
        (_, Acc) ->
            Acc
    end, {[], []}, tuple_to_list(AwardLog)),
    Fun = fun({Mod, LanguageKey, NeddQuality, ColorCfg} = A, {Sid, _, _}) ->
        Record = prop_kit_lib:get_prop_record(prop_kit_lib:get_prop(Sid)),
        Quality = Mod:get_quality(Record),
        if
            Quality >= NeddQuality ->
                Content = game_lib:get_language(LanguageKey, [RoleName, broadcast_lib:get_color(ColorCfg, Quality, Mod:get_name(Record))]),
                broadcast_db:update(Src, broadcast_db:new(Content)),
                {'ok', A};
            true ->
                {'ok', A}
        end
    end,
    z_lib:foreach(Fun, {'card', 'use_prop_card_broadcast', CardQuality, 'card_quality_color'}, CardList),
    z_lib:foreach(Fun, {'equipment', 'use_prop_equipment_broadcast', EquipQuality, 'equip_quality_color'}, EquipList);
notify(Src, {'duplicate', Args}) ->%%通关副本
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, Country} = lists:keyfind('country', 1, Args),
    {_, Sid} = lists:keyfind('sid', 1, Args),
    {_, SidList} = zm_config:get('broadcast_config', 'duplicate_sids'),
    case lists:member(Sid, SidList) of
        true ->
            RoleShow = role_db:get_role_show(Src, RoleUid),
            RoleName = role_show:get_name(RoleShow),
            {_, Duplicate} = zm_config:get('duplicate', Sid),
            DName = game_lib:get_language_package(z_lib:get_value(Duplicate, 'name', "")),
            Content = game_lib:get_language('duplicate_broadcast', [fight_db:get_country_name(Country), RoleName, DName]),
            broadcast_db:update(Src, broadcast_db:new(Content));
        false ->
            'ignore'
    end;
notify(Src, {'castle_lv', Args}) -> %% 玩家大殿达到N级
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, CastleLv} = lists:keyfind('castle_lv', 1, Args),
    {_, CastleLvs} = zm_config:get('broadcast_config', 'castle_lvs'),
    case lists:member(CastleLv, CastleLvs) of
        true ->
            RoleShow = role_db:get_role_show(Src, RoleUid),
            RoleName = role_show:get_name(RoleShow),
            Content = game_lib:get_language('castle_lv_broadcast', [RoleName, CastleLv]),
            broadcast_db:update(Src, broadcast_db:new(Content));
        false ->
            'ignore'
    end;
notify(Src, {'create_corps', Args}) ->
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, Corps} = lists:keyfind('corps', 1, Args),
    CName = corps:get_name(Corps),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    RoleName = role_show:get_name(RoleShow),
    Country = role_show:get_country(RoleShow),
    Content = game_lib:get_language('create_corps_broadcast', [fight_db:get_country_name(Country), RoleName, fight_db:get_country_color(Country, CName)]),
    broadcast_db:update(Src, broadcast_db:new(Content));
notify(Src, {'corps_lv', Args}) ->
    {_, Corps} = lists:keyfind('corps', 1, Args),
    CName = corps:get_name(Corps),
    CLevel = corps:get_level(Corps),
    {_, Lvs} = zm_config:get('broadcast_config', 'corps_lvs'),
    case lists:member(CLevel, Lvs) of
        true ->
            Country = corps:get_country(Corps),
            Content = game_lib:get_language('corps_lv_broadcast', [fight_db:get_country_name(Country), fight_db:get_country_color(Country, CName), CLevel]),
            broadcast_db:update(Src, broadcast_db:new(Content));
        false ->
            'ignore'
    end;
%% 城池战
notify(Src, {'town_fight', Args}) ->
    CfgName = z_lib:get_value(Args, 'cfg_name', none),
    Country = z_lib:get_value(Args, 'country', 0),
    TownType = z_lib:get_value(Args, 'town_type', 0),
    TownLevel = z_lib:get_value(Args, 'town_level', 0),
    TownName = z_lib:get_value(Args, 'town_name', ""),
    CorpsName = z_lib:get_value(Args, 'corps_name', ""),
    Content1 = [fight_db:get_country_name(Country), fight_db:get_country_color(Country, CorpsName), fight_db:get_town_type_name(TownType), TownLevel, TownName],
    Content = game_lib:get_language(CfgName, Content1),
    broadcast_db:update(Src, broadcast_db:new(Content)),
    ok;
notify(Src, {'normal_boadcast', KVList}) ->
    {_, Type} = lists:keyfind('type', 1, KVList),
    {_, Args} = lists:keyfind('args', 1, KVList),
    Content = game_lib:get_language(Type, Args),
    broadcast_db:update(Src, broadcast_db:new(Content));
%武将星级 4星级 及 以上
notify(Src, {'card_new_star', Args}) ->
    RoleUid = z_lib:get_value(Args, 'role_uid', 0),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    RoleName = role_show:get_name(RoleShow),
    Country = role_show:get_country(RoleShow),
    Sid = z_lib:get_value(Args, 'sid', 0),
    NewStar = z_lib:get_value(Args, 'new_star', 0),
    Card = prop_kit_lib:get_prop_record(prop_kit_lib:get_prop(Sid)),
    Content = game_lib:get_language('card_new_star_broadcast', [fight_db:get_country_color(Country, RoleName),
        broadcast_lib:get_color('card_quality_color', card:get_quality(Card), card:get_name(Card)), NewStar]),
    broadcast_db:update(Src, broadcast_db:new(Content));
notify(Src, {'awards_broadcast', Args}) ->              %%获得奖励可通用广播；现已使用：皇宫探宝，
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, Awards} = lists:keyfind('award', 1, Args),      %%奖励结构1
    {_, Source} = lists:keyfind('source', 1, Args),     %%广播来源
    {_, Language} = lists:keyfind('language', 1, Args), %%广播语言包
    {_, Q} = zm_config:get('broadcast_config', 'awards_broadcast'),
    F = fun({'prop', {Sid, _}}) ->
        Prop = prop_kit_lib:get_prop(Sid),
        PropMod = prop_kit_lib:get_prop_mod(Prop),
        PropRecord = prop_kit_lib:get_prop_record(Prop),
        PropQuality = PropMod:get_quality(PropRecord),
        if
            PropQuality >= Q ->
%%              ColorType = string_lib:to_atom(PropMod, '_quality_color'),
                ColorType = 'equip_quality_color',      %写死只用一种颜色
                RoleShow = role_db:get_role_show(Src, RoleUid),
                RoleName = role_show:get_name(RoleShow),
                Country = role_show:get_country(RoleShow),
                PropName = PropMod:get_name(PropRecord),
                Content = game_lib:get_language(Language, [fight_db:get_country_color(Country, RoleName), Source, broadcast_lib:get_color(ColorType, PropQuality, PropName)]),
                broadcast_db:update(Src, broadcast_db:new(Content));
            true ->
                ok
        end;
        (_) ->
            ok
    end,
    lists:foreach(F, Awards).
%%-------------------------------------------------------------------
%% @doc
%%      抽卡 寻宝 广播
%% @end
%%-------------------------------------------------------------------
ld_broadcast_(Src, PropQuality, CfgQuality, RoleName, VipLevel, LdName, RecordName, LanguageType, ColorType) ->
    if
        PropQuality >= CfgQuality ->
            Content = game_lib:get_language(LanguageType, [RoleName, VipLevel, LdName, broadcast_lib:get_color(ColorType, PropQuality, RecordName)]),
            broadcast_db:update(Src, broadcast_db:new(Content));
        true ->
            'ignore'
    end.

