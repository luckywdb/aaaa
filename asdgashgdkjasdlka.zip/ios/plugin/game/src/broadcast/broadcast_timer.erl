%%系统广播定时器
-module(broadcast_timer).
-description("broadcast_timer").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([broadcast/3]).

%%%=======================INCLUDE======================
-include("../../../include/sign_key.hrl").

%%%=======================RECORD=======================

%%%=======================DEFINE=======================
%% 游戏内部广播
-define(BROADCAST, 2).

%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      广播Timer
%% @end
%%-------------------------------------------------------------------
broadcast(Src, _Args, _) ->
    Bool = zm_load:server_start_ok() =:= ?KEY,
    if
        Bool ->
            case list_to_tuple(broadcast_db:get(Src)) of
                {} ->
                    ok;
                Msg ->
                    broadcast_lib:send(Src, ?BROADCAST, Msg)
            end;
        true ->
            ok
    end.

%%%=====================LOCAL FUNCTIONS=================