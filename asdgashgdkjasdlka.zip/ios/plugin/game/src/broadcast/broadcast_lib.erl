%% 系统公告工具模块
-module(broadcast_lib).
-description("broadcast_lib").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([send/3, get_color/3]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      发送类型广播
%% @end
%%-------------------------------------------------------------------
-spec send(atom(), integer(), tuple()) -> 'ok'.%{{integer(), string()}..}
send(Src, Type, Msg) ->
    Sessions = login_db:get_all_online(Src),
    M = {'broadcast', [{'msg', {Type, Msg}}]},
    lists:foreach(fun(Session) ->
        zm_session:send(Session, M)
    end, Sessions),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      根据品质获取颜色
%% @end
%%-------------------------------------------------------------------
-spec get_color(atom(), integer(), string()) -> string().
get_color(ColorCfg, Quality, Text) ->
    {_, Colors} = zm_config:get('broadcast_config', ColorCfg),
    string_lib:content(element(Quality, Colors), [Text]).


%%%===================LOCAL FUNCTIONS==================