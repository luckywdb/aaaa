-module(garray_port).

%%%=======================STATEMENT====================
-description("编队阵型").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    get_other_garray/5,
    get_garray/5,
    change_card/5,
    change_ordnance/5,
    set_soldiers/5,
    set_skill36/5,
    get_garray_by_gid/5,
    exchange_garray_pos/5,
    set_auto_add_soldier/5,
    set_soldiers_one_key/5
]).

%%%=======================INCLUDE======================
-include("../include/garray.hrl").
-include("../include/point.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%     获取其他玩家编队信息,友军驻防使用
%% @end
%% ----------------------------------------------------
get_other_garray(_, _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    RUid = list_to_integer(z_lib:get_value(Msg, "ruid", "0")),
    GarrayId = z_lib:get_value(Msg, "gid", 0),
    GarrayList = garray_lib:get_garray_ids(Src, RUid),
    CheckVaild = valid_lib:check_valib([{'unequal', RUid, 0}, {'unequal', RUid, RoleUid}, {'exist', GarrayId, GarrayList}]),
    if
        CheckVaild ->
            Garray = garray_db:get_garray(Src, RUid, GarrayId),
            CardPropSet = storage_db:get_storage('card', Src, RUid),
            Study = building_db:get_study(Src, RUid),
            OfficailAttr = official_db:get_attrs(Src, RoleUid),
            Political = building_db:get_political(Src, RoleUid),
            {OSid, OLevel} = case garray:get_ordnance(Garray) of
                0 ->
                    {0, 0};
                OId ->
                    {OId, z_lib:get_value(z_lib:get_value(Study, building_lib:get_bsid('ordnance'), []), OId, 0)}
            end,
            Skill36 = garray:get_skill36(Garray),
            Fun = fun(Acc, N, {Uid, SolidersNum}) when Uid > 0 andalso SolidersNum > 0 ->
                {_, CardProp} = storage_lib:find_by_uid(CardPropSet, Uid),
                Card = prop_kit_lib:get_prop_record(CardProp),
                Sid = prop_kit_lib:get_prop_sid(CardProp),
                Star = card:get_star(Card),
                NewStar = card:get_new_star(Card),
                Level = card:get_level(Card),
                MaxSolidersNum = card_lib:get_max_soldiers_num(Card, Study, attrs:merge_attrs(building_db:get_political_attr(Uid, Political), OfficailAttr)),
                [{N, Sid, Star, Level, SolidersNum, MaxSolidersNum, NewStar} | Acc];
                (Acc, _, _) ->
                    Acc
            end,
            RoleShow = role_db:get_role_show(Src, RUid),
            Power = attrs:get_garray_power(Src, RUid, GarrayId),
            Reply = {role_show:get_name(RoleShow), role_show:get_level(RoleShow), Power,
                list_to_tuple(z_lib:tuple_foreach(garray:get_queue(Garray), Fun, [])), OSid, OLevel, Skill36},
            {'ok', [], Info, [{'msg', Reply}]};
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     获取玩家编队信息(压测用)
%% @end
%% ----------------------------------------------------
get_garray(_, _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    GarrayId = z_lib:get_value(Msg, "gid", 0),
    GarrayList = garray_lib:get_garray_ids(Src, RoleUid),
    CheckVaild = valid_lib:check_valib([{'exist', GarrayId, GarrayList}]),
    if
        CheckVaild ->
            Garray = garray_db:get_garray(Src, RoleUid, GarrayId),
            CardPropSet = storage_db:get_storage('card', Src, RoleUid),
            Study = building_db:get_study(Src, RoleUid),
            Political = building_db:get_political(Src, RoleUid),
            OfficailAttr = official_db:get_attrs(Src, RoleUid),
            Fun = fun(Acc, N, {Uid, SolidersNum}) when Uid > 0 ->
                {_, CardProp} = storage_lib:find_by_uid(CardPropSet, Uid),
                Card = prop_kit_lib:get_prop_record(CardProp),
                MaxSolidersNum = card_lib:get_max_soldiers_num(Card, Study, attrs:merge_attrs(building_db:get_political_attr(Uid, Political), OfficailAttr)),
                [{N, Uid, SolidersNum, MaxSolidersNum} | Acc];
                (Acc, _, _) ->
                    Acc
            end,
            Reply = list_to_tuple(z_lib:tuple_foreach(garray:get_queue(Garray), Fun, [])),
            {'ok', [], Info, [{'msg', Reply}]};
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     队伍内换位置
%% @end
%% ----------------------------------------------------
exchange_garray_pos([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    GarrayId = z_lib:get_value(Msg, "gid", 0),
    Pos1 = z_lib:get_value(Msg, "pos1", 0),
    Pos2 = z_lib:get_value(Msg, "pos2", 0),
    GarrayList = garray_lib:get_garray_ids(Src, RoleUid),
    CheckVaild = valid_lib:check_valib([{'unequal', Pos1, Pos2}, {'range', Pos1, {1, ?QUEUE_MAX}}, {'range', Pos2, {1, ?QUEUE_MAX}},
        {'exist', GarrayId, GarrayList}]),
    if
        CheckVaild ->
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'garray', {RoleUid, GarrayId}}]),
            Reply = z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, GarrayId, Pos1, Pos2}, TableKeys),
            {'ok', [], Info, [{'msg', Reply}]};
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.
%% ----------------------------------------------------
%% @doc
%%     队伍换武将,武将上阵
%% @end
%% ----------------------------------------------------
change_card([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    CardUid = erlang:list_to_integer(z_lib:get_value(Msg, "card_uid", "0")),%0表示下阵
    GarrayId = z_lib:get_value(Msg, "gid", 0),
    Index = z_lib:get_value(Msg, "index", 0),
    %% 如果是替换型上阵
    AlreadyGid = z_lib:get_value(Msg, "already_gid", 0),
    GarrayList = garray_lib:get_garray_ids(Src, RoleUid),
    CheckVaild = valid_lib:check_valib([{'ge', CardUid, 0}, {'range', Index, {1, ?QUEUE_MAX}}, {'exist', GarrayId, GarrayList}]),
    if
        CheckVaild ->
            Country = role_lib:get_country(Attr),
            TableName = game_lib:get_table(Src),
            if
                CardUid =:= 0 ->%下阵
                    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'garray', {RoleUid, GarrayId}},
                        {'card', RoleUid},
                        {'barracks', RoleUid, barracks:init()},
                        {'garrison', RoleUid, garrison:init()}]),
                    Reply = z_db_lib:handle(TableName, {M, 'take_off', A}, {RoleUid, GarrayId, Index}, TableKeys),
                    zm_event:notify(Src, {'power_change', Country}, [{'uid', RoleUid}, {'gid', [GarrayId]}, {'country', Country}]),
                    {'ok', [], Info, [{'msg', Reply}]};
                true ->
                    RoleLv = role_show:get_level(role_db:get_role_show(Src, RoleUid)),
                    {_, LevelConditions} = zm_config:get('garray_info', 'card_garray'),
                    IndexList = game_lib:level_value(RoleLv, LevelConditions),
                    case lists:member(Index, IndexList) of
                        false ->
                            {'ok', [], Info, [{'msg', "index_limit"}]};
                        true ->
                            {NotifyList, OtherTables} =
                                if
                                    AlreadyGid > 0 andalso AlreadyGid =/= GarrayId ->
                                        {[AlreadyGid, GarrayId], [{'garray', {RoleUid, AlreadyGid}, garray:init()}]};
                                    true ->
                                        {[GarrayId], []}
                                end,
                            TableKeys = z_db_lib:transformation_tablekey(TableName, [
                                {'garray', {RoleUid, GarrayId}, garray:init()},
                                {'card', RoleUid},
                                {'barracks', RoleUid, barracks:init()},
                                {'garrison', RoleUid, garrison:init()} | OtherTables]),
                            Study = building_db:get_study(Src, RoleUid),
                            OfficailAttr = official_db:get_attrs(Src, RoleUid),
                            Political = building_db:get_political(Src, RoleUid),
                            Reply = z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, GarrayId, CardUid, Index, Study, Political, OfficailAttr}, TableKeys),
                            %% 武将上阵事件
                            garray_db:set_garray_changed(RoleUid, NotifyList),
                            zm_event:notify(Src, {'power_change', Country}, [{'uid', RoleUid}, {'gid', NotifyList}, {'country', Country}]),
                            {'ok', [], Info, [{'msg', Reply}]}
                    end
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     军械更换
%% @end
%% ----------------------------------------------------
change_ordnance(_, _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    Sid = z_lib:get_value(Msg, "sid", 0),%=0卸载
    GId = z_lib:get_value(Msg, "gid", 0),
    GarrayList = garray_lib:get_garray_ids(Src, RoleUid),
    CheckVaild = valid_lib:check_valib([{'ge', Sid, 0}, {'exist', GId, GarrayList}]),
    if
        CheckVaild ->
            Reply = garray_db:change_ordnance(Src, RoleUid, Sid, GId, GarrayList),
            {'ok', [], Info, [{'msg', Reply}]};
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     配兵
%% @end
%% ----------------------------------------------------
set_soldiers([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    UidNums = garray_lib:analysis(z_lib:get_value(Msg, "uid_nums", "")),%uid,soldiers_num,sid,weapon_num,uid,soldiers_num,sid,weapon_num....
    GId = z_lib:get_value(Msg, "gid", 0),
    GarrayList = garray_lib:get_garray_ids(Src, RoleUid),
    CheckVaild = valid_lib:check_valib([{'unequal', UidNums, []}, {'exist', GId, GarrayList}]),
    if
        CheckVaild ->
            case lists:all(fun({_, Num1, _, Num2}) -> Num1 >= 0 andalso Num2 >= 0 end, UidNums) of
                true ->
                    Study = building_db:get_study(Src, RoleUid),
                    Political = building_db:get_political(Src, RoleUid),
                    OfficailAttr = official_db:get_attrs(Src, RoleUid),
                    CardSotrage = storage_db:get_storage('card', Src, RoleUid),
                    TableName = game_lib:get_table(Src),
                    RoleStations = station_db:get_role_stations(Src, RoleUid),
                    {TableKeys, IsStation} =
                        case lists:keyfind(GId, station:get_gid_index(), RoleStations) of
                            false ->
                                TableKeys1 = z_db_lib:transformation_tablekey(TableName, [
                                    {'garray', {RoleUid, GId}, garray:init()},
                                    {'barracks', RoleUid, barracks:init()},
                                    {'garrison', RoleUid, garrison:init()}]),
                                {TableKeys1, false};
                            Station ->
                                TableKeys1 = z_db_lib:transformation_tablekey(TableName, [
                                    {'garray', {RoleUid, GId}, garray:init()},
                                    {'barracks', RoleUid, barracks:init()},
                                    {'garrison', RoleUid, garrison:init()},
                                    {'point_march', station:get_puid(Station), point_march:init()}]),
                                {TableKeys1, true}
                        end,
                    Reply =
                        case z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, GId, UidNums, Study, CardSotrage, Political, OfficailAttr, IsStation}, TableKeys) of
                            {ok, NBarracks} ->
                                zm_log:info(Src, ?MODULE, 'set_soldiers', "set_soldiers", [{'roleuid', RoleUid}, {'gid', GId}, {'uid_nums', UidNums}, {'barracks', NBarracks}]),
                                Country = role_lib:get_country(Attr),
                                zm_event:notify(Src, {'power_change', Country}, [{'uid', RoleUid}, {'gid', GId}, {'country', Country}]),
                                "ok";
                            Error ->
                                Error
                        end,
                    {'ok', [], Info, [{'msg', Reply}]};
                false ->
                    {ok, [], Info, [{msg, "input_error"}]}
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.
%% ----------------------------------------------------
%% @doc
%%    一键配兵
%% @end
%% ----------------------------------------------------
set_soldiers_one_key(_, _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    GId = z_lib:get_value(Msg, "gid", 0),
    IsAddSoldiers = z_lib:get_value(Msg, "is_add_soldiers", 0),
    IsAddWeapon = z_lib:get_value(Msg, "is_add_weapon", 0),
    GarrayList = garray_lib:get_garray_ids(Src, RoleUid),
    CheckVaild = valid_lib:check_valib([{'exist', GId, GarrayList}]),
    if
        CheckVaild ->
            Study = building_db:get_study(Src, RoleUid),
            Political = building_db:get_political(Src, RoleUid),
            OfficialAttr = official_db:get_attrs(Src, RoleUid),
            CardSotrage = storage_db:get_storage('card', Src, RoleUid),
            R = garray_db:auto_add_soldiers(Src, RoleUid, GId, Study, CardSotrage, Political, OfficialAttr, true, IsAddSoldiers =:= 1, IsAddWeapon =:= 1, false),
            {'ok', [], Info, [{'msg', R}]};
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     36计设置
%% @end
%% ----------------------------------------------------
set_skill36(_, _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    GId = z_lib:get_value(Msg, "gid", 0),
    Index = z_lib:get_value(Msg, "index", 0),
    Sid = z_lib:get_value(Msg, "sid", 0),
    GarrayList = garray_lib:get_garray_ids(Src, RoleUid),
    CheckVaild = valid_lib:check_valib([{'ge', Sid, 0}, {'range', Index, {1, 2}}, {'exist', GId, GarrayList}]),
    if
        CheckVaild ->
            Reply = garray_db:set_skill36(Src, RoleUid, Index, Sid, GId, GarrayList),
            {'ok', [], Info, [{'msg', Reply}]};
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     根据gid,获取玩家编队信息
%% @end
%% ----------------------------------------------------
get_garray_by_gid(_, _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    GarrayId = z_lib:get_value(Msg, "gid", 0),
    GarrayList = garray_lib:get_garray_ids(Src, RoleUid),
    CheckVaild = valid_lib:check_valib([{'exist', GarrayId, GarrayList}]),
    if
        CheckVaild ->
            RoleShow = role_db:get_role_show(Src, RoleUid),
            PointUid = role_show:get_point(RoleShow),
            {_, Array, _, _, _} = fight_db:role_online(Src, RoleUid, PointUid, [GarrayId], false, {}),
            {'ok', [], Info, [{'msg', list_to_tuple(Array)}]};
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%        设置自己驻防部队自动补兵
%% @end
%% ----------------------------------------------------
set_auto_add_soldier([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    AutoAddSoldier = z_lib:get_value(Msg, "v", 0),
    GId = z_lib:get_value(Msg, "gid", 0),
    GarrayList = garray_lib:get_garray_ids(Src, RoleUid),
    CheckVaild = valid_lib:check_valib([{'range', AutoAddSoldier, {0, 1}}, {'exist', GId, GarrayList}]),
    if
        CheckVaild ->
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'garray', {RoleUid, GId}, garray:init()}]),
            B = z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, AutoAddSoldier}, TableKeys),
            R = if
                B andalso AutoAddSoldier =:= 1 ->
                    Study = building_db:get_study(Src, RoleUid),
                    OfficailAttr = official_db:get_attrs(Src, RoleUid),
                    CardStorage = storage_db:get_storage('card', Src, RoleUid),
                    Political = building_db:get_political(Src, RoleUid),
                    garray_db:auto_add_soldiers(Src, RoleUid, GId, Study, CardStorage, Political, OfficailAttr, true, true, true, true),
                    ok;
                true ->
                    ok
            end,
            {ok, [], Info, [{msg, R}]};
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------