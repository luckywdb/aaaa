-module(garray_lib).

%%%=======================STATEMENT====================
-description("garray_lib").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_garray_ids/2, check/3, is_no_soldiers/1, get_max_gid/0]).
-export([analysis/1, calc_injured/1]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================
-define(MAX_GID, 4).%最大gid,如果策划新增gid则需要修改

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%      获取所有编队id
%% @end
%% ----------------------------------------------------
-spec get_garray_ids(Src :: atom(), RoleUid :: integer()) -> [integer()].
get_garray_ids(Src, RoleUid) ->
    List = get_cfg_garray_list(),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    [Id || {Id, Condition} <- List, game_lib:checks({?MODULE, 'check'}, {Src, RoleUid, RoleShow}, 'change_card', Condition) =:= true].

%% ----------------------------------------------------
%% @doc
%%      检测各条件
%% @end
%% ----------------------------------------------------
-spec check(_, tuple(), tuple()) -> boolean().
check({_Src, _RoleUid, RoleShow}, 'change_card', {role_lv, Lv}) ->
    role_show:get_level(RoleShow) >= Lv;
check({Src, RoleUid}, _, {'building_sid', {NeedSid, NeedLv}}) ->%设置36计时候需要计略府等级,军械时候军械所等级
    Castle = castle_db:get_castle(Src, RoleUid),
    Building = castle:get_building(Castle),
    case lists:keyfind(NeedSid, 2, Building) of
        false ->
            false;
        {_, _, Lv, _} ->
            Lv >= NeedLv
    end;
check(_, _, _) ->
    false.

%% ----------------------------------------------------
%% @doc
%%      没有带兵
%% @end
%% ----------------------------------------------------
-spec is_no_soldiers(garray:garray()) -> boolean().
is_no_soldiers(Garray) ->
    Queue = garray:get_queue(Garray),
    Fun = fun(A, _, {_, N}) ->
        if
            N > 0 ->
                {'break', false};
            true ->
                {ok, A}
        end
    end,
    z_lib:tuple_foreach(Queue, Fun, true).

%% ----------------------------------------------------
%% @doc
%%      最大队伍个数(gid)
%% @end
%% ----------------------------------------------------
-spec get_max_gid() -> integer().
get_max_gid() ->
    ?MAX_GID.

%%-------------------------------------------------------------------
%% @doc
%%      解析前台传入数据，"card_uid,num,weapon_sid,num,card_uid,num,weapon_sid,num..."
%% @end
%%-------------------------------------------------------------------
-spec analysis(Str :: string()) -> list().
analysis(Str) ->
    analysis_(string:tokens(Str, ","), []).
analysis_([CardUid, SoilderNum, WeaponSid, WeaponNum | T], R) ->
    analysis_(T, [{list_to_integer(CardUid), list_to_integer(SoilderNum), list_to_integer(WeaponSid), list_to_integer(WeaponNum)} | R]);
analysis_([], R) -> %%合并一次,key相同的值
    lists:reverse(R);
analysis_(_, _) -> %%格式不正确返回[]
    [].

%%-------------------------------------------------------------------
%% @doc
%%      计算伤兵总和
%% @end
%%-------------------------------------------------------------------
calc_injured(GarrayInjured) ->
    F = fun(Total, _, {Soldiers, _Weapons}) ->
        {ok, Total + Soldiers}
    end,
    z_lib:tuple_foreach(GarrayInjured, F, 0).
%%%===================LOCAL FUNCTIONS=============；=====
%% ----------------------------------------------------
%% @doc
%%      得到队伍配置文件
%% @end
%% ----------------------------------------------------
-spec get_cfg_garray_list() -> list().
get_cfg_garray_list() ->
    {_, GarrayList} = zm_config:get('garray_info', 'garray_max'),
    GarrayList.