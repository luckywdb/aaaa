-module(garray_event).

%%%=======================STATEMENT====================
-description("garray_event").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([notify/4]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      官职变化,任命变化,更新阵型数据
%% @end
%% ----------------------------------------------------
notify(_A, Src, {'official_update_garray', _}, Args) -> %% 更新玩家战斗力
    {_, RoleUid} = lists:keyfind('uid', 1, Args),
    {_, Gids1} = lists:keyfind('gid', 1, Args),
    if
        Gids1 =:= [] ->
            ok;
        true ->
            Gids = lists:usort(Gids1),
            {NewGarrayChanges, NewBarracks, ChangeNum1} = garray_db:officail_update_garray(Src, RoleUid, Gids),
            if
                ChangeNum1 > 0 ->
                    BStations = barracks:get_stations(NewBarracks),
                    StationGarrayChange =
                        z_lib:foreach(fun(Acc, {GId, _}) ->
                            case lists:keyfind(GId, barracks:get_station_gid_index(), BStations) of
                                false ->
                                    {ok, Acc};
                                Bs ->
                                    {ok, [{GId, barracks:get_station_leisure(Bs), list_to_tuple(barracks:get_weapon(NewBarracks, GId))} | Acc]}
                            end
                        end, [], NewGarrayChanges),
                    Reply = {list_to_tuple(NewGarrayChanges), barracks:get_leisure(NewBarracks),
                        barracks:get_occupy(NewBarracks), list_to_tuple(StationGarrayChange), list_to_tuple(barracks:get_weapon(NewBarracks))},
                    set_front_lib:send_garray_change(Src, RoleUid, Reply);
                true ->
                    'ok'
            end,
            'ok'
    end.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
