-module(garray_db).

%%%=======================STATEMENT====================
-description("编队阵型").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([format_garray/4, check_sids/3, award_card_oneexp/5, award_card_allexp/5, auto_add_soldiers/11]).
-export([get_garray/3, take_off/3, change_card/3, change_ordnance/5, set_soldiers/3, set_skill36/6, get_garray_bearload/3]).
-export([exchange_garray_pos/3]).
-export([set_auto_add_soldier/3, get_max_charm/3, set_garray_changed/2, get_garray_changed/1]).
-export([get_garray_soldiers/3]).
-export([clear_weapon_error/5]).
-export([officail_update_garray/3]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================
-define(GARRAY_CHANGED, '$garray_changed').

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%     格式化阵型显示数据 Array={队伍id,队伍详细信息(garray.erl),队伍状态/0空闲/1行军中/2返回城堡中/3主城驻守/4盟友主城驻守,起点uid,终点uid,速度,开始时间,结束时间,类型(友军支援)}}
%% @end
%% ----------------------------------------------------
-spec format_garray(Src, RoleUid, RPUid, CardStorage) -> {tuple(), tuple(), garrison:garrison(), RoleStations} when
    Src :: atom(),
    RoleUid :: integer(),
    RPUid :: integer(),
    RoleStations :: list(),
    CardStorage :: tuple().
format_garray(Src, RoleUid, RPUid, CardStorage) ->
    GarrayIds = garray_lib:get_garray_ids(Src, RoleUid),
    {FightLines, Array, Garrison, RoleStations, RoleMapBuild} = fight_db:role_online(Src, RoleUid, RPUid, GarrayIds, true, CardStorage),
    {FightLines, list_to_tuple(Array), Garrison, RoleStations, RoleMapBuild}.

%% ----------------------------------------------------
%% @doc
%%     判断sid的武将是否已经上阵(true=已经上阵,false=未上阵)
%% @end
%% ----------------------------------------------------
-spec check_sids(UpCardUid :: integer(),
        CardSotrage :: tuple(),
        Sid :: integer()) ->
    boolean().
check_sids(UpCardUid, CardSotrage, Sid) ->
    F = fun(Bool, _, Prop) ->
        PSid = prop_kit_lib:get_prop_sid(Prop),
        if
            PSid =:= Sid ->
                PUid = prop_kit_lib:get_prop_uid(Prop),
                Card = prop_kit_lib:get_prop_record(Prop),
                State = card:get_state(Card),
                if
                    PUid =:= UpCardUid andalso State > 0 ->
                        {'break', Bool};
                    State > 0 ->
                        {'break', true};
                    true ->
                        {'ok', Bool}
                end;
            true ->
                {'ok', Bool}
        end
    end,
    z_lib:tuple_foreach(CardSotrage, F, false).

%% ----------------------------------------------------
%% @doc
%%     获取编队信息
%% @end
%% ----------------------------------------------------
-spec get_garray(Src, RoleUid, GId) -> garray:garray()|[{integer(), garray:garray()}] when
    Src :: atom(),
    RoleUid :: integer(),
    GId :: integer()|[integer()].
get_garray(Src, RoleUid, GId) when is_integer(GId) ->
    z_db_lib:get(game_lib:get_table(Src, 'garray'), {RoleUid, GId}, garray:init());
get_garray(Src, RoleUid, GIds) when is_list(GIds) ->
    Garrays = z_db_lib:gets(game_lib:get_table(Src, 'garray'), [{RoleUid, GId} || GId <- GIds], 'none'),
    lists:filter(fun({_, Garray}) ->
        Garray =/= 'none' end,
        lists:zip(GIds, Garrays)).

%% ----------------------------------------------------
%% @doc
%%     下阵
%% @end
%% ----------------------------------------------------
-spec take_off(_, {integer(), integer(), integer()}, list()) -> string()|tuple().
take_off(_, {_RoleUid, GId, Index}, [{Index1, GArray}, {Index2, CardStorage}, {Index3, Barracks}, {Index4, Garrison}]) ->
    Queue = garray:get_queue(GArray),
    Idle = garray:check_idle(GArray),
    if
        Idle ->
            case element(Index, Queue) of
                {0, _} ->
                    throw("ok");
                {TakeCardUid, Num} ->
                    Queue1 = setelement(Index, Queue, {0, 0}),
                    Weapons = garray:get_weapon(GArray),
                    {OWeaponSid, OWeaponNum} = element(Index, Weapons),
                    Weapons1 = setelement(Index, Weapons, {0, 0}),
                    ResGArray1 = garray:set_weapon(garray:set_queue(GArray, Queue1), Weapons1),

                    ResCardStorage = down_card_storage(CardStorage, TakeCardUid),
                    ResBarracks1 = barracks:up_soldiers(Barracks, GId, -Num),
                    ResBarracks = barracks:update_weapons(ResBarracks1, OWeaponSid, OWeaponNum),
                    Bool = z_lib:tuple_foreach(Queue1, fun(R, _, {Uid, _}) ->
                        case Uid =/= 0 of
                            true ->
                                {'break', false};
                            false ->
                                {ok, R}
                        end
                    end, true),
                    ResGArray =
                        case Bool of
                            true ->
                                garray:set_auto_add_soldier(ResGArray1, 0);
                            false ->
                                ResGArray1
                        end,
                    %队伍状态=3为主城驻防,但主城驻防=0,
                    Update =
                        case (garrison:get_ogid(Garrison) =:= GId orelse (garrison:get_ogid(Garrison) =:= 0 andalso garray:get_state(GArray) =:= 3)) andalso check_queue_null(Queue1) of
                            true ->
                                [{Index1, garray:set_state(ResGArray, 0)}, {Index2, ResCardStorage},
                                    {Index3, ResBarracks}, {Index4, garrison:set_ogid(Garrison, 0)}];
                            false ->
                                [{Index1, ResGArray}, {Index2, ResCardStorage}, {Index3, ResBarracks}]
                        end,
                    {ok, "ok", Update}
            end;
        true ->
            throw("garray_not_idle")
    end.

%% ----------------------------------------------------
%% @doc
%%     队伍内换位置
%% @end
%% ----------------------------------------------------
-spec exchange_garray_pos(term(), tuple(), list()) -> string()|tuple().
exchange_garray_pos(_A, {_Src, _RoleUid, _GarrayId, Pos1, Pos2}, [{Index1, GArray}]) ->
    Idle = garray:check_idle(GArray),
    if
        Idle ->
            Queue = garray:get_queue(GArray),
            NQueue1 = setelement(Pos1, Queue, element(Pos2, Queue)),
            NQueue2 = setelement(Pos2, NQueue1, element(Pos1, Queue)),
            NGarray1 = garray:set_queue(GArray, NQueue2),

            Weapon = garray:get_weapon(GArray),
            NWeapon1 = setelement(Pos1, Weapon, element(Pos2, Weapon)),
            NWeapon2 = setelement(Pos2, NWeapon1, element(Pos1, Weapon)),
            NGarray = garray:set_weapon(NGarray1, NWeapon2),
            {ok, ok, [{Index1, NGarray}]};
        true ->
            throw("garray_not_idle")
    end.

%% ----------------------------------------------------
%% @doc
%%     上阵或更换
%% @end
%% ----------------------------------------------------
-spec change_card(term(), tuple(), list()) -> string()|tuple().
change_card(_A, {_Src, _RoleUid, GId, UpCardUid, ChangeIndex, Study, Political, OfficailAttr}, [{Index1, GArray}, {Index2, CardStorage}, {Index3, Barracks}, {Index4, Garrison} | T]) ->
    Queue = garray:get_queue(GArray),
    Idle = garray:check_idle(GArray),
    if
        Idle ->
            case element(ChangeIndex, Queue) of
                {UpCardUid, _} ->
                    {ok, "ok"};
                {CardUid, _} ->
                    case storage_lib:find_by_uid(CardStorage, UpCardUid) of
                        UpCardUid ->
                            throw("no_card");
                        {Index, Prop} ->
                            NewCardStorage = down_card_storage(CardStorage, CardUid),
                            Card = prop_kit_lib:get_prop_record(Prop),
                            SoldiersType = card:get_soldiers_type(Card),
                            %%  阵位1,2,3只能上阵盾兵,枪兵,骑兵;
                            %%  阵位4,5,6只能上阵弓兵.
                            if
                                (SoldiersType =< 3 andalso ChangeIndex =< 3) orelse (SoldiersType > 3 andalso ChangeIndex > 3) ->
                                    Sid = prop_kit_lib:get_prop_sid(Prop),
                                    SameSid = check_sids(UpCardUid, CardStorage, Sid),
                                    if
                                        SameSid ->
                                            throw("exist_same_card_sid");
                                        true ->
                                            {NGArray1, NBarracks1, NGarrison, UpdateList} =
                                                case card:get_state(Card) of
                                                    0 ->
                                                        {Garray1, Barracks1} = down_card_queue(GId, Queue, CardUid, GArray, Barracks),
                                                        {Garray1, Barracks1, Garrison, []};
                                                    GId ->
                                                        {Garray1, Barracks1} = down_card_queue(GId, Queue, CardUid, GArray, Barracks),
                                                        {Garray2, Barracks2} = down_card_queue(GId, Queue, UpCardUid, Garray1, Barracks1),
                                                        {Garray2, Barracks2, Garrison, []};
                                                    CGid ->
                                                        case T of
                                                            [] ->
                                                                throw("card_not_up");
                                                            [{Index5, OldGarray}] ->
                                                                case garray:check_idle(OldGarray) of
                                                                    true ->
                                                                        {Garray1, Barracks1} = down_card_queue(GId, Queue, CardUid, GArray, Barracks),
                                                                        OldQueue = garray:get_queue(OldGarray),
                                                                        {NOldGarray, Barracks2} = down_card_queue(CGid, OldQueue, UpCardUid, OldGarray, Barracks1),
                                                                        case garrison:get_ogid(Garrison) =:= CGid andalso check_queue_null(garray:get_queue(NOldGarray)) of
                                                                            true ->
                                                                                {Garray1, Barracks2, garrison:set_ogid(Garrison, 0), [{Index5, garray:set_state(NOldGarray, 0)}]};
                                                                            false ->
                                                                                {Garray1, Barracks2, Garrison, [{Index5, NOldGarray}]}
                                                                        end;
                                                                    _ ->
                                                                        throw("garray_not_idle")
                                                                end
                                                        end
                                                end,
                                            Soldiers = card_lib:get_max_soldiers_num(Card, Study, attrs:merge_attrs(building_db:get_political_attr(UpCardUid, Political), OfficailAttr)),
                                            Leisure = barracks:get_leisure(NBarracks1),
                                            AddSNum = if
                                                Soldiers > Leisure ->
                                                    Leisure;
                                                true ->
                                                    Soldiers
                                            end,
                                            {NBarrack2, NGArray2} =
                                                case barracks:get_weapon_sidandnum_by_type_in_barracks(NBarracks1, card:get_soldiers_type(Card)) of
                                                    {0, _} ->
                                                        {NBarracks1, NGArray1};
                                                    {WSid, WNum} ->
                                                        AddWSum = min(WNum, AddSNum),
                                                        {barracks:update_weapons(NBarracks1, WSid, -AddWSum),
                                                            garray:set_weapon(NGArray1, setelement(ChangeIndex, garray:get_weapon(NGArray1), {WSid, AddWSum}))}
                                                end,
                                            NBarracks = barracks:up_soldiers(NBarrack2, GId, AddSNum),
                                            NewProp = prop_kit_lib:set_prop_record(Prop, card:set_state(Card, GId)),
                                            NCardStorage1 = storage_lib:update_by_index(NewCardStorage, Index, NewProp),
                                            NGarray = garray:set_queue(NGArray2, setelement(ChangeIndex, garray:get_queue(NGArray2), {UpCardUid, AddSNum})),
                                            UpTable =
                                                if
                                                    NGarrison =/= Garrison ->%没有数据存在,给的默认值时候,不去写数据库了
                                                        [{Index4, NGarrison}];
                                                    true ->
                                                        []
                                                end,
                                            {ok, "ok", UpTable ++ [{Index1, NGarray}, {Index2, NCardStorage1}, {Index3, NBarracks} | UpdateList]}
                                    end;
                                true ->
                                    throw("garray_soldier_type_limit")
                            end
                    end
            end;
        true ->
            throw("garray_not_idle")
    end.

%% ----------------------------------------------------
%% @doc
%%     军械更换
%% @end
%% ----------------------------------------------------
-spec change_ordnance(Src, RoleUid, Sid, GId, GarrayList) -> string()|tuple() when
    Src :: atom(),
    RoleUid :: integer(),
    Sid :: integer(),
    GId :: integer(),
    GarrayList :: [integer()].
change_ordnance(Src, RoleUid, 0, GId, _GarrayList) ->%卸载
    Fun = fun(_, Garray) ->
        Idle = garray:check_idle(Garray),
        if
            Idle ->
                {'ok', "ok", garray:set_ordnance(Garray, 0)};
            true ->
                throw("garray_not_idle")
        end
    end,
    z_db_lib:update(game_lib:get_table(Src, 'garray'), {RoleUid, GId}, garray:init(), Fun, []);
change_ordnance(Src, RoleUid, Sid, GId, GarrayList) ->%上阵
    Conditions = element(2, zm_config:get('garray_info', 'ordnance')),
    Bool = game_lib:checks({'garray_lib', 'check'}, {Src, RoleUid}, 'change_ordnance', Conditions),
    if
        Bool ->
            OrdnanceList1 = lists:foldl(fun(Garrayid, Acc0) ->
                [{Garrayid, garray:get_ordnance(get_garray(Src, RoleUid, Garrayid))} | Acc0]
            end, [], GarrayList),
            TableName = game_lib:get_table(Src),
            TableKeys =
                case lists:keyfind(Sid, 2, OrdnanceList1) of
                    false ->
                        z_db_lib:transformation_tablekey(TableName, [{'garray', {RoleUid, GId}, garray:init()}]);
                    {OGId, _} ->
                        z_db_lib:transformation_tablekey(TableName, [{'garray', {RoleUid, GId}, garray:init()},
                            {'garray', {RoleUid, OGId}, garray:init()}])
                end,
            Study = building_db:get_study(Src, RoleUid),
            Fun = fun(_, [{Index1, Garray} | T]) ->
                Idle = garray:check_idle(Garray),
                if
                    Idle ->
                        OrdnanceList = z_lib:get_value(Study, building_lib:get_bsid('ordnance'), []),
                        case lists:keyfind(Sid, 1, OrdnanceList) of
                            false ->
                                throw("no_ordnance");
                            _ ->
                                case length(T) > 0 of
                                    true ->
                                        [{Index2, OldG}] = T,
                                        case garray:check_idle(OldG) of
                                            true ->
                                                {'ok', "ok", [{Index1, garray:set_ordnance(Garray, Sid)}, {Index2, garray:set_ordnance(OldG, 0)}]};
                                            false ->
                                                throw("garray_not_idle")
                                        end;
                                    false ->
                                        {'ok', "ok", [{Index1, garray:set_ordnance(Garray, Sid)}]}
                                end
                        end;
                    true ->
                        throw("garray_not_idle")
                end
            end,
            z_db_lib:handle(TableName, Fun, [], TableKeys);
        true ->
            Bool
    end.

%% ----------------------------------------------------
%% @doc
%%     配兵,一键配兵
%% @end
%% ----------------------------------------------------
-spec set_soldiers(term(), tuple(), list()) -> string()|tuple().
set_soldiers(_A, {_Src, RoleUid, GId, UidNums, Study, CardStorage, Political, OfficialAttr, IsStation},
        [{Index1, GArray}, {Index2, Barracks}, {Index3, Garrison} | T]) ->
    Idle = check_idle(RoleUid, GId, T, GArray, IsStation, true),
    if
        Idle ->
            Queue = garray:get_queue(GArray),
            Weapon = garray:get_weapon(GArray),
            Fun = fun
                (Args, _, {0, _}) ->
                    {'ok', Args};
                ({RCSoilderNum, NWeapon1, CQueue} = Args, Index, {CardUid, OSoilderNum}) ->
                    case lists:keyfind(CardUid, 1, UidNums) of
                        false ->
                            {'ok', Args};
                        {_, CSoilderNum, _CWeaponSid, CWeaponNum} when CSoilderNum < CWeaponNum ->
                            throw("weapons_are_more_than_soldiers");
                        {_, CSoilderNum, CWeaponSid, CWeaponNum} ->
                            {_, Prop} = storage_lib:find_by_uid(CardStorage, CardUid),
                            Card = prop_kit_lib:get_prop_record(Prop),
                            CardMaxSoldiers = card_lib:get_max_soldiers_num(Card, Study, attrs:merge_attrs(building_db:get_political_attr(CardUid, Political), OfficialAttr)),
                            if
                                CardMaxSoldiers >= CSoilderNum ->
                                    NW =
                                        if
                                            CWeaponSid =:= 0 ->
                                                setelement(Index, NWeapon1, {0, 0});
                                            CWeaponNum =:= 0 ->
                                                setelement(Index, NWeapon1, {CWeaponSid, 0});
                                            true ->
                                                CardType = card:get_soldiers_type(Card),
                                                CWType = barracks:get_weapon_type_bysid(CWeaponSid),
                                                if
                                                    CardType =:= CWType ->
                                                        setelement(Index, NWeapon1, {CWeaponSid, CWeaponNum});
                                                    true ->
                                                        throw("type_error")
                                                end
                                        end,
                                    {'ok', {RCSoilderNum + CSoilderNum - OSoilderNum, NW, setelement(Index, CQueue, {CardUid, CSoilderNum})}};
                                true ->
                                    throw("card_soldiers_limit")
                            end
                    end
            end,
            {ChangeSoilderValue, NWeapon, NQueue} = z_lib:tuple_foreach(Queue, Fun, {0, Weapon, Queue}),
            Fun1 = fun(A, {Sid, Num}) ->
                case Num > z_lib:get_value(A, Sid, 0) of
                    true ->
                        throw("leisure_weapon_not_enough");
                    false ->
                        {ok, A}
                end
            end,
            %%根据上面得到的改变兵器去兵器库或者阵容上检测数量是否足够
            if
                IsStation ->
                    z_lib:foreach(Fun1, game_lib:merge_kv(tuple_to_list(Weapon), []), game_lib:merge_kv(tuple_to_list(NWeapon), []));
                true ->
                    z_lib:foreach(Fun1, game_lib:merge_kv(tuple_to_list(Weapon), barracks:get_weapon(Barracks)), game_lib:merge_kv(tuple_to_list(NWeapon), []))
            end,
            Leisure = barracks:get_leisure(GId, Barracks),
            if
                Leisure >= ChangeSoilderValue ->
                    NBarracks = barracks:update_barracks_weapon(Barracks, GId, Weapon, NWeapon),
                    NewBarracks = barracks:up_soldiers(NBarracks, GId, ChangeSoilderValue),
                    Update =
                        case garrison:get_ogid(Garrison) =:= GId andalso check_queue_null(NQueue) of
                            true ->
                                [{Index1, garray:set_state(garray:set_queue(garray:set_weapon(GArray, NWeapon), NQueue), 0)}, {Index2, NewBarracks},
                                    {Index3, garrison:set_ogid(Garrison, 0)}];
                            false ->
                                [{Index1, garray:set_queue(garray:set_weapon(GArray, NWeapon), NQueue)}, {Index2, NewBarracks}]
                        end,

                    {'ok', {ok, NewBarracks}, Update};
                true ->
                    throw("leisure_limit")
            end;
        true ->
            throw("garray_not_idle")
    end.

%% ----------------------------------------------------
%% @doc
%%     自动配兵
%% @end
%% ----------------------------------------------------
-spec auto_add_soldiers(atom(), integer(), integer(), list(), tuple(), [fighter:attr()], [fighter:attr()], boolean(), boolean(), boolean(), boolean()) -> string()|tuple().
auto_add_soldiers(Src, RoleUid, GId, Study, CardStorage, Political, OfficialAttr, IsCheckFight, IsAddSoilders, IsAddWeapons, IsPush) ->
    TableName = game_lib:get_table(Src),
    RoleStations = station_db:get_role_stations(Src, RoleUid),
    {TableKeys, IsStation} =
        case lists:keyfind(GId, station:get_gid_index(), RoleStations) of
            false ->
                TableKeys1 = z_db_lib:transformation_tablekey(TableName, [
                    {'garray', {RoleUid, GId}, garray:init()},
                    {'barracks', RoleUid, barracks:init()}
                ]),
                {TableKeys1, false};
            Station ->
                TableKeys1 = z_db_lib:transformation_tablekey(TableName, [
                    {'garray', {RoleUid, GId}, garray:init()},
                    {'barracks', RoleUid, barracks:init()},
                    {'point_march', station:get_puid(Station), point_march:init()}
                ]),
                {TableKeys1, true}
        end,
    case z_db_lib:handle(TableName, fun auto_add_soldiers_/2, {Src, RoleUid, GId, Study, CardStorage, Political, OfficialAttr, IsStation, IsCheckFight andalso IsStation, IsAddSoilders, IsAddWeapons}, TableKeys) of
        {ok, NQueue, NBarracks, NWeapon} ->
            NLeisure = barracks:get_leisure(GId, NBarracks),
            NCardOccNum = barracks:get_occupy(NBarracks),
            zm_log:info(Src, ?MODULE, 'auto_add_soldiers', "auto_add_soldiers", [{'roleuid', RoleUid}, {'gid', GId}, {'new_queue', NQueue},
                {'barracks', NBarracks}]),
            RoleShow = role_db:get_role_show(Src, RoleUid),
            Country = role_show:get_country(RoleShow),
            zm_event:notify(Src, {'power_change', Country}, [{'uid', RoleUid}, {'gid', GId}, {'country', Country}]),
            if
                IsPush ->
                    set_front_lib:send_garray_auto_add_soldiers(Src, RoleUid, {GId, NQueue, NLeisure, NCardOccNum, NWeapon, list_to_tuple(barracks:get_weapon(NBarracks, GId))}),
                    ok;
                true ->
                    {GId, NQueue, NLeisure, NCardOccNum, NWeapon, list_to_tuple(barracks:get_weapon(NBarracks))}
            end;
        Other ->
            Other
    end.

%% ----------------------------------------------------
%% @doc
%%     36计设置
%% @end
%% ----------------------------------------------------
-spec set_skill36(Src, RoleUid, Index, Sid, GId, GarrayList) -> string()|tuple() when
    Src :: atom(),
    RoleUid :: integer(),
    Index :: integer(),
    Sid :: integer(),
    GId :: integer(),
    GarrayList :: [integer()].
set_skill36(Src, RoleUid, Index, 0, GId, _GarrayList) ->%卸载
    Fun = fun(_, Garray) ->
        Idle = garray:check_idle(Garray),
        if
            Idle ->
                NSkill36 = erlang:setelement(Index, garray:get_skill36(Garray), 0),
                {'ok', "ok", garray:set_skill36(Garray, NSkill36)};
            true ->
                throw("garray_not_idle")
        end
    end,
    z_db_lib:update(game_lib:get_table(Src, 'garray'), {RoleUid, GId}, garray:init(), Fun, []);
set_skill36(Src, RoleUid, Index, Sid, GId, GarrayList) ->%上阵
    Conditions = z_lib:get_value(element(2, zm_config:get('garray_info', 'skill36_garray')), Index, []),
    Bool = game_lib:checks({'garray_lib', 'check'}, {Src, RoleUid}, 'set_skill36', Conditions),
    if
        Bool ->
            Study = building_db:get_study(Src, RoleUid),
            Skill36List = z_lib:get_value(Study, building_lib:get_bsid('skill36'), []),
            case lists:keyfind(Sid, 1, Skill36List) of
                false ->
                    throw("no_skill36");
                _ ->
                    UpSkills = lists:append(
                        [begin G = get_garray(Src, RoleUid, Garrayid),
                        tuple_to_list(garray:get_skill36(G))
                        end || Garrayid <- lists:delete(GId, GarrayList)]),
                    Fun = fun(_, Garray) ->
                        Idle = garray:check_idle(Garray),
                        if
                            Idle ->
                                AllSkill = garray:get_skill36(Garray),
                                BoolExist = lists:member(Sid, tuple_to_list(AllSkill) ++ UpSkills),
                                if
                                    BoolExist ->
                                        throw("skill36_exist");
                                    true ->
                                        NSkill36 = erlang:setelement(Index, AllSkill, Sid),
                                        {'ok', "ok", garray:set_skill36(Garray, NSkill36)}
                                end;
                            true ->
                                throw("garray_not_idle")
                        end
                    end,
                    z_db_lib:update(game_lib:get_table(Src, 'garray'), {RoleUid, GId}, garray:init(), Fun, [])
            end;
        true ->
            Bool
    end.

%% ----------------------------------------------------
%% @doc
%%     奖励阵型武将经验,科技等加成在外部计算.
%% @end
%% ----------------------------------------------------
award_card_oneexp(_, _, _, AddExp, _) when AddExp =< 0 ->
    'ok';
award_card_oneexp(Src, RoleUid, GarrayId, AddExp, Sid) ->
    Garray = get_garray(Src, RoleUid, GarrayId),
    Queue = garray:get_queue(Garray),
    award_card_oneexp_(Queue, Src, RoleUid, AddExp, GarrayId, Sid).

award_card_oneexp_(Queue, Src, RoleUid, AddExp, GarrayId, Sid) ->
    CardUidList = [CUid || {CUid, _} <- tuple_to_list(Queue), CUid =/= 0],
    RoleShow = role_db:get_role_show(Src, RoleUid),
    RoleLevel = role_show:get_level(RoleShow),
    Fun = fun(_, CardSet) ->
        {CardPropTups, NCardSet} = card_lib:add_exp(CardSet, CardUidList, AddExp, RoleLevel),
        {ok, {ok, CardPropTups}, NCardSet}
    end,
    {ok, CardPropTups} = z_db_lib:update(game_lib:get_table(Src, 'card'), RoleUid, Fun, []),
    {NCardPropList, IsUpLevel} = lists:foldl(fun({OldCardProp, NewCardProp}, {Acc, Bool}) ->
        UpBool = card:get_level(prop_kit_lib:get_prop_record(NewCardProp)) > card:get_level(prop_kit_lib:get_prop_record(OldCardProp)),
        if
            UpBool ->
                {[NewCardProp | Acc], Bool orelse UpBool};
            true ->
                {Acc, Bool orelse UpBool}
        end
    end, {[], false}, CardPropTups),
    if
        IsUpLevel ->
            Country = role_show:get_country(RoleShow),
            zm_event:notify(Src, {'power_change', Country}, [{'uid', RoleUid}, {'gid', GarrayId}, {'country', Country}]),
            zm_event:notify(Src, 'bi_garray_card_up_exp', [{'role_uid', RoleUid}, {'new_card_list', NCardPropList}, {'sid', Sid}]),
            ok;
        true ->
            ok
    end.

%% ----------------------------------------------------
%% @doc
%%     奖励阵型武将经验,(已增加了,科技等加成)
%% @end
%% ----------------------------------------------------
-spec award_card_allexp(Src, RoleUid, GarrayId, AddExp, Sid) -> integer() when
    Src :: atom(),
    RoleUid :: integer(),
    GarrayId :: integer(),
    AddExp :: integer(),
    Sid :: integer().
award_card_allexp(_, _, _, AllExp, _) when AllExp =< 0 ->
    0;
award_card_allexp(Src, RoleUid, GarrayId, AllExp, Sid) ->
    Garray = get_garray(Src, RoleUid, GarrayId),
    Queue = garray:get_queue(Garray),
    CardUidList = [CUid || {CUid, _} <- tuple_to_list(Queue), CUid =/= 0],
    OneExp = role_addition:get_card_exp(Src, RoleUid, AllExp) div length(CardUidList),
    award_card_oneexp_(Queue, Src, RoleUid, OneExp, GarrayId, Sid),
    OneExp.

%% ----------------------------------------------------
%% @doc
%%      得到阵型基础负重{士兵,军械}
%% @end
%% ----------------------------------------------------
-spec get_garray_bearload(atom(), integer(), integer()) -> {integer(), integer()}.
get_garray_bearload(Src, RoleUid, GId) ->
    Garray = get_garray(Src, RoleUid, GId),
    PropSet = storage_db:get_storage('card', Src, RoleUid),
    OBL = attrs:get_ordnance_bear_load(Src, RoleUid, Garray),
    Fun = fun(A, _, {Uid, Num}) ->
        if
            Uid =:= 0 orelse Num =:= 0 ->
                {ok, A};
            true ->
                {_, Prop} = storage_lib:find_by_uid(PropSet, Uid),
                NewStar = card:get_new_star(prop_kit_lib:get_prop_record(Prop)),
                BL = attrs:get_soldier_bear_load(NewStar),
                {ok, A + Num * BL div 10000}
        end
    end,
    GBL = z_lib:tuple_foreach(garray:get_queue(Garray), Fun, 0),
    {GBL, OBL div 10000}.


%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
-spec set_auto_add_soldier(_, tuple(), list()) -> tuple().
set_auto_add_soldier(_, {_Src, _RoleUid, AutoAddSoldier}, [{Index1, Garray}]) ->
    OldAutoAddSoldier = garray:get_auto_add_soldier(Garray),
    if
        OldAutoAddSoldier =:= AutoAddSoldier ->
            {ok, false};
        true ->
            NGarrison = garray:set_auto_add_soldier(Garray, AutoAddSoldier),
            {ok, true, [{Index1, NGarrison}]}
    end.

%% ----------------------------------------------------
%% @doc
%%  记录阵型变化
%% @end
%% ----------------------------------------------------
set_garray_changed(RoleUid, GIds) ->
    case zm_config:get(?GARRAY_CHANGED, RoleUid) of
        none ->
            zm_config:set(?GARRAY_CHANGED, {RoleUid, GIds});
        {_, List} ->
            zm_config:set(?GARRAY_CHANGED, {RoleUid, lists:usort(GIds ++ List)})
    end.

%% ----------------------------------------------------
%% @doc
%%  获取阵型变化
%% @end
%% ----------------------------------------------------
get_garray_changed(RoleUid) ->
    case zm_config:delete(?GARRAY_CHANGED, RoleUid) of
        none ->
            [];
        {_, {_, List}} ->
            List
    end.


%% ----------------------------------------------------
%% @doc
%%     处理
%% @end
%% ----------------------------------------------------
clear_weapon_error(Src, RoleUid, Gid, OGarray, CardStorage) ->
    OQueue = garray:get_queue(OGarray),
    OWeapon = garray:get_weapon(OGarray),
    Fun1 = fun(R, N, {CardUid, SoldiersNum}) when CardUid > 0 ->
        {WeaponSid, WeaponNum} = element(N, OWeapon),
        if
            WeaponSid > 0 ->
                WeaponType = barracks:get_weapon_type_bysid(WeaponSid),
                {_, CardProp} = storage_lib:find_by_uid(CardStorage, CardUid),
                Card = prop_kit_lib:get_prop_record(CardProp),
                SoldiersType = card:get_soldiers_type(Card),
                if
                    WeaponType =/= SoldiersType orelse SoldiersNum < WeaponNum ->
                        {ok, [{N, SoldiersType, SoldiersNum} | R]};
                    true ->
                        {ok, R}
                end;
            true ->
                {ok, R}
        end;
        (R, _, _) ->
            {ok, R}
    end,
    ClearWeaponIndexs = z_lib:tuple_foreach(OQueue, Fun1, []),
    if
        ClearWeaponIndexs =/= [] ->
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'garray', {RoleUid, Gid}, garray:init()}, {'barracks', RoleUid, barracks:init()}]),
            Fun2 = fun(_, [{Index1, Garray}, {Index2, Barracks}]) ->
                Weapon = garray:get_weapon(Garray),
                {NWeapon, NBarracks} = z_lib:foreach(fun({WeaponAcc, BarracksAcc}, {N, SType, SNum}) ->
                    {OSid, ONum} = element(N, WeaponAcc),
                    NBarracksAcc1 = barracks:update_weapons(BarracksAcc, OSid, ONum),
                    {WeaponSid, WeaponNum} = barracks:get_weapon_sidandnum_by_type_in_barracks(NBarracksAcc1, SType),
                    {NBarracksAcc, NWeaponAcc} =
                        case WeaponSid =:= 0 of
                            true ->
                                {NBarracksAcc1, erlang:setelement(N, WeaponAcc, {0, 0})};
                            false ->
                                AddWNum = min(SNum, WeaponNum),
                                {barracks:update_weapons(NBarracksAcc1, WeaponSid, -AddWNum), erlang:setelement(N, WeaponAcc, {WeaponSid, AddWNum})}
                        end,
                    {ok, {NWeaponAcc, NBarracksAcc}}
                end, {Weapon, Barracks}, ClearWeaponIndexs),
                NGarray = garray:set_weapon(Garray, NWeapon),
                {ok, NGarray, [{Index1, NGarray}, {Index2, NBarracks}]}
            end,
            z_db_lib:handle(TableName, Fun2, {}, TableKeys);
        true ->
            OGarray
    end.

%% ----------------------------------------------------
%% @doc
%%      官职下降更新阵型数据
%% @end
%% ----------------------------------------------------
officail_update_garray(Src, RoleUid, Gids) ->
    Study = building_db:get_study(Src, RoleUid),
    OfficailAttr = official_db:get_attrs(Src, RoleUid),
    Political = building_db:get_political(Src, RoleUid),
    CardStorage = storage_db:get_storage('card', Src, RoleUid),
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'barracks', RoleUid, barracks:init()} | [{'garray', {RoleUid, Gid}, 'none'} || Gid <- Gids]]),
    Fun = fun(_, [{Index1, Barracks} | IndexValue]) ->
        F = fun(Acc, {_GId, {_Index, 'none'}}) ->
            {'ok', Acc};
            ({DNum, Acc0, Acc1, BarracksTmp}, {GId, {Index, Garray}}) ->
                Queue = garray:get_queue(Garray),
                Weapons = garray:get_weapon(Garray),
                {Dnum1, NQueue, NWeapons} =
                    z_lib:tuple_foreach(Queue, fun({DnumAcc, QueueAcc, CWeapons} = A, N, {CUid, Cnum}) ->
                        if
                            Cnum > 0 ->
                                {_, CardProp} = storage_lib:find_by_uid(CardStorage, CUid),
                                Card = prop_kit_lib:get_prop_record(CardProp),
                                CMax = card_lib:get_max_soldiers_num(Card, Study, attrs:merge_attrs(building_db:get_political_attr(CUid, Political), OfficailAttr)),
                                if
                                    Cnum > CMax ->
                                        {WSid, WNum} = element(N, CWeapons),
                                        NCW = if
                                            WNum > CMax ->
                                                setelement(N, CWeapons, {WSid, CMax});
                                            true ->
                                                CWeapons
                                        end,
                                        {'ok', {DnumAcc + Cnum - CMax, setelement(N, QueueAcc, {CUid, CMax}), NCW}};
                                    true ->
                                        {'ok', A}
                                end;
                            true ->
                                {'ok', A}
                        end
                    end, {0, Queue, Weapons}),

                if
                    Dnum1 > 0 ->
                        NBarracksTmp1 = barracks:up_soldiers(BarracksTmp, GId, -Dnum1),
                        NBarracksTmp = barracks:update_barracks_weapon(NBarracksTmp1, GId, Weapons, NWeapons),
                        {'ok', {DNum + Dnum1, [{lists:nth(Index - 1, Gids), {NQueue, NWeapons}} | Acc0], [{Index, garray:set_weapon(garray:set_queue(Garray, NQueue), NWeapons)} | Acc1], NBarracksTmp}};
                    true ->
                        {'ok', {DNum, Acc0, Acc1, BarracksTmp}}
                end
        end,
        {ChangeNum, Changes, Update, NBarracks} = z_lib:foreach(F, {0, [], [], Barracks}, lists:zip(Gids, IndexValue)),
        {RelUpdate, RBarracks} = if
            ChangeNum > 0 ->
                {[{Index1, NBarracks} | Update], NBarracks};
            true ->
                {Update, Barracks}
        end,
        {'ok', {Changes, RBarracks, ChangeNum}, RelUpdate}
    end,
    z_db_lib:handle(TableName, Fun, [], TableKeys).

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%     下阵的武将更新包裹状态
%% @end
%% ----------------------------------------------------
-spec down_card_storage(tuple(), integer()) -> tuple().
down_card_storage(CardStorage, 0) ->
    CardStorage;
down_card_storage(CardStorage, CardUid) ->
    {Index, Prop} = storage_lib:find_by_uid(CardStorage, CardUid),
    NPropTmp = prop_kit_lib:set_prop_record(Prop,
        card:set_state(prop_kit_lib:get_prop_record(Prop), 0)),
    storage_lib:update_by_index(CardStorage, Index, NPropTmp).

%% ----------------------------------------------------
%% @doc
%%     武将下阵修改阵型和兵营信息
%% @end
%% ----------------------------------------------------
-spec down_card_queue(integer(), tuple(), integer(), garray:garray(), barracks:barracks()) ->
    {garray:garray(), barracks:barracks()}.
down_card_queue(_GId, _, 0, Garray, Barracks) ->
    {Garray, Barracks};
down_card_queue(GId, Queue, UpCardUid, Garray, Barracks) ->
    case z_lib:tuple_foreach(Queue, fun
        (_, I, {UpCardUid1, Nums}) when UpCardUid1 =:= UpCardUid ->
            {break, {I, Nums}};
        (_, _, _) ->
            {ok, 0}
    end, 0) of
        0 ->
            throw("card_not_up");
        {ExtraIndex, ExtraNums} ->
            Weapons = garray:get_weapon(Garray),
            {WeaponSid, WeaponNum} = element(ExtraIndex, Weapons),
            NGarray1 = garray:set_queue(Garray, setelement(ExtraIndex, garray:get_queue(Garray), {0, 0})),
            NGarray2 = garray:set_weapon(NGarray1, setelement(ExtraIndex, Weapons, {0, 0})),
            NBarracks1 = barracks:up_soldiers(Barracks, GId, -ExtraNums),
            NBarracks2 = barracks:update_weapons(NBarracks1, WeaponSid, WeaponNum),
            {NGarray2, NBarracks2}
    end.


%% ----------------------------------------------------
%% @doc
%%     自动配兵
%% @end
%% ----------------------------------------------------
-spec auto_add_soldiers_(tuple(), list()) -> string()|tuple().
auto_add_soldiers_({_Src, RoleUid, GId, Study, CardStorage, Political, OfficialAttr, IsStation, IsCheckFight, IsAddSoilders, IsAddWeapons}, [{Index1, GArray}, {Index3, Barracks} | T]) ->
    Idle = check_idle(RoleUid, GId, T, GArray, IsStation, IsCheckFight),
    if
        Idle ->
            Queue = garray:get_queue(GArray),
            %%先检查队伍里面是否有兵力为0的队伍，有的话则优先补一个兵进去
            {Barracks3, Queue3} = if
                IsAddSoilders ->
                    Fun1 = fun({Barracks1, Queue1, ArgsNum}, N1, {Uid1, Num1}) ->
                        case Uid1 =/= 0 of
                            true ->
                                CLeisure = barracks:get_leisure(GId, Barracks1),
                                Add = min(ArgsNum - Num1, CLeisure),
                                NNum = Num1 + Add,
                                NCQueue = setelement(N1, Queue1, {Uid1, NNum}),
                                NCBarracks1 = barracks:up_soldiers(Barracks1, GId, Add),
                                {'ok', {NCBarracks1, NCQueue, ArgsNum}};
                            false ->
                                {ok, {Barracks1, Queue1, ArgsNum}}
                        end
                    end,
                    {BarracksTmp, QueueTmp, _} = tuple_foreach1(Queue, Fun1, {Barracks, Queue, 0}),%%把所有兵都卸下来
                    {BarracksTmp2, QueueTmp2, _} = tuple_foreach1(QueueTmp, Fun1, {BarracksTmp, QueueTmp, 1}),%%给所有配置1个兵
                    {BarracksTmp2, QueueTmp2};
                true ->
                    {Barracks, Queue}
            end,
%%            %%主城，把阵容上的兵器退到兵营中，然后再对每个武将配兵，兵器
%%            Weapons = garray:get_weapon(GArray),
%%            {Barracks4, Weapons4} = if
%%                IsStation orelse not IsAddWeapons -> %%如果是驻扎点兵器不变
%%                    {Barracks3, tuple_to_list(Weapons)};
%%                true ->
%%                    z_lib:tuple_foreach(Weapons, fun({R, W}, _, {0, _}) ->
%%                        {R, [{0, 0} | W]};
%%                        ({CBarracks, RWeapons}, _, {Sid, Num}) ->
%%                            {barracks:update_weapons(CBarracks, Sid, Num), [{0, 0} | RWeapons]}
%%                    end, {Barracks3, []})
%%            end,
            %%配兵，兵器
            Fun = fun({CBarracks, CQueue, CWeapon} = R, N, {Uid, Num}) ->
                if
                    Uid > 0 ->
                        {_, Prop} = storage_lib:find_by_uid(CardStorage, Uid),
                        Card = prop_kit_lib:get_prop_record(Prop),
                        MaxSoldiers = card_lib:get_max_soldiers_num(Card, Study, attrs:merge_attrs(building_db:get_political_attr(Uid, Political), OfficialAttr)),
                        %%补兵
                        {SoldiersNumTmp, NCQueueTmp1, NCBarracksTmp1} =
                            if
                                IsAddSoilders ->
                                    CLeisure = barracks:get_leisure(GId, CBarracks),
                                    Add = min(MaxSoldiers - Num, CLeisure),
                                    NNum = Num + Add,
                                    NCQueue = setelement(N, CQueue, {Uid, NNum}),
                                    NCBarracks1 = barracks:up_soldiers(CBarracks, GId, Add),
                                    {NNum, NCQueue, NCBarracks1};
                                true ->
                                    {Num, CQueue, CBarracks}
                            end,
                        %%补兵器
                        {NCBarracksTmp2, NCWeaponTmp2} =
                            if
                                IsAddWeapons ->
                                    {WeaponSid, WeaponNum} = element(N, CWeapon),
                                    case lists:keyfind(WeaponSid, 1, barracks:get_weapon(NCBarracksTmp1, GId)) of
                                        false ->
                                            {NCBarracksTmp1, CWeapon};
                                        {WeaponSid, BWeaponNum} ->
                                            AddToWeaponNum = min(min(SoldiersNumTmp, BWeaponNum + WeaponNum), SoldiersNumTmp),
                                            AddWeaponNum = AddToWeaponNum - WeaponNum,
                                            NCBarracks = barracks:update_weapons(NCBarracksTmp1, GId, WeaponSid, -AddWeaponNum),
                                            NCWeapon = setelement(N, CWeapon, {WeaponSid, AddToWeaponNum}),
                                            {NCBarracks, NCWeapon}
                                    end;
                                true ->
                                    {NCBarracksTmp1, CWeapon}
                            end,
                        {'ok', {NCBarracksTmp2, NCQueueTmp1, NCWeaponTmp2}};
                    true ->
                        {'ok', R}
                end
            end,
            {NBarracks, NQueue, NWeapon1} = tuple_foreach1(Queue3, Fun, {Barracks3, Queue3, garray:get_weapon(GArray)}),
            NGarray = garray:set_weapon(garray:set_queue(GArray, NQueue), NWeapon1),
            {'ok', {ok, NQueue, NBarracks, NWeapon1}, [{Index1, NGarray}, {Index3, NBarracks}]};
        true ->
            throw("garray_not_idle")
    end.

%% ----------------------------------------------------
%% @doc
%%     检测阵型是否为空;或者所有武将所带兵都为0
%% @end
%% ----------------------------------------------------
-spec check_queue_null(Queue :: tuple()) -> boolean().
check_queue_null(Queue) ->
    F = fun(Bool, _, {V, Num}) ->
        if
            V > 0 andalso Num > 0 ->
                {'break', false};
            true ->
                {'ok', Bool}
        end
    end,
    z_lib:tuple_foreach(Queue, F, true).

%% ----------------------------------------------------
%% @doc
%%     获取队伍魅力值最高的武将
%% @end
%% ----------------------------------------------------
get_max_charm(Src, RoleUid, Garray) ->
    CardStorage = storage_db:get_storage('card', Src, RoleUid),
    Queue = garray:get_queue(Garray),
    F = fun(A, _, {0, _}) ->
        {'ok', A};
        (A, _, {CardUid, _}) ->
            {_, CardProp} = storage_lib:find_by_uid(CardStorage, CardUid),
            Card = prop_kit_lib:get_prop_record(CardProp),
            Charm = card:get_charm(Card),
            {'ok', max(Charm, A)}
    end,
    z_lib:tuple_foreach(Queue, F, 0).

%% ----------------------------------------------------
%% @doc
%%    获取阵型兵力信息 返回 {最大带兵数,每个位置最大兵力}
%% @end
%% ----------------------------------------------------
get_garray_soldiers(Src, RoleUid, Garray) ->
    Study = building_db:get_study(Src, RoleUid),
    Political = building_db:get_political(Src, RoleUid),
    OfficialAttr = official_db:get_attrs(Src, RoleUid),
    CardStorage = storage_db:get_storage('card', Src, RoleUid),
    Queue = garray:get_queue(Garray),
    z_lib:tuple_foreach(Queue, fun({MCount, ICount} = Acc, I, {Uid, _}) ->
        if
            Uid > 0 ->
                {_, Prop} = storage_lib:find_by_uid(CardStorage, Uid),
                Card = prop_kit_lib:get_prop_record(Prop),
                Num = card_lib:get_max_soldiers_num(Card, Study, attrs:merge_attrs(building_db:get_political_attr(Uid, Political), OfficialAttr)),
                {ok, {MCount + Num, erlang:setelement(I, ICount, Num)}};
            true ->
                {ok, Acc}
        end
    end, {0, erlang:list_to_tuple(lists:duplicate(tuple_size(Queue), 0))}).

%% ----------------------------------------------------
%% @doc
%%    是否空闲中 IndexList第一个必须为{_, PointMarch}
%% @end
%% ----------------------------------------------------
check_idle(RoleUid, GId, IndexList, GArray, IsStation, IsCheckFight) ->
    case garray:check_idle(GArray) of
        true ->
            true;
        false ->
            case IsStation of
                true ->
                    [{_, PointMarch} | _] = IndexList,
                    [point_march:check_fighting(PointMarch) || IsCheckFight =:= true],
                    OccMarchings = point_march:get_occupy(PointMarch),
                    lists:keyfind({RoleUid, GId}, marching:get_roleuid_gid_index(), OccMarchings) =/= false;
                false ->
                    false
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      tuple_foreach从第一个开始循环
%% @end
%% ----------------------------------------------------
tuple_foreach1(Tuple, F, A) ->
    tuple_foreach1(Tuple, 1, F, A, tuple_size(Tuple)).
% 遍历元组
tuple_foreach1(Tuple, N, F, A, TupleSize) when N =< TupleSize ->
    case F(A, N, element(N, Tuple)) of
        {ok, A1} ->
            tuple_foreach1(Tuple, N + 1, F, A1, TupleSize);
        {break, A1} ->
            A1;
        A1 ->
            tuple_foreach1(Tuple, N + 1, F, A1, TupleSize)
    end;
tuple_foreach1(_Tuple, _N, _F, A, _TupleSize) ->
    A.
