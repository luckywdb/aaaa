-module(garray).
-description("队伍信息").
-copyright('youkia,www.youkia.net').
-author({lqq, 'liqiqiang@youkia.net'}).
-vsn(1).

%%%=======================EXPORT========================
-export([get_queue/1, get_ordnance/1, get_skill36/1, get_state/1, check_idle/1, get_injured/1, get_auto_add_soldier/1, get_queue_card_num/1]).
-export([set_queue/2, set_ordnance/2, set_skill36/2, set_state/2, set_injured/2, set_auto_add_soldier/2, set_injured_init/1]).
-export([init/0, get_garray_soldiers/1, check_march/1, check_fight_dup/1, get_weapon/1, set_weapon/2, init_garray_or_injured/0]).

-export_type([garray/0]).
%%%=======================DEFINE========================
-include("../include/garray.hrl").
-include("../include/point.hrl").
%%%=======================INCLUDE======================

%%%=======================RECORD======================
-record(garray, {
    queue = erlang:list_to_tuple(lists:duplicate(?QUEUE_MAX, {0, 0})) :: tuple(),%武将阵型{武将uid,带兵数量}
    ordnance = 0 :: integer(),%军械sid 0表示未装备军械
    skill36 = erlang:list_to_tuple(lists:duplicate(?SKILL36_NUM, 0)) :: tuple(),%装备的36计{0,0}
    %队伍状态 空闲/驻防/其他玩家城堡驻防/行军对应坐标uid
    state = ?IDLE :: integer(), %(有行军和返回行军都是存在pointuid,只有空闲和自己主城驻防才会存point.hrl对应的宏)空闲和自己主城驻防都没有行军信息
    injured = erlang:list_to_tuple(lists:duplicate(?QUEUE_MAX, {0, 0})) :: tuple(), %{{伤兵数量,剩余空闲兵器数量}}
    auto_add_soldier = 0 :: 0 | 1,%%是否自动补充兵力
    weapon = erlang:list_to_tuple(lists:duplicate(?QUEUE_MAX, {0, 0})) :: tuple(),%%[{武将所带兵器类型+等级,上阵个数}]
    info = [] :: list() %扩展用
}).

%%%=======================TYPE=========================
-type garray() :: #garray{}.

%%%=================EXPORTED FUNCTIONS===================
%% ----------------------------------------------------
%% @doc
%%      获取武将队列（武将,带兵数）
%% @end
%% ----------------------------------------------------
-spec get_queue(garray()) -> tuple().
get_queue(#garray{queue = Value}) -> Value.

%% ----------------------------------------------------
%% @doc
%%      获取军械
%% @end
%% ----------------------------------------------------
-spec get_ordnance(garray()) -> integer().
get_ordnance(#garray{ordnance = Value}) -> Value.

%% ----------------------------------------------------
%% @doc
%%      获取36计
%% @end
%% ----------------------------------------------------
-spec get_skill36(garray()) -> tuple().
get_skill36(#garray{skill36 = Value}) -> Value.

%% ----------------------------------------------------
%% @doc
%%     状态
%% @end
%% ----------------------------------------------------
-spec get_state(garray()) -> integer().
get_state(#garray{state = Value}) -> Value.

%% ----------------------------------------------------
%% @doc
%%     伤兵
%% @end
%% ----------------------------------------------------
-spec get_injured(garray()) -> tuple().
get_injured(#garray{injured = Value}) -> Value.

%% ----------------------------------------------------
%% @doc
%%        是否自动补充兵力
%% @end
%% ----------------------------------------------------
-spec get_auto_add_soldier(garray()) -> 0 | 1.
get_auto_add_soldier(#garray{auto_add_soldier = AutoAddSoldier}) -> AutoAddSoldier.

%% ----------------------------------------------------
%% @doc
%%      设置武将队列（主力,后补）
%% @end
%% ----------------------------------------------------
-spec set_queue(garray(), tuple()) -> garray().
set_queue(Array, Value) -> Array#garray{queue = Value}.

%% ----------------------------------------------------
%% @doc
%%      设置军械
%% @end
%% ----------------------------------------------------
-spec set_ordnance(garray(), integer()) -> garray().
set_ordnance(Array, Value) -> Array#garray{ordnance = Value}.

%% ----------------------------------------------------
%% @doc
%%      设置36计
%% @end
%% ----------------------------------------------------
-spec set_skill36(garray(), tuple()) -> garray().
set_skill36(Array, Value) -> Array#garray{skill36 = Value}.

%% ----------------------------------------------------
%% @doc
%%      设置状态{状态,开始时间,需要行军时间,行军uid}
%% @end
%% ----------------------------------------------------
-spec set_state(garray(), integer()) -> garray().
set_state(Array, Value) -> Array#garray{state = Value}.

%% ----------------------------------------------------
%% @doc
%%      设置伤兵
%% @end
%% ----------------------------------------------------
-spec set_injured(garray(), tuple()) -> garray().
set_injured(Array, Value) -> Array#garray{injured = Value}.
%% ----------------------------------------------------
%% @doc
%%      设置初始化伤兵
%% @end
%% ----------------------------------------------------
-spec set_injured_init(garray()) -> garray().
set_injured_init(Array) -> Array#garray{injured = erlang:list_to_tuple(lists:duplicate(?QUEUE_MAX, {0, 0}))}.

%% ----------------------------------------------------
%% @doc
%%        是否自动补充兵力
%% @end
%% ----------------------------------------------------
-spec set_auto_add_soldier(garray(), 0 | 1) -> garray().
set_auto_add_soldier(Garrison, AutoAddSoldier) ->
    Garrison#garray{auto_add_soldier = AutoAddSoldier}.
%%---------------------------------------------------
%% @doc
%%      初始阵型
%% @end
%%----------------------------------------------------
-spec init() -> garray().
init() ->
    #garray{}.

%% ----------------------------------------------------
%% @doc
%%      获取编队总配兵
%% @end
%% ----------------------------------------------------
-spec get_garray_soldiers(Garray :: garray()) -> integer().
get_garray_soldiers(Garray) ->
    Queue = get_queue(Garray),
    F = fun(A, _, {_, N}) ->
        {'ok', A + N}
    end,
    z_lib:tuple_foreach(Queue, F, 0).

%% ----------------------------------------------------
%% @doc
%%      检测该队是否可行军
%% @end
%% ----------------------------------------------------
-spec check_march(Garray :: garray()) -> boolean().
check_march(Garray) ->
    State = get_state(Garray),
    State =:= ?IDLE andalso check_fight_dup(Garray).

%% ----------------------------------------------------
%% @doc
%%      检测该队是否可以打关卡
%% @end
%% ----------------------------------------------------
-spec check_fight_dup(Garray :: garray()) -> boolean().
check_fight_dup(Garray) ->
    Queue = get_queue(Garray),
    z_lib:tuple_foreach(Queue, fun(_, _, {Uid, 0}) when Uid > 0 ->
        {'break', false};
        (A, _, {0, 0}) ->
            {'ok', A};
        (_, _, _) ->
            {'ok', true}
    end, false).

%% ----------------------------------------------------
%% @doc
%%      检测队伍是否为空闲状态/或者主城驻军中,
%% @end
%% ----------------------------------------------------
-spec check_idle(garray()) -> boolean().
check_idle(#garray{state = State}) ->
    State =:= ?IDLE orelse State =:= ?ON_THE_CASTLE.

%% ----------------------------------------------------
%% @doc
%%      获取武将兵器{兵器Sid,兵器数量}
%% @end
%% ----------------------------------------------------
-spec get_weapon(garray()) -> tuple().
get_weapon(#garray{weapon = Value}) -> Value.

%% ----------------------------------------------------
%% @doc
%%      设置军械
%% @end
%% ----------------------------------------------------
-spec set_weapon(garray(), tuple()) -> garray().
set_weapon(Array, Value) -> Array#garray{weapon = Value}.
%%---------------------------------------------------
%% @doc
%%      初始阵型上的兵器
%% @end
%%----------------------------------------------------
-spec init_garray_or_injured() -> tuple().
init_garray_or_injured() ->
    erlang:list_to_tuple(lists:duplicate(?QUEUE_MAX, {0, 0})).
%% ----------------------------------------------------
%% @doc
%%      获取编队武将数量
%% @end
%% ----------------------------------------------------
-spec get_queue_card_num(tuple()) -> integer().
get_queue_card_num(Queue) ->
    F = fun(A, _, {0, _}) ->
        {'ok', A};
        (A, _, _) ->
            {'ok', A + 1}
    end,
    z_lib:tuple_foreach(Queue, F, 0).


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
