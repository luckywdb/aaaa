-module(look_town_card).

%%%=======================STATEMENT====================
-description("寻访武将遭遇事件").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    get_award/3
]).

-export_type([look_town_card/0]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(look_town_card, {
    sid :: integer(),%城池sid
    cards = [] :: list()%权重,武将碎片概率
}).

%%%=======================TYPE=========================
-type look_town_card() :: #look_town_card{}.


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%     获取寻访武将遭遇事件奖励列表
%% @end
%% ----------------------------------------------------
-spec get_award(integer(), look_event:look_event(), integer()) -> {integer(), list()}.
get_award(TownSid, LookEvent, MaxCharm) ->
    LookTown = get_cfg(TownSid),
    Sid = game_lib:random_value(get_cards(LookTown)),
    {Min, Max} = look_event:get_card_num(LookEvent),
    %策划说魅力也是用政治加成公式
    Random = game_lib:ceil(z_lib:random(Min, Max) * (10000 + building_lib:get_polity_addper(MaxCharm)) / 10000),
    Award =
        if
            Random =:= 0 ->
                [];
            true ->
                [{'prop', {Sid, Random}}]
        end,
    {Sid, Award}.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%     获取寻访武将遭遇事件
%% @end
%% ----------------------------------------------------
-spec get_cfg(integer()) -> look_town_card().
get_cfg(Sid) ->
    zm_config:get('look_town_card', Sid).

%% ----------------------------------------------------
%% @doc
%%     获取权重概率列表
%% @end
%% ----------------------------------------------------
-spec get_cards(look_town_card()) -> list().
get_cards(#look_town_card{cards = V}) -> V.
