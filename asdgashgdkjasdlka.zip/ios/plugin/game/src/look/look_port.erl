-module(look_port).

%%%=======================STATEMENT====================
-description("寻访点").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    look_march/5,
    look_info/5,
    look_event/5,
    look_get_occ/5
]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      寻访点,行军
%% @end
%% ----------------------------------------------------
look_march([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    MarchRoleUid = role_lib:get_uid(Attr),
    MarchGId = z_lib:get_value(Msg, "gid", 0),
    TownSidTmp = list_to_integer(z_lib:get_value(Msg, "town_sid", "0")),
    HaveBuild = z_lib:get_value(Msg, "have_build", 0),%0没有建筑,1表示有建筑
    CheckVaild = valid_lib:check_valib([{'gt', TownSidTmp, 0}, {'range', MarchGId, {1, garray_lib:get_max_gid()}}, {'range', HaveBuild, {0, 1}}]),
    if
        CheckVaild ->
            MapId = role_lib:get_mapid(Attr),
            MarchRoleShow = role_db:get_role_show(Src, MarchRoleUid),
            TownSid = point_lib:sidaddmapid(TownSidTmp, MapId),
            Town = z_db_lib:get(game_lib:get_table(Src, 'town'), TownSid, town:init(TownSidTmp)),
            MarchBool = role_show:get_corps_uid(MarchRoleShow) =:= town:get_corps_uid(Town),
            if
                MarchBool ->
                    restore_db:restore(Src, MarchRoleUid),
                    RoleStations = station_db:get_role_stations(Src, MarchRoleUid),
                    {MarchPInfo, MarchPoint, IsStation} =
                        case lists:keyfind(MarchGId, station:get_gid_index(), RoleStations) of
                            false ->
                                {{?ROLE, MarchRoleUid}, role_show:get_point(MarchRoleShow), false};
                            Station ->
                                {{?STATION, MarchRoleUid}, station:get_puid(Station), true}
                        end,
                    MarchSpeed = role_addition:get_marching_speed(Src, MarchRoleUid, MarchPoint, map_build_lib:check_station_marchg(IsStation, HaveBuild)),
                    EndPoint = town_detail:get_point(town_detail:get_cfg(TownSid)),
                    EndPInfo = {?TOWN, TownSid},
                    Marching = marching:set_state(marching:init(MarchRoleUid, MarchGId, MarchPoint,
                        EndPoint, MarchSpeed, element(1, MarchPInfo), EndPInfo), ?ON_THE_LOOK_MARCHING),
                    TableName = game_lib:get_table(Src),
                    TableKeys = z_db_lib:transformation_tablekey(TableName, [
                        {'role', MarchRoleUid},
                        {'garray', {MarchRoleUid, MarchGId}, 'none'},
                        {'point_march', MarchPoint, point_march:init()},
                        {'point_march', EndPoint, point_march:init()},
                        {'role_restore', MarchRoleUid}
                    ]),
                    Reply = case z_db_lib:handle(TableName, {M, F, A}, {Src, MapId, MarchPoint, EndPoint, Marching, EndPInfo, MarchPInfo, IsStation}, TableKeys) of
                        {'ok', MarchPMarch, _EndPMarch, BiCs, _Bool, _OcRoleUid} ->
                            %bi
                            zm_event:notify(Src, 'bi_fight_marching', [{'role_uid', MarchRoleUid}, {'consumes', BiCs}, {'gid', MarchGId}, {'type', ?LOOK}]),
                            MarchLine = marching:marching_to_lines(EndPoint, EndPInfo, Marching),
                            point_search_db:send_march_line(Src, MarchPoint, EndPoint, MarchLine, [MarchRoleUid]),
                            fight_db:add_fight_assist(Src, EndPoint, Marching),
                            station_db:update_station_occ_num(Src, MarchPoint, MarchPMarch, IsStation),
                            "ok";
                        Err ->
                            Err
                    end,
                    {'ok', [], Info, [{'msg', Reply}]};
                true ->
                    {'ok', [], Info, [{'msg', "town_not_owner"}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      查看寻访点信息
%% @end
%% ----------------------------------------------------
look_info(_, _, _Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    TownSid = list_to_integer(z_lib:get_value(Msg, "town_sid", "-1")),
    RoleUid = list_to_integer(z_lib:get_value(Msg, "role_uid", "-1")),%查看信息的角色uid
    GId = z_lib:get_value(Msg, "gid", "-1"),%查看信息的角色队伍id
    Start = z_lib:get_value(Msg, "start", 1),
    End = z_lib:get_value(Msg, "end", 1),
    Flag = z_lib:get_value(Msg, "flag", 0),%就只发送事件列表,其他都为{}
    CheckVaild = valid_lib:check_valib([{'gt', TownSid, 0}, {'gt', RoleUid, 0}, {'ge', Start, 1}, {'ge', End, Start},
        {'ge', Flag, 0}, {'range', GId, {1, garray_lib:get_max_gid()}}]),
    if
        CheckVaild ->
            TownDetail = town_detail:get_cfg(TownSid),
            PointUid = town_detail:get_point(TownDetail),
            case look_db:get_look_logs(Src, RoleUid, GId, PointUid) of
                'none' ->
                    {'ok', [], Info, [{'msg', "look_goback"}]};
                LookLogs ->
                    Logs = look_logs:get_logs(LookLogs, Start, End),
                    if
                        Flag =:= 0 ->
                            {'ok', [], Info, [{'msg', {Logs, {}, {}, {}}}]};
                        true ->
                            PointMarch = z_db_lib:get(game_lib:get_table(Src, 'point_march'), PointUid, point_march:init()),
                            Occ = point_march:get_occupy(PointMarch),
                            Fun = fun(R, M) ->
                                MState = marching:get_state(M),
                                LookState = look_fight:looking_state(MState),
                                if
                                    LookState ->
                                        {MRoleUid, MGid} = marching:get_roleuid_gid(M),
                                        STime = marching:get_stime(M),
                                        ETime = marching:get_etime(M),
                                        MRShow = role_db:get_role_show(Src, MRoleUid),
                                        {'ok', [{MRoleUid, role_show:get_name(MRShow), role_show:get_style(MRShow), MGid, STime, ETime} | R]};
                                    true ->
                                        {'ok', R}
                                end
                            end,
                            RoleViews = z_lib:foreach(Fun, [], lists:keysort(marching:get_stime_index(), Occ)),
                            Consume = list_to_tuple(look_logs:get_consumes(LookLogs)),
                            Award = list_to_tuple(look_logs:get_awards(LookLogs)),
                            {'ok', [], Info, [{'msg', {Logs, list_to_tuple(lists:reverse(RoleViews)), Consume, Award}}]}
                    end
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      寻访点事件触发
%% @end
%% ----------------------------------------------------
look_event(_, _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    TownSid = list_to_integer(z_lib:get_value(Msg, "town_sid", "-1")),
    MarchGId = z_lib:get_value(Msg, "gid", 0),
    Flag = z_lib:get_value(Msg, "flag", 0),
    CheckVaild = valid_lib:check_valib([{'gt', TownSid, 0}, {'range', MarchGId, {1, garray_lib:get_max_gid()}}, {'ge', Flag, 0}]),
    if
        CheckVaild ->
            RoleUid = role_lib:get_uid(Attr),
            TownDetail = town_detail:get_cfg(TownSid),
            PointUid = town_detail:get_point(TownDetail),
            PointMarch = z_db_lib:get(game_lib:get_table(Src, 'point_march'), PointUid, point_march:init()),
            Occ = point_march:get_occupy(PointMarch),
            Reply =
                case lists:keyfind({RoleUid, MarchGId}, marching:get_roleuid_gid_index(), Occ) of
                    false ->
                        "no_look";
                    Marching ->
                        look_db:event(Src, PointUid, Marching, TownSid, Flag)
                end,
            {'ok', [], Info, [{'msg', Reply}]};
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      获取寻访中玩家信息
%% @end
%% ----------------------------------------------------
look_get_occ(_, _, _Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    TownSid = list_to_integer(z_lib:get_value(Msg, "town_sid", "-1")),
    CheckVaild = valid_lib:check_valib([{'gt', TownSid, 0}]),
    if
        CheckVaild ->
            TownDetail = town_detail:get_cfg(TownSid),
            PointUid = town_detail:get_point(TownDetail),
            PointMarch = z_db_lib:get(game_lib:get_table(Src, 'point_march'), PointUid, point_march:init()),
            Occ = point_march:get_occupy(PointMarch),
            Fun = fun(R, M) ->
                MState = marching:get_state(M),
                LookState = look_fight:looking_state(MState),
                if
                    LookState ->
                        STime = marching:get_stime(M),
                        ETime = marching:get_etime(M),
                        {MRoleUid, MGid} = marching:get_roleuid_gid(M),
                        MRShow = role_db:get_role_show(Src, MRoleUid),
                        {'ok', [{MRoleUid, role_show:get_name(MRShow), role_show:get_style(MRShow), MGid, STime, ETime} | R]};
                    true ->
                        {'ok', R}
                end
            end,
            RoleViews = z_lib:foreach(Fun, [], lists:keysort(marching:get_stime_index(), Occ)),
            {'ok', [], Info, [{'msg', list_to_tuple(lists:reverse(RoleViews))}]};
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
