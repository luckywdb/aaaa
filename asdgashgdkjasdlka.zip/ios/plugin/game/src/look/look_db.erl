-module(look_db).

%%%=======================STATEMENT====================
-description("look_db").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    get_look_logs/4,
    event/5,
    get_soldiers/2
]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").
%%%=======================DEFINE======================


%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%      获取寻访点寻访玩家log
%% @end
%%-------------------------------------------------------------------
-spec get_look_logs(atom(), integer(), integer(), integer()) -> look_logs:look_logs()|'none'.
get_look_logs(Src, RoleUid, GId, PointUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'look'), {RoleUid, GId, PointUid}, 'none').

%% ----------------------------------------------------
%% @doc
%%     事件触发(返回:{下次触发时间,此次事件消耗,此次事件奖励武将经验值,此次事件其他信息{事件sid,损兵事件阵型变化}})
%%     登录时候,也先调用一次事件,处理所有该处理的事件,
%%     flag=0(不给前台返回详细),1(给前台返回信息)
%%     注意:由look_fight过来的数据,不要继续抛出战斗事件,否则出现死循环
%% @end
%% ----------------------------------------------------
event(Src, PointUid, Marching, TownSid, Flag) ->
    case marching:get_state(Marching) =:= ?ON_THE_LOOK of %寻访中
        true ->
            {RoleUid, MarchGId} = marching:get_roleuid_gid(Marching),
            Stime = marching:get_stime(Marching),
            Etime = marching:get_etime(Marching),
            LookSid = marching:get_extra_looksid(marching:get_extra(Marching)),
            TableName = game_lib:get_table(Src),
            %目前消耗只有粮食,所以只取角色信息
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'role', RoleUid},
                {'look', {RoleUid, MarchGId, PointUid}, 'none'},
                {'garray', {RoleUid, MarchGId}, 'none'},
                {'barracks', RoleUid}]),
            Fun = fun(_, [_, _, {_, 'none'}, _]) ->
                throw("input_error");
                (_, [{Index1, Role}, {Index2, LookLogs}, {Index3, Garray}, {Index4, Barracks}]) ->
                    NLookLogs1 = if
                        LookLogs =:= 'none' ->
                            look_logs:init(Stime, Garray);
                        true ->
                            case look_logs:get_last_time(LookLogs) < Stime of %回城报错,未清除上一次寻访数据
                                true ->
                                    look_logs:init(Stime, Garray);
                                false ->
                                    LookLogs
                            end
                    end,
                    ITime = look_logs:get_interval_time(NLookLogs1),
                    if
                        ITime =:= ?LOOK_OVER ->
                            {'ok', {?LOOK_OVER, length(look_logs:get_awards(LookLogs))}};
                        true ->
                            Queue = garray:get_queue(Garray),
                            CardUidList = [CUid || {CUid, _} <- tuple_to_list(Queue), CUid =/= 0],
                            CNum = length(CardUidList),
                            %事件段内,触发(可以触发多少次就多少次)
                            {{NRole, NLookLogs, NGarray, NBarracks}, Reply} =
                                iterate_event(Src, MarchGId, LookSid, TownSid, Stime, Etime, CNum, {Role, NLookLogs1, Garray, Barracks}),
                            {'ok', {Reply, Role, NGarray, ITime, length(look_logs:get_awards(NLookLogs))}, [{Index1, NRole}, {Index2, look_logs:add_card_exp(NLookLogs, element(5, Reply))},
                                {Index3, NGarray}, {Index4, NBarracks}]}
                    end

            end,
            case z_db_lib:handle(TableName, Fun, [], TableKeys) of
                {{NextTime, GoBackTime, GoBackType, AllConsumes, AllOneCardExp, AllDead, AllLogs}, ORole, NewGarray, OldITime, AllAwardNum} ->
                    if
                        AllConsumes =/= [] ->
                            {BiCs, _} = game_lib:consumes({'look_lib', 'consume'}, ORole, 'look', AllConsumes),
                            %% 记录事件消耗日志
                            zm_log:info(Src, ?MODULE, 'event', "look_event_consume", [{'roleuid', RoleUid}, {'consume', BiCs}]),
                            %% bi事件
                            zm_event:notify(Src, 'bi_look_event', [{'role_uid', RoleUid}, {'consume', BiCs}]);
                        true ->
                            'ok'
                    end,
                    if
                        Flag =:= ?PSTATE_LOOK_EVENT ->%战斗中触发返回
                            {NextTime, GoBackTime, GoBackType};
                        true ->
                            if
                                NextTime =:= ?LOOK_OVER andalso OldITime =/= NextTime ->%只有第一次提前goback时候处理
                                    look_goback(Src, RoleUid, MarchGId, PointUid, GoBackTime, GoBackType, Flag);
                                true ->
                                    ok
                            end,
                            garray_db:award_card_oneexp(Src, RoleUid, MarchGId, AllOneCardExp, 0),%武将经验
                            NForntViewData = if
                                Flag =:= 0 ->
                                    {};
                                true ->
                                    list_to_tuple(AllLogs)
                            end,
                            DealGarray = if
                                AllDead > 0 ->
                                    {garray:get_queue(NewGarray), garray:get_weapon(NewGarray)};
                                true ->
                                    {}
                            end,
                            {NextTime, list_to_tuple(AllConsumes), AllOneCardExp, AllDead, DealGarray, NForntViewData, AllAwardNum}
                    end;
                {?LOOK_OVER, AwardNum} ->
                    if
                        Flag =:= ?PSTATE_LOOK_EVENT ->%战斗中触发返回(不是前台调用接口的返回)
                            {?LOOK_OVER, Etime};
                        true ->
                            {?LOOK_OVER, {}, 0, 0, {}, {}, AwardNum}
                    end;
                Other ->
                    zm_log:warn(?MODULE, ?MODULE, 'event', "reply_error", [{'other', Other}]),
                    Other
            end;
        false ->
            "input_error"
    end.

%% ----------------------------------------------------
%% @doc
%%      事件触发(当前时间到上次触发时间之间可以进行多少次)
%%      返回:%下次事件时间,寻访结束返回时间,回城类型,总消耗,总武将经验,总死亡,logs
%% @end
%% ----------------------------------------------------
iterate_event(Src, MarchGId, LookSid, TownSid, Stime, Etime, CNum, {_, LookLogs, _, _} = Table) ->
    InverTime = look_logs:get_interval_time(LookLogs),
    Now = time_lib:now_second(),
    if
        InverTime =:= ?LOOK_OVER ->
            {Table, {?LOOK_OVER, min(Etime, Now), ?ON_THE_LOOK, [], 0, 0, []}};
        true ->
            LastTime = look_logs:get_last_time(LookLogs),
            EventTime = LastTime + InverTime,
            Reply = {EventTime, min(Etime, Now), ?ON_THE_LOOK, [], 0, 0, []},
            iterate_event(Src, MarchGId, LookSid, TownSid, Now, Stime, Etime, CNum, Table, Reply)
    end.
iterate_event(Src, MarchGId, LookSid, TownSid, Now, Stime, Etime, CNum, Table, Reply) ->
    {Role, LookLogs, Garray, Barracks} = Table,
    {_NexTime, _GoBackTime, GoBackType, AllConsume, AllAddCardExp, AllAddDead, AllLogs} = Reply,
    InverTime = look_logs:get_interval_time(LookLogs),
    if
        InverTime =:= ?LOOK_OVER ->
            {Table, Reply};
        true ->
            LastTime = look_logs:get_last_time(LookLogs),
            EventTime = LastTime + InverTime,
            if
                EventTime > Etime andalso Now >= Etime ->%已经结束了,直接返回
                    NTable = {Role, look_logs:set_time(LookLogs, Etime, ?LOOK_OVER), Garray, Barracks},
                    {NTable, Reply};
                true ->
                    %首次触发,触发
                    if
                        Now + ?FAILOVER_TIME >= EventTime ->
                            LookDetail = look_detail:get_cfg(LookSid),
                            EventSid = look_detail:get_event(LookDetail, Stime, EventTime),
                            LookEvent = look_event:get_cfg(EventSid),
                            Consume = look_event:get_consume(LookEvent),
                            ConsumeBool = game_lib:checks({'look_lib', 'check'}, Role, 'look', Consume),
                            if
                                ConsumeBool ->
                                    {_BiCs, NRole} = game_lib:consumes({'look_lib', 'consume'}, Role, 'look', Consume),
                                    Loss = look_event:get_loss(LookEvent),
                                    {Win, AddCardExp, CardName} =
                                        case game_lib:checks({'look_lib', 'check'}, {Src, Role, MarchGId, Garray}, 'check_condition', look_event:get_condition(LookEvent)) of
                                            true ->
                                                {?WINNER, look_event:get_card_exp(LookEvent) div CNum, ""};
                                            {true, CardName1} ->
                                                {?WINNER, look_event:get_card_exp(LookEvent) div CNum, CardName1};
                                            {false, CardName1} ->
                                                {?LOSE, 0, CardName1};
                                            _ ->
                                                {?LOSE, 0, ""}
                                        end,
                                    %奖励,log显示数据,是否返回,事件处理后前台处理数据用(例如阵型),修改表数据
                                    {AddAward, ViewData, IsGoBack, NGarray, NBarracks, Dead} =
                                        look_event(Loss, Src, role:get_uid(Role), TownSid, LookEvent, Win, Garray, Barracks, CardName),
                                    AddLog = look_logs:log(EventTime - Stime, EventSid, Consume, AddAward, AddCardExp, Win, ViewData),
                                    NLookLogs = look_logs:add_consumes(look_logs:add_awards(look_logs:add_logs(LookLogs, AddLog), AddAward), Consume),
                                    {NextTime, NInverTime, NGoBackType} =
                                        if
                                            IsGoBack ->
                                                {?LOOK_OVER, ?LOOK_OVER, ?ON_THE_LOOK_DEAD};
                                            true ->
                                                ITime = look_event:get_continue_time(LookEvent),
                                                {EventTime + ITime, ITime, GoBackType}
                                        end,
                                    NLookLogs1 = look_logs:set_time(NLookLogs, EventTime, NInverTime),
                                    NTable = {NRole, look_logs:add_dead(NLookLogs1, Dead), NGarray, NBarracks},
                                    NReply = {NextTime, min(EventTime, Now), NGoBackType, awarder_game:merger(Consume, AllConsume), AllAddCardExp + AddCardExp, AllAddDead + Dead, [AddLog | AllLogs]},
                                    iterate_event(Src, MarchGId, LookSid, TownSid, Now, Stime, Etime, CNum, NTable, NReply);
                                true ->%消耗不足,需要回家
                                    NLookLogs = look_logs:set_time(LookLogs, EventTime, ?LOOK_OVER),
                                    NTable = {Role, NLookLogs, Garray, Barracks},
                                    NReply = {?LOOK_OVER, min(EventTime, Now), ?ON_THE_LOOK_CONSUME, AllConsume, AllAddCardExp, AllAddDead, AllLogs},
                                    iterate_event(Src, MarchGId, LookSid, TownSid, Now, Stime, Etime, CNum, NTable, NReply)
                            end;
                        true ->
                            {Table, Reply}
                    end
            end
    end.

%% ----------------------------------------------------
%% @doc
%%     具体事件处理,返回(奖励,事件前台显示描述用数据,是否回城,修改阵型数据,修改兵营数据,死亡数量)
%% @end
%% ----------------------------------------------------
look_event(?LOOK_TOWN_CARD, Src, RoleUid, TonwSid, LookEvent, Win, Garray, Barracks, _CardName) ->%遭遇武将事件
    MaxCharm = garray_db:get_max_charm(Src, RoleUid, Garray),
    {CardSid, Award} = look_town_card:get_award(TonwSid, LookEvent, MaxCharm),
    NAward =
        if
            Win =:= ?WINNER ->
                Award;
            true ->
                []
        end,
    {NAward, {CardSid}, false, Garray, Barracks, 0};
look_event(?LOOK_TOWN_CARD_CHARM, Src, RoleUid, _TonwSid, LookEvent, Win, Garray, Barracks, _CardName) ->%魅力影响奖励事件
    Award =
        if
            Win =:= ?WINNER ->
                MaxCharm = garray_db:get_max_charm(Src, RoleUid, Garray),
                AddPer = building_lib:get_polity_addper(MaxCharm),
                awarder_game:award_item(awarder_game:award_percent(awarder_game:get_award_list(look_event:get_award(LookEvent)), 10000 + AddPer));
            true ->
                []
        end,
    {Award, {}, false, Garray, Barracks, 0};
look_event(?LOOK_TOWN_CARD_ATTR, _Src, _RoleUid, _TownSid, LookEvent, Win, Garray, Barracks, CardName) ->%武将比属性事件
    Award =
        if
            Win =:= ?WINNER ->
                awarder_game:award_item(awarder_game:get_award_list(look_event:get_award(LookEvent)));
            true ->
                []
        end,
    {Award, {CardName}, false, Garray, Barracks, 0};
look_event(0, _Src, _RoleUid, _TonwSid, LookEvent, Win, Garray, Barracks, _CardName) ->%普通事件
    Award =
        if
            Win =:= ?WINNER ->
                awarder_game:award_item(awarder_game:get_award_list(look_event:get_award(LookEvent)));
            true ->
                []
        end,
    {Award, {}, false, Garray, Barracks, 0};
look_event(Loss, _Src, _RoleUid, _TonwSid, LookEvent, Win, Garray, Barracks, _CardName) ->%损兵事件
    {DeadNum, NGarray} = soldier_event(Garray, Loss),
    RestNum = garray:get_garray_soldiers(NGarray),
    Award =
        if
            DeadNum =:= Loss ->%损兵量=事件损兵量
                if
                    Win =:= ?WINNER ->
                        awarder_game:award_item(awarder_game:get_award_list(look_event:get_award(LookEvent)));
                    true ->
                        []
                end;
            true ->
                []
        end,
    {_, NBarracks} = barracks:fight_over(Barracks, 0, DeadNum, 0, 0),
    {Award, {DeadNum}, RestNum =< 0, NGarray, NBarracks, DeadNum}.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%     事件终止了,需要提前结束(flag=-1,表示战斗中过来的,不能继续抛战斗事件)
%% @end
%% ----------------------------------------------------
look_goback(Src, MarchRoleUid, MarchGId, EndPoint, Time, GoBackType, Flag) ->
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'point_march', EndPoint, 'none'}]),
    case z_db_lib:handle(TableName, {'fight_db', 'collect_recall', [GoBackType]}, {{MarchRoleUid, MarchGId}, Time}, TableKeys) of
        'ok' ->
            if
                Flag =:= ?PSTATE_LOOK_EVENT ->
                    ok;
                true ->
                    zm_event:notify(Src, 'around_fight', [{'pm_uids', [EndPoint]}])
            end;
        _ ->
            'ok'
    end.

%% ----------------------------------------------------
%% @doc
%%      损兵,返回:死亡数量,新的queue
%% @end
%% ----------------------------------------------------
soldier_event(Garray, Loss) ->
    Queue = tuple_to_list(garray:get_queue(Garray)),
    F = fun(A, {_, 0}) ->
        {'ok', A};
        ({A1, A2}, {CUid, Num}) ->
            DelNum = Loss-A1,
            if
                Num - DelNum >= 0 ->
                    {'break', {A1 + DelNum, lists:keyreplace(CUid, 1, A2, {CUid, Num - DelNum})}};
                true ->
                    {'ok', {A1 + Num, lists:keyreplace(CUid, 1, A2, {CUid, 0})}}
            end
    end,
    {DeadNum, NQeue} = z_lib:foreach(F, {0, Queue}, Queue),
    {DeadNum, garray:set_queue(Garray, list_to_tuple(NQeue))}.

%% ----------------------------------------------------
%% @doc
%%     根据阵型,以及死亡数量,整理战报需要格式
%% @end
%% ----------------------------------------------------
get_soldiers(Queue, AllDead) ->
    F = fun(A, {_, 0}) ->
        {'ok', A};
        ({A1, A2}, {CUid, Num}) ->
            DelNum = AllDead-A1,
            if
                Num - DelNum >= 0 ->
                    {'ok', {A1 + DelNum, [{CUid, DelNum, 0} | A2]}};
                true ->
                    {'ok', {A1 + Num, [{CUid, Num, 0} | A2]}}
            end
    end,
    {_, Soldiers} = z_lib:foreach(F, {0, []}, tuple_to_list(Queue)),
    {{list_to_tuple(Soldiers), {}}}.