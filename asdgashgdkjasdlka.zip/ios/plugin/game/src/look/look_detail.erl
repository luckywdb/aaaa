%%寻访点
-module(look_detail).

%%%=======================STATEMENT====================
-description("look_detail").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    get_cfg/1,
    get_max_num/2,
    get_occ_sec/1,
    get_sid/1,
    get_event/3
]).

-export_type([look_detail/0]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(look_detail, {
    sid :: integer(),%%寻访点sid
    nor_max_num :: integer(),%%最大同时寻访人数,县城
    chi_max_num :: integer(),%%最大同时寻访人数,郡城
    occ_sec :: integer(),%%驻防时间(秒)
    envens :: tuple()%%事件权重列表(按时间选取权重列表,事件间隔时间直接用驻防上限时间除 权重列表 长度)
}).
%%%=======================TYPE=========================
-type look_detail() :: #look_detail{}.


%%%=================EXPORTED FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%      获取配置
%% @end
%%-------------------------------------------------------------------
-spec get_cfg(integer()) -> look_detail()|'none'.
get_cfg(Sid) ->
    zm_config:get('look_detail', Sid).

%%-------------------------------------------------------------------
%% @doc
%%      寻访点sid
%% @end
%%-------------------------------------------------------------------
-spec get_sid(look_detail()) -> integer().
get_sid(#look_detail{sid = Sid}) -> Sid.

%%-------------------------------------------------------------------
%% @doc
%%      最大寻访次数
%% @end
%%-------------------------------------------------------------------
-spec get_max_num(look_detail(), integer()|town_detail:town_detail()) -> integer().
get_max_num(#look_detail{nor_max_num = MaxTimes, chi_max_num = CMaxTimes}, Td) ->
    case town_detail:chk_chief(Td) of
        true ->
            CMaxTimes;
        false ->
            MaxTimes
    end.

%%-------------------------------------------------------------------
%% @doc
%%      驻防时间(秒)
%% @end
%%-------------------------------------------------------------------
-spec get_occ_sec(look_detail()) -> integer().
get_occ_sec(#look_detail{occ_sec = OccSec}) -> OccSec.

%%-------------------------------------------------------------------
%% @doc
%%      根据寻访开始时间,当前时间,获取当前事件权重列表并计算出具体事件
%% @end
%%-------------------------------------------------------------------
-spec get_event(look_detail(), integer(), integer()) -> integer().
get_event(LookDetail, STime, Now) ->
    Events = get_events(LookDetail),
    OccSec = get_occ_sec(LookDetail),
    Size = tuple_size(Events),
    IntervalTime = OccSec div Size,
    Nth = max(min(game_lib:ceil((Now - STime) / IntervalTime), Size), 1),
    WeightList = element(Nth, Events),
    game_lib:random_value(WeightList).

%%%===================LOCAL FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%      获取事件权重列表
%% @end
%%-------------------------------------------------------------------
-spec get_events(look_detail()) -> tuple().
get_events(#look_detail{envens = V}) -> V.


