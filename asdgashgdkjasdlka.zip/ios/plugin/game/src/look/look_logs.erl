-module(look_logs).

%%%=======================STATEMENT====================
-description("look_logs").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    init/2,
    get_logs/3,
    get_last_time/1,
    get_interval_time/1,
    get_logs/1,
    get_consumes/1,
    get_awards/1,
    get_garray/1,
    get_dead/1,
    get_card_exp/1,
    set_garray/2,
    add_dead/2,
    add_card_exp/2,
    add_logs/2,
    add_awards/2,
    add_consumes/2,
    set_time/3,
    log/7,
    event_time_index/0
]).

-export_type([look_logs/0, event_log/0]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(look_logs, {
    last_time = 0 :: integer(),%上次触发时间
    interval_time = 0 :: integer(),%下次触发间隔时间(=-1表示该轮寻访已经结束,返回中了)
    logs = [] :: [event_log()],%已触发事件具体信息
    consumes = [] :: list(),%所有消耗(目前只有粮食消耗)
    awards = [] :: list(), %已获得奖励列表
    garray = {} :: garray:garray(), %寻访开始时候阵型信息
    dead = 0 :: integer(), %总死亡
    card_exp = 0 :: integer() %整个事件增加武将经验(单个武将经验)
}).

-record(event_log, {
    time = 0 :: integer(),%事件触发时间
    sid = 0 :: integer(),%事件sid
    win = 0 :: integer(),%胜负
    consume = {} :: tuple(),%事件消耗
    awards = {} :: tuple(),%事件奖励
    card_exp = 0 :: integer(),%事件增加武将经验
    info = {} :: tuple() %事件其他描述用信息
}).
%%%=======================TYPE=========================
-type look_logs() :: #look_logs{}.
-type event_log() :: #event_log{}.

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%     初始化(玩家到达寻访点,开始寻访)
%% @end
%% ----------------------------------------------------
-spec init(STime :: integer(), Garray :: tuple()) -> look_logs().
init(STime, Garray) ->
    {_, StartEvent} = zm_config:get('look_other_info', 'arrive_event'),
    LookEvent = look_event:get_cfg(StartEvent),
    #look_logs{logs = [#event_log{sid = StartEvent}], %初始到达事件
        last_time = STime,
        interval_time = look_event:get_continue_time(LookEvent),
        garray = Garray}.

%% ----------------------------------------------------
%% @doc
%%     前台显示信息
%% @end
%% ----------------------------------------------------
-spec get_logs(look_logs(), integer(), integer()) -> tuple().
get_logs(LookLogs, Start, End) ->
    Logs = get_logs(LookLogs),
    Len = length(Logs),
    if
        Start > Len ->
            {};
        true ->
            list_to_tuple(lists:sublist(Logs, Start, End - Start + 1)) %倒序给前台(最近触发的放前面)
    end.

%% ----------------------------------------------------
%% @doc  
%%     获取上次触发时间
%% @end
%% ----------------------------------------------------
-spec get_last_time(look_logs()) -> integer().
get_last_time(#look_logs{last_time = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%     获取上次触发后此次间隔时间
%% @end
%% ----------------------------------------------------
-spec get_interval_time(look_logs()) -> integer().
get_interval_time(#look_logs{interval_time = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%     获取已触发事件logs
%% @end
%% ----------------------------------------------------
-spec get_logs(look_logs()) -> list().
get_logs(#look_logs{logs = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%     获取已触发事件消耗信息
%% @end
%% ----------------------------------------------------
-spec get_consumes(look_logs()) -> list().
get_consumes(#look_logs{consumes = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%     获取已触发事件已获得奖励信息
%% @end
%% ----------------------------------------------------
-spec get_awards(look_logs()) -> list().
get_awards(#look_logs{awards = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%     获取寻访开始阵型
%% @end
%% ----------------------------------------------------
-spec get_garray(look_logs()) -> tuple().
get_garray(#look_logs{garray = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%     总死亡数
%% @end
%% ----------------------------------------------------
-spec get_dead(look_logs()) -> integer().
get_dead(#look_logs{dead = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%     单个武将总经验
%% @end
%% ----------------------------------------------------
-spec get_card_exp(look_logs()) -> integer().
get_card_exp(#look_logs{card_exp = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%     寻访开始阵型
%% @end
%% ----------------------------------------------------
-spec set_garray(look_logs(), tuple()) -> look_logs().
set_garray(LookLogs, Garray) -> LookLogs#look_logs{garray = Garray}.

%% ----------------------------------------------------
%% @doc
%%     死亡数,经验
%% @end
%% ----------------------------------------------------
-spec add_dead(look_logs(), integer()) -> look_logs().
add_dead(LookLogs, Dead) ->
    NewDead = LookLogs#look_logs.dead + Dead,
    LookLogs#look_logs{dead = NewDead}.

%% ----------------------------------------------------
%% @doc
%%     单个武将总经验
%% @end
%% ----------------------------------------------------
-spec add_card_exp(look_logs(), integer()) -> look_logs().
add_card_exp(LookLogs, CardExp) ->
    NewCardExp = LookLogs#look_logs.card_exp + CardExp,
    LookLogs#look_logs{card_exp = NewCardExp}.

%% ----------------------------------------------------
%% @doc
%%      增加log
%% @end
%% ----------------------------------------------------
-spec add_logs(look_logs(), event_log()) -> look_logs().
add_logs(#look_logs{logs = Logs} = LookLogs, Log) ->
    LookLogs#look_logs{logs = [Log | Logs]}.

%% ----------------------------------------------------
%% @doc
%%      增加奖励
%% @end
%% ----------------------------------------------------
-spec add_awards(look_logs(), list()) -> look_logs().
add_awards(#look_logs{awards = AwardList} = LookLogs, Award) ->
    LookLogs#look_logs{awards = awarder_game:merger(AwardList, Award)}.

%% ----------------------------------------------------
%% @doc
%%      增加消耗
%% @end
%% ----------------------------------------------------
-spec add_consumes(look_logs(), list()) -> look_logs().
add_consumes(#look_logs{consumes = Consumes} = LookLogs, Consume) ->
    LookLogs#look_logs{consumes = awarder_game:merger(Consumes, Consume)}.

%% ----------------------------------------------------
%% @doc
%%      设置时间
%% @end
%% ----------------------------------------------------
-spec set_time(look_logs(), integer(), integer()) -> look_logs().
set_time(LookLogs, Ltime, Itime) ->
    LookLogs#look_logs{last_time = Ltime, interval_time = Itime}.

%% ----------------------------------------------------
%% @doc
%%     每条log记录信息
%% @end
%% ----------------------------------------------------
-spec log(Time, EventSid, Consume, Award, CardExp, Win, ViewData) -> event_log() when
    Time :: integer(),
    EventSid :: integer(),
    Consume :: list(),
    Award :: list(),
    CardExp :: integer(),
    Win :: integer(),
    ViewData :: tuple().
log(Time, EventSid, Consume, Award, CardExp, Win, ViewData) ->
    #event_log{
        time = Time,
        sid = EventSid,
        win = Win,
        consume = list_to_tuple(Consume),
        awards = list_to_tuple(Award),
        card_exp = CardExp,
        info = ViewData
    }.

event_time_index() ->
    #event_log.time.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
