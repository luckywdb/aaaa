-module(look_lib).

%%%=======================STATEMENT====================
-description("寻访点").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    check/3,
    consume/3
]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%     检测条件
%% @end
%% ----------------------------------------------------
-spec check(term(), term(), tuple()) -> boolean().
check(Role, 'look', {'forage', V}) ->%升级,检测粮草
    role:get_forage(Role) >= V;
check({Src, Role, _Gid, Garray}, 'check_condition', {'card_lv', CLv}) ->%事件胜负判定 所有武将等级>=
    RoleUid = role:get_uid(Role),
    CardStorage = storage_db:get_storage('card', Src, RoleUid),
    Queue = garray:get_queue(Garray),
    Fun = fun(Bool, _, {0, _}) ->
        {'ok', Bool};
        (Bool, _, {CUid, _Num}) ->
            {_, Prop} = storage_lib:find_by_uid(CardStorage, CUid),
            Card = prop_kit_lib:get_prop_record(Prop),
            case card:get_level(Card) >= CLv of
                true ->
                    {'ok', Bool};
                false ->
                    {'break', false}
            end
    end,
    z_lib:tuple_foreach(Queue, Fun, true);
check({_Src, _Role, _Gid, Garray}, 'check_condition', {'soldiers_num', SNum}) ->%队伍总数量>=
    GSNum = garray:get_garray_soldiers(Garray),
    GSNum >= SNum;
check({Src, Role, Gid, Garray}, 'check_condition', {{'attr', AttrType}, AttrNum}) ->%队伍任意武将属性>=
    FighgBattle = fighter:init_role(Src, role:get_uid(Role), Gid, 0, Garray),
    Fighters = fighter:get_fighters(FighgBattle),
    GFun = string_lib:to_atom("get_", AttrType),
    Fun = fun({Num, Name}, Fight) ->
        Num1 = fighter:GFun(Fight),
        if
            Num1 > Num ->
                {'ok', {Num1, fighter:get_name(Fight)}};
            true ->
                {'ok', {Num, Name}}
        end
    end,
    {MaxAttr, CardName} = z_lib:foreach(Fun, {0, ""}, Fighters),
    {MaxAttr >= AttrNum, CardName};
check({Src, Role, Gid, _Garray}, 'check_condition', {'power', Power}) ->%队伍战斗力
    attrs:get_garray_power(Src, role:get_uid(Role), Gid) >= Power;
check(_, _, _) ->
    false.

%% ----------------------------------------------------
%% @doc
%%     消耗
%% @end
%% ----------------------------------------------------
-spec consume(term(), term(), tuple()) -> {'none'|tuple(), tuple()}.
consume(Role, _, {'forage', Value}) ->
    {BiCs, Role1} = role_lib:deduct_forage(Role, Value),
    {BiCs, Role1};
consume(Table, _, _) ->%外部条件不需处理
    {'none', Table}.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
