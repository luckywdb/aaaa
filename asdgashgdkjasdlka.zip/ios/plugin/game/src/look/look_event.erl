-module(look_event).

%%%=======================STATEMENT====================
-description("寻访点事件").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    get_cfg/1,
    get_continue_time/1,
    get_loss/1,
    get_consume/1,
    get_condition/1,
    get_award/1,
    get_card_num/1,
    get_card_exp/1,
    get_desc/1
]).

-export_type([look_event/0]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(look_event, {
    sid :: integer(),%%事件sid
    continue_time :: integer(), %%事件持续时间
    loss = 0 :: integer(),%%是否损兵(-1=遭遇武将事件,0=不损失,>0不论胜负,损失兵量(从位置1往后挨着扣除,直到扣除损失量))
    consume = [] :: list(),%%触发该事件后,消耗(粮食等)
    condition = [] :: list(),%胜负条件  武将等级(全部都高于) ;士兵数量:(队伍总带兵量>该值);具体属性(任意某一个武将属性>该值);全队战斗力(>该值)
    award :: integer()|{integer(), integer()},%胜利后奖励sid
    card_num = {0, 0} :: {integer(), integer()},%遭遇武将事件个数:{min,max}
    card_exp = 0 :: integer(),%事件增加武将经验(全队武将增加值)
    desc = "" :: string()%%事件描述
}).

%%%=======================TYPE=========================
-type look_event() :: #look_event{}.


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%     获取寻访事件配置
%% @end
%% ----------------------------------------------------
-spec get_cfg(integer()) -> look_event().
get_cfg(Sid) ->
    zm_config:get('look_event', Sid).

%% ----------------------------------------------------
%% @doc
%%      获取该事件持续时间
%% @end
%% ----------------------------------------------------
-spec get_continue_time(look_event()) -> integer().
get_continue_time(#look_event{continue_time = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      获取该事件损兵量
%% @end
%% ----------------------------------------------------
-spec get_loss(look_event()) -> integer().
get_loss(#look_event{loss = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      获取该事件触发后消耗
%% @end
%% ----------------------------------------------------
-spec get_consume(look_event()) -> list().
get_consume(#look_event{consume = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      获取该事件判断胜负条件
%% @end
%% ----------------------------------------------------
-spec get_condition(look_event()) -> list().
get_condition(#look_event{condition = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      获取该事件胜利后奖励
%% @end
%% ----------------------------------------------------
-spec get_award(look_event()) -> integer().
get_award(#look_event{award = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      获取武将碎片个数
%% @end
%% ----------------------------------------------------
-spec get_card_num(look_event()) -> {integer(), integer()}.
get_card_num(#look_event{card_num = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      获取该事件胜利后武将增加经验值
%% @end
%% ----------------------------------------------------
-spec get_card_exp(look_event()) -> integer().
get_card_exp(#look_event{card_exp = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      获取该事件描述
%% @end
%% ----------------------------------------------------
-spec get_desc(look_event()) -> string().
get_desc(#look_event{desc = V}) -> V.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
