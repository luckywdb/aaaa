-module(getpve_port).

%%%=======================STATEMENT====================
-description("getpve_port").
-copyright('youkia,www.youkia.net').
-author("name,chenxiao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    info/5,
    get_pve/5
]).

%%%=======================INCLUDE======================

%%%=======================RECORD=======================

%%%=======================DEFINE=======================


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%     获取领取状态
%% @end
%% ----------------------------------------------------
info(_, _, Attr, Info, _Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, 'src', 'none'),
    {'ok', [], Info, [{'msg', getpve_db:getpve_info(Src, RoleUid)}]}.

%% ----------------------------------------------------
%% @doc
%%     获得体力
%% @end
%% ----------------------------------------------------
get_pve([{M, F, A}], _, Attr, Info, Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, 'src', 'none'),
    Sid = z_lib:get_value(Msg, "sid", 0),
    Type = z_lib:get_value(Msg, "type", 0),
    CheckVaild = valid_lib:check_valib([{'gt', Sid, 0}, {'range', Type, {0, 1}}]),
    if
        CheckVaild ->
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'role_restore', RoleUid}, {'get_pve', RoleUid, 'none'}]),
            case z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, role_db:get_role(Src, RoleUid), Sid, Type}, TableKeys) of
                {AwardLog, BiCs} ->
                    %% 获得体力日志
                    zm_log:info(Src, ?MODULE, 'getpve', "getpve", [{'roleuid', RoleUid}, {'sid', Sid}, {'consume', BiCs}, {'award', AwardLog}]),
                    %% 获得体力事件
                    zm_event:notify(Src, 'bi_getpve', [{'role_uid', RoleUid}, {'sid', Sid}, {'consume', BiCs}, {'award', AwardLog}]),
                    {ok, [], Info, [{msg, "ok"}]};
                Reply ->
                    {ok, [], Info, [{msg, Reply}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.
