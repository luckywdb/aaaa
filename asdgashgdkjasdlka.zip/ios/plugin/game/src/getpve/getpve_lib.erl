-module(getpve_lib).

%%%=======================STATEMENT====================
-description("getpve_lib").
-copyright('youkia,www.youkia.net').
-author("cx,chenxiao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    check/3,
    consume/3
]).

%%%=======================INCLUDE======================

%%%=======================RECORD=======================

%%%=======================DEFINE=======================


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%     检测条件
%% @end
%% ----------------------------------------------------
-spec check(term(), term(), tuple()) -> boolean().
check({_Src, _RoleUid}, _, {'time', {{SH, SM, SS}, {EH, EM, ES}}}) ->%检测时间
    Time = time_lib:get_current_second(),
    StartTime = (SH * 60 + SM) * 60 + SS,
    EndTime = (EH * 60 + EM) * 60 + ES,
    Time >= StartTime andalso Time < EndTime;
check({_Src, _RoleUid}, _, {'time', {EH, EM, ES}}) ->%检测时间
    Time = time_lib:get_current_second(),
    EndTime = (EH * 60 + EM) * 60 + ES,
    Time >= EndTime;
check({Src, RoleUid}, _, {'rmb', NeedRmb}) ->%检测rmb
    rmb_db:get_all_rmb(Src, RoleUid) >= NeedRmb;
check(_, _, _) ->
    false.

%% ----------------------------------------------------
%% @doc
%%     消耗
%% @end
%% ----------------------------------------------------
-spec consume(term(), term(), tuple()) -> {'none'|tuple(), tuple()}.
consume({Src, RoleUid}, _, {'rmb', NeedRmb}) ->%升级,临时队列扣rmb,秒cd资源消耗
    Fun = fun(_, Rmb) ->
        {BiCs, NRmb} = rmb_lib:reduct_rmb(Rmb, NeedRmb),
        {'ok', BiCs, NRmb}
    end,
    Bi = z_db_lib:update(game_lib:get_table(Src, 'rmb'), RoleUid, {0, 0}, Fun, []),
    {Bi, {Src, RoleUid}};
consume(Table, _, _) ->%外部条件不需处理
    {[], Table}.
