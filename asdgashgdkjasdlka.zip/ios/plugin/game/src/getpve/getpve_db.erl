-module(getpve_db).

%%%=======================STATEMENT====================
-description("getpve_db").
-copyright('youkia,www.youkia.net').
-author("name,chenxiao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    getpve_info/2,
    get_pve/3
]).

%%%=======================INCLUDE======================

%%%=======================RECORD=======================

%%%=======================DEFINE=======================


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%     获取领奖信息
%% @end
%% ----------------------------------------------------
getpve_info(Src, RoleUid) ->
    Day = time_lib:get_date_by_type('day_of_year'),
    Fun = fun(_, {Day1, AwardList}) when Day1 =:= Day ->
        {'ok', list_to_tuple(AwardList)};
        (_, _) ->
            {'ok', {}, {Day, []}}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'get_pve'), RoleUid, 'none', Fun, []).

%% ----------------------------------------------------
%% @doc
%%     领取体力(type=0正常领取,=1补领)
%% @end
%% ----------------------------------------------------
get_pve(_A, {Src, RoleUid, Role, Sid, Type}, [{Index1, RoleRestore}, {Index2, GetPve}]) ->
    Day = time_lib:get_date_by_type('day_of_year'),
    NGetPve =
        case GetPve of
            {Day, AwardList} ->
                case lists:member(Sid, AwardList) of
                    true ->
                        throw("getpve_awarded");
                    false ->
                        {Day, [Sid | AwardList]}
                end;
            _ ->
                {Day, [Sid]}
        end,
    {_, Condition, AwardNum, PvpAwardNum, Consumes} = zm_config:get('getpve_info', Sid),
    Conditions =
        if
            Type =:= 0 ->
                Condition;
            true ->
                {_, {_, ETime}} = lists:keyfind('time', 1, Condition),
                [{'time', ETime} | Consumes]
        end,
    ChkBool = game_lib:checks({'getpve_lib', 'check'}, {Src, RoleUid}, 'getpve', Conditions),
    if
        ChkBool ->
            Limit = restore_lib:get_limit('pve'),
            LimitPvp = restore_lib:get_limit('pve'),
            Pve = restore_lib:get_value(RoleRestore, 'pve'),
            Pvp = restore_lib:get_value(RoleRestore, 'pvp'),
            if
                Pve >= Limit ->
                    throw("pve_limit");
                true ->
                    %%顺带附加五点pvp体力
                    NAwardPvpNum = min(PvpAwardNum, LimitPvp - Pvp),
                    NAwardNum = min(AwardNum, Limit - Pve),
                    NRestore = restore_lib:update(RoleRestore, time_lib:now_second(), restore_lib:get_max(Src, Role, 'pve'), 'pve', NAwardNum),
                    NRestore1 = restore_lib:update(NRestore, time_lib:now_second(), restore_lib:get_max(Src, Role, 'pvp'), 'pvp', NAwardPvpNum),
                    {BiCs, _} = game_lib:consumes({'getpve_lib', 'consume'}, {Src, RoleUid}, 'getpve', Conditions),
                    {'ok', {{{'pve', AwardNum, restore_lib:get_value(NRestore1, 'pve')},
                        {'pvp', NAwardPvpNum, restore_lib:get_value(NRestore1, 'pvp')}}, BiCs}, [{Index1, NRestore1}, {Index2, NGetPve}]}
            end;
        true ->
            throw(ChkBool)
    end.

