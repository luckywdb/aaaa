-module(login_event).

-description("login_event").
-copyright({seasky, 'www.seasky.cn'}).
-author({cb, 'chenbin@seaskyjoy.com'}).
-vsn(1).
%%%=======================EXPORT=======================
-export([close_con/4, notify/4]).
-export([delete/5, new_castle/3]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").
%%-------------------------------------------------------------------
%% @doc
%%      断线消息
%% @end
%%-------------------------------------------------------------------
-spec close_con(_, Src, {zm_tcp_con, closed}, {Session, Info, _}) -> false|string() when
    Src :: atom(),
    Session :: tuple(),
    Info :: list().
close_con(_, Src, {zm_tcp_con, closed}, {Session, Info, _}) ->%%其它异常处理
    close(Src, Session, Info).

%% ----------------------------------------------------
%% @doc
%%      通知记录缓存,重登陆
%% @end
%% ----------------------------------------------------
-spec notify(_, Src, Type, Args) -> 'ok' when
    Src :: atom(),
    Type :: 'login'|'relogin',
    Args :: list().
notify(_, Src, 'login', Args) ->%%这里处理被清理的不活跃小号再次登陆的数据
    clear_missing_role(Src, Args),
    old_role_active(Src, Args);%%处理老玩家回归活动信息
notify(_, _Src, 'relogin', _Args) ->
    ok.
%%%=================LOCAL FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      断线处理
%% @end
%%-------------------------------------------------------------------
-spec close(Src, Session, Info) -> false|'ok' when
    Src :: atom(),
    Session :: game_types:session(),
    Info :: list().
close(Src, Session, Info) ->
    case get_attr(Session) of
        none ->
            false;
        nil ->
            z_db_lib:update(game_lib:get_table(Src, 'common'), 'clear_dead_online', 2),
            false;
        Attr ->
            case z_lib:get_value(Attr, 'role_uid', none) of
                none ->
                    false;
                {RoleUid, _, _} when is_integer(RoleUid) ->%%玩家
                    delete(Src, RoleUid, get_con(Session), Attr, Info);
                {RoleUid, _, _} when is_list(RoleUid) ->%%监控者
                    %%删除监听者
                    monitor_db:delete_monitor(Src, RoleUid)
            end
    end.

delete(Src, RoleUid, Session, Attr, Info) ->
    case login_db:delete_online(Src, RoleUid, Session) of
        ok ->%%写最后登录时间
            Fun = fun(Logouttime, GUser) -> {ok, ok, guser:set_logout_time(GUser, Logouttime)} end,
            z_db_lib:update(game_lib:get_table(Src, 'user'), RoleUid, Fun, time_lib:now_second()),
            try
                zm_event:notify(Src, 'logout', [{'role_uid', RoleUid}, {'attr', Attr}, {'info', Info}]),
                %% 记录玩家登出信息
                log_lib:log_login(?MODULE, "handle_login_out", [{'user_uid', RoleUid}, {'attr', Attr}, {'info', Info}])
            catch
                _:Err ->
                    zm_log:warn(Src, ?MODULE, 'logout_err', "logout_err", [{'role_uid', RoleUid},
                        {'err', Err}, {'stacktrace', erlang:get_stacktrace()}]),
                    ok
            end;

        Res ->
            Res
    end.

%% ----------------------------------------------------
%% @doc
%%      取session中的登录存入数据(等于port中的Attr)
%% @end
%% ----------------------------------------------------
-spec get_attr(Session) -> game_types:attr() when Session :: game_types:session().
get_attr(Session) ->
    {zm_session, _Con, _Time, Attr, _Sequence, _Concurrent, _Collatetime} = Session,
    Attr.
%% ----------------------------------------------------
%% @doc
%%      取session中的connect
%% @end
%% ----------------------------------------------------
-spec get_con(Session) -> tuple() when Session :: game_types:session().
get_con(Seesion) ->
    {zm_session, Con, _Time, _Attr, _Sequence, _Concurrent, _Collatetime} = Seesion,
    Con.

%%登陆处理被清理的小号数据
clear_missing_role(Src, Args) ->
    %Args=[{'username', UserName}, {'role', Role}, {login, Login}, {'msg', Msg}, {'info', Info}, {'reply', "login_ok"}]
    {_, Role} = lists:keyfind('role', 1, Args),
    Country = role:get_country(Role),
    RoleUid = role:get_uid(Role),
    Check = check_role_new_point(Src, RoleUid, Country),
    if
        Check ->
            BornIndex = uid_lib:get_born_index(Src),
            NPointBorns = point_born:get_point_born(Src, BornIndex, 0),
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'castle', RoleUid, castle:init()} |
                [{'point_state', Np, 'none'} || Np <- tuple_to_list(NPointBorns)]]),
            case z_db_lib:handle(TableName, {?MODULE, new_castle, []}, {Src, RoleUid, NPointBorns}, TableKeys) of
                {ok, Castle} ->
                    role_event:update_role_show_notify(1, Src, 'update_role_show', {RoleUid, {'castle', {Country, Castle}}}),
                    %%给前台推送新的主城坐标
                    set_front_lib:send_castle_point(Src, RoleUid, element(1, NPointBorns)),
                    ok;
                _ ->%%对于取坐标失败的玩家，判断Args中的num次数，如果大于10次，不再继续处理
                    Num = z_lib:get_value(Args, 'num', 0),
                    if
                        Num >= 10 -> ok;
                        true ->
                            NArgs = lists:keystore('num', 1, Args, {'num', Num + 1}),
                            clear_missing_role(Src, NArgs)
                    end
            end;
        true -> ok
    end.
%%满足条件的玩家：有国家，但是主城坐标都被置为0 返回true，其余返回false
check_role_new_point(Src, RoleUid, Country) ->
    if
        Country > 0 ->%%玩家有国家，再次检测主城坐标
            role_show:get_point(role_db:get_role_show(Src, RoleUid)) =:= 0;
        true ->
            false
    end.

%%对于需要重新分配坐标的玩家，修改point_state表中的数据
new_castle(_A, {_Src, RoleUid, PointBrons}, [{Index1, Castle} | T]) ->
    ReplyBornList = [{I, {?ROLE, RoleUid}} || {I, V} <- T, V =:= 'none'],
    if
        length(ReplyBornList) =:= length(T) ->
            'ok';
        true ->
            throw("born_point_error") %取出的坐标点已经被使用了
    end,
    NCastle = castle:set_points(Castle, PointBrons),
    NewData = [{Index1, NCastle} | ReplyBornList],
    {ok, {ok, NCastle}, NewData}.

old_role_active(Src, Args) ->
    %Args=[{'username', UserName}, {'role', Role}, {login, Login}, {'msg', Msg}, {'info', Info}, {'reply', "login_ok"}]
    {_, Role} = lists:keyfind('role', 1, Args),
    RoleUid = role:get_uid(Role),
    Table = game_lib:get_table(Src, 'active_old_role'),

    case z_db_lib:get(Table, RoleUid, 'none') of
        'none' -> ok;
        ActiveSid ->
            Active = z_db_lib:get(game_lib:get_table(Src, 'active'), active_lib:get_active_key(Src, ActiveSid), {}),
            active_old_role:handle_event1(Src, Active, Role),
            ok
    end.