-module(login_db).

-description("login_db").
-copyright({seasky, 'www.seasky.cn'}).
-author({hzh, 'huanzghenghan@youkia.net'}).
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_server/0, handle_args/2, handle_user/4, handle_login/7]).
%%在线表操作
-export([get_online/2, delete_online/3, get_count/1, get_all_online/1, get_country_online/2,
    get_all_online_uid/1, get_country_online_uid/2, is_online/2]).

-export([send_all_online/2, send_country_online/3]).
-export([get_uid_psu/2, get_psu_uid/2]).

%%%=======================DEFINE======================
-define(CREATE, 0).%创建
-define(CREATE_NO, 1).%限制创建
-define(LOGIN_NO, 1).%限制登录
-define(GM, 2).%gm帐号
%%%=======================INCLUDE======================
-include("../include/role.hrl").
-include("../../../include/sign_key.hrl").


%%%===================EXPORT FUNCTIONS==================
%%---------------------------------------------------
%% @doc
%%      处理server级校验
%% @end
%%----------------------------------------------------
-spec handle_server() -> 'ok'|string().
handle_server() ->
    Bool = zm_load:server_start_ok() =:= ?KEY,
    if
        Bool ->
            ok;%%服务已经启动完成
        true ->
            throw("server_starting")
    end.
%%---------------------------------------------------
%% @doc
%%      处理url 参数
%% @end
%%----------------------------------------------------
-spec handle_args(Src, Msg) -> string()|login:login() when
    Src :: atom(),
    Msg :: list().
handle_args(Src, Msg) ->
    Bool = login_db:get_count(Src) >= args_system:get_login_max(Src),
    if
        Bool ->%%人数大于max也不可以进
            throw("limit_count");
        true ->
            Login = login:init(Src, Msg),
            Bool1 = login:get_sign_state(Login),
            if
                not Bool1 ->%%签名没有过
                    throw("sig_error");
                true ->
                    %%帐号被禁用
                    case monitor_db:get_username(Src, login:get_pid(Login)) of
                        'none' ->
                            Login;
                        _ ->
                            throw("pid_disable")
                    end
            end
    end.
%%---------------------------------------------------
%% @doc
%%      handle_user
%% @end
%%----------------------------------------------------
-spec handle_user(Src, IP, Login, _) -> integer()|string() when
    Src :: atom(),
    IP :: tuple(),
    Login :: login:login().
handle_user(Src, IP, Login, _Msg) ->
    Platform = login:get_platform(Login),
    Server = login:get_server(Login),
    Pid = login:get_pid(Login),
    case zm_db_client:transaction([{game_lib:get_table(Src, 'psu_uid'), {Platform, Server, Pid}}], fun handle_user_/2, {Src, IP, Login}, 9000) of
        {'ok', {register, UserId}} ->
            zm_event:notify(Src, 'bi_register_user_ok', [{'user_id', UserId}, {'login', Login}, {'ip', IP}]),
            UserId;
        {'ok', UserId} ->
            UserId;
        {'break', Reason} ->
            throw(Reason);
        {'error', Reason} ->
            throw(Reason)
    end.

%%---------------------------------------------------
%% @doc
%%      处理登录
%% @end
%%----------------------------------------------------
handle_login(Src, RoleUid, Session, Login, Msg, Info, MapId) ->
    case zm_db_client:transaction([{game_lib:get_table(Src, 'user'), RoleUid},
        {game_lib:get_table(Src, 'role'), RoleUid}, {game_lib:get_table(Src, 'online'), RoleUid}],
        fun handle_login_/2, {RoleUid, Session, Login, time_lib:now_second(), Msg, Info, MapId}, 9000) of
        {'ok', {Type, Reply, NMsg}} when is_atom(Type) ->%% 角色登录或重登
            %% 抛出(登录,重登)事件
            zm_event:notify(Src, Type, NMsg),
            Reply;
        {'ok', {Attr, NoRoleReply}} ->%% 角色未创建
            %%先检测玩家的渠道是否被限制在这服服务器创建角色
            LimitPlatforms = args_expend:get_limit_create_platform(Src),
            case lists:member(login:get_platform_id(Login), LimitPlatforms) of
                true ->
                    throw("limit_create");
                false ->
                    %% 抛出注册登录事件
                    zm_event:notify(Src, 'login_no_role', {Attr, Info, Msg}),
                    %%获取好名字
                    Names = role_name_db:get_good_name(Src, RoleUid),
                    {Attr, erlang:append_element(NoRoleReply, Names)}
            end;
        {'break', Reason} ->
            throw(Reason);
        {'error', Reason} ->
            throw(Reason)
    end.

%%---------------------------------------------------
%% @doc
%%      得到在线人数
%% @end
%%----------------------------------------------------
-spec get_count(Src) -> integer()|string() when Src :: atom().
get_count(Src) ->
    case zm_db_client:count(game_lib:get_table(Src, 'online')) of
        {ok, Number} ->
            Number;
        Reason ->
            throw(Reason)
    end.

%% -----------------------------------------------------------------
%% @doc
%%      得到在线列表 Online={session,country}
%% @end
%% -----------------------------------------------------------------
-spec get_online(Src, RoleUid) -> 'none'|tuple() when
    Src :: atom(),
    RoleUid :: integer().
get_online(Src, RoleUid) ->
    case z_db_lib:get(game_lib:get_table(Src, online), RoleUid, none) of
        {Session, _} ->
            Session;
        _ ->
            'none'
    end.

%% -----------------------------------------------------------------
%% @doc
%%      判断玩家是否在线, Returns: 1 不在线 0 在线
%% @end
%% -----------------------------------------------------------------
-spec is_online(Src, RoleUid) -> 1|0 when
    Src :: atom(),
    RoleUid :: integer().
is_online(Src, RoleUid) ->
    case z_db_lib:get(game_lib:get_table(Src, online), RoleUid, none) of
        none ->
            1;
        _ ->
            0
    end.

%%---------------------------------------------------
%% @doc
%%      删除在线信息(顶号不进行删除session,因登陆已经改)
%% @end
%%----------------------------------------------------
-spec delete_online(Src, RoleUid, Session) -> 'ok'|false when
    Src :: atom(),
    RoleUid :: integer(),
    Session :: tuple().
delete_online(Src, RoleUid, Session) ->
    Table = game_lib:get_table(Src, 'online'),
    case z_db_lib:get(Table, RoleUid, none) of
        none ->
            false;
        {Session, _} ->
            F = fun(_, {Session1, _}) when Session1 =:= Session ->
                {'ok', 'ok', 'delete'};
                (_, _) ->
                    {'ok', 'ok'}
            end,
            z_db_lib:update(Table, RoleUid, 'none', F, []);
        _ ->
            false
    end.

%%---------------------------------------------------
%% @doc
%%      得到在线表
%% @end
%%----------------------------------------------------
-spec get_all_online(Src) -> list()|string() when Src :: atom().
get_all_online(Src) ->
    Table = game_lib:get_table(Src, online),
    case zm_db_client:iterate(Table, descending, false) of
        {ok, Iterator} ->
            case iterator(Src, Iterator, fun(S, K, R) ->
                case get_online(S, K) of none -> R; OR -> [OR | R] end end, []) of
                {ok, Onlines} ->
                    Onlines;
                {error, Reason} ->
                    throw(Reason)
            end;
        {error, Reason} ->
            throw(Reason)
    end.

%%-------------------------------------------------------------------
%% @doc
%%      给所有在线玩家发送消息
%% @end
%%-------------------------------------------------------------------
-spec send_all_online(atom(), tuple()) -> list().
send_all_online(Src, Msg) ->
    Table = game_lib:get_table(Src, online),
    case zm_db_client:iterate(Table, descending, false) of
        {ok, Iterator} ->
            case iterator(Src, Iterator, fun(_S, K, R) ->
                case z_db_lib:get(Table, K) of
                    {Session, _} ->
                        zm_session:send(Session, Msg),
                        R;
                    _ -> R
                end end, []) of
                {ok, Onlines} ->
                    Onlines;
                {error, Reason} ->
                    throw(Reason)
            end;
        {error, Reason} ->
            throw(Reason)
    end.

%%-------------------------------------------------------------------
%% @doc
%%      给指定国家在线玩家发送消息
%% @end
%%-------------------------------------------------------------------
-spec send_country_online(atom(), integer(), tuple()) -> list().
send_country_online(Src, Country, Msg) ->
    Table = game_lib:get_table(Src, online),
    case zm_db_client:iterate(Table, descending, false) of
        {ok, Iterator} ->
            case iterator(Src, Iterator, fun(_S, K, R) ->
                case z_db_lib:get(Table, K) of
                    {Session, Country} ->
                        zm_session:send(Session, Msg),
                        R;
                    _ -> R
                end end, []) of
                {ok, Onlines} ->
                    Onlines;
                {error, Reason} ->
                    throw(Reason)
            end;
        {error, Reason} ->
            throw(Reason)
    end.

%%---------------------------------------------------
%% @doc
%%      得到在线表(国家或者跨服地图)
%% @end
%%----------------------------------------------------
-spec get_country_online(Src, Country) -> list()|string() when
    Src :: atom(),
    Country :: integer().
get_country_online(Src, Country) ->
    Table = game_lib:get_table(Src, online),
    case zm_db_client:iterate(Table, descending, false) of
        {ok, Iterator} ->
            case iterator(Src, Iterator, fun(_S, K, R) ->
                case z_db_lib:get(Table, K) of
                    {OR, Country} ->
                        [OR | R];
                    _ -> R
                end end, []) of
                {ok, Onlines} ->
                    Onlines;
                {error, Reason} ->
                    throw(Reason)
            end;
        {error, Reason} ->
            throw(Reason)
    end.
%%迭代器处理数据
iterator(Src, Iterator, ValueFun, R) ->
    case zm_db_client:iterate_next(Iterator) of
        {ok, {Key, _, _}, NewIterator} ->
            iterator(Src, NewIterator, ValueFun, ValueFun(Src, Key, R));
        over ->
            {ok, R};
        E ->
            E
    end.

%%---------------------------------------------------
%% @doc
%%      获得所有在线玩家uid
%% @end
%%----------------------------------------------------
-spec get_all_online_uid(Src) -> list()|string() when Src :: atom().
get_all_online_uid(Src) ->
    Table = game_lib:get_table(Src, online),
    case zm_db_client:iterate(Table, descending, false) of
        {ok, Iterator} ->
            case iterator(Src, Iterator, fun(_S, K, R) -> [K | R] end, []) of
                {ok, Onlines} ->
                    Onlines;
                {error, Reason} ->
                    throw(Reason)
            end;
        {error, Reason} ->
            throw(Reason)
    end.

%%---------------------------------------------------
%% @doc
%%      获得指定国家所有在线玩家uid
%% @end
%%----------------------------------------------------
-spec get_country_online_uid(Src, Country) -> list()|string() when
    Src :: atom(),
    Country :: integer().
get_country_online_uid(Src, Country) ->
    Table = game_lib:get_table(Src, online),
    case zm_db_client:iterate(Table, descending, false) of
        {ok, Iterator} ->
            F = fun(_S, K, R) ->
                RoleCountry = element(2, z_db_lib:get(Table, K)),
                if
                    RoleCountry =:= Country ->
                        [K | R];
                    true ->
                        R
                end
            end,
            case iterator(Src, Iterator, F, []) of
                {ok, Onlines} ->
                    Onlines;
                {error, Reason} ->
                    throw(Reason)
            end;
        {error, Reason} ->
            throw(Reason)
    end.

%%-------------------------------------------------------------------
%% @doc
%%      根据UserId获得玩家平台账号信息{游戏服平台id,服务器Id,平台账号}
%% @end
%%-------------------------------------------------------------------
-spec get_uid_psu(Src :: atom(), UserId :: integer()) -> 'none' | {integer(), integer(), string()}.
get_uid_psu(Src, UserId) ->
    z_db_lib:get(game_lib:get_table(Src, 'uid_psu'), UserId, 'none').

%%-------------------------------------------------------------------
%% @doc
%%      根据平台账号获得玩家UserId
%% @end
%%-------------------------------------------------------------------
-spec get_psu_uid(Src :: atom(), RoleUid :: string()) -> 'none' | integer().
get_psu_uid(Src, RoleUid) ->
    Pid = uid_lib:get_pid(RoleUid),
    Sid = uid_lib:get_sid(RoleUid),
    z_db_lib:get(game_lib:get_table(Src, 'psu_uid'), {Pid, Sid, RoleUid}, 'none').


%%%======================LOC FUNCTIONS==================
%%---------------------------------------------------
%% @doc
%%      处理登陆user信息
%% @end
%%----------------------------------------------------
-spec handle_user_({Src, _IP, _Login}, [UserUid]) -> tuple() when
    Src :: atom(),
    UserUid :: '$nil'|integer().
handle_user_({Src, IP, Login}, ['$nil']) ->
    Platform = login:get_platform(Login),
    Server = login:get_server(Login),
    Pid = login:get_pid(Login),
    Bool = args_system:get_login_statue(Src) =:= ?LOGIN_NO,%%服务器限制登录
    if
        Bool ->
            {break, "limit_login"};
        true ->
            Bool1 = args_system:get_create_statue(Src) =/= ?CREATE,
            if
                Bool1 ->
                    {break, "limit_create"};
                true ->
                    %%检测创建角色数是否已达最大
                    case z_db_lib:get_count(game_lib:get_table(Src, 'user')) >= args_system:get_create_max(Src) of
                        true ->
                            {break, "limit_create"};
                        false ->
                            Guser = guser:init(IP, Login),
                            UserUid = uid_lib:get_uid(Platform, Server, uid_lib:create_user_uid(Src, Platform, Server)),
                            {ok, {register, UserUid}, [UserUid], [{game_lib:get_table(Src, user), UserUid, Guser},
                                {game_lib:get_table(Src, 'uid_psu'), UserUid, {Platform, Server, Pid}}]}
                    end
            end
    end;
handle_user_({Src, _IP, _Login}, [UserUid]) ->
    Guser = user_db:get_user(Src, UserUid),
    %%gm帐号可以直接进行，未限制登录可进入
    Bool = guser:get_type(Guser) =:= ?GM orelse (args_system:get_login_statue(Src) =/= ?LOGIN_NO),
    if
        Bool ->
            Bool1 = guser:is_status(Guser, 'trust'),
            if
                Bool1 ->%%帐号被托管不可登录
                    {break, "trusting"};
                true ->
                    %%账号冻结检测 true表示账号冻结
                    Bool2 = user_db:get_disable_user(Src, UserUid) > time_lib:now_second(),
                    if
                        Bool2 ->
                            {break, "user_disable"};
                        true ->
                            {ok, UserUid, ['$ignore']}
                    end
            end;
        true ->
            {break, "limit_login"}
    end.

%%---------------------------------------------------
%% @doc
%%      处理登录信息
%% @end
%%----------------------------------------------------
-spec handle_login_(tuple(), list()) -> tuple().
handle_login_({RoleUid, _Session, Login, Time, Msg, Info, _MapId}, [Guser, '$nil', _]) ->
    UserName = {login:get_platform(Login), login:get_server(Login), login:get_pid(Login)},
    Reply = {[{'username', UserName}, {'user_uid', RoleUid}, {'login', Login}],
        {"no_role", Time, game_lib:get_client_version(), z_lib:get_value(Msg, "timestamp", "")}},
    NGuser = guser:login(Guser, Login, z_lib:get_value(Info, ip, ""), 0),
    {ok, Reply, [NGuser, '$ignore', '$ignore']};
handle_login_({RoleUid, Session, Login, Time, Msg, Info, MapId}, [Guser, Role, '$nil']) ->
    UserName = {login:get_platform(Login), login:get_server(Login), login:get_pid(Login)},
    Country = role:get_country(Role),
    Reply = {[{'username', UserName}, {'user_uid', RoleUid}, {'role_uid', RoleUid}, {'country', Country}],
        {"login_ok", Time, game_lib:get_client_version(), z_lib:get_value(Msg, "timestamp", "")}},
    NGuser = guser:login(Guser, Login, z_lib:get_value(Info, ip, ""), Time),
    NewCountry =
        if
            MapId > 0 ->%跨服在线表作为地图
                MapId;
            true ->
                Country
        end,
    {ok, {'login', Reply, [{'username', UserName}, {'role', Role}, {login, Login}, {'msg', Msg}, {'info', Info}, {'reply', "login_ok"}]},
        [NGuser, '$ignore', {Session, NewCountry}]};
handle_login_({RoleUid, Session, Login, Time, Msg, Info, MapId}, [Guser, Role, {OldSession, _}]) ->%%顶号
    UserName = {login:get_platform(Login), login:get_server(Login), login:get_pid(Login)},
    Country = role:get_country(Role),
    Reply = {[{'username', UserName}, {'user_uid', RoleUid}, {'role_uid', RoleUid},
        {'country', Country}], {"relogin_ok", Time, game_lib:get_client_version(), z_lib:get_value(Msg, "timestamp", "")}},
    zm_session:send(OldSession, {'system_notice', [{'msg', 'offline'}]}),
    zm_session:close(OldSession, {'stop', 'tcp_closed'}),
    NGuser = guser:login(Guser, Login, z_lib:get_value(Info, ip, ""), Time),
    NewCountry =
        if
            MapId > 0 ->%跨服在线表作为地图
                MapId;
            true ->
                Country
        end,
    {ok, {'relogin', Reply, [{'username', UserName}, {'role', Role}, {login, Login}, {'msg', Msg}, {'info', Info}, {'reply', "relogin_ok"}]},
        [NGuser, '$ignore', {Session, NewCountry}]}.


