%%登陆用记录，解决匹配问题
-module(login).
-description("login").
-copyright("seasky,www.seasky.cn").
-author("cb, chenbin@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    init/2,
    init/3,
    set_pid/2
]).
-export([
    get_sign_state/1,
    get_platform/1,
    get_server/1,
    get_pid/1,
    get_invite_user/1,
    get_platform_id/1,
    get_youkiaid/1,
    get_device_id/1,
    get_phonename/1,
    get_memtotal/1,
    get_osversion/1,
    get_carriertype/1,
    get_networktype/1,
    get_o_system/1,
    get_push_id/1,
    get_cpsid/1
]).

-export_type([login/0]).
%%%=======================INCLUDE======================

%%%=======================RECORD=======================
-record(login, {
    sign_state :: boolean(),%sign_state 签名状态
    platform :: integer(),%platform 游戏服平台id
    server :: integer(),%server 游戏服务器id(合服以后可能用到)
    pid :: string(),%pid 平台帐号
    nick_name :: string(),%nick_name 平台昵称
    invite_user :: string(),%invite_user 邀请帐号
    vip :: integer(),%vip 平台vip
    time :: integer(),%time 登录时间
    sign :: string(),%sign 签名
    platform_id = 0 :: integer(),%平台id(360手机助手渠道或360网页渠道),接入中心传入的,sdk传入的平台id
    youkiaid = 0 :: integer(), %youkiaid 手机唯一定义id，由youkia平台提供
    device_id = 0 :: integer(),
    phonename = "",%获得手机名称，由SDK传入
    memtotal = "",%获得手机内存，由SDK传入
    osversion = "0",%获得操作系统版本，由SDK传入
    carriertype = "",%获得运营商，由SDK传入
    networktype = "",%获得网络类型，由SDK传入
    o_system = 1, %android还是ios :0=未知, 1=android,2=ios
    push_id = 0, %ios推送用id
    cpsid = 0 %因市场部广告投放需要在bi里统计相关数据，现需要将广告渠道标识id记录到bi_player表
}).
%%%=======================DEFINE=======================

%%%=======================TYPE=========================
-type login() :: #login{}.

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      初始登录
%% @end
%% ----------------------------------------------------
-spec init(Src, Msg) -> string()|login() when
    Src :: atom(),
    Msg :: list().
init(Src, Msg) ->
    init(Src, Msg, false).

%% ----------------------------------------------------
%% @doc
%%      初始登录
%% @end
%% ----------------------------------------------------
-spec init(Src, Msg, ComeIn) -> string()|login() when
    Src :: atom(),
    Msg :: list(),
    ComeIn :: boolean().
init(Src, Msg, ComeIn) ->
    Bool = ({ok, [["network"]]} =:= init:get_argument('statue')) orelse ComeIn,
    if
        Bool ->
            Pid = z_lib:get_value(Msg, "userid", "0"),
            #login{sign_state = true, platform = args_system:get_pid(Src), server = args_system:get_sid(Src), pid = Pid};
        true ->
            Args = login_lib:analyse_login_url_args(z_lib:get_value(Msg, "url", "")),
            ServerName = z_lib:get_value(Args, 'server_name', 'none'),%服务器名称
            case z_db_lib:get(game_lib:get_table(Src, 'identity'), ServerName) of
                {Platform, Server} ->
                    Pid = z_lib:get_value(Args, 'pid', ""), %%平台帐号
                    Nickname = z_lib:get_value(Args, 'nickname', ""), %%平台昵称
                    Time = z_lib:get_value(Args, 'time', ""),%% 登录时间,
                    Sign = z_lib:get_value(Args, 'sig', ""),%%签名
                    PlatformId = z_lib:get_value(Args, 'platform_id', 0),%%bi平台id(360手机助手渠道或360网页渠道),接入中心传入的
                    YoukiaId = z_lib:get_value(Args, 'youkiaid', 1),%% 手机唯一定义id，由youkia平台提供
                    DeviceId = z_lib:get_value(Msg, "deviceId", 0),%% 手机设备号，前台提供
                    Phonename = z_lib:get_value(Args, 'phone_name', ""),
                    Memtotal = z_lib:get_value(Args, 'memory_total', ""),
                    Osversion = z_lib:get_value(Args, 'os_version', ""),
                    Carriertype = z_lib:get_value(Args, 'carrier_type', ""),
                    Networktype = z_lib:get_value(Args, 'network_type', ""),
                    OSystem = z_lib:get_value(Args, 'o_system', 0),%玩家使用的是,Android还是ios手机
                    PushID = z_lib:get_value(Args, 'push_id', 0),%ios的推送id
                    Cpsid = z_lib:get_value(Args, 'cpsid', 0),%广告渠道

                    %%下面是平台暂时未传的参数
                    InviteUser = z_lib:get_value(Args, 'invite_user', ""), %邀请帐号
                    Vip = z_lib:get_value(Args, 'vip', 0),%平台vip
                    #login{sign_state = sign_lib:login_check(Sign, {Pid, Time}), platform = Platform, server = Server,
                        pid = Pid, nick_name = Nickname, invite_user = InviteUser, vip = Vip, time = Time,
                        sign = Sign, platform_id = PlatformId, youkiaid = YoukiaId, device_id = DeviceId, phonename = Phonename,
                        memtotal = Memtotal, osversion = Osversion, carriertype = Carriertype, networktype = Networktype,
                        o_system = OSystem, push_id = PushID, cpsid = Cpsid};
                _ ->
                    throw("no_server_name")
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      获得签名状态
%% @end
%% ----------------------------------------------------
-spec get_sign_state(login()) -> boolean().
get_sign_state(#login{sign_state = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      获得平台ID
%% @end
%% ----------------------------------------------------
-spec get_platform(login()) -> integer().
get_platform(#login{platform = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      获得服ID
%% @end
%% ----------------------------------------------------
-spec get_server(login()) -> integer().
get_server(#login{server = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      获得平台用户ID
%% @end
%% ----------------------------------------------------
-spec get_pid(login()) -> string().
get_pid(#login{pid = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      设置平台用户ID
%% @end
%% ----------------------------------------------------
-spec set_pid(Login, Pid) -> login() when
    Login :: login(),
    Pid :: string().
set_pid(Login, Pid) -> Login#login{'pid' = Pid}.

%% ----------------------------------------------------
%% @doc
%%      获得邀请人
%% @end
%% ----------------------------------------------------
-spec get_invite_user(login()) -> string().
get_invite_user(#login{invite_user = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      获得BI用ID(接入中心传入)
%% @end
%% ----------------------------------------------------
-spec get_platform_id(login()) -> integer().
get_platform_id(#login{platform_id = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      获得youkiaid
%% @end
%% ----------------------------------------------------
-spec get_youkiaid(login()) -> integer().
get_youkiaid(#login{youkiaid = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      获得手机设备号
%% @end
%% ----------------------------------------------------
-spec get_device_id(login()) -> integer().
get_device_id(#login{device_id = V}) ->
    V.

%% ----------------------------------------------------
%% @doc
%%      获得手机名称，由SDK传入
%% @end
%% ----------------------------------------------------
-spec get_phonename(login()) -> string().
get_phonename(#login{phonename = V}) ->
    V.
%% ----------------------------------------------------
%% @doc
%%  获得手机内存，由SDK传入
%% @end
%% ----------------------------------------------------
-spec get_memtotal(login()) -> string().
get_memtotal(#login{memtotal = V}) ->
    V.
%% ----------------------------------------------------
%% @doc
%%      获得操作系统版本，由SDK传入
%% @end
%% ----------------------------------------------------
-spec get_osversion(login()) -> string().
get_osversion(#login{osversion = V}) ->
    V.
%% ----------------------------------------------------
%% @doc
%%      获得运营商，由SDK传入
%% @end
%% ----------------------------------------------------
-spec get_carriertype(login()) -> string().
get_carriertype(#login{carriertype = V}) ->
    V.
%% ----------------------------------------------------
%% @doc
%%      获得网络类型，由SDK传入
%% @end
%% ----------------------------------------------------
-spec get_networktype(login()) -> string().
get_networktype(#login{networktype = V}) ->
    V.

%% ----------------------------------------------------
%% @doc
%%      获得玩家手机类型android还是ios，由SDK传入
%% @end
%% ----------------------------------------------------
-spec get_o_system(login()) -> integer().
get_o_system(#login{o_system = V}) ->
    V.

%% ----------------------------------------------------
%% @doc
%%    push_id
%% @end
%% ----------------------------------------------------
get_push_id(#login{push_id = PushId}) -> PushId.

%% ----------------------------------------------------
%% @doc
%%    cpsid
%% @end
%% ----------------------------------------------------
get_cpsid(#login{cpsid = V}) -> V.
%%%===================LOCAL FUNCTIONS==================