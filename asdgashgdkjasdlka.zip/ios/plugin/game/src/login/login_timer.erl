-module(login_timer).
-description("在线等级整理定时器").
-copyright('youkia,www.youkia.net').
-author('cb,chenbin@youkia.net').
-vsn(1).

%%%=======================EXPORT=======================
-export([computer_grade/3, clear_dead_online/3]).
%%%=======================INCLUDE======================
-include("../include/role.hrl").
-include("../../../include/sign_key.hrl").

%%%=======================RECORD=======================

%%%=======================DEFINE=======================
%%等级分布段
-define(GRADE, 5).

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      清除死亡在线
%% @end
%% ----------------------------------------------------
clear_dead_online(Src, _Args, _Time) ->
    Bool = zm_load:server_start_ok() =:= ?KEY,
    if
        Bool ->
            B = z_db_lib:update(game_lib:get_table(Src, 'common'), 'clear_dead_online', 0, fun(_, Count) ->
                case Count > 0 of
                    true ->
                        {ok, true, Count - 1};
                    false ->
                        {ok, false}
                end
            end, []),
            if
                B ->
                    Fun1 = fun(_, RoleUid, _, R) ->
                        Session = login_db:get_online(Src, RoleUid),
                        if
                            Session =:= none ->
                                ok;
                            true ->
                                Pid = zm_tcp_con:get_pid(Session),
                                case is_pid(Pid) andalso erlang:process_info(Pid, priority) =/= 'undefined' of
                                    false ->
                                        login_event:delete(Src, RoleUid, Session, [], []);
                                    true ->
                                        ok
                                end
                        end,
                        {ok, R}
                    end,
                    z_db_lib:table_iterate(Src, game_lib:get_table(Src, 'online'), Fun1, [], []),
                    Fun2 = fun(_, RUid, _, R) ->
                        Session = monitor_db:get_monitor(Src, RUid),
                        if
                            Session =:= none ->
                                ok;
                            true ->
                                Pid = zm_tcp_con:get_pid(Session),
                                case is_pid(Pid) andalso erlang:process_info(Pid, priority) =/= 'undefined' of
                                    false ->
                                        monitor_db:delete_monitor(Src, RUid);
                                    true ->
                                        ok
                                end
                        end,
                        {ok, R}
                    end,
                    z_db_lib:table_iterate(Src, game_lib:get_table(Src, 'monitor'), Fun2, [], []);
                true ->
                    ok
            end;
        true ->
            ok
    end.
%% ----------------------------------------------------
%% @doc
%%      进行等级计算
%% @end
%% ----------------------------------------------------
computer_grade(Src, _Args, _Time) ->
    Bool = zm_load:server_start_ok() =:= ?KEY,
    if
        Bool ->
            %%事先组织好1到玩家最高等级的数据段，在完成后将以前的数据进行覆盖（防高等级下线，但没有高等级段，而不会被覆盖）
            L = lists:usort([{X div ?GRADE, []} || X <- lists:seq(1, game_lib:get_max_level('role', 'role_exps'))]),
            RShowTable = game_lib:get_table(Src, 'role_show'),
            case zm_db_client:iterate(game_lib:get_table(Src, 'online'), descending, false) of
                {ok, Iterator} ->
                    List = grade_listener_(Iterator, RShowTable, L),
                    write(Src, List);
                E ->
                    E
            end;
        true ->
            ok
    end.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%      写在线等级数据
%% @end
%% ----------------------------------------------------
-spec write(Src, [{Index, List} | T]) -> 'ok' when
    Src :: atom(),
    Index :: integer(),
    List :: list(),
    T :: list().
write(Src, [{Index, List} | T]) ->
    z_db_lib:update(game_lib:get_table(Src, 'online_level_stage'), Index, List),
    write(Src, T);
write(_Src, []) ->
    ok.

%% ----------------------------------------------------
%% @doc
%%      在线等级分析
%% @end
%% ----------------------------------------------------
-spec grade_listener_(Iterator, Table, List) -> string()|list() when
    Iterator :: tuple(),
    Table :: atom(),
    List :: list().
grade_listener_(Iterator, Table, List) ->
    case zm_db_client:iterate_next(Iterator) of
        {ok, {RoleUid, _, _}, NewIterator} ->
            Level = role_show:get_level(z_db_lib:get(Table, RoleUid)),
            Index = Level div ?GRADE,
            case lists:keyfind(Index, 1, List) of
                false ->
                    grade_listener_(NewIterator, Table, [{Index, [{RoleUid, Level}]} | List]);
                {_, L} ->
                    grade_listener_(NewIterator, Table, lists:keyreplace(Index, 1, List, {Index, [{RoleUid, Level} | L]}))
            end;
        over ->
            List;
        E ->
            E
    end.

