%%登陆工具
-module(login_lib).

%%%=======================STATEMENT====================
-description("login_lib").
-copyright("seasky,www.seasky.cn").
-author("cb, chenbin@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([analyse_login_url_args/1]).
%%%=======================INCLUDE======================

%%%=======================RECORD=======================

%%%=======================DEFINE=======================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      对url数据进行参数分析
%% @end
%% ----------------------------------------------------
-spec analyse_login_url_args(Url) -> list() when Url :: string().
analyse_login_url_args("") ->
    throw("no_server_name");
analyse_login_url_args(Url) ->
    analyse_login_url_args(zm_http:parse_qs(lists:nth(2, (string:tokens(Url, "?"))), []), []).
analyse_login_url_args([{"userid", V} | T], R) ->
    analyse_login_url_args(T, [{'pid', V} | R]);
analyse_login_url_args([{"nickname", V} | T], R) ->
    analyse_login_url_args(T, [{'nickname', V} | R]);
analyse_login_url_args([{"time", V} | T], R) ->
    analyse_login_url_args(T, [{'time', V} | R]);
analyse_login_url_args([{"sig", V} | T], R) ->
    analyse_login_url_args(T, [{'sig', V} | R]);
analyse_login_url_args([{"bi_platform_id", V} | T], R) ->%平台id(不是记录bi使用)
    analyse_login_url_args(T, [{'platform_id', list_to_integer(V)} | R]);
analyse_login_url_args([{"server_name", V} | T], R) ->
    analyse_login_url_args(T, [{'server_name', V} | R]);
analyse_login_url_args([{"youkiaid", V} | T], R) ->
    analyse_login_url_args(T, [{'youkiaid', V} | R]);
analyse_login_url_args([{"phoneName", V} | T], R) ->
    analyse_login_url_args(T, [{'phone_name', V} | R]);
analyse_login_url_args([{"memoryTotal", V} | T], R) ->
    analyse_login_url_args(T, [{'memory_total', V} | R]);
analyse_login_url_args([{"OS", Os} | T], R) -> %android还是ios :0=未知, 1=android,2=ios
    V = case string:to_lower(Os) of
        "android" ->
            1;
        "ios" ->
            2;
        _ ->
            0
    end,
    analyse_login_url_args(T, [{'o_system', V} | R]);
analyse_login_url_args([{"osVersion", V} | T], R) ->
    analyse_login_url_args(T, [{'os_version', V} | R]);
analyse_login_url_args([{"carrierType", V} | T], R) ->
    analyse_login_url_args(T, [{'carrier_type', V} | R]);
analyse_login_url_args([{"networkType", V} | T], R) ->
    analyse_login_url_args(T, [{'network_type', V} | R]);
analyse_login_url_args([{"push_id", V} | T], R) ->
    analyse_login_url_args(T, [{'push_id', V} | R]);
analyse_login_url_args([{"cpsid", V} | T], R) ->
    Cpsid = try
        erlang:list_to_integer(string:strip(V))
    catch
        _:_ ->
            0
    end,
    analyse_login_url_args(T, [{'cpsid', Cpsid} | R]);

analyse_login_url_args([H | T], R) ->
    analyse_login_url_args(T, [H | R]);
analyse_login_url_args([], R) ->
    R.

%%%===================LOCAL FUNCTIONS==================