-module(login_port).
-description("login_port").
-copyright({seasky, 'www.seasky.cn'}).
-author({hzh, 'huangzhenghan@youkia.net'}).
-vsn(1).

%%%=======================EXPORT=======================
-export([get_time/5, login/5, trust/5]).

%%%=======================DEFINE======================

%%%=======================INCLUDE======================

%%%=======================TYPE=========================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      得到服务器当前时间和开服时间
%% @end
%% ----------------------------------------------------
get_time(_, _, _, Info, _) ->
    try
        %% 处理server级校验
        login_db:handle_server(),
        Src = z_lib:get_value(Info, src, none),
        {ok, [], Info, [{msg, {time_lib:now_second(), args_system:get_online_time(Src)}}]}
    catch
        throw:Reason when is_list(Reason) ->
            log_lib:log_login(?MODULE, "get_time_error", [{'info', Info}, {'reason', Reason}]),
            {ok, [], Info, [{'msg', Reason}]};
        _:Reason ->
            throw({Reason, erlang:get_stacktrace()})
    end.

%% ----------------------------------------------------
%% @doc
%%      托管登录
%% @end
%% ----------------------------------------------------
trust(_, Session, _Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, ""),
    UserUid = list_to_integer(z_lib:get_value(Msg, "userid", "0")),
    try
        case user_db:get_user(Src, UserUid) of
            none ->
                throw("no_user_trust");
            Guser ->
                case guser:is_status(Guser, trust) of%%托管
                    false ->
                        throw("no_trust");
                    _ ->
                        case role_db:get_role(Src, UserUid) of
                            none ->
                                throw("no_role_trust");%没有角色,跳转角色创建
                            _ ->
                                UserAccount = z_db_lib:get(game_lib:get_table(Src, 'uid_psu'), UserUid, none),
                                Login = login:init(Src, lists:keyreplace("userid", 1, Msg, {"userid", element(3, UserAccount)}), true),
                                %io:format("Format======trust =====user_name=~p,role_uid=~p~n", [login:get_pid(Login), UserUid]),
                                log_lib:log_login(?MODULE, "trust", [{useruid, UserUid}, {ip, z_lib:get_value(Info, ip, 'none')}, {'login', Login}]),
                                MapId = case cross_battle_area_db:check_login_cross_battle_server(Src, UserUid) of
                                    {true, MapId1} ->
                                        MapId1;
                                    _ ->
                                        0
                                end,
                                {NAttr, NMsg} = login_db:handle_login(Src, UserUid, Session, Login, Msg, Info, MapId),
                                %%0非断线重连|1断线重连,非断线重连登录需要清理玩家通讯缓存数据
                                case z_lib:get_value(Msg, "login_type", 0) of
                                    0 ->
                                        reconnect_lib:delete(Src, UserUid);
                                    _ ->
                                        ok
                                end,
                                log_lib:log_login(?MODULE, "trust_login", [{user_uid, UserUid}, {msg, Msg}, {info, Info}, {'nmsg', NMsg}]),
                                {ok, [{'map_id', MapId} | NAttr], Info, [{msg, NMsg}]}
                        end
                end
        end
    catch
        throw:Reason when is_list(Reason) ->
            log_lib:log_login(?MODULE, "trust_error", [{msg, Msg}, {info, Info}, {reason, Reason}]),
            {ok, [], Info, [{msg, Reason}]};
        _:Reason ->
            throw({Reason, erlang:get_stacktrace()})
    end.

%% ----------------------------------------------------
%% @doc
%%      登陆
%% @end
%% ----------------------------------------------------
login(_, Session, _Attr, Info, Msg) ->
    %io:format("s,a,i,m=~p~n", [{Session, Attr, Info, Msg}]),
    Src = z_lib:get_value(Info, src, ""),
    try
        %% 处理server级校验
        login_db:handle_server(),
        %%初始登录数据
        Login = login_db:handle_args(Src, Msg),
        log_lib:log_login(?MODULE, "handle_args", [{'login', Login}]),
        IP = z_lib:get_value(Info, ip, none),
        UserUid = login_db:handle_user(Src, IP, Login, Msg),
%%        io:format("Format======login ====user_name=~p,role_uid=~p~n", [login:get_pid(Login), UserUid]),
        log_lib:log_login(?MODULE, "handle_user", [{'user_uid', UserUid}, {'msg', Msg}, {'info', Info}]),
        RoleUid = UserUid,
        case cross_battle_area_db:check_login_cross_battle_server(Src, RoleUid) of
            {true, MapId} ->
                {NAttr, NMsg} = login_db:handle_login(Src, RoleUid, Session, Login, Msg, Info, MapId),
                log_lib:log_login(?MODULE, "handle_login", [{'user_uid', UserUid}, {'msg', NMsg}]),
                %%0非断线重连|1断线重连,非断线重连登录需要清理玩家通讯缓存数据
                case z_lib:get_value(Msg, "login_type", 0) of
                    0 ->
                        case lists:keyfind('role_uid', 1, NAttr) of
                            {_, RoleUid2} ->
                                reconnect_lib:delete(Src, RoleUid2);
                            _ ->
                                ok
                        end;
                    _ ->
                        ok
                end,
                %io:format("Attr,NMsg=~p~n", [{NAttr, NMsg}]),
                NMsg1 = erlang:append_element(NMsg, role_db:is_can_change_country2(Src, RoleUid, NAttr)),
                {ok, [{'map_id', MapId} | NAttr], Info, [{'msg', NMsg1}]};
            false ->
                {ok, [], Info, [{'msg', "no_login_cross_server"}]}
        end
    catch
        throw:Reason when is_list(Reason) ->
            log_lib:log_login(?MODULE, "login_error", [{'msg', Msg}, {'info', Info}, {'reason', Reason}]),
            {ok, [], Info, [{'msg', Reason}]};
        _:Reason ->
            throw({Reason, erlang:get_stacktrace()})
    end.
