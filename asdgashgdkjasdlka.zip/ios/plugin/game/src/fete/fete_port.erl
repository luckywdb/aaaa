-module(fete_port).

%%%=======================STATEMENT====================
-description("祭坛祭祀端口").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([execute/5, get_info/5]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      执行抽奖
%% @end
%% ----------------------------------------------------
execute([{M, F, A}], _, Attr, Info, Msg) ->
    RoleUid = role_lib:get_uid(Attr),    % 抽取奖励玩家
    Src = z_lib:get_value(Info, src, none),
    Id = z_lib:get_value(Msg, "id", 0),    % 抽取奖励类型
    case zm_config:get('fete_info', Id) of
        none ->
            {ok, [], Info, [{msg, "input_error"}]};
        {_, FeteInfo} ->
            {M1, F1, A1} = z_lib:get_value(FeteInfo, 'award', 'none'),
            case M1:F1(A1, Src, RoleUid) of
                [] ->
                    {'ok', [], Info, [{'msg', "function_not_open"}]};
                AwardList ->
                    TableName = game_lib:get_table(Src),
                    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'fete_count', {RoleUid, Id}, fete:init()},
                        {'rmb', RoleUid, rmb_lib:init()}]),
                    Role = role_db:get_role(Src, RoleUid),
                    case z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, Role, Id, FeteInfo}, TableKeys) of
                        {'ok', IsFree, Multiple, RmbCs} ->%IsFree=1消耗免费次数
                            AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, AwardList, Multiple),
                            %% 抽奖日志
                            zm_log:info(Src, ?MODULE, 'execute', "fete_execute", [{'roleuid', RoleUid}, {'is_free', IsFree},
                                {'fete_draw', Id}, {'consume', RmbCs}, {'award', AwardLog}]),
                            %% 祭祀事件触发
                            zm_event:notify(Src, 'fete_execute', [{'role_uid', RoleUid}, {'id', Id}, {'is_free', IsFree},
                                {'consume', RmbCs}, {'award', AwardLog}]),
                            zm_event:notify(Src, achieve, {RoleUid, {argu, {'fete_execute_times', 1}}}),
                            {'ok', [], Info, [{'msg', {Multiple, AwardLog}}]};
                        Err ->
                            {'ok', [], Info, [{'msg', Err}]}
                    end
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      获取祭祀信息
%% @end
%% ----------------------------------------------------
get_info(_, _, Attr, Info, _) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    Reply = [fete_lib:front_format(Id, fete:refresh_count(fete_db:get_fete_count(Src, {RoleUid, Id}))) ||
        {Id, _FeteInfo} <- zm_config:get('fete_info'), is_integer(Id)],
    {'ok', [], Info, [{'msg', list_to_tuple(Reply)}]}.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
