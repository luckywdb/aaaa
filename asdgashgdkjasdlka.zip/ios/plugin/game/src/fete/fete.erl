-module(fete).

%%%=======================STATEMENT====================
-description("fete").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_day/1, get_free_count/1, get_total_count/1, get_day_times/1]).
-export([set_day/2, set_free_count/2, set_total_count/2, set_day_times/2]).
-export([refresh_count/1, init/0]).

-export_type([fete/0]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(fete, {
    'day' :: integer(),%每日刷新标记
    'free_count' = 0 :: integer(),%每日使用的免费次数
    'total_count' = 0 :: integer(),%抽奖累计次数
    'day_times' = 0 :: integer()%今日抽奖次数
}).

%%%=======================TYPE=========================
-type fete() :: #fete{}.


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      获取重置记录日期
%% @end
%% ----------------------------------------------------
-spec get_day(fete()) -> integer().
get_day(#fete{'day' = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%      设置重置记录日期
%% @end
%% ----------------------------------------------------
-spec set_day(Fete, Value) -> fete() when
    Fete :: fete(),
    Value :: integer().
set_day(Fete, Value) ->
    Fete#fete{'day' = Value}.

%% ----------------------------------------------------
%% @doc
%%       获取每日已使用的免费次数
%% @end
%% ----------------------------------------------------
-spec get_free_count(fete()) -> integer().
get_free_count(#fete{'free_count' = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%      设置每日已使用的免费次数
%% @end
%% ----------------------------------------------------
-spec set_free_count(Fete, Value) -> fete() when
    Fete :: fete(),
    Value :: integer().
set_free_count(Fete, Value) ->
    Fete#fete{'free_count' = Value}.

%% ----------------------------------------------------
%% @doc
%%      获取此条目抽取的总次数
%% @end
%% ----------------------------------------------------
-spec get_total_count(fete()) -> integer().
get_total_count(#fete{'total_count' = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%      设置此条目抽取的总次数
%% @end
%% ----------------------------------------------------
-spec set_total_count(Fete, Value) -> fete() when
    Fete :: fete(),
    Value :: integer().
set_total_count(Fete, Value) ->
    Fete#fete{'total_count' = Value}.

%% ----------------------------------------------------
%% @doc
%%      获取今日抽奖次数
%% @end
%% ----------------------------------------------------
-spec get_day_times(fete()) -> integer().
get_day_times(#fete{'day_times' = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%      设置今日抽奖次数
%% @end
%% ----------------------------------------------------
-spec set_day_times(Fete, Value) -> fete() when
    Fete :: fete(),
    Value :: integer().
set_day_times(Fete, Value) ->
    Fete#fete{'day_times' = Value}.

%% ----------------------------------------------------
%% @doc
%%      刷新每日使用的免费抽奖次数，每日刷新
%% @end
%% ----------------------------------------------------
-spec refresh_count(Fete) -> fete() when Fete :: fete().
refresh_count(Fete) ->
    NowDay = time_lib:get_date_by_type('day_of_year'),
    case get_day(Fete) of
        NowDay ->
            Fete;
        _ ->
            Fete#fete{'day' = NowDay, 'free_count' = 0, 'day_times' = 0}
    end.

%% ----------------------------------------------------
%% @doc
%%      初始化信息
%% @end
%% ----------------------------------------------------
-spec init() -> fete().
init() ->
    NowDay = time_lib:get_date_by_type('day_of_year'),
    #fete{'day' = NowDay}.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
