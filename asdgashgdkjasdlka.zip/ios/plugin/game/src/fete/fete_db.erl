-module(fete_db).

%%%=======================STATEMENT====================
-description("祭坛祭祀db操作").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_fete_count/2, execute/3]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================
-define(LOG_NUM, 5).%保留最近日志条数
%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      获取抽奖次数信息，key={RoleUid,ActiveId}
%%      Tuple {每日刷新标记,每日使用的免费次数,抽奖累计次数,下次的次数回复时间,各种模式的首次抽取状态}
%% @end
%% ----------------------------------------------------
-spec get_fete_count(Src :: atom(), Key :: {integer(), integer()}) -> fete:fete().
get_fete_count(Src, Key) ->
    z_db_lib:get(game_lib:get_table(Src, 'fete_count'), Key, fete:init()).

%% ----------------------------------------------------
%% @doc
%%      执行抽奖
%% @end
%% ----------------------------------------------------
-spec execute(_, {Src, RoleUid, Role, Id, FeteInfo}, List) -> string()|tuple() when
    Src :: atom(),
    RoleUid :: integer(),
    Role :: role:role(),
    Id :: integer(),
    FeteInfo :: list(),
    List :: list().
execute(_, {_Src, _RoleUid, Role, Id, FeteInfo}, [{Index1, TmpFete}, {Index2, Rmb}]) ->
    %% 刷新每日免费次数
    Fete = fete:refresh_count(TmpFete),
    Free = fete:get_free_count(Fete),
    {MaxFree, AllTimes} = vip_lib:get_fete_times(Role),
    DayTimes = fete:get_day_times(Fete),
    Total = fete:get_total_count(Fete),
    NFete1 = fete:set_total_count(fete:set_day_times(Fete, DayTimes + 1), Total + 1),
    {NFete, IsFree, RmbCs, NRmb} =
        if
            Free >= MaxFree ->
                VipRmbTimes = AllTimes-MaxFree,
                if
                    DayTimes - Free + 1 > VipRmbTimes ->
                        throw("day_max");
                    true ->
                        RmbTuple = z_lib:get_value(FeteInfo, 'rmb', {}),
                        Size = tuple_size(RmbTuple),
                        NeedRmb = element(min(Size, DayTimes - Free + 1), RmbTuple),
                        case rmb_lib:reduct_rmb(Rmb, NeedRmb) of
                            {RmbCs1, NRmb1} ->
                                {NFete1, 0, RmbCs1, NRmb1};
                            Err ->
                                throw(Err)
                        end
                end;
            true ->
                if
                    DayTimes + 1 > AllTimes ->
                        throw("day_max");
                    true ->
                        {fete:set_free_count(NFete1, Free + 1), 1, [], Rmb}
                end
        end,
    Multiple = fete_lib:get_multiple(element(2, zm_config:get('fete_library', Id))),
    {'ok', {'ok', IsFree, Multiple, RmbCs}, [{Index1, NFete}, {Index2, NRmb}]}.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
