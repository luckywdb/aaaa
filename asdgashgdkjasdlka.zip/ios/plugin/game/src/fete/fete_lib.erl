-module(fete_lib).

%%%=======================STATEMENT====================
-description("祭坛祭祀工具类").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_multiple/1, front_format/2, get_award/3]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%     根据权重获取倍数
%% @end
%% ----------------------------------------------------
-spec get_multiple(Multiple) -> integer() when
    Multiple :: integer()|list().
get_multiple([weight | Award]) ->
    award_weight(Award, Award, 0);
get_multiple(Multiple) when is_integer(Multiple) ->
    Multiple;
get_multiple(_) ->%其他模式都为1倍
    1.

%% ----------------------------------------------------
%% @doc
%%      格式化抽奖信息，发送给前端
%% @end
%% ----------------------------------------------------
-spec front_format(Id, Fete) -> tuple() when
    Id :: integer(),
    Fete :: fete:fete().
front_format(Id, Fete) ->
    Free = fete:get_free_count(Fete),
    {Id, fete:get_day_times(Fete), Free, fete:get_total_count(Fete)}.

%% ----------------------------------------------------
%% @doc
%%      根据玩家信息获取奖励基数
%% @end
%% ----------------------------------------------------
-spec get_award([Type], Src, RoleUid) -> [{atom(), integer()}] when
    Type :: atom(),
    Src :: atom(),
    RoleUid :: integer().
get_award([Type], Src, RoleUid) ->
    Number = role_addition:get_fete(Src, RoleUid, Type),
    if
        Number > 0 ->
            [{Type, Number}];
        true ->
            []
    end.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%      计算随机奖励的权重，返回奖励
%% @end
%% ----------------------------------------------------
award_weight(L, [Weight, _Award | T], C) ->
    award_weight(L, T, Weight + C);
award_weight(L, [], C) ->
    random_award(L, z_lib:random(1, C)).

%% ----------------------------------------------------
%% @doc
%%      根据随机权重，返回奖励
%% @end
%% ----------------------------------------------------
random_award([Weight, _Award | T], C) when Weight < C ->
    random_award(T, C - Weight);
random_award([_Weight, Award | _T], _C) ->
    get_multiple(Award).