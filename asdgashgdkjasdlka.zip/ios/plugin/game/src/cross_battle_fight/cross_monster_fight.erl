-module(cross_monster_fight).

%%%=======================STATEMENT====================
-description("土匪战斗").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    fighting/5
]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").
-include("../include/report.hrl").

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      土匪战斗
%% @end
%% ----------------------------------------------------
-spec fighting(Src, Now, PointUid, {_, MUid}, ArrMarch) -> list() when
    Src :: atom(),
    Now :: integer(),
    PointUid :: integer(),
    MUid :: integer(),
    ArrMarch :: [marching:marching()].
fighting(Src, Now, EndPoint, EndPInfo, ArrMarch) ->%需要战斗
    MUid = element(2, EndPInfo),
    MSid = monster_db:muid_2_msid(MUid),
    MonstInfo = monster_detail:get_cfg(MSid),
    MNpcArray = monster_detail:get_npc(MonstInfo),
    FightType = match_lib:get_fight_type(?MODULE),
    FightArgs = [
        {'ma', {'fighting', []}},
        {'auto', 1},%是否自动释放技能自动战斗 1:自动,0:手动
        {'fight_type', FightType},
        {'duplicate_sid', fighting:get_fight_scene('monster')},
        {'sid', MSid},
        {'point_int', EndPoint}],
    case monster_detail:is_boss(MonstInfo) of
        false ->
            FightNpc = fighter:init_npc(MNpcArray),
            {_, UpGoBack} = do_fighting(Src, Now, EndPoint, [{'fight_enemy', FightNpc} | FightArgs], MUid, MonstInfo, ArrMarch, false, []),
            UpGoBack;
        true ->
            BossDataTable = game_lib:get_table(Src, 'boss_data'),
            BossData = z_db_lib:get(BossDataTable, MUid, boss_data:init()),
            NpcArray = monster_detail:get_npc(MonstInfo),
            NpcState = boss_data:get_npc_state(BossData),
            Extra = boss_data:get_extra(BossData),
            {IsDead, UpGoBack, NewNpcState, NewAddRank} = boss_fight:do_fighting(Src, Now, EndPoint, FightArgs, MUid, MonstInfo, ArrMarch, false, [], NpcArray, NpcState, [], Extra, {0, [], [], [], 0}),
            NCurrValue = boss_fight:get_curr_value(MNpcArray, NewNpcState, Extra),
            UFun = fun(_, NBData) ->
                NBossData = boss_data:set_curr_value(boss_data:set_npc_state(NBData, NewNpcState), NCurrValue),
                {ok, {ok, NBossData}, NBossData}
            end,
            {ok, NBossData} = z_db_lib:update(BossDataTable, MUid, BossData, UFun, []),
            case NCurrValue =/= 0 andalso NCurrValue =/= boss_data:get_curr_value(BossData) of
                true ->
                    point_search_db:update_boss(Src, EndPoint, MUid, NBossData);
                false ->
                    ok
            end,
            case Extra of
                {'active', ActiveSid} ->
                    zm_event:notify(Src, 'active_event', {'active_corps_boss_score', [{'score', monster_detail:get_score(MonstInfo)}, {'add_rank', NewAddRank},
                        {'active_sid', ActiveSid}, {'monster_uid', MUid}, {'dead', IsDead}, {'monster_deail', MonstInfo}, {'monster_uid', MUid}]});
                _ ->
                    ok
            end,
            UpGoBack
    end.

%% ----------------------------------------------------
%% @doc
%%      土匪进行战斗 UpPmarch=[{{role_uid,gid},{奖励},{随机奖励},死亡数量,伤兵数量}]
%% @end
%% ----------------------------------------------------
do_fighting(_, _, _, _, _, _, [], IsDead, UpGoBacks) ->
    {IsDead, UpGoBacks};
do_fighting(Src, Now, EndPoint, FightArgs, MonsterUid, MonstInfo, [Marching | T], IsDead, UpGoBack) ->
    {RoleUid, GId} = RoleAndGId = marching:get_roleuid_gid(Marching),
    ETime = marching:get_etime(Marching),
    MonsterSid = monster_detail:get_sid(MonstInfo),
    if
        IsDead -> %土匪已经死亡
            zm_event:notify(Src, 'fight_null_report', [
                {'role_uid', RoleUid},
                {'point_int', EndPoint},
                {'time', ETime},
                {'r_type', ?REPORT_NULL_MONSTER_DEAD},
                {'id', MonsterSid}]),%已到达时间+1秒为下一个状态开始时间
            do_fighting(Src, Now, EndPoint, FightArgs, MonsterUid, MonstInfo, T, IsDead, UpGoBack);
        true ->
            Garray = garray_db:get_garray(Src, RoleUid, GId),
            FighterRole = fighter:init_role(Src, RoleUid, GId, 0, Garray),%出发前已经检测过阵型
            NFightArgs = [
                {'seed', game_lib:get_seed()},
                {'fight_role', FighterRole},
                {'role_uid', RoleUid} | FightArgs],
            case match:auto_result(Src, RoleUid, NFightArgs) of
                {Winner, Result} ->%返回 result/6的结果,表示web一切正常
                    {NIsDead1, NUpGoBack1} =
                        try
                            Dead = result:get_dead(Result),
                            Injured = result:get_injured(Result),
                            WebRoleResult = result:get_queue(Result),
                            AllCardExp = result:get_allexp(Result),
                            WaveInfo = result:get_waves(Result),
                            {_, MarchiQueue, GarrayInjured, _AutoAddSoldier, _DeductSosldierNum} =
                                fighting:update_garray_after_fight(Src, WebRoleResult, RoleAndGId),
                            OneCardExp = garray_db:award_card_allexp(Src, RoleUid, GId, AllCardExp, z_lib:get_value(FightArgs, 'duplicate_sid', 0)),%武将加经验
                            set_front_lib:send_map_result(Src, RoleUid, {ETime, EndPoint, ?MONSTER, ?MONSTER, Winner, GId, {MarchiQueue, Dead, Injured, GarrayInjured}, OneCardExp, MonsterSid}),
                            {Faward, AwardView, NIsDead, NUpGoBack, NMonsterScore} =
                                if
                                    Winner =:= 0 ->%玩家胜利,土匪死亡
                                        AwardSid = monster_detail:get_award(MonstInfo),
                                        ActiveMonsterDrops = active_monster_drop:get_active_monster_drops(Src, MonsterSid),
                                        Multi = active_addition:get_monster_drop_multi(Src),
                                        AwardList = awarder_game:award_percent(ActiveMonsterDrops, Multi) ++ awarder_game:award_percent(AwardSid, Multi),
                                        MonsterLv = monster_detail:get_level(MonstInfo),
                                        MonsetType = monster_detail:get_type(MonstInfo),
                                        TFun = fun(_, TimeSet1) ->
                                            KillLvList = z_lib:get_value(TimeSet1, 'monster', []),
                                            KLv = z_lib:get_value(KillLvList, MonsetType, 0),
                                            if
                                                MonsterLv > KLv ->
                                                    NMKList = lists:keystore(MonsetType, 1, KillLvList, {MonsetType, MonsterLv}),
                                                    {'ok', awarder_game:get_award_list(monster_detail:get_first_award(MonstInfo)), lists:keystore('monster', 1, TimeSet1, {'monster', NMKList})};
                                                true ->
                                                    {'ok', []}
                                            end
                                        end,
                                        FirstAward = z_db_lib:update(game_lib:get_table(Src, 'times_set'), RoleUid, times_set_lib:roleuid_key_init(), TFun, []),
                                        NAwardList = FirstAward ++ AwardList,
                                        {NAView, Award} = awarder_game:get_advance_award(Src, RoleUid, ?MODULE, NAwardList),
                                        monster_db:monster_dead(Src, MonsterUid, EndPoint, MonstInfo),%土匪死亡
                                        %%增加军团积分
                                        CorpsUid = role_show:get_corps_uid(role_db:get_role_show(Src, RoleUid)),
                                        MonsterScore = monster_detail:get_score(MonstInfo),
                                        zm_event:notify(Src, 'cross_battle_corps_point', [{CorpsUid, MonsterScore}]),
                                        {FirstAward, NAView--FirstAward, true, [{RoleAndGId, Award, Dead, Injured} | UpGoBack], MonsterScore};
                                    true ->
                                        {AView, Award} = {[], []},
                                        {[], AView, IsDead, [{RoleAndGId, Award, Dead, Injured} | UpGoBack], 0}
                                end,
                            zm_event:notify(Src, 'fight_monster_report', [
                                {'winner', Winner},
                                {'time', ETime},
                                {'award_list', {Faward, [{'card_exp', OneCardExp}, {'sociaty_num', NMonsterScore} | AwardView]}},
                                {'wave_infos', WaveInfo},
                                {'report_type', ?REPORT_FIGHT_MONSTER} | NFightArgs]),
                            {NIsDead, NUpGoBack}
                        catch
                            E1:E2 ->
                                zm_log:warn(?MODULE, ?MODULE, 'fighting', "handle_error", [{'e1', E1}, {'e2', E2}, {'point_uid', EndPoint},
                                    {'marching', Marching}, {'stacktrace', erlang:get_stacktrace()}]),
                                {IsDead, UpGoBack}
                        end,
                    do_fighting(Src, Now, EndPoint, FightArgs, MonsterUid, MonstInfo, T, NIsDead1, NUpGoBack1);
                WebErr ->
                    zm_log:warn(?MODULE, ?MODULE, 'fighting', "web_error", [{'error', WebErr}, {'point_uid', EndPoint}, {'marching', Marching}]),
                    do_fighting(Src, Now, EndPoint, FightArgs, MonsterUid, MonstInfo, T, IsDead, UpGoBack)
            end
    end.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------