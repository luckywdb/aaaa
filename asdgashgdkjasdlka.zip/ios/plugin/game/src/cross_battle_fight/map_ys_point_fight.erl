-module(map_ys_point_fight).

%%%=======================STATEMENT====================
-description("map_ys_point_fight").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    fighting/6,
    get_npc_by_level/3,
    get_ys_attack/1,
    get_wall_attack/1
]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        
%% @end
%% ----------------------------------------------------
fighting(Src, Now, EndPoint, TSid, ArrMarch, MapYsPoint) ->
    FightType = match_lib:get_fight_type(?MODULE),
    FightArgs = [
        {'ma', {'fighting', []}},
        {'auto', 1},%是否自动释放技能自动战斗 1:自动,0:手动
        {'fight_type', FightType},
        {'duplicate_sid', fighting:get_fight_scene('monster')},
        {'point_int', EndPoint},
        {'level', map_ys_point:get_level(MapYsPoint)}],
    do_fighting(Src, Now, EndPoint, TSid, FightArgs, ArrMarch, MapYsPoint, [], {0, []}).


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
do_fighting(_Src, _Now, _EndPoint, _TSid, _FightArgs, [], OMapYsPoint, UpdateGabackAcc, _) ->
    {UpdateGabackAcc, OMapYsPoint};
do_fighting(Src, Now, EndPoint, TSid, FightArgs, [Marching | TailMarchings], MapYsPoint, UpdateGabackAcc, ReportInfo) ->
    ETime = marching:get_etime(Marching),
    DefenseWaveNum = map_ys_point:get_defense_wave_number(MapYsPoint),
    {MRoleUid, MGId} = MRGId = marching:get_roleuid_gid(Marching),
    FightRole = fighter:init_role(Src, MRoleUid, MGId, 0, garray_db:get_garray(Src, MRoleUid, MGId)),
    case DefenseWaveNum > 0 of
        true ->%%打npc
            MYPLevel = map_ys_point:get_level(MapYsPoint),
            LastHpState = map_ys_point:get_last_hp_state(MapYsPoint),
            YsDetail = map_ys_point_detail:get_cfg(MYPLevel),
            NpcGarray = map_ys_point_detail:get_defense_npc_garray(YsDetail),
            FightNpc = get_fight_npc(MapYsPoint, NpcGarray, LastHpState),
            NFightArgs = [
                {'seed', game_lib:get_seed()},
                {'fight_role', FightRole},
                {'fight_enemy', FightNpc},
                {'role_uid', MRoleUid},
                {'time', ETime} | FightArgs],
            case match:auto_result(Src, MRoleUid, NFightArgs) of
                {Winner, Result} ->
                    {WaveNum, PreFightArgs} = ReportInfo,
                    {NMapYsPoint, NMarchings, NUpdateGabackAcc, NReportInfo} =
                        try
                            Dead = result:get_dead(Result),
                            Injured = result:get_injured(Result),
                            WebRoleResult = result:get_queue(Result),
                            AllCardExp = result:get_allexp(Result),
                            WaveInfo = result:get_waves(Result),
                            {_, MarchiQueue, GarrayInjured, _AutoAddSoldier, _DeductSosldierNum} =
                                fighting:update_garray_after_fight(Src, WebRoleResult, MRGId),
                            OneCardExp = garray_db:award_card_allexp(Src, MRoleUid, MGId, AllCardExp, z_lib:get_value(FightArgs, 'duplicate_sid', 0)),%武将加经验
                            set_front_lib:send_map_result(Src, MRoleUid, {ETime, EndPoint, ?ROLE, ?MAP_YS_POINT, Winner, MGId, {MarchiQueue, Dead, Injured, GarrayInjured}, OneCardExp, MYPLevel}),
                            if
                                Winner =:= 0 ->
                                    NDefenseWaveNum = DefenseWaveNum - 1,
                                    NMapYsPoint1 = map_ys_point:set_last_hp_state(map_ys_point:set_defense_wave_number(MapYsPoint, NDefenseWaveNum), {}),
                                    NMarching = marching:fight_result(Marching, Injured, Dead, []),
                                    NReportInfo1 =
                                        case NDefenseWaveNum =< 0 of
                                            true ->
                                                zm_event:notify(Src, 'cross_fight_ys', [
                                                    {'winner', Winner},
                                                    {'wave_infos', WaveInfo},
                                                    {'num', WaveNum + 1} | NFightArgs]),
                                                {0, NFightArgs};
                                            false ->
                                                {WaveNum + 1, [{'wave_infos', WaveInfo} | NFightArgs]}
                                        end,
                                    {NMapYsPoint1, [NMarching | TailMarchings], UpdateGabackAcc, NReportInfo1};
                                true ->
                                    NLastHpState = result:get_enemy_last_hps(Result),
                                    NMapYsPoint1 = map_ys_point:set_last_hp_state(MapYsPoint, NLastHpState),
                                    AddGobackMarching = marching:change_goback(marching:fight_result(Marching, Injured, Dead, []), EndPoint),
                                    case WaveNum > 0 of
                                        true ->
                                            zm_event:notify(Src, 'cross_fight_ys', [
                                                {'winner', 0},
                                                {'num', WaveNum} | PreFightArgs]);
                                        false ->
                                            zm_event:notify(Src, 'cross_fight_ys', [
                                                {'winner', Winner},
                                                {'wave_infos', WaveInfo},
                                                {'num', WaveNum} | NFightArgs])
                                    end,
                                    {NMapYsPoint1, TailMarchings, [AddGobackMarching | UpdateGabackAcc], {0, NFightArgs}}
                            end
                        catch
                            E1:E2 ->
                                zm_log:warn(?MODULE, ?MODULE, 'fighting', "handle_error", [{'e1', E1}, {'e2', E2}, {'point_uid', EndPoint},
                                    {'marching', Marching}, {'stacktrace', erlang:get_stacktrace()}]),
                                case WaveNum > 0 of
                                    true ->
                                        zm_event:notify(Src, 'cross_fight_ys', [
                                            {'winner', 0},
                                            {'num', WaveNum} | PreFightArgs]);
                                    false ->
                                        ok
                                end,
                                {MapYsPoint, TailMarchings, UpdateGabackAcc, {0, NFightArgs}}
                        end,
                    do_fighting(Src, Now, EndPoint, TSid, FightArgs, NMarchings, NMapYsPoint, NUpdateGabackAcc, NReportInfo);
                WebErr ->
                    {WaveNum, PreFightArgs} = ReportInfo,
                    case WaveNum > 0 of
                        true ->
                            zm_event:notify(Src, 'cross_fight_ys', [
                                {'winner', 0},
                                {'num', WaveNum} | PreFightArgs]);
                        false ->
                            ok
                    end,
                    zm_log:warn(?MODULE, ?MODULE, 'fighting', "web_error", [{'error', WebErr}, {'point_uid', EndPoint}, {'marching', Marching}]),
                    do_fighting(Src, Now, EndPoint, TSid, FightArgs, TailMarchings, MapYsPoint, UpdateGabackAcc, {0, NFightArgs})
            end;
        false ->%%打建筑值
            Attack = get_ys_attack(FightRole),
            {IsOver, NMapYsPoint} = map_ys_point_lib:deduct_bvalue(MapYsPoint, Attack, ETime),
            zm_event:notify(Src, 'cross_fight_ys_wall', [
                {'winner', 0},
                {'hp', Attack},
                {'fight_role', FightRole},
                {'role_uid', MRoleUid},
                {'time', ETime} | FightArgs]),
            zm_event:notify(Src, 'cross_battle_town_point', [{MRoleUid, Attack}]),
            case IsOver of
                true ->
                    fighting:mrole_endpoint_change(Src, EndPoint, TailMarchings),
                    {UpdateGabackAcc, NMapYsPoint};
                false ->
                    do_fighting(Src, Now, EndPoint, TSid, FightArgs, TailMarchings, NMapYsPoint, UpdateGabackAcc, ReportInfo)
            end
    end.


%% ----------------------------------------------------
%% @doc
%%      获取伤害
%% @end
%% ----------------------------------------------------
get_ys_attack(FightRole) ->
    Attack = z_lib:foreach(fun(A, Fighter) ->
        {'ok', A + fighter:get_attack(Fighter)} end, 0, fighter:get_fighters(FightRole)),
    {OAttack, Speed} = case fighter:get_ordnance(FightRole) of
        {} -> {0, 10000};
        Ordnance ->
            {_, _, _, S} = zm_config:get('study_attrs', {fighter:get_o_sid(Ordnance), fighter:get_o_level(Ordnance)}),
            {fighter:get_o_attack(Ordnance), S}
    end,
    %speed是扩大了10000倍
    (Attack + (OAttack * 10000 div Speed)) div 10000.


%% ----------------------------------------------------
%% @doc
%%      获取npc
%% @end
%% ----------------------------------------------------
get_fight_npc(_MapYsPoint, NpcGarray, {}) ->
    fighter:init_npc(NpcGarray);
get_fight_npc(MapYsPoint, NpcGarray, {Len, LastHp}) ->
    Level = map_ys_point:get_level(MapYsPoint),
    boss_fight:init_fight_npc(NpcGarray, 0, Level, {Len, LastHp}, []).

%% ----------------------------------------------------
%% @doc
%%    根据等级获取npc
%% @end
%% ----------------------------------------------------
get_npc_by_level(MYPLevel, NpcHp, Camp) ->
    YsDetail = map_ys_point_detail:get_cfg(MYPLevel),
    NpcGarray = map_ys_point_detail:get_attack_npc_garray(YsDetail),
    z_lib:foreach(fun(Args, F) ->
        case fighter:get_fighters(F) =:= [] of
            true ->
                {ok, Args};
            false ->
                {'ok', [fighter:add_npc_uid(fighter:set_camp(F, Camp), 2000000000) | Args]}
        end
    end, [], boss_fight:init_fight_npc(NpcGarray, 0, 0, NpcHp, [])).

%% ----------------------------------------------------
%% @doc
%%     根据npc获取攻城伤害
%% @end
%% ----------------------------------------------------
get_wall_attack(MYPLevel) ->
    lists:sum([get_ys_attack(F) || F <- get_npc_by_level(MYPLevel, {1, []}, 0)]).