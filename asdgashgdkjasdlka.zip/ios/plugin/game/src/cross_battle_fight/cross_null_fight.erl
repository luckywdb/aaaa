-module(cross_null_fight).

%%%=======================STATEMENT====================
-description("cross_null_fight").
-copyright('youkia,www.youkia.net').
-author("ss,shusong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([fighting/5]).
-export([spy_marching_null_report/3]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        
%% @end
%% ----------------------------------------------------
fighting(Src, Now, EndPoint, EndPInfo, Marchings) ->
    fighting(Src, Now, EndPoint, EndPInfo, Marchings, [], 'none').

fighting(Src, Now, EndPoint, EndPInfo, [Marching | TailMarchings], GoBackAcc, SpyMarchings) ->
    MState = marching:get_state(Marching),
    case MState of
        ?ON_THE_INVESTIGATE ->
            if
                SpyMarchings =:= 'none' ->
                    fighting(Src, Now, EndPoint, EndPInfo, TailMarchings, GoBackAcc, Marching);
                true ->
                    spy_marching_null_report_1(Src, Marching, EndPoint),
                    fighting(Src, Now, EndPoint, EndPInfo, TailMarchings, GoBackAcc, SpyMarchings)
            end;
        _ ->
            UpGoBackList = fighting:mrole_endpoint_change(Src, EndPoint, [Marching]),
            fighting(Src, Now, EndPoint, EndPInfo, TailMarchings, UpGoBackList ++ GoBackAcc, SpyMarchings)
    end;
fighting(_Src, _Now, _EndPoint, _EndPInfo, [], GoBackAcc, SpyMarchings) ->
    {GoBackAcc, [], SpyMarchings}.

%% ----------------------------------------------------
%% @doc
%%      侦查行军空战报处理
%% @end
%% ----------------------------------------------------
spy_marching_null_report(Src, Marchings, EndPoint) ->
    lists:foreach(fun(Marching) ->
        case marching:get_state(Marching) =:= ?ON_THE_INVESTIGATE of
            true ->
                spy_marching_null_report_1(Src, Marching, EndPoint);
            false ->
                ok
        end
    end, Marchings).

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%      侦查行军空战报
%% @end
%% ----------------------------------------------------
spy_marching_null_report_1(Src, Marching, EndPoint) ->
    Fun = fun(_, [{Index1, PointMarch}, {Index2, MapSpy}]) ->
        MPoints = lists:delete(EndPoint, map_spy:get_mpoints(MapSpy)),
        NMapSpy = map_spy:set_mpoints(MapSpy, MPoints),
        NPointMarch = point_march:check_del(point_march:set_role_march(PointMarch, lists:delete(EndPoint, point_march:get_role_march(PointMarch)))),
        {ok, {ok, NPointMarch}, [{Index1, NPointMarch}, {Index2, NMapSpy}]}
    end,
    MRoleUid = marching:get_roleuid(Marching),
    MarchRolePoint = marching:get_s_point(Marching),
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'point_march', MarchRolePoint, point_march:init()},
        {'map_spy', MRoleUid, map_spy:spy_init()}
    ]),
    {ok, PointMarch} = z_db_lib:handle(TableName, Fun, [], TableKeys),
    case PointMarch =:= 'delete' of
        true ->
            point_search_db:del_marching(Src, MarchRolePoint);
        false ->
            ok
    end,
    zm_event:notify(Src, 'fight_null_report', [
        {'role_uid', marching:get_roleuid(Marching)},
        {'point_int', EndPoint},
        {'time', marching:get_etime(Marching)},
        {'r_type', ?REPORT_NULL_SPY_NOT_NULL},
        {'id', 0}]),
    ok.
