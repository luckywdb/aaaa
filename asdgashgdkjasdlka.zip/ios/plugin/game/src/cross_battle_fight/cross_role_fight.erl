-module(cross_role_fight).

%%%=======================STATEMENT====================
-description("cross_role_fight").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    fighting/6
]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      玩家战斗
%% @end
%% ----------------------------------------------------
fighting(Src, Now, EndPoint, {_, EndRoleUid}, ArrMarch, Occ) ->%需要战斗
    EndRShow = role_db:get_role_show(Src, EndRoleUid),
    CastleState = role_show:get_state(EndRShow),
    FightType = match_lib:get_fight_type(?MODULE),
    FightArgs = [
        {'ma', {'fighting', []}},
        {'auto', 1},%是否自动释放技能自动战斗 1:自动,0:手动
        {'fight_type', FightType},
        {'point_int', EndPoint}],
    EndCorpsUid = role_show:get_corps_uid(EndRShow),
    do_fighting(Src, CastleState, EndCorpsUid, Now, EndPoint, FightArgs, EndRoleUid, ArrMarch, [], false, {0, 0, 0}, Now, Occ).

%% ----------------------------------------------------
%% @doc
%%      进行战斗 UpPmarch=[{{role_uid,gid},{奖励},{随机奖励},死亡数量,伤兵数量}]
%% @end
%% ----------------------------------------------------
do_fighting(_, _, _, _, _, _, _, [], UpGoBack, RandMove, BName, PlunderTime, Occ) ->
    {UpGoBack, Occ, RandMove, BName, PlunderTime};
do_fighting(Src, {EndRState, EndPTime} = CastleState, EndCorpsUid, Now, EndPoint, FightArgs,
        EndRoleUid, [Marching | T], UpGoBack, RandomMove, BName, PlunderTime, Occ) ->
    MState = marching:get_state(Marching),
    {MarchRoleUid, MarchGId} = MarchRGId = marching:get_roleuid_gid(Marching),
    MEtime = marching:get_etime(Marching),
    case MState =:= ?ON_THE_MB_CC of
        true ->
            case MarchRoleUid =/= EndCorpsUid of  %冲车行军时候,存的就是军团uid
                true ->
                    ToGoback = lists:filter(fun(M) ->
                        marching:get_state(M) =/= ?ON_THE_MB_CC end, T),
                    NUpGoBack2 = fighting:mrole_endpoint_change(Src, EndPoint, ToGoback) ++ UpGoBack,
                    MExtra = marching:get_extra(Marching),
                    SPoint = marching:get_s_point(Marching),
                    CorpsName = marching:get_extra_mb_cc_corpsname(MExtra),
                    {NUpGoBack2, Occ, true, {2, SPoint, CorpsName}, MEtime};
                false ->
                    do_fighting(Src, CastleState, EndCorpsUid, Now, EndPoint, FightArgs,
                        EndRoleUid, T, UpGoBack, RandomMove, BName, PlunderTime, Occ)
            end;
        false ->
            case MState =:= ?ON_THE_CASTLE_MARCHING of
                true ->
                    MarchCorpUid = role_show:get_corps_uid(role_db:get_role_show(Src, MarchRoleUid)),
                    IsAlly = corps_db:is_ally(Src, MarchCorpUid, EndCorpsUid),
                    if
                        (MarchCorpUid > 0 andalso MarchCorpUid =:= EndCorpsUid) orelse IsAlly ->
                            Max = element(2, zm_config:get('garray_info', 'garrison_friend_max_num')),
                            case length(Occ) < Max of
                                true ->
                                    OMarching = marching:change_occ(Marching, MEtime, ?ON_THE_CASTLE_OTHER),
                                    do_fighting(Src, CastleState, EndCorpsUid, Now, EndPoint, FightArgs,
                                        EndRoleUid, T, UpGoBack, RandomMove, BName, PlunderTime, Occ ++ [OMarching]);
                                false ->
                                    zm_event:notify(Src, 'fight_null_report', [
                                        {'role_uid', MarchRoleUid},
                                        {'point_int', EndPoint},
                                        {'time', MEtime},
                                        {'r_type', ?REPORT_NULL_GARRISON_FULL},
                                        {'id', EndRoleUid}]),
                                    do_fighting(Src, CastleState, EndCorpsUid, Now, EndPoint, FightArgs,
                                        EndRoleUid, T, UpGoBack, RandomMove, BName, PlunderTime, Occ)
                            end;
                        true ->
                            zm_event:notify(Src, 'fight_null_report', [
                                {'role_uid', MarchRoleUid},
                                {'point_int', EndPoint},
                                {'time', MEtime},
                                {'r_type', ?REPORT_NULL_GARRISON_DIFF_CORPS},
                                {'id', EndRoleUid}]),
                            do_fighting(Src, CastleState, EndCorpsUid, Now, EndPoint, FightArgs,
                                EndRoleUid, T, UpGoBack, RandomMove, BName, PlunderTime, Occ)
                    end;
                false ->
                    if
                        EndRState =:= ?STATE_PROTECT andalso MEtime =< EndPTime ->%保护状态,空战报
                            zm_event:notify(Src, 'fight_null_report', [
                                {'role_uid', MarchRoleUid},
                                {'point_int', EndPoint},
                                {'time', MEtime},
                                {'r_type', ?REPORT_NULL_CASTLE_PROTECT},
                                {'id', EndRoleUid}]),
                            do_fighting(Src, CastleState, EndCorpsUid, Now, EndPoint, FightArgs,
                                EndRoleUid, T, UpGoBack, RandomMove, BName, PlunderTime, Occ);
                        true ->
                            MarchCorpUid = role_show:get_corps_uid(role_db:get_role_show(Src, MarchRoleUid)),
                            IsAlly = corps_db:is_ally(Src, MarchCorpUid, EndCorpsUid),
                            if
                                MarchCorpUid > 0 andalso MarchCorpUid =:= EndCorpsUid ->%都没有军团是可以攻打的
                                    zm_event:notify(Src, 'fight_null_report', [
                                        {'role_uid', MarchRoleUid},
                                        {'point_int', EndPoint},
                                        {'time', MEtime},
                                        {'r_type', ?REPORT_NULL_SAME_CORPS},
                                        {'id', EndRoleUid}]),
                                    do_fighting(Src, CastleState, EndCorpsUid, Now, EndPoint, FightArgs, EndRoleUid,
                                        T, UpGoBack, RandomMove, BName, PlunderTime, Occ);
                                IsAlly ->
                                    zm_event:notify(Src, 'fight_null_report', [
                                        {'role_uid', MarchRoleUid},
                                        {'point_int', EndPoint},
                                        {'time', MEtime},
                                        {'r_type', ?REPORT_NULL_ALLY_CORPS},
                                        {'id', EndRoleUid}]),
                                    do_fighting(Src, CastleState, EndCorpsUid, Now, EndPoint, FightArgs, EndRoleUid,
                                        T, UpGoBack, RandomMove, BName, PlunderTime, Occ);
                                true ->
                                    case Occ of
                                        [] ->
                                            do_fight_end_role(Src, MarchRoleUid, MarchGId, EndRoleUid, FightArgs, MarchRGId, Now, MEtime, EndPoint,
                                                Marching, UpGoBack, CastleState, EndCorpsUid, T, RandomMove, BName, PlunderTime, Occ);
                                        [OMarching | TailOcc] ->
                                            {ORoleUid, OGId} = marching:get_roleuid_gid(OMarching),
                                            MarchGarray = garray_db:get_garray(Src, MarchRoleUid, MarchGId),
                                            FighterRole = fighter:init_role(Src, MarchRoleUid, MarchGId, 0, MarchGarray),
                                            OGarray = garray_db:get_garray(Src, ORoleUid, OGId),
                                            FightEnemy = fighter:init_role(Src, ORoleUid, OGId, 1, OGarray),
                                            NFightArgs = [
                                                {'duplicate_sid', fighting:get_fight_scene('role_role')},
                                                {'seed', game_lib:get_seed()},
                                                {'fight_role', FighterRole},
                                                {'fight_enemy', [FightEnemy]}%由于npc时候会有多场,故给web发送的是一个list,打玩家时候也需要发送list
                                                | FightArgs],
                                            case match:auto_result(Src, MarchRoleUid, NFightArgs) of
                                                {Winner, Result} ->%攻打玩家不会获得武将经验
                                                    Flourish = restore_lib:get_value(restore_db:restore(Src, EndRoleUid), 'flourish'),%%获得被攻击玩家的繁荣度
                                                    {NMarching, NOMarching, Bool} =
                                                        try
                                                            Dead = result:get_dead(Result),
                                                            Injured = result:get_injured(Result),
                                                            RoleChange = result:get_queue(Result),
                                                            RoleAddFeats = result:get_role_feats(Result),
                                                            EnemyAddFeatsList = result:get_enemy_feats_list(Result),
                                                            WaveInfos = result:get_waves(Result),
                                                            {SoldierBearload, MarchQueue, GarrayInjured, _, _DeductSosldierNum} =
                                                                fighting:update_garray_after_fight(Src, RoleChange, MarchRGId),
                                                            MarchingExtra = marching:set_extra_soldier_bearload(marching:get_extra(Marching), SoldierBearload),
                                                            set_front_lib:send_map_result(Src, MarchRoleUid, {MEtime, EndPoint, ?ROLE, ?ROLE, Winner, MarchGId, {MarchQueue, Dead, Injured, GarrayInjured}, 0}),
                                                            {Feats, OFeats, OMarching1} = update_occ_garray(Src, Winner, OMarching, EndPoint, EndRoleUid, WaveInfos, EnemyAddFeatsList, MEtime),%驻防或者玩家自己阵型兵营等信息处理.
                                                            FeatsList = [{MarchRoleUid, RoleAddFeats}, {EndRoleUid, Feats}, {ORoleUid, OFeats}],
                                                            zm_event:notify(Src, 'fight_role_castle_report', [
                                                                {'time', MEtime},
                                                                {'role_uid', MarchRoleUid},
                                                                {'ruid', EndRoleUid},
                                                                {'garrison_role_uid', ORoleUid},
                                                                {'winner', Winner},
                                                                {'award_list', []},
                                                                {'wave_infos', WaveInfos},
                                                                {'lose_list', []},
                                                                {'personal_num', FeatsList},
                                                                {'del_flourish', 0},
                                                                {'new_flourish', Flourish} | NFightArgs]),
                                                            zm_event:notify(Src, 'bi_fight_attack_role', [{'role_uid', MarchRoleUid}, {'be_role_uid', EndRoleUid}, {'type', ?ROLE}, {'dead', Dead},
                                                                {'injured', Injured}, {'be_dead', result:get_enemy_total_dead(Result)}, {'be_injured', result:get_enemy_total_injure(Result)},
                                                                {'award_list', []}, {'win', Winner}]),
                                                            zm_event:notify(Src, 'cross_battle_role_fight', [{'muid', MarchRoleUid}, {'euid', EndRoleUid}, {'result', Result}]),
                                                            zm_event:notify(Src, 'cross_battle_role_point', FeatsList),
                                                            zm_event:notify(Src, 'cross_battle_kill_enemy', [{MarchRoleUid, result:get_enemy_total_dead(Result)}, {EndRoleUid, Dead}]),
                                                            Marching1 = marching:set_extra(marching:fight_result(Marching, Injured, Dead, []), MarchingExtra),
                                                            {Marching1, OMarching1, true}
                                                        catch
                                                            E1: E2 ->
                                                                zm_log:warn(?MODULE, ?MODULE, 'fighting', "handle_error", [{'e1', E1}, {'e2', E2}, {'point_uid', EndPoint},
                                                                    {'marching', Marching}, {'stacktrace', erlang:get_stacktrace()}]),
                                                                {Marching, OMarching, false}
                                                        end,
                                                    if
                                                        Bool andalso Winner =:= 0 ->
                                                            AddGoback = marching:change_goback(NOMarching, EndPoint, MEtime, ?ON_THE_CASTLE_GOBACK),
                                                            do_fight_end_role(Src, MarchRoleUid, MarchGId, EndRoleUid, FightArgs, MarchRGId, Now, MEtime, EndPoint,
                                                                NMarching, [AddGoback | UpGoBack], CastleState, EndCorpsUid, T, RandomMove, BName, PlunderTime, TailOcc);
                                                        Bool andalso Winner =:= 1 ->
                                                            AddGoBack = marching:change_goback(NMarching, EndPoint),
                                                            case garray_lib:is_no_soldiers(garray_db:get_garray(Src, ORoleUid, OGId)) of
                                                                true ->
                                                                    AddGoBackList = [AddGoBack, marching:change_goback(NOMarching, EndPoint, MEtime, ?ON_THE_CASTLE_GOBACK)],
                                                                    do_fighting(Src, CastleState, EndCorpsUid, Now, EndPoint, FightArgs, EndRoleUid,
                                                                        T, AddGoBackList ++ UpGoBack, RandomMove, BName, PlunderTime, TailOcc);
                                                                false ->
                                                                    do_fighting(Src, CastleState, EndCorpsUid, Now, EndPoint, FightArgs, EndRoleUid,
                                                                        T, [AddGoBack | UpGoBack], RandomMove, BName, PlunderTime, Occ)
                                                            end;
                                                        true ->
                                                            do_fighting(Src, CastleState, EndCorpsUid, Now, EndPoint, FightArgs, EndRoleUid,
                                                                T, UpGoBack, RandomMove, BName, PlunderTime, Occ)
                                                    end;
                                                WebErr ->
                                                    zm_log:warn(?MODULE, ?MODULE, 'fighting', "web_error", [{'error', WebErr}, {'point_uid', EndPoint}, {'marching', Marching}]),
                                                    do_fighting(Src, CastleState, EndCorpsUid, Now, EndPoint, FightArgs, EndRoleUid,
                                                        T, UpGoBack, RandomMove, BName, PlunderTime, Occ)
                                            end
                                    end
                            end
                    end
            end
    end.

do_fight_end_role(Src, MarchRoleUid, MarchGId, EndRoleUid, FightArgs, MarchRGId, Now, MEtime, EndPoint, Marching,
        UpGoBack, CastleState, EndCorpsUid, ArrMarch, RandomMove, BName, PlunderTime, Occ) ->
    MarchGarray = garray_db:get_garray(Src, MarchRoleUid, MarchGId),
    FighterRole = fighter:init_role(Src, MarchRoleUid, MarchGId, 0, MarchGarray),
    {OGid, FightEnemy, SceneSid} = garrison_db:get_dispatch_fightrole(Src, EndRoleUid),
    NFightArgs = [
        {'duplicate_sid', SceneSid},
        {'seed', game_lib:get_seed()},
        {'fight_role', FighterRole},
        {'fight_enemy', FightEnemy}%由于npc时候会有多场,故给web发送的是一个list,打玩家时候也需要发送list
        | FightArgs],
    case match:auto_result(Src, MarchRoleUid, NFightArgs) of
        {Winner, Result} ->%攻打玩家不会获得武将经验
            {NUpGoBack1, NewRMove, NBName, NPlunderTime} =
                try
                    Dead = result:get_dead(Result),
                    Injured = result:get_injured(Result),
                    RoleChange = result:get_queue(Result),
                    RoleAddFeats = result:get_role_feats(Result),
                    EnemyAddFeatsList = result:get_enemy_feats_list(Result),
                    WaveInfos = result:get_waves(Result),
                    {SoldierBearLoad, MarchQueue, GarrayInjured, _, _DeductSosldierNum} =
                        fighting:update_garray_after_fight(Src, RoleChange, MarchRGId),
                    MarchingExtra = marching:set_extra_soldier_bearload(marching:get_extra(Marching), SoldierBearLoad),
                    set_front_lib:send_map_result(Src, MarchRoleUid, {MEtime, EndPoint, ?ROLE, ?ROLE, Winner, MarchGId, {MarchQueue, Dead, Injured, GarrayInjured}, 0}),
                    FeatsTmp = update_owner_garray(Src, Winner, OGid, EndPoint, EndRoleUid, WaveInfos, EnemyAddFeatsList, MEtime),
                    Feats = role_addition:get_feats(Src, EndRoleUid, FeatsTmp),%%被攻击方也需要加成活动的功勋加成,被攻击方已award_feats方法中加成
                    {LoseList, NAwardView, NUpGoBack, BiCs, EnemyAward, DelFlourish, RandMove, BRName, RPlunderTime, NewFlourish1} =
                        if
                            Winner =:= 0 ->%进攻方玩家胜利
                                {LoseList1, MarchAward, EndBiCs, EnemyFlourishInfo, _EnemyAwardList, BuildLoseList, DelFlourish1, NewFlourish} =
                                    building_db:plunder_award(Src, EndRoleUid, SoldierBearLoad, Marching, 0, fighter:get_attack_for_flourish(FighterRole) * 2),%掠夺+扣除繁荣度(跨服扣除繁荣度比游戏服扩大到2倍)
                                set_front_lib:send_plunder(Src, EndRoleUid, LoseList1, EnemyFlourishInfo, {}),
                                AddGoBack = marching:change_goback(marching:set_extra(marching:fight_result(Marching, Injured, Dead, []), MarchingExtra), EndPoint),
                                {MoveFlag, MoveName} =
                                    if
                                        NewFlourish =< 0 ->
                                            {true, {1, marching:get_s_point(Marching), marching:get_roleuid(Marching)}};
                                        true ->
                                            {false, BName}
                                    end,
                                {awarder_game:merger(LoseList1, BuildLoseList), MarchAward, [AddGoBack | UpGoBack], EndBiCs, {}, DelFlourish1, MoveFlag, MoveName, marching:get_etime(Marching), NewFlourish};
                            true ->
                                NewFlourish = restore_lib:get_value(restore_db:restore(Src, EndRoleUid), 'flourish'),
                                AddGoBack = marching:change_goback(marching:fight_result(Marching, Injured, Dead, []), EndPoint),
                                {[], [], [AddGoBack | UpGoBack], [], {}, 0, false, BName, PlunderTime, NewFlourish}
                        end,
                    FeatsList = [{MarchRoleUid, RoleAddFeats}, {EndRoleUid, Feats}],
                    %被掠夺玩家损失和奖励
                    zm_event:notify(Src, 'bi_fight_pasv_plunder', [{'role_uid', EndRoleUid}, {'consumes', BiCs}, {'award', EnemyAward}]),
                    GRUid =
                        if
                            OGid =:= 0 ->
                                0;
                            true ->
                                EndRoleUid
                        end,
                    zm_event:notify(Src, 'fight_role_castle_report', [
                        {'time', MEtime},
                        {'role_uid', MarchRoleUid},
                        {'ruid', EndRoleUid},
                        {'garrison_role_uid', GRUid},
                        {'winner', Winner},
                        {'award_list', NAwardView},
                        {'wave_infos', WaveInfos},
                        {'lose_list', LoseList},
                        {'feats', []},
                        {'del_flourish', DelFlourish},
                        {'personal_num', FeatsList},%%个人积分
                        {'new_flourish', NewFlourish1} | NFightArgs]),
                    zm_event:notify(Src, 'bi_fight_attack_role', [{'role_uid', MarchRoleUid}, {'be_role_uid', EndRoleUid}, {'type', ?ROLE}, {'dead', Dead},
                        {'injured', Injured}, {'be_dead', result:get_enemy_total_dead(Result)}, {'be_injured', result:get_enemy_total_injure(Result)},
                        {'award_list', NAwardView}, {'win', Winner}]),
                    zm_event:notify(Src, 'cross_battle_role_point', FeatsList),
                    zm_event:notify(Src, 'cross_battle_kill_enemy', [{MarchRoleUid, result:get_enemy_total_dead(Result)}, {EndRoleUid, Dead}]),
                    {NUpGoBack, RandMove, BRName, RPlunderTime}
                catch
                    E1: E2 ->
                        zm_log:warn(?MODULE, ?MODULE, 'fighting', "handle_error", [{'e1', E1}, {'e2', E2}, {'point_uid', EndPoint},
                            {'marching', Marching}, {'stacktrace', erlang:get_stacktrace()}]),
                        {[marching:change_goback(Marching, EndPoint) | UpGoBack], RandomMove, BName, PlunderTime}
                end,
            case NewRMove of
                true ->
                    ArrMarchToGoback = lists:filter(fun(M) ->
                        marching:get_state(M) =/= ?ON_THE_MB_CC andalso marching:get_state(Marching) =/= ?ON_THE_PATROL end, ArrMarch),
                    NUpGoBack2 = fighting:mrole_endpoint_change(Src, EndPoint, ArrMarchToGoback) ++ NUpGoBack1,
                    {NUpGoBack2, Occ, NewRMove, NBName, NPlunderTime};
                false ->
                    do_fighting(Src, CastleState, EndCorpsUid, Now, EndPoint, FightArgs, EndRoleUid,
                        ArrMarch, NUpGoBack1, NewRMove, NBName, NPlunderTime, Occ)
            end;
        WebErr ->
            zm_log:warn(?MODULE, ?MODULE, 'fighting', "web_error", [{'error', WebErr}, {'point_uid', EndPoint}, {'marching', Marching}]),
            AddGoBack = marching:change_goback(Marching, EndPoint),
            do_fighting(Src, CastleState, EndCorpsUid, Now, EndPoint, FightArgs, EndRoleUid,
                ArrMarch, [AddGoBack | UpGoBack], RandomMove, BName, PlunderTime, Occ)
    end.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%      驻防友军战斗后阵型等数据修改
%% @end
%% ----------------------------------------------------
update_occ_garray(Src, Winner, OMarching, EndPoint, EndRoleUid, [{_, {DeadNum, Injured, GarrayList}} | _], EnemyAddFeatsList, FightTime) ->
    {ORoleUid, OGId} = marching:get_roleuid_gid(OMarching),
    {_, FQueue, GarrayInjured, _AutoAddSoldier, _DeductSosldierNum} =
        fighting:update_garray_after_fight(Src, GarrayList, {ORoleUid, OGId}),%修改队伍信息
    set_front_lib:send_map_result(Src, EndRoleUid, {FightTime, EndPoint, ?ROLE, ?ROLE, Winner, 0, ORoleUid, 1}),%%(玩家A协防B;给B推送时候,Gid=0;即Gid=0时候不处理阵型兵营数据,只处理友军驻防的队伍信息,阵型地方传递为友军roleuid;如果是自己则不处理)
    set_front_lib:send_map_result(Src, ORoleUid, {FightTime, EndPoint, ?ROLE, ?ROLE, Winner, OGId, {FQueue, DeadNum, Injured, GarrayInjured}, 2}), %协防玩家
    %%死亡数和受伤数累计
    [Feats | TailEnemyAddFeatsList] = EnemyAddFeatsList,
    NOMarching = marching:fight_result(OMarching, Injured, DeadNum, []),
    AddFeats = lists:sum(TailEnemyAddFeatsList),
    {AddFeats, Feats, NOMarching}.


%% ----------------------------------------------------
%% @doc
%%      自己驻防或者只有城墙战斗后阵型等数据修改
%% @end
%% ----------------------------------------------------
update_owner_garray(Src, Winner, 0, EndPoint, EndRoleUid, _, EnemyAddFeatsList, FightTime) ->
    %%只有城墙
    set_front_lib:send_map_result(Src, EndRoleUid, {FightTime, EndPoint, ?ROLE, ?ROLE, Winner, 0, EndRoleUid, 1}),
    [Feats] = EnemyAddFeatsList,
    Feats;
update_owner_garray(Src, Winner, GId, EndPoint, EndRoleUid, [{_, {DeadNum, Injured, GarrayList}} | _], EnemyAddFeatsList, FightTime) ->
    %%自己队伍
    {_, FQueue, GarrayInjured, AutoAddSoldier, _DeductSosldierNum} =
        fighting:update_garray_after_fight(Src, GarrayList, {EndRoleUid, GId}, false),%修改队伍信息
    set_front_lib:send_map_result(Src, EndRoleUid, {FightTime, EndPoint, ?ROLE, ?ROLE, Winner, GId, {FQueue, DeadNum, Injured, GarrayInjured}, 1}), %10s内的战斗才推送给玩家战斗结果
    FInjureMax = building_db:get_injure_max(Src, EndRoleUid),
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'barracks', EndRoleUid, barracks:init()},
        {'garray', {EndRoleUid, GId}, garray:init()}
    ]),
    Fun = fun(_, [{Index1, Barracks}, {Index2, Garry}]) ->
        {FInjure2Dead, NBarracks} = barracks:fight_over(Barracks, GId, DeadNum, Injured, FInjureMax),
        NGarray = garray:set_injured_init(Garry),
        {'ok', {barracks:get_leisure(NBarracks), FInjure2Dead}, [{Index1, NBarracks}, {Index2, NGarray}]}
    end,
    {_Leisure, Injure2Dead} = z_db_lib:handle(TableName, Fun, [], TableKeys),%修改兵营信息,以及阵型伤病数据
    fighting:injure2dead_mail(Src, EndRoleUid, Injure2Dead),
    if
        (Injured =/= 0 orelse DeadNum =/= 0) andalso AutoAddSoldier =:= 1 ->
            Study = building_db:get_study(Src, EndRoleUid),
            OfficailAttr = official_db:get_attrs(Src, EndRoleUid),
            CardStorage = storage_db:get_storage('card', Src, EndRoleUid),
            Political = building_db:get_political(Src, EndRoleUid),
            garray_db:auto_add_soldiers(Src, EndRoleUid, GId, Study, CardStorage, Political, OfficailAttr, false, true, true, true);
        true ->
            ok
    end,
    Bool = garray_lib:is_no_soldiers(garray_db:get_garray(Src, EndRoleUid, GId)),
    if
        Bool ->
            case garrison_db:down_garray(Src, EndRoleUid, GId) of
                'ok' ->
                    set_front_lib:send_garrison_down_garray(Src, EndRoleUid, GId),
                    ok;
                Other ->
                    Other
            end;
        true ->
            ok
    end,
    lists:sum(EnemyAddFeatsList).