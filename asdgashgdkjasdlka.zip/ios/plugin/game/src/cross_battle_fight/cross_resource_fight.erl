-module(cross_resource_fight).

%%%=======================STATEMENT====================
-description("cross_resource_fight").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    fighting/5,
    get_collect_value/4,
    overflow_res_award/3,
    overflow_res_award/4
]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").
-include("../include/report.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
-spec fighting(Src, Now, EndPoint, {?RESOURCE, RSid}, {ArrMarch, Occ}) -> {[marching:marching()], list()} when
    Src :: atom(),
    Now :: integer(),
    EndPoint :: integer(),
    RSid :: integer(),
    ArrMarch :: [marching:marching()],
    Occ :: [marching:marching()].
fighting(Src, Now, EndPoint, {?RESOURCE, ResourceSid}, {ArrMarch, _Occ}) ->
    {COccList, RealArr} = lists:partition(fun(M) -> marching:get_state(M) =:= ?ON_THE_COLLECTION end, ArrMarch),
    ResourceDetail = resource_detail:get_cfg(ResourceSid),
    {NewOccList, OccBackList} = calc_occ(EndPoint, ResourceDetail, COccList, Now),
    {NOcc, AddBackMarchings} = do_fighting(Src, Now, EndPoint, ResourceDetail, RealArr, lists:reverse(lists:keysort(marching:get_etime_index(), NewOccList)), []),
    %处理视野
    if
        COccList =:= [] andalso NOcc =:= [] ->
            ok;
        COccList =:= [] ->
            M = hd(NOcc),
            CorpsUid = role_show:get_corps_uid(role_db:get_role_show(Src, marching:get_roleuid(M))),
            point_horizon:add_resource_horizon(Src, CorpsUid, EndPoint, ResourceDetail);
        NOcc =:= [] ->
            M = hd(COccList),
            CorpsUid = role_show:get_corps_uid(role_db:get_role_show(Src, marching:get_roleuid(M))),
            point_horizon:delete_horizon(Src, CorpsUid, EndPoint);
        true ->
            M1 = hd(NOcc),
            CorpsUid1 = role_show:get_corps_uid(role_db:get_role_show(Src, marching:get_roleuid(M1))),
            M2 = hd(COccList),
            CorpsUid2 = role_show:get_corps_uid(role_db:get_role_show(Src, marching:get_roleuid(M2))),
            if
                M1 =:= M2 ->
                    ok;
                true ->
                    point_horizon:add_resource_horizon(Src, CorpsUid1, EndPoint, ResourceDetail),
                    point_horizon:delete_horizon(Src, CorpsUid2, EndPoint)
            end
    end,
    {NOcc, OccBackList ++ AddBackMarchings}.


%%%===================LOCAL FUNCTIONS==================
do_fighting(_Src, _Now, _EndPoint, _ResourceDetail, [], Occ, BackMarchs) ->
    {Occ, BackMarchs};
do_fighting(Src, Now, EndPoint, ResourceDetail, [Marching | Marchings], Occ, BackMarchs) ->
    {MarchRoleUid, MarchGId} = marching:get_roleuid_gid(Marching),
    MRShow = role_db:get_role_show(Src, MarchRoleUid),
    CorpsUid = role_show:get_corps_uid(MRShow),
    OccLen = length(Occ),
    ETime = marching:get_etime(Marching),
    case Occ of
        [] ->%无人采集,无守军
            {_, NOccMarching} = refresh_occ_marching(ResourceDetail, marching:set_state(marching:set_stime(Marching, ETime), ?ON_THE_COLLECTION), OccLen + 1, ETime, false),
            do_fighting(Src, Now, EndPoint, ResourceDetail, Marchings, [NOccMarching], BackMarchs);
        [OccMarching | RestOccList] ->
            case check_occ(Marching, Occ) of
                true ->%自己队伍已经有了,回城
                    BackMarching = marching:change_goback(Marching, EndPoint),
                    do_fighting(Src, Now, EndPoint, ResourceDetail, Marchings, Occ, [BackMarching | BackMarchs]);
                false ->
                    {ORoleUid, OGid} = marching:get_roleuid_gid(OccMarching),
                    OCorpUid = role_show:get_corps_uid(role_db:get_role_show(Src, ORoleUid)),
                    if
                        CorpsUid =:= OCorpUid ->%同一军团
                            {_, NOccMarching} = refresh_occ_marching(ResourceDetail, marching:set_state(marching:set_stime(Marching, ETime), ?ON_THE_COLLECTION), OccLen + 1, ETime, false),
                            do_fighting(Src, Now, EndPoint, ResourceDetail, Marchings, lists:append(Occ, [NOccMarching]), BackMarchs);
                        true -> %不同军团
                            MarchFightRole = fighter:init_role(Src, MarchRoleUid, MarchGId, 0, garray_db:get_garray(Src, MarchRoleUid, MarchGId)),
                            %攻占胜利后,继续战斗,有可能无兵了
                            case fighter:get_fighters(MarchFightRole) of
                                [] ->
                                    BackMarching = marching:change_goback(Marching, EndPoint),
                                    do_fighting(Src, Now, EndPoint, ResourceDetail, Marchings, Occ, [BackMarching | BackMarchs]);
                                _ ->
                                    FightType = match_lib:get_fight_type(?MODULE),
                                    Sid = fighting:get_fight_scene('resource'),
                                    FightArgs = [
                                        {'auto', 1},
                                        {'time', ETime},
                                        {'fight_type', FightType},
                                        {'duplicate_sid', Sid},
                                        {'seed', game_lib:get_seed()},
                                        {'fight_role', MarchFightRole},
                                        {'role_uid', MarchRoleUid},
                                        {'point_int', EndPoint}],
                                    OFighterRole = fighter:init_role(Src, ORoleUid, OGid, 1, garray_db:get_garray(Src, ORoleUid, OGid)),
                                    NFightArgs = [{'ma', {'fighting', []}},
                                        {'fight_enemy', [OFighterRole]},
                                        {'ruid', ORoleUid},
                                        {'sid', resource_detail:get_sid(ResourceDetail)} | FightArgs],
                                    case match:auto_result(Src, MarchRoleUid, NFightArgs) of %攻打玩家不会获得武将经验
                                        {Winner, Result} ->%返回 result/6的结果,表示web一切正常
                                            Dead = result:get_dead(Result),
                                            Injured = result:get_injured(Result),
                                            RoleChange = result:get_queue(Result),
                                            WaveInfos = result:get_waves(Result),
                                            [{_, {ODead, OInjured, TargetChange}} | _] = WaveInfos,
                                            {_SoldierBearLoad, MarchQueue, GarrayInjured, _, _} =
                                                fighting:update_garray_after_fight(Src, RoleChange, {MarchRoleUid, MarchGId}),
                                            {OSoldierBearLoad, OQueue, OGarrayInjured, _, _} =
                                                fighting:update_garray_after_fight(Src, TargetChange, {ORoleUid, OGid}),
                                            OccMarchingExtra = marching:get_extra(OccMarching),
                                            NOccMarchingExtra = marching:set_extra_soldier_bearload(OccMarchingExtra, OSoldierBearLoad),
                                            {_, NOccMarching} = refresh_occ_marching(ResourceDetail, marching:set_extra(OccMarching, NOccMarchingExtra), OccLen, ETime, false),
                                            set_front_lib:send_map_result(Src, MarchRoleUid,
                                                {ETime, EndPoint, ?RESOURCE, ?ROLE, Winner, MarchGId, {MarchQueue, Dead, Injured, GarrayInjured}, 0}),
                                            set_front_lib:send_map_result(Src, ORoleUid,
                                                {ETime, EndPoint, ?RESOURCE, ?ROLE, Winner, OGid, {OQueue, ODead, OInjured, OGarrayInjured}, 1}),
                                            zm_event:notify(Src, 'bi_fight_attack_role', [{'role_uid', MarchRoleUid}, {'be_role_uid', ORoleUid}, {'type', ?RESOURCE}, {'dead', Dead},
                                                {'injured', Injured}, {'be_dead', result:get_enemy_total_dead(Result)}, {'be_injured', result:get_enemy_total_injure(Result)},
                                                {'award_list', []}, {'win', Winner}]),
                                            PersonalNumList = [{MarchRoleUid, result:get_role_feats(Result)}, {ORoleUid, hd(result:get_enemy_feats_list(Result))}],
                                            zm_event:notify(Src, 'cross_battle_role_point', PersonalNumList),
                                            zm_event:notify(Src, 'cross_battle_kill_enemy', [{MarchRoleUid, result:get_enemy_total_dead(Result)}, {ORoleUid, Dead}]),
                                            if
                                                Winner =:= 0 ->%进攻方玩家胜利
                                                    BMarching = marching:change_goback(marching:set_etime(NOccMarching, ETime), EndPoint),
                                                    OccBackMarching = marching:fight_result(BMarching, OInjured, ODead, []),%失败方,只有功勋奖励,且不修改状态为采集回城
                                                    NewMarching = marching:fight_result(Marching, Injured, Dead, []),
                                                    zm_event:notify(Src, 'cross_fight_publice_resource_report', [
                                                        {'winner', Winner},
                                                        {'award_list', []},
                                                        {'wave_infos', WaveInfos},
                                                        {'personal_num', PersonalNumList} | NFightArgs]),
                                                    do_fighting(Src, Now, EndPoint, ResourceDetail, [NewMarching | Marchings], RestOccList, [OccBackMarching | BackMarchs]);
                                                true ->
                                                    zm_event:notify(Src, 'cross_fight_publice_resource_report', [
                                                        {'winner', Winner},
                                                        {'award_list', []},
                                                        {'wave_infos', WaveInfos},
                                                        {'personal_num', PersonalNumList} | NFightArgs]),
                                                    BackMarching = marching:fight_result(marching:change_goback(Marching, EndPoint), Injured, Dead, []),%进攻方失败,直接回城,不发送采集战报
                                                    case marching:get_etime(NOccMarching) =< ETime of %被攻击方,胜利,但是达到负重,回城,发送采集战报
                                                        true ->
                                                            Value = get_collect_value(OccMarching, ResourceDetail, ETime, OccLen),%使用Occ计算当前采集量
                                                            AwardList = if
                                                                Value > 0 ->
                                                                    RType = resource_detail:get_type(ResourceDetail),
                                                                    [{RType, Value}];
                                                                true -> []
                                                            end,
                                                            OccBackMarching = marching:change_goback(marching:set_etime(NOccMarching, ETime), EndPoint),
                                                            NAddGoBack = marching:set_state(marching:fight_result(OccBackMarching, OInjured, ODead, AwardList), ?ON_THE_COLLECTION_GOBACK),
                                                            do_fighting(Src, Now, EndPoint, ResourceDetail, Marchings, RestOccList, [NAddGoBack, BackMarching | BackMarchs]);
                                                        false ->
                                                            NNOccMarching = marching:fight_result(NOccMarching, OInjured, ODead, []),
                                                            do_fighting(Src, Now, EndPoint, ResourceDetail, Marchings, [NNOccMarching | RestOccList], [BackMarching | BackMarchs])
                                                    end
                                            end;
                                        WebErr ->
                                            zm_log:warn(?MODULE, ?MODULE, 'fighting', "web_error", [{'error', WebErr}, {'point_uid', EndPoint}, {'marching', Marching}]),
                                            BackMarching = marching:change_goback(Marching, EndPoint),
                                            do_fighting(Src, Now, EndPoint, ResourceDetail, Marchings, Occ, [BackMarching | BackMarchs])
                                    end
                            end
                    end
            end
    end.


%% ----------------------------------------------------
%% @doc
%%      刷新计算正在采集的行军信息
%% @end
%% ----------------------------------------------------
refresh_occ_marching(ResourceDetail, Marching, OccLen, Now, ChkBakBool) ->
    {_, PerList} = zm_config:get('cross_battle_info', 'resource_ratio'),
    AddPer = game_lib:level_value(OccLen, PerList),
    MarchingExtra = marching:get_extra(Marching),
    BearLoad = marching:get_extra_bearload(MarchingExtra),
    CollectSpeedAdd = marching:get_extra_collect_speed_add(MarchingExtra),
    BeginTime = marching:get_stime(Marching),
    ETime = marching:get_etime(Marching),
    BaseSpeed = resource_detail:get_speed(ResourceDetail),
    T = resource_detail:get_time(ResourceDetail),
    Speed = BaseSpeed * (10000 + CollectSpeedAdd + AddPer) div 10000,
    OldValue = marching:get_extra_collect_plunder(MarchingExtra),%跨服记录已采集量
    CTime = max(0, min(Now, ETime) - BeginTime),
    MState = marching:get_state(Marching),
    CValue = trunc(CTime * Speed / T),%已产出
    {Bool, NM} =
        if
            OldValue + CValue >= BearLoad ->
                Ex = marching:set_extra_collext_plunder(marching:get_extra(Marching), 0),
                NM1 = marching:set_award(marching:set_stime(marching:set_extra(marching:set_etime(Marching, Now), Ex), Now), [{resource_detail:get_type(ResourceDetail), BearLoad}]),
                {true, NM1};
            ChkBakBool andalso MState =:= ?ON_THE_COLLECTION andalso Now >= ETime ->%提前召回
                Ex = marching:set_extra_collext_plunder(marching:get_extra(Marching), 0),
                NM1 = marching:set_award(marching:set_stime(marching:set_extra(marching:set_etime(Marching, ETime), Ex), Now), [{resource_detail:get_type(ResourceDetail), OldValue + CValue}]),
                {true, NM1};
            true ->
                EndTime = game_lib:ceil(max((BearLoad - OldValue), 0) / Speed * T) + Now,
                Ex = marching:set_extra_collext_plunder(marching:get_extra(Marching), OldValue + CValue),
                NM1 = marching:set_stime(marching:set_extra(marching:set_etime(Marching, EndTime), Ex), Now),
                {false, NM1}
        end,
    {Bool, NM}.

%% ----------------------------------------------------
%% @doc
%%      获取当前采集量
%% @end
%% ----------------------------------------------------
get_collect_value(Marching, ResourceDetail, EndTimeTmp, OccLen) ->
    {_, PerList} = zm_config:get('cross_battle_info', 'resource_ratio'),
    AddPer = game_lib:level_value(OccLen, PerList),
    EndTime = min(EndTimeTmp, marching:get_etime(Marching)),
    MarchingExtra = marching:get_extra(Marching),
    CollectSpeedAdd = marching:get_extra_collect_speed_add(MarchingExtra),
    OldValue = marching:get_extra_collect_plunder(MarchingExtra),
    BearLoad = marching:get_extra_bearload(MarchingExtra),
    BeginTime = marching:get_stime(Marching),
    BaseSpeed = resource_detail:get_speed(ResourceDetail),
    T = resource_detail:get_time(ResourceDetail),
    Speed = BaseSpeed * (10000 + CollectSpeedAdd + AddPer) div 10000,
    erlang:min(erlang:trunc((EndTime - BeginTime) * Speed / T) + OldValue, BearLoad).


%% ----------------------------------------------------
%% @doc
%%     计算采集信息
%% @end
%% ----------------------------------------------------
calc_occ(_EndPoint, _ResourceDetail, [], _Now) ->
    {[], []};
calc_occ(EndPoint, ResourceDetail, OccList, Now) ->
    Fun = fun({Len, OAcc, BAcc}, Marching) ->
        case refresh_occ_marching(ResourceDetail, Marching, Len, Now, true) of
            {true, BackMarch} ->
                {ok, {Len - 1, OAcc, [marching:set_state(marching:change_goback(BackMarch, EndPoint), ?ON_THE_COLLECTION_GOBACK) | BAcc]}};
            {false, OccMarch} ->
                {ok, {Len, [OccMarch | OAcc], BAcc}}
        end
    end,
    {_, OL, BL} = z_lib:foreach(Fun, {length(OccList), [], []}, OccList),
    {lists:reverse(OL), lists:reverse(BL)}.

%% ----------------------------------------------------
%% @doc
%%    检测occ中是否有自己队伍
%% @end
%% ----------------------------------------------------
check_occ(Marching, OccList) ->
    RoleUid = marching:get_roleuid(Marching),
    lists:any(fun(M) -> marching:get_roleuid(M) =:= RoleUid end, OccList).

%% ----------------------------------------------------
%% @doc
%%      处理资源C溢出
%% @end
%% ----------------------------------------------------
overflow_res_award(Src, RoleUid, AwardList) ->
    overflow_res_award(Src, RoleUid, AwardList, true).
overflow_res_award(Src, RoleUid, AwardList, Bool) ->
    {_, FlowList} = zm_config:get('cross_battle_info', 'res_upper'),
    Role = role_db:get_role(Src, RoleUid),
    Fun = fun(AList, {RType, Max}) ->
        case lists:keyfind(RType, 1, AList) of
            false ->
                {'ok', AList};
            {_, AwardV} ->
                Fun = string_lib:to_atom('get_', RType),
                CurV = role:Fun(Role),
                if
                    CurV + AwardV > Max ->
                        AddV = Max-CurV,
                        if
                            AddV > 0 ->
                                {ok, lists:keyreplace(RType, 1, AList, {RType, AddV})};
                            true ->
                                {ok, lists:keydelete(RType, 1, AList)}
                        end;
                    true ->
                        {'ok', AList}
                end
        end
    end,
    NAwardList = z_lib:foreach(Fun, AwardList, FlowList),
    case Bool of
        true ->
            %%采集量转换成积分
            zm_event:notify(Src, 'cross_battle_role_point', [{RoleUid, cross_battle_lib:resource_to_point(NAwardList)}]);
        false ->
            ok
    end,
    NAwardList.