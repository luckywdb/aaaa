-module(cross_map_build_fight).

%%%=======================STATEMENT====================
-description("cross_map_build_fight").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([fighting/8]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        
%% @end
%% ----------------------------------------------------
fighting(Src, Now, EndPoint, EndPInfo, Marchings, Occ, MapBuildV, MapBuildVs) ->
    FightType = match_lib:get_fight_type(?MODULE),
    FightArgs = [
        {'ma', {'fighting', []}},
        {'auto', 1},%是否自动释放技能自动战斗 1:自动,0:手动
        {'fight_type', FightType},
        {'point_int', EndPoint}],
    {PointType, _, Key} = EndPInfo,
    {EndCorpsUid, EndCorps} =
        if
            PointType =:= ?MAP_BUILD_CORPS ->
                {Key, corps_db:get_corps(Src, Key)};
            PointType =:= ?MAP_BUILD_ROLE ->
                RoleUid = element(2, Key),
                RoleCorps = corps_db:get_role_corps(Src, RoleUid),
                CorpsUid = role_corps:get_corps_uid(RoleCorps),
                {CorpsUid, corps_db:get_corps(Src, CorpsUid)};
            true ->
                CUid = town:get_corps_uid(z_db_lib:get(game_lib:get_table(Src, 'town'), Key, town:init(Key))),
                {CUid, corps_db:get_corps(Src, CUid)}
        end,
    fighting(Src, Now, EndPoint, EndPInfo, FightArgs, Marchings, Occ, MapBuildV, [], EndCorpsUid, EndCorps, MapBuildVs).

fighting(Src, Now, EndPoint, EndPInfo, FightArgs, [Marching | TailMarchings], Occ, MapBuildV1, GoBackAcc, EndCorpsUid, EndCorps, MapBuildVs) ->
    MState = marching:get_state(Marching),
    {MRoleUid, MGId} = MarchRGId = marching:get_roleuid_gid(Marching),
    METime = marching:get_etime(Marching),
    MapBuildV = map_build_lib:calc_map_build_v(MapBuildV1, map_build:get_v_bvalue_speed(MapBuildV1), METime),
    MarchRoleShow = role_db:get_role_show(Src, MRoleUid),
    CUid = role_show:get_corps_uid(MarchRoleShow),
    {PointType, BSid, Key} = EndPInfo,
    case MState of
        ?ON_THE_MB_MARCHING ->
            case CUid =/= EndCorpsUid of
                true ->
                    zm_event:notify(Src, 'fight_null_report', [
                        {'role_uid', MRoleUid},
                        {'point_int', EndPoint},
                        {'time', METime},
                        {'r_type', ?REPORT_NULL_MB_GARRISON_NOTSOME_COPRS},
                        {'id', BSid}]),
                    fighting(Src, Now, EndPoint, EndPInfo, FightArgs, TailMarchings, Occ, MapBuildV, GoBackAcc, EndCorpsUid, EndCorps, MapBuildVs);
                false ->
                    {Speed, Const} = map_build_db:get_garray_speed_const(Src, MRoleUid, MGId),
                    OccMarching = marching:set_etime(marching:change_occ(Marching, Now, ?ON_THE_MB), -1),
                    NOccMarching = marching:set_extra(OccMarching, marching:init_mb_extra(Speed, Const)),
                    TotalSpeed = map_build:get_v_bvalue_speed(MapBuildV) + Speed,
                    NMapBuildV = map_build_lib:calc_map_build_v(MapBuildV, TotalSpeed, METime),
                    fighting(Src, Now, EndPoint, EndPInfo, FightArgs, TailMarchings, [NOccMarching | Occ], NMapBuildV, GoBackAcc, EndCorpsUid, EndCorps, MapBuildVs)
            end;
        _ ->
            case CUid =:= 0 of
                true ->
                    zm_event:notify(Src, 'fight_null_report', [
                        {'role_uid', MRoleUid},
                        {'point_int', EndPoint},
                        {'time', METime},
                        {'r_type', ?REPORT_NULL_FIGHT_MB_NOT_CORPS},
                        {'id', BSid}]),
                    fighting(Src, Now, EndPoint, EndPInfo, FightArgs, TailMarchings, Occ, MapBuildV, GoBackAcc, EndCorpsUid, EndCorps, MapBuildVs);
                false ->
                    Bool =
                        case PointType of
                            ?MAP_BUILD_CORPS ->
                                CUid =/= Key;
                            ?MAP_BUILD_ROLE ->
                                RoleUid = element(2, Key),
                                CUid =/= role_corps:get_corps_uid(corps_db:get_role_corps(Src, RoleUid));
                            ?MAP_BUILD_TOWN ->
                                CUid =/= town:get_corps_uid(z_db_lib:get(game_lib:get_table(Src, 'town'), Key, town:init(Key)))
                        end,
                    case Bool of
                        true ->
                            {NMarchings, AddGobackTmps} =
                                case PointType =/= ?MAP_BUILD_TOWN orelse marching:get_fight_num(Marching) > 0 of
                                    true ->
                                        {[Marching], []};
                                    false ->
                                        TownPointUid = town_detail:get_point(town_detail:get_cfg(Key)),
                                        map_build_db:map_build_damage(Src, Marching, EndPoint, EndCorps, MapBuildVs, TownPointUid)
                                end,
                            case NMarchings of
                                [MarchingT] ->
                                    case Occ of
                                        [] ->
                                            FightRole = fighter:init_role(Src, MRoleUid, MGId, 0, garray_db:get_garray(Src, MRoleUid, MGId)),
                                            Attack = get_mb_bvalue_attack(FightRole),
                                            {IsMBOver, {DeductValue1, _NBValue} = BValueInfo, NMapBuildV} = map_build_lib:deduct_bvalue(MapBuildV, Attack, METime),
                                            zm_event:notify(Src, 'cross_battle_town_point', [{MRoleUid, DeductValue1}]),
                                            zm_event:notify(Src, 'fight_map_build_bvalue_report', [
                                                {'time', METime},
                                                {'role_uid', MRoleUid},
                                                {'map_build_v', NMapBuildV},
                                                {'is_mb_over', IsMBOver},
                                                {'end_corps', EndCorps},
                                                {'bvalue', BValueInfo},
                                                {'fight_role', FightRole} | FightArgs]),
                                            GoBackMarching = marching:change_goback(Marching, EndPoint),
                                            if
                                                IsMBOver ->%%被打爆
                                                    AddGoBackMarching = marching:change_goback(Occ, EndPoint, METime),
                                                    {true, [], NMapBuildV, AddGoBackMarching ++ [GoBackMarching | GoBackAcc]};
                                                true ->
                                                    fighting(Src, Now, EndPoint, EndPInfo, FightArgs, TailMarchings, Occ, NMapBuildV, [GoBackMarching | GoBackAcc], EndCorpsUid, EndCorps, MapBuildVs)
                                            end;
                                        [OMarching | TailOcc] ->
                                            {ORoleUid, OGId} = ORGId = marching:get_roleuid_gid(OMarching),
                                            OGarray = garray_db:get_garray(Src, ORoleUid, OGId),
                                            MarchGarray = garray_db:get_garray(Src, MRoleUid, MGId),
                                            FighterRole = fighter:init_role(Src, MRoleUid, MGId, 0, MarchGarray),
                                            FightEnemy = fighter:init_role(Src, ORoleUid, OGId, 1, OGarray),
                                            NFightArgs = [
                                                {'duplicate_sid', fighting:get_fight_scene('station')},
                                                {'seed', game_lib:get_seed()},
                                                {'fight_role', FighterRole},
                                                {'fight_enemy', [FightEnemy]}%由于npc时候会有多场,故给web发送的是一个list,打玩家时候也需要发送list
                                                | FightArgs],
                                            case match:auto_result(Src, MRoleUid, NFightArgs) of
                                                {Winner, Result} ->%攻打玩家不会获得武将经验
                                                    {NMarching, NOMarching, Bool} =
                                                        try
                                                            Dead = result:get_dead(Result),
                                                            Injured = result:get_injured(Result),
                                                            RoleChange = result:get_queue(Result),
                                                            RoleAddFeats = result:get_role_feats(Result),
                                                            [EnemyAddFeats1] = result:get_enemy_feats_list(Result),
                                                            EnemyAddFeats = role_db:award_feats(Src, ORoleUid, EnemyAddFeats1),
                                                            NRoleAddFeats = role_db:award_feats(Src, MRoleUid, RoleAddFeats),
                                                            WaveInfos = result:get_waves(Result),
                                                            [{_, {ODead, OInjured, TargetChange}} | _] = WaveInfos,
                                                            {_, MarchQueue, GarrayInjured, _, _DeductSosldierNum} =
                                                                fighting:update_garray_after_fight(Src, RoleChange, MarchRGId),
                                                            set_front_lib:send_map_result(Src, MRoleUid, {METime, EndPoint, ?ROLE, PointType, Winner, MGId, {MarchQueue, Dead, Injured, GarrayInjured}, 0}),
                                                            {_, OMarchQueue, OGarrayInjured, _, _DeductSosldierNum} =
                                                                fighting:update_garray_after_fight(Src, TargetChange, ORGId),
                                                            set_front_lib:send_map_result(Src, ORoleUid, {METime, EndPoint, ?ROLE, PointType, Winner, OGId, {OMarchQueue, ODead, OInjured, OGarrayInjured}, 1}),

                                                            AttackAward = if
                                                                NRoleAddFeats > 0 ->
                                                                    [{'feats', NRoleAddFeats}];
                                                                true ->
                                                                    []
                                                            end,
                                                            Marching1 = marching:fight_result(MarchingT, Injured, Dead, AttackAward),
                                                            OAttackAward = if
                                                                EnemyAddFeats > 0 ->
                                                                    [{'feats', EnemyAddFeats}];
                                                                true ->
                                                                    []
                                                            end,
                                                            OMarching1 = marching:fight_result(OMarching, OInjured, ODead, OAttackAward),
                                                            FeatsList = [{MRoleUid, NRoleAddFeats}, {ORoleUid, EnemyAddFeats}],
                                                            BValueInfo =
                                                                if
                                                                    Winner =:= 0 andalso TailOcc =:= [] ->
                                                                        FightRole = fighter:init_role(Src, MRoleUid, MGId, 0, garray_db:get_garray(Src, MRoleUid, MGId)),
                                                                        Attack = get_mb_bvalue_attack(FightRole),
                                                                        {_, {DeductValue, _NBValue} = BValueInfo1, _} = map_build_lib:deduct_bvalue(MapBuildV, Attack, METime),
                                                                        zm_event:notify(Src, 'cross_battle_town_point', [{MRoleUid, DeductValue}]),
                                                                        BValueInfo1;
                                                                    true ->
                                                                        {0, map_build:get_v_bvalue(MapBuildV)}
                                                                end,
                                                            PointOwner = case element(1, EndPInfo) of
                                                                ?MAP_BUILD_ROLE ->
                                                                    element(2, element(3, EndPInfo));
                                                                _ ->
                                                                    0
                                                            end,
                                                            zm_event:notify(Src, 'fight_map_build_report', [
                                                                {'time', METime},
                                                                {'role_uid', MRoleUid},
                                                                {'ruid', ORoleUid},
                                                                {'point_owner', PointOwner},
                                                                {'map_build_v', MapBuildV},
                                                                {'bvalue', BValueInfo},
                                                                {'winner', Winner},
                                                                {'wave_infos', WaveInfos},
                                                                {'personal_num', FeatsList} | NFightArgs]),
                                                            zm_event:notify(Src, 'bi_fight_attack_station', [{'role_uid', MRoleUid}, {'be_role_uid', ORoleUid}, {'type', PointType}, {'dead', Dead},
                                                                {'injured', Injured}, {'be_dead', result:get_enemy_total_dead(Result)}, {'be_injured', result:get_enemy_total_injure(Result)},
                                                                {'award_list', []}, {'win', Winner}]),
                                                            zm_event:notify(Src, 'cross_battle_role_point', FeatsList),
                                                            zm_event:notify(Src, 'cross_battle_kill_enemy', [{MRoleUid, result:get_enemy_total_dead(Result)}, {ORoleUid, Dead}]),
                                                            {Marching1, OMarching1, true}
                                                        catch
                                                            E1: E2 ->
                                                                zm_log:warn(?MODULE, ?MODULE, 'fighting', "handle_error", [{'e1', E1}, {'e2', E2}, {'point_uid', EndPoint},
                                                                    {'marching', MarchingT}, {'stacktrace', erlang:get_stacktrace()}]),
                                                                {MarchingT, OMarching, false}
                                                        end,
                                                    OccMExtra = marching:get_extra(NOMarching),
                                                    if
                                                        Bool andalso Winner =:= 0 ->
                                                            AddGoback = marching:change_goback(NOMarching, EndPoint, METime),
                                                            NMapBuildV = map_build_lib:calc_map_build_v(MapBuildV,
                                                                map_build:get_v_bvalue_speed(MapBuildV) - marching:get_extra_mb_speed(OccMExtra), METime),
                                                            fighting(Src, Now, EndPoint, EndPInfo, FightArgs, [NMarching | TailMarchings], TailOcc, NMapBuildV, [AddGoback | GoBackAcc], EndCorpsUid, EndCorps, MapBuildVs);
                                                        Bool andalso Winner =:= 1 ->
                                                            AddGoBack = marching:change_goback(NMarching, EndPoint),
                                                            case garray_lib:is_no_soldiers(garray_db:get_garray(Src, ORoleUid, OGId)) of
                                                                true ->
                                                                    AddGoBackList = [AddGoBack, marching:change_goback(NOMarching, EndPoint, METime)],
                                                                    NMapBuildV = map_build_lib:calc_map_build_v(MapBuildV,
                                                                        map_build:get_v_bvalue_speed(MapBuildV) - marching:get_extra_mb_speed(OccMExtra), METime),
                                                                    fighting(Src, Now, EndPoint, EndPInfo, FightArgs, TailMarchings, TailOcc, NMapBuildV, AddGoBackList ++ GoBackAcc, EndCorpsUid, EndCorps, MapBuildVs);
                                                                false ->
                                                                    GSpeed = map_build_db:get_garray_speed(Src, ORoleUid, OGId, marching:get_extra_mb_const(OccMExtra)),
                                                                    NMapBuildV = map_build_lib:calc_map_build_v(MapBuildV,
                                                                        map_build:get_v_bvalue_speed(MapBuildV) - marching:get_extra_mb_speed(OccMExtra) + GSpeed, METime),
                                                                    NewOMarching = marching:set_extra(NOMarching, marching:set_extra_mb_speed(OccMExtra, GSpeed)),
                                                                    fighting(Src, Now, EndPoint, EndPInfo, FightArgs, TailMarchings, [NewOMarching | TailOcc], NMapBuildV, [AddGoBack | GoBackAcc], EndCorpsUid, EndCorps, MapBuildVs)
                                                            end;
                                                        true ->
                                                            GSpeed = map_build_db:get_garray_speed(Src, ORoleUid, OGId, marching:get_extra_mb_const(OccMExtra)),
                                                            NMapBuildV = map_build_lib:calc_map_build_v(MapBuildV,
                                                                map_build:get_v_bvalue_speed(MapBuildV) - marching:get_extra_mb_speed(OccMExtra) + GSpeed, METime),
                                                            NewOMarching = marching:set_extra(NOMarching, marching:set_extra_mb_speed(OccMExtra, GSpeed)),
                                                            fighting(Src, Now, EndPoint, EndPInfo, FightArgs, TailMarchings, [NewOMarching | TailOcc], NMapBuildV, GoBackAcc, EndCorpsUid, EndCorps, MapBuildVs)
                                                    end;
                                                WebErr ->
                                                    zm_log:warn(?MODULE, ?MODULE, 'fighting', "web_error", [{'error', WebErr}, {'point_uid', EndPoint}, {'marching', MarchingT}]),
                                                    AddGoback = marching:change_goback(MarchingT, EndPoint, METime),
                                                    fighting(Src, Now, EndPoint, EndPInfo, FightArgs, TailMarchings, Occ, MapBuildV, [AddGoback | GoBackAcc], EndCorpsUid, EndCorps, MapBuildVs)
                                            end
                                    end;
                                _ ->
                                    fighting(Src, Now, EndPoint, EndPInfo, FightArgs, TailMarchings, Occ, MapBuildV, AddGobackTmps ++ GoBackAcc, EndCorpsUid, EndCorps, MapBuildVs)
                            end;
                        false ->
                            zm_event:notify(Src, 'fight_null_report', [
                                {'role_uid', MRoleUid},
                                {'point_int', EndPoint},
                                {'time', METime},
                                {'r_type', ?REPORT_NULL_FIGHT_MB_OWNER_COPRS},
                                {'id', BSid}]),
                            GoBackMarching = marching:change_goback(Marching, EndPoint),
                            fighting(Src, Now, EndPoint, EndPInfo, FightArgs, TailMarchings, Occ, MapBuildV, [GoBackMarching | GoBackAcc], EndCorpsUid, EndCorps, MapBuildVs)
                    end
            end
    end;
fighting(_Src, _Now, _EndPoint, _EndPInfo, _FightArgs, [], Occ, MapBuildV, GoBackAcc, _EndCorpsUid, _EndCorps, _MapBuildVs) ->
    {false, Occ, MapBuildV, GoBackAcc}.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
%% ----------------------------------------------------
%% @doc
%%     攻击驻扎点建筑值造成伤害
%% @end
%% ----------------------------------------------------
get_mb_bvalue_attack(FightRole) ->
    Attack = z_lib:foreach(fun(A, Fighter) ->
        {'ok', A + fighter:get_attack(Fighter)} end, 0, fighter:get_fighters(FightRole)),
    {OAttack, Speed} = case fighter:get_ordnance(FightRole) of
        {} -> {0, 10000};
        Ordnance ->
            {_, _, _, S} = zm_config:get('study_attrs', {fighter:get_o_sid(Ordnance), fighter:get_o_level(Ordnance)}),
            {fighter:get_o_attack(Ordnance), S}
    end,
    %speed是扩大了10000倍
    (Attack + (OAttack * 10000 div Speed)) div 10000.