-module(cross_spy_fight).

%%%=======================STATEMENT====================
-description("cross_spy_fight").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([fighting/7]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        
%% @end
%% ----------------------------------------------------
fighting(Src, _Now, EndPoint, {_, EndRoleUid} = EndPState, ArrMarch, OccMarchings, MapSpyBuild) ->
    EndRShow = role_db:get_role_show(Src, EndRoleUid),
    FightType = match_lib:get_fight_type(?MODULE),
    FightArgs = [
        {'ma', {'fighting', []}},
        {'auto', 1},%是否自动释放技能自动战斗 1:自动,0:手动
        {'fight_type', FightType},
        {'point_int', EndPoint}],
    EndCorpsUid = role_show:get_corps_uid(EndRShow),
    do_fighting(Src, EndCorpsUid, EndPoint, FightArgs, EndPState, ArrMarch, OccMarchings, MapSpyBuild, []).

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
do_fighting(Src, EndCorpsUid, EndPoint, FightArgs, EndPState, [Marching | TailMarchings], Occs, MapSpyBuild, UpGoBack) ->
    MState = marching:get_state(Marching),
    MarchRoleUid = marching:get_roleuid(Marching),
    MEtime = marching:get_etime(Marching),
    case MState of
        ?ON_THE_PATROL ->
            case MarchRoleUid =/= EndCorpsUid of
                true ->
                    case Occs =:= [] of
                        true ->
                            zm_event:notify(Src, 'fight_null_report', [
                                {'role_uid', element(2, EndPState)},
                                {'point_int', EndPoint},
                                {'time', marching:get_etime(Marching)},
                                {'r_type', ?REPORT_NULL_SPY_DEF},
                                {'id', point_lib:xyz2view(marching:get_s_point(Marching))}]),
                            AddGobackMarchings = fighting:mrole_endpoint_change(Src, EndPoint, TailMarchings),
                            {AddGobackMarchings ++ UpGoBack, Occs, MapSpyBuild, true};
                        false ->
                            do_fighting(Src, EndCorpsUid, EndPoint, FightArgs, EndPState, TailMarchings, Occs, MapSpyBuild, UpGoBack)
                    end;
                false ->
                    do_fighting(Src, EndCorpsUid, EndPoint, FightArgs, EndPState, TailMarchings, Occs, MapSpyBuild, UpGoBack)
            end;
        _ ->
            MarchCorpUid = role_show:get_corps_uid(role_db:get_role_show(Src, MarchRoleUid)),
            case MarchCorpUid > 0 andalso MarchCorpUid =:= EndCorpsUid of
                true ->
                    case MState =:= ?ON_THE_GARRISON_SPY_MARCHING of
                        true ->
                            ChangeOccM = marching:change_occ(Marching, MEtime, ?ON_THE_GARRISON_SPY),
                            do_fighting(Src, EndCorpsUid, EndPoint, FightArgs, EndPState, TailMarchings, [ChangeOccM | Occs], MapSpyBuild, UpGoBack);
                        false ->
                            %%TODO 战斗空战报(跨服不做)
                            ChangeGobackMarching = marching:change_goback(Marching, EndPoint),
                            do_fighting(Src, EndCorpsUid, EndPoint, FightArgs, EndPState, TailMarchings, Occs, MapSpyBuild, [ChangeGobackMarching | UpGoBack])
                    end;
                false ->
                    case MState =:= ?ON_THE_FIGHT_SPY_MARCHING of
                        true ->
                            {Bool1, Marching1, NOccs, NUpGoBack1} = role_fight_occ(Src, MEtime, EndPoint, element(2, EndPState), FightArgs, Marching, Occs, UpGoBack),
                            case Bool1 of
                                true ->
                                    {Bool2, Marching2, NMapSpyBuild} = role_fight_spy_npc(Src, MEtime, EndPoint, element(2, EndPState), FightArgs, Marching1, MapSpyBuild),
                                    NUpGoBack = [marching:change_goback(Marching2, EndPoint) | NUpGoBack1],
                                    case Bool2 of
                                        true ->
                                            AddGobackMarchings = fighting:mrole_endpoint_change(Src, EndPoint, TailMarchings),
                                            {AddGobackMarchings ++ NUpGoBack, NOccs, NMapSpyBuild, Bool2};
                                        false ->
                                            do_fighting(Src, EndCorpsUid, EndPoint, FightArgs, EndPState, TailMarchings, NOccs, NMapSpyBuild, NUpGoBack)
                                    end;
                                false ->
                                    NUpGoBack = [marching:change_goback(Marching1, EndPoint) | NUpGoBack1],
                                    do_fighting(Src, EndCorpsUid, EndPoint, FightArgs, EndPState, TailMarchings, NOccs, MapSpyBuild, NUpGoBack)
                            end;
                        false ->
                            %%TODO 驻防空战报(跨服不做)
                            ChangeGobackMarching = marching:change_goback(Marching, EndPoint),
                            do_fighting(Src, EndCorpsUid, EndPoint, FightArgs, EndPState, TailMarchings, Occs, MapSpyBuild, [ChangeGobackMarching | UpGoBack])
                    end
            end
    end;
do_fighting(_Src, _EndCorpsUid, _EndPoint, _FightArgs, _EndPState, [], Occs, MapSpyBuild, UpGoBack) ->
    {UpGoBack, Occs, MapSpyBuild, false}.


%% ----------------------------------------------------
%% @doc
%%      人打驻防
%% @end
%% ----------------------------------------------------
role_fight_occ(Src, MEtime, EndPoint, EndRoleUid, FightArgs, Marching, [OMarching | TailOcc], UpGoBack) ->
    {MRoleUid, MGId} = MRGId = marching:get_roleuid_gid(Marching),
    MGarray = garray_db:get_garray(Src, MRoleUid, MGId),
    FighterRole = fighter:init_role(Src, MRoleUid, MGId, 0, MGarray),
    {ORoleUid, OGId} = marching:get_roleuid_gid(OMarching),
    OGarray = garray_db:get_garray(Src, ORoleUid, OGId),
    FightEnemys = [fighter:init_role(Src, ORoleUid, OGId, 1, OGarray)],
    NFightArgs = [
        {'orgid', {ORoleUid, OGId}},
        {'duplicate_sid', fighting:get_fight_scene('role_role')},
        {'seed', game_lib:get_seed()},
        {'fight_role', FighterRole},
        {'fight_enemy', FightEnemys}%由于npc时候会有多场,故给web发送的是一个list,打玩家时候也需要发送list
        | FightArgs],
    case match:auto_result(Src, MRoleUid, NFightArgs) of
        {Winner, Result} ->
            Dead = result:get_dead(Result),
            Injured = result:get_injured(Result),
            RoleChange = result:get_queue(Result),
            RoleAddFeats = result:get_role_feats(Result),
            EnemyAddFeatsList = result:get_enemy_feats_list(Result),
            WaveInfos = result:get_waves(Result),
            {_, MarchQueue, GarrayInjured, _, _} = fighting:update_garray_after_fight(Src, RoleChange, MRGId),
            set_front_lib:send_map_result(Src, MRoleUid, {MEtime, EndPoint, ?ROLE, ?MAP_SPY, Winner, MGId, {MarchQueue, Dead, Injured, GarrayInjured}, 0, 0}),
            NRoleAddFeats = role_db:award_feats(Src, MRoleUid, RoleAddFeats),
            {Feats, OFeats, OMarching1} = update_occ_garray(Src, Winner, OMarching, EndPoint, EndRoleUid, WaveInfos, EnemyAddFeatsList, MEtime),
            AttackAward = if
                NRoleAddFeats > 0 ->
                    [{'feats', NRoleAddFeats}];
                true ->
                    []
            end,
            FeatsList = [{MRoleUid, NRoleAddFeats}, {EndRoleUid, Feats}, {ORoleUid, OFeats}],
            zm_event:notify(Src, 'fight_role_spy_garrison_report', [
                {'time', MEtime},
                {'role_uid', MRoleUid},
                {'ruid', EndRoleUid},
                {'garrison_role_uid', ORoleUid},
                {'winner', Winner},
                {'wave_infos', WaveInfos},
                {'feats', FeatsList} | NFightArgs]),
            NMarching = marching:fight_result(Marching, Injured, Dead, AttackAward),
            case Winner =:= 0 of
                true ->
                    NUpGoBack = [marching:change_goback(OMarching1, EndPoint) | UpGoBack],
                    role_fight_occ(Src, MEtime, EndPoint, EndRoleUid, FightArgs, NMarching, TailOcc, NUpGoBack);
                false ->
                    {false, NMarching, [OMarching1 | TailOcc], UpGoBack}
            end;
        WebErr ->
            zm_log:warn(?MODULE, ?MODULE, 'role_fight_occ', "web_error", [{'error', WebErr}, {'point_uid', EndPoint}, {'marching', Marching}, {'omarching', OMarching}]),
            {false, Marching, [OMarching | TailOcc], UpGoBack}
    end;
role_fight_occ(_Src, _MEtime, _EndPoint, _EndRoleUid, _FightArgs, Marching, [], UpGoBack) ->
    {true, Marching, [], UpGoBack}.

%% ----------------------------------------------------
%% @doc
%%      人打npc
%% @end
%% ----------------------------------------------------
role_fight_spy_npc(Src, _MEtime, EndPoint, EndRoleUid, _FightArgs, Marching, MapSpyBuild) ->
%%    {MRoleUid, MGId} = MRGId = marching:get_roleuid_gid(Marching),
%%    MGarray = garray_db:get_garray(Src, MRoleUid, MGId),
%%    FighterRole = fighter:init_role(Src, MRoleUid, MGId, 0, MGarray),
%%    NpcState = map_spy:get_build_npc_state(MapSpyBuild),
%%    FightEnemys = get_fight_npc(NpcState),
%%    NFightArgs = [
%%        {'duplicate_sid', fighting:get_fight_scene('monster')},
%%        {'seed', game_lib:get_seed()},
%%        {'fight_role', FighterRole},
%%        {'fight_enemy', FightEnemys}%由于npc时候会有多场,故给web发送的是一个list,打玩家时候也需要发送list
%%        | FightArgs],
%%    case match:auto_result(Src, MRoleUid, NFightArgs) of
%%        {Winner, Result} ->
%%            Dead = result:get_dead(Result),
%%            Injured = result:get_injured(Result),
%%            RoleChange = result:get_queue(Result),
%%            AllCardExp = result:get_allexp(Result),
%%            WaveInfos = result:get_waves(Result),
%%            {_, MarchQueue, GarrayInjured, _, _} = fighting:update_garray_after_fight(Src, RoleChange, MRGId),
%%            OneCardExp = garray_db:award_card_allexp(Src, MRoleUid, MGId, AllCardExp, z_lib:get_value(FightArgs, 'duplicate_sid', 0)),%武将加经验
%%            set_front_lib:send_map_result(Src, MRoleUid, {MEtime, EndPoint, ?ROLE, ?MAP_SPY, Winner, MGId, {MarchQueue, Dead, Injured, GarrayInjured}, 0, OneCardExp}),
%%            zm_event:notify(Src, 'fight_role_spy_npc_report', [
%%                {'time', MEtime},
%%                {'role_uid', MRoleUid},
%%                {'ruid', EndRoleUid},
%%                {'winner', Winner},
%%                {'wave_infos', WaveInfos} | NFightArgs]),
%%            NMarching = marching:fight_result(Marching, Injured, Dead, []),
%%            NNpcState = result:get_enemy_last_hps(Result),
%%            NMapSpyBuild = map_spy:set_build_npc_state(MapSpyBuild, NNpcState),
%%            {Winner =:= 0, NMarching, NMapSpyBuild};
%%        WebErr ->
%%            zm_log:warn(?MODULE, ?MODULE, 'role_fight_spy_npc', "web_error", [{'error', WebErr}, {'point_uid', EndPoint}, {'marching', Marching}, {'npc_state', NpcState}]),
%%            {false, Marching, MapSpyBuild}
%%    end.
    zm_event:notify(Src, 'fight_null_report', [
        {'role_uid', marching:get_roleuid(Marching)},
        {'point_int', EndPoint},
        {'time', marching:get_etime(Marching)},
        {'r_type', ?REPORT_NULL_SPY_FIGHT},
        {'id', EndRoleUid}]),
    zm_event:notify(Src, 'fight_null_report', [
        {'role_uid', EndRoleUid},
        {'point_int', EndPoint},
        {'time', marching:get_etime(Marching)},
        {'r_type', ?REPORT_NULL_SPY_DEF},
        {'id', point_lib:xyz2view(marching:get_s_point(Marching))}]),
    {true, Marching, MapSpyBuild}.

%% ----------------------------------------------------
%% @doc
%%      巡逻队伍打驻防
%% @end
%% ----------------------------------------------------
%%patrol_fight_occ(Src, MEtime, EndPoint, EndRoleUid, FightArgs, Marching, [OMarching | TailOcc], UpGoBack) ->
%%    %%巡逻不攻打驻防,直接消失,目前gid随机增加的id
%%    NpcGarray = [marching:get_gid(Marching)],
%%    FightNpc = fighter:init_npc(NpcGarray),
%%    {ORoleUid, OGId} = ORGId = marching:get_roleuid_gid(OMarching),
%%    OGarray = garray_db:get_garray(Src, ORoleUid, OGId),
%%    RoleFight = fighter:init_role(Src, ORoleUid, OGId, 1, OGarray),
%%    NFightArgs = [
%%        {'duplicate_sid', fighting:get_fight_scene('monster')},
%%        {'seed', game_lib:get_seed()},
%%        {'fight_role', RoleFight},
%%        {'fight_enemy', FightNpc}%由于npc时候会有多场,故给web发送的是一个list,打玩家时候也需要发送list
%%        | FightArgs],
%%    case match:auto_result(Src, ORoleUid, NFightArgs) of
%%        {Winner, Result} ->
%%            Dead = result:get_dead(Result),
%%            Injured = result:get_injured(Result),
%%            RoleChange = result:get_queue(Result),
%%            AllCardExp = result:get_allexp(Result),
%%            WaveInfos = result:get_waves(Result),
%%            {_, MarchQueue, GarrayInjured, _, _} = fighting:update_garray_after_fight(Src, RoleChange, ORGId),
%%            OneCardExp = garray_db:award_card_allexp(Src, ORoleUid, OGId, AllCardExp, z_lib:get_value(FightArgs, 'duplicate_sid', 0)),%武将加经验
%%            NWinner = case Winner =:= 0 of
%%                true ->
%%                    1;
%%                false ->
%%                    0
%%            end,
%%            set_front_lib:send_map_result(Src, EndRoleUid, {MEtime, EndPoint, ?MONSTER, ?MAP_SPY, NWinner, 0, ORoleUid, 1, 0}),
%%            set_front_lib:send_map_result(Src, ORoleUid, {MEtime, EndPoint, ?MONSTER, ?MAP_SPY, NWinner, OGId, {MarchQueue, Dead, Injured, GarrayInjured}, 2, OneCardExp}),
%%            zm_event:notify(Src, 'fight_patrol_spy_occ_report', [
%%                {'time', MEtime},
%%                {'role_uid', ORoleUid},
%%                {'ruid', EndRoleUid},
%%                {'winner', Winner},
%%                {'wave_infos', WaveInfos} | NFightArgs]),
%%            NOMarching = marching:fight_result(OMarching, Injured, Dead, []),
%%            case Winner =:= 0 of
%%                true ->
%%                    NUpGoBack = [marching:change_goback(NOMarching, EndPoint) | UpGoBack],
%%                    {Marching, TailOcc, NUpGoBack};
%%                false ->
%%                    {Marching, [NOMarching | TailOcc], UpGoBack}
%%            end;
%%        WebErr ->
%%            zm_log:warn(?MODULE, ?MODULE, 'patrol_fight_occ', "web_error", [{'error', WebErr}, {'point_uid', EndPoint}, {'marching', Marching}, {'omarching', OMarching}]),
%%            {Marching, [OMarching | TailOcc], UpGoBack}
%%    end;
%%patrol_fight_occ(_Src, _Now, _EndPoint, _EndRoleUid, _FightArgs, Marching, [], UpGoBack) ->
%%    {Marching, [], UpGoBack}.

%% ----------------------------------------------------
%% @doc
%%      巡逻队伍打npc
%% @end
%% ----------------------------------------------------
%%patrol_fight_spy_npc(Src, _MEtime, EndPoint, EndRoleUid, _FightArgs, Marching, MapSpyBuild) ->
%%    [FightNpc | _] = fighter:init_npc([marching:get_gid(Marching)]),
%%    NpcState = map_spy:get_build_npc_state(MapSpyBuild),
%%    FightEnemys = get_fight_npc(NpcState),
%%    NFightArgs = [
%%        {'duplicate_sid', fighting:get_fight_scene('monster')},
%%        {'seed', game_lib:get_seed()},
%%        {'fight_role', FightNpc},
%%        {'fight_enemy', FightEnemys}
%%        | FightArgs],
%%    case match:auto_result(Src, EndRoleUid, NFightArgs) of
%%        {Winner, Result} ->
%%            WaveInfos = result:get_waves(Result),
%%            zm_event:notify(Src, 'fight_patrol_spy_npc_report', [
%%                {'time', MEtime},
%%                {'role_uid', EndRoleUid},
%%                {'winner', Winner},
%%                {'wave_infos', WaveInfos} | NFightArgs]),
%%            NNpcState = result:get_enemy_last_hps(Result),
%%            NMapSpyBuild = map_spy:set_build_npc_state(MapSpyBuild, NNpcState),
%%            {Winner =:= 0, Marching, NMapSpyBuild};
%%        WebErr ->
%%            zm_log:warn(?MODULE, ?MODULE, 'patrol_fight_spy_npc', "web_error", [{'error', WebErr}, {'point_uid', EndPoint}, {'marching', Marching}, {'npc_state', NpcState}]),
%%            {false, Marching, MapSpyBuild}
%%    end.

%%    zm_event:notify(Src, 'fight_null_report', [
%%        {'role_uid', EndRoleUid},
%%        {'point_int', EndPoint},
%%        {'time', marching:get_etime(Marching)},
%%        {'r_type', ?REPORT_NULL_SPY_DEF},
%%        {'id', point_lib:xyz2view(marching:get_s_point(Marching))}]),
%%    {true, Marching, MapSpyBuild}.

%% ----------------------------------------------------
%% @doc
%%      驻防友军战斗后阵型等数据修改
%% @end
%% ----------------------------------------------------
update_occ_garray(Src, Winner, OMarching, EndPoint, EndRoleUid, [{_, {DeadNum, Injured, GarrayList}} | _], EnemyAddFeatsList, FightTime) ->
    {ORoleUid, OGId} = marching:get_roleuid_gid(OMarching),
    {_, FQueue, GarrayInjured, _AutoAddSoldier, _DeductSosldierNum} =
        fighting:update_garray_after_fight(Src, GarrayList, {ORoleUid, OGId}),%修改队伍信息
    set_front_lib:send_map_result(Src, EndRoleUid, {FightTime, EndPoint, ?ROLE, ?MAP_SPY, Winner, 0, ORoleUid, 1, 0}),
    set_front_lib:send_map_result(Src, ORoleUid, {FightTime, EndPoint, ?ROLE, ?MAP_SPY, Winner, OGId, {FQueue, DeadNum, Injured, GarrayInjured}, 2, 0}),
    %%死亡数和受伤数累计
    [Feats | TailEnemyAddFeatsList] = EnemyAddFeatsList,
    OAddFeats = role_db:award_feats(Src, ORoleUid, Feats),
    NOMarching = marching:fight_result(OMarching, Injured, DeadNum, [{'feats', OAddFeats}]),
    AddFeats = role_db:award_feats(Src, EndRoleUid, lists:sum(TailEnemyAddFeatsList)),
    {AddFeats, OAddFeats, NOMarching}.


%% ----------------------------------------------------
%% @doc
%%      获取npc
%% @end
%% ----------------------------------------------------
%%get_fight_npc({}) ->
%%    {_, NpcGarraySid} = zm_config:get('map_spy_info', 'spy_occ_npc_garray'),
%%    fighter:init_npc([NpcGarraySid]);
%%get_fight_npc({Len, LastHp}) ->
%%    {_, NpcGarraySid} = zm_config:get('map_spy_info', 'spy_occ_npc_garray'),
%%    boss_fight:init_fight_npc([NpcGarraySid], 0, 0, {Len, LastHp}, []).