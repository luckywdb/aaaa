-module(drama_port).

%%%=======================STATEMENT====================
-description("drama_port").
-copyright('youkia,www.youkia.net').
-author("zyc,zhouyucheng@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    get_drama/5,
    set_drama/5,
    get_newbie_guide/5,
    set_newbie_guide/5,
    get_award/5,
    get_fight_info/5,
    setting/5,
    set_data/5
]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================
%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%      获取剧情记录
%% @end
%% ----------------------------------------------------
get_drama(_, _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    Res = drama_db:get_info(Src, RoleUid, drama),
    {'ok', [], Info, [{'msg', Res}]}.

%% ----------------------------------------------------
%% @doc
%%      设置剧情记录
%% @end
%% ----------------------------------------------------
set_drama(_, _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    Save = z_lib:get_value(Msg, "save", none),
    Res = drama_db:set_info(Src, RoleUid, Save, drama),
    {'ok', [], Info, [{'msg', Res}]}.

%% ----------------------------------------------------
%% @doc
%%      获取新手引导
%% @end
%% ----------------------------------------------------
get_newbie_guide(_, _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    Res = drama_db:get_info(Src, RoleUid, new_bie),
    {'ok', [], Info, [{'msg', Res}]}.

%% ----------------------------------------------------
%% @doc
%%      设置新手引导
%% @end
%% ----------------------------------------------------
set_newbie_guide(_, _Session, Attr, Info, Msg) ->
    %%因为新手引导很多前台断线重连问题,故新增方法修改
    case role_lib:get_uid_none(Attr) of
        "no_role_uid" ->
            {'ok', [], Info, [{'msg', "no_role_uid"}]};
        RoleUid ->
            Src = z_lib:get_value(Info, src, none),
            Save = z_lib:get_value(Msg, "save", none),
            Res = drama_db:set_info(Src, RoleUid, Save, new_bie),
            zm_event:notify(Src, 'record_guide', [{'role_uid', RoleUid}, {'guide_sid', Save}]),%bi记录新手引导
            {'ok', [], Info, [{'msg', Res}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      新手奖励, 只得到一次
%% @end
%% ----------------------------------------------------
get_award(_, _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    Country = role_lib:get_country(Attr),
    Func = fun(_, Drama) ->
        case drama_db:get_val(award, Drama) of
            0 ->
                NewDrama = drama_db:set_val(award, Drama, 1),
                {ok, {ok, drama_db:get_award(Country)}, NewDrama};
            _ ->
                {ok, {error, drama_db:get_award(Country)}}
        end
    end,
    case z_db_lib:update(game_lib:get_table(Src, drama), RoleUid, drama_db:date_init(), Func, none) of
        {ok, Award} ->
            AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, Award),
            %% BI
            zm_event:notify(Src, 'bi_drama_award', [{'role_uid', RoleUid}, {'award', AwardLog}]),
            {'ok', [], Info, [{'msg', AwardLog}]};
        {error, Award} ->
            CardStorage = storage_db:get_storage(card, Src, RoleUid),
            [{prop, {Sid, _}} | _] = Award,%%TODO 处理卡死,写死
            F = fun(A, _, Prop) ->
                case prop_kit_lib:get_prop_sid(Prop) =:= Sid of
                    true ->
                        {'break', prop_kit_lib:get_prop_uid(Prop)};
                    false ->
                        {ok, A}
                end
            end,
            CardUid = z_lib:tuple_foreach(CardStorage, F, 0),
            AwardLog = {{card, {{Sid, CardUid, 1}}}},
            {'ok', [], Info, [{'msg', AwardLog}]}
    end.


%% ----------------------------------------------------
%% @doc
%%      新手引导, fight
%% @end
%% ----------------------------------------------------
get_fight_info(_, _Session, _Attr, Info, _Msg) ->
    {_, FightInfo} = zm_config:get('drama', guide_fight),
    DuplicateSid = z_lib:get_value(FightInfo, 'duplicate_sid', 0),
    EnemyNpcArray = z_lib:get_value(FightInfo, 'enemy_npc_array', []),
    RoleNpcArray = z_lib:get_value(FightInfo, 'role_npc_array', []),
    FightType = match_lib:get_fight_type(?MODULE),
    EnemyBattleField = fighter:init_npc(EnemyNpcArray),
    [RoleBattleField | _] = fighter:init_npc(RoleNpcArray),
    RoleBattleField1 = fighter:set_camp(RoleBattleField, 0),
    Res = {
        {seed, game_lib:get_seed()},
        {auto, 0},
        {fight_role, RoleBattleField1},
        {fight_enemy, EnemyBattleField},
        {fight_type, FightType},
        {duplicate_sid, DuplicateSid}
    },
    {'ok', [], Info, [{'msg', Res}]}.

%% ----------------------------------------------------
%% @doc
%%      系统设置  (set_type)
%% @end
%% ----------------------------------------------------
setting(_, _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    SetKey = z_lib:get_value(Msg, "set_key", 0),
    SetValue = z_lib:get_value(Msg, "set_value", 0),
    case valid_lib:check_valib([{'exist', SetKey, [1]}, {'ge', SetValue, 0}]) of %目前只有设置后台推送,类型=1
        true ->
            Fun = fun(_, Setting) ->
                {'ok', "ok", lists:keystore(SetKey, 1, Setting, {SetKey, SetValue})}
            end,
            Reply = z_db_lib:update(game_lib:get_table(Src, 'setting'), RoleUid, [], Fun, []),
            {'ok', [], Info, [{'msg', Reply}]};
        false ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      前台自己设置数据
%% @end
%% ----------------------------------------------------
set_data(_, _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    Data = z_lib:get_value(Msg, "data", 0),
    TFun = fun(_, TimeSet1) ->
        {'ok', 'ok', lists:keystore('data', 1, TimeSet1, {'data', Data})}
    end,
    Reply = z_db_lib:update(game_lib:get_table(Src, 'times_set'), RoleUid, times_set_lib:roleuid_key_init(), TFun, []),
    {'ok', [], Info, [{'msg', Reply}]}.

%%%===================LOCAL FUNCTIONS==================
