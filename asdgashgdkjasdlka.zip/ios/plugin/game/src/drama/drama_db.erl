-module(drama_db).

%%%=======================STATEMENT====================
-description("drama_db").
-copyright('youkia,www.youkia.net').
-author("zyc,zhouyucheng@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    get_info/3,
    set_info/4,
    get_award/1,
    date_init/0,
    get_val/2,
    set_val/3,
    get_setting/2,
    chk_push_setting/3
]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
-type drama() :: {list(), tuple(), integer()}.
-type type() :: drama | new_bie | award.

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%       得到数据, 根据type
%% @end
%% ----------------------------------------------------
-spec get_info(Src, RoleUid, Type) -> string() | tuple() when
    Src :: atom(),
    RoleUid :: integer(),
    Type :: atom().
get_info(Src, RoleUid, Type) ->
    Res = z_db_lib:get(game_lib:get_table(Src, drama), RoleUid, date_init()),
    get_val(Type, Res).

%% ----------------------------------------------------
%% @doc
%%       设置数据, 根据type
%% @end
%% ----------------------------------------------------
-spec set_info(Src, RoleUid, Save, Type) -> string() when
    Src :: atom(),
    RoleUid :: integer(),
    Save :: any(),
    Type :: atom().
set_info(_Src, _RoleUid, none, _Type) -> "input_error";
set_info(Src, RoleUid, Save, Type) ->
    Func = fun(_, Drama) ->
        NewDrama = set_val(Type, Drama, Save),
        {ok, "ok", NewDrama}

    end,
    z_db_lib:update(game_lib:get_table(Src, drama), RoleUid, date_init(), Func, none).

%% ----------------------------------------------------
%% @doc
%%       得到新手引导奖励武将
%% @end
%% ----------------------------------------------------
-spec get_award(integer()) -> list().
get_award(Country) ->
    {_, Award} = zm_config:get(drama, {award, Country}),
    Award.
%% ----------------------------------------------------
%% @doc
%%       初始化数据结构
%% @end
%% ----------------------------------------------------
-spec date_init() -> {[], {}, 0}.
date_init() ->
    {[], {}, 0}.
%% ----------------------------------------------------
%% @doc
%%       根据类型, 得到drama数据
%% @end
%% ----------------------------------------------------
-spec get_val(Type, Drama) -> tuple() | integer() when
    Type :: type(),
    Drama :: drama().
get_val(drama, {Val, _, _}) -> list_to_tuple(Val);
get_val(new_bie, {_, Val, _}) -> Val;
get_val(award, {_, _, Val}) -> Val.

%% ----------------------------------------------------
%% @doc
%%       根据类型, 设置drama数据
%% @end
%% ----------------------------------------------------
-spec set_val(Type, Drama, Val) -> drama() when
    Type :: type(),
    Drama :: drama(),
    Val :: string() | integer().
set_val(drama, {Old, V2, V3}, Val) ->
    MsgValue = [list_to_integer(V) || V <- string:tokens(Val, ",")],
    {lists:usort(MsgValue ++ Old), V2, V3};
set_val(new_bie, {V1, _, V3}, Val) -> {V1, {Val}, V3};
set_val(award, {V1, V2, _}, Val) -> {V1, V2, Val}.

%% ----------------------------------------------------
%% @doc
%%     获取玩家系统设置.
%% @end
%% ----------------------------------------------------
get_setting(Src, RoleUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'setting'), RoleUid, [{1, 16#ffff}]).%推送默认全推送

%% ----------------------------------------------------
%% @doc
%%     检测是否进行推送
%% @end
%% ----------------------------------------------------
chk_push_setting(Src, RoleUid, PType) ->
    Setting = get_setting(Src, RoleUid),
    PushSet = z_lib:get_value(Setting, 1, 16#ffff),%推送的 set_key=1
    (PushSet bsr (PType - 1)) band 1 =:= 1.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
