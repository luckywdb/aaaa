-module(card).

%%%=======================STATEMENT====================
-description("武将").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_name/1, get_country/1, get_type/1, get_exp/1, get_overflow_exp/1, get_quality/1, get_star/1,
    get_skill_sid/1, get_skill_lv/1, get_skills/1, get_fetter/1, get_soldiers_type/1, get_soldiers_num/1, get_growth_govern/1,
    get_growth_force/1, get_growth_brains/1, get_growth_soldiers_num/1, get_state/1, get_star_grid/1, get_info/1, get_level/1,
    get_govern/1, get_force/1, get_brains/1, get_attack/1, get_defence/1, get_polity/1, get_charm/1]).
-export([set_exp/2, set_overflow_exp/2, set_star/2, set_state/2, set_star_grid/2, set_info/2]).
-export([reset/1, get_base_attrs/1, get_star_attrs/1, get_grow_soldier/1]).
-export([set_new_star/2, get_new_star/1, get_mount/1, set_mount/2]).

-export_type([card/0]).
%%%=======================INCLUDE======================

%%%=======================RECORD======================
%% 武将结构 ,技能直接根据星级读取配置信息
-record(card, {
    record_type :: atom(),%卡牌结构类型
    name :: string(),%名字
    country :: integer(),%武将所属国家,对应role.hrl中的魏=1,蜀=2,吴=3,群雄=4
    type :: integer(),%卡牌主属性(智力武将=1,武力武将=2,统率=3)
    exp = 0 :: integer(),%经验
    overflow_exp = 0 :: integer(),%溢出经验,,--废弃
    quality :: integer(),%品质
    star = 0 :: integer(),%阶 ---  以前为星级， 改名为阶了，新增了星级
    new_star = 0 :: integer(),%星级
    skill :: [{integer(), integer()}],%技能=[星等级,{sid,技能等级},星等级,{sid,技能等级}](使用game_lib:level_value())
    fetter :: [integer()],%武将装备羁绊
    soldiers_type :: integer(),%所带兵种(盾兵=1,枪兵=2,骑兵=3,弓兵=4),士兵武器类型与这个相同
    soldiers_num :: integer(),%初始带兵数
    growth_govern :: integer(),%统率成长
    growth_force :: integer(),%武力成长
    growth_brains :: integer(),%智力成长
    growth_soldiers_num :: integer(),%带兵数成长
    state = 0 :: integer(),%状态 0:闲置,>大于0时候直接使用所在阵型id表示上阵
    star_grid = [] :: [integer()],%星格
    govern = 0 :: integer(), %基础统率
    force = 0 :: integer(),  %基础武力
    brains = 0 :: integer(), %基础智力
    attack = 0 :: float(), %基础攻击
    defence = 0 :: float(),%基础防御
    polity = 0 :: integer(), %基础政治
    charm = 0 :: integer(),%基础魅力
    growth_polity = 0 :: integer(),%政治成长
    growth_charm = 0 :: integer(),%魅力成长
    info = [] :: list()  %扩展
}).

%%%=======================DEFINE=======================

%%%=======================TYPE=========================
-type card() :: #card{}.

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      获取名字
%% @end
%% ----------------------------------------------------
-spec get_name(card()) -> string().
get_name(#card{name = Value}) -> game_lib:get_language_package(Value).
%% ----------------------------------------------------
%% @doc
%%      获取国家
%% @end
%% ----------------------------------------------------
-spec get_country(card()) -> integer().
get_country(#card{country = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      获取类型
%% @end
%% ----------------------------------------------------
-spec get_type(card()) -> integer().
get_type(#card{type = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      获取经验
%% @end
%% ----------------------------------------------------
-spec get_exp(card()) -> integer().
get_exp(#card{exp = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      获取溢出经验
%% @end
%% ----------------------------------------------------
-spec get_overflow_exp(card()) -> integer().
get_overflow_exp(#card{overflow_exp = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      获取品质
%% @end
%% ----------------------------------------------------
-spec get_quality(card()) -> integer().
get_quality(#card{quality = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      获取星级
%% @end
%% ----------------------------------------------------
-spec get_star(card()) -> integer().
get_star(#card{star = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      获取技能sid
%% @end
%% ----------------------------------------------------
-spec get_skill_sid(card()) -> integer().
get_skill_sid(#card{skill = Skills, new_star = NewStar}) ->
    case game_lib:level_value(NewStar, Skills) of
        Tuple when is_tuple(Tuple) ->
            element(1, Tuple);
        _ ->
            0
    end.
%% ----------------------------------------------------
%% @doc
%%      获取技能对应等级
%% @end
%% ----------------------------------------------------
-spec get_skill_lv(card()) -> integer().
get_skill_lv(#card{skill = Skills, new_star = NewStar}) ->
    case game_lib:level_value(NewStar, Skills) of
        Tuple when is_tuple(Tuple) ->
            element(2, Tuple);
        _ ->
            0
    end.
%% ----------------------------------------------------
%% @doc
%%      获取技能
%% @end
%% ----------------------------------------------------
-spec get_skills(card()) -> [{integer(), integer()}].
get_skills(#card{skill = Skills}) -> Skills.
%% ----------------------------------------------------
%% @doc
%%      获取武将装备羁绊
%% @end
%% ----------------------------------------------------
-spec get_fetter(card()) -> [integer()].
get_fetter(#card{fetter = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      获取所带兵种
%% @end
%% ----------------------------------------------------
-spec get_soldiers_type(card()) -> integer().
get_soldiers_type(#card{soldiers_type = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      初始带兵数
%% @end
%% ----------------------------------------------------
-spec get_soldiers_num(card()) -> integer().
get_soldiers_num(#card{soldiers_num = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      统率成长
%% @end
%% ----------------------------------------------------
-spec get_growth_govern(card()) -> integer().
get_growth_govern(#card{growth_govern = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      武力成长
%% @end
%% ----------------------------------------------------
-spec get_growth_force(card()) -> integer().
get_growth_force(#card{growth_force = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      智力成长
%% @end
%% ----------------------------------------------------
-spec get_growth_brains(card()) -> integer().
get_growth_brains(#card{growth_brains = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      带兵数成长
%% @end
%% ----------------------------------------------------
-spec get_growth_soldiers_num(card()) -> integer().
get_growth_soldiers_num(#card{growth_soldiers_num = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      获取状态(0空闲,其他就是阵型id)
%% @end
%% ----------------------------------------------------
-spec get_state(card()) -> integer().
get_state(#card{state = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      获取已激活星格star_grid
%% @end
%% ----------------------------------------------------
-spec get_star_grid(card()) -> [integer()].
get_star_grid(#card{star_grid = Value}) -> Value.

%% ----------------------------------------------------
%% @doc
%%      统率
%% @end
%% ----------------------------------------------------
-spec get_govern(card()) -> integer().
get_govern(#card{govern = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      武力
%% @end
%% ----------------------------------------------------
-spec get_force(card()) -> integer().
get_force(#card{force = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      智力
%% @end
%% ----------------------------------------------------
-spec get_brains(card()) -> integer().
get_brains(#card{brains = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      攻击
%% @end
%% ----------------------------------------------------
-spec get_attack(card()) -> float().
get_attack(#card{attack = Value}) -> Value.
%% ----------------------------------------------------
%% @doc
%%      防御
%% @end
%% ----------------------------------------------------
-spec get_defence(card()) -> float().
get_defence(#card{defence = Value}) -> Value.

%% ----------------------------------------------------
%% @doc
%%      政治(配置属性扩大了10000倍)
%% @end
%% ----------------------------------------------------
-spec get_polity(card()) -> integer().
get_polity(Card) ->
    NewCard = card:get_base_attrs(Card), %需要计算成长值
    NewCard#card.polity div 10000.

%% ----------------------------------------------------
%% @doc
%%      魅力(配置属性扩大了10000倍)
%% @end
%% ----------------------------------------------------
-spec get_charm(card()) -> integer().
get_charm(Card) ->
    NewCard = card:get_base_attrs(Card), %需要计算成长值
    NewCard#card.charm div 10000.

%% ----------------------------------------------------
%% @doc
%%      获取信息
%% @end
%% ----------------------------------------------------
-spec get_info(card()) -> list().
get_info(#card{info = Info}) -> Info.
%% ----------------------------------------------------
%% @doc
%%      获取等级(任务需要)
%% @end
%% ----------------------------------------------------
-spec get_level(card()) -> integer().
get_level(Card) ->
    game_lib:get_level('card', Card).

%% ----------------------------------------------------
%% @doc
%%      设置经验
%% @end
%% ----------------------------------------------------
-spec set_exp(Card :: card(), Value :: integer()) -> card().
set_exp(Card, Value) -> Card#card{exp = Value}.

%% ----------------------------------------------------
%% @doc
%%      设置溢出经验
%% @end
%% ----------------------------------------------------
-spec set_overflow_exp(Card :: card(), Value :: integer()) -> card().
set_overflow_exp(Card, Value) -> Card#card{overflow_exp = Value}.

%% ----------------------------------------------------
%% @doc
%%      设置星级
%% @end
%% ----------------------------------------------------
-spec set_star(Card :: card(), Value :: integer()) -> card().
set_star(Card, Value) -> Card#card{star = Value}.

%% ----------------------------------------------------
%% @doc
%%      设置状态
%% @end
%% ----------------------------------------------------
-spec set_state(Card :: card(), Value :: integer()) -> card().
set_state(Card, Value) -> Card#card{state = Value}.

%% ----------------------------------------------------
%% @doc
%%      设置已激活星格
%% @end
%% ----------------------------------------------------
-spec set_star_grid(Card :: card(), Value :: [integer()]) -> card().
set_star_grid(Card, Value) -> Card#card{star_grid = Value}.

%% ----------------------------------------------------
%% @doc
%%      设置扩展信息
%% @end
%% ----------------------------------------------------
-spec set_info(Card :: card(), Value :: list()) -> card().
set_info(Card, Value) -> Card#card{info = Value}.

%% ----------------------------------------------------
%% @doc
%%      重置
%% @end
%% ----------------------------------------------------
-spec reset(Card :: card()) -> card().
reset(Card) -> Card#card{exp = 0, overflow_exp = 0, star = 0, new_star = 0, state = 0, star_grid = []}.

%% ----------------------------------------------------
%% @doc
%%      根据基础属性计算出1,2级基础值. (基础属性+等级成长属性)
%%      一级属性：攻击、防御
%%      二级属性：统御、武力、智力
%%      武将自身一级属性：由武将自身二级属性直接计算得到的一级属性
%%      武将自身二级属性：武将1级属性（直接配置）+由等级成长带来的属性
%% @end
%% ----------------------------------------------------
-spec get_base_attrs(Card :: card()) -> card().
get_base_attrs(Card) ->
    #card{
        govern = BaseGovern,
        force = BaseForce,
        brains = BaseBrains,
        attack = BaseAttack,
        defence = BaseDefence,
        polity = Polity,
        charm = Charm,

        growth_brains = GBrains,
        growth_force = GForce,
        growth_govern = GGovern,
        growth_polity = GPolity,
        growth_charm = GCharm} = Card,
    Lv = get_level(Card) - 1,
    Govern = BaseGovern + GGovern * Lv,
    Brains = BaseBrains + GBrains * Lv,
    Force = BaseForce + GForce * Lv,
    NPolity = Polity + GPolity * Lv,
    NCharm = Charm + GCharm * Lv,

    Coefficient = element(2, zm_config:get('fight_info', 'coefficient')),
    C11 = z_lib:get_value(Coefficient, 'c11', 10000),
    C12 = z_lib:get_value(Coefficient, 'c12', 1200),

    Attack = BaseAttack + C11 * Force / 10000,
    Defence = BaseDefence + C12 * Force / 10000,

    Card#card{
        govern = Govern,
        force = Force,
        brains = Brains,
        attack = Attack,
        defence = Defence,
        polity = NPolity,
        charm = NCharm
    }.

%% ----------------------------------------------------
%% @doc
%%      武将 成长带兵量属性+当前星级,激活的星格属性(修改后需要修改gm_attr_db.erl里面属性)
%% @end
%% ----------------------------------------------------
-spec get_star_attrs(card()) -> [fighter:attr()].
get_star_attrs(Card) ->
    #card{
        star = Star,
        new_star = NewStar,
        type = Type,
        quality = Quality,
        star_grid = StarGrid,
        growth_soldiers_num = GSNum} = Card,
    Lv = get_level(Card) - 1,
    SoldierNum = GSNum * Lv,

    %所有武将共有的基础属性
    {_, AllBase} = zm_config:get('card_info', 'all_base_attr'),
    Attrs = if
        SoldierNum > 0 ->
            [{{'integer', 'soldier_num'}, SoldierNum} | AllBase];
        true ->
            AllBase
    end,

    %阶属性----旧的星级
    {_, _, _, _, StarAttr} = zm_config:get('card_up_star_attr', {Quality, Type, Star}),
    %新星级属性
    NewStarAttr =
        if
            NewStar =:= 0 ->
                [];
            true ->
                element(3, zm_config:get('card_up_new_star_attr', {Quality, Type, NewStar}))
        end,
    %星格属性
    F = fun(Args, Sid) ->
        {_, _, GridAttr} = zm_config:get('card_star_grid', Sid),
        {'ok', GridAttr ++ Args}
    end,
    GridAttrs = z_lib:foreach(F, [], StarGrid),
    attrs:merge_attrs(StarAttr ++ NewStarAttr ++ Attrs ++ GridAttrs, []).

%% ----------------------------------------------------
%% @doc
%%      武将升级,升星增加的带兵数
%% @end
%% ----------------------------------------------------
-spec get_grow_soldier(Card :: card()) -> integer().
get_grow_soldier(Card) ->
    Attrs = get_star_attrs(Card),
    z_lib:get_value(Attrs, {'integer', 'soldier_num'}, 0).

%% ----------------------------------------------------
%% @doc
%%      设置星级--- 新星级
%% @end
%% ----------------------------------------------------
-spec set_new_star(Card :: card(), Value :: integer()) -> card().
set_new_star(Card, Value) -> Card#card{new_star = Value}.

%% ----------------------------------------------------
%% @doc
%%      获取星级--- 新星级
%% @end
%% ----------------------------------------------------
-spec get_new_star(Card :: card()) -> integer().
get_new_star(#card{new_star = Value}) -> Value.


%% ----------------------------------------------------
%% @doc
%%      获取坐骑
%% @end
%% ----------------------------------------------------
-spec get_mount(Card :: card()) -> integer().
get_mount(#card{info = Value}) ->
    case lists:keyfind(mount, 1, Value) of
        {_, V} -> V;
        _ -> 0
    end.

%% ----------------------------------------------------
%% @doc
%%      设置武将武将坐骑
%% @end
%% ----------------------------------------------------
-spec set_mount(Card :: card(), Value :: integer()) -> card().
set_mount(Card, Value) ->
    Info = get_info(Card),
    NInfo = lists:keystore(mount, 1, Info, {mount, Value}),
    Card#card{info = NInfo}.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
