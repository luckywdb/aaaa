-module(card_event).

%%%=======================STATEMENT====================
-description("card_event").
-copyright('youkia,www.youkia.net').
-author("yhr,yuanhairong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
%%%=======================EXPORT========================
-export([notify/4]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================


%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      羁绊属性
%% @end
%%-------------------------------------------------------------------
notify(_A, Src, card_fetter, Args) ->
    {_, AllSidList} = lists:keyfind('all_sid_list', 1, Args),
%%    {_, AddSidList} = lists:keyfind('add_sid_list', 1, Args),
    {_, RoleUid} = lists:keyfind('roleuid', 1, Args),
    TableName = game_lib:get_table(Src, 'card_fetter'),
    F = fun(_, FetterInfo) ->
        K = fun(Sid, Acc0) ->
            CardProp = prop_kit_lib:get_prop_record(prop_kit_lib:get_prop(Sid)),
            FetterList1 = card:get_fetter(CardProp),
            case FetterList1 -- FetterInfo of
                [] ->
                    Acc0;
                FetterList2 ->
                    lists:foldl(fun(FetterId, Acc2) ->
                        {_, CfgList, _, _} = zm_config:get(fetter_attr, FetterId),
                        {_, FetterCardCfg} = lists:keyfind(card, 1, CfgList),
                        case FetterCardCfg -- AllSidList =:= [] of
                            true ->
                                [FetterId | Acc2];
                            false ->
                                Acc2
                        end
                    end, Acc0, FetterList2)
            end
        end,
        List3 = lists:foldl(K, [], AllSidList),
        {ok, List3, List3 ++ FetterInfo}
    end,
    List = z_db_lib:update(TableName, RoleUid, [], F, []),
    case List =:= [] of
        false ->
            set_front_lib:send_fetter(Src, RoleUid, List);
        true ->
            ok
    end.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
