-module(card_lib).

%%%=======================STATEMENT====================
-description("武将工具").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([add_exp/4, add_exp_byindex/5, add_exp_byindex/6, check_consume_card/2, check/3, consume/3]).
-export([off_equipments/4, get_up_star_consume/2, get_max_soldiers_num/3]).
-export([off_treasures/4]).
-export([get_up_newstar_consume/2]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      武将涨经验(武将所在包裹index未知)
%% @end
%% ----------------------------------------------------
-spec add_exp(CardStorage, CardUid, AddExp, MaxLevel) -> tuple() when
    CardStorage :: tuple(),
    CardUid :: integer()|[integer()],
    AddExp :: integer(),
    MaxLevel :: integer().
add_exp(CardStorage, CardUid, AddExp, MaxLevel) when is_integer(CardUid) ->
    add_exp(CardStorage, [CardUid], AddExp, MaxLevel);
add_exp(CardStorage, CardUids, AddExp, MaxLevel) when is_list(CardUids) ->
    Infos = storage_lib:find_by_uid(CardStorage, CardUids),
    Fun = fun({OldNewProps, Storage}, {Index, CardProp}) ->
        {NCardProp, NStorage} = add_exp_byindex(Storage, CardProp, Index, AddExp, MaxLevel),
        {ok, {[{CardProp, NCardProp} | OldNewProps], NStorage}}
    end,
    z_lib:foreach(Fun, {[], CardStorage}, Infos).

%% ----------------------------------------------------
%% @doc
%%      武将涨经验(武将所在包裹index已知)
%% @end
%% ----------------------------------------------------
-spec add_exp_byindex(CardStorage, CardProp, Index, AddExp, MaxLevel, Bool) -> {tuple(), tuple()} when
    CardStorage :: tuple(),
    CardProp :: tuple(),
    Index :: integer(),
    AddExp :: integer(),
    MaxLevel :: integer(),
    Bool :: boolean().%是否可以溢出经验，只有吃经验书时可以溢出经验
add_exp_byindex(CardStorage, CardProp, Index, AddExp, MaxLevl) ->
    add_exp_byindex(CardStorage, CardProp, Index, AddExp, MaxLevl, false).
add_exp_byindex(CardStorage, CardProp, Index, AddExp, MaxLevel, Bool) ->
    Card = prop_kit_lib:get_prop_record(CardProp),
    NCard = add_card_exp(Card, AddExp, MaxLevel, Bool),
    NProp = prop_kit_lib:set_prop_record(CardProp, NCard),
    {NProp, storage_lib:update_by_index(CardStorage, Index, NProp)}.

%% ----------------------------------------------------
%% @doc
%%      检测武将卡牌是否可被消耗,且检测消耗sid是否与升星sid一致
%% @end
%% ----------------------------------------------------
-spec check_consume_card(list(), integer()) -> true|string().
check_consume_card([], _) ->
    true;
check_consume_card(IndexCardProps, CardSid) ->
    {_, Conditions} = zm_config:get('card_info', 'card_consume'),
    Fun = fun(_, Uid) when is_integer(Uid) ->
        {break, "uid_error"};
        (Bool, {_Index, Prop}) ->
            Card = prop_kit_lib:get_prop_record(Prop),
            Sid = prop_kit_lib:get_prop_sid(Prop),
            if
                Sid =:= CardSid ->
                    case game_lib:checks({?MODULE, 'check'}, {Card}, 'cards', Conditions) of
                        true ->
                            {ok, Bool};
                        Err ->
                            {break, Err}
                    end;
                true ->
                    {break, "uid_error"}
            end
    end,
    z_lib:foreach(Fun, true, IndexCardProps).

%% ----------------------------------------------------
%% @doc
%%     检测条件
%% @end
%% ----------------------------------------------------
-spec check(tuple(), tuple(), tuple()) -> boolean().
check({_Role, _Card}, {'up_star', Uids, Prop}, {'card', Number}) when Number > 0 ->%升星校验吃的卡数量足够(是否和升星卡一个sid在上层检测卡牌是否可被消耗时候已经检测)
    Bool = lists:member(prop_kit_lib:get_prop_uid(Prop), Uids),
    not (Bool orelse length(Uids) =/= Number);
check({Role, _Card}, {'up_star', _Uids, _Prop}, {'money', Value}) ->%武将旧升阶校验钱是否足够
    role:get_money(Role) >= Value;
check({_Role, Card}, {'up_star', _Uids, _Prop}, {'card_level', Value}) ->%武将旧升阶等级判断是否足够
    game_lib:get_level('card', Card) >= Value;
check({_GoodsStorage, Role}, 'star_grid', {'money', Value}) ->%激活星格校验钱是否足够
    role:get_money(Role) >= Value;
check({GoodsStorage, _Role}, 'star_grid', {'prop', {Sid, Number}}) ->%激活星格校验材料是否足够
    storage_lib:exist_by_sid(GoodsStorage, {Sid, Number});
check({Card}, 'cards', {'card_level', Value}) ->%消耗同名卡牌等级检查
    game_lib:get_level('card', Card) =< Value;
check({Card}, 'cards', {'card_state', Value}) ->%消耗同名卡牌卡牌状态检查,卡牌是否为该状态
    card:get_state(Card) =:= Value;
check({Card}, 'cards', {'card_star', Value}) ->%消耗同名卡牌卡牌阶级检查
    card:get_star(Card) =< Value;
check({Card}, 'cards', {'card_star_grid', Value}) ->%消耗同名卡牌,当前星格个数检查
    length(card:get_star_grid(Card)) =< Value;
check({Card}, 'cards', {'card_new_star', Value}) ->%消耗同名卡牌,当前星级检查
    card:get_new_star(Card) =< Value;
%%check({ResetCards, Rmb}, 'up_star_reset', {'rmb', V}) ->
%%    rmb_lib:get_rmb(Rmb) >= V * length(ResetCards);
%%check(Card, 'up_star_reset_cards', {'card_level', V}) ->
%%    game_lib:get_level('card', Card) >= V;
%%check(Card, 'up_star_reset_cards', {'card_star', V}) ->
%%    card:get_star(Card) >= V;
%%check(Card, 'up_star_reset_cards', {'card_new_star', V}) ->
%%    card:get_new_star(Card) >= V;
check(_, _, _) ->
    false.

%% ----------------------------------------------------
%% @doc
%%     消耗
%% @end
%% ----------------------------------------------------
-spec consume(tuple(), tuple(), tuple()) -> {'none'|tuple(), tuple()}.
consume({CardStorage, Role}, {'up_star', Uids}, {'card', _Number}) ->%升星扣副卡
    {BiCs, CardStorage1} = storage_lib:deduct_by_uid(CardStorage, Uids),% 扣除卡牌
    {BiCs, {CardStorage1, Role}};
consume({CardStorage, Role}, {'up_star', _Uids}, {'money', Value}) ->%升星扣钱
    {BiCs, Role1} = role_lib:deduct_money(Role, Value),
    {BiCs, {CardStorage, Role1}};
consume({GoodsStorage, Role}, 'star_grid', {'money', Value}) ->%激活星格扣钱
    {BiCs, Role1} = role_lib:deduct_money(Role, Value),
    {BiCs, {GoodsStorage, Role1}};
consume({GoodsStorage, Role}, 'star_grid', {'prop', {Sid, Number}}) ->%激活星格扣材料
    {BiCs, GoodsStorage1} = storage_lib:deduct_by_sid(GoodsStorage, {Sid, Number}),% 扣除材料
    {BiCs, {GoodsStorage1, Role}};
consume(Table, _, _) ->%外部条件不需处理
    {'none', Table}.

%% ----------------------------------------------------
%% @doc
%%      武将脱装备
%% @end
%% ----------------------------------------------------
-spec off_equipments(Src, RoleUid, EquipmentStorage, CardPutProps) -> {tuple(), tuple(), list()} when
    Src :: atom(),
    RoleUid :: integer(),
    EquipmentStorage :: tuple(),
    CardPutProps :: tuple()|list().
off_equipments(Src, RoleUid, EquipmentStorage, CardPutProps) when is_tuple(CardPutProps) ->
    off_equipments(Src, RoleUid, EquipmentStorage, [CardPutProps]);
off_equipments(Src, RoleUid, EquipmentStorage, CardPutProps) when is_list(CardPutProps) ->
    Fun = fun(A, 'none') ->
        {ok, A};
        (A, CardPutProp) ->
            Equipments = card_put_prop:get_equipments(CardPutProp),
            {'ok', [E || E <- tuple_to_list(Equipments), E =/= 0] ++ A}
    end,
    L1 = z_lib:foreach(Fun, [], CardPutProps),
    equipment_lib:off_equipment(Src, RoleUid, EquipmentStorage, L1).

%% ----------------------------------------------------
%% @doc
%%      武将脱宝物
%% @end
%% ----------------------------------------------------
-spec off_treasures(Src, RoleUid, TreasureStorage, CardPutProps) -> {tuple(), tuple(), list()} when
    Src :: atom(),
    RoleUid :: integer(),
    TreasureStorage :: tuple(),
    CardPutProps :: tuple()|list().
off_treasures(Src, RoleUid, TreasureStorage, CardPutProps) when is_tuple(CardPutProps) ->
    off_treasures(Src, RoleUid, TreasureStorage, [CardPutProps]);
off_treasures(Src, RoleUid, TreasureStorage, CardPutProps) when is_list(CardPutProps) ->
    Fun = fun(A, 'none') ->
        {ok, A};
        (A, CardPutProp) ->
            case card_put_prop:get_treasure(CardPutProp) of
                0 ->
                    {'ok', A};
                T ->
                    {'ok', [T | A]}
            end
    end,
    L1 = z_lib:foreach(Fun, [], CardPutProps),
    treasure_lib:off_treasure(Src, RoleUid, TreasureStorage, L1).

%% ----------------------------------------------------
%% @doc
%%      获取武将升星、星格所有消耗
%% @end
%% ----------------------------------------------------
-spec get_up_star_consume(Sid, Card) -> {list(), list()} when
    Sid :: integer(),
    Card :: card:card().
get_up_star_consume(Sid, Card) ->
    Quality = card:get_quality(Card),
    Type = card:get_type(Card),
    Star = card:get_star(Card),
    SStar = card:get_star(prop_kit_lib:get_prop_record(prop_kit_lib:get_prop(Sid))),
    GCons = z_lib:foreach(fun(Args, Gid) ->
        {_, Cons, _} = zm_config:get('card_star_grid', Gid),
        {'ok', awarder_game:merger(Args, Cons)}
    end, [], card:get_star_grid(Card)),

    if
        Star > SStar ->
            Fun = fun(A, {'card', Num}) ->
                {'ok', [{'prop', {Sid, Num}} | A]};
                (A, V) ->
                    {'ok', [V | A]}
            end,
            lists:foldl(fun(S, {GAcc, SAcc}) ->
                {_, Gids, _, Cs, _} = zm_config:get('card_up_star_attr', {Quality, Type, S + 1}),
                NGAcc = z_lib:foreach(fun(Args, Gid) ->
                    {_, Cons, _} = zm_config:get('card_star_grid', Gid),
                    {'ok', awarder_game:merger(Args, Cons)}
                end, GAcc, Gids),
                NSAcc = awarder_game:merger(z_lib:foreach(Fun, [], Cs), SAcc),
                {NGAcc, NSAcc}
            end, {GCons, []}, lists:seq(SStar, Star - 1));
        true ->
            {GCons, []}
    end.

%% ----------------------------------------------------
%% @doc
%%      获取武将最大带兵数 (初始带兵数+升级升星+成长带兵数+科技天赋增加带兵数+内政增加) %%羁绊/装备属性等不支持增加带兵数 后台配置都是扩大10000倍
%% @end
%% ----------------------------------------------------
-spec get_max_soldiers_num(Card, Study, OtherAttrs) -> integer() when
    Card :: card:card(),
    Study :: list(),
    OtherAttrs :: [fighter:attr()].
get_max_soldiers_num(Card, Study, OtherAttrs) ->
    StudyAdd = role_addition:get_soldier_num(Study),
    InitNum = card:get_soldiers_num(Card),
    GrowNum = card:get_grow_soldier(Card),
    OtherAdd = z_lib:get_value(OtherAttrs, {'integer', 'soldier_num'}, 0),
    (StudyAdd + InitNum + GrowNum + OtherAdd) div 10000.

%% ----------------------------------------------------
%% @doc
%%      获取武将升星的消耗（新的星级）
%% @end
%% ----------------------------------------------------
-spec get_up_newstar_consume(Sid, Card) -> list() when
    Sid :: integer(),
    Card :: card:card().
get_up_newstar_consume(Sid, Card) ->
    Quality = card:get_quality(Card),
    Type = card:get_type(Card),
    Star = card:get_new_star(Card),
    SStar = card:get_new_star(prop_kit_lib:get_prop_record(prop_kit_lib:get_prop(Sid))),
    if
        Star > SStar ->
            Fun = fun(A, {'card', Num}) ->
                {'ok', [{'prop', {Sid, Num}} | A]};
                (A, V) ->
                    {'ok', [V | A]}
            end,
            lists:foldl(fun(S, Acc) ->
                {_, Cs, _} = zm_config:get('card_up_new_star_attr', {Quality, Type, S + 1}),
                awarder_game:merger(z_lib:foreach(Fun, [], Cs), Acc)
            end, [], lists:seq(SStar, Star - 1));
        true ->
            []
    end.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%     武将增加经验(不需要溢出经验)
%% @end
%% ----------------------------------------------------
add_card_exp(Card, Exp, _MaxLevel, _Bool) ->
%%TODO 以下是武将在未满级之前会有等级上限，并且有溢出经验；由于策划需求现屏蔽此功能
%%    NowExp = card:get_exp(Card),
%%    MaxExp = game_lib:get_exp_by_level('card', Card, MaxLevel),
%%    if
%%        NowExp >= MaxExp ->
%%            Card;
%%        true ->
%%            NewExp = NowExp + Exp,
%%            if
%%                NewExp > MaxExp andalso Bool -> %%经验溢出
%%                    card:set_overflow_exp(card:set_exp(Card, MaxExp), NewExp - MaxExp);
%%                true ->
%%                    card:set_overflow_exp(card:set_exp(Card, min(NewExp, MaxExp)), 0)
%%            end
%%    end.
    MaxExp = game_lib:get_max_exp('card', Card),
    NowExp = card:get_exp(Card),
    if
        NowExp >= MaxExp ->
            Card;
        true ->
            NewExp = min(NowExp + Exp, MaxExp),
            card:set_exp(Card, NewExp)
    end.
