-module(card_port).

%%%=======================STATEMENT====================
-description("武将端口").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_card_record/5, get_treasure_record/5, up_exp/5, up_star/5, star_grid/5]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%    获取名将录
%% @end
%%-------------------------------------------------------------------
get_card_record(_, _, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    {_, CardSidList} = card_db:get_card_record(Src, RoleUid),
    {'ok', [], Info, [{'msg', list_to_tuple(CardSidList)}]}.

%%-------------------------------------------------------------------
%% @doc
%%    获取百宝鉴
%% @end
%%-------------------------------------------------------------------
get_treasure_record(_, _, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    {_, TreasureSidList} = card_db:get_treasure_record(Src, RoleUid),
    {'ok', [], Info, [{'msg', list_to_tuple(TreasureSidList)}]}.
%% ----------------------------------------------------
%% @doc  
%%     武将,吃经验丹
%% @end
%% ----------------------------------------------------
up_exp([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    CardUid = erlang:list_to_integer(z_lib:get_value(Msg, "card_uid", "0")),
    Props = game_lib:parse_props(z_lib:get_value(Msg, "props", "")),
    Bool = erlang:length(Props) < 1 orelse CardUid < 1,
    if
        Bool ->
            {'ok', [], Info, [{'msg', "input_error"}]};
        true ->
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'card', RoleUid}, {'goods', RoleUid}]),
            RoleShow = role_db:get_role_show(Src, RoleUid),
            case z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, CardUid, Props, RoleShow}, TableKeys) of
                {'ok', CardSid, OldCard, NewCard, BiCs} ->
                    %% 记录武将卡牌升级日志信息
                    zm_log:info(Src, ?MODULE, 'up_exp', "card_up_exp", [{'roleuid', RoleUid},
                        {'old_exp', card:get_exp(OldCard)}, {'new_exp', card:get_exp(NewCard)},
                        {'consume', BiCs}, {'sid', CardSid}, {'props', Props}]),
                    %% 卡牌升级事件
                    OldLevel = game_lib:get_level('card', OldCard),
                    NewLevel = game_lib:get_level('card', NewCard),
                    if
                        NewLevel =:= OldLevel ->
                            'ok';
                        true ->
                            GId = card:get_state(NewCard),
                            if
                                GId > 0 ->
                                    Country = role_lib:get_country(Attr),
                                    zm_event:notify(Src, {'power_change', Country}, [{'uid', RoleUid}, {'gid', GId}, {'country', Country}]);
                                true ->
                                    'ok'
                            end
                    end,
                    %% bi收集
                    zm_event:notify(Src, 'bi_card_up_exp', [{'role_uid', RoleUid},
                        {'new_card', NewCard}, {'consume', BiCs}, {'sid', CardSid}, {'card_uid', CardUid}]),
                    {'ok', [], Info, [{'msg', "ok"}]};
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end
    end.

%% ----------------------------------------------------
%% @doc
%%     武将升星
%% @end
%% ----------------------------------------------------
up_star([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    CardUid = erlang:list_to_integer(z_lib:get_value(Msg, "card_uid", "0")),
    Type = z_db_lib:get_value(Msg, "type", 1),
    CheckVaild = valid_lib:check_valib([{'gt', CardUid, 1}, {'range', Type, {1, 2}}]),

    if
        CheckVaild ->
            %升星消耗的同名卡牌的uids
            Uids = lists:usort([erlang:list_to_integer(X) || X <- string:tokens(z_lib:get_value(Msg, "uids", ""), ",")]),
%%            PoliticalUids = building_db:get_political_carduids(Src, RoleUid),
%%            case Uids -- PoliticalUids of
%%                Uids ->
%%                    UnRCardUids = building_db:get_all_dispatch_carduids(Src, RoleUid),
%%                    case Uids -- UnRCardUids of
%%                        Uids ->
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'role', RoleUid}, {'card', RoleUid}, {'equipment', RoleUid},
                {'castle', RoleUid}, {'political', RoleUid, []}, {'treasure', RoleUid, {}}, {'card_put_treasure', RoleUid, []} |
                [{'card_put_prop', Uid, 'none'} || Uid <- Uids]]),
            case z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, CardUid, Uids, Type}, TableKeys) of
                {'ok', CardSid, OldCard, NewCard, Consumes, EquipmentLog, TreasLogs, Awards, _GIds} ->
                    Country = role_lib:get_country(Attr),
                    AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, Awards),
                    {OStar, NStar} =
                        if
                            Type =:= 1 ->
                                {card:get_star(OldCard), card:get_star(NewCard)};
                            true ->
                                OS = card:get_new_star(OldCard),
                                NS = card:get_new_star(NewCard),
                                {_, StarCfg} = zm_config:get('broadcast_config', 'card_new_star'),
                                if
                                    NS >= StarCfg ->
                                        %%TODO 广播
                                        zm_event:notify(Src, 'broadcast', {'card_new_star', [{'role_uid', RoleUid}, {'new_star', NS}, {'sid', CardSid}]});
                                    true ->
                                        ok
                                end,
                                {OS, NS}
                        end,
                    %% 记录卡牌升阶日志信息
                    zm_log:info(Src, ?MODULE, 'up_star', "card_up_star", [{'roleuid', RoleUid}, {'card_uid', CardUid}, {'type', Type}, {'old_star', OStar},
                        {'new_star', NStar}, {'consume', Consumes}, {'award', AwardLog}]),
                    %% 卡牌升阶事件
                    GId = card:get_state(NewCard),
                    zm_event:notify(Src, 'bi_card_star_up', [{'role_uid', RoleUid}, {'type', Type}, {'new_card', NewCard},
                        {'consume', Consumes}, {'sid', CardSid}, {'card_uid', CardUid}, {'gid', GId}, {'award', AwardLog}]),
                    if
                        GId > 0 ->
                            zm_event:notify(Src, {'power_change', Country}, [{'uid', RoleUid}, {'gid', GId}, {'country', Country}]);
                        true ->
                            'ok'
                    end,
                    {'ok', [], Info, [{'msg', {EquipmentLog, TreasLogs, AwardLog}}]};
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end;
%%                        _ ->
%%                            {'ok', [], Info, [{'msg', "card_dispatching"}]}
%%                    end;
%%                _ ->
%%                    {'ok', [], Info, [{'msg', "card_politicaling"}]}
%%    end
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     武将激活星格(一键激活星格)
%% @end
%% ----------------------------------------------------
star_grid([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    CardUid = erlang:list_to_integer(z_lib:get_value(Msg, "card_uid", "0")),
    GridSids = lists:usort([erlang:list_to_integer(X) || X <- string:tokens(z_lib:get_value(Msg, "grid_sid", ""), ",")]),
    if
        CardUid < 1 orelse GridSids =:= [] ->
            {'ok', [], Info, [{'msg', "input_error"}]};
        true ->
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'role', RoleUid}, {'card', RoleUid, {}}, {'material', RoleUid, {}}]),
            case z_db_lib:handle(TableName, {M, F, A}, {CardUid, GridSids}, TableKeys) of
                {'ok', CardSid, OldCard, NewCard, Consumes} ->
                    %% 记录卡牌升阶日志信息
                    zm_log:info(Src, ?MODULE, 'star_grid', "card_star_grid", [{'roleuid', RoleUid}, {'card_uid', CardUid},
                        {'old_grid', game_lib:to_string2(card:get_star_grid(OldCard))}, {'new_grid', game_lib:to_string2(card:get_star_grid(NewCard))},
                        {'consume', Consumes}, {'grid_sids', game_lib:to_string2(GridSids)}]),
                    %% 卡牌激活星格事件
                    GId = card:get_state(NewCard),
                    zm_event:notify(Src, 'bi_card_star_grid', [{'role_uid', RoleUid}, {'new_card', NewCard},
                        {'consume', Consumes}, {'sid', CardSid}, {'card_uid', CardUid}, {'gid', GId}]),
                    if
                        GId > 0 ->
                            Country = role_lib:get_country(Attr),
                            zm_event:notify(Src, {'power_change', Country}, [{'uid', RoleUid}, {'gid', GId}, {'country', Country}]);
                        true ->
                            'ok'
                    end,
                    {'ok', [], Info, [{'msg', "ok"}]};
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end
    end.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
