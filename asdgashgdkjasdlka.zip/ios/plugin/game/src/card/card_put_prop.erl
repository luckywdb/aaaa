-module(card_put_prop).

%%%=======================STATEMENT====================
-description("武将着装信息").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([init/0, get_equipments/1, set_equipments/2]).
-export([set_treasure/2, get_treasure/1]).

-export_type([card_put_prop/0]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
%uid=card_uid
-record(card_put_prop, {
    equipments = {0, 0, 0, 0},%装备,武器=1,头盔=2,战甲=3,靴子=4
    treasure = 0 %宝物sid, 宝物uid, 宝物等级
}).

%%%=======================TYPE=========================
-type card_put_prop() :: #card_put_prop{}.


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%     初始化武将着装信息
%% @end
%% ----------------------------------------------------
-spec init() -> card_put_prop().
init() ->
    #card_put_prop{}.

%% ----------------------------------------------------
%% @doc
%%     获取穿戴装备信息
%% @end
%% ----------------------------------------------------
-spec get_equipments(card_put_prop()) -> tuple().
get_equipments(#card_put_prop{equipments = Value}) -> Value.

%% ----------------------------------------------------
%% @doc
%%     获取宝物信息
%% @end
%% ----------------------------------------------------
-spec get_treasure(card_put_prop()) -> tuple()|0.
get_treasure(#card_put_prop{treasure = Value}) -> Value.

%% ----------------------------------------------------
%% @doc
%%     设置穿戴装备信息
%% @end
%% ----------------------------------------------------
-spec set_equipments(card_put_prop(), Value :: tuple()) -> card_put_prop().
set_equipments(CardPutProp, Value) -> CardPutProp#card_put_prop{equipments = Value}.

%% ----------------------------------------------------
%% @doc
%%     设置穿戴宝物信息
%% @end
%% ----------------------------------------------------
-spec set_treasure(card_put_prop(), Value :: integer()|tuple()) -> card_put_prop().
set_treasure(CardPutProp, Value) -> CardPutProp#card_put_prop{treasure = Value}.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
