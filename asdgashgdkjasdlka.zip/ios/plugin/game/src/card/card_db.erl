-module(card_db).

%%%=======================STATEMENT====================
-description("武将db操作").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([up_exp/3, up_star/3, star_grid/3]).
-export([add_card/4, get_card_record_attrs/2]).
-export([get_card_record/2, get_treasure_record/2]).
-export([get_card_fetter/2]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%      武将升级（吃经验丹）
%% @end
%% ----------------------------------------------------
-spec up_exp(_A, {_Src, _RoleUid, CardUid, Props, RoleShow}, List) -> string()|tuple() when
    CardUid :: integer(),
    Props :: [{integer(), integer()}],
    RoleShow :: tuple(),
    List :: [{integer(), tuple()}].
up_exp(_A, {_Src, _RoleUid, CardUid, Props, RoleShow}, [{Index1, CardStorage}, {Index2, GoodsStorage}]) ->
    case storage_lib:find_by_uid(CardStorage, CardUid) of
        CardUid ->
            throw("no_card");
        {Index, CardProp} ->
            Bool = storage_lib:exist_by_sid(GoodsStorage, Props),
            if
                Bool ->
                    Card = prop_kit_lib:get_prop_record(CardProp),
                    MaxExp = game_lib:get_max_exp('card', Card),
                    CardExp = card:get_exp(Card),
                    case CardExp >= MaxExp of
                        true ->
                            throw("card_level_max");
                        false ->
                            RoleLv = role_show:get_level(RoleShow),
                            AddExp = lists:sum([add_value_goods:get_value(Sid) * Num || {Sid, Num} <- Props]),
                            {NCardProp, NCardStorage} = card_lib:add_exp_byindex(CardStorage, CardProp, Index, AddExp, RoleLv, true),
                            {BiCs, NGoodsStorage} = storage_lib:deduct_by_sid(GoodsStorage, Props),
                            {'ok', {'ok', prop_kit_lib:get_prop_sid(CardProp), Card, prop_kit_lib:get_prop_record(NCardProp), BiCs},
                                [{Index1, NCardStorage}, {Index2, NGoodsStorage}]}
                    end;
                true ->
                    throw("goods_not_enough")
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      武将升星
%% @end
%% ----------------------------------------------------
-spec up_star(_A, {Src, RoleUid, CardUid, Uids, Type}, List) -> string()|tuple() when
    Src :: atom(),
    RoleUid :: integer(),
    CardUid :: integer(),
    Uids :: [integer()],
    Type :: integer(),
    List :: [{integer(), role:role()|tuple()}].
up_star(_A, {Src, RoleUid, CardUid, Uids, Type}, [{Index1, Role}, {Index2, CardStorage}, {Index3, EquipmentStorage},
    {Index4, Castle}, {Index5, Political}, {Index7, TreasureStorage}, {Index8, PutSids} | T]) ->
    case storage_lib:find_by_uid(CardStorage, CardUid) of
        CardUid ->
            throw("no_card");
        {Index, Prop} ->
            Card = prop_kit_lib:get_prop_record(Prop),
            Sid = prop_kit_lib:get_prop_sid(Prop),
            Condtions = if
                Type =:= 1 -> %Type= 1 升阶（原来的升星）
                    case zm_config:get('card_up_star_attr', {card:get_quality(Card), card:get_type(Card), card:get_star(Card) + 1}) of
                        none ->
                            throw("card_star_max");
                        {_, GridList, Condtions1, Condtions2, _} ->
                            case GridList =:= card:get_star_grid(Card) of
                                true ->
                                    Condtions1 ++ Condtions2;
                                false ->
                                    %%12月25日热更,修改武将类型后,导致玩家旧类型激活星格,新类型也激活星格
                                    case GridList -- card:get_star_grid(Card) of
                                        [] ->
                                            Condtions1 ++ Condtions2;
                                        _ ->
                                            throw("grid_not_full")
                                    end
                            end
                    end;
                true ->  %Type = 2 新的升星
                    case zm_config:get('card_up_new_star_attr', {card:get_quality(Card), card:get_type(Card), card:get_new_star(Card) + 1}) of
                        none ->
                            throw("card_new_star_max");
                        {_, Condtions1, _} ->
                            Condtions1
                    end
            end,
            IndexProps = storage_lib:find_by_uid(CardStorage, Uids),
            CheckConsume = card_lib:check_consume_card(IndexProps, Sid),% 检测同名卡牌是否可被消耗
            if
                CheckConsume ->
                    case game_lib:checks({'card_lib', 'check'}, {Role, Card}, {'up_star', Uids, Prop}, Condtions) of
                        true ->
%%                            ResetConditions = element(2, zm_config:get('card_info', 'up_star_reset_card')),
%%                            {ResetCards, Awards} = z_lib:foreach(fun({Acc1, Acc2}, {_, CProp}) ->
%%                                C = prop_kit_lib:get_prop_record(CProp),
%%                                case lists:any(
%%                                    fun(Condition) ->
%%                                        game_lib:checks({'card_lib', 'check'}, C, 'up_star_reset_cards', [Condition]) =:= true
%%                                    end, ResetConditions) of
%%                                    true ->
%%                                        {ok, {[C | Acc1], awarder_game:merger(resolve_lib:reset_card(CProp), Acc2)}};
%%                                    _ ->
%%                                        {ok, {Acc1, Acc2}}
%%                                end
%%                            end, {[], []}, IndexProps),
%%                            Conditions = element(2, zm_config:get('resolve_info', 'card_reset_conditions')),
%%                            Bool = game_lib:checks({'resolve_lib', 'check'}, {ResetCards, Rmb}, 'reset', Conditions),
%%                            if
%%                                Bool ->
%%                                    {Cs, {_, NRmb}} = game_lib:consumes({'resolve_lib', 'consume'}, {ResetCards, Rmb}, 'reset', Conditions),
                            Building = castle:get_building(Castle),
                            NBuilding = z_lib:tuple_foreach(list_to_tuple(Building), fun(Acc, _, {_, _, _, CUid} = Bd) ->
                                case lists:member(CUid, Uids) of
                                    true ->
                                        [setelement(4, Bd, 0) | Acc];
                                    false ->
                                        [Bd | Acc]
                                end
                            end, []),
                            NCastle = castle:set_building(Castle, NBuilding),
                            {GIds, NPolitical} = z_lib:tuple_foreach(list_to_tuple(Political), fun({GAcc, Acc}, _, {_, CUid, _} = P) ->
                                case lists:member(CUid, Uids) of
                                    true ->
                                        {_, CProp} = storage_lib:find_by_uid(CardStorage, CUid),
                                        Gid = card:get_state(prop_kit_lib:get_prop_record(CProp)),
                                        {[Gid | lists:delete(Gid, GAcc)], Acc};
                                    false ->
                                        {GAcc, [P | Acc]}
                                end
                            end, {[], []}),
                            NCard = if
                                Type =:= 1 ->  %Type = 1 升阶（原来的升星）
                                    card:set_star_grid(card:set_star(Card, card:get_star(Card) + 1), []);
                                true ->%Type = 2 新的升星
                                    card:set_new_star(Card, card:get_new_star(Card) + 1)
                            end,
                            NProp = prop_kit_lib:set_prop_record(Prop, NCard),
                            CardStorage1 = storage_lib:update_by_index(CardStorage, Index, NProp),
                            {Consumes, {CardStorage2, Role1}} =
                                game_lib:consumes({'card_lib', 'consume'}, {CardStorage1, Role},
                                    {'up_star', Uids}, Condtions),
                            {Indexs1, CardPutProps} = lists:unzip(T),% 装备返还信息
                            %% 返还装备
                            {NEquipmentStorage, EquipmentLog, OverFlowProps} =
                                card_lib:off_equipments(Src, RoleUid, EquipmentStorage, CardPutProps),
                            {NTreasureStorage, TreasLogs, TOverFlowProps} =
                                card_lib:off_treasures(Src, RoleUid, TreasureStorage, CardPutProps),
                            %%将脱下来的宝物从上阵SidList 中删除
                            NPutSids = lists:foldl(fun(TreasFormat, R) ->
                                TreasSid = element(1, TreasFormat),
                                lists:delete(TreasSid, R)
                            end, PutSids, tuple_to_list(TreasLogs)),
                            if
                                length(OverFlowProps) > 0 ->
                                    throw("storage_full");
                                length(TOverFlowProps) > 0 ->
                                    throw("treasure_storage_full");
                                true ->
                                    {ok, {ok, Sid, Card, NCard, Consumes, EquipmentLog, TreasLogs, [], GIds}, [{Index1, Role1},
                                        {Index2, CardStorage2}, {Index3, NEquipmentStorage}, {Index4, NCastle},
                                        {Index5, NPolitical}, {Index7, NTreasureStorage}, {Index8, NPutSids} |
                                        [{CardPutPropIndex, 'delete'} || CardPutPropIndex <- Indexs1]]}
                            end;
%%                                true ->
%%                                    throw(Bool)
%%                    end;
                        Err ->
                            throw(Err)
                    end;
                true ->
                    throw(CheckConsume)
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      武将激活星格
%% @end
%% ----------------------------------------------------
-spec star_grid(_A, {CardUid, GridSids}, List) -> string()|tuple() when
    CardUid :: integer(),
    GridSids :: [integer()],
    List :: [{integer(), role:role()|tuple()}].
star_grid(_A, {CardUid, GridSids}, [{Index1, Role}, {Index2, CardStorage}, {Index3, MaterialStorage}]) ->
    case storage_lib:find_by_uid(CardStorage, CardUid) of
        CardUid ->
            throw("no_card");
        {Index, Prop} ->
            Card = prop_kit_lib:get_prop_record(Prop),
            Sid = prop_kit_lib:get_prop_sid(Prop),
            CardGrid = card:get_star_grid(Card),
            ActivedGrids = GridSids -- CardGrid,
            if
                length(ActivedGrids) =:= length(GridSids) ->
                    case zm_config:get('card_up_star_attr', {card:get_quality(Card), card:get_type(Card), card:get_star(Card) + 1}) of
                        'none' ->
                            throw("card_star_max");
                        {_, GridList, _, _, _} ->
                            case GridSids--GridList of
                                [] ->
                                    Consume = z_lib:foreach(fun(Args, GridSid) ->
                                        {_, Cons, _} = zm_config:get('card_star_grid', GridSid),
                                        {'ok', awarder_game:merger(Args, Cons)}
                                    end, [], GridSids),
                                    case game_lib:checks({'card_lib', 'check'}, {MaterialStorage, Role}, 'star_grid', Consume) of
                                        true ->
                                            NCard = card:set_star_grid(Card, lists:usort(GridSids ++ CardGrid)),
                                            NProp = prop_kit_lib:set_prop_record(Prop, NCard),
                                            CardStorage1 = storage_lib:update_by_index(CardStorage, Index, NProp),
                                            {Cs, {MaterialStorage1, Role1}} =
                                                game_lib:consumes({'card_lib', 'consume'}, {MaterialStorage, Role},
                                                    'star_grid', Consume),
                                            {ok, {ok, Sid, Card, NCard, Cs}, [{Index1, Role1},
                                                {Index2, CardStorage1}, {Index3, MaterialStorage1}]};
                                        Err ->
                                            throw(Err)
                                    end;
                                _ ->
                                    throw("grid_not_this_star")
                            end
                    end;
                true ->
                    throw("grid_is_activited")
            end
    end.

%%-------------------------------------------------------------------
%% @doc
%%      获得物件之后增加名将录、百宝鉴、激活羁绊
%% @end
%%-------------------------------------------------------------------
-spec add_card(atom(), integer(), atom(), [prop_kit_lib:prop()]) -> ok.
add_card(Src, RoleUid, Type, AddProps) when Type =:= 'card';Type =:= 'treasure' ->
    TableName = game_lib:get_table(Src, 'card_record'),
    F = fun(_, {{OCardLen, OCardSidList}, {OTreasureLen, OTreasureSidList}}) ->
        OSidList = if
            Type =:= 'card' ->
                OCardSidList;
            true ->
                OTreasureSidList
        end,
        AddSidList =
            z_lib:foreach(fun(Res, Prop) ->%%遍历AddProps,找到以前没有的Sid
                Sid = prop_kit_lib:get_prop_sid(Prop),
                case not lists:member(Sid, Res) andalso not lists:member(Sid, OSidList) of
                    true ->
                        {ok, [Sid | Res]};
                    false ->
                        {ok, Res}
                end
            end, [], AddProps),

        case AddSidList =:= [] of
            true ->
                {ok, {ok, OCardLen, OCardLen}};
            false ->
                NSidList = AddSidList ++ OSidList,
                % 计算羁绊
                NLen = length(NSidList),
                if
                    Type =:= 'card' ->
                        zm_event:notify(Src, card_fetter, [{'all_sid_list', NSidList}, {'roleuid', RoleUid}, {'add_sid_list', AddSidList}]),
                        {ok, {ok, OCardLen, NLen}, {{NLen, NSidList}, {OTreasureLen, OTreasureSidList}}};
                    true ->
                        {ok, {ok, OTreasureLen, NLen}, {{OCardLen, OCardSidList}, {NLen, NSidList}}}
                end
        end
    end,
    {ok, Len1, Len2} = z_db_lib:update(TableName, RoleUid, {{0, []}, {0, []}}, F, []),
    if
        Type =:= 'card' andalso Len2 > Len1 ->
            CardRecordAttrs = zm_config:get('card_record_attr'),
            AttrNum1 = get_card_record_num_attr(Len1, CardRecordAttrs),
            AttrNum2 = get_card_record_num_attr(Len2, CardRecordAttrs),
            case AttrNum2 > AttrNum1 of
                true ->
                    set_front_lib:send_card_record_num(Src, RoleUid, Len2);
                false ->
                    ok
            end;
        true ->
            ok
    end;
add_card(_Src, _RoleUid, _Type, _AddProps) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      获取名将录增加的属性
%% @end
%%-------------------------------------------------------------------
get_card_record_attrs(Src, RoleUid) ->
    {{CardSidNum, _}, _} = z_db_lib:get(game_lib:get_table(Src, 'card_record'), RoleUid, {{0, []}, {0, []}}),
    CardRecordAttrs = zm_config:get('card_record_attr'),
    z_lib:foreach(fun(R, {Num, Attrs}) ->
        case CardSidNum >= Num of
            true ->
                {ok, attrs:merge_attrs(Attrs, R)};
            false ->
                {'break', R}
        end
    end, [], CardRecordAttrs).

%%-------------------------------------------------------------------
%% @doc
%%      获取羁绊列表
%% @end
%%-------------------------------------------------------------------
get_card_fetter(Src, RoleUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'card_fetter'), RoleUid, []).

%%-------------------------------------------------------------------
%% @doc
%%      获取名将录
%% @end
%%-------------------------------------------------------------------
get_card_record(Src, RoleUid) ->
    element(1, z_db_lib:get(game_lib:get_table(Src, 'card_record'), RoleUid, {{0, []}, {0, []}})).

%%-------------------------------------------------------------------
%% @doc
%%      获取百宝鉴
%% @end
%%-------------------------------------------------------------------
get_treasure_record(Src, RoleUid) ->
    element(2, z_db_lib:get(game_lib:get_table(Src, 'card_record'), RoleUid, {{0, []}, {0, []}})).

%%%===================LOCAL FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%      根据名将个数获取激活名将属性个数
%% @end
%%-------------------------------------------------------------------
get_card_record_num_attr(SidNum, CardRecordAttrs) ->
    z_lib:foreach(fun(R, {Num, _}) ->
        case SidNum >= Num of
            true ->
                {ok, R + 1};
            false ->
                {break, R}
        end
    end, 0, CardRecordAttrs).