-module(corps).

%%%=======================STATEMENT====================
-description("corps").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    get_uid/1,
    get_name/1,
    get_banner/1,
    get_exp/1,
    get_level/1,
    get_create_uid/1,
    get_owner/1,
    get_vice_owner_list/1,
    get_create_time/1,
    get_state/1,
    get_liveness/1,
    get_mem_num/1,
    get_country/1,
    get_conditon/1
]).
-export([
    set_banner/2,
    set_exp/2,
    set_owner/2,
    set_vice_owner_list/2,
    set_state/2,
    set_liveness/2,
    set_mem_num/2,
    set_name/2,
    set_conditon/2
]).
-export([init/5]).

%%%=======================INCLUDE======================
-include("../include/corps.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(corps, {
    uid :: integer(),
    name :: string(),%%名字
    banner :: integer(),%%军团旗帜
    country :: integer(),%%所属国家
    exp = 0 :: integer(),%%军团经验
    create_uid :: integer(), %%创建者
    owner :: integer(),%%军团长
    vice_owner_list = [] :: [integer()], %%副军团长列表
    create_time :: integer(),%%创建时间
    state = 0 :: integer(),%%军团状态
    liveness = {0, 0} :: {integer(), integer()},%%活跃度 {day_of_year,活跃值}
    mem_num = 1 :: integer(), %%成员数
    conditon = 'none' :: none | corps_condition:corps_condition() %%各种军团条件
}).
%%%=======================TYPE=========================
-type corps() :: #corps{}.
-type state() :: 0 | 1 | 2 | 3.
-type position() :: 0 .. 7.
-type requests() :: [{integer(), integer()}].
-type invites() :: [{integer(), integer()}].
-type corps_gift() :: [{integer(), integer(), integer()}].

-export_type([corps/0, state/0, position/0, requests/0, invites/0, corps_gift/0]).
%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        军团uid
%% @end
%% ----------------------------------------------------
-spec get_uid(corps()) -> integer().
get_uid(#corps{uid = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%        军团名字
%% @end
%% ----------------------------------------------------
-spec get_name(corps()) -> string().
get_name(#corps{name = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%        军团旗帜
%% @end
%% ----------------------------------------------------
-spec get_banner(corps()) -> integer().
get_banner(#corps{banner = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%        军团所属国家
%% @end
%% ----------------------------------------------------
-spec get_country(corps()) -> integer().
get_country(#corps{country = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%        军团经验
%% @end
%% ----------------------------------------------------
-spec get_exp(corps()) -> integer().
get_exp(#corps{exp = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%        军团等级
%% @end
%% ----------------------------------------------------
-spec get_level(corps()) -> integer().
get_level(Corps) ->
    game_lib:get_level('corps', Corps).

%% ----------------------------------------------------
%% @doc
%%        军团创建者uid
%% @end
%% ----------------------------------------------------
-spec get_create_uid(corps()) -> integer().
get_create_uid(#corps{create_uid = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%        军团创建时间
%% @end
%% ----------------------------------------------------
-spec get_create_time(corps()) -> integer().
get_create_time(#corps{create_time = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%        军团状态
%% @end
%% ----------------------------------------------------
-spec get_state(corps()) -> state().
get_state(#corps{state = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%        军团团长uid
%% @end
%% ----------------------------------------------------
-spec get_owner(corps()) -> integer().
get_owner(#corps{owner = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%        军团副团长uid列表
%% @end
%% ----------------------------------------------------
-spec get_vice_owner_list(corps()) -> [integer()].
get_vice_owner_list(#corps{vice_owner_list = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%        军团副团长uid列表
%% @end
%% ----------------------------------------------------
-spec get_liveness(corps()) -> {integer(), integer()}.
get_liveness(#corps{liveness = Value}) ->
    Value.
%% ----------------------------------------------------
%% @doc
%%        军团成员数
%% @end
%% ----------------------------------------------------
-spec get_mem_num(corps()) -> integer().
get_mem_num(#corps{mem_num = Value}) ->
    Value.

%%-------------------------------------------------------------------
%% @doc
%%      军团条件
%% @end
%%-------------------------------------------------------------------
get_conditon(#corps{conditon = V}) ->
    case V =:= 'none' of
        true ->
            corps_condition:init();
        false ->
            V
    end.
%% ----------------------------------------------------
%% @doc
%%        军团旗帜
%% @end
%% ----------------------------------------------------
-spec set_banner(corps(), integer()) -> corps().
set_banner(Corps, Value) ->
    Corps#corps{banner = Value}.

%% ----------------------------------------------------
%% @doc
%%        军团经验
%% @end
%% ----------------------------------------------------
-spec set_exp(corps(), integer()) -> corps().
set_exp(Corps, Value) ->
    Corps#corps{exp = Value}.

%% ----------------------------------------------------
%% @doc
%%        军团状态
%% @end
%% ----------------------------------------------------
-spec set_state(corps(), state()) -> corps().
set_state(Corps, Value) ->
    Corps#corps{state = Value}.

%% ----------------------------------------------------
%% @doc
%%        军团团长uid
%% @end
%% ----------------------------------------------------
-spec set_owner(corps(), integer()) -> corps().
set_owner(Corps, Value) ->
    Corps#corps{owner = Value}.

%% ----------------------------------------------------
%% @doc
%%        军团副团长uid列表
%% @end
%% ----------------------------------------------------
-spec set_vice_owner_list(corps(), [integer()]) -> corps().
set_vice_owner_list(Corps, Value) ->
    Corps#corps{vice_owner_list = Value}.

%% ----------------------------------------------------
%% @doc
%%        活跃度
%% @end
%% ----------------------------------------------------
-spec set_liveness(corps(), {integer(), integer()}) -> corps().
set_liveness(Corps, Value) ->
    Corps#corps{liveness = Value}.


%% ----------------------------------------------------
%% @doc
%%        军团成员数
%% @end
%% ----------------------------------------------------
-spec set_mem_num(corps(), integer()) -> corps().
set_mem_num(Corps, Value) ->
    Corps#corps{mem_num = Value}.
%% ----------------------------------------------------
%% @doc
%%        军团名字
%% @end
%% ----------------------------------------------------
set_name(Corps, Value) ->
    Corps#corps{name = Value}.

%%-------------------------------------------------------------------
%% @doc
%%    设置条件
%% @end
%%-------------------------------------------------------------------
set_conditon(Corps, Value) ->
    Corps#corps{conditon = Value}.

%% ----------------------------------------------------
%% @doc
%%        军团初始化
%% @end
%% ----------------------------------------------------
-spec init(RoleUid, CorpsUid, CorpsName, Country, Banner) -> Corps when
    RoleUid :: integer(),
    CorpsUid :: integer(),
    CorpsName :: string(),
    Country :: integer(),
    Banner :: integer(),
    Corps :: corps().
init(RoleUid, CorpsUid, CorpsName, Country, Banner) ->
    #corps{uid = CorpsUid, name = CorpsName, create_uid = RoleUid, create_time = time_lib:now_second(),
        banner = Banner, owner = RoleUid, country = Country}.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
