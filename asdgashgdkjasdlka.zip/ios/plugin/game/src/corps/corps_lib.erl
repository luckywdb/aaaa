-module(corps_lib).

%%%=======================STATEMENT====================
-description("corps_lib").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    check_condition/2, check_enter/2, check_enter/3, check_position_limit/2, check/3, consume/3, get_requests/1, get_request_uids/1
]).
-export([get_base_view/3, get_other_view/2, format_recommend_view/2, get_request_view/2, get_request_view/3, get_invite_role_view/2,
    get_role_invite_view/2, format_role_invite_view/2, get_member_view/2,
    get_invite_uids/1, get_invites/1, add_contribute/2, deduct_contribute/2, check_banner/1, check_notice/2]).
-export([get_corps_reminder/3]).
-export([get_notice_time/2]).
-export([check_corps_invite/2]).
-export([refresh_corps_gift_info/1, get_donate_times/2, refresh_position_award_state/1]).
-export([ally_clear_invalid_info/3, ally_format_search_by_name/2, ally_format_send_ally_request/2, ally_format_get_corps_info/4, ally_agree_send/6,
    ally_notice/4, ally_mail/4, ally_delete_repatriate/3, ally_repatriate/3, ally_role_exit_corps/3, ally_format_invites/2]).
%%%=======================INCLUDE======================
-include("../include/corps.hrl").
-include("../include/rank.hrl").
-include("../include/money.hrl").
-include("../include/point.hrl").
%%%=======================DEFINE======================
-define(SKILL_RMB, 4).
%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%        刷新军团赠送信息
%% @end
%% ----------------------------------------------------
-spec refresh_corps_gift_info(corps:corps_gift()|'none') -> {Day, SendNum, GetNum} when
    Day :: integer(),%%军团旗帜
    SendNum :: integer(),%%送出次数
    GetNum :: integer().%%获得次数
refresh_corps_gift_info('none') ->
    Today = time_lib:get_date_by_type('day_of_year'),
    {Today, 0, 0};
refresh_corps_gift_info({Day, SendNum, GetNum}) ->
    Today = time_lib:get_date_by_type('day_of_year'),
    if
        Day =:= Today ->
            {Day, SendNum, GetNum};
        true ->
            {Today, 0, 0}
    end.
%% ----------------------------------------------------
%% @doc  
%%        检验额外条件,退出上一军团时间是否超过24小时,目前是否有军团
%% @end
%% ----------------------------------------------------
-spec check_condition(integer(), role_corps:role_corps()) -> true | string().
check_condition(OnlineTime, RoleCorps) ->
    ExitTime = role_corps:get_exit_time(RoleCorps),
    CorpsUid = role_corps:get_corps_uid(RoleCorps),
    {_, {{OpenTimeDec, Cd1}, Cd2}} = zm_config:get('corps', 'corps_enter_cd'),
    Now = time_lib:now_second(),
    Cd =
        if
            Now - OnlineTime > OpenTimeDec ->
                Cd2;
            true ->
                Cd1
        end,
    case time_lib:now_second() - ExitTime >= Cd of
        true ->
            if
                CorpsUid =:= 0 ->
                    true;
                true ->
                    "corps_was_in"
            end;
        false ->
            "corps_cd_limit"
    end.

%% ----------------------------------------------------
%% @doc
%%        检验加入军团条件(不包括设置的条件)
%% @end
%% ----------------------------------------------------
-spec check_enter(atom(), integer() | role_show:role_show() | 'none') -> true | string().
check_enter(Src, RoleUid) when is_integer(RoleUid) ->
    RoleShow = role_db:get_role_show(Src, RoleUid),
    check_enter(Src, RoleShow);
check_enter(_Src, RoleShow) ->
    {_, Conds} = zm_config:get('corps', 'enter'),
    game_lib:checks({corps_lib, check}, RoleShow, 'enter', Conds).

%%-------------------------------------------------------------------
%% @doc
%%      检验加入军团条件(包括设置的条件)
%% @end
%%-------------------------------------------------------------------
check_enter(Src, RoleUid, Corps) when is_integer(RoleUid) ->
    RoleShow = role_db:get_role_show(Src, RoleUid),
    check_enter(Src, RoleShow, Corps);
check_enter(_Src, RoleShow, Corps) ->
    {_, Conds} = zm_config:get('corps', 'enter'),
    AddConds = corps_condition:get_requst_conditons(corps:get_conditon(Corps)),
    game_lib:checks({corps_lib, check}, RoleShow, 'enter', Conds ++ AddConds).
%% ----------------------------------------------------
%% @doc
%%        检验权限
%% @end
%% ----------------------------------------------------
-spec check_position_limit(atom(), corps:position()) -> true | string().
check_position_limit(Type, Position) ->
    {_, PList} = zm_config:get('corps_position', Type),
    case lists:member(Position, PList) of
        true ->
            true;
        false ->
            "corps_position_limit"
    end.


%% ----------------------------------------------------
%% @doc
%%      得到请求uids(过滤过期)
%% @end
%% ----------------------------------------------------
-spec get_request_uids(corps:requests()) -> [integer()].
get_request_uids(Requests) ->
    NRequests = get_requests(Requests),
    [Uid || {Uid, _} <- NRequests].

%% ----------------------------------------------------
%% @doc
%%      得到请求(过滤过期)
%% @end
%% ----------------------------------------------------
-spec get_requests(corps:requests()) -> corps:requests().
get_requests(Requests) ->
    {_, Timeout} = zm_config:get('corps', 'corps_request_timeout'),
    T = time_lib:now_second() - Timeout,
    [Request || Request <- Requests, element(2, Request) > T].

%% ----------------------------------------------------
%% @doc
%%     检测是否有请求
%% @end
%% ----------------------------------------------------
-spec check_requests(Now :: integer(), List :: [corps:requests()]) -> 0|1.
check_requests(Now, List) ->
    {_, Timeout} = zm_config:get('corps', 'corps_request_timeout'),
    T = Now - Timeout,
    case lists:any(fun({_, Time}) -> Time > T end, List) of
        true ->
            1;
        false ->
            0
    end.

%% ----------------------------------------------------
%% @doc
%%      得到邀请uids(过滤过期)
%% @end
%% ----------------------------------------------------
-spec get_invite_uids(corps:invites()) -> [integer()].
get_invite_uids(Invites) ->
    NInvites = get_invites(Invites),
    [Uid || {Uid, _} <- NInvites].

%% ----------------------------------------------------
%% @doc
%%      得到邀请(过滤过期)
%% @end
%% ----------------------------------------------------
-spec get_invites(corps:invites()) -> corps:invites().
get_invites(Invites) ->
    {_, Timeout} = zm_config:get('corps', 'corps_inivite_timeout'),
    T = time_lib:now_second() - Timeout,
    [Invite || Invite <- Invites, element(2, Invite) > T].

%% ----------------------------------------------------
%% @doc
%%     判断是否有邀请
%% @end
%% ----------------------------------------------------
-spec check_invites(Now :: integer(), RoleCorps :: role_corps:role_corps()) -> 0|1.
check_invites(Now, RoleCorps) ->
    {_, Timeout} = zm_config:get('corps', 'corps_request_timeout'),
    T = Now - Timeout,
    case lists:any(fun({_, Time}) -> Time > T end, role_corps:get_invites(RoleCorps)) of
        true ->
            1;
        false ->
            0
    end.

%% ----------------------------------------------------
%% @doc
%%        增加贡献值
%% @end
%% ----------------------------------------------------
-spec add_contribute(role_corps:role_corps(), integer()) -> {tuple(), role_corps:role_corps()}.
add_contribute(RoleCorps, AddC) when AddC > 0 ->
    {C, List} = role_corps:get_contribute(RoleCorps),
    TimeSec = time_lib:now_second(),
    Day = time_lib:get_date_by_type('day_of_year', TimeSec),
    Week = time_lib:get_date_by_type('week_of_year', TimeSec),
    Fun = fun({Key, V1, _}) when (Key =:= 'day_times' andalso V1 =:= Day) orelse (Key =:= 'week_times' andalso V1 =:= Week) ->
        true;
        ({'total_times', _}) ->
            true;
        (_) ->
            false
    end,
    List1 = lists:filter(Fun, List),
    NList1 = times_set_lib:update(List1, {'day_times', Day, AddC}),
    NList2 = times_set_lib:update(NList1, {'week_times', Week, AddC}),
    NList3 = times_set_lib:update(NList2, {'total_times', AddC}),
    NC = C + AddC,
    {{'contribute', AddC, NC}, role_corps:set_contribute(RoleCorps, {NC, NList3})}.

%%-------------------------------------------------------------------
%% @doc
%%      扣除贡献值
%% @end
%%-------------------------------------------------------------------
-spec deduct_contribute(role_corps:role_corps(), integer()) -> {list(), role_corps:role_corps()} | list().
deduct_contribute(RoleCorps, DeductC) when DeductC > 0 ->
    {C, List} = role_corps:get_contribute(RoleCorps),
    if
        C >= DeductC ->
            NC = C - DeductC,
            {[{'contribute', DeductC, NC}], role_corps:set_contribute(RoleCorps, {NC, List})};
        true ->
            "contribute_not_enough"
    end.

%% ----------------------------------------------------
%% @doc
%%      推荐前段显示
%% @end
%% ----------------------------------------------------
-spec format_recommend_view(_Src, Corps) -> {CorpsUid, CorpsName, CorpsLevel, Banner, MemNum, {RequestFlag, RequestCastleLv, RequestRoleLv}} when
    _Src :: atom(),
    CorpsUid :: integer(),%%军团uid
    Corps :: corps:corps(),%%军团
    CorpsName :: string(),%%军团名字
    CorpsLevel :: integer(),%%军团等级
    Banner :: integer(),%%军团旗帜
    MemNum :: integer(),%%军团成员数
    RequestFlag :: 0|1,%%申请设置
    RequestCastleLv :: integer(),%申请需要大殿等级
    RequestRoleLv :: integer().%申请需要主公等级
format_recommend_view(_Src, Corps) ->
    CorpsUid = corps:get_uid(Corps),
    CorpsName = corps:get_name(Corps),
    CorpsLevel = corps:get_level(Corps),
    Banner = corps:get_banner(Corps),
    MemNum = corps:get_mem_num(Corps),
    CorpsCondition = corps:get_conditon(Corps),
    RequestFlag = corps_condition:get_request_flag(CorpsCondition),
    RequestCastleLv = corps_condition:get_request_castle_lv(CorpsCondition),
    RequestRoleLv = corps_condition:get_request_role_lv(CorpsCondition),
    {CorpsUid, CorpsName, CorpsLevel, Banner, MemNum, {RequestFlag, RequestCastleLv, RequestRoleLv}}.

%% ----------------------------------------------------
%% @doc
%%      推荐前段显示
%% @end
%% ----------------------------------------------------
-spec get_request_view(Src, RoleUid) -> {RoleUid, Name, Level, Point, LoginTime} when
    Src :: atom(),
    RoleUid :: integer(),
    Name :: string(),
    Level :: integer(),
    Point :: integer(),
    LoginTime :: integer().
get_request_view(Src, RoleUid) ->
    User = user_db:get_user(Src, RoleUid),
    LoginTime = guser:get_login_time(User),
    LogoutTime = guser:get_logout_time(User),
    Time = if
        LoginTime > LogoutTime ->
            0;
        true ->
            LogoutTime
    end,
    get_request_view(Src, RoleUid, Time).

-spec get_request_view(Src, RoleUid, Time) -> {RoleUid, Name, Level, Point, LoginTime} when
    Src :: atom(),
    RoleUid :: integer(),
    Time :: integer(),
    Name :: string(),
    Level :: integer(),
    Point :: integer(),
    LoginTime :: integer().
get_request_view(Src, RoleUid, Time) ->
    RoleShow = role_db:get_role_show(Src, RoleUid),
    Name = role_show:get_name(RoleShow),
    Level = role_show:get_level(RoleShow),
    Point = role_show:get_point(RoleShow),
    {RoleUid, Name, Level, point_lib:xyz2view(Point), Time}.
%% ----------------------------------------------------
%% @doc
%%      推荐前段显示
%% @end
%% ----------------------------------------------------
-spec get_member_view(Src, RoleUid) -> {RoleUid, Name, Level, Point, Pos, Contribute, LoginTime, Style} when
    Src :: atom(),
    RoleUid :: integer(),
    Name :: string(),
    Level :: integer(),
    Point :: integer(),
    Pos :: integer(),
    Contribute :: integer(),
    LoginTime :: integer(),
    Style :: integer().
get_member_view(Src, RoleUid) ->
    RoleShow = role_db:get_role_show(Src, RoleUid),
    Name = role_show:get_name(RoleShow),
    Level = role_show:get_level(RoleShow),
    Point = role_show:get_point(RoleShow),
    Style = role_show:get_style(RoleShow),
    Time = case login_db:is_online(Src, RoleUid) =:= 0 of
        true ->
            0;
        false ->
            guser:get_logout_time(user_db:get_user(Src, RoleUid))
    end,
    RoleCorps = corps_db:get_role_corps(Src, RoleUid),
    {C, _List} = role_corps:get_contribute(RoleCorps),
    Pos = role_corps:get_position(RoleCorps),
    {RoleUid, Name, Level, point_lib:xyz2view(Point), Pos, C, Time, Style}.

%% ----------------------------------------------------
%% @doc
%%      推荐前段显示
%% @end
%% ----------------------------------------------------
-spec get_invite_role_view(Src, RoleUid) -> {RoleUid, Name, Level, Point, LoginTime} when
    Src :: atom(),
    RoleUid :: integer(),
    Name :: string(),
    Level :: integer(),
    Point :: integer(),
    LoginTime :: integer().
get_invite_role_view(Src, RoleUid) ->
    RoleShow = role_db:get_role_show(Src, RoleUid),
    Name = role_show:get_name(RoleShow),
    Level = role_show:get_level(RoleShow),
    Point = role_show:get_point(RoleShow),
    User = user_db:get_user(Src, RoleUid),
    LoginTime = guser:get_login_time(User),
    {RoleUid, Name, Level, point_lib:xyz2view(Point), LoginTime}.

%% ----------------------------------------------------
%% @doc
%%      推荐前段显示
%% @end
%% ----------------------------------------------------
-spec get_role_invite_view(Src, CorpsUid) -> {CorpsUid, Name, Level, Banner} when
    Src :: atom(),
    CorpsUid :: integer(),
    Name :: string(),
    Level :: integer(),
    Banner :: integer().
get_role_invite_view(Src, CorpsUid) ->
    Corps = corps_db:get_corps(Src, CorpsUid),
    format_role_invite_view(CorpsUid, Corps).
%% ----------------------------------------------------
%% @doc
%%      推荐前段显示
%% @end
%% ----------------------------------------------------
-spec format_role_invite_view(CorpsUid, Corps) -> {CorpsUid, Name, Level, Banner} when
    CorpsUid :: integer(),
    Corps :: corps:corps(),
    Name :: string(),
    Level :: integer(),
    Banner :: integer().
format_role_invite_view(CorpsUid, Corps) ->
    Name = corps:get_name(Corps),
    Level = corps:get_level(Corps),
    Banner = corps:get_banner(Corps),
    {CorpsUid, Name, Level, Banner}.
%% ----------------------------------------------------
%% @doc
%%      推荐前段显示
%% @end
%% ----------------------------------------------------
-spec get_base_view(_Src, RoleUid, RoleCorps) -> {CorpsName, OwnerUid, OwnerName, CorpsExp, Banner, MemNum, TownNum, PrivateNotice, NPublicNotice, Rank, Pos, State, DonateTimes, Num} | string() when
    _Src :: atom(),
    RoleUid :: integer(), %%玩家uid
    RoleCorps :: role_corps:role_corps(),
    CorpsName :: string(),%%军团名字
    OwnerUid :: integer(),%%军团长uid
    OwnerName :: string(),%%军团长名字
    CorpsExp :: integer(),%%军团经验
    Banner :: integer(),%%军团旗帜
    MemNum :: integer(),%%军团成员数
    TownNum :: integer(), %%军团城池数量
    PrivateNotice :: string(),%%军团公告
    NPublicNotice :: string(),%%军团公告
    Rank :: integer(),%%军团排名
    Pos :: corps:position(),%%个人职位
    State :: corps:state(),%%军团状态
    DonateTimes :: tuple(), %%军团捐献次数{{?MONEY,铜币捐献次数},{?RMB,RMB捐献次数}}
    Num :: integer(). %%当天领取福利次数

get_base_view(Src, RoleUid, RoleCorps) ->
    CorpsUid = role_corps:get_corps_uid(RoleCorps),
    if
        CorpsUid =/= 0 ->
            Corps = corps_db:get_corps(Src, CorpsUid),
            CorpsName = corps:get_name(Corps),
            OwnerRoleUid = corps:get_owner(Corps),
            RoleShow = role_db:get_role_show(Src, OwnerRoleUid),
            RoleName = role_show:get_name(RoleShow),
            Exp = corps:get_exp(Corps),
            Banner = corps:get_banner(Corps),
            MemNum = corps:get_mem_num(Corps),
            TownNum = corps_db:get_corps_town_num(Src, CorpsUid),
            State = corps:get_state(Corps),
            {PrivateNotice, PublicNotice} = corps_db:get_corps_notice(Src, CorpsUid),
            Pos = role_corps:get_position(RoleCorps),
            NPublicNotice =
                case corps_lib:check_position_limit('set_public_notice', Pos) of
                    true ->
                        PublicNotice;
                    _ ->
                        ""
                end,
            Rank = rank_get:get_rank(Src, CorpsUid, ?CORPS_LV_ALL_RANK),
            ToDay = time_lib:get_date_by_type('day_of_year'),
            DonateMoneyTimes = role_corps:get_ctb_money_times(RoleCorps, ToDay),
            DonateRmbTimes = role_corps:get_ctb_rmb_times(RoleCorps, ToDay),
            {_AwardDay, Num} = refresh_position_award_state(z_db_lib:get(game_lib:get_table(Src, 'corps_award_state'), RoleUid, {0, 0})),
            {CorpsName, OwnerRoleUid, RoleName, Exp, Banner, MemNum, TownNum, PrivateNotice, NPublicNotice, Rank, Pos, State, {{?MONEY, DonateMoneyTimes}, {?RMB, DonateRmbTimes}}, Num};
        true ->
            "corps_not_in"
    end.
%% ----------------------------------------------------
%% @doc
%%      推荐前段显示
%% @end
%% ----------------------------------------------------
-spec get_other_view(Src, CorpsUid) -> {CorpsName, OwnerUid, OwnerName, CorpsLevel, Banner, MemNum, TownNum, Notice, Rank, {RequestFlag, RequestCastleLv, RequestRoleLv}} when
    Src :: atom(),
    CorpsUid :: integer(),
    CorpsName :: string(),%%军团名字
    OwnerUid :: integer(),%%军团长uid
    OwnerName :: string(),%%军团长名字
    CorpsLevel :: integer(),%%军团等级
    Banner :: integer(),%%军团旗帜
    MemNum :: integer(),%%军团成员数
    TownNum :: integer(), %%军团城池数量
    Notice :: string(),%%军团公告
    Rank :: integer(),%%军团排名
    RequestFlag :: 0|1,%%申请设置
    RequestCastleLv :: integer(),%申请需要大殿等级
    RequestRoleLv :: integer().%申请需要主公等级
get_other_view(Src, CorpsUid) ->
    case corps_db:get_corps(Src, CorpsUid) of
        'none' ->
            "corps_not_find";
        Corps ->
            CorpsName = corps:get_name(Corps),
            RoleUid = corps:get_owner(Corps),
            RoleShow = role_db:get_role_show(Src, RoleUid),
            RoleName = role_show:get_name(RoleShow),
            CorpsLevel = corps:get_level(Corps),
            Banner = corps:get_banner(Corps),
            MemNum = corps:get_mem_num(Corps),
            TownNum = corps_db:get_corps_town_num(Src, CorpsUid),
            {_PrivateNotice, PublicNotice} = corps_db:get_corps_notice(Src, CorpsUid),
            %Rank = rank_get:get_rank(Src, CorpsUid, z_lib:get_value(?COUNTRY_CORPS_LV_RANK, corps:get_country(Corps), 0)),
            Rank = 0,
            CorpsCondition = corps:get_conditon(Corps),
            RequestFlag = corps_condition:get_request_flag(CorpsCondition),
            RequestCastleLv = corps_condition:get_request_castle_lv(CorpsCondition),
            RequestRoleLv = corps_condition:get_request_role_lv(CorpsCondition),
            {CorpsName, RoleUid, RoleName, CorpsLevel, Banner, MemNum, TownNum, PublicNotice, Rank,
                {RequestFlag, RequestCastleLv, RequestRoleLv}}
    end.

%% ----------------------------------------------------
%% @doc
%%      检查旗帜
%% @end
%% ----------------------------------------------------
-spec check_banner(integer()) -> boolean().
check_banner(Banner) when Banner < 1000 andalso Banner >= 100 ->
    B1 = Banner rem 10,
    B2 = (Banner div 10) rem 10,
    B3 = Banner div 100,
    {_, {List1, List2, List3}} = zm_config:get('corps', 'banner_select_list'),
    lists:member(B3, List1) andalso lists:member(B2, List2) andalso lists:member(B1, List3);
check_banner(_) ->
    false.

%% ----------------------------------------------------
%% @doc
%%      检查公告
%% @end
%% ----------------------------------------------------
-spec check_notice(atom(), string()) -> {'ok', string()} | string().
check_notice(Src, Notice) ->
    NNotice = string:strip(unicode:characters_to_list(Notice, 'utf8')),
    Size = string_lib:compute_size(NNotice),
    if
        Size > 600 ->
            "corps_notice_len_error";
        true ->
            case string_lib:check_str(Src, NNotice) of
                false ->
                    {ok, NNotice};
                _ ->
                    "have_mask_word"
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      检查
%% @end
%% ----------------------------------------------------
-spec check(term(), term(), tuple()) -> boolean().
check({Role, _Rmb}, 'create', {'money', Value}) ->
    role:get_money(Role) >= Value;
check({_Role, Rmb}, 'create', {'rmb', Value}) ->
    rmb_lib:get_rmb(Rmb) >= Value;
check({Role, _Rmb}, 'create', {'role_level', Value}) ->
    game_lib:get_level('role', Role) >= Value;
check({Role, _Rmb}, 'create', {'vip', Value}) ->
    game_lib:get_level('vip', Role) >= Value;
check(RoleShow, 'enter', {'castle_level', Value}) ->
    role_show:get_castle_lv(RoleShow) >= Value;
check(RoleShow, 'enter', {'role_level', Value}) ->
    role_show:get_level(RoleShow) >= Value;
check(GUser, 'replace_owner', {'offline_sec', V}) ->
    LogoutTime = guser:get_logout_time(GUser),
    LoginTime = guser:get_login_time(GUser),
    LogoutTime > LoginTime andalso time_lib:now_second() - LogoutTime >= V;
check({Rmb}, 'change_banner', {'rmb', Value}) ->
    rmb_lib:get_rmb(Rmb) >= Value;
check({_RoleCorps, _Type, _DonateTimes, RoleOrRmb, _DonateMaxTimes}, 'donate', {'money', Value}) ->
    role:get_money(RoleOrRmb) >= Value;
check({_RoleCorps, _Type, _DonateTimes, RoleOrRmb, _DonateMaxTimes}, 'donate', {'rmb', Value}) ->
    rmb_lib:get_rmb(RoleOrRmb) >= Value;
check({RoleCorps, Type, DonateTimes, _RoleOrRmb, {M, F}}, 'donate', {'contribute_times', Value}) ->
    DonateMaxTimes = M:F(RoleCorps, Type),
    DonateTimes + Value =< DonateMaxTimes;
check({Src, SelfRoleUid, SelfSendNum, PropNum, _Storage}, 'corps_gift', 'send_num') ->
    Role = role_db:get_role(Src, SelfRoleUid),
    vip_lib:get_corps_gift_send_num(Role) - SelfSendNum >= PropNum;
check({_Src, _SelfRoleUid, _SelfSendNum, _PropNum, Storage}, 'corps_gift', {'prop', PropList}) ->
    storage_lib:check_goods(PropList, Storage);
check({Src, SelfRoleUid, SelfSendNum, PropNum, _Storage}, 'corps_gift', {'rmb', {BaseValue, AddValue}}) ->
    rmb_db:get_all_rmb(Src, SelfRoleUid) >= corps_gift_rmb(SelfSendNum, PropNum, {BaseValue, AddValue});
check({_Src, _RoleUid, PropList}, 'corps_gift', {'prop_num', Value}) ->
    PropNum = lists:foldl(fun({_Sid, Num}, TotalNum) ->
        TotalNum + Num
    end, 0, PropList),
    PropNum =< Value;
check({Src, RoleUid, _PropList}, 'corps_gift', {'vip_lv', Value}) ->
    RoleShow = role_db:get_role_show(Src, RoleUid),
    role_show:get_vip_level(RoleShow) >= Value;
check({_Src, _RoleUid, PropList}, 'corps_gift', {'prop_type', PropTypes}) ->
    z_lib:foreach(fun(Args, {Sid, _Num}) ->
        Bl = lists:member(Sid, PropTypes),
        if
            Bl ->
                {ok, Args};
            true ->
                {break, false}
        end
    end, true, PropList);
check({GoodStorage}, 'change_name', {'prop', {Sid, Num}}) ->
    storage_lib:check_goods([{Sid, Num}], GoodStorage);
check(_, _, _) ->
    false.

%% ----------------------------------------------------
%% @doc
%%      消耗
%% @end
%% ----------------------------------------------------
-spec consume(term(), term(), tuple()) -> {term(), term()}.
consume({Role, Rmb}, 'create', {'money', Value}) ->
    {Cs, Role1} = role_lib:deduct_money(Role, Value),
    {Cs, {Role1, Rmb}};
consume({Role, Rmb}, 'create', {'rmb', Value}) ->
    {Cs, NRmb} = rmb_lib:reduct_rmb(Rmb, Value),
    {Cs, {Role, NRmb}};
consume({Rmb}, 'change_banner', {'rmb', Value}) ->
    {Cs, NRmb} = rmb_lib:reduct_rmb(Rmb, Value),
    {Cs, {NRmb}};
consume({DonateTimes, RoleOrRmb}, 'donate', {'money', Value}) ->
    {Cs, NRoleOrRmb} = role_lib:deduct_money(RoleOrRmb, Value),
    {Cs, {DonateTimes, NRoleOrRmb}};
consume({DonateTimes, RoleOrRmb}, 'donate', {'rmb', Value}) ->
    {Cs, NRoleOrRmb} = rmb_lib:reduct_rmb(RoleOrRmb, Value),
    {Cs, {DonateTimes, NRoleOrRmb}};
consume({DonateTimes, RoleOrRmb}, 'donate', {'contribute_times', V}) ->
    NDonateTimes = DonateTimes + V,
    {'none', {NDonateTimes, RoleOrRmb}};
consume({Src, SelfRoleUid, {StartNum, SelfSendNum}, PropNum, Storage}, 'corps_gift', {'prop', PropList}) ->
    {Consumes, NewStorage} = storage_lib:deduct_by_sid(Storage, PropList),
    {Consumes, {Src, SelfRoleUid, {StartNum, SelfSendNum}, PropNum, NewStorage}};
consume({Src, SelfRoleUid, {StartNum, SelfSendNum}, PropNum, Storage}, 'corps_gift', {'rmb', {BaseValue, AddValue}}) ->
    NeedValue = corps_gift_rmb(StartNum, PropNum, {BaseValue, AddValue}),
    Consumes = rmb_db:reduce_rmb(Src, SelfRoleUid, NeedValue),
    {Consumes, {Src, SelfRoleUid, {StartNum, SelfSendNum}, PropNum, Storage}};
consume({Src, SelfRoleUid, {StartNum, SelfSendNum}, PropNum, Storage}, 'corps_gift', 'send_num') ->
    {'none', {Src, SelfRoleUid, {StartNum, SelfSendNum + PropNum}, PropNum, Storage}};
consume({GoodStorage}, 'change_name', {'prop', {Sid, Num}}) ->
    {Consumes, NewGoodStorage} = storage_lib:deduct_by_sid(GoodStorage, [{Sid, Num}]),
    {Consumes, {NewGoodStorage}};
consume(Tables, _, _) ->
    {'none', Tables}.

%% ----------------------------------------------------
%% @doc
%%      军团红点提示
%% @end
%% ----------------------------------------------------
-spec get_corps_reminder(Src, CorpsUid, RoleCorps) -> 1 | 0 when
    Src :: atom(),
    CorpsUid :: integer(),
    RoleCorps :: role_corps:role_corps().
get_corps_reminder(Src, CorpsUid, RoleCorps) ->
    Now = time_lib:now_second(),
    if
        CorpsUid =:= 0 ->
            check_invites(Now, RoleCorps);
        true ->
            RolePos = role_corps:get_position(RoleCorps),
            if
                RolePos =:= ?CORPS_POSITION_OWNER ->%军团长
                    check_requests(Now, corps_db:get_corps_request(Src, CorpsUid));
                true ->
%%                    Corps = corps_db:get_corps(Src, CorpsUid),
%%                    Ownner = corps:get_owner(Corps),    %% 得到军团长
%%                    {_, Conditions} = zm_config:get('corps', 'replace_owner_conditions'),
%%                    Days = z_lib:get_value(Conditions, 'offline_sec', 0),
%%                    User = user_db:get_user(Src, Ownner),
%%                    LogoutTime = guser:get_logout_time(User),
%%                    LoginTime = guser:get_login_time(User),
%%                    if
%%                        LogoutTime > LoginTime andalso Now - LogoutTime >= Days ->
%%                            1;      %% 军团长离线一段时间了
%%                        true ->
                    case corps_lib:check_position_limit('check_request', role_corps:get_position(RoleCorps)) of
                        true ->     %% 有权限
                            check_requests(Now, corps_db:get_corps_request(Src, CorpsUid));
                        _ ->
                            0
                    end
%%                    end
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      获取军团公告设置时间
%% @end
%% ----------------------------------------------------
-spec get_notice_time(atom(), integer()) -> {integer(), integer()}.
get_notice_time(_Src, 0) ->
    {0, 0};
get_notice_time(Src, CorpsUid) ->
    {PrivateTime, _, PublicTime, _} = z_db_lib:get(game_lib:get_table(Src, 'corps_notice'), CorpsUid, {0, "", 0, ""}),
    {PrivateTime, PublicTime}.


%% ----------------------------------------------------
%% @doc
%%      检查开服时间
%% @end
%% ----------------------------------------------------
-spec check_corps_invite(atom(), integer()) -> boolean().
check_corps_invite(Src, RoleUid) ->
    {Start_after_day, Login_series_days} = element(2, zm_config:get(corps, corps_invite_role_clogin_day)),
    OnlineTime = args_system:get_online_time(Src),
    Now = time_lib:now_second(),
    case time_lib:day_two_second(OnlineTime, Now) - 1 > Start_after_day of
        true ->
            guser:get_clogin_day(user_db:get_user(Src, RoleUid)) >= Login_series_days;
        false ->
            true
    end.
%% ----------------------------------------------------
%% @doc
%%      获得军团职位对应捐献次数
%% @end
%% ----------------------------------------------------
-spec get_donate_times(RoleCorps, Type) -> integer() when
    RoleCorps :: role_corps:role_corps(),
    Type :: integer().
get_donate_times(RoleCorps, Type) ->
    Pos = role_corps:get_position(RoleCorps),
    {_, TimesCfg} = zm_config:get('donate_times', Pos),
    element(2, lists:keyfind(Type, 1, TimesCfg)).
%% ----------------------------------------------------
%% @doc
%%      刷新每日职位奖励
%% @end
%% ----------------------------------------------------
refresh_position_award_state({AwardDay, Num}) ->
    Today = time_lib:get_date_by_type('day_of_year'),
    if
        AwardDay =:= Today ->
            {AwardDay, Num};
        true ->
            {Today, 0}
    end.
%% ----------------------------------------------------
%% @doc
%%      结盟信息清空无效的信息
%%      拒绝消息保存30分钟(配置)，
%%      申请结盟消息保存24小时(配置)
%% @end
%% ----------------------------------------------------
ally_clear_invalid_info(List, ValitTime, Now) ->
    Fun1 = fun({_CorpsUid, Time}) ->
        Time + ValitTime > Now
    end,
    lists:filter(Fun1, List).
%% ----------------------------------------------------
%% @doc
%%      前台显示根据名字搜索的结果
%% @end
%% ----------------------------------------------------
ally_format_search_by_name(Src, CorpsUid) ->
    Corps = corps_db:get_corps(Src, CorpsUid),
    CorpsName = corps:get_name(Corps),
    CorpsLevel = corps:get_level(Corps),
    CorpsTown = corps_db:get_corps_town(Src, CorpsUid),
    Influence = corps_town:get_influence(CorpsTown),
    OwnerUid = corps:get_owner(Corps),
    RoleShow = role_db:get_role_show(Src, OwnerUid),
    RoleName = role_show:get_name(RoleShow),
    Allyinfo = corps_db:get_db_ally_info(Src, CorpsUid),
    IsAllyInfo = case ally_info:get_ally_corps(Allyinfo) =:= [] of
        true ->
            ally_info:get_delete_time(Allyinfo);
        false ->
            1
    end,
    {CorpsUid, CorpsName, CorpsLevel, Influence, RoleName, IsAllyInfo}.
%% ----------------------------------------------------
%% @doc
%%      推送申请结盟
%% @end
%% ----------------------------------------------------
ally_format_send_ally_request(Src, CorpsUid) ->
    Corps = corps_db:get_corps(Src, CorpsUid),
    CorpsName = corps:get_name(Corps),
    CorpsLevel = corps:get_level(Corps),
    CorpsTown = corps_db:get_corps_town(Src, CorpsUid),
    Influence = corps_town:get_influence(CorpsTown),
    {CorpsUid, CorpsName, CorpsLevel, Influence}.
%% ----------------------------------------------------
%% @doc
%%      上线第一次获取结盟信息,Bool,是否是团长，团长获取的信息更多
%% @end
%% ----------------------------------------------------
ally_format_get_corps_info(Src, CorpsUid, Corps, Bool) ->
    CorpsName = corps:get_name(Corps),
    Banner = corps:get_banner(Corps),
    if
        Bool ->
            CorpsTown = corps_db:get_corps_town(Src, CorpsUid),
            CorpsOwner = corps:get_owner(Corps),
            OwnerRoleShow = role_db:get_role_show(Src, CorpsOwner),
            OwnerName = role_show:get_name(OwnerRoleShow),
            CorpsLevel = corps:get_level(Corps),
            TownNum = corps_town:get_num(CorpsTown) + corps_town:get_cnum(CorpsTown),
            CorpsMemberNum = corps:get_mem_num(Corps),
            Influence = corps_town:get_influence(CorpsTown),
            Rank = rank_get:get_rank(Src, CorpsUid, ?CORPS_LV_ALL_RANK),
            {1, CorpsUid, CorpsName, Banner, OwnerName, CorpsLevel, TownNum, CorpsMemberNum, Influence, Rank};
        true ->
            {1, CorpsUid, CorpsName, Banner}
    end.
%% ----------------------------------------------------
%% @doc
%%      同意申请之后需要推送
%% @end
%% ----------------------------------------------------
ally_agree_send(Src, Corps, CorpsMembers, BCorpsUid, BCorps, BCorpsMembersList) ->
    CorpsOwner = corps:get_owner(Corps),
    BCorpsInfo = corps_lib:ally_format_get_corps_info(Src, BCorpsUid, BCorps, true),
    [Flag, BCorpsUid, BCorpsName, BBanner | _] = tuple_to_list(BCorpsInfo),
    BCorpsMembers = list_to_tuple(BCorpsMembersList),
    set_front_lib:send_ally_reply(Src, [CorpsOwner], {BCorpsInfo, BCorpsMembers, {}}),
    set_front_lib:send_ally_reply(Src, lists:delete(CorpsOwner, CorpsMembers), {{Flag, BCorpsUid, BCorpsName, BBanner}, BCorpsMembers, {}}).
%% ----------------------------------------------------
%% @doc
%%      结盟系统公告
%% @end
%% ----------------------------------------------------
ally_notice(Src, CorpsName, BCorpsName, Type) ->
    CfgName = if
        Type =:= ?AGREE ->
            'ally_reply';
        Type =:= ?REFUSE ->
            'ally_delete'
    end,
    chat_lib:notice_world(Src, CfgName, [CorpsName, BCorpsName]).
%% ----------------------------------------------------
%% @doc
%%      结盟系统邮件,Type=0解除结盟，Type=1，结盟
%% @end
%% ----------------------------------------------------
ally_mail(Src, RoleUids, CorpsName, Type) ->
    MailNum = if
        Type =:= ?AGREE ->
            55;
        Type =:= ?REFUSE ->
            56
    end,
    MailType = award_source:get_source(?MODULE),
    Source = game_lib:get_language('mail_system_source', []),
    Mail = mail:init({Source, MailType, time_lib:now_second(), 0, {0, game_lib:get_language({mail_title, MailNum})}, {0, game_lib:get_language({mail_content, MailNum}, [CorpsName])}, []}),
    lists:foreach(fun(RoleUid) ->
        mail_db:send(Src, RoleUid, Mail)
    end, RoleUids).
%% ----------------------------------------------------
%% @doc
%%      玩家退/踢出军团
%% @end
%% ----------------------------------------------------
ally_role_exit_corps(Src, RoleUid, CorpsUid) ->
    AllyCorpsUids = corps_db:get_ally_corps_uids(Src, CorpsUid),
    Fun1 = fun(AllyRoleUidsTmp, CrpUid) ->
        CrpMembr = corps_db:get_corps_members(Src, CrpUid),
        {ok, AllyRoleUidsTmp ++ CrpMembr}
    end,
    OldAllyRoleUids = z_lib:foreach(Fun1, [], AllyCorpsUids),
    ally_delete_repatriate(Src, [RoleUid], OldAllyRoleUids).
%% ----------------------------------------------------
%% @doc
%%      解散结盟遣返盟军驻防
%% @end
%% ----------------------------------------------------
ally_delete_repatriate(_Src, CorpsMember, BCorpsMember) when CorpsMember =:= [] orelse BCorpsMember =:= [] ->
    ok;
ally_delete_repatriate(Src, CorpsMember, BCorpsMember) ->
    Fun1 = fun(AllyCorpsMember, RoleUidTmp) ->
        ally_repatriate(Src, RoleUidTmp, AllyCorpsMember),
        {ok, AllyCorpsMember}
    end,
    z_lib:foreach(Fun1, BCorpsMember, CorpsMember),
    z_lib:foreach(Fun1, CorpsMember, BCorpsMember),
    ok.

%% ----------------------------------------------------
%% @doc
%%      盟军不存在了，遣返自己这里盟军的驻防
%% @end
%% ----------------------------------------------------
ally_repatriate(Src, RoleUid, OldAlyyCorpsMember) ->
    Garrison = garrison_db:get_garrison(Src, RoleUid),
    Dispatchs = garrison:get_dispatchs(Garrison),
    Fun2 = fun({Gid, EndRUid, EndPint}) ->
        case lists:member(EndRUid, OldAlyyCorpsMember) of
            true ->
                garrison_db:repatriate(Src, EndRUid, EndPint, {?ROLE, EndRUid}, RoleUid, Gid);
            false ->
                ok
        end
    end,
    lists:foreach(Fun2, Dispatchs).
%% ----------------------------------------------------
%% @doc
%%      前台显示邀请列表
%% @end
%% ----------------------------------------------------
ally_format_invites(Src, Invites) ->
    Fun2 = fun(Acc, {CorpsUid, Time}) ->
        case corps_db:get_corps(Src, CorpsUid) of
            none ->
                {ok, Acc};
            Corps ->
                CorpsTown = corps_db:get_corps_town(Src, CorpsUid),
                {ok, [{CorpsUid, corps:get_name(Corps), corps:get_level(Corps), corps_town:get_influence(CorpsTown), Time} | Acc]}
        end
    end,
    list_to_tuple(z_lib:foreach(Fun2, [], Invites)).

%%%===================LOCAL FUNCTIONS==================
corps_gift_rmb(StartNum, GiftNum, {BaseValue, AddValue}) ->
    Fun = fun(Index, NeedRmb_) ->
        NeedRmb_ + BaseValue + (Index - 1) * AddValue
    end,
    lists:foldl(Fun, 0, lists:seq(StartNum + 1, StartNum + GiftNum)).
