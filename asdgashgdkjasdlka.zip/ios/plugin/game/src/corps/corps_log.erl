-module(corps_log).

%%%=======================STATEMENT====================
-description("corps_log").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([enter/1, kickout/3, quit/1, set_position/3, trans_position/3]).
-export([town_complete_achieve/5]).
-export([town_contribute/6]).
-export([town_defend_fight/5, town_fight/6, abandon_town/4, cancel_abandon_town/4]).
-export([condition_enter/3, condition_request/5]).
%%%=======================INCLUDE======================
-include("../include/corps.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%        加入军团
%% @end
%% ----------------------------------------------------
-spec enter(RoleName) -> tuple() when
    RoleName :: string().%进入军团的玩家的名字
enter(RoleName) ->
    {?CORPS_LOG_TYPE_ENTER, RoleName, time_lib:now_second()}.

%%-------------------------------------------------------------------
%% @doc
%%      踢出军团
%% @end
%%-------------------------------------------------------------------
-spec kickout(RoleName1, Pos, RoleName2) -> tuple() when
    RoleName1 :: string(),%操作者名字
    Pos :: integer(),%操作者职位
    RoleName2 :: string().%被踢出者名字
kickout(RoleName1, Pos, RoleName2) ->
    {?CORPS_LOG_TYPE_KICKOUT, RoleName1, Pos, RoleName2, time_lib:now_second()}.

%%-------------------------------------------------------------------
%% @doc
%%      退出军团
%% @end
%%-------------------------------------------------------------------
-spec quit(RoleName) -> tuple() when
    RoleName :: string().%退出者名字
quit(RoleName) ->
    {?CORPS_LOG_TYPE_QUIT, RoleName, time_lib:now_second()}.

%%-------------------------------------------------------------------
%% @doc
%%      设置职位
%% @end
%%-------------------------------------------------------------------
-spec set_position(RoleName, OldPos, NewPos) -> tuple() when
    RoleName :: string(),%被设置者名字
    OldPos :: integer(),%被设置者旧职位
    NewPos :: integer().%被设置者新职位
set_position(RoleName, OldPos, NewPos) ->
    {?CORPS_LOG_TYPE_SETPOSITION, RoleName, OldPos, NewPos, time_lib:now_second()}.

%%-------------------------------------------------------------------
%% @doc
%%    转让职位
%% @end
%%-------------------------------------------------------------------
-spec trans_position(RoleName1, Pos1, RoleName2) -> tuple() when
    RoleName1 :: string(),%转让者名字
    Pos1 :: integer(),%转让者职位
    RoleName2 :: string().%被转让者名字
trans_position(RoleName1, Pos1, RoleName2) ->
    {?CORPS_LOG_TYPE_TRANSPOSITION, RoleName1, Pos1, RoleName2, time_lib:now_second()}.

%%-------------------------------------------------------------------
%% @doc
%%    完成皇榜任务
%% @end
%%-------------------------------------------------------------------
-spec town_complete_achieve(RoleName, TownSid, TownLv, AchieveSid, TownAddExp) -> tuple() when
    RoleName :: string(),%玩家名字
    TownSid :: integer(),%城池sid
    TownLv :: integer(),%城池等级
    AchieveSid :: integer(),%皇榜任务sid
    TownAddExp :: integer().%城池增加的经验值
town_complete_achieve(RoleName, TownSid, TownLv, AchieveSid, TownAddExp) ->
    {?CORPS_LOG_TYPE_TOWN_COMPLETE_ACHIEVE, RoleName, TownSid, TownLv, AchieveSid, TownAddExp, time_lib:now_second()}.

%%-------------------------------------------------------------------
%% @doc
%%    捐献
%% @end
%%-------------------------------------------------------------------
-spec town_contribute(RoleName, TownSid, TownLv, CtbSid, TownAddExp, CorpsAddExp) -> tuple() when
    RoleName :: string(),%玩家名字
    TownSid :: integer(),%城池sid
    TownLv :: integer(),%城池等级
    CtbSid :: integer(),%捐献项sid
    TownAddExp :: integer(),%城池增加经验值
    CorpsAddExp :: integer().%军团增加的经验值
town_contribute(RoleName, TownSid, TownLv, CtbSid, TownAddExp, CorpsAddExp) ->
    {?CORPS_LOG_TYPE_TOWN_CONTRIBUTE, RoleName, TownSid, TownLv, CtbSid, TownAddExp, CorpsAddExp, time_lib:now_second()}.

%%-------------------------------------------------------------------
%% @doc
%%    城池防御
%% @end
%%-------------------------------------------------------------------
-spec town_defend_fight(Sucess, CorpsName, Country, TownSid, TownLv) -> tuple() when
    Sucess :: 0|1,%是否防守成功 0:失败 1:成功
    CorpsName :: string(),%进攻的军团名字
    Country :: integer(),%进攻的军团所属国家
    TownSid :: integer(),%城池sid
    TownLv :: integer().%城池等级
town_defend_fight(Sucess, CorpsName, Country, TownSid, TownLv) ->
    {?CORPS_LOG_TYPE_TOWN_DEFEND_FIGHT, Sucess, CorpsName, Country, TownSid, TownLv, time_lib:now_second()}.

%%-------------------------------------------------------------------
%% @doc
%%    城池进攻
%% @end
%%-------------------------------------------------------------------
-spec town_fight(Sucess, CorpsName, Country, TownSid, TownLv, FullFlag) -> tuple() when
    Sucess :: 0|1,%是否进攻成功 0:失败 1:成功
    CorpsName :: string(),%防御的军团名字
    Country :: integer(),%防御的军团所属国家
    TownSid :: integer(),%城池sid
    TownLv :: integer(),%城池等级
    FullFlag :: 0|1.%城池是否满 0:正常获得， 1：满了丢弃城池
town_fight(Sucess, CorpsName, Country, TownSid, TownLv, FullFlag) ->
    {?CORPS_LOG_TYPE_TOWN_FIGHT, Sucess, CorpsName, Country, TownSid, TownLv, FullFlag, time_lib:now_second()}.

%%-------------------------------------------------------------------
%% @doc
%%    军团申请进入是否需要批准设置
%% @end
%%-------------------------------------------------------------------
-spec condition_enter(RoleName, Pos, EnterFlag) -> tuple() when
    RoleName :: string(),%玩家名字
    Pos :: integer(),%玩家职位
    EnterFlag :: integer().
condition_enter(RoleName, Pos, EnterFlag) ->
    {?CORPS_LOG_TYPE_CONDITION_ENTER, RoleName, Pos, EnterFlag, time_lib:now_second()}.

%%-------------------------------------------------------------------
%% @doc
%%    军团申请条件
%% @end
%%-------------------------------------------------------------------
-spec condition_request(RoleName, Pos, RequestFlag, RequestRoleLv, RequestCastleLv) -> tuple() when
    RoleName :: string(),%玩家名字
    Pos :: integer(),%玩家职位
    RequestFlag :: integer(),
    RequestRoleLv :: integer(),
    RequestCastleLv :: integer().
condition_request(RoleName, Pos, RequestFlag, RequestRoleLv, RequestCastleLv) ->
    {?CORPS_LOG_TYPE_CONDITION_REQUEST, RoleName, Pos, RequestFlag, RequestRoleLv, RequestCastleLv, time_lib:now_second()}.
%% ---------------------------------------------------
%% @doc
%%      放弃城池
%% @end
%% ----------------------------------------------------
abandon_town(RoleName, Pos, TownSid, TownLv) ->
    {?CORPS_LOG_TYPE_ABANDON_TOWN, TownSid, TownLv, RoleName, Pos, time_lib:now_second()}.
%% ---------------------------------------------------
%% @doc
%%      取消放弃城池
%% @end
%% ----------------------------------------------------
cancel_abandon_town(RoleName, Pos, TownSid, TownLv) ->
    {?CORPS_LOG_TYPE_CANCEL_ABANDON_TOWN, TownSid, TownLv, RoleName, Pos, time_lib:now_second()}.
%%%===================LOCAL FUNCTIONS==================


