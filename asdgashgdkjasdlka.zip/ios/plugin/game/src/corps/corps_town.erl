-module(corps_town).

%%%=======================STATEMENT====================
-description("corps_town").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([init/0]).
-export([
    get_num/1,
    get_influence/1,
    get_olist_townsid/1,
    get_clist_townsid/1,
    add_olist/5,
    del_olist/4,
    get_flist/1,
    get_flist_townsid/1,
    get_cflist_townsid/1,
    add_flist/3,
    del_flist/3,
    get_olist/1,

    get_atimes/1,
    set_atimes/2,
    update_olist/5,
    get_barns_sid/1,
    get_cross_townsid/1
]).

-export([
    get_cnum/1,
    get_clist/1,
    get_cflist/1
]).
-export_type([corps_town/0]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(corps_town, {
    num = 0 :: integer(),%%当前军团占领的普通城池数
    cnum = 0 :: integer(),%当前军团占领的郡城数
    influence = 0 :: integer(),%%当前军团势力值
    olist = [] :: [{integer(), integer()}],%%当前占领的普通城池 {城池sid,等级}
    clist = [] :: [{integer(), integer()}],%%当前占领的郡城 {城池sid,等级}
    flist = [] :: [{integer(), integer()}], %%当前正在战斗的普通城池,开始时间
    cflist = [] :: [{integer(), integer()}],%%当前正在战斗的郡城,开始时间
    atimes = {0, 0}  %{天数,放弃城池次数}
}).
%%%=======================TYPE=========================
-type corps_town() :: #corps_town{}.


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%      初始化
%% @end
%% ----------------------------------------------------
-spec init() -> corps_town().
init() ->
    #corps_town{}.
%%-------------------------------------------------------------------
%% @doc
%%      获取军团占领城池数量
%% @end
%%-------------------------------------------------------------------
-spec get_num(corps_town()) -> integer().
get_num(#corps_town{num = Num}) -> Num.

%%-------------------------------------------------------------------
%% @doc
%%      获取军团占领郡城数量
%% @end
%%-------------------------------------------------------------------
-spec get_cnum(corps_town()) -> integer().
get_cnum(#corps_town{cnum = Num}) -> Num.

%%-------------------------------------------------------------------
%% @doc
%%      势力值
%% @end
%%-------------------------------------------------------------------
-spec get_influence(corps_town()) -> integer().
get_influence(#corps_town{influence = Influence}) -> Influence.
%%-------------------------------------------------------------------
%% @doc
%%      获取军团占领中的普通城池
%% @end
%%-------------------------------------------------------------------
-spec get_olist_townsid(corps_town()) -> [integer()].
get_olist_townsid(#corps_town{olist = OList}) -> [TownSid || {TownSid, _} <- OList].

%%-------------------------------------------------------------------
%% @doc
%%      获取军团占领中的郡城城池
%% @end
%%-------------------------------------------------------------------
-spec get_clist_townsid(corps_town()) -> [integer()].
get_clist_townsid(#corps_town{clist = CList}) -> [TownSid || {TownSid, _} <- CList].

%%-------------------------------------------------------------------
%% @doc
%%      获取军团占领中的普通城池和等级
%% @end
%%-------------------------------------------------------------------
-spec get_olist(corps_town()) -> [{integer(), integer()}].
get_olist(#corps_town{olist = OList}) -> OList.

%% ----------------------------------------------------
%% @doc
%%      删除军团占领的普通城池
%% @end
%% ----------------------------------------------------
del_olist(CorpsTown, TownSid, IsChief, TownDetail) ->
    DelInfluence = town_detail:get_influence(TownDetail),
    if
        IsChief ->
            #corps_town{clist = OList, cflist = FList, influence = Influence} = CorpsTown,
            NOList = lists:keydelete(TownSid, 1, OList),
            CorpsTown#corps_town{clist = NOList, cflist = lists:keydelete(TownSid, 1, FList), cnum = length(NOList), influence = Influence - DelInfluence};
        true ->
            #corps_town{olist = OList, flist = FList, influence = Influence} = CorpsTown,
            NOList = lists:keydelete(TownSid, 1, OList),
            CorpsTown#corps_town{olist = NOList, flist = lists:keydelete(TownSid, 1, FList), num = length(NOList), influence = Influence - DelInfluence}
    end.

%% ----------------------------------------------------
%% @doc
%%    增加军团占领的普通城池
%% @end
%% ----------------------------------------------------
add_olist(CorpsTown, TownSid, IsChief, TownDetail, Town) ->
    DelInfluence = town_detail:get_influence(TownDetail),
    if
        IsChief ->
            #corps_town{clist = CList, cflist = CFList, influence = Influence} = CorpsTown,
            case lists:keymember(TownSid, 1, CList) of
                true ->
                    CorpsTown;
                false ->
                    NOList = [{TownSid, town:get_lv(Town, TownDetail)} | CList],
                    CorpsTown#corps_town{clist = NOList, cflist = lists:keydelete(TownSid, 1, CFList), cnum = length(NOList), influence = Influence + DelInfluence}
            end;
        true ->
            #corps_town{olist = OList, flist = FList, influence = Influence} = CorpsTown,
            case lists:keymember(TownSid, 1, OList) of
                true ->
                    CorpsTown;
                false ->
                    NOList = [{TownSid, town:get_lv(Town, TownDetail)} | OList],
                    CorpsTown#corps_town{olist = NOList, flist = lists:keydelete(TownSid, 1, FList), num = length(NOList), influence = Influence + DelInfluence}
            end
    end.

%% ----------------------------------------------------
%% @doc
%%    修改军团占领城池等级信息
%% @end
%% ----------------------------------------------------
update_olist(CorpsTown, TownSid, IsChief, TownDetail, Town) ->
    if
        IsChief ->
            #corps_town{clist = CList} = CorpsTown,
            NCList = [{TownSid, town:get_lv(Town, TownDetail)} | lists:keydelete(TownSid, 1, CList)],
            CorpsTown#corps_town{clist = NCList};
        true ->
            #corps_town{olist = OList} = CorpsTown,
            NOList = [{TownSid, town:get_lv(Town, TownDetail)} | lists:keydelete(TownSid, 1, OList)],
            CorpsTown#corps_town{olist = NOList}
    end.

%%-------------------------------------------------------------------
%% @doc
%%      获取军团占领中的郡城和等级
%% @end
%%-------------------------------------------------------------------
-spec get_clist(corps_town()) -> [{integer(), integer()}].
get_clist(#corps_town{clist = OList}) -> OList.

%%-------------------------------------------------------------------
%% @doc
%%      获取军团战斗的普通城池
%% @end
%%-------------------------------------------------------------------
-spec get_flist(corps_town()) -> [{integer(), integer()}].
get_flist(#corps_town{flist = FList}) -> FList.

%%-------------------------------------------------------------------
%% @doc
%%      获取军团战斗的普通城池sid
%% @end
%%-------------------------------------------------------------------
get_flist_townsid(#corps_town{flist = FList}) -> [TownSid || {TownSid, _} <- FList].

%%-------------------------------------------------------------------
%% @doc
%%      增加军团战斗的普通城池
%% @end
%%-------------------------------------------------------------------
add_flist(CorpsTown, TownSid, IsChief) ->
    FList = if
        IsChief ->
            get_cflist(CorpsTown);
        true ->
            get_flist(CorpsTown)
    end,
    case lists:keyfind(TownSid, 1, FList) of
        false ->
            if
                IsChief ->
                    {CorpsTown#corps_town{cflist = [{TownSid, time_lib:now_second()} | FList]}, true};
                true ->
                    {CorpsTown#corps_town{flist = [{TownSid, time_lib:now_second()} | FList]}, true}
            end;
        _ ->
            {CorpsTown, false}
    end.

%%-------------------------------------------------------------------
%% @doc
%%      删除军团战斗的普通城池
%% @end
%%-------------------------------------------------------------------
del_flist(CorpsTown, TownSid, IsChief) ->
    if
        IsChief ->
            FList = get_cflist(CorpsTown),
            CorpsTown#corps_town{cflist = lists:keydelete(TownSid, 1, FList)};
        true ->
            FList = get_flist(CorpsTown),
            CorpsTown#corps_town{flist = lists:keydelete(TownSid, 1, FList)}
    end.

%%-------------------------------------------------------------------
%% @doc
%%      获取军团战斗的普通城池
%% @end
%%-------------------------------------------------------------------
-spec get_cflist(corps_town()) -> [{integer(), integer()}].
get_cflist(#corps_town{cflist = FList}) -> FList.

%%-------------------------------------------------------------------
%% @doc
%%      获取军团战斗的普通城池sid
%% @end
%%-------------------------------------------------------------------
get_cflist_townsid(#corps_town{cflist = CFList}) -> [TownSid || {TownSid, _} <- CFList].
%%-------------------------------------------------------------------
%% @doc
%%
%% @end
%%-------------------------------------------------------------------
-spec get_atimes(corps_town()) -> {integer(), integer()}.
get_atimes(#corps_town{atimes = ATimes}) ->
    ATimes.

%%-------------------------------------------------------------------
%% @doc
%%
%% @end
%%-------------------------------------------------------------------
-spec set_atimes(corps_town(), {integer(), integer()}) -> corps_town().
set_atimes(CorpsTown, ATimes) ->
    CorpsTown#corps_town{atimes = ATimes}.
%%-------------------------------------------------------------------
%% @doc
%%      获得占领粮仓
%% @end
%%-------------------------------------------------------------------
get_barns_sid(#corps_town{clist = List, olist = List2}) ->
    z_lib:foreach(fun(A, {Sid, _}) ->
        TSid = point_lib:sid2view(Sid),
        TD = town_detail:get_cfg(TSid),
        case town_detail:chk_forage(TD) of
            true ->
                {'ok', [TSid | A]};
            false ->
                {'ok', A}
        end
    end, [], List ++ List2).

%%-------------------------------------------------------------------
%% @doc
%%      获得跨服占领普通城池
%% @end
%%-------------------------------------------------------------------
get_cross_townsid(#corps_town{clist = List, olist = List2}) ->
    z_lib:foreach(fun(A, {Sid, _}) ->
        TSid = point_lib:sid2view(Sid),
        TD = town_detail:get_cfg(TSid),
        case town_detail:chk_cross_town(TD) of
            true ->
                {'ok', [TSid | A]};
            false ->
                {'ok', A}
        end
    end, [], List ++ List2).

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------