-module(ally_info).

%%%=======================STATEMENT====================
-description("corps_ally").
-copyright('youkia,www.youkia.net').
-author("ljh,lvjihong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_delete_time/1, get_invites/1, get_ally_corps/1, get_refuses/1]).
-export([set_delete_time/2, set_invites/2, set_ally_corps/2, set_refuses/2]).
-export([init/0]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(ally_info, {
    ally_corps = [] :: list(), %%已经结盟军团
    invites = [] :: list(),  %%别人邀请结盟列表[{军团Uid,时间}]
    refuses = [] :: list(),  %%已拒绝列表，被拒绝的军团30分钟内不能再发来请求
    delete_time = 0 :: integer()  %%解除结盟时间
}).
%%%=======================TYPE=========================
-type corps_ally() :: #ally_info{}.


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%        获取结盟军团UID LIST
%% @end
%% ----------------------------------------------------
-spec get_ally_corps(corps_ally()) -> list().
get_ally_corps(#ally_info{ally_corps = V}) ->
    V.

%% ----------------------------------------------------
%% @doc
%%        设置结盟军团UID LIST
%% @end
%% ----------------------------------------------------
-spec set_ally_corps(corps_ally(), list()) -> corps_ally().
set_ally_corps(CorpsAlly, V) ->
    CorpsAlly#ally_info{ally_corps = V}.

%% ----------------------------------------------------
%% @doc
%%        获取解除结盟时间
%% @end
%% ----------------------------------------------------
-spec get_delete_time(corps_ally()) -> integer().
get_delete_time(#ally_info{delete_time = V}) ->
    V.

%% ----------------------------------------------------
%% @doc
%%        设置解除结盟时间
%% @end
%% ----------------------------------------------------
-spec set_delete_time(corps_ally(), integer()) -> corps_ally().
set_delete_time(CorpsAlly, V) ->
    CorpsAlly#ally_info{delete_time = V}.

%% ----------------------------------------------------
%% @doc
%%        获取别人邀请结盟的列表
%% @end
%% ----------------------------------------------------
-spec get_invites(corps_ally()) -> list().
get_invites(#ally_info{invites = V}) ->
    V.
%% ----------------------------------------------------
%% @doc
%%        设置别人邀请结盟的列表
%% @end
%% ----------------------------------------------------
-spec set_invites(corps_ally(), list()) -> corps_ally().
set_invites(CorpsAlly, V) ->
    CorpsAlly#ally_info{invites = V}.
%% ----------------------------------------------------
%% @doc
%%        获取别人邀请结盟的列表
%% @end
%% ----------------------------------------------------
-spec get_refuses(corps_ally()) -> list().
get_refuses(#ally_info{refuses = V}) ->
    V.
%% ----------------------------------------------------
%% @doc
%%        设置别人邀请结盟的列表
%% @end
%% ----------------------------------------------------
-spec set_refuses(corps_ally(), list()) -> corps_ally().
set_refuses(CorpsAlly, V) ->
    CorpsAlly#ally_info{refuses = V}.
%% ----------------------------------------------------
%% @doc
%%        初始化
%% @end
%% ----------------------------------------------------
-spec init() -> corps_ally().
init() ->
    #ally_info{}.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
