-module(abandoning_town).

%%%=======================STATEMENT====================
-description("abandoning_town").
-copyright('youkia,www.youkia.net').
-author("ljh,lvjihong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_pos/1, get_start_time/1, get_town_sid/1, get_town_sid_index/0]).
-export([init/0, init/3]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(abandoning_town, {
    town_sid = 0 :: integer(),%%城池Sid
    start_time = 0 :: integer(),%%开始时间
    pos = 0 :: integer()%%放弃者职位
}).
%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%      基础函数
%% @end
%% ----------------------------------------------------
get_town_sid(#abandoning_town{town_sid = V}) -> V.
get_start_time(#abandoning_town{start_time = V}) -> V.
get_pos(#abandoning_town{pos = V}) -> V.
get_town_sid_index() -> #abandoning_town.town_sid.

init() -> #abandoning_town{}.
init(TownSid, StartTime, Pos) ->
    #abandoning_town{town_sid = TownSid, start_time = StartTime, pos = Pos}.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
