-module(role_corps).

%%%=======================STATEMENT====================
-description("role_corps").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    get_corps_uid/1,
    get_requests/1,
    get_contribute/1,
    get_ctb_times/3,
    get_position/1,
    get_exit_time/1,
    get_enter_time/1,
    get_invites/1,
    get_is_first/1,
    get_ctb_money_times/2,
    get_ctb_rmb_times/2,
    get_all_ctb_times/2
]).
-export([
    set_requests/2,
    set_contribute/2,
    set_ctb_times/4,
    set_position/2,
    set_invites/2,
    set_exit_time/2,
    set_is_first/2,
    set_ctb_money_times/3,
    set_ctb_rmb_times/3
]).
-export([
    enter/3,
    exit/1,
    init/0
]).

-export_type([role_corps/0]).
%%%=======================INCLUDE======================
-include("../include/corps.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(role_corps, {
    corps_uid = 0 :: integer(),             %%军团uid
    enter_time = 0 :: integer(),                %%进入军团时间
    exit_time = 0 :: integer(),                %%上一军团离开时间
    requests = [] :: corps:requests(),%%申请军团列表[{军团Uid,时间}]
    invites = [] :: corps:invites(),            %%被邀请列表
    contribute = {0, []} :: {integer(), list()},            %%贡献值{当前贡献值,贡献值统计}
    ctb_times = {[], 0} :: {integer()|list(), integer()},             %%当天捐献次数{次数(后面修改为类型次数),天数}
    ctb_money_times = {0, 0} :: {integer(), integer()},             %%当天捐献铜币次数{次数,天数}
    ctb_rmb_times = {0, 0} :: {integer(), integer()},            %%当天捐献Rmb次数{次数,天数}
    position = ?CORPS_POSITION_NORMAL_E :: corps:position(),           %%职位-
    is_first = 0 :: integer()        %%是否是第一次加入军团  0未领奖  1已领奖
}).
%%%=======================TYPE=========================
-type role_corps() :: #role_corps{}.


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        军团uid
%% @end
%% ----------------------------------------------------
-spec get_corps_uid(role_corps()) -> integer().
get_corps_uid(#role_corps{corps_uid = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%        军团退出时间
%% @end
%% ----------------------------------------------------
-spec get_exit_time(role_corps()) -> integer().
get_exit_time(#role_corps{exit_time = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%        军团加入时间
%% @end
%% ----------------------------------------------------
-spec get_enter_time(role_corps()) -> integer().
get_enter_time(#role_corps{enter_time = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%        军团贡献值
%% @end
%% ----------------------------------------------------
-spec get_contribute(role_corps()) -> {integer(), list()}.
get_contribute(#role_corps{contribute = Value}) ->
    Value.

%%-------------------------------------------------------------------
%% @doc
%%      获取捐献次数 根据传入的类型获取对应的捐献次数
%% @end
%%-------------------------------------------------------------------
-spec get_ctb_times(role_corps(), integer(), atom()) -> integer().
get_ctb_times(#role_corps{ctb_times = {Times, Day}}, Day, Type) ->
    NTimes = if
        is_integer(Times) ->%%老数据处理，因为之前只存了元宝捐献次数，所以这里检查类型，如果是老数据就修正为新的数据格式
            [{rmb, Times}];
        true ->
            Times
    end,
    z_lib:get_value(NTimes, Type, 0);
get_ctb_times(_, _, _) ->
    0.

%%-------------------------------------------------------------------
%% @doc
%%      获取所有类型的捐献次数
%% @end
%%-------------------------------------------------------------------
get_all_ctb_times(#role_corps{ctb_times = {Times, Day}}, Day) ->
    if
        is_integer(Times) ->%%老数据处理，因为之前只存了元宝捐献次数，所以这里检查类型，如果是老数据就修正为新的数据格式
            [{rmb, Times}];
        true ->
            Times
    end;
get_all_ctb_times(_, _) ->
    [].

%% ----------------------------------------------------
%% @doc
%%        军团职位
%% @end
%% ----------------------------------------------------
-spec get_position(role_corps()) -> corps:position().
get_position(#role_corps{corps_uid = CorpsUid, position = Value}) ->
    if
        CorpsUid > 0 ->
            if
                Value > ?CORPS_POSITION_NORMAL_E ->
                    ?CORPS_POSITION_NORMAL_E;
                true ->
                    Value
            end;
        true ->
            Value
    end.

%% ----------------------------------------------------
%% @doc
%%        军团申请列表
%% @end
%% ----------------------------------------------------
-spec get_requests(role_corps()) -> corps:requests().
get_requests(#role_corps{requests = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%        军团邀请列表
%% @end
%% ----------------------------------------------------
-spec get_invites(role_corps()) -> corps:invites().
get_invites(#role_corps{invites = Value}) ->
    Value.

%% ----------------------------------------------------
%% @doc
%%        军团贡献值
%% @end
%% ----------------------------------------------------
-spec set_contribute(role_corps(), {integer(), list()}) -> role_corps().
set_contribute(RoleCorps, Value) ->
    RoleCorps#role_corps{contribute = Value}.

%%-------------------------------------------------------------------
%% @doc
%%      设置捐献次数
%% @end
%%-------------------------------------------------------------------
set_ctb_times(RoleCorps, Times, Day, Type) ->
    AllTimes = get_all_ctb_times(RoleCorps, Day),
    NAllTimes = lists:keystore(Type, 1, AllTimes, {Type, Times}),
    RoleCorps#role_corps{ctb_times = {NAllTimes, Day}}.
%% ----------------------------------------------------
%% @doc
%%        军团职位
%% @end
%% ----------------------------------------------------
-spec set_position(role_corps(), corps:position()) -> role_corps().
set_position(RoleCorps, Value) ->
    RoleCorps#role_corps{position = Value}.

%% ----------------------------------------------------
%% @doc
%%        军团申请列表
%% @end
%% ----------------------------------------------------
-spec set_requests(role_corps(), corps:requests()) -> role_corps().
set_requests(RoleCorps, Value) ->
    RoleCorps#role_corps{requests = Value}.


%% ----------------------------------------------------
%% @doc
%%        军团邀请列表
%% @end
%% ----------------------------------------------------
-spec set_invites(role_corps(), corps:invites()) -> role_corps().
set_invites(RoleCorps, Value) ->
    RoleCorps#role_corps{invites = Value}.

%% ----------------------------------------------------
%% @doc
%%        离开时间
%% @end
%% ----------------------------------------------------
-spec set_exit_time(role_corps(), integer()) -> role_corps().
set_exit_time(RoleCorps, Value) ->
    RoleCorps#role_corps{exit_time = Value}.


%% ----------------------------------------------------
%% @doc
%%        加入军团
%% @end
%% ----------------------------------------------------
-spec enter(role_corps(), integer(), corps:position()) -> role_corps().
enter(RoleCorps, CorpsUID, Position) ->
    RoleCorps#role_corps{corps_uid = CorpsUID, enter_time = time_lib:now_second(), requests = [],
        position = Position, invites = []}.
%% ----------------------------------------------------
%% @doc
%%        离开军团
%% @end
%% ----------------------------------------------------
-spec exit(role_corps()) -> role_corps().
exit(RoleCorps) ->
    RoleCorps#role_corps{corps_uid = 0, exit_time = time_lib:now_second(), requests = [], invites = [], position = ?CORPS_POSITION_NONE, contribute = {0, []}}.


%% ----------------------------------------------------
%% @doc
%%        初始化
%% @end
%% ----------------------------------------------------
-spec init() -> role_corps().
init() ->
    #role_corps{}.


%% ----------------------------------------------------
%% @doc
%%        设置是否第一次加入军团
%% @end
%% ----------------------------------------------------
-spec set_is_first(role_corps(), integer()) -> role_corps().
set_is_first(RoleCorps, Value) ->
    RoleCorps#role_corps{is_first = Value}.

%% ----------------------------------------------------
%% @doc
%%        获取是否第一次加入军团
%% @end
%% ----------------------------------------------------
-spec get_is_first(role_corps()) -> integer().
get_is_first(#role_corps{is_first = Value}) ->
    Value.
%%-------------------------------------------------------------------
%% @doc
%%      获取铜币捐献次数
%% @end
%%-------------------------------------------------------------------
-spec get_ctb_money_times(role_corps(), integer()) -> integer().
get_ctb_money_times(#role_corps{ctb_money_times = {Times, Day}}, Day) ->
    Times;
get_ctb_money_times(_, _) ->
    0.
%%-------------------------------------------------------------------
%% @doc
%%      获取元宝捐献次数
%% @end
%%-------------------------------------------------------------------
-spec get_ctb_rmb_times(role_corps(), integer()) -> integer().
get_ctb_rmb_times(#role_corps{ctb_rmb_times = {Times, Day}}, Day) ->
    Times;
get_ctb_rmb_times(_, _) ->
    0.

%%-------------------------------------------------------------------
%% @doc
%%      设置铜币捐献次数
%% @end
%%-------------------------------------------------------------------
-spec set_ctb_money_times(role_corps(), integer(), integer()) -> role_corps().
set_ctb_money_times(RoleCorps, Times, Day) ->
    RoleCorps#role_corps{ctb_money_times = {Times, Day}}.
%%-------------------------------------------------------------------
%% @doc
%%      设置捐献次数
%% @end
%%-------------------------------------------------------------------
-spec set_ctb_rmb_times(role_corps(), integer(), integer()) -> role_corps().
set_ctb_rmb_times(RoleCorps, Times, Day) ->
    RoleCorps#role_corps{ctb_rmb_times = {Times, Day}}.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
