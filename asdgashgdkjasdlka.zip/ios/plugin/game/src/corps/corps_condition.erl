-module(corps_condition).

%%%=======================STATEMENT====================
-description("corps_conditoin").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([init/0, update/2]).
-export([get_enter_flag/1, get_request_flag/1, get_request_castle_lv/1, get_request_role_lv/1, get_requst_conditons/1, format/1]).
-export_type([corps_condition/0]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(corps_condition, {
    enter_flag = 0 :: 0|1,%%入团设置(0:需要批准 1:无需批准)
    request_flag = 0 :: 0|1,%%申请设置(0:都可申请,1:满足条件可申请)
    request_role_lv = 0 :: integer(),%%需要主公等级
    request_castle_lv = 0 :: integer() %需要大殿等级
}).
%%%=======================TYPE=========================
-type corps_condition() :: #corps_condition{}.


%%%=================EXPORTED FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%        
%% @end
%% ----------------------------------------------------
%%-spec my_function(Args1::integer()) -> integer().
init() ->
    #corps_condition{}.
update(CorpsCondition, {EnterFlag, RequestFlag, RequestRoleLv, RequestMBLv}) ->
    CorpsCondition#corps_condition{enter_flag = EnterFlag, request_flag = RequestFlag, request_castle_lv = RequestMBLv, request_role_lv = RequestRoleLv}.

get_enter_flag(#corps_condition{enter_flag = V}) -> V.
get_request_flag(#corps_condition{request_flag = V}) -> V.
get_request_castle_lv(#corps_condition{request_castle_lv = V}) -> V.
get_request_role_lv(#corps_condition{request_role_lv = V}) -> V.

get_requst_conditons(#corps_condition{request_flag = RFlag, request_castle_lv = MBLv, request_role_lv = RoleLv}) ->
    case RFlag =:= 0 of
        true ->
            [];
        false ->
            CList1 = case MBLv > 0 of
                true ->
                    [{'castle_level', MBLv}];
                false ->
                    []
            end,
            CList2 = case RoleLv > 0 of
                true ->
                    [{'role_level', RoleLv}];
                false ->
                    []
            end,
            CList1 ++ CList2
    end.

%%-------------------------------------------------------------------
%% @doc
%%    格式化
%% @end
%%-------------------------------------------------------------------
format(#corps_condition{enter_flag = EnterFlag, request_flag = RequestFlag, request_castle_lv = RequestMBLv, request_role_lv = RequestRoleLv}) ->
    {EnterFlag, RequestFlag, RequestRoleLv, RequestMBLv}.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------


