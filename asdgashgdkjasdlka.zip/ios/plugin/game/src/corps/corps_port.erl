-module(corps_port).

%%%=======================STATEMENT====================
-description("corps_port").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    create/5,
    change_banner/5,
    request/5,
    cancel_request/5,
    check_request/5,
    trans_position/5,
    set_position/5,
    quit/5, kickout/5,
    invite/5,
    check_invite/5,
    get_corps_member/5,
    get_corps_log/5,
    set_notice/5,
    replace_owner/5,
    set_condition/5,
    change_name/5
]).
-export([
    get_recommends/5,
    get_base/5,
    get_other/5,
    get_corps_requests/5,
    get_invite_role_list/5,
    get_role_invite_list/5,
    search_by_name/5,
    search_rank/5,
    get_condition/5,
    get_corps_show/5,
    get_corps_donate_num/5
]).
-export([
    get_corps_town/5,
    abandon_town/5,
    cancel_abandon_town/5,
    abandon_town_assist/5
]).
-export([get_corps_gift_info/5, corps_gift/5, position_award/5]).
-export([award_first_enter_corps/5, donate/5]).
-export([request_help/5, get_help/5, help_other/5]).

-export([
    ally_request/5,
    ally_reply/5,
    ally_get_request/5,
    ally_delete/5,
    ally_search_by_name/5,
    ally_get_corps_info/5
]).
%%%=======================INCLUDE======================
-include("../include/corps.hrl").
-include("../include/rank.hrl").
-include("../include/money.hrl").
-include("../include/building.hrl").
-include("../include/point.hrl").
%%%=======================DEFINE======================
-define(MAX_RECOMMENDS_COUNT, 40).      %% 最大请求推荐个数
-define(SEARCH_MAX_NUM, 100).       %%搜索到的最大个数
-define(SEARCH_RANDOM_NUM, 50).     %%随机显示个数
%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%        获取军团赠送信息
%% @end
%% ----------------------------------------------------
get_corps_gift_info(_A, _Session, Attr, Info, _Msg) ->
    io:format("get_corps_gift_info:~p~n",[_Msg]),
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    %%GiftRoleUid = list_to_integer(z_lib:get_value(Msg, "role_uid", "0")),
    Table = game_lib:get_table(Src, 'corps_gift'),
    {_, SelfSendNum, _GetNum} = corps_lib:refresh_corps_gift_info(z_db_lib:get(Table, RoleUid, 'none')),
    %%{{_, _GiftRoleSendNum, GiftRoleGetNum} = corps_lib:refresh_corps_gift_info(z_db_lib:get(Table, GiftRoleUid, 'none')),
    Role = role_db:get_role(Src, RoleUid),
    %%{_, MaxGetNum} = zm_config:get('corps', 'corps_gift_get_num'),
    {ok, [], Info, [{msg, {vip_lib:get_corps_gift_send_num(Role), SelfSendNum}}]}.
%% ----------------------------------------------------
%% @doc
%%        军团赠送
%% @end
%% ----------------------------------------------------
corps_gift([{M, F, A}], _Session, Attr, Info, Msg) ->
    io:format("~p~n",[corps_gift]),
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    GiftRoleUid = list_to_integer(z_lib:get_value(Msg, "role_uid", "0")),
    PropList = game_lib:parse_props(z_lib:get_value(Msg, "props", "")),
    CheckVaild = valid_lib:check_valib([{'unequal', PropList, []}]),
    if
        CheckVaild ->
            {_, Conditions} = zm_config:get('corps', 'corps_gift_condition'),
            case game_lib:checks({corps_lib, check}, {Src, RoleUid, PropList}, 'corps_gift', Conditions) of
                true ->
                    RoleCorps = corps_db:get_role_corps(Src, RoleUid),
                    CorpsUid = role_corps:get_corps_uid(RoleCorps),
                    TableName = game_lib:get_table(Src),
                    TableKeys = z_db_lib:transformation_tablekey(TableName,
                                                                 [
                                                                     {'corps_gift', RoleUid, 'none'},
                                                                     {'corps_gift', GiftRoleUid, 'none'},
                                                                     {'corps_member', CorpsUid},
                                                                     {'goods', RoleUid}
                                                                 ]),
                    Reply = case z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, GiftRoleUid, PropList}, TableKeys) of
                                {ok, Consumes} ->
                                    ShowRole = role_db:get_role_show(Src, RoleUid),
                                    RoleName = role_show:get_name(ShowRole),
                                    Fun = fun({Sid, Num}, Award_) ->
                                        [{prop, {Sid, Num}} | Award_]
                                          end,
                                    Award = lists:foldl(Fun, [], PropList),
                                    STime = time_lib:now_second(),
                                    ETime = STime + 86400 * 3,
                                    Title = game_lib:get_language('corps_gift_title'),
                                    Content = game_lib:get_language('corps_gift_content', [RoleName]),
                                    Source = game_lib:get_language({'corps_mail_source', role_corps:get_position(RoleCorps)}, [RoleName]),
                                    MailType = award_source:get_source(?MODULE),
                                    %%TODO 用数字
                                    Mail = mail:init({Source, MailType, STime, ETime, {0, Title}, {0, Content}, Award}),
                                    mail_db:send(Src, GiftRoleUid, Mail),
                                    zm_event:notify(Src, 'bi_corps_gift', [{'role_uid', RoleUid}, {'gift_role_uid', GiftRoleUid}, {'consumes', Consumes}]),
                                    "ok";
                                Reasion1 ->
                                    Reasion1
                            end,
                    {ok, [], Info, [{msg, Reply}]};
                Reasion2 ->
                    {ok, [], Info, [{msg, Reasion2}]}
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.
%% ----------------------------------------------------
%% @doc
%%        没有军团的玩家请求推荐
%% @end
%% ----------------------------------------------------
get_recommends(_A, _Session, Attr, Info, Msg) ->
    io:format("~p~n",[get_recommends]),
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    CorpsUid = role_show:get_corps_uid(RoleShow),
    Country = role_lib:get_country(Attr),
    Num = z_lib:get_value(Msg, "num", 20),
    CUid = list_to_integer(z_lib:get_value(Msg, "cuid", "0")),
    CheckVaild = valid_lib:check_valib([{'range', Num, {1, ?MAX_RECOMMENDS_COUNT}}, {'equal', CorpsUid, 0}, {'ge', CUid, 0}]),
    if
        CheckVaild ->
            CheckEnter = corps_lib:check_enter(Src, RoleShow),
            CCorps = if
                         CUid > 0 ->
                             corps_db:get_corps(Src, CUid);
                         true ->
                             'none'
                     end,
            case CheckEnter =/= true orelse (CUid =/= 0 andalso CCorps =/= 'none' andalso corps:get_country(CCorps) =/= Country) of
                true ->
                    {ok, [], Info, [{msg, "error_input"}]};
                false ->
                    RoleCorps = corps_db:get_role_corps(Src, RoleUid),
                    ExitTime = role_corps:get_exit_time(RoleCorps),
                    RequestUids = corps_lib:get_request_uids(role_corps:get_requests(RoleCorps)),
                    Num1 = Num div 2,
                    Uids1 = game_lib:random_list(rank_get:get_rank_uids(Src, z_lib:get_value(?COUNTRY_CORPS_LV_RANK, Country, 0), 1, 30) -- RequestUids, Num1),
                    NewCorpsUidList = (corps_db:get_new_corps_uids(Src, Country) -- Uids1) -- RequestUids,
                    Uids2 = game_lib:random_list(NewCorpsUidList, Num - Num1),
                    CorpsUids =
                        case CUid > 0 of
                            true ->
                                if
                                    CCorps =:= 'none' ->
                                        CUids = game_lib:random_order(Uids2 ++ Uids1) ++ RequestUids,
                                        lists:delete(CUid, CUids);
                                    true ->
                                        CUids = game_lib:random_order(Uids2 ++ Uids1) ++ RequestUids,
                                        case lists:member(CUid, CUids) of
                                            true ->
                                                [CUid | lists:delete(CUid, CUids)];
                                            false ->
                                                lists:sublist([CUid | CUids], Num)
                                        end
                                end;
                            false ->
                                game_lib:random_order(Uids2 ++ Uids1) ++ RequestUids
                        end,
                    Reply =
                        if
                            CorpsUids =:= [] ->
                                {{}, list_to_tuple(RequestUids), ExitTime};
                            true ->
                                CorpsList = corps_db:get_corps_list(Src, CorpsUids),
                                %%TODO 容错处理
%%                        CorpsViews = [corps_lib:format_recommend_view(Src, Cps) || Cps <- CorpsList, Cps =/= 'none'],
                                CorpsViews = [corps_lib:format_recommend_view(Src, Cps) || Cps <- CorpsList],
                                {list_to_tuple(CorpsViews), list_to_tuple(RequestUids), ExitTime}
                        end,
                    {ok, [], Info, [{msg, Reply}]}
            end;
        true ->
            {ok, [], Info, [{msg, "corps_was_in"}]}
    end.


%% ----------------------------------------------------
%% @doc
%%        军团基础信息
%% @end
%% ----------------------------------------------------
get_base(_A, _Session, Attr, Info, _Msg) ->
    io:format("~p~n",[get_base]),
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    RoleCorps = corps_db:get_role_corps(Src, RoleUid),
    Reply = corps_lib:get_base_view(Src, RoleUid, RoleCorps),
    io:format("Reply:~p~n",[Reply]),
    {ok, [], Info, [{msg, Reply}]}.

%% ----------------------------------------------------
%% @doc
%%        其他军团信息
%% @end
%% ----------------------------------------------------
get_other(_A, _Session, _Attr, Info, Msg) ->
    io:format("~p~n",[get_other]),
    Src = z_lib:get_value(Info, src, none),
    CorpsUid = list_to_integer(z_lib:get_value(Msg, "uid", "0")),
    if
        CorpsUid > 0 ->
            Reply = corps_lib:get_other_view(Src, CorpsUid),
            {ok, [], Info, [{msg, Reply}]};
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%        军团申请信息
%% @end
%% ----------------------------------------------------
get_corps_requests(_A, _Session, Attr, Info, _Msg) ->
    io:format("~p~n",[get_corps_requests]),
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    RoleCorps = corps_db:get_role_corps(Src, RoleUid),
    CorpsUid = role_corps:get_corps_uid(RoleCorps),
    if
        CorpsUid =/= 0 ->
            case corps_lib:check_position_limit('check_request', role_corps:get_position(RoleCorps)) of
                true ->
                    RoleUids = corps_lib:get_request_uids(corps_db:get_corps_request(Src, CorpsUid)),
                    R = list_to_tuple(lists:map(fun(Uid) -> corps_lib:get_request_view(Src, Uid) end, RoleUids)),
                    {ok, [], Info, [{msg, R}]};
                Err ->
                    {ok, [], Info, [{msg, Err}]}
            end;
        true ->
            {ok, [], Info, [{msg, "corps_not_in"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%        军团成员列表
%% @end
%% ----------------------------------------------------
get_corps_member(_A, _Session, Attr, Info, _Msg) ->
    io:format("~p~n",[get_corps_member]),
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    CorpsUid = role_show:get_corps_uid(role_db:get_role_show(Src, RoleUid)),
    if
        CorpsUid =/= 0 ->
            RoleUidList = corps_db:get_corps_members(Src, CorpsUid),
            R = list_to_tuple(lists:map(fun(Uid) -> corps_lib:get_member_view(Src, Uid) end, RoleUidList)),
            {ok, [], Info, [{msg, R}]};
        true ->
            {ok, [], Info, [{msg, "corps_not_in"}]}
    end.
%% ----------------------------------------------------
%% @doc
%%        军团日志
%% @end
%% ----------------------------------------------------
get_corps_log(_A, _Session, Attr, Info, Msg) ->
    io:format("~p~n",[get_corps_log]),
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    LogType = z_lib:get_value(Msg, "type", 0),
    Start = z_lib:get_value(Msg, "s", 1),
    End = z_lib:get_value(Msg, "e", 20),
    CheckVaild = valid_lib:check_valib([{'gt', LogType, 0}, {'gt', Start, 0}, {'gt', End, Start}]),
    if
        CheckVaild ->
            CorpsUid = role_show:get_corps_uid(role_db:get_role_show(Src, RoleUid)),
            if
                CorpsUid =/= 0 ->
                    CorpsLogs = corps_db:get_corps_log(Src, CorpsUid, LogType),
                    NCorpsLogs =
                        case Start > length(CorpsLogs) of
                            true ->
                                [];
                            false ->
                                lists:sublist(CorpsLogs, Start, End - Start + 1)
                        end,
%%                    NCorpsLogs = case catch lists:sublist(CorpsLogs, Start, End - Start + 1) of
%%                        {'EXIT', _} ->
%%                            CorpsLogs;
%%                        Ls ->
%%                            Ls
%%                    end,
                    {ok, [], Info, [{msg, list_to_tuple(NCorpsLogs)}]};
                true ->
                    {ok, [], Info, [{msg, "corps_not_in"}]}
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%        军团得到邀请玩家列表信息
%% @end
%% ----------------------------------------------------
get_invite_role_list(_A, _Session, Attr, Info, Msg) ->
    io:format("~p~n",[get_invite_role_list]),
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    Name = z_lib:get_value(Msg, "name", ""),
    RoleCorps = corps_db:get_role_corps(Src, RoleUid),
    CorpsUid = role_corps:get_corps_uid(RoleCorps),
    if
        CorpsUid =/= 0 ->
            case corps_lib:check_position_limit('invite_role', role_corps:get_position(RoleCorps)) of
                true ->
                    RoleShow = role_db:get_role_show(Src, RoleUid),
                    Country = role_show:get_country(RoleShow),
                    {_, Num, Rules} = zm_config:get('corps', 'invite_list_rule'),
                    RoleUidList =
                        if
                            Name =:= "" orelse Name =:= 'none' ->
                                InviteRoleUidList = corps_lib:get_invite_uids(corps_db:get_corps_invites(Src, CorpsUid)),
                                Fun = fun({R, N, T}, {List, N1}) ->
                                    N2 = N + N1,
                                    AddUidList = game_lib:random_list(corps_db:get_corps_mf_level_list(Src, List, Country) -- InviteRoleUidList, N2),
                                    NR = R ++ AddUidList,
                                    AddLen = length(AddUidList),
                                    NT = T + AddLen,
                                    case NT >= Num of
                                        true ->
                                            {break, {NR, N2 - AddLen, NT}};
                                        false ->
                                            {ok, {NR, N2 - AddLen, NT}}
                                    end
                                      end,
                                element(1, z_lib:foreach(Fun, {[], 0, 0}, Rules));
                            true ->
                                Table = game_lib:get_table(Src, role_name),
                                Fun = fun(_, Key, _, R) ->
                                    case string_lib:string_with_exist(Name, Key) of
                                        true ->
                                            RUid = z_db_lib:get(Table, Key),
                                            RShow = role_db:get_role_show(Src, RUid),
                                            case role_show:get_country(RShow) =:= Country andalso
                                                 role_show:get_corps_uid(RShow) =:= 0 andalso
                                                corps_lib:check_enter(Src, RShow) =:= true of
                                                true ->
                                                    {N, Ls} = R,
                                                    NN = N + 1,
                                                    if
                                                        NN >= Num * 2 ->
                                                            {break, {NN, [RUid | Ls]}};
                                                        true ->
                                                            {ok, {NN, [RUid | Ls]}}
                                                    end;
                                                false ->
                                                    {ok, R}
                                            end;
                                        false ->
                                            {ok, R}
                                    end
                                      end,
                                element(2, z_db_lib:table_iterate(Src, Table, Fun, [], {0, []}))
                        end,
                    Reply = list_to_tuple([corps_lib:get_invite_role_view(Src, RUid) || RUid <- game_lib:random_order(game_lib:random_list(RoleUidList, Num))]),
                    {ok, [], Info, [{msg, Reply}]};
                Err ->
                    {ok, [], Info, [{msg, Err}]}
            end;
        true ->
            {ok, [], Info, [{msg, "corps_not_in"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%        玩家得到邀请自己的军团列表信息
%% @end
%% ----------------------------------------------------
get_role_invite_list(_A, _Session, Attr, Info, _Msg) ->
    io:format("~p~n",[get_role_invite_list]),
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    RoleCorps = corps_db:get_role_corps(Src, RoleUid),
    CorpsUid = role_corps:get_corps_uid(RoleCorps),
    if
        CorpsUid =:= 0 ->
            CorpsUidList = corps_lib:get_invite_uids(role_corps:get_invites(RoleCorps)),
            Reply = list_to_tuple([corps_lib:get_role_invite_view(Src, CUid) || CUid <- CorpsUidList]),
            {ok, [], Info, [{msg, Reply}]};
        true ->
            {ok, [], Info, [{msg, "corps_was_in"}]}
    end.
%% ----------------------------------------------------
%% @doc  
%%        创建军团
%% @end
%% ----------------------------------------------------
create([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    Country = role_lib:get_country(Attr),
    Name = z_lib:get_value(Msg, "name", none),
    Banner = z_lib:get_value(Msg, "banner", 0),
    CheckVaild = valid_lib:check_valib([{'unequal', Name, none}]),
    case CheckVaild andalso corps_lib:check_banner(Banner) of
        true ->
            case role_lib:check_input_name(Src, Name) of
                {true, NName} ->
                    TableName = game_lib:get_table(Src),
                    TableKeys = z_db_lib:transformation_tablekey(TableName, [
                        {'role_corps', RoleUid, role_corps:init()},
                        {'corps_name', NName},
                        {'role', RoleUid},
                        {'rmb', RoleUid, rmb_lib:init()}
                    ]),

                    case z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, NName, Banner, Country}, TableKeys) of
                        {ok, CorpsUid, Corps, RoleRequests, Consumes, OwnerName} ->
                            NRoleRequests = corps_lib:get_requests(RoleRequests),
                            zm_log:info(Src, ?MODULE, 'create', "corps_create", [{'roleuid', RoleUid}, {'corps', Corps}, {'consume', Consumes}]),
                            zm_event:notify(Src, 'corps_create', [{'role_uid', RoleUid}, {'corps_uid', CorpsUid}, {'consumes', Consumes}, {'corps', Corps},
                                                                  {'country', corps:get_country(Corps)}, {'role_requests', NRoleRequests}]),
                            BKey = {'corps_create', Country},
                            BArgs = [CorpsUid, Country, OwnerName, NName],
                            chat_lib:notice_world(Src, BKey, BArgs),
                            chat_lib:notice_country(Src, BKey, BArgs, Country),
                            {ok, [], Info, [{msg, CorpsUid}]};
                        Err ->
                            {ok, [], Info, [{msg, Err}]}
                    end;
                {_, Reply} ->
                    {ok, [], Info, [{msg, Reply}]}
            end;
        _ ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%        修改旗帜
%% @end
%% ----------------------------------------------------
change_banner([{M, F, A}], _Session, Attr, Info, Msg) ->
    io:format("~p~n",[change_banner]),
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    Banner = z_lib:get_value(Msg, "banner", 0),
    case corps_lib:check_banner(Banner) of
        true ->
            RoleCorps = corps_db:get_role_corps(Src, RoleUid),
            CorpsUid = role_corps:get_corps_uid(RoleCorps),
            if
                CorpsUid =/= 0 ->
                    case corps_lib:check_position_limit('change_banner', role_corps:get_position(RoleCorps)) of
                        true ->
                            TableName = game_lib:get_table(Src),
                            TableKeys = z_db_lib:transformation_tablekey(TableName,
                                                                         [
                                                                             {'corps', CorpsUid, 'none'},
                                                                             {'rmb', RoleUid, rmb_lib:init()}
                                                                         ]),
                            case z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, Banner}, TableKeys) of
                                {ok, Corps, Cs} ->
                                    zm_event:notify(Src, 'corps_change_banner', [{'role_uid', RoleUid}, {'corps_uid', CorpsUid}, {'consumes', Cs}, {'corps', Corps}, {'banner', Banner}]),
                                    {ok, [], Info, [{msg, ok}]};
                                Err ->
                                    {ok, [], Info, [{msg, Err}]}
                            end;
                        Err ->
                            {ok, [], Info, [{msg, Err}]}
                    end;
                true ->
                    {ok, [], Info, [{msg, "corps_not_in"}]}
            end;
        false ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%        玩家申请加入军团
%% @end
%% ----------------------------------------------------
request([{M, F, A}], _Session, Attr, Info, Msg) ->
    io:format("~p~n",[request]),
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    CorpsUid = list_to_integer(z_lib:get_value(Msg, "cuid", "0")),
    CheckVaild = valid_lib:check_valib([{'unequal', CorpsUid, 0}]),
    if
        CheckVaild ->
            RoleShow = role_db:get_role_show(Src, RoleUid),
            RoleCountry = role_show:get_country(RoleShow),
            Corps = corps_db:get_corps(Src, CorpsUid),
            if
                Corps =:= 'none' ->
                    {ok, [], Info, [{msg, "corps_not_find"}]};
                true ->
                    case corps_lib:check_enter(Src, RoleShow, Corps) of
                        true ->
                            case corps:get_country(Corps) =:= RoleCountry of
                                true ->
                                    InCrossBattle = cross_battle_db:check_corps_in_cross_battle(Src, CorpsUid),
                                    TableName = game_lib:get_table(Src),
                                    TableKeys = z_db_lib:transformation_tablekey(TableName,
                                                                                 [
                                                                                     {'corps', CorpsUid, 'none'},
                                                                                     {'corps_request', CorpsUid, []},
                                                                                     {'role_corps', RoleUid, role_corps:init()},
                                                                                     {'corps_member', CorpsUid}
                                                                                 ]),
                                    Now = time_lib:now_second(),
                                    Reply =
                                        case z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, CorpsUid, Now, args_system:get_online_time(Src), InCrossBattle}, TableKeys) of
                                            {'request', NCorps} ->
                                                set_front_lib:send_corps_request(Src, NCorps, RoleUid),
                                                {0};
                                            {'enter', NCorps, RoleRequests} ->
                                                NRoleRequests = corps_lib:get_requests(RoleRequests),
                                                zm_event:notify(Src, 'corps_request_enter', [{'role_uid', RoleUid}, {'corps_uid', CorpsUid},
                                                                                             {'corps', NCorps}, {'role_requests', NRoleRequests}]),

                                                CorpsTown = corps_db:get_corps_town(Src, CorpsUid),
                                                TFun = fun(R, {TSid, _}) ->
                                                    Town = z_db_lib:get(game_lib:get_table(Src, 'town'), TSid, town:init(TSid)),
                                                    {_, STime, _} = town:get_state(Town),
                                                    {ok, [{TSid, STime} | R]}
                                                       end,
                                                FTSidSTimeList1 = z_lib:foreach(TFun, [], corps_town:get_flist(CorpsTown)),
                                                FTSidSTimeList = z_lib:foreach(TFun, FTSidSTimeList1, corps_town:get_cflist(CorpsTown)),
                                                {1, {CorpsUid, list_to_tuple(FTSidSTimeList)}};
                                            Other ->
                                                Other
                                        end,
                                    {ok, [], Info, [{msg, Reply}]};
                                false ->
                                    {ok, [], Info, [{msg, "corps_request_only_country"}]}
                            end;
                        Err ->
                            {ok, [], Info, [{msg, Err}]}
                    end
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%        邀请玩家加入军团
%% @end
%% ----------------------------------------------------
invite([{M, F, A}], _Session, Attr, Info, Msg) ->
    io:format("~p~n",[invite]),
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    RUids = [list_to_integer(SUid) || SUid <- string:tokens(z_lib:get_value(Msg, "ruids", ""), ",")],
    if
        RUids =/= [] ->
            RoleCorps = corps_db:get_role_corps(Src, RoleUid),
            CorpsUid = role_corps:get_corps_uid(RoleCorps),
            if
                CorpsUid =/= 0 ->
                    case cross_battle_db:check_corps_in_cross_battle(Src, CorpsUid) of
                        false ->
                            RoleCountry1 = role_lib:get_country(Attr),
                            case lists:all(fun(RUid) ->
                                role_show:get_country(role_db:get_role_show(Src, RUid)) =:= RoleCountry1
                                           end, RUids) of
                                true ->
                                    Position = role_corps:get_position(RoleCorps),
                                    case corps_lib:check_position_limit('invite_role', Position) of
                                        true ->
                                            Fun = fun(Args, RUid) ->
                                                case corps_lib:check_enter(Src, RUid) of
                                                    true ->
                                                        TableName = game_lib:get_table(Src),
                                                        TableKeys = z_db_lib:transformation_tablekey(TableName,
                                                                                                     [
                                                                                                         {'role_corps', RoleUid},
                                                                                                         {'corps', CorpsUid, 'none'},
                                                                                                         {'corps_invite', CorpsUid, []},
                                                                                                         {'role_corps', RUid, role_corps:init()}
                                                                                                     ]),
                                                        Reply = z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, RUid, CorpsUid}, TableKeys),
                                                        if
                                                            is_tuple(Reply) ->
                                                                set_front_lib:send_corps_invite(Src, CorpsUid, element(2, Reply), RUid),
                                                                {ok, [RUid | Args]};
                                                            Reply =:= 'ignore' ->
                                                                {ok, [RUid | Args]};
                                                            Reply =:= "corps_invite_num_limit" orelse Reply =:= "corps_member_num_limit" ->
                                                                {break, Args};
                                                            true ->
                                                                {ok, Args}
                                                        end;
                                                    _ ->
                                                        {ok, Args}
                                                end
                                                  end,
                                            InviteRUids = z_lib:foreach(Fun, [], RUids),
                                            {ok, [], Info, [{msg, list_to_tuple(InviteRUids)}]};
                                        Err ->
                                            {ok, [], Info, [{msg, Err}]}
                                    end;
                                false ->
                                    {ok, [], Info, [{msg, "corps_invote_only_country"}]}
                            end;
                        true ->
                            {ok, [], Info, [{msg, "corps_in_cross_battle"}]}
                    end;
                true ->
                    {ok, [], Info, [{msg, "corps_not_in"}]}
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.


%% ----------------------------------------------------
%% @doc
%%        同意拒绝军团邀请
%%          type : 0拒绝 1同意
%% @end
%% ----------------------------------------------------
check_invite([{M, F, A}], _Session, Attr, Info, Msg) ->
    io:format("~p~n",[check_invite]),
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    CorpsUid = list_to_integer(z_lib:get_value(Msg, "cuid", "0")),
    Type = z_lib:get_value(Msg, "type", 0),
    CheckVaild = valid_lib:check_valib([{'unequal', CorpsUid, 0}, {'range', Type, {0, 1}}]),
    if
        CheckVaild ->
            case Type =:= 0 orelse not cross_battle_db:check_corps_in_cross_battle(Src, CorpsUid) of
                true ->
                    TableName = game_lib:get_table(Src),
                    TableKeys = z_db_lib:transformation_tablekey(TableName,
                                                                 [
                                                                     {'role_corps', RoleUid, role_corps:init()},
                                                                     {'corps', CorpsUid, 'none'},
                                                                     {'corps_invite', CorpsUid, []},
                                                                     {'corps_member', CorpsUid}
                                                                 ]),
                    Reply =
                        case z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, CorpsUid, Type, args_system:get_online_time(Src)}, TableKeys) of
                            {ok, NCorps, RoleRequests} ->
                                NRoleRequests = corps_lib:get_requests(RoleRequests),
                                zm_event:notify(Src, 'corps_check_invite', [{'role_uid', RoleUid}, {'corps_uid', CorpsUid}, {'type', Type},
                                                                            {'corps', NCorps}, {'role_requests', NRoleRequests}]),
                                case Type =:= 0 of
                                    true ->
                                        {};
                                    false ->
                                        CorpsTown = corps_db:get_corps_town(Src, CorpsUid),
                                        TFun = fun(R, {TSid, _}) ->
                                            Town = z_db_lib:get(game_lib:get_table(Src, 'town'), TSid, town:init(TSid)),
                                            {_, STime, _} = town:get_state(Town),
                                            {ok, [{TSid, STime} | R]}
                                               end,
                                        FTSidSTimeList1 = z_lib:foreach(TFun, [], corps_town:get_flist(CorpsTown)),
                                        FTSidSTimeList = z_lib:foreach(TFun, FTSidSTimeList1, corps_town:get_cflist(CorpsTown)),
                                        list_to_tuple(FTSidSTimeList)
                                end;
                            Other ->
                                Other
                        end,
                    {ok, [], Info, [{msg, Reply}]};
                false ->
                    {ok, [], Info, [{msg, "corps_in_cross_battle"}]}
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%        玩家取消申请加入军团
%% @end
%% ----------------------------------------------------
cancel_request([{M, F, A}], _Session, Attr, Info, Msg) ->
    io:format("~p~n",[cancel_request]),
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    CorpsUid = list_to_integer(z_lib:get_value(Msg, "cuid", "0")),
    if
        CorpsUid =/= 0 ->
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName,
                                                         [
                                                             {'corps', CorpsUid, 'none'},
                                                             {'corps_request', CorpsUid, []},
                                                             {'role_corps', RoleUid, role_corps:init()}
                                                         ]),
            Reply =
                case z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, CorpsUid}, TableKeys) of
                    {ok, Corps} ->
                        set_front_lib:send_corps_cancel_request(Src, Corps, RoleUid),
                        ok;
                    Other ->
                        Other
                end,
            {ok, [], Info, [{msg, Reply}]};
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%        同意玩家申请加入军团
%%          type : 0拒绝 1同意
%% @end
%% ----------------------------------------------------
check_request([{M, F, A}], _Session, Attr, Info, Msg) ->
    io:format("~p~n",[check_request]),
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    RUids = [list_to_integer(SUid) || SUid <- string:tokens(z_lib:get_value(Msg, "ruids", ""), ",")],
    Type = z_lib:get_value(Msg, "type", 0),
    CheckVaild = valid_lib:check_valib([{'unequal', RUids, []}, {'range', Type, {0, 1}}]),
    if
        CheckVaild ->
            RoleCorps = corps_db:get_role_corps(Src, RoleUid),
            CorpsUid = role_corps:get_corps_uid(RoleCorps),
            if
                CorpsUid =/= 0 ->
                    case corps_lib:check_position_limit('check_request', role_corps:get_position(RoleCorps)) of
                        true ->
                            CRUids = corps_db:check_requests(Src, RoleUid, CorpsUid, M, F, A, Type, RUids),
                            {ok, [], Info, [{msg, list_to_tuple(CRUids)}]};
                        Err ->
                            {ok, [], Info, [{msg, Err}]}
                    end;
                true ->
                    {ok, [], Info, [{msg, "corps_not_in"}]}
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%         转让职位
%% @end
%% ----------------------------------------------------
trans_position([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RUid = list_to_integer(z_lib:get_value(Msg, "ruid", "0")),
    RoleUid = role_lib:get_uid(Attr),
    RoleCorps = corps_db:get_role_corps(Src, RoleUid),
    CorpsUid = role_corps:get_corps_uid(RoleCorps),
    if
        CorpsUid =/= 0 ->
            case corps_lib:check_position_limit('trans_position', role_corps:get_position(RoleCorps)) of
                true ->
                    case not cross_battle_db:check_corps_in_cross_battle(Src, CorpsUid) of
                        true ->
                            TableName = game_lib:get_table(Src),
                            TableKeys = z_db_lib:transformation_tablekey(TableName,
                                                                         [
                                                                             {'role_corps', RoleUid, role_corps:init()},
                                                                             {'role_corps', RUid, role_corps:init()},
                                                                             {'corps', CorpsUid}
                                                                         ]),
                            Reply =
                                case z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, RUid}, TableKeys) of
                                    {ok, Corps, OldPos, NewPos} ->
                                        zm_event:notify(Src, 'corps_trans_position', [{'role_uid', RoleUid}, {'ruid', RUid}, {'corps_uid', CorpsUid},
                                                                                      {'role_corps', RoleCorps}, {'corps', Corps}, {'old_pos', OldPos}, {'new_pos', NewPos}]),
                                        ok;
                                    Other ->
                                        Other
                                end,
                            {ok, [], Info, [{msg, Reply}]};
                        false ->
                            {ok, [], Info, [{msg, "corps_in_cross_battle"}]}
                    end;
                Err ->
                    {ok, [], Info, [{msg, Err}]}
            end;
        true ->
            {ok, [], Info, [{msg, "corps_not_in"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%         设置职位
%% @end
%% ----------------------------------------------------
set_position([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    Position = z_lib:get_value(Msg, "pos", ?CORPS_POSITION_NORMAL_E),
    RUid = list_to_integer(z_lib:get_value(Msg, "ruid", "0")),
    RoleUid = role_lib:get_uid(Attr),
    CheckVaild = valid_lib:check_valib([{'unequal', RUid, 0}, {'unequal', RUid, RoleUid},
                                        {'exist', Position, [?CORPS_POSITION_OWNER, ?CORPS_POSITION_VICE_OWNER, ?CORPS_POSITION_NORMAL_E]}]),
    if
        CheckVaild ->
            RoleCorps = corps_db:get_role_corps(Src, RoleUid),
            CorpsUid = role_corps:get_corps_uid(RoleCorps),
            if
                CorpsUid =/= 0 ->
                    case corps_lib:check_position_limit('set_position', role_corps:get_position(RoleCorps)) of
                        true ->
                            case not cross_battle_db:check_corps_in_cross_battle(Src, CorpsUid) of
                                true ->
                                    TableName = game_lib:get_table(Src),
                                    TableKeys = z_db_lib:transformation_tablekey(TableName,
                                                                                 [
                                                                                     {'role_corps', RoleUid, role_corps:init()},
                                                                                     {'role_corps', RUid, role_corps:init()},
                                                                                     {'corps', CorpsUid}
                                                                                 ]),
                                    Reply =
                                        case z_db_lib:handle(TableName, {M, F, A}, {Src, RUid, Position}, TableKeys) of
                                            {ok, Corps, OldPos} ->
                                                zm_event:notify(Src, 'corps_set_position', [{'role_uid', RoleUid}, {'ruid', RUid}, {'corps_uid', CorpsUid},
                                                                                            {'role_corps', RoleCorps}, {'corps', Corps}, {'old_pos', OldPos}, {'new_pos', Position}]),
                                                ok;
                                            Other ->
                                                Other
                                        end,
                                    {ok, [], Info, [{msg, Reply}]};
                                false ->
                                    {ok, [], Info, [{msg, "corps_in_cross_battle"}]}
                            end;
                        Err ->
                            {ok, [], Info, [{msg, Err}]}
                    end;
                true ->
                    {ok, [], Info, [{msg, "corps_not_in"}]}
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%         退出军团
%% @end
%% ----------------------------------------------------
quit([{M, F, A}], _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    CorpsUid = role_show:get_corps_uid(role_db:get_role_show(Src, RoleUid)),
    if
        CorpsUid =/= 0 ->
            IsCrossBattle = cross_battle_db:check_corps_in_wheel_cross_battle_ignore_state(Src, CorpsUid),
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName,
                                                         [
                                                             {'role_corps', RoleUid, role_corps:init()},
                                                             {'corps', CorpsUid},
                                                             {'corps_member', CorpsUid}
                                                         ]),
            Reply =
                case z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, IsCrossBattle}, TableKeys) of
                    {ok, NCorps, NCorpsMembers} ->
                        if
                            length(NCorpsMembers) =:= 0 ->
                                zm_event:notify(Src, 'corps_dissolve', [{'role_uid', RoleUid}, {'corps', NCorps}]);
                            true ->
                                zm_event:notify(Src, 'corps_role_quit', [{'role_uid', RoleUid}, {'corps_uid', CorpsUid}, {'corps_memeber', NCorpsMembers}, {'corps', NCorps}])
                        end,
                        corps_db:corps_help_quit_corps(Src, RoleUid, CorpsUid),
                        ok;
                    Other ->
                        Other
                end,
            {ok, [], Info, [{msg, Reply}]};
        true ->
            {ok, [], Info, [{msg, "corps_not_in"}]}
    end.


%% ----------------------------------------------------
%% @doc
%%         踢出军团
%% @end
%% ----------------------------------------------------
kickout([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    RUid = list_to_integer(z_lib:get_value(Msg, "ruid", "0")),
    if
        RUid =/= 0 ->
            RoleCorps = corps_db:get_role_corps(Src, RoleUid),
            CorpsUid = role_corps:get_corps_uid(RoleCorps),
            if
                CorpsUid =/= 0 ->
                    case corps_lib:check_position_limit('kickout', role_corps:get_position(RoleCorps)) of
                        true ->
                            case cross_battle_db:check_corps_in_cross_battle(Src, CorpsUid) of
                                false ->
                                    TableName = game_lib:get_table(Src),
                                    TableKeys = z_db_lib:transformation_tablekey(TableName,
                                                                                 [
                                                                                     {'role_corps', RoleUid},
                                                                                     {'role_corps', RUid, role_corps:init()},
                                                                                     {'corps', CorpsUid},
                                                                                     {'corps_member', CorpsUid}
                                                                                 ]),
                                    Reply =
                                        case z_db_lib:handle(TableName, {M, F, A}, {Src, RUid}, TableKeys) of
                                            {ok, NCorps, NCorpsMembers} ->
                                                zm_event:notify(Src, 'corps_kickout_role', [{'role_uid', RoleUid}, {'ruid', RUid},
                                                                                            {'corps_uid', CorpsUid}, {'role_corps', RoleCorps}, {'corps_member', NCorpsMembers}, {'corps', NCorps}]),
                                                corps_db:corps_help_quit_corps(Src, RoleUid, CorpsUid),
                                                ok;
                                            Other ->
                                                Other
                                        end,
                                    {ok, [], Info, [{msg, Reply}]};
                                true ->
                                    {ok, [], Info, [{msg, "corps_in_cross_battle"}]}
                            end;
                        Err ->
                            {ok, [], Info, [{msg, Err}]}
                    end;
                true ->
                    {ok, [], Info, [{msg, "corps_not_in"}]}
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%         设置公告(0:对内公告 1:对外公告)
%% @end
%% ----------------------------------------------------
set_notice([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    Type = z_lib:get_value(Msg, "type", 0),
    CheckVaild = valid_lib:check_valib([{'range', Type, {0, 1}}]),
    if
        CheckVaild ->
            Context = z_lib:get_value(Msg, "context", ""),
            case corps_lib:check_notice(Src, Context) of
                {ok, Notice} ->
                    RoleCorps = corps_db:get_role_corps(Src, RoleUid),
                    CorpsUid = role_corps:get_corps_uid(RoleCorps),
                    if
                        CorpsUid =/= 0 ->
                            PositionType = lists:nth(Type + 1, ['set_private_notice', 'set_public_notice']),
                            Position = role_corps:get_position(RoleCorps),
                            CheckPositionBool = corps_lib:check_position_limit(PositionType, Position),
                            if
                                CheckPositionBool ->
                                    TableName = game_lib:get_table(Src),
                                    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'corps_notice', CorpsUid, {0, "", 0, ""}}, {'role_corps', RoleUid, role_corps:init()}]),
                                    case z_db_lib:handle(TableName, {M, F, A}, {Src, CorpsUid, Notice, Type, PositionType}, TableKeys) of
                                        {ok, Time} ->
                                            CorpsMembers = corps_db:get_corps_members(Src, CorpsUid),
                                            if
                                                Type =:= 0 ->
                                                    set_front_lib:send_private_notice_time(Src, lists:delete(RoleUid, CorpsMembers), {Time, Notice});
                                                true ->
                                                    set_front_lib:send_publice_notice_time(Src, lists:delete(RoleUid, CorpsMembers), {Time, Notice})
                                            end,
                                            {ok, [], Info, [{msg, ok}]};
                                        Other ->
                                            {ok, [], Info, [{msg, Other}]}
                                    end;
                                true ->
                                    {ok, [], Info, [{msg, CheckPositionBool}]}
                            end;
                        true ->
                            {ok, [], Info, [{msg, "corps_not_in"}]}
                    end;
                Other ->
                    {ok, [], Info, [{msg, Other}]}
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.


%% ----------------------------------------------------
%% @doc
%%         根据名字模糊查找军团
%% @end
%% ----------------------------------------------------
search_by_name(_A, _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    Name = z_lib:get_value(Msg, "name", ""),
    Country = role_lib:get_country(Attr),
    case role_lib:check_input_name(Src, Name) of
        {true, NName} ->
            RoleUid = role_lib:get_uid(Attr),
            RoleShow = role_db:get_role_show(Src, RoleUid),
            case role_show:get_corps_uid(RoleShow) =:= 0 of
                true ->
                    CorpsUids1 = corps_db:search_by_name(Src, NName, Country),
                    CorpsUids2 = lists:sublist(CorpsUids1, ?SEARCH_MAX_NUM),
                    CorpsUids = game_lib:random_list(CorpsUids2, ?SEARCH_RANDOM_NUM),
                    Fun1 = fun(CorpsUid) ->
                        Corps = corps_db:get_corps(Src, CorpsUid),
                        corps_lib:format_recommend_view(Src, Corps)
                           end,
                    CorpsViews = lists:map(Fun1, CorpsUids),
                    {ok, [], Info, [{msg, list_to_tuple(CorpsViews)}]};
                false ->
                    {ok, [], Info, [{msg, "corps_was_in"}]}
            end;
        {_, Err} ->
            {ok, [], Info, [{msg, Err}]}
    end.

%% ----------------------------------------------------
%% @doc
%%         根据名字模糊查找军团排行榜
%% @end
%% ----------------------------------------------------
search_rank(_A, _Session, _Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    Name = z_lib:get_value(Msg, "name", ""),
    case role_lib:check_input_name(Src, Name) of
        {true, NName} ->
            Table = game_lib:get_table(Src, 'corps_name'),
            Fun = fun(_Src, Key, _, R) ->
                Check = string_lib:string_with_exist(NName, Key),
                if
                    Check ->
                        CorpsUid = z_db_lib:get(Table, Key, none),
                        if
                            CorpsUid =/= none ->
                                {ok, [CorpsUid | R]};
                            true ->
                                {ok, R}
                        end;
                    true ->
                        {ok, R}
                end
                  end,
            CorpsUidList = z_db_lib:table_iterate(Src, Table, Fun, [], []),
            {Ranks, RankViews} = rank_get:get_uid_ranks(Src, CorpsUidList, ?CORPS_INFLUENCE_ALL_RANK),
            {ok, [], Info, [{msg, {list_to_tuple(Ranks), list_to_tuple(RankViews)}}]};
        {_, Err} ->
            {ok, [], Info, [{msg, Err}]}
    end.

%% ----------------------------------------------------
%% @doc
%%         取代团长
%% @end
%% ----------------------------------------------------
replace_owner([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    RUid = list_to_integer(z_lib:get_value(Msg, "ruid", "0")),
    if
        RUid > 0 ->
            RShow = role_db:get_role_show(Src, RUid),
            CorpsUid1 = role_show:get_corps_uid(role_db:get_role_show(Src, RoleUid)),
            CorpsUid2 = role_show:get_corps_uid(RShow),
            if
                CorpsUid1 =:= CorpsUid2 andalso CorpsUid1 =/= 0 ->
                    case not cross_battle_db:check_corps_in_cross_battle(Src, CorpsUid1) of
                        true ->
                            case corps_db:get_replace_owner_roleuid(Src, CorpsUid1, corps_db:get_corps(Src, CorpsUid1)) of
                                {0, _} ->
                                    {ok, [], Info, [{msg, ok}]};
                                {MUid, Members} ->
                                    TableName = game_lib:get_table(Src),
                                    TableKeys = z_db_lib:transformation_tablekey(TableName, [
                                        {'corps', CorpsUid1},
                                        {'role_corps', MUid, role_corps:init()},
                                        {'role_corps', RUid, role_corps:init()},
                                        {'user', RUid}
                                    ]),
                                    case z_db_lib:handle(TableName, {M, F, A}, {Src, MUid, RUid}, TableKeys) of
                                        {ok, Corps} ->
                                            zm_log:info(Src, ?MODULE, 'replace_owner', "corps_replace_owner", [{'roleuid', RoleUid},
                                                                                                               {'ruid', RUid}, {'corps_uid', CorpsUid1}, {'new_owner', MUid}]),
                                            zm_event:notify(Src, 'corps_replace_owner', [{'type', 0}, {'role_uid', MUid}, {'ruid', RUid}, {'corps_uid', CorpsUid1},
                                                                                         {'corps', Corps}, {'members', Members}, {'role_name', role_show:get_name(role_db:get_role_show(Src, MUid))},
                                                                                         {'rname', role_show:get_name(RShow)}]),
                                            {ok, [], Info, [{msg, ok}]};
                                        Other ->
                                            {ok, [], Info, [{msg, Other}]}
                                    end
                            end;
                        false ->
                            {ok, [], Info, [{msg, "corps_in_cross_battle"}]}
                    end;
                true ->
                    {ok, [], Info, [{msg, "input_error"}]}
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      军团城池
%% @end
%% ----------------------------------------------------
get_corps_town(_, _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    CorpsUid = role_show:get_corps_uid(RoleShow),
    if
        CorpsUid =:= 0 ->
            {ok, [], Info, [{msg, "corps_not_in"}]};
        true ->
            AbandoningTownList = corps_db:get_abandoning_town(Src, CorpsUid),
            R = [{abandoning_town:get_town_sid(AbandoningTown), abandoning_town:get_start_time(AbandoningTown), abandoning_town:get_pos(AbandoningTown)}
                 || AbandoningTown <- AbandoningTownList],
            {ok, [], Info, [{msg, list_to_tuple(R)}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      放弃城池
%% @end
%% ----------------------------------------------------
abandon_town([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    TownSid = z_lib:get_value(Msg, "town_sid", 0),
    TownDetail = town_detail:get_cfg(TownSid),
    CheckVaild = valid_lib:check_valib([{'unequal', TownSid, 0}, {'unequal', TownDetail, 'none'}]),
    if
        CheckVaild ->
            RoleShow = role_db:get_role_show(Src, RoleUid),
            CorpsUid = role_show:get_corps_uid(RoleShow),
            case CorpsUid =:= 0 of
                true ->
                    {ok, [], Info, [{msg, "corps_not_in"}]};
                false ->
                    RoleCorps = corps_db:get_role_corps(Src, RoleUid),
                    Pos = role_corps:get_position(RoleCorps),
                    case corps_lib:check_position_limit('abandon_town', Pos) of
                        true ->
                            Town = z_db_lib:get(game_lib:get_table(Src, 'town'), TownSid, town:init(TownDetail)),
                            CorpsTown = z_db_lib:get(game_lib:get_table(Src, 'corps_town'), CorpsUid, corps_town:init()),
                            Now = time_lib:now_second(),
                            case town:get_corps_uid(Town) =:= CorpsUid of
                                true ->
                                    {S, _, ETime} = town:get_state(Town),
                                    case S =:= ?STATE_NOR orelse (S =:= ?STATE_PROTECT andalso Now >= ETime) of
                                        true ->
                                            {_, DayMaxATimes} = zm_config:get('corps', 'day_max_abandon_town_times'),
                                            {_, AbandoningNum} = zm_config:get('corps', 'abandoning_num'),
                                            Day = time_lib:get_date_by_type('day_of_year'),
                                            ATimes = corps_town:get_atimes(CorpsTown),
                                            Times = case element(1, ATimes) =:= Day of
                                                        true ->
                                                            element(2, ATimes);
                                                        false ->
                                                            0
                                                    end,
                                            if
                                                Times >= DayMaxATimes ->
                                                    {ok, [], Info, [{msg, "corps_town_abandon_times_limit"}]};
                                                true ->
                                                    TableName = game_lib:get_table(Src),
                                                    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'abandoning_town', CorpsUid, []}]),
                                                    case z_db_lib:handle(TableName, {M, F, A}, {Src, TownSid, Now, Pos, AbandoningNum}, TableKeys) of
                                                        ok ->
                                                            %%添加辅助信息
                                                            corps_db:add_abondoning_town_tmp(Src, CorpsUid, TownSid, Now),
                                                            %% 军团记录
                                                            CorpsLog = corps_log:abandon_town(role_show:get_name(RoleShow), Pos, TownSid, town:get_lv(Town, TownDetail)),
                                                            corps_db:insert_corps_log(Src, CorpsUid, CorpsLog),
                                                            %% 全军团成员推送城池开始放弃
                                                            CorpsMemberUids = corps_db:get_corps_members(Src, CorpsUid),
                                                            set_front_lib:send_corps_abandoning_town(Src, CorpsMemberUids, {?CORPS_ABANDONING_TOWN, TownSid, Now, Pos}),
                                                            %%更新point_search
                                                            point_search_db:update_town_abandon_st(Src, TownSid, TownDetail, Town),
                                                            zm_log:info(Src, ?MODULE, 'abandon_town', "corps_abandon_town", [{'roleuid', RoleUid}, {'corps_uid', CorpsUid},
                                                                                                                             {'town_sid', TownSid}, {'town', Town}]),
                                                            {ok, [], Info, [{msg, 'ok'}]};
                                                        Err ->
                                                            {ok, [], Info, [{msg, Err}]}
                                                    end
                                            end;
                                        false ->
                                            {ok, [], Info, [{msg, "corps_town_state_error"}]}
                                    end;
                                false ->
                                    {ok, [], Info, [{msg, "corps_town_not_owner"}]}
                            end;
                        Err1 ->
                            {ok, [], Info, [{msg, Err1}]}
                    end
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.
%% ----------------------------------------------------
%% @doc
%%      取消放弃城池
%% @end
%% ----------------------------------------------------
cancel_abandon_town(_, _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    TownSid = z_lib:get_value(Msg, "town_sid", 0),
    CheckVaild = valid_lib:check_valib([{'unequal', TownSid, 0}]),
    if
        CheckVaild ->
            RoleShow = role_db:get_role_show(Src, RoleUid),
            CorpsUid = role_show:get_corps_uid(RoleShow),
            case CorpsUid =:= 0 of
                true ->
                    {ok, [], Info, [{msg, "corps_not_in"}]};
                false ->
                    TownDetail = town_detail:get_cfg(TownSid),
                    Town = z_db_lib:get(game_lib:get_table(Src, 'town'), TownSid, town:init(TownDetail)),
                    {S, _, ETime} = town:get_state(Town),
                    Now = time_lib:now_second(),
                    case S =:= ?STATE_NOR orelse (S =:= ?STATE_PROTECT andalso Now >= ETime) of
                        true ->
                            RoleCorps = corps_db:get_role_corps(Src, RoleUid),
                            Pos = role_corps:get_position(RoleCorps),
                            R = case corps_db:cancel_abandon_town(Src, TownSid, CorpsUid, Pos) of
                                    {ok, StartTime} ->
                                        %%删除辅助信息
                                        corps_db:del_abondoning_town_tmp(Src, CorpsUid, TownSid, StartTime),
                                        TownDetail = town_detail:get_cfg(TownSid),
                                        Town = z_db_lib:get(game_lib:get_table(Src, 'town'), TownSid, town:init(TownDetail)),
                                        %% 军团记录
                                        CorpsLog = corps_log:cancel_abandon_town(role_show:get_name(RoleShow), Pos, TownSid, town:get_lv(Town, TownDetail)),
                                        corps_db:insert_corps_log(Src, CorpsUid, CorpsLog),
                                        %% 全军团成员推送城池取消放弃
                                        CorpsMemberUids = corps_db:get_corps_members(Src, CorpsUid),
                                        set_front_lib:send_corps_abandoning_town(Src, CorpsMemberUids, {?CORPS_CANCEL_ABANDONING_TOWN, TownSid}),
                                        %%更新point_search
                                        point_search_db:update_town_abandon_st(Src, TownSid, TownDetail, Town),
                                        zm_log:info(Src, ?MODULE, 'cancel_abandon_town', "cancel_corps_abandon_town", [{'roleuid', RoleUid}, {'corps_uid', CorpsUid},
                                                                                                                       {'town_sid', TownSid}, {'town', Town}]);
                                    Err ->
                                        Err
                                end,
                            {ok, [], Info, [{msg, R}]};
                        false ->
                            {ok, [], Info, [{msg, "corps_town_state_error2"}]}
                    end
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%%-------------------------------------------------------------------
%% @doc
%%      设置军团条件
%% @end
%%-------------------------------------------------------------------
set_condition([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    EnterFlag = z_lib:get_value(Msg, "ef", 0),
    RequestFlag = z_lib:get_value(Msg, "rf", 0),
    RequestRoleCastLv = z_lib:get_value(Msg, "clv", 0),
    RequestRoleLv = z_lib:get_value(Msg, "rlv", 0),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    CorpsUid = role_show:get_corps_uid(RoleShow),
    CheckVaild = valid_lib:check_valib([{'range', EnterFlag, {0, 1}}, {'range', RequestFlag, {0, 1}}, {'ge', RequestRoleCastLv, 0}, {'ge', RequestRoleLv, 0}, {'gt', CorpsUid, 0}]),
    if
        CheckVaild ->
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [
                {'corps', CorpsUid},
                {'role_corps', RoleUid, role_corps:init()}
            ]),
            Reply =
                case z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, CorpsUid, {EnterFlag, RequestFlag, RequestRoleLv, RequestRoleCastLv}}, TableKeys) of
                    {ok, CorpsCondition, NCorpsCondition} ->
                        RoleName = role_show:get_name(RoleShow),
                        NEnterFlag = corps_condition:get_enter_flag(NCorpsCondition),
                        RoleCorps = corps_db:get_role_corps(Src, RoleUid),
                        Pos = role_corps:get_position(RoleCorps),
                        case NEnterFlag =/= corps_condition:get_enter_flag(CorpsCondition) of
                            true ->
                                case NEnterFlag =:= 1 of
                                    true ->
                                        RUids = corps_lib:get_request_uids(corps_db:get_corps_request(Src, CorpsUid)),
                                        corps_db:check_requests(Src, 0, CorpsUid, 'corps_db', 'check_request', [], 1, RUids);
                                    false ->
                                        ok
                                end,
                                CorpsLog1 = corps_log:condition_enter(RoleName, Pos, EnterFlag),
                                corps_db:insert_corps_log(Src, CorpsUid, CorpsLog1);
                            false ->
                                ok
                        end,
                        NRequestFlag = corps_condition:get_request_flag(NCorpsCondition),
                        NRequestRoleLv = corps_condition:get_request_role_lv(NCorpsCondition),
                        NRequestCastleLv = corps_condition:get_request_castle_lv(NCorpsCondition),
                        ORequestFlag = corps_condition:get_request_flag(CorpsCondition),
                        ORequestRoleLv = corps_condition:get_request_role_lv(CorpsCondition),
                        ORequestCastleLv = corps_condition:get_request_castle_lv(CorpsCondition),
                        case NRequestFlag =/= ORequestFlag orelse (NRequestFlag =:= 1 andalso (NRequestCastleLv =/= ORequestCastleLv orelse NRequestRoleLv =/= ORequestRoleLv)) of
                            true ->
                                CorpsLog2 = corps_log:condition_request(RoleName, Pos, NRequestFlag, NRequestRoleLv, NRequestCastleLv),
                                corps_db:insert_corps_log(Src, CorpsUid, CorpsLog2);
                            false ->
                                ok
                        end,
                        ok;
                    Err ->
                        Err
                end,
            {ok, [], Info, [{msg, Reply}]};
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%%-------------------------------------------------------------------
%% @doc
%%      获取军团条件
%% @end
%%-------------------------------------------------------------------
get_condition(_, _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    CorpsUid = case list_to_integer(z_lib:get_value(Msg, "cuid", "0")) of
                   0 ->
                       role_show:get_corps_uid(role_db:get_role_show(Src, RoleUid));
                   CUid ->
                       CUid
               end,
    Corps = corps_db:get_corps(Src, CorpsUid),
    Condition = corps:get_conditon(Corps),
    {ok, [], Info, [{msg, corps_condition:format(Condition)}]}.


%%-------------------------------------------------------------------
%% @doc
%%      第一次加入军团领取奖励
%% @end
%%-------------------------------------------------------------------
award_first_enter_corps(_A, _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    Reply = case corps_db:award_first_enter_corps(Src, RoleUid) of
                true ->
                    Award = element(2, zm_config:get('corps', 'award_first_enter_corps')),
                    AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, Award),
                    zm_event:notify(Src, 'bi_award_first_enter_corps', [{'role_uid', RoleUid}, {'award_log', AwardLog}]),
                    AwardLog;
                Err ->
                    Err
            end,

    {ok, [], Info, [{msg, Reply}]}.

%%-------------------------------------------------------------------
%% @doc
%%      捐献  Type=1(money),  Type=2(rmb)
%% @end
%%-------------------------------------------------------------------
donate([{M, F, A}], _Session, Attr, Info, Msg) ->
    Type = z_db_lib:get_value(Msg, "type", 0),
    Number = z_db_lib:get_value(Msg, "number", 0),
    CheckVaild = valid_lib:check_valib([{'range', Number, {1, 10}}, {'exist', Type, [?MONEY, ?RMB]}]),
    R = if
            CheckVaild ->
                Src = z_lib:get_value(Info, src, none),
                RoleUid = role_lib:get_uid(Attr),
                RoleShow = role_db:get_role_show(Src, RoleUid),
                CorpsUid = role_show:get_corps_uid(RoleShow),
                if
                    CorpsUid =:= 0 ->
                        "corps_not_in";
                    true ->
                        T = if
                                Type =:= ?MONEY ->
                                    [{'role', RoleUid}];
                                true ->
                                    [{'rmb', RoleUid}]
                            end,
                        Corps = corps_db:get_corps(Src, CorpsUid),
                        TableName = game_lib:get_table(Src),
                        TableKeys = z_db_lib:transformation_tablekey(TableName, [{'role_corps', RoleUid}, {'donate', CorpsUid, []} | T]),
                        case z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, Type, Number, Corps}, TableKeys) of
                            {ok, Award, Cs, DonateNum} ->
                                AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, Award),
                                zm_event:notify(Src, 'bi_corps_donate', [{'role_uid', RoleUid}, {'consumes', Cs}, {'award_log', AwardLog}, {'corps_uid', CorpsUid}]),
                                {AwardLog, DonateNum};
                            Error ->
                                Error
                        end
                end;
            true ->
                "input_error"
        end,
    {ok, [], Info, [{msg, R}]}.

%%-------------------------------------------------------------------
%% @doc
%%      发起军团互助
%% @end
%%-------------------------------------------------------------------
request_help([{M, F, A}], _Session, Attr, Info, Msg) ->
    BSid = z_db_lib:get_value(Msg, "bsid", 0),
    CheckVaild = valid_lib:check_valib([{'ge', BSid, 0}]),
    if
        CheckVaild ->
            Src = z_lib:get_value(Info, src, none),
            RoleUid = role_lib:get_uid(Attr),
            RoleShow = role_db:get_role_show(Src, RoleUid),
            CorpsUid = role_show:get_corps_uid(RoleShow),
            if
                CorpsUid =:= 0 ->
                    {ok, [], Info, [{msg, "corps_not_in"}]};
                true ->
                    Queue = building_db:get_queue(Src, RoleUid),
                    BUpQueue = building_db:get_building_up_queue(Queue),%%此建筑是否在升级中，需要加入帮助队列
                    HelpInfo1 = case lists:keyfind(BSid, building_queue:get_up_bsid_index(), BUpQueue) of
                                    false ->
                                        [];
                                    _ ->
                                        Castel = castle_db:get_castle(Src, RoleUid),
                                        Level1 = castle:get_buildlv(castle:get_building(Castel), BSid),
                                        [{?BUILDING, BSid, Level1}]
                                end,
                    HelpInfos = HelpInfo1, %%下面是检查建筑内部有没有升级的队列，现在需求只有建筑本身升级才能加入帮助，所以不需要检查内部
%%                  HelpInfos = case building_db:get_queue_bytype(Queue, BSid) of%%检查此建筑内是否有队列
%%                            [] ->
%%                                HelpInfo1;
%%                            [BQ1] ->
%%                                Sid = building_queue:get_study_sid(BQ1),
%%                                Treasure = building_lib:get_bsid('treasure'),
%%                                Science = building_lib:get_bsid('science'),
%%                                Ordnance = building_lib:get_bsid('ordnance'),
%%                                Skill36 = building_lib:get_bsid('skill36'),
%%                                Wall = building_lib:get_bsid('wall'),
%%                                if
%%                                    BSid =:= Treasure ->
%%                                        [{BSid, Sid, 0} | HelpInfo1];
%%                                    BSid =:= Science orelse BSid =:= Ordnance orelse BSid =:= Skill36 orelse BSid =:= Wall ->
%%                                        BStudy = building_db:get_study_by_key(Src, RoleUid, BSid),
%%                                        [{BSid, Sid, z_lib:get_value(BStudy, Sid, 0)} | HelpInfo1];
%%                                    true ->
%%                                        HelpInfo1
%%                                end
%%                        end,
                    Reply =
                        if
                            HelpInfos =:= [] ->
                                "input_error";
                            true ->
                                TableName = game_lib:get_table(Src),
                                TableKeys = z_db_lib:transformation_tablekey(TableName, [{'corps_help', CorpsUid, {0, []}}, {'role_corps_help', RoleUid, []}]),
                                case z_db_lib:handle(TableName, {M, F, A}, {RoleUid, HelpInfos}, TableKeys) of
                                    {ok, AddCH} ->
                                        Name = role_show:get_name(RoleShow),
                                        MsgList = z_lib:foreach(fun(Msg1, CorpsHelp1) ->
                                            Id = corps_help:get_id(CorpsHelp1),
                                            {_RUid1, BSid1, Sid1} = corps_help:get_key(CorpsHelp1),
                                            Level2 = corps_help:get_level(CorpsHelp1),
                                            {ok, [{Id, RoleUid, Name, BSid1, Sid1, Level2, 0} | Msg1]}
                                                                end, [], AddCH),
                                        CRoleUids = corps_db:get_corps_members(Src, CorpsUid),
                                        set_front_lib:send_request_help(Src, CRoleUids, list_to_tuple(MsgList)),
                                        ok;
                                    Err ->
                                        Err
                                end
                        end,
                    {ok, [], Info, [{msg, Reply}]}
            end;
        true ->
            {ok, [], Info, [{msg, "input_eror"}]}
    end.

%%-------------------------------------------------------------------
%% @doc
%%      获取军团帮助列表
%% @end
%%-------------------------------------------------------------------
get_help(_A, _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    CorpsUid = role_show:get_corps_uid(RoleShow),
    R = if
            CorpsUid =:= 0 ->
                {{}, {}};  %%由于是登录获取信息，所以当没有军团的时候传空的过去
            true ->
                corps_db:format_help(Src, RoleUid, CorpsUid)
        end,
    {ok, [], Info, [{msg, R}]}.


%%-------------------------------------------------------------------
%% @doc
%%      军团互助帮助他人
%% @end
%%-------------------------------------------------------------------
help_other([{M, F, A}], _Session, Attr, Info, Msg) ->
    Ids = lists:usort([erlang:list_to_integer(X) || X <- string:tokens(z_lib:get_value(Msg, "id", ""), ",")]),
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    CorpsUid = role_show:get_corps_uid(RoleShow),
    R = if
            CorpsUid =:= 0 ->
                "corps_not_in";
            true ->
                TableName = game_lib:get_table(Src),
                TableKeys = z_db_lib:transformation_tablekey(TableName, [{'corps_help', CorpsUid, {0, []}}]),
                HelpMaxTimes = element(2, zm_config:get('corps', 'help_max_times')),
                case z_db_lib:handle(TableName, {M, F, A}, {RoleUid, Ids, HelpMaxTimes}, TableKeys) of
                    {ok, []} ->
                        ok;
                    {ok, ReduceTimeCHs} ->
                        CRoleUids = corps_db:get_corps_members(Src, CorpsUid),
                        Name = role_show:get_name(RoleShow),
                        {_, RTime} = zm_config:get('corps', 'help_reduce_time'),
                        {HelpIds, CompleteList} =
                            z_lib:foreach(fun({Ids1, ResComplete}, CorpsHelp2) ->
                                Id1 = corps_help:get_id(CorpsHelp2),
                                {HRoleUid1, HBSid1, HSid1} = corps_help:get_key(CorpsHelp2),
                                {NIds, NRComplete} = case building_db:reduce_queue_time(Src, HRoleUid1, HBSid1, HSid1, RTime) of
                                                         {_, _NeedTime, IsComplete} ->
                                                             C = if
                                                                     IsComplete ->
                                                                         [CorpsHelp2 | ResComplete];
                                                                     true ->
                                                                         ResComplete
                                                                 end,
                                                             {[Id1 | Ids1], C};
                                                         _ ->
                                                             {Ids1, ResComplete}
                                                     end,
                                {ok, {NIds, NRComplete}}
                                          end, {[], []}, ReduceTimeCHs),
                        set_front_lib:send_complete_help(Src, CRoleUids, {?HELP, list_to_tuple(HelpIds), RoleUid, Name}),
                        corps_db:update_corps_show_times(Src, RoleUid, 'corps_help_times', length(HelpIds)),
                        if
                            CompleteList =:= [] ->
                                ok;
                            true ->
                                corps_db:corps_help_queue_over2(Src, CompleteList, CorpsUid, CRoleUids)
                        end;
                    Err ->
                        Err
                end
        end,
    {ok, [], Info, [{msg, R}]}.
%%-------------------------------------------------------------------
%% @doc
%%      军团领取俸禄
%% @end
%%-------------------------------------------------------------------
position_award([{M, F, A}], _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    CorpsUid = role_show:get_corps_uid(RoleShow),
    if
        CorpsUid > 0 ->
            RoleCorps = corps_db:get_role_corps(Src, RoleUid),
            Pos = role_corps:get_position(RoleCorps),
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName,
                                                         [
                                                             {'corps_award_state', RoleUid, {0, 0}},
                                                             {'corps_position_gift_num', {CorpsUid, Pos}, {0, 0}}
                                                         ]),
            Reply = case z_db_lib:handle(TableName, {M, F, A}, {Src, RoleUid, RoleCorps}, TableKeys) of
                        {ok, Award} ->
                            AwardLog = awarder:give_award(Src, RoleUid, ?MODULE, Award),
                            zm_event:notify(Src, 'bi_position_award', [{'role_uid', RoleUid}, {'award_log', AwardLog}]),
                            AwardLog;
                        Reasion ->
                            Reasion
                    end,
            {ok, [], Info, [{msg, Reply}]};
        true ->
            {ok, [], Info, [{msg, "no_corps"}]}
    end.
%%-------------------------------------------------------------------
%% @doc
%%      获取军团成员详细信息
%% @end
%%-------------------------------------------------------------------
get_corps_show(_A, _Session, Attr, Info, Msg) ->
    io:format("get_corps_show:~p~n",[Msg]),
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    CorpsUid = role_show:get_corps_uid(RoleShow),
    if
        CorpsUid > 0 ->
            RUid = erlang:list_to_integer(z_lib:get_value(Msg, "ruid", "0")),
            RShow = role_db:get_role_show(Src, RUid),
            Reply = case role_show:get_corps_uid(RShow) of
                        CorpsUid ->
                            ToDay = time_lib:get_date_by_type('day_of_year'),
                            RCorps = corps_db:get_role_corps(Src, RUid),
                            {_, ContributionList} = role_corps:get_contribute(RCorps),
                            Contribution = times_set_lib:get_value(ContributionList, day_times, day),
                            CtbTimes = list_to_tuple(role_corps:get_all_ctb_times(RCorps, ToDay)),
                            RCorpsShow = corps_db:get_corps_show(Src, RUid),
                            CorpsHelpTimes = corps_show:format(corps_show:get_corps_help_times(RCorpsShow), ToDay),
                            TownAchieveTimes = corps_show:format(corps_show:get_town_achieve_times(RCorpsShow), ToDay),
                            DayFeats = corps_show:format(corps_show:get_day_feats(RCorpsShow), ToDay),
                            {role_show:get_vip_level(RShow), Contribution, CorpsHelpTimes, TownAchieveTimes, CtbTimes, DayFeats};
                        _ ->
                            "not_in_same_corps"
                    end,
            {ok, [], Info, [{msg, Reply}]};
        true ->
            {ok, [], Info, [{msg, "no_corps"}]}
    end.
%% ----------------------------------------------------
%% @doc
%%      放弃城池,前台倒计时结束的时候调用
%% @end
%% ----------------------------------------------------
abandon_town_assist(_, _Session, _Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    TownSid = z_lib:get_value(Msg, "town_sid", 0),
    CorpsUid = list_to_integer(z_lib:get_value(Msg, "corps_uid", "0")),
    CheckVaild = valid_lib:check_valib([{'gt', TownSid, 0}, {'gt', CorpsUid, 0}]),
    if
        CheckVaild ->
            AbandoningTownList = corps_db:get_abandoning_town(Src, CorpsUid),
            case lists:keyfind(TownSid, abandoning_town:get_town_sid_index(), AbandoningTownList) of
                false ->
                    ok;
                AbandoningTown ->
                    Now = time_lib:now_second(),
                    StarTime = abandoning_town:get_start_time(AbandoningTown),
                    {_, NeedTime} = zm_config:get('corps', 'abandoning_time'),
                    if
                        StarTime + NeedTime =< Now ->
                            corps_db:abandon_town2(Src, CorpsUid, TownSid, Now, time_lib:get_date_by_type('day_of_year'));
                        true ->
                            ok
                    end
            end;
        true ->
            ok
    end,
    {ok, [], Info, [{msg, "ok"}]}.

%% ----------------------------------------------------
%% @doc
%%      获得公会今日的捐献总次数
%% @end
%% ----------------------------------------------------
get_corps_donate_num(_, _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    CorpsUid = role_corps:get_corps_uid(corps_db:get_role_corps(Src, RoleUid)),
    if
        CorpsUid =:= 0 ->
            {ok, [], Info, [{msg, "corps_not_in"}]};
        true ->
            DonateInfo = z_db_lib:get(game_lib:get_table(Src, 'donate'), CorpsUid, []),
            Today = public_lib:day_of_utc(time_lib:now_second()),%%当前utc天数
            MoneyNum = case z_lib:get_value(DonateInfo, ?MONEY, {0, 0}) of%%获得这个城池今天的铜币捐献次数
                           {Today, Num1} -> Num1;
                           _ -> 0
                       end,
            RmbNum = case z_lib:get_value(DonateInfo, ?RMB, {0, 0}) of%%获得这个城池今天的铜币捐献次数
                         {Today, Num2} -> Num2;
                         _ -> 0
                     end,
            {ok, [], Info, [{msg, {MoneyNum, RmbNum}}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      改名
%% @end
%% ----------------------------------------------------
change_name([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    Name = z_lib:get_value(Msg, "name", ""),
    case role_lib:check_input_name(Src, Name) of
        {true, NName} ->
            RoleShow = role_db:get_role_show(Src, RoleUid),
            CorpsUid = role_show:get_corps_uid(RoleShow),
            case not cross_battle_db:check_corps_in_cross_battle(Src, CorpsUid) of
                true ->
                    TableName = game_lib:get_table(Src),
                    OldCorpsName = role_show:get_corps_name(RoleShow),
                    TableKeys = z_db_lib:transformation_tablekey(TableName, [
                        {'corps', CorpsUid},
                        {'corps_name', NName, none},
                        {'corps_name', OldCorpsName, 'none'},
                        {'goods', RoleUid, {}},
                        {'role_corps', RoleUid, role_corps:init()}
                    ]),
                    case z_db_lib:handle(TableName, {M, F, A}, {RoleUid, CorpsUid, OldCorpsName, NName}, TableKeys) of
                        {ok, Corps, Consumes} ->
                            zm_log:info(Src, ?MODULE, 'change_name', "change_name", [{'roleuid', RoleUid}, {'corps', Corps}, {'consume', Consumes}, {'old_name', OldCorpsName}]),
                            zm_event:notify(Src, 'corps_change_name', [{'role_uid', RoleUid}, {'corps_uid', CorpsUid}, {'consume', Consumes}, {'corps', Corps}]),
                            {ok, [], Info, [{msg, "ok"}]};
                        Err ->
                            {ok, [], Info, [{msg, Err}]}
                    end;
                false ->
                    {ok, [], Info, [{msg, "corps_in_cross_battle"}]}
            end;
        {_, Err} ->
            {ok, [], Info, [{msg, Err}]}
    end.
%% ----------------------------------------------------
%% @doc
%%      申请结盟
%% @end
%% ----------------------------------------------------
ally_request([{M, F, A}], _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    BCorpsUid = list_to_integer(z_lib:get_value(Msg, "corps_uid", "0")),
    CheckVaild = valid_lib:check_valib([{'gt', BCorpsUid, 0}]),
    R = if
            CheckVaild ->
                case corps_db:get_corps(Src, BCorpsUid) of
                    none ->
                        "input_error";
                    BCorps ->
                        RoleUid = role_lib:get_uid(Attr),
                        Country = role_lib:get_country(Attr),
                        RoleShow = role_db:get_role_show(Src, RoleUid),
                        CorpsUid = role_show:get_corps_uid(RoleShow),
                        BCountry = corps:get_country(BCorps),
                        if
                            Country =:= BCountry ->
                                if
                                    BCorpsUid =/= CorpsUid ->
                                        if
                                            CorpsUid > 0 ->
                                                RoleCorps = corps_db:get_role_corps(Src, RoleUid),
                                                Pos = role_corps:get_position(RoleCorps),
                                                case corps_lib:check_position_limit('ally_operation', Pos) of
                                                    true ->
                                                        {_, AllyCd} = zm_config:get('corps', 'ally_cd'),
                                                        {_, AllyRefuseCd} = zm_config:get('corps', 'ally_refuse_cd'),
                                                        {_, AllyRequsetValidTime} = zm_config:get('corps', 'request_ally_valid_time'),
                                                        Now = time_lib:now_second(),
                                                        TableName = game_lib:get_table(Src),
                                                        TableKeys = z_db_lib:transformation_tablekey(TableName,
                                                                                                     [
                                                                                                         {'ally_info', CorpsUid, ally_info:init()},
                                                                                                         {'ally_info', BCorpsUid, ally_info:init()}
                                                                                                     ]),
                                                        case z_db_lib:handle(TableName, {M, F, A}, {CorpsUid, BCorpsUid, AllyCd, AllyRefuseCd, AllyRequsetValidTime, Now}, TableKeys) of
                                                            ok ->
                                                                set_front_lib:send_ally_request(Src, [corps:get_owner(BCorps)], corps_lib:ally_format_send_ally_request(Src, CorpsUid)),
                                                                zm_log:info(Src, ?MODULE, 'ally_request', "ally_request", [{'roleuid', RoleUid}, {'corps_uid', CorpsUid}, {'bcorps_uid', BCorpsUid}]),
                                                                "ok";
                                                            Error ->
                                                                Error
                                                        end;
                                                    Err ->
                                                        Err
                                                end;
                                            true ->
                                                "no_corps"
                                        end;
                                    true ->
                                        "input_error"
                                end;
                            true ->
                                "not_the_same_country"
                        end
                end;
            true ->
                "input_error"
        end,
    {ok, [], Info, [{msg, R}]}.

%% ----------------------------------------------------
%% @doc
%%      回复结盟
%% @end
%% ----------------------------------------------------
ally_reply([{M, F, A}], _Session, Attr, Info, Msg) ->
    CorpsUid = list_to_integer(z_lib:get_value(Msg, "corps_uid", "0")),
    Reply = z_lib:get_value(Msg, "reply", -1),
    CheckVaild = valid_lib:check_valib([{'gt', CorpsUid, 0}, {'exist', Reply, [?AGREE, ?REFUSE]}]),
    R = if
            CheckVaild ->
                Src = z_lib:get_value(Info, 'src', 'none'),
                RoleUid = role_lib:get_uid(Attr),
                RoleShow = role_db:get_role_show(Src, RoleUid),
                BCorpsUid = role_show:get_corps_uid(RoleShow),
                if
                    CorpsUid =/= BCorpsUid ->
                        if
                            BCorpsUid > 0 ->
                                RoleCorps = corps_db:get_role_corps(Src, RoleUid),
                                Pos = role_corps:get_position(RoleCorps),
                                case corps_lib:check_position_limit('ally_operation', Pos) of
                                    true ->
                                        {_, AllyCd} = zm_config:get('corps', 'ally_cd'),
                                        {_, RefuseCd} = zm_config:get('corps', 'ally_refuse_cd'),
                                        {_, ValidTime} = zm_config:get('corps', 'request_ally_valid_time'),
                                        Now = time_lib:now_second(),
                                        TableName = game_lib:get_table(Src),
                                        TableKeys = z_db_lib:transformation_tablekey(TableName,
                                                                                     [
                                                                                         {'ally_info', CorpsUid, ally_info:init()},
                                                                                         {'ally_info', BCorpsUid, ally_info:init()}
                                                                                     ]),
                                        case z_db_lib:handle(TableName, {M, F, A}, {CorpsUid, BCorpsUid, Reply, AllyCd, RefuseCd, ValidTime, Now}, TableKeys) of
                                            ok ->
                                                Corps = corps_db:get_corps(Src, CorpsUid),
                                                BCorps = corps_db:get_corps(Src, BCorpsUid),
                                                if
                                                    Reply =:= ?AGREE ->
                                                        CorpsName = corps:get_name(Corps),
                                                        BCorpsName = corps:get_name(BCorps),
                                                        CorpsMembers = corps_db:get_corps_members(Src, CorpsUid),
                                                        BCorpsMembers = corps_db:get_corps_members(Src, BCorpsUid),
                                                        corps_lib:ally_agree_send(Src, Corps, CorpsMembers, BCorpsUid, BCorps, BCorpsMembers),
                                                        corps_lib:ally_agree_send(Src, BCorps, BCorpsMembers, CorpsUid, Corps, CorpsMembers),
                                                        corps_lib:ally_notice(Src, CorpsName, BCorpsName, ?AGREE),
                                                        corps_lib:ally_mail(Src, CorpsMembers, BCorpsName, ?AGREE),
                                                        corps_lib:ally_mail(Src, BCorpsMembers, CorpsName, ?AGREE),
                                                        zm_event:notify(Src, 'bi_ally_reply', [{'corps_uid', CorpsUid}, {'bcorps_uid', BCorpsUid}, {'reply', Reply}]),
                                                        ok;
                                                    true ->
                                                        ok
                                                end,
                                                zm_log:info(Src, ?MODULE, 'ally_reply', "ally_reply", [{'roleuid', RoleUid}, {'corps_uid', CorpsUid}, {'bcorps_uid', BCorpsUid}, {'reply', Reply}]),
                                                "ok";
                                            Error ->
                                                Error
                                        end;
                                    Err ->
                                        Err
                                end;
                            true ->
                                "no_corps"
                        end;
                    true ->
                        "input_error"
                end;
            true ->
                "input_error"
        end,
    {ok, [], Info, [{msg, R}]}.


%% ----------------------------------------------------
%% @doc
%%      获取邀请结盟列表
%% @end
%% ----------------------------------------------------
ally_get_request(_, _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    BCorpsUid = role_show:get_corps_uid(RoleShow),
    R = if
            BCorpsUid > 0 ->
                RoleCorps = corps_db:get_role_corps(Src, RoleUid),
                Pos = role_corps:get_position(RoleCorps),
                case corps_lib:check_position_limit('ally_operation', Pos) of
                    true ->
                        Now = time_lib:now_second(),
                        {_, RequestValidTime} = zm_config:get('corps', 'request_ally_valid_time'),
                        NBInvites = corps_db:ally_get_invites(Src, BCorpsUid, Now, RequestValidTime),
                        corps_lib:ally_format_invites(Src, NBInvites);
                    Err ->
                        Err
                end;
            true ->
                "no_corps"
        end,
    {ok, [], Info, [{msg, R}]}.

%% ----------------------------------------------------
%% @doc
%%      解散结盟
%% @end
%% ----------------------------------------------------
ally_delete([{M, F, A}], _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    CorpsUid = role_show:get_corps_uid(RoleShow),
    R = if
            CorpsUid > 0 ->
                RoleCorps = corps_db:get_role_corps(Src, RoleUid),
                Pos = role_corps:get_position(RoleCorps),
                case corps_lib:check_position_limit('ally_operation', Pos) of
                    true ->
                        AllyInfo = corps_db:get_db_ally_info(Src, CorpsUid),
                        case ally_info:get_ally_corps(AllyInfo) of
                            [] ->
                                "no_ally_corps";
                            AllyCorpsList ->
                                BCorpsUid = hd(AllyCorpsList),%%现在只有一个结盟军团
                                Now = time_lib:now_second(),
                                TableName = game_lib:get_table(Src),
                                TableKeys = z_db_lib:transformation_tablekey(TableName,
                                                                             [
                                                                                 {'ally_info', CorpsUid, ally_info:init()},
                                                                                 {'ally_info', BCorpsUid, ally_info:init()}
                                                                             ]),
                                case z_db_lib:handle(TableName, {M, F, A}, {Now, CorpsUid, BCorpsUid}, TableKeys) of
                                    ok ->
                                        Corps = corps_db:get_corps(Src, CorpsUid),
                                        BCorps = corps_db:get_corps(Src, BCorpsUid),
                                        CorpsName = corps:get_name(Corps),
                                        BCorpsName = corps:get_name(BCorps),
                                        CorpsMember = corps_db:get_corps_members(Src, CorpsUid),
                                        BCorpsMember = corps_db:get_corps_members(Src, BCorpsUid),
                                        %%遣返盟军驻守
                                        corps_lib:ally_delete_repatriate(Src, CorpsMember, BCorpsMember),
                                        %%推送
                                        set_front_lib:send_ally_delete(Src, CorpsMember ++ BCorpsMember, {}),
                                        %%系统公告,邮件
                                        corps_lib:ally_notice(Src, CorpsName, BCorpsName, ?REFUSE),
                                        corps_lib:ally_mail(Src, CorpsMember, BCorpsName, ?REFUSE),
                                        corps_lib:ally_mail(Src, BCorpsMember, CorpsName, ?REFUSE),
                                        %%BI,日志
                                        zm_log:info(Src, ?MODULE, 'ally_delete', "ally_reply", [{'roleuid', RoleUid}, {'corps_uid', CorpsUid}, {'bcorps_uid', BCorpsUid}, {'reply', ?REFUSE}]),
                                        zm_event:notify(Src, 'bi_ally_delete', [{'corps_uid', CorpsUid}, {'bcorps_uid', BCorpsUid}, {'reply', ?REFUSE}]),
                                        "ok";
                                    Error ->
                                        Error
                                end
                        end;
                    Err ->
                        Err
                end;
            true ->
                "no_corps"
        end,
    {ok, [], Info, [{msg, R}]}.

%% ----------------------------------------------------
%% @doc
%%         根据名字模糊查找军团
%% @end
%% ----------------------------------------------------
ally_search_by_name(_A, _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    Name = z_lib:get_value(Msg, "name", ""),
    Country = role_lib:get_country(Attr),
    case role_lib:check_input_name(Src, Name) of
        {true, NName} ->
            RoleUid = role_lib:get_uid(Attr),
            RoleShow = role_db:get_role_show(Src, RoleUid),
            CorpsUid = role_show:get_corps_uid(RoleShow),
            if
                CorpsUid > 0 ->
                    RoleCorps = corps_db:get_role_corps(Src, RoleUid),
                    Pos = role_corps:get_position(RoleCorps),
                    case corps_lib:check_position_limit('ally_operation', Pos) of
                        true ->
                            CorpsUids = corps_db:search_by_name(Src, NName, Country),
                            Fun1 = fun(CorpsUidTmp) ->
                                corps_lib:ally_format_search_by_name(Src, CorpsUidTmp)
                                   end,
                            CorpsViews = lists:map(Fun1, lists:delete(CorpsUid, CorpsUids)),
                            {ok, [], Info, [{msg, list_to_tuple(CorpsViews)}]};
                        Err ->
                            {ok, [], Info, [{msg, Err}]}
                    end;
                true ->
                    {ok, [], Info, [{msg, "no_corps"}]}
            end;
        {_, Err} ->
            {ok, [], Info, [{msg, Err}]}
    end.
%% ----------------------------------------------------
%% @doc
%%      获取结盟信息
%% @end
%% ----------------------------------------------------
ally_get_corps_info(_, _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    CorpsUid = role_show:get_corps_uid(RoleShow),
    R = if
            CorpsUid > 0 ->
                corps_db:ally_get_corps_info(Src, RoleUid, CorpsUid);
            true ->
                "no_corps"
        end,
    {ok, [], Info, [{msg, R}]}.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
