-module(corps_show).

%%%=======================STATEMENT====================
-description("corps_show").
-copyright('youkia,www.youkia.net').
-author("ljh,lvjihong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_corps_help_times/1, get_town_achieve_times/1, get_day_feats/1]).
-export([set_corps_help_times/2, set_town_achieve_times/2, set_day_feats/2]).
-export([init/0, format/2]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(corps_show, {
    corps_help_times = {0, 0} :: tuple(),%%天数，军团帮助次数
    day_feats = {0, 0} :: tuple(),%%天数，今日获得功勋值
    town_achieve_times = {0, 0} :: tuple()%%天数，完成皇榜任务次数
}).
%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        基础函数
%% @end
%% ----------------------------------------------------
init() -> #corps_show{}.
get_corps_help_times(#corps_show{corps_help_times = V}) -> V.
get_town_achieve_times(#corps_show{town_achieve_times = V}) -> V.
get_day_feats(#corps_show{day_feats = V}) -> V.

set_corps_help_times(CorpsShow, V) -> CorpsShow#corps_show{corps_help_times = V}.
set_town_achieve_times(CorpsShow, V) -> CorpsShow#corps_show{town_achieve_times = V}.
set_day_feats(CorpsShow, V) -> CorpsShow#corps_show{day_feats = V}.

%% ----------------------------------------------------
%% @doc
%%      获得今天的次数
%% @end
%% ----------------------------------------------------
format({Day, V}, Day) ->
    V;
format(_, _) ->
    0.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
