-module(corps_event).

%%%=======================STATEMENT====================
-description("corps_event").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([notify/4, cash_notify/4]).

%%%=======================INCLUDE======================
-include("../include/corps.hrl").
-include("../include/point.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%        
%% @end
%% ----------------------------------------------------
notify(_, Src, 'corps_create', Args) ->
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, CorpsUid} = lists:keyfind('corps_uid', 1, Args),
    {_, Corps} = lists:keyfind('corps', 1, Args),
    {_, Country} = lists:keyfind('country', 1, Args),
    zm_event:notify(Src, {'corps_level_influence_rank', Country}, [{'uid', CorpsUid}]),
    zm_event:notify(Src, {'corps_power_rank', Country}, [{'uid', CorpsUid}]),
    zm_event:notify(Src, 'update_role_show', {RoleUid, {'corps', Corps}}),

    {_, RoleRequests} = lists:keyfind('role_requests', 1, Args),
    Fun = fun(_, List) ->
        {ok, ok, lists:keydelete(RoleUid, 1, List)}
    end,
    Table = game_lib:get_table(Src, 'corps_request'),
    lists:foreach(fun({CUid, _}) -> z_db_lib:update(Table, CUid, [], Fun, []) end, RoleRequests),
%%    GarraySidList = garray_lib:get_garray_ids(Src, RoleUid),
%%    lists:foreach(fun(GarraySid) ->
%%        zm_event:notify(Src, {'power_change', Country}, [{'uid', RoleUid}, {'gid', GarraySid}, {'country', Country}])
%%    end, GarraySidList),

    corps_db:save_new_corps_uid(Src, Corps);
notify(_, Src, 'corps_change_banner', Args) ->
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, CorpsUid} = lists:keyfind('corps_uid', 1, Args),
    {_, Banner} = lists:keyfind('banner', 1, Args),
    {_, Corps} = lists:keyfind('corps', 1, Args),
    CorpsMembers = corps_db:get_corps_members(Src, CorpsUid),
    lists:foreach(fun(RUid) ->
        zm_event:notify(Src, 'update_role_show', {RUid, {'corps_banner', Corps}})
    end, CorpsMembers),
    set_front_lib:send_corps_change_banner(Src, lists:delete(RoleUid, CorpsMembers), Banner),
    CorpsTown = corps_db:get_corps_town(Src, CorpsUid),
    Table = game_lib:get_table(Src, 'town'),
    lists:foreach(fun({TownSid, _}) ->
        TownDetail = town_detail:get_cfg(TownSid),
        Town = z_db_lib:get(Table, TownSid, town:init(TownDetail)),
        point_search_db:update_towninfo(Src, TownSid, TownDetail, Town)%由于战斗中也需要更新,故直接调用update_towninfo
    end, corps_town:get_flist(CorpsTown) ++ corps_town:get_cflist(CorpsTown) ++ corps_town:get_olist(CorpsTown) ++ corps_town:get_clist(CorpsTown));
notify(_, Src, 'corps_change_name', Args) ->
    {_, CorpsUid} = lists:keyfind('corps_uid', 1, Args),
    {_, Corps} = lists:keyfind('corps', 1, Args),
    CorpsTown = z_db_lib:get(game_lib:get_table(Src, 'corps_town'), CorpsUid, corps_town:init()),
    TownSidList = corps_town:get_olist_townsid(CorpsTown) ++ corps_town:get_clist_townsid(CorpsTown),
    CorpsName = corps:get_name(Corps),
    lists:foreach(fun(TownSid) ->
        Town = z_db_lib:get(game_lib:get_table(Src, 'town'), TownSid, town:init(TownSid)),
        point_db:update_map_towninfo(Src, CorpsUid, CorpsUid, TownSid, Town),
        point_search_db:update_town_corps_name(Src, TownSid, town_detail:get_cfg(TownSid), CorpsName),
        MapBuild = map_build_db:get_map_build(Src, TownSid),
        lists:foreach(fun(MBV) ->
            point_search_db:update_map_build_corps_name(Src, MBV, CorpsName)
        end, map_build:get_build(MapBuild))
    end, TownSidList),
    MapBuild = map_build_db:get_map_build(Src, CorpsUid),
    lists:foreach(fun(MBV) ->
        point_search_db:update_map_build_corps_name(Src, MBV, CorpsName)
    end, map_build:get_build(MapBuild)),
    lists:foreach(fun(RUid) ->
        zm_event:notify(Src, 'update_role_show', {RUid, {'corps_name', Corps}})
    end, corps_db:get_corps_members(Src, CorpsUid)),
    set_front_lib:send_corps_change_name(Src, CorpsUid, CorpsName);
notify(_, Src, 'corps_check_request', Args) ->
    {_, Type} = lists:keyfind('type', 1, Args),
    %%这儿可能是自动同意，所以RoleUid可能为0
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, CorpsUid} = lists:keyfind('corps_uid', 1, Args),
    {_, Corps} = lists:keyfind('corps', 1, Args),
    {_, RRequests} = lists:keyfind('role_requests', 1, Args),
    if
        Type =:= 1 ->%%同意
            Fun = fun(A, {RUid, RoleRequests}) ->
                role_enter(Src, CorpsUid, RUid, Corps, RoleRequests),
                {ok, [RUid | A]}
            end,
            RUids = z_lib:foreach(Fun, [], RRequests),
            CorpsTown = corps_db:get_corps_town(Src, CorpsUid),
            TFun = fun(R, {TSid, _}) ->
                Town = z_db_lib:get(game_lib:get_table(Src, 'town'), TSid, town:init(TSid)),
                {_, STime, _} = town:get_state(Town),
                {ok, [{TSid, STime} | R]}
            end,
            FTSidSTimeList1 = z_lib:foreach(TFun, [], corps_town:get_flist(CorpsTown)),
            FTSidSTimeList = z_lib:foreach(TFun, FTSidSTimeList1, corps_town:get_cflist(CorpsTown)),
            set_front_lib:send_corps_agree_request(Src, corps_db:get_corps_members(Src, CorpsUid), RoleUid, RUids, Corps, FTSidSTimeList),
            case corps_db:get_ally_corps_uids(Src, CorpsUid) of
                [] ->
                    'ok';
                [AllyCorpsUid | _] ->
                    set_front_lib:send_ally_reply(Src, RUids, corps_db:ally_get_corps_info(Src, 0, CorpsUid)),
                    set_front_lib:send_ally_add_member(Src, corps_db:get_corps_members(Src, AllyCorpsUid), list_to_tuple(RUids))
            end,
            ok;
        true ->
            Fun = fun(A, {RUid, _}) ->
                set_front_lib:send_corps_refuse_request(Src, Corps, RoleUid, RUid),
                {ok, A}
            end,
            z_lib:foreach(Fun, [], RRequests),
            ok
    end;
notify(_, Src, 'corps_check_invite', Args) ->
    {_, Type} = lists:keyfind('type', 1, Args),
    if
        Type =:= 1 ->%%同意
            {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
            {_, CorpsUid} = lists:keyfind('corps_uid', 1, Args),
            {_, Corps} = lists:keyfind('corps', 1, Args),
            {_, RoleRequests} = lists:keyfind('role_requests', 1, Args),
            role_enter(Src, CorpsUid, RoleUid, Corps, RoleRequests),
            set_front_lib:send_corps_agree_invite(Src, corps_db:get_corps_members(Src, CorpsUid), RoleUid, Corps),
            case corps_db:get_ally_corps_uids(Src, CorpsUid) of
                [] ->
                    'ok';
                [AllyCorpsUid | _] ->
%%                    set_front_lib:send_ally_reply(Src, [RoleUid], corps_db:ally_get_corps_info(Src, RoleUid, CorpsUid)),
                    set_front_lib:send_ally_add_member(Src, corps_db:get_corps_members(Src, AllyCorpsUid), {RoleUid})
            end;
        true ->
            ok
    end;
notify(_, Src, 'corps_request_enter', Args) ->
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, CorpsUid} = lists:keyfind('corps_uid', 1, Args),
    {_, Corps} = lists:keyfind('corps', 1, Args),
    {_, RoleRequests} = lists:keyfind('role_requests', 1, Args),
    role_enter(Src, CorpsUid, RoleUid, Corps, RoleRequests),
    set_front_lib:send_corps_request_enter(Src, corps_db:get_corps_members(Src, CorpsUid), RoleUid, Corps),
    case corps_db:get_ally_corps_uids(Src, CorpsUid) of
        [] ->
            'ok';
        [AllyCorpsUid | _] ->
%%            set_front_lib:send_ally_reply(Src, [RoleUid], corps_db:ally_get_corps_info(Src, RoleUid, CorpsUid)),
            set_front_lib:send_ally_add_member(Src, corps_db:get_corps_members(Src, AllyCorpsUid), {RoleUid})
    end;
notify(_, Src, 'corps_role_quit', Args) ->
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, CorpsUid} = lists:keyfind('corps_uid', 1, Args),
    {_, CorpsMemebers} = lists:keyfind('corps_memeber', 1, Args),
    {_, Corps} = lists:keyfind('corps', 1, Args),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    role_quit(Src, CorpsUid, RoleUid, Corps, role_show:get_country(RoleShow)),
    corps_db:insert_corps_log(Src, CorpsUid, corps_log:quit(role_show:get_name(RoleShow))),
    set_front_lib:send_corps_quit(Src, CorpsMemebers, RoleUid),
    case corps_db:get_ally_corps_uids(Src, CorpsUid) of
        [] ->
            'ok';
        [AllyCorpsUid | _] ->
            set_front_lib:send_ally_delete(Src, [RoleUid], {}),
            set_front_lib:send_ally_delete_member(Src, corps_db:get_corps_members(Src, AllyCorpsUid), {RoleUid})
    end,
    ok;
notify(_, Src, 'corps_kickout_role', Args) ->
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, RUid} = lists:keyfind('ruid', 1, Args),
    {_, CorpsUid} = lists:keyfind('corps_uid', 1, Args),
    {_, RoleCorps} = lists:keyfind('role_corps', 1, Args),
    {_, CorpsMemebers} = lists:keyfind('corps_member', 1, Args),
    {_, Corps} = lists:keyfind('corps', 1, Args),

    RoleShow = role_db:get_role_show(Src, RoleUid),
    role_quit(Src, CorpsUid, RUid, Corps, role_show:get_country(RoleShow)),

    Pos = role_corps:get_position(RoleCorps),
    RoleShow1 = role_db:get_role_show(Src, RUid),
    RoleShow2 = role_db:get_role_show(Src, RoleUid),
    corps_db:insert_corps_log(Src, CorpsUid, corps_log:kickout(role_show:get_name(RoleShow1), Pos, role_show:get_name(RoleShow2))),
    set_front_lib:send_corps_kickout(Src, CorpsMemebers, RoleUid, RUid),
    case corps_db:get_ally_corps_uids(Src, CorpsUid) of
        [] ->
            'ok';
        [AllyCorpsUid | _] ->
            set_front_lib:send_ally_delete(Src, [RUid], {}),
            set_front_lib:send_ally_delete_member(Src, corps_db:get_corps_members(Src, AllyCorpsUid), {RUid})
    end,
    %%给被踢出军团的人发送邮件
    MailType = award_source:get_source(?MODULE),
    RoleName = role_show:get_name(RoleShow),
    CorpsName = corps:get_name(Corps),
    Mail = mail:init({MailType, time_lib:now_second(), 0, {0, game_lib:get_language({mail_title, 50})}, {0, game_lib:get_language({mail_content, 50}, [RoleName, CorpsName])}, []}),
    mail_db:send(Src, RUid, Mail),
    ok;
notify(_, Src, 'corps_trans_position', Args) ->
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, CorpsUid} = lists:keyfind('corps_uid', 1, Args),
    {_, Corps} = lists:keyfind('corps', 1, Args),
    {_, RUid} = lists:keyfind('ruid', 1, Args),
    {_, NewPos} = lists:keyfind('new_pos', 1, Args),
    RoleShow1 = role_db:get_role_show(Src, RoleUid),
    RoleShow2 = role_db:get_role_show(Src, RUid),
    corps_db:insert_corps_log(Src, CorpsUid, corps_log:trans_position(role_show:get_name(RoleShow1), NewPos, role_show:get_name(RoleShow2))),
    CorpsMembers = corps_db:get_corps_members(Src, CorpsUid),
    zm_event:notify(Src, 'bi_corps_change', [{'corps', Corps}]),
    set_front_lib:send_corps_trans_position(Src, lists:delete(RoleUid, CorpsMembers), RUid, NewPos),
    case corps_db:get_ally_corps_uids(Src, CorpsUid) of
        [] ->
            'ok';
        _ ->
            set_front_lib:send_ally_reply(Src, [RUid], corps_db:ally_get_corps_info(Src, RUid, CorpsUid))
    end;
notify(_, Src, 'corps_set_position', Args) ->
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, CorpsUid} = lists:keyfind('corps_uid', 1, Args),
%%    {_, Corps} = lists:keyfind('corps', 1, Args),
    {_, RUid} = lists:keyfind('ruid', 1, Args),
    {_, OldPos} = lists:keyfind('old_pos', 1, Args),
    {_, NewPos} = lists:keyfind('new_pos', 1, Args),
    RoleShow = role_db:get_role_show(Src, RUid),
    corps_db:insert_corps_log(Src, CorpsUid, corps_log:set_position(role_show:get_name(RoleShow), OldPos, NewPos)),
    CorpsMembers = corps_db:get_corps_members(Src, CorpsUid),
    set_front_lib:send_corps_set_position(Src, lists:delete(RoleUid, CorpsMembers), RUid, NewPos);
notify(_, Src, 'corps_replace_owner', Args) ->
    {_, NewOwerUid} = lists:keyfind('new_owner', 1, Args),
    {_, OldOwerUid} = lists:keyfind('old_owner', 1, Args),
    {_, CorpsMembers} = lists:keyfind('members', 1, Args),
    {_, CorpsUid} = lists:keyfind('corps_uid', 1, Args),
    {_, Type} = lists:keyfind('type', 1, Args),%%0弹劾，1变换阵营
    OldOwerName = role_show:get_name(role_db:get_role_show(Src, OldOwerUid)),
    NewOwerName = role_show:get_name(role_db:get_role_show(Src, NewOwerUid)),
    MailType = award_source:get_source(?MODULE),
    {OldOwnerCfg, MemberCfg, NewOwnerCfg} = if
        Type =:= 0 ->
            {38, 39, 40};
        true ->
            {58, 59, 60}
    end,
%给老团长发邮件
    Mail = mail:init({MailType, 0, 0, {0, game_lib:get_language({mail_title, OldOwnerCfg})}, {0, game_lib:get_language({mail_content, OldOwnerCfg})}, []}),
    mail_db:send(Src, OldOwerUid, Mail),
%%给军团成员发邮件
    Mail2 = mail:init({MailType, 0, 0, {0, game_lib:get_language({mail_title, MemberCfg})}, {0, game_lib:get_language({mail_content, MemberCfg}, [OldOwerName, NewOwerName])}, []}),
    lists:foreach(fun(Id) ->
        mail_db:send(Src, Id, Mail2) end, lists:delete(OldOwerUid, lists:delete(NewOwerUid, CorpsMembers))),
    Mail3 = mail:init({MailType, 0, 0, {0, game_lib:get_language({mail_title, NewOwnerCfg})}, {0, game_lib:get_language({mail_content, NewOwnerCfg}, [OldOwerName])}, []}),
    mail_db:send(Src, NewOwerUid, Mail3),
    set_front_lib:send_corps_replace_owner(Src, CorpsMembers, {NewOwerUid}),
    case corps_db:get_ally_corps_uids(Src, CorpsUid) of
        [] ->
            'ok';
        _ ->
            set_front_lib:send_ally_reply(Src, [NewOwerUid], corps_db:ally_get_corps_info(Src, NewOwerUid, CorpsUid))
    end;
notify(_, Src, 'corps_abandon_town', Args) ->
    {_, TownSid} = lists:keyfind('town_sid', 1, Args),
    {_, Town} = lists:keyfind('town', 1, Args),
    {_, CorpsUid} = lists:keyfind('corps_uid', 1, Args),
    {_, FightCUids} = lists:keyfind('fight_cuids', 1, Args),
    TownDetail = town_detail:get_cfg(TownSid),
    point_search_db:update_towninfo(Src, TownSid, TownDetail, Town, [{PUid, 0} || PUid <- tuple_to_list(town_detail:get_points(TownDetail, 0))]),
    Corps = corps_db:get_corps(Src, CorpsUid),
    town_db:add_town_event(Src, 'corps_abandon_town', TownSid, Town, Corps),
%set_front_lib:send_corps_abandon_town(Src, CorpsUid, TownSid, town:get_exp(Town)),
    set_front_lib:send_town_owner(Src, TownSid, town:set_exp(town:init(TownDetail), town:get_exp(Town)), ""),%统一使用城池所属变化
    point_db:update_map_towninfo(Src, CorpsUid, 0, TownSid, Town),
    role_addition:set_corps_bufflist(CorpsUid, 'none'),
    map_build_db:del_map_build(Src, TownSid, CorpsUid),
    map_build_db:clear_mb_fight_num(Src, CorpsUid, TownSid),
    fight_db:town_occ_marching_back_corps(Src, TownSid, tuple_to_list(town_detail:get_points(TownDetail, 0)), CorpsUid, FightCUids, town_detail:chk_chief(TownDetail));
%%周期城池放弃事件处理
notify(_, Src, 'corps_abandon_cycle_town', Args) ->
    {_, TownSid} = lists:keyfind('town_sid', 1, Args),
    {_, Town} = lists:keyfind('town', 1, Args),
    {_, CorpsUid} = lists:keyfind('corps_uid', 1, Args),
    {_, FightCUids} = lists:keyfind('fight_cuids', 1, Args),
    TownDetail = town_detail:get_cfg(TownSid),
    point_search_db:update_towninfo(Src, TownSid, TownDetail, Town, [{PUid, 0} || PUid <- tuple_to_list(town_detail:get_points(TownDetail, 0))]),
    Corps = corps_db:get_corps(Src, CorpsUid),
    town_db:add_town_event(Src, 'corps_abandon_cycle_town', TownSid, Town, Corps),
    set_front_lib:send_town_owner(Src, TownSid, town:set_exp(town:init(TownDetail), town:get_exp(Town)), ""),%统一使用城池所属变化
    point_db:update_map_towninfo(Src, CorpsUid, 0, TownSid, Town),
    role_addition:set_corps_bufflist(CorpsUid, 'none'),
    map_build_db:del_map_build(Src, TownSid, CorpsUid),
    map_build_db:clear_mb_fight_num(Src, CorpsUid, TownSid),
    fight_db:town_occ_marching_back_corps(Src, TownSid, tuple_to_list(town_detail:get_points(TownDetail, 0)), CorpsUid, FightCUids, town_detail:chk_chief(TownDetail));


notify(_, Src, 'corps_dissolve', Args) ->
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, Corps} = lists:keyfind('corps', 1, Args),
    CorpsUid = corps:get_uid(Corps),
    RCTable = game_lib:get_table(Src, 'role_corps'),
    Country = corps:get_country(Corps),
    zm_event:notify(Src, 'bi_corps_change', [{'corps', Corps}]),
    zm_event:notify(Src, {'corps_rank_delete', Country}, [{'uid', CorpsUid}]),
    active_corps_town_score:delete_corps_rank(Src, CorpsUid),
    active_corps_town_rank:delete_corps_rank(Src, CorpsUid),
    active_corps_boss:delete_corps_rank(Src, CorpsUid),
    zm_event:notify(Src, 'update_role_show', {RoleUid, {'corps', 'none'}}),
    GarraySidList = garray_lib:get_garray_ids(Src, RoleUid),
    zm_event:notify(Src, {'power_change', Country}, [{'uid', RoleUid}, {'gid', GarraySidList}, {'country', Country}]),

    CorpsInvites = corps_lib:get_invite_uids(corps_db:get_corps_invites(Src, CorpsUid)),
    lists:foreach(fun(Uid) ->
        try
            z_db_lib:update(RCTable, Uid, fun(_, RoleCorps) ->
                {ok, ok, role_corps:set_invites(RoleCorps, lists:keydelete(CorpsUid, 1, role_corps:get_invites(RoleCorps)))} end, [])
        catch
            E:E1 ->
                zm_log:warn(Src, ?MODULE, "corps_dissolve", "corps_dissolve", [{'args', Args}, {E, E1}, {'stacktrace', erlang:get_stacktrace()}])
        end
    end, CorpsInvites),
    CorpsRequests = corps_lib:get_request_uids(corps_db:get_corps_request(Src, CorpsUid)),
    lists:foreach(fun(Uid) ->
        try
            z_db_lib:update(RCTable, Uid, fun(_, RoleCorps) ->
                {ok, ok, role_corps:set_requests(RoleCorps, lists:keydelete(CorpsUid, 1, role_corps:get_requests(RoleCorps)))} end, [])
        catch
            E:E1 ->
                zm_log:warn(Src, ?MODULE, "corps_dissolve", "corps_dissolve", [{'args', Args}, {E, E1}, {'stacktrace', erlang:get_stacktrace()}])
        end
    end, CorpsRequests),

    RoleMembers = corps_db:get_corps_members(Src, CorpsUid),

    RoleUids1 = lists:usort(CorpsInvites ++ CorpsRequests ++ lists:delete(RoleUid, RoleMembers)),
    set_front_lib:send_corps_dissolve(Src, RoleUids1, CorpsUid),

    CorpsTown = corps_db:get_corps_town(Src, CorpsUid),
    Now = time_lib:now_second(),
    lists:foreach(fun(TownSid) ->
        TownDetail = town_detail:get_cfg(TownSid),
%军团解散,战斗中城池立即结束战斗
        Fun = fun(_, Town) ->
            Fight = town:chk_fight(Town),
            NTown = town:win_fight(Town, TownDetail, Now, 0, 0, false),
            if
                Fight ->
                    {STate, STime, Etime} = town:get_state(Town),
                    RTown = town:set_state(NTown, {STate, STime, min(Now, Etime)}),
                    {'ok', {RTown, town:get_fight_uids(Town)}, RTown};
                true ->
                    {'ok', {NTown, town:get_fight_uids(Town)}, NTown}
            end
        end,
        {Town, FightCUids} = z_db_lib:update(game_lib:get_table(Src, 'town'), TownSid, town:init(TownDetail), Fun, []),
        town_db:add_town_event(Src, 'corps_dissolve', TownSid, Town, Corps),
        Points = tuple_to_list(town_detail:get_points(TownDetail, 0)),
        fight_db:town_occ_marching_back_corps(Src, TownSid, Points, CorpsUid, FightCUids, town_detail:chk_chief(TownDetail)),
        PMUid = town_detail:get_point(TownDetail),
        PInfo = {?TOWN, TownSid},
        fighting:arrive(Src, PMUid, PInfo, []),
        map_build_db:del_map_build(Src, TownSid, CorpsUid),
        point_search_db:update_towninfo(Src, TownSid, TownDetail, Town, [{Puid, 0} || Puid <- Points]),
        set_front_lib:send_town_owner(Src, TownSid, town:init(TownDetail), "")
    end, corps_town:get_olist_townsid(CorpsTown) ++ corps_town:get_clist_townsid(CorpsTown)),
    map_build_db:clear_mb_fight_num(Src, CorpsUid, CorpsUid),
    lists:foreach(fun(TownSid) ->
        TownDetail = town_detail:get_cfg(TownSid),
        Fun = fun(_, Town) ->
            FightUids = town:get_fight_uids(Town),
            NFightUids = lists:delete(CorpsUid, FightUids),
            PointsOwner = town:get_points_owner(Town),
            {PUids, NPointsOwner} = z_lib:foreach(fun({Acc1, Acc2}, {PUid, CUid}) ->
                case CUid =:= CorpsUid of
                    true ->
                        {[PUid | Acc1], Acc2};
                    false ->
                        {Acc1, [{PUid, CUid} | Acc2]}
                end
            end, {[], []}, PointsOwner),
            NTown = town:set_points_owner(town:set_fight_uids(Town, NFightUids), lists:reverse(NPointsOwner)),
            {ok, {ok, PUids, NTown}, NTown}
        end,
        {ok, PUids, Town} = z_db_lib:update(game_lib:get_table(Src, 'town'), TownSid, town:init(TownDetail), Fun, []),
        fight_db:town_occ_marching_back_corps(Src, TownSid, PUids, CorpsUid, [], town_detail:chk_chief(TownDetail)),
        point_search_db:update_towninfo(Src, TownSid, TownDetail, Town, [{Puid, 0} || Puid <- PUids])
    end, corps_town:get_flist_townsid(CorpsTown) ++ corps_town:get_cflist_townsid(CorpsTown)),
    point_db:del_corps_map_info(Src, CorpsUid),
    role_addition:del_corps_bufflist(CorpsUid),
    corps_db:ally_delete_corps(Src, Now, RoleUid, CorpsUid),
        catch z_db_lib:delete(game_lib:get_table(Src, 'corps_town'), CorpsUid),
        catch corps_db:delete_new_corps_uid(Src, Corps),
        catch z_db_lib:delete(game_lib:get_table(Src, 'corps'), CorpsUid),
        catch z_db_lib:delete(game_lib:get_table(Src, 'corps_member'), CorpsUid),
        catch z_db_lib:delete(game_lib:get_table(Src, 'corps_name'), corps:get_name(Corps)),
        catch z_db_lib:delete(game_lib:get_table(Src, 'corps_invite'), CorpsUid),
        catch z_db_lib:delete(game_lib:get_table(Src, 'corps_request'), CorpsUid),
        catch z_db_lib:delete(game_lib:get_table(Src, 'corps_log'), CorpsUid),
%%军团解散时删除军团贡献排行榜
        catch z_db_lib:delete(game_lib:get_table(Src, 'contribute_rank'), CorpsUid),
    shop_db:clear_corps_shop(Src, CorpsUid),
        catch z_db_lib:delete(game_lib:get_table(Src, 'corps_mail'), CorpsUid),
        catch z_db_lib:delete(game_lib:get_table(Src, 'corps_show'), CorpsUid),
        catch z_db_lib:delete(game_lib:get_table(Src, 'map_build'), CorpsUid),
        catch z_db_lib:delete(game_lib:get_table(Src, 'ally_info'), CorpsUid),
    case z_db_lib:delete1(game_lib:get_table(Src, 'abandoning_town'), CorpsUid) of
        ok ->
            ok;
        AbandoingTownList ->
            Fun2 = fun(AbandoningTown) ->
                StartTime = abandoning_town:get_start_time(AbandoningTown),
                TownSid = abandoning_town:get_town_sid(AbandoningTown),
                corps_db:del_abondoning_town_tmp(Src, CorpsUid, TownSid, StartTime)
            end,
            lists:foreach(Fun2, AbandoingTownList)
    end,
    ok;
notify(_, Src, 'login', Args) ->
    {_, Role} = lists:keyfind('role', 1, Args),
    RoleUid = role:get_uid(Role),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    corps_db:update_corps_mf_level(Src, RoleUid, 'login', RoleShow, RoleShow),
    %%自动处理军团长
    corps_db:auto_replace(Src, RoleUid, RoleShow),
    ok;
%%notify(_, Src, 'corps_set_notice', Args) ->
%%    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
%%    {_, CorpsUid} = lists:keyfind('corps_uid', 1, Args),
%%    {_, Time} = lists:keyfind('time', 1, Args),
%%    {_, Type} = lists:keyfind('type', 1, Args),
%%    CorpsMembers = corps_db:get_corps_members(Src, CorpsUid),
%%    if
%%        Type =:= 0 ->
%%            set_front_lib:send_private_notice_time(Src, lists:delete(RoleUid, CorpsMembers), Time);
%%        true ->
%%            set_front_lib:send_publice_notice_time(Src, lists:delete(RoleUid, CorpsMembers), Time)
%%    end;
notify(_, Src, 'all_contribute_notice', Args) ->
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    RoleCorps = corps_db:get_role_corps(Src, RoleUid),
    {_, Contribute} = role_corps:get_contribute(RoleCorps),
    case lists:keyfind('total_times', 1, Contribute) of
        {_, TotalContribute} ->
            Fun = fun(_, ContributeList) ->
                NewContributeList = lists:sort(fun({_, V1}, {_, V2}) ->
                    V1 > V2 end, lists:keystore(RoleUid, 1, ContributeList, {RoleUid, TotalContribute})),
                {ok, ok, NewContributeList}
            end,
            z_db_lib:update(game_lib:get_table(Src, 'contribute_rank'), role_corps:get_corps_uid(RoleCorps), [], Fun, []);
        _ ->
            ok
    end;
notify(_, Src, 'town_owner_change', Args) ->
    {_, Town} = lists:keyfind('town', 1, Args),
    {_, TownSid} = lists:keyfind('town_sid', 1, Args),
    {_, TownDetail} = lists:keyfind('town_detail', 1, Args),
    {_, OldCorpsUid} = lists:keyfind('old_corps_uid', 1, Args),
    Fun1 = fun(_, AbandoningTownList) ->
        case lists:keytake(TownSid, abandoning_town:get_town_sid_index(), AbandoningTownList) of
            false ->
                {ok, ok};
            {value, AbandoningTown, NAbandoningTownList} ->
                {ok, {ok, abandoning_town:get_start_time(AbandoningTown)}, NAbandoningTownList}
        end
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'abandoning_town'), OldCorpsUid, [], Fun1, []) of
        {ok, StartTime} ->
            corps_db:del_abondoning_town_tmp(Src, OldCorpsUid, TownSid, StartTime);
        _ ->
            ok
    end,
    point_search_db:update_town_abandon_st(Src, TownSid, TownDetail, Town).

%% ----------------------------------------------------
%% @doc
%%    购买充值礼包
%% @end
%% ----------------------------------------------------
cash_notify(_, Src, 'cash_gift_award_crops_email', Args) ->
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    case role_show:get_corps_uid(RoleShow) of
        0 ->
            'ok';
        CorpsUid ->
            {_, ItemId} = lists:keyfind('item_id', 1, Args),
            case zm_config:get('cash_gift_award', ItemId) of
                'none' ->
                    'ok';
                {_, Num, AwardList} ->
                    %%修改为自己的邮件单独发送
                    {_, Cash} = lists:keyfind('bi_cash', 1, Args),
                    CashFormat = lists:flatten(io_lib:format("~.2f", [Cash / 100])),
                    MailType = award_source:get_source(?MODULE),
                    RoleSource = game_lib:get_language('mail_system_source', []),
                    Mail = mail:init({RoleSource, MailType, time_lib:now_second(), 0, {0, game_lib:get_language({mail_title, 41})}, {0, game_lib:get_language({mail_content, 41}, [CashFormat])}, AwardList}),
                    mail_db:send(Src, RoleUid, Mail),
                    RoleUids = lists:delete(RoleUid, corps_db:get_corps_members(Src, CorpsUid)),
                    RoleName = role_show:get_name(RoleShow),
                    RoleCorps = corps_db:get_role_corps(Src, RoleUid),
                    %{8, ActiveName}, {8, ActiveName, Score}
                    Source = game_lib:get_language({'corps_mail_source', role_corps:get_position(RoleCorps)}, [RoleName]),
                    corps_db:send_corps_mail(Src, CorpsUid, RoleUids, Source, MailType,
                        {0, game_lib:get_language({mail_title, 18})}, {0, game_lib:get_language({mail_content, 18}, [Num])}, AwardList)

            end
    end.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%      遣返玩家所有派遣
%% @end
%% ----------------------------------------------------
%%corps_garrison_repatriate(Src, RoleUid) ->
%%    RoleShow = role_db:get_role_show(Src, RoleUid),
%%    PointUid = role_show:get_point(RoleShow),
%%    PPStateList = z_lib:foreach(fun(Acc, Station) ->
%%        {ok, [{station:get_puid(Station), {?STATION, RoleUid}} | Acc]}
%%    end, [{PointUid, {?ROLE, RoleUid}}], station_db:get_role_stations(Src, RoleUid)),
%%    lists:foreach(fun({PUid, PState}) ->
%%        PointMarch = z_db_lib:get(game_lib:get_table(Src, 'point_march'), PUid, point_march:init()),
%%        lists:foreach(fun(OccMarching) ->
%%            {MRUid, MGId} = marching:get_roleuid_gid(OccMarching),
%%            garrison_db:repatriate(Src, RoleUid, PUid, PState, MRUid, MGId)
%%        end, point_march:get_occupy(PointMarch))
%%    end, PPStateList),
%%
%%    Garrison = garrison_db:get_garrison(Src, RoleUid),
%%    DispatchGarrays = garrison:get_dispatchs(Garrison),
%%    lists:foreach(fun({GId, RUid, PUid}) ->
%%        garrison_db:recall_dispatch(Src, RoleUid, GId, RUid, PUid)
%%    end, DispatchGarrays).


%%-------------------------------------------------------------------
%% @doc
%%      玩家进入军团
%% @end
%%-------------------------------------------------------------------
role_enter(Src, CorpsUid, RoleUid, Corps, RoleRequests) ->
    RoleShow = role_db:get_role_show(Src, RoleUid),
    Country = role_show:get_country(RoleShow),
    GarraySidList = garray_lib:get_garray_ids(Src, RoleUid),
    zm_event:notify(Src, 'bi_corps_change', [{'corps', Corps}]),
    zm_event:notify(Src, 'update_role_show', {RoleUid, {'corps', Corps}}),
    zm_event:notify(Src, {'power_change', Country}, [{'uid', RoleUid}, {'gid', GarraySidList}, {'country', Country}]),
    corps_db:insert_corps_log(Src, CorpsUid, corps_log:enter(role_show:get_name(RoleShow))),
    Fun = fun(_, List) ->
        {ok, ok, lists:keydelete(RoleUid, 1, List)}
    end,
    Table = game_lib:get_table(Src, 'corps_request'),
    lists:foreach(fun({CUid, _}) -> z_db_lib:update(Table, CUid, [], Fun, []) end, RoleRequests),
    zm_event:notify(Src, 'active_event', {'role_enter_corps', [{'role_uid', RoleUid}, {'corps', Corps}]}).

%%-------------------------------------------------------------------
%% @doc
%%      玩家退出军团
%% @end
%%-------------------------------------------------------------------
role_quit(Src, CorpsUid, RoleUid, Corps, Country) ->
    zm_event:notify(Src, 'bi_corps_change', [{'corps', Corps}]),
    zm_event:notify(Src, 'update_role_show', {RoleUid, {'corps', 'none'}}),
    CorpsCondition = corps:get_conditon(Corps),
    case corps_condition:get_enter_flag(CorpsCondition) =:= 1 of
        true ->
            RUids = corps_lib:get_request_uids(corps_db:get_corps_request(Src, CorpsUid)),
            corps_db:check_requests(Src, 0, CorpsUid, 'corps_db', 'check_request', [], 1, RUids);
        false ->
            ok
    end,
    GarraySidList = garray_lib:get_garray_ids(Src, RoleUid),
    zm_event:notify(Src, {'power_change', Country}, [{'uid', RoleUid}, {'gid', GarraySidList}, {'country', Country}]),
    zm_event:notify(Src, {'corps_power_rank', Country}, [{'uid', CorpsUid}]),

    RoleStations = station_db:get_role_stations(Src, RoleUid),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    PointUids = [role_show:get_point(RoleShow) | [station:get_puid(Station) || Station <- RoleStations]],
    PointMarchs = z_db_lib:gets(game_lib:get_table(Src, 'point_march'), PointUids, point_march:init()),

    %%遣返友军在自己驻防
    PUids = lists:usort(z_lib:foreach(fun(Acc, {PointUid, PointMarch}) ->
        lists:foreach(fun(M) ->
            {MRUid, MGId} = marching:get_roleuid_gid(M),
            case MRUid =/= RoleUid of
                true ->
                    fight_db:occ_repatriate(Src, MRUid, MGId, PointUid);
                false ->
                    ok
            end
        end, point_march:get_occupy(PointMarch)),
        {ok, point_march:get_role_march(PointMarch) ++ Acc}
    end, [], lists:zip(PointUids, PointMarchs))) -- PointUids,
    case PUids =/= [] of
        true ->
            PMarchs = z_db_lib:gets(game_lib:get_table(Src, 'point_march'), PUids, point_march:init()),
            lists:foreach(fun({PointUid, PMarch}) ->
                PointState = point_march:get_point_info(PMarch),
                PType = element(1, PointState),
                if
                    PType =:= ?ROLE orelse PType =:= ?STATION ->%%遣返所有驻防在友军的
                        RGIdList = z_lib:foreach(fun(A, M) ->
                            {MRUid, MGId} = marching:get_roleuid_gid(M),
                            case MRUid =:= RoleUid of
                                true ->
                                    {ok, lists:keystore(MRUid, 1, A, {MRUid, [MGId | z_lib:get_value(A, MRUid, [])]})};
                                false ->
                                    {ok, A}
                            end
                        end, [], point_march:get_occupy(PMarch)),
                        lists:foreach(fun({MRUid, MGIdList}) ->
                            fight_db:occ_repatriate(Src, MRUid, MGIdList, PointUid)
                        end, RGIdList);
                    PType =:= ?MAP_BUILD_CORPS orelse PType =:= ?MAP_BUILD_TOWN ->%%遣返所有驻防在建筑里的
                        RGIdList = z_lib:foreach(fun(A, M) ->
                            {MRUid, MGId} = marching:get_roleuid_gid(M),
                            case MRUid =:= RoleUid of
                                true ->
                                    {ok, lists:keystore(MRUid, 1, A, {MRUid, [MGId | z_lib:get_value(A, MRUid, [])]})};
                                false ->
                                    {ok, A}
                            end
                        end, [], point_march:get_occupy(PMarch)),
                        B = z_lib:foreach(fun(A, {MRUid, MGIdList}) ->
                            {ok, A orelse fight_db:occ_repatriate(Src, MRUid, MGIdList, PointUid) =:= "ok"}
                        end, false, RGIdList),
                        case B of
                            true ->
                                map_build_db:recalc_map_build(Src, element(3, PointState), PointUid);
                            false ->
                                ok
                        end;
                    PType =:= ?TOWN ->%%遣返所有驻防在城池里的和寻访中的
                        {RGIdList1, RGIdList2} =
                            z_lib:foreach(fun({A1, A2} = Acc, M) ->
                                {MRUid, MGId} = marching:get_roleuid_gid(M),
                                case MRUid =:= RoleUid of
                                    true ->
                                        MState = marching:get_state(M),
                                        LookState = look_fight:looking_state(MState),
                                        if
                                            LookState ->
                                                {ok, {lists:keystore(MRUid, 1, A1, {MRUid, [MGId | z_lib:get_value(A1, MRUid, [])]}), A2}};
                                            true ->
                                                {ok, {A1, lists:keystore(MRUid, 1, A2, {MRUid, [MGId | z_lib:get_value(A2, MRUid, [])]})}}
                                        end;
                                    false ->
                                        {ok, Acc}
                                end
                            end, {[], []}, point_march:get_occupy(PMarch)),
                        lists:foreach(fun({MRUid, MGIdList}) ->
                            fight_db:occ_repatriate(Src, MRUid, MGIdList, PointUid, ?ON_THE_LOOK_GOBACK_LEAVE_CORPS)
                        end, RGIdList1),
                        lists:foreach(fun({MRUid, MGIdList}) ->
                            fight_db:occ_repatriate(Src, MRUid, MGIdList, PointUid)
                        end, RGIdList2);
                    true ->
                        ok
                end
            end, lists:zip(PUids, PMarchs));
        false ->
            ok
    end.
%%    corps_garrison_repatriate(Src, RoleUid),
%%    fight_db:town_occ_marching_back(Src, RoleUid).
