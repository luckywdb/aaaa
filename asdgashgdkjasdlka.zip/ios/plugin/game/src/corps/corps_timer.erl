-module(corps_timer).

%%%=======================STATEMENT====================
-description("corps_timer").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([refresh_corps_mf_level/3, refresh_role_corps_pos_timer/3, refresh_role_corps_pos/1, refresh_abandoning_town/3]).

%%%=======================INCLUDE======================
-include("../../../include/sign_key.hrl").
-include("../include/corps.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      移除没有连续登陆的主城等级分布
%% @end
%% ----------------------------------------------------
refresh_corps_mf_level(Src, _Args, Time) ->
    corps_db:refresh_corps_mf_level(Src),
    zm_log:info(Src, ?MODULE, 'refresh_corps_mf_level', "remove_clogin", [{'time', Time}]),
    'ok'.
%% ----------------------------------------------------
%% @doc
%%      军团职位更新定时器
%% @end
%% ----------------------------------------------------
refresh_role_corps_pos_timer(Src, _Args, _Time) ->
    Bool = zm_load:server_start_ok() =:= ?KEY,
    if
        Bool ->
            Today = time_lib:get_date_by_type('day_of_year'),
            case args_expend:get_refresh_corps_position_state(Src) of
                Today ->
                    ok;
                _ ->
                    args_expend:set_get_refresh_corps_position_state(Src, Today),
                    refresh_role_corps_pos(Src)
            end;
        true ->
            ok
    end.
%% ----------------------------------------------------
%% @doc
%%      军团职位更新
%% @end
%% ----------------------------------------------------
refresh_role_corps_pos(Src) ->
    Table = game_lib:get_table(Src, 'contribute_rank'),
    RoleCorpsTable = game_lib:get_table(Src, 'role_corps'),
    {_, ExtraPos} = zm_config:get('corps', 'order_extra_pos'),
    RCInit = role_corps:init(),
    Fun1 = fun({Rank, RoleUid, CorpsLevel, CorpUid}, RoleCorps) ->
        Bl = role_corps:get_corps_uid(RoleCorps) =:= CorpUid,
        if
            Bl ->
                %%玩家当前军团和结算军团相同，才重新设置职位
                case lists:member(role_corps:get_position(RoleCorps), ExtraPos) of
                    true ->
                        {ok, true};
                    false ->
                        NewPos = get_role_corps_nor_position(Src, RoleUid, RoleCorps, CorpsLevel, Rank),
                        {ok, false, role_corps:set_position(RoleCorps, NewPos)}
                end;
            true ->
                {ok, true}
        end
    end,
    Fun2 = fun({RoleUid, _}, {Index, CorpsLevel, CorpUid}) ->
        case z_db_lib:update(RoleCorpsTable, RoleUid, RCInit, Fun1, {Index, RoleUid, CorpsLevel, CorpUid}) of
            true ->
                {Index, CorpsLevel, CorpUid};
            false ->
                {Index + 1, CorpsLevel, CorpUid}
        end
    end,
    Fun3 = fun(_Src, Key, _Args1, _R) ->
        Corps = corps_db:get_corps(Src, Key),
        CorpsLevel = if
            Corps =/= none ->
                corps:get_level(Corps);
            true ->
                -1
        end,
        ContributeList = z_db_lib:get(Table, Key, []),
        NewContributeList = lists:sort(fun({_, V1}, {_, V2}) -> V1 > V2 end, ContributeList),
        lists:foldl(Fun2, {1, CorpsLevel, Key}, NewContributeList),
        ok
    end,
    z_db_lib:table_iterate(Src, Table, Fun3, [], ok).
%%    contribute_day_award(Src).
%% ----------------------------------------------------
%% @doc
%%      遍历放弃中的城池，检查是否已经达到时间，执行放弃
%% @end
%% ----------------------------------------------------
refresh_abandoning_town(Src, _, _) ->
    Bl = zm_load:server_start_ok() =:= ?KEY,
    if
        Bl ->
            Table = game_lib:get_table(Src, 'abandoning_town'),
            TableTmp = game_lib:get_table(Src, 'abandoning_town_tmp'),
            Now = time_lib:now_second(),
            ToDay = time_lib:get_date_by_type('day_of_year'),
            {_, NeedTime} = zm_config:get('corps', 'abandoning_time'),
            Fun1 = fun(_Src, {StartTime, CorpsUid, TownSid} = Key, _, _) ->
                if
                    StartTime + NeedTime =< Now ->
                        Fun2 = fun(_, AbandoningTownList) ->
                            NAbandoningTownList = lists:keydelete(TownSid, abandoning_town:get_town_sid_index(), AbandoningTownList),
                            {ok, ok, NAbandoningTownList}
                        end,
                        z_db_lib:update(Table, CorpsUid, [], Fun2, []),
                        z_db_lib:delete(TableTmp, Key),
                        corps_db:abandon_town2(Src, CorpsUid, TownSid, Now, ToDay),
                        {ok, ok};
                    true ->
                        {break, ok}
                end
            end,
            z_db_lib:table_iterate(Src, TableTmp, Fun1, [], [], 'ascending');
        true ->
            ok
    end.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%      每日发奖
%% @end
%% ----------------------------------------------------
%%contribute_day_award(Src) ->
%%    AwardTable = game_lib:get_table(Src, 'corps_award_state'),
%%    AwardDay = z_db_lib:get(AwardTable, 'corps_award_state', 0),
%%    Today = time_lib:get_date_by_type('day_of_year'),
%%    if
%%        AwardDay =/= Today ->
%%            Table = game_lib:get_table(Src, 'role_corps'),
%%            z_db_lib:update(AwardTable, 'corps_award_state', Today),
%%            RCinit = role_corps:init(),
%%            Now = time_lib:now_second(),
%%            MailList = [{P, mail:init({0, Now, 0, {37}, {37, game_lib:get_language({'corps_pos', P})}, Award})} || {P, Award} <- zm_config:get('contribute_day_award')],
%%            Fun = fun(_Src, Key, _Args, R) ->
%%                RoleCorps = z_db_lib:get(Table, Key, RCinit),
%%                CorpsUid = role_corps:get_corps_uid(RoleCorps),
%%                if
%%                    CorpsUid =/= 0 ->
%%                        Pos = role_corps:get_position(RoleCorps),
%%                        case lists:keyfind(Pos, 1, MailList) of
%%                            {_, Mail} ->
%%                                mail_db:send(Src, Key, Mail);
%%                            _ ->
%%                                ok
%%                        end,
%%                        {ok, R};
%%                    true ->
%%                        {ok, R}
%%                end
%%            end,
%%            z_db_lib:table_iterate(Src, Table, Fun, ok, []),
%%            zm_log:info(Src, ?MODULE, 'send_mail', "send_mail", [{'time', Now}]);
%%        true ->
%%            ok
%%    end.
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
get_role_corps_nor_position(_Src, _RoleUid, _RoleCorps, -1, _) ->
    ?CORPS_POSITION_NONE;
get_role_corps_nor_position(_Src, RoleUid, RoleCorps, CorpsLevel, Rank) ->
    {_, Conditions} = zm_config:get('position_contion', CorpsLevel),
    Fun = fun({Ponsition2, Condition}, Ponsition1) ->
        case check_corps_position_condition(RoleUid, RoleCorps, Rank, Condition) of
            true ->
                min(Ponsition2, Ponsition1);
            _ ->
                Ponsition1
        end
    end,
    lists:foldl(Fun, ?CORPS_POSITION_NORMAL_E, Conditions).

%% ----------------------------------------------------
%% @doc
%%      计算玩家职位
%% @end
%% ----------------------------------------------------
check_corps_position_condition(RoleUid, RoleCorps, Rank, [Condition | Conditions]) ->
    case check_corps_position_condition_(RoleUid, RoleCorps, Rank, Condition) of
        true ->
            check_corps_position_condition(RoleUid, RoleCorps, Rank, Conditions);
        _ ->
            false
    end;
check_corps_position_condition(_RoleUid, _Contribute, _ContributeList, []) ->
    true.
check_corps_position_condition_(_RoleUid, RoleCorps, _Rank, {contribute, {MinValue, MaxValue}}) ->
    {_, ContributeList} = role_corps:get_contribute(RoleCorps),
    Contribute = case lists:keyfind('total_times', 1, ContributeList) of
        {_, Contribute_} ->
            Contribute_;
        _ ->
            0
    end,
    Contribute >= MinValue andalso Contribute < MaxValue;
check_corps_position_condition_(_RoleUid, RoleCorps, _Rank, {contribute, MinValue}) ->
    {_, ContributeList} = role_corps:get_contribute(RoleCorps),
    Contribute = case lists:keyfind('total_times', 1, ContributeList) of
        {_, Contribute_} ->
            Contribute_;
        _ ->
            0
    end,
    Contribute >= MinValue;
check_corps_position_condition_(_RoleUid, _RoleCorps, Rank, {rank, MinValue}) ->
    Rank =< MinValue;
check_corps_position_condition_(_RoleUid, _RoleCorps, _Rank, _) ->
    false.