-module(corps_help).

%%%=======================STATEMENT====================
-description("corps_help").
-copyright('youkia,www.youkia.net').
-author("ljh,lvjihong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([set_helpers/2, set_level/2, set_id/2]).
-export([get_helpers/1, get_level/1, get_id/1, get_key/1]).
-export([init/6, get_key_index/0, get_id_index/0, add_helper/2]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(corps_help, {
    id = 0 :: integer(), %%编号
    key = {} :: tuple(), %%{role_uid,   %%发起帮助请求的角色
    %% bsid,    %%queue中的id,建筑升级1，科技黑市等都是建筑自己的SID
    %% sid}     %%建筑升级下面的BSID,如果是科技就是对应科技的Sid，
    level = 0 :: integer(),%%建筑升级时3->4，记录3级
    helpers = [] :: list() %% 帮助者roleUid
}).
%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().
-type corps_help() :: #corps_help{}.

%%%=================EXPORTED FUNCTIONS=================

%% ----------------------------------------------------
%% @doc
%%      设置建筑现在等级
%% @end
%% ----------------------------------------------------
-spec set_level(corps_help(), integer()) -> corps_help().
set_level(CorpsHelp, V) ->
    CorpsHelp#corps_help{level = V}.

%% ----------------------------------------------------
%% @doc
%%      设置帮助者
%% @end
%% ----------------------------------------------------
-spec set_helpers(corps_help(), list()) -> corps_help().
set_helpers(CorpsHelp, V) ->
    CorpsHelp#corps_help{helpers = V}.

%% ----------------------------------------------------
%% @doc
%%      获取key ={RoleUid,BSid,Sid}
%% @end
%% ----------------------------------------------------
-spec get_key(corps_help()) -> tuple().
get_key(#corps_help{key = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      获取此条请求建筑现在等级
%% @end
%% ----------------------------------------------------
-spec get_level(corps_help()) -> integer().
get_level(#corps_help{level = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      获取已经帮助过此条的人roleuid
%% @end
%% ----------------------------------------------------
-spec get_helpers(corps_help()) -> list().
get_helpers(#corps_help{helpers = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%      获得key位置
%% @end
%% ----------------------------------------------------
-spec get_key_index() -> integer().
get_key_index() -> #corps_help.key.
%% ----------------------------------------------------
%% @doc
%%      获得id位置
%% @end
%% ----------------------------------------------------
-spec get_id_index() -> integer().
get_id_index() -> #corps_help.id.
%% ----------------------------------------------------
%% @doc
%%      添加一个帮助者
%% @end
%% ----------------------------------------------------
-spec add_helper(corps_help(), integer()) -> corps_help().
add_helper(CorpsHelp, RoleUid) ->
    CorpsHelp#corps_help{helpers = [RoleUid | get_helpers(CorpsHelp)]}.
%% ----------------------------------------------------
%% @doc
%%      获取编号
%% @end
%% ----------------------------------------------------
-spec get_id(corps_help()) -> integer().
get_id(#corps_help{id = V}) -> V.
%% ----------------------------------------------------
%% @doc
%%      设置编号
%% @end
%% ----------------------------------------------------
-spec set_id(corps_help(), integer()) -> corps_help().
set_id(CorpsHelp, V) ->
    CorpsHelp#corps_help{id = V}.
%% ----------------------------------------------------
%% @doc
%%      init
%% @end
%% ----------------------------------------------------
-spec init(
        Id :: integer(),
        RoleUid :: integer(),
        BSid :: integer(),
        Sid :: integer(),
        Level :: integer(),
        Helpers :: list()) -> corps_help().
init(Id, RoleUid, BSid, Sid, Level, Helpers) ->
    #corps_help{id = Id, key = {RoleUid, BSid, Sid}, level = Level, helpers = Helpers}.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
