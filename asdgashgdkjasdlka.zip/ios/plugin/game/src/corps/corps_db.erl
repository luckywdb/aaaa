-module(corps_db).

%%%=======================STATEMENT====================
-description("corps_db").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([create/3, change_banner/3, request/3, cancel_request/3, check_request/3, trans_position/3, set_position/3, quit/3, kickout/3,
         invite/3, check_invite/3, set_notice/3, replace_owner/3, abandon_town/3, set_condition/3, replace_owner_by_user/3, change_name/3]).
-export([get_corps/2, get_corps_lv/2, get_corps_town/2, get_corps_town_num/2, get_corps_by_name/2, get_corps_by_roleuid/2, get_corps_list/2,
         get_role_corps/2, get_corps_request/2, get_corps_invites/2, get_corps_members/2, get_corps_log/3,
         insert_corps_log/3, get_corps_notice/2, send_corps_mail/4, send_corps_mail/5, save_new_corps_uid/2, get_new_corps_uids/2,
         delete_new_corps_uid/2, update_corps_mf_level/5, refresh_corps_mf_level/1, get_corps_mf_level_list/3, award_exp/4]).
-export([get_corps_town_score/2]).
-export([get_corps_town_influence/2, online_format/4]).
-export([check_requests/8]).
-export([corps_gift/3, position_award/3]).

-export([award_first_enter_corps/2, donate/3]).
-export([request_help/3, get_corps_help/2, get_role_corps_help/2, help_other/3, corps_help_quit_corps/3, corps_help_queue_over/4, corps_help_queue_over2/4, corps_help_queue_over1/3]).
-export([format_help/3]).

-export([send_corps_mail/8, get_role_corps_mail/2, get_replace_owner_roleuid/3, auto_replace/3]).
-export([update_corps_show_times/4, get_corps_show/2]).
-export([get_abandoning_town/2, cancel_abandon_town/4, add_abondoning_town_tmp/4, del_abondoning_town_tmp/4, abandon_town2/5, abandon_cycle_town/5]).

-export([search_by_name/3]).
-export([get_db_ally_info/2, ally_request/3, ally_reply/3, ally_delete/3, ally_get_corps_info/3, is_ally/3, get_ally_corps_uids/2, ally_delete_corps/4, ally_get_invites/4]).
-export([change_country2_new_owner/3]).
%%%=======================INCLUDE======================
-include("../include/corps.hrl").
-include("../include/point.hrl").
-include("../include/money.hrl").
%%%=======================DEFINE======================
-define(CORPS_MAIL_TIMEOUT, 86400 * 3).
-define(CORPS_MAIL_MAX, 200).
%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%        军团赠送
%% @end
%% ----------------------------------------------------
-spec corps_gift(list(), tuple(), list()) ->
    string()|tuple().
corps_gift(_A, {Src, SelfRoleUid, GiftRoleUid, PropList}, [{Index1, SelfInfo}, {Index2, GiftRoleInfo}, {_Index3, CorpsMember}, {Index4, Storage}]) ->
    IsMember = lists:member(GiftRoleUid, CorpsMember),
    if
        IsMember ->
            PropNum = lists:foldl(fun({_Sid, Num}, TotalNum) ->
                TotalNum + Num
                                  end, 0, PropList),
            {SelfDay, SelfSendNum, SelfGetNum} = corps_lib:refresh_corps_gift_info(SelfInfo),
            {GiftRoleDay, GiftRoleSendNum, GiftRoleGetNum} = corps_lib:refresh_corps_gift_info(GiftRoleInfo),
            {_, Consumes} = zm_config:get('corps', 'corps_gift_consumes'),
            case game_lib:checks({corps_lib, check}, {Src, SelfRoleUid, SelfSendNum, PropNum, Storage}, 'corps_gift',
                                 ['send_num', {'prop', PropList} | Consumes]) of
                true ->
                    {ConsumeLogs, {_, _, {_, NewSendNum}, _, NewStorage}} = game_lib:consumes({corps_lib, consume}, {Src, SelfRoleUid, {SelfSendNum, SelfSendNum}, PropNum, Storage},
                                                                                              'corps_gift', ['send_num', {'prop', PropList} | Consumes]),
                    {ok, {ok, ConsumeLogs}, [{Index1, {SelfDay, NewSendNum, SelfGetNum}}, {Index2, {GiftRoleDay, GiftRoleSendNum, GiftRoleGetNum + PropNum}},
                                             {Index4, NewStorage}]};
                Reasion ->
                    throw(Reasion)
            end;
        true ->
            throw("not_in_same_corps")
    end.
%% ----------------------------------------------------
%% @doc  
%%        创建军团
%% @end
%% ----------------------------------------------------
-spec create(list(), tuple(), list()) ->
    string()|tuple().
create(_A, {Src, RoleUid, Name, Banner, Country}, [{Index1, RoleCorps}, {Index2, '$nil'}, {Index3, Role}, {Index4, Rmb}]) ->
    case role_corps:get_corps_uid(RoleCorps) =:= 0 of
        true ->
            CorpsUid = uid_lib:create_corps_uid(Src),
            Corps = corps:init(RoleUid, CorpsUid, Name, Country, Banner),
            {_, Conds, Consumes} = zm_config:get('corps', 'create'),
            Bool2 = game_lib:checks({corps_lib, check}, {Role, Rmb}, 'create', Conds ++ Consumes),
            if
                Bool2 ->
                    ok;
                true ->
                    throw(Bool2)
            end,
            {Cs, {NRole, NRmb}} = game_lib:consumes({corps_lib, consume}, {Role, Rmb}, 'create', Consumes),
            NewRoleCorps = role_corps:enter(RoleCorps, CorpsUid, ?CORPS_POSITION_OWNER),
            {ok, {ok, CorpsUid, Corps, role_corps:get_requests(RoleCorps), Cs, role:get_name(Role)},
             [{Index1, NewRoleCorps}, {Index2, CorpsUid}, {Index3, NRole}, {Index4, NRmb}],
             [{'corps', CorpsUid, Corps}, {'corps_member', CorpsUid, [RoleUid]}]};
        false ->
            throw("corps_was_in")
    end;
create(_A, _, _) ->
    throw("corps_name_exist").


%% ----------------------------------------------------
%% @doc
%%        修改旗帜
%% @end
%% ----------------------------------------------------
-spec change_banner(list(), tuple(), list()) ->
    string()|tuple().
change_banner(_A, {_Src, _RoleUid, Banner}, [{Index1, Corps}, {Index2, Rmb}]) ->
    case corps:get_banner(Corps) =/= Banner of
        true ->
            {_, Consumes} = zm_config:get('corps', 'change_banner_consumes'),
            Bool2 = game_lib:checks({corps_lib, check}, {Rmb}, 'change_banner', Consumes),
            if
                Bool2 ->
                    {Cs, {NRmb}} = game_lib:consumes({corps_lib, consume}, {Rmb}, 'change_banner', Consumes),
                    NCorps = corps:set_banner(Corps, Banner),
                    {ok, {ok, NCorps, Cs}, [{Index1, NCorps}, {Index2, NRmb}]};
                true ->
                    throw(Bool2)
            end;
        false ->
            throw("input_error")
    end.
%% ----------------------------------------------------
%% @doc
%%        申请加入军团
%% @end
%% ----------------------------------------------------
-spec request(list(), tuple(), list()) ->
    string()|tuple().
request(_A, {_Src, RoleUid, CorpsUid, Now, OnlineTime, InCrossBattle}, [{Index1, Corps}, {Index2, CorpsRequests}, {Index3, RoleCorps}, {Index4, CorpsMembers}]) ->
    case Corps =:= none orelse corps:get_state(Corps) =:= ?CORPS_STATE_DISSOLVE of
        true ->
            throw("corps_not_find");
        false ->
            ok
    end,
    case role_corps:get_corps_uid(RoleCorps) =/= 0 of
        true ->
            throw("corps_was_in");
        false ->
            ok
    end,
    case corps_lib:check_condition(OnlineTime, RoleCorps) of
        true ->
            ok;
        Err1 ->
            throw(Err1)
    end,
    RoleRequests = corps_lib:get_requests(role_corps:get_requests(RoleCorps)),
    case lists:keyfind(CorpsUid, 1, RoleRequests) of
        false ->
            ok;
        _ ->
            throw("corps_was_request")
    end,
    CorpsCondition = corps:get_conditon(Corps),
    {_, CorpsLvList} = zm_config:get('corps_level', corps:get_level(Corps)),
    MaxMemNum = z_lib:get_value(CorpsLvList, 'max_mem_num', 0),
    MemNum = length(CorpsMembers),
    case (not InCrossBattle) andalso corps_condition:get_enter_flag(CorpsCondition) =:= 1 andalso MemNum < MaxMemNum of
        true ->
            NRoleCorps = role_corps:enter(RoleCorps, CorpsUid, ?CORPS_POSITION_NORMAL_E),
            NCorpsMembers = [RoleUid | CorpsMembers],
            NCorps = corps:set_mem_num(Corps, MemNum + 1),
            {ok, {'enter', NCorps, role_corps:get_requests(RoleCorps)}, [{Index1, NCorps}, {Index3, NRoleCorps}, {Index4, NCorpsMembers}]};
        false ->
            {_, {RoleMax, CorpsMax}} = zm_config:get('corps', 'corps_request_max_num'),
            case length(RoleRequests) >= RoleMax of
                true ->
                    throw("corps_role_request_num_limit");
                false ->
                    ok
            end,
            NCorpsRequests1 = corps_lib:get_requests(CorpsRequests),
            case length(NCorpsRequests1) >= CorpsMax of
                true ->
                    throw("corps_request_num_limit");
                false ->
                    ok
            end,
            NRoleRequests = [{CorpsUid, Now} | RoleRequests],
            NRoleCorps = role_corps:set_requests(RoleCorps, NRoleRequests),
            NCorpsRequests = lists:keystore(RoleUid, 1, NCorpsRequests1, {RoleUid, Now}),
            {ok, {'request', Corps}, [{Index2, NCorpsRequests}, {Index3, NRoleCorps}]}
    end.

%% ----------------------------------------------------
%% @doc
%%        发出加入军团邀请
%% @end
%% ----------------------------------------------------
-spec invite(list(), tuple(), list()) ->
    string()|tuple().
invite(_A, {_Src, _RoleUid, RUid, CorpsUid}, [{_, RC}, {_Index1, Corps}, {Index2, CorpsInvites1}, {Index3, RoleCorps}]) ->
    case corps_lib:check_position_limit('trans_position', role_corps:get_position(RC)) of
        true ->
            ok;
        Err ->
            throw(Err)
    end,
    case role_corps:get_corps_uid(RoleCorps) =/= 0 of
        true ->
            throw("corps_was_in");
        false ->
            ok
    end,
    {_, CorpsLvList} = zm_config:get('corps_level', corps:get_level(Corps)),
    MaxMemNum = z_lib:get_value(CorpsLvList, 'max_mem_num', 0),
    MemNum = corps:get_mem_num(Corps),
    case MemNum >= MaxMemNum of
        true ->
            throw("corps_member_num_limit");
        false ->
            ok
    end,
    {_, {CorpsMax, RoleMax}} = zm_config:get('corps', 'invite_max_num'),
    RoleInvites = corps_lib:get_invites(role_corps:get_invites(RoleCorps)),
    case lists:keyfind(CorpsUid, 1, RoleInvites) of
        false ->
            CorpsInvites = corps_lib:get_invites(CorpsInvites1),
            case length(CorpsInvites) >= CorpsMax of
                true ->
                    throw("corps_invite_num_limit");
                false ->
                    ok
            end,
            case length(RoleInvites) >= RoleMax of
                true ->
                    throw("corps_role_invite_num_limit");
                false ->
                    ok
            end,
            Now = time_lib:now_second(),
            NCorpsInvites = lists:keystore(RUid, 1, CorpsInvites, {RUid, Now}),
            NRoleInvites = [{CorpsUid, Now} | RoleInvites],
            NRoleCorps = role_corps:set_invites(RoleCorps, NRoleInvites),
            {ok, {ok, Corps}, [{Index2, NCorpsInvites}, {Index3, NRoleCorps}]};
        _ ->
            {ok, ignore}
    end.


%% ----------------------------------------------------
%% @doc
%%        同意/拒绝军团邀请
%% @end
%% ----------------------------------------------------
-spec check_invite(list(), tuple(), list()) ->
    string()|tuple().
check_invite(_A, {_Src, RoleUid, CorpsUid, Type, OnlineTime}, [{Index1, RoleCorps}, {Index2, Corps}, {Index3, CorpsInvites}, {Index4, CorpsMembers}]) ->
    case Corps =:= none orelse corps:get_state(Corps) =:= ?CORPS_STATE_DISSOLVE of
        true ->
            throw("corps_not_find");
        false ->
            ok
    end,
    case role_corps:get_corps_uid(RoleCorps) =/= 0 of
        true ->
            throw("corps_was_in");
        false ->
            ok
    end,
    RoleInvites = corps_lib:get_invites(role_corps:get_invites(RoleCorps)),
    case lists:keyfind(CorpsUid, 1, RoleInvites) of
        false ->
            throw("corps_no_invite");
        _ ->
            ok
    end,
    NRoleInvites = lists:keydelete(CorpsUid, 1, RoleInvites),
    NCorpsInvites = lists:keydelete(RoleUid, 1, corps_lib:get_invites(CorpsInvites)),
    case Type of
        0 ->
            NRoleCorps = role_corps:set_invites(RoleCorps, NRoleInvites),
            {ok, {ok, Corps, NRoleInvites}, [{Index1, NRoleCorps}, {Index3, NCorpsInvites}]};
        1 ->
            case corps_lib:check_condition(OnlineTime, RoleCorps) of
                true ->
                    ok;
                Err1 ->
                    throw(Err1)
            end,
            {_, CorpsLvList} = zm_config:get('corps_level', corps:get_level(Corps)),
            MaxMemNum = z_lib:get_value(CorpsLvList, 'max_mem_num', 0),
            MemNum = length(CorpsMembers),
            case MemNum >= MaxMemNum of
                true ->
                    NRoleCorps = role_corps:set_invites(RoleCorps, NRoleInvites),
                    {ok, "corps_member_num_limit", [{Index1, NRoleCorps}, {Index3, NCorpsInvites}]};
                false ->
                    NRoleCorps = role_corps:enter(RoleCorps, CorpsUid, ?CORPS_POSITION_NORMAL_E),
                    NCorpsMembers = [RoleUid | CorpsMembers],
                    NCorps = corps:set_mem_num(Corps, MemNum + 1),
                    {ok, {ok, NCorps, role_corps:get_requests(RoleCorps)}, [{Index1, NRoleCorps}, {Index2, NCorps}, {Index3, NCorpsInvites}, {Index4, NCorpsMembers}]}
            end
    end.

%% ----------------------------------------------------
%% @doc
%%        申请加入军团
%% @end
%% ----------------------------------------------------
-spec cancel_request(list(), tuple(), list()) ->
    string()|tuple().
cancel_request(_A, {_Src, RoleUid, CorpsUid}, [{_Index1, Corps}, {Index2, CorpsRequests}, {Index3, RoleCorps}]) ->
    case Corps =:= none orelse corps:get_state(Corps) =:= ?CORPS_STATE_DISSOLVE of
        true ->
            throw("corps_not_find");
        false ->
            ok
    end,
    case role_corps:get_corps_uid(RoleCorps) =/= 0 of
        true ->
            throw("corps_was_in");
        false ->
            ok
    end,
    RoleRequests = corps_lib:get_requests(role_corps:get_requests(RoleCorps)),
    case lists:keyfind(CorpsUid, 1, RoleRequests) of
        false ->
            throw("corps_not_request");
        _ ->
            ok
    end,
    NRoleRequests = lists:keydelete(CorpsUid, 1, RoleRequests),
    NRoleCorps = role_corps:set_requests(RoleCorps, NRoleRequests),
    NCorpsRequests1 = corps_lib:get_requests(CorpsRequests),
    NCorpsRequests = lists:keydelete(RoleUid, 1, NCorpsRequests1),
    {ok, {ok, Corps}, [{Index2, NCorpsRequests}, {Index3, NRoleCorps}]}.

%%-------------------------------------------------------------------
%% @doc
%%      批量同意拒绝请求
%% @end
%%-------------------------------------------------------------------
check_requests(Src, RoleUid, CorpsUid, M, F, A, Type, RUids) ->
    case Type =:= 0 orelse not cross_battle_db:check_corps_in_cross_battle(Src, CorpsUid) of
        true ->
            Fun = fun({_, RRequstAcc, Acc} = Args, RUid) ->
                TableName = game_lib:get_table(Src),
                TableKeys =
                    case RoleUid =:= 0 of
                        true ->
                            z_db_lib:transformation_tablekey(TableName,
                                                             [
                                                                 {'corps', CorpsUid, 'none'},
                                                                 {'corps_request', CorpsUid, []},
                                                                 {'role_corps', RUid, role_corps:init()},
                                                                 {'corps_member', CorpsUid}
                                                             ]);
                        false ->
                            z_db_lib:transformation_tablekey(TableName,
                                                             [
                                                                 {'corps', CorpsUid, 'none'},
                                                                 {'corps_request', CorpsUid, []},
                                                                 {'role_corps', RUid, role_corps:init()},
                                                                 {'corps_member', CorpsUid},
                                                                 {'role_corps', RoleUid}
                                                             ])
                    end,
                Reply = z_db_lib:handle(TableName, {M, F, A}, {Src, RUid, CorpsUid, Type}, TableKeys),
                case Reply of
                    {ok, Corps, NRoleRequests} ->
                        {ok, {Corps, [{RUid, NRoleRequests} | RRequstAcc], [RUid | Acc]}};
                    "corps_member_num_limit" ->
                        {'break', Args};
                    _ ->
                        {ok, Args}

                end
                  end,
            {Corps, RRequests, CRUids} = z_lib:foreach(Fun, {'none', [], []}, RUids),
            if
                CRUids =/= [] ->
                    zm_event:notify(Src, 'corps_check_request', [{'role_uid', RoleUid}, {'ruids', CRUids}, {'corps_uid', CorpsUid}, {'type', Type},
                                                                 {'corps', Corps}, {'role_requests', RRequests}]);
                true ->
                    ok
            end,
            CRUids;
        false ->
            []
    end.

%% ----------------------------------------------------
%% @doc
%%        同意/拒绝玩家申请加入军团
%% @end
%% ----------------------------------------------------
-spec check_request(list(), tuple(), list()) ->
    string()|tuple().
check_request(_A, {_Src, RoleUid, CorpsUid, Type}, [{Index1, Corps}, {Index2, CorpsRequests}, {Index3, RoleCorps}, {Index4, CorpsMembers} | T]) ->
    case T of
        [{_, RC}] ->
            case corps_lib:check_position_limit('check_request', role_corps:get_position(RC)) of
                true ->
                    ok;
                Err ->
                    throw(Err)
            end;
        [] ->
            ok
    end,
    case role_corps:get_corps_uid(RoleCorps) =/= 0 of
        true ->
            throw("corps_was_in");
        false ->
            ok
    end,
    NCorpsRequests1 = corps_lib:get_requests(CorpsRequests),
    case lists:keyfind(RoleUid, 1, NCorpsRequests1) of
        false ->
            throw("corps_not_request");
        _ ->
            ok
    end,
    RoleRequests = corps_lib:get_requests(role_corps:get_requests(RoleCorps)),
    NRoleRequests = lists:keydelete(CorpsUid, 1, RoleRequests),
    NCorpsRequests = lists:keydelete(RoleUid, 1, NCorpsRequests1),
    case Type of
        0 ->
            NRoleCorps = role_corps:set_requests(RoleCorps, NRoleRequests),
            {ok, {ok, Corps, NRoleRequests}, [{Index2, NCorpsRequests}, {Index3, NRoleCorps}]};
        1 ->
            {_, CorpsLvList} = zm_config:get('corps_level', corps:get_level(Corps)),
            MaxMemNum = z_lib:get_value(CorpsLvList, 'max_mem_num', 0),
            MemNum = length(CorpsMembers),
            case MemNum >= MaxMemNum of
                true ->
                    throw("corps_member_num_limit");
                false ->
                    ok
            end,
            NRoleCorps = role_corps:enter(RoleCorps, CorpsUid, ?CORPS_POSITION_NORMAL_E),
            NCorpsMembers = [RoleUid | CorpsMembers],
            NCorps = corps:set_mem_num(Corps, MemNum + 1),
            {ok, {ok, NCorps, NRoleRequests}, [{Index1, NCorps}, {Index2, NCorpsRequests}, {Index3, NRoleCorps}, {Index4, NCorpsMembers}]}
    end.
%% ----------------------------------------------------
%% @doc
%%        军团转让职位
%% @end
%% ----------------------------------------------------
-spec trans_position(list(), tuple(), list()) ->
    string()|tuple().
trans_position(_A, {_Src, RoleUid1, RoleUid2}, [{Index1, RoleCorps1}, {Index2, RoleCorps2}, {Index3, Corps}]) ->
    Position1 = role_corps:get_position(RoleCorps1),
    case corps_lib:check_position_limit('trans_position', Position1) of
        true ->
            ok;
        Err ->
            throw(Err)
    end,
    CorpsUid1 = role_corps:get_corps_uid(RoleCorps1),
    CorpsUid2 = role_corps:get_corps_uid(RoleCorps2),
    case CorpsUid1 =:= 0 of
        true ->
            throw("corps_not_in");
        false ->
            ok
    end,
    case CorpsUid1 =:= 0 orelse CorpsUid1 =/= CorpsUid2 of
        true ->
            throw("corps_not_member");
        false ->
            ok
    end,
    Position2 = role_corps:get_position(RoleCorps2),

    case Position1 >= Position2 of
        true ->
            throw("corps_position_limit");
        false ->
            ok
    end,
    NRoleCorps1 = role_corps:set_position(RoleCorps1, ?CORPS_POSITION_NORMAL_E),
    NRoleCorps2 = role_corps:set_position(RoleCorps2, Position1),
    Owner =
        case Position1 =:= ?CORPS_POSITION_OWNER of
            true ->
                RoleUid2;
            false ->
                corps:get_owner(Corps)
        end,
    ViceOwnerList = corps:get_vice_owner_list(Corps) -- [RoleUid1, RoleUid2],
    NViceOwnerList =
        if
            Position1 =:= ?CORPS_POSITION_VICE_OWNER ->
                [RoleUid2 | lists:delete(RoleUid1, ViceOwnerList)];
            Position2 =:= ?CORPS_POSITION_VICE_OWNER ->
                lists:delete(RoleUid2, ViceOwnerList);
            true ->
                ViceOwnerList
        end,
    NCorps = corps:set_vice_owner_list(corps:set_owner(Corps, Owner), NViceOwnerList),
    {ok, {ok, NCorps, Position2, Position1}, [{Index1, NRoleCorps1}, {Index2, NRoleCorps2}, {Index3, NCorps}]}.

%% ----------------------------------------------------
%% @doc
%%        军团设置职位
%% @end
%% ----------------------------------------------------
-spec set_position(list(), tuple(), list()) ->
    string()|tuple().
set_position(_A, {_Src, RUid, Position}, [{_Index1, RoleCorps1}, {Index2, RoleCorps2}, {Index3, Corps}]) ->
    Position1 = role_corps:get_position(RoleCorps1),
    case corps_lib:check_position_limit('set_position', Position1) of
        true ->
            ok;
        Err ->
            throw(Err)
    end,
    CorpsUid1 = role_corps:get_corps_uid(RoleCorps1),
    CorpsUid2 = role_corps:get_corps_uid(RoleCorps2),
    case CorpsUid1 =:= 0 of
        true ->
            throw("corps_not_in");
        false ->
            ok
    end,
    case CorpsUid1 =/= CorpsUid2 of
        true ->
            throw("corps_not_member");
        false ->
            ok
    end,
    Position2 = role_corps:get_position(RoleCorps2),
    case Position1 >= Position2 orelse Position =< Position1 of
        true ->
            throw("corps_position_limit");
        false ->
            ok
    end,
    {_, CorpsLvList} = zm_config:get('corps_level', corps:get_level(Corps)),
    MaxViceOwnerNum = z_lib:get_value(CorpsLvList, 'max_vice_owner_num', 0),
    NRoleCorps2 = role_corps:set_position(RoleCorps2, Position),
    ViceOwnerList = corps:get_vice_owner_list(Corps),
    NViceOwnerList =
        if
            Position =:= ?CORPS_POSITION_VICE_OWNER ->
                [RUid | ViceOwnerList];
            true ->
                lists:delete(RUid, ViceOwnerList)
        end,
    case length(NViceOwnerList) > MaxViceOwnerNum of
        true ->
            throw("corps_vice_owner_num_limit");
        false ->
            ok
    end,
    NCorps = corps:set_vice_owner_list(Corps, NViceOwnerList),
    {ok, {ok, NCorps, Position2}, [{Index2, NRoleCorps2}, {Index3, NCorps}]}.

%% ----------------------------------------------------
%% @doc
%%        退出军团
%% @end
%% ----------------------------------------------------
-spec quit(list(), tuple(), list()) ->
    string()|tuple().
quit(_A, {_Src, RoleUid, IsCrossBattle}, [{Index1, RoleCorps}, {Index2, Corps}, {Index3, CorpsMembers}]) ->
    case role_corps:get_corps_uid(RoleCorps) =:= 0 of
        true ->
            throw("corps_not_in");
        false ->
            ok
    end,
    if
        length(CorpsMembers) =:= 1 ->
            case IsCrossBattle of
                true ->
                    throw("corps_in_cross_battle");
                false ->
                    NCorpsMembers = lists:delete(RoleUid, CorpsMembers),
                    NCorps = corps:set_state(Corps, ?CORPS_STATE_DISSOLVE),
                    NRoleCorps = role_corps:exit(RoleCorps),
                    {ok, {ok, NCorps, NCorpsMembers}, [{Index1, NRoleCorps}, {Index2, NCorps}]}
            end;
        true ->
            NCorpsMembers = lists:delete(RoleUid, CorpsMembers),
            NRoleCorps = role_corps:exit(RoleCorps),
            NCorps = corps:set_vice_owner_list(corps:set_mem_num(Corps, length(NCorpsMembers)), lists:delete(RoleUid, corps:get_vice_owner_list(Corps))),
            {ok, {ok, NCorps, NCorpsMembers}, [{Index1, NRoleCorps}, {Index2, NCorps}, {Index3, NCorpsMembers}]}
    end.

%% ----------------------------------------------------
%% @doc
%%        踢出军团
%% @end
%% ----------------------------------------------------
-spec kickout(list(), tuple(), list()) ->
    string()|tuple().
kickout(_A, {_Src, RoleUid}, [{_, RC}, {Index1, RoleCorps}, {Index2, Corps}, {Index3, CorpsMembers}]) ->
    case corps_lib:check_position_limit('kickout', role_corps:get_position(RC)) of
        true ->
            ok;
        Err ->
            throw(Err)
    end,
    case role_corps:get_position(RC) >= role_corps:get_position(RoleCorps) of
        true ->
            throw("corps_position_limit");
        false ->
            ok
    end,
    case lists:member(RoleUid, CorpsMembers) of
        false ->
            throw("corps_not_member");
        true ->
            ok
    end,
    NCorpsMembers = lists:delete(RoleUid, CorpsMembers),
    NRoleCorps = role_corps:exit(RoleCorps),
    NCorps = corps:set_vice_owner_list(corps:set_mem_num(Corps, length(NCorpsMembers)), lists:delete(RoleUid, corps:get_vice_owner_list(Corps))),
    {ok, {ok, NCorps, NCorpsMembers}, [{Index1, NRoleCorps}, {Index2, NCorps}, {Index3, NCorpsMembers}]}.

%% ----------------------------------------------------
%% @doc
%%        设置公告(0:对内公告 1:对外公告)
%% @end
%% ----------------------------------------------------
-spec set_notice(list(), tuple(), list()) ->
    string()|tuple().
set_notice(_A, {_Src, CorpsUid, Context, Type, PositionType}, [{Index1, {PrivateTime, PrivateText, PulicTime, PulicText}}, {_, RoleCorps}]) ->
    CUid = role_corps:get_corps_uid(RoleCorps),
    if
        CUid =:= CorpsUid ->
            ok;
        true ->
            throw("corps_not_in")
    end,
    Position = role_corps:get_position(RoleCorps),
    CheckPositionBool = corps_lib:check_position_limit(PositionType, Position),
    if
        CheckPositionBool ->
            ok;
        true ->
            throw(CheckPositionBool)
    end,
    NowTime = time_lib:now_second(),
    NText = if
                Type =:= 0 ->
                    {NowTime, Context, PulicTime, PulicText};
                true ->
                    {PrivateTime, PrivateText, NowTime, Context}
            end,
    {ok, {ok, NowTime}, [{Index1, NText}]}.


%% ----------------------------------------------------
%% @doc
%%  获取取代军团长的uid
%% @end
%% ----------------------------------------------------
get_replace_owner_roleuid(Src, CorpsUid, Corps) ->
    VList = corps:get_vice_owner_list(Corps),
    Now = time_lib:now_second(),
    {_, Conditions} = zm_config:get('corps', 'replace_owner_conditions'),
    {_, ActiveTime} = zm_config:get('corps', 'replace_active_time'),
    Members = corps_db:get_corps_members(Src, CorpsUid),
    %%团员 -> 1天
    RankList = z_db_lib:get(game_lib:get_table(Src, 'contribute_rank'), CorpsUid, []),
    case VList of
        [] ->
            {get_replace_owner_roleuid_(Src, VList, Now, Members, ActiveTime, RankList), Members};
        _ ->
            Fun = fun({AUid, AInTime, AOutTime} = Acc, {Uid, Guser}) ->
                case game_lib:checks({corps_lib, check}, Guser, 'replace_owner', Conditions) of
                    true ->
                        {ok, Acc};
                    _ ->
                        InTime1 = guser:get_login_time(Guser),
                        OutTime1 = guser:get_logout_time(Guser),
                        if
                            AInTime =:= 0 andalso AOutTime =:= 0 ->
                                {ok, {Uid, InTime1, OutTime1}};
                            true -> %两个副团长都3天内登录过时候,按贡献高的
                                ACNum = z_lib:get_value(RankList, AUid, 0),
                                CNum = z_lib:get_value(RankList, Uid, 0),
                                if
                                    ACNum > CNum ->
                                        {ok, Acc};
                                    true ->
                                        {ok, {Uid, InTime1, OutTime1}}
                                end
                        end
                end
                  end,
            {VUid, _, _} = z_lib:foreach(Fun, {0, 0, 0}, lists:zip(VList, z_db_lib:gets(game_lib:get_table(Src, 'user'), VList))),
            if
                VUid =:= 0 ->
                    {get_replace_owner_roleuid_(Src, VList, Now, Members, ActiveTime, RankList), Members};
                true ->
                    {VUid, Members}
            end
    end.

%% ----------------------------------------------------
%% @doc
%%  获取最活跃军团玩家uid
%% @end
%% ----------------------------------------------------
get_replace_owner_roleuid_(Src, VList, Now, Members, ActiveTime, RankList) ->
    Table = game_lib:get_table(Src, 'user'),
    case lists:filter(fun(Uid) ->
        GUser = z_db_lib:get(Table, Uid),
        OutTime = guser:get_logout_time(GUser),
        InTime = guser:get_login_time(GUser),
        InTime > OutTime orelse Now - OutTime < ActiveTime
                      end, Members-- VList) of
        [] ->
            0;
        Filters ->
            case lists:sort(fun({_, V1}, {_, V2}) -> V1 > V2 end, lists:filter(fun({Id, _}) ->
                lists:member(Id, Filters) end,                                 RankList)) of
                [] ->
                    hd(Filters);
                [{RoleUid, _} | _] ->
                    RoleUid
            end
    end.

%% ----------------------------------------------------
%% @doc
%%        取代团长
%% @end
%% ----------------------------------------------------
-spec replace_owner(list(), tuple(), list()) ->
    string()|tuple().
replace_owner(_A, {_Src, _RoleUid, _OldOwnerUid, Today}, [_, _, _, {_Index4, Today}]) ->
    throw("today_changed");
replace_owner(_A, {_Src, RoleUid, _OldOwnerUid, Today}, [{Index1, Corps}, {Index2, RoleCorps1}, {Index3, RoleCorps2}, {Index4, _}]) ->
    case role_corps:get_position(RoleCorps2) =:= ?CORPS_POSITION_OWNER of
        true ->
            ok;
        false ->
            throw("corps_only_replace_owner")
    end,
    NCorps =
        case role_corps:get_position(RoleCorps1) =:= ?CORPS_POSITION_VICE_OWNER of
            true ->
                ViceOwnerList = lists:delete(RoleUid, corps:get_vice_owner_list(Corps)),
                corps:set_vice_owner_list(corps:set_owner(Corps, RoleUid), ViceOwnerList);
            false ->
                corps:set_owner(Corps, RoleUid)
        end,
    NRoleCorps1 = role_corps:set_position(RoleCorps1, ?CORPS_POSITION_OWNER),
    NRoleCorps2 = role_corps:set_position(RoleCorps2, ?CORPS_POSITION_NORMAL_E),
    {ok, {ok, NCorps}, [{Index1, NCorps}, {Index2, NRoleCorps1}, {Index3, NRoleCorps2}, {Index4, Today}]}.

%% ----------------------------------------------------
%% @doc
%%        手动取代团长
%% @end
%% ----------------------------------------------------
-spec replace_owner_by_user(list(), tuple(), list()) ->
    string()|tuple().
replace_owner_by_user(_A, {_Src, RoleUid, _RUid}, [{Index1, Corps}, {Index2, RoleCorps1}, {Index3, RoleCorps2}, {_, GUser}]) ->
    case role_corps:get_corps_uid(RoleCorps1) =:= role_corps:get_corps_uid(RoleCorps2) of
        true ->
            ok;
        false ->
            throw("input_error")
    end,
    case role_corps:get_position(RoleCorps2) =:= ?CORPS_POSITION_OWNER of
        true ->
            ok;
        false ->
            throw("corps_only_replace_owner")
    end,
    {_, Conditions} = zm_config:get('corps', 'replace_owner_conditions'),
    Bool = game_lib:checks({corps_lib, check}, GUser, 'replace_owner', Conditions),
    if
        Bool ->
            ok;
        true ->
            throw(Bool)
    end,
    NCorps =
        case role_corps:get_position(RoleCorps1) =:= ?CORPS_POSITION_VICE_OWNER of
            true ->
                ViceOwnerList = lists:delete(RoleUid, corps:get_vice_owner_list(Corps)),
                corps:set_vice_owner_list(corps:set_owner(Corps, RoleUid), ViceOwnerList);
            false ->
                corps:set_owner(Corps, RoleUid)
        end,
    NRoleCorps1 = role_corps:set_position(RoleCorps1, ?CORPS_POSITION_OWNER),
    NRoleCorps2 = role_corps:set_position(RoleCorps2, ?CORPS_POSITION_NORMAL_E),
    {ok, {ok, NCorps}, [{Index1, NCorps}, {Index2, NRoleCorps1}, {Index3, NRoleCorps2}]}.

%% ----------------------------------------------------
%% @doc
%%      点击放弃城池，开始放弃倒计时
%% @end
%% ----------------------------------------------------
-spec abandon_town(list(), tuple(), list()) ->
    string()|tuple().
abandon_town(_A, {_Src, TownSid, Now, Pos, AbandoningNum}, [{Index1, AbandoningTownList}]) ->
    case length(AbandoningTownList) >= AbandoningNum of
        true ->
            throw("corps_town_abandon_times_limit");
        false ->
            ok
    end,
    AbandoningTown = abandoning_town:init(TownSid, Now, Pos),
    {ok, ok, [{Index1, [AbandoningTown | AbandoningTownList]}]}.
%% ----------------------------------------------------
%% @doc
%%      放弃城池
%% @end
%% ----------------------------------------------------
abandon_town2(Src, CorpsUid, TownSid, Now, ToDay) ->
    TownDetail = town_detail:get_cfg(TownSid),
    %%需不需要判断城池是否是这个军团的
    town_fight:over(Src, TownSid, Now, [], true),
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName,
                                                 [
                                                     {'corps_town', CorpsUid, corps_town:init()},
                                                     {'town', TownSid, town:init(TownDetail)}
                                                 ]),
    Fun1 = fun(_, [{Index1, CorpsTown}, {Index2, Town}]) ->
        case town:get_corps_uid(Town) of
            CorpsUid ->
                ATimes = corps_town:get_atimes(CorpsTown),
                Times = case element(1, ATimes) =:= ToDay of
                            true ->
                                element(2, ATimes);
                            false ->
                                0
                        end,
                IsChief = town_detail:chk_chief(TownDetail),
                NCorpsTown = corps_town:del_olist(corps_town:set_atimes(CorpsTown, {ToDay, Times + 1}), TownSid, IsChief, TownDetail),
                NTown = town:win_fight(Town, TownDetail, Now, 0, 0, false), %主动放弃城池不扣经验
                {ok, {ok, NTown, town:get_fight_uids(Town)}, [{Index1, NCorpsTown}, {Index2, NTown}]};
            _ ->
                {ok, ok}
        end
           end,
    case z_db_lib:handle(TableName, Fun1, [], TableKeys) of
        {ok, Town, FightUids} ->
            point_search_db:update_town_abandon_st(Src, TownSid, TownDetail, Town),
            zm_event:notify(Src, 'corps_abandon_town', [{'corps_uid', CorpsUid}, {'town_sid', TownSid}, {'town', Town}, {'fight_cuids', FightUids}]);
        _ ->
            ok
    end.

%% ----------------------------------------------------
%% @doc
%%      放弃周期城池
%% @end
%% ----------------------------------------------------
abandon_cycle_town(Src, CorpsUid, TownSid, Now, ToDay) ->
    TownDetail = town_detail:get_cfg(TownSid),
    %%需不需要判断城池是否是这个军团的
    town_fight:over(Src, TownSid, Now, [], true),
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName,
                                                 [
                                                     {'corps_town', CorpsUid, corps_town:init()},
                                                     {'town', TownSid, town:init(TownDetail)}
                                                 ]),
    Fun1 = fun(_, [{Index1, CorpsTown}, {Index2, Town}]) ->
        case town:get_corps_uid(Town) of
            CorpsUid ->
                ATimes = corps_town:get_atimes(CorpsTown),
                Times = case element(1, ATimes) =:= ToDay of
                            true ->
                                element(2, ATimes);
                            false ->
                                0
                        end,
                IsChief = town_detail:chk_chief(TownDetail),
                NCorpsTown = corps_town:del_olist(corps_town:set_atimes(CorpsTown, {ToDay, Times + 1}), TownSid, IsChief, TownDetail),
                NTown = town:win_fight(Town, TownDetail, Now, 0, 0, false), %主动放弃城池不扣经验
                {ok, {ok, NTown, town:get_fight_uids(Town)}, [{Index1, NCorpsTown}, {Index2, NTown}]};
            _ ->
                {ok, ok}
        end
           end,
    case z_db_lib:handle(TableName, Fun1, [], TableKeys) of
        {ok, Town, FightUids} ->
            point_search_db:update_town_abandon_st(Src, TownSid, TownDetail, Town),
            zm_event:notify(Src, 'corps_abandon_cycle_town', [{'corps_uid', CorpsUid}, {'town_sid', TownSid}, {'town', Town}, {'fight_cuids', FightUids}]);
        _ ->
            ok
    end.

%% ----------------------------------------------------
%% @doc
%%       取消放弃城池
%% @end
%% ----------------------------------------------------
cancel_abandon_town(Src, TownSid, CorpsUid, Pos) ->
    Now = time_lib:now_second(),
    Index = abandoning_town:get_town_sid_index(),
    {_, NeedTime} = zm_config:get('corps', 'abandoning_time'),
    Fun1 = fun(_, AbandoningTownList) ->
        case lists:keyfind(TownSid, Index, AbandoningTownList) of
            false ->
                throw("no_abandoing_town");
            AbandoningTown ->
                StartTime = abandoning_town:get_start_time(AbandoningTown),
                AbandonPos = abandoning_town:get_pos(AbandoningTown),
                if
                    Now =< StartTime + NeedTime ->
                        CheckType = if
                                        AbandonPos =:= ?CORPS_POSITION_OWNER ->
                                            'cancel_owner_abandon_tow';
                                        true ->
                                            'cancel_vice_owner_abandon_tow'
                                    end,
                        case corps_lib:check_position_limit(CheckType, Pos) of
                            true ->
                                NAbandoningList = lists:keydelete(TownSid, Index, AbandoningTownList),
                                {ok, {ok, StartTime}, NAbandoningList};
                            Err ->
                                throw(Err)
                        end;
                    true ->
                        throw("time_error")
                end
        end
           end,
    z_db_lib:update(game_lib:get_table(Src, 'abandoning_town'), CorpsUid, [], Fun1, []).
%%-------------------------------------------------------------------
%% @doc
%%      设置军团条件
%% @end
%%-------------------------------------------------------------------
set_condition(_, {_Src, _RoleUid, CorpsUid, {EnterFlag, RequestFlag, RequestRoleLv, RequestRoleCastLv}}, [{Index1, Corps}, {_Index2, RoleCorps}]) ->
    CorpsUid = role_corps:get_corps_uid(RoleCorps),
    Pos = role_corps:get_position(RoleCorps),
    case corps_lib:check_position_limit('set_conditon', Pos) of
        true ->
            CorpsCondition = corps:get_conditon(Corps),
            NCorpsCondition = corps_condition:update(CorpsCondition, {EnterFlag, RequestFlag, RequestRoleLv, RequestRoleCastLv}),
            NCorps = corps:set_conditon(Corps, NCorpsCondition),
            {ok, {ok, CorpsCondition, NCorpsCondition}, [{Index1, NCorps}]};
        Err ->
            throw(Err)
    end.

%% ----------------------------------------------------
%% @doc
%%        得到军团
%% @end
%% ----------------------------------------------------
-spec get_corps(atom(), integer()) -> 'none' | corps:corps().
get_corps(Src, CorpsUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'corps'), CorpsUid, 'none').

%% ----------------------------------------------------
%% @doc
%%        得到军团等级
%% @end
%% ----------------------------------------------------
-spec get_corps_lv(atom(), integer()) -> integer().
get_corps_lv(Src, CorpsUid) ->
    case get_corps(Src, CorpsUid) of
        'none' ->
            0;
        Corps ->
            case corps:get_state(Corps) =:= ?CORPS_STATE_DISSOLVE of
                true ->
                    -1;
                false ->
                    corps:get_level(Corps)
            end
    end.

%%-------------------------------------------------------------------
%% @doc
%%
%% @end
%%-------------------------------------------------------------------
-spec get_corps_town(atom(), integer()) -> corps_town:corps_town().
get_corps_town(Src, CorpsUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'corps_town'), CorpsUid, corps_town:init()).

%% ----------------------------------------------------
%% @doc
%%        得到军团占领城池数
%% @end
%% ----------------------------------------------------
-spec get_corps_town_num(atom(), integer()) -> integer().
get_corps_town_num(Src, CorpsUid) ->
    CorpsTown = get_corps_town(Src, CorpsUid),
    corps_town:get_num(CorpsTown) + corps_town:get_cnum(CorpsTown).

%%-------------------------------------------------------------------
%% @doc
%%      得到军团占领城池势力值
%% @end
%%-------------------------------------------------------------------
-spec get_corps_town_influence(atom(), integer()) -> integer().
get_corps_town_influence(Src, CorpsUid) ->
    CorpsTown = get_corps_town(Src, CorpsUid),
    corps_town:get_influence(CorpsTown).
%% ----------------------------------------------------
%% @doc
%%        得到军团
%% @end
%% ----------------------------------------------------
-spec get_corps_by_roleuid(atom(), integer()) -> 'none' | corps:corps().
get_corps_by_roleuid(Src, RoleUid) ->
    RoleCorps = get_role_corps(Src, RoleUid),
    case role_corps:get_corps_uid(RoleCorps) of
        0 ->
            'none';
        CorpdUid ->
            corps_db:get_corps(Src, CorpdUid)
    end.
%% ----------------------------------------------------
%% @doc
%%        得到军团
%% @end
%% ----------------------------------------------------
-spec get_corps_by_name(atom(), string()) -> 'none' | corps:corps().
get_corps_by_name(Src, CorpsName) ->
    case z_db_lib:get(game_lib:get_table(Src, 'corps_name'), CorpsName, 'none') of
        'none' ->
            'none';
        CorpsUid ->
            get_corps(Src, CorpsUid)
    end.
%% ----------------------------------------------------
%% @doc
%%        得到军团列表
%% @end
%% ----------------------------------------------------
-spec get_corps_list(atom(), [integer()]) -> ['none' | corps:corps()].
get_corps_list(Src, CorpsUids) ->
    z_db_lib:gets(game_lib:get_table(Src, 'corps'), CorpsUids, 'none').

%% ----------------------------------------------------
%% @doc
%%        得到玩家军团信息
%% @end
%% ----------------------------------------------------
-spec get_role_corps(atom(), integer()) -> role_corps:role_corps()|no_return().
get_role_corps(Src, RoleUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'role_corps'), RoleUid, role_corps:init()).

%% ----------------------------------------------------
%% @doc
%%        得到军团申请列表
%% @end
%% ----------------------------------------------------
-spec get_corps_request(atom(), integer()) -> corps:requests()|no_return().
get_corps_request(Src, CorpsUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'corps_request'), CorpsUid, []).

%% ----------------------------------------------------
%% @doc
%%        得到军团邀请
%% @end
%% ----------------------------------------------------
-spec get_corps_invites(atom(), integer()) -> [integer()].
get_corps_invites(Src, CorpsUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'corps_invite'), CorpsUid, []).

%% ----------------------------------------------------
%% @doc
%%        得到军团成员uid
%% @end
%% ----------------------------------------------------
-spec get_corps_members(atom(), integer()) -> [integer()].
get_corps_members(Src, CorpsUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'corps_member'), CorpsUid, []).

%% ----------------------------------------------------
%% @doc
%%        得到军团日志
%% @end
%% ----------------------------------------------------
-spec get_corps_log(atom(), integer(), integer()) -> corps:requests().
get_corps_log(Src, CorpsUid, Type) ->
    z_db_lib:get(game_lib:get_table(Src, 'corps_log'), {CorpsUid, Type}, []).

%% ----------------------------------------------------
%% @doc
%%        得到军团公告
%% @end
%% ----------------------------------------------------
-spec get_corps_notice(atom(), integer()) -> {string(), string()}.
get_corps_notice(Src, CorpsUid) ->
    {_PrivateTime, PrivateNotice, _PublicTime, PublicNotice} = z_db_lib:get(game_lib:get_table(Src, 'corps_notice'), CorpsUid, {0, "", 0, ""}),
    {PrivateNotice, PublicNotice}.

%% ----------------------------------------------------
%% @doc
%%        发送军团邮件
%% @end
%% ----------------------------------------------------
-spec send_corps_mail(atom(), integer(), string(), string(), list()) -> 'ok' | string().
send_corps_mail(Src, RoleUid, Title, Content, Annex) ->
    RoleCorps = corps_db:get_role_corps(Src, RoleUid),
    CorpsUid = role_corps:get_corps_uid(RoleCorps),
    if
        CorpsUid =:= 0 ->
            "corps_not_in";
        true ->
            Position = role_corps:get_position(RoleCorps),
            CheckPositionBool = corps_lib:check_position_limit('send_corps_mail', Position),
            if
                CheckPositionBool ->
                    RoleUids = get_corps_members(Src, CorpsUid),
                    RoleShow = role_db:get_role_show(Src, RoleUid),
                    RoleName = role_show:get_name(RoleShow),
                    Source = game_lib:get_language({'corps_mail_source', role_corps:get_position(RoleCorps)}, [RoleName]),
                    MailType = award_source:get_source(?MODULE),
                    send_corps_mail(Src, CorpsUid, RoleUids, Source, MailType, Title, Content, Annex);
                true ->
                    CheckPositionBool
            end
    end.
-spec send_corps_mail(atom(), integer(), string()|tuple(), string()|tuple()) -> 'ok' | string().
send_corps_mail(Src, RoleUid, Title, Content) ->
    send_corps_mail(Src, RoleUid, Title, Content, []).


%% ----------------------------------------------------
%% @doc
%%   发送邮件
%% @end
%% ----------------------------------------------------
%%send_corps_mail(Src, RoleUids, RoleName, RoleCorps, Title, Content, Annex) ->
%%    if
%%        RoleUids =:= [] ->
%%            ok;
%%        true ->
%%            STime = time_lib:now_second(),
%%            ETime = STime + 86400 * 7,
%%            MailType = award_source:get_source(?MODULE),
%%            Source = game_lib:get_language({'corps_mail_source', role_corps:get_position(RoleCorps)}, [RoleName]),
%%            Mail = mail:init_sys(Src, {Source, MailType, STime, ETime, Title, Content, Annex}),
%%            SysMailUid = uid_lib:create_system_mail_uid(Src),
%%            Bl = is_list(RoleUids),
%%            SysMail = if
%%                Bl ->
%%                    system_mail:init({SysMailUid, [{member_uid, RoleUids}], [], Mail, ETime});
%%                true ->
%%                    %%支持给单个军团成员发送邮件
%%                    system_mail:init({SysMailUid, [{member_uid, [RoleUids]}], [], Mail, ETime})
%%            end,
%%            mail_db:send_system_mail(Src, SysMail),
%%            push_message_lib:push(Src, RoleUids, 5, []),%军团邮件,推送
%%            ok
%%    end.

%% ----------------------------------------------------
%% @doc
%%      发送军团邮件(军团全体成员都发)
%% @end
%% ----------------------------------------------------
send_corps_mail(Src, CorpsUid, RoleUids, Source, MailType, Title, Content, Annex) ->
    STime = time_lib:now_second(),
    ETime = STime + ?CORPS_MAIL_TIMEOUT,
    Uid = uid_lib:create_mail_uid(Src),
    Mail = mail:set_flag(mail:set_uid(mail:init({Source, MailType, STime, ETime, Title, Content, Annex}), Uid), RoleUids),
    z_db_lib:update(game_lib:get_table(Src, 'corps_mail'), CorpsUid, {[], 0}, fun(_, CMail) ->
        {MList, FirstTime} = remove_timeout_mail(STime, CMail),
        NFirstTime = case MList =:= [] of
                         true ->
                             STime;
                         false ->
                             FirstTime
                     end,
        {ok, ok, {lists:sublist([Mail | MList], ?CORPS_MAIL_MAX), NFirstTime}}
                                                                              end, []),
    lists:foreach(fun(RUid) ->
        set_front_lib:send_mail(Src, RUid, Mail)
                  end, RoleUids),
    push_message_lib:push(Src, RoleUids, 5, []),%军团邮件,推送
    ok.

%% ----------------------------------------------------
%% @doc
%%    获取军团邮件列表
%% @end
%% ----------------------------------------------------
get_role_corps_mail(Src, RoleUid) ->
    RoleShow = role_db:get_role_show(Src, RoleUid),
    CorpsUid = role_show:get_corps_uid(RoleShow),
    case CorpsUid > 0 of
        true ->
            IndexTableName = game_lib:get_table(Src, 'corps_mail_role_index'),
            TableName = game_lib:get_table(Src, 'corps_mail'),
            CMail = z_db_lib:get(TableName, CorpsUid, {[], 0}),
            Now = time_lib:now_second(),
            {MList, _} = remove_timeout_mail(Now, CMail),
            OMaxUid = z_db_lib:get(IndexTableName, RoleUid, 0),
            OId1 = uid_lib:get_id(OMaxUid),
            case lists:any(                                 fun(M) ->
                uid_lib:get_id(mail:get_uid(M)) > OId1 end, MList) of
                true ->
                    TName = game_lib:get_table(Src),
                    TableKeys = z_db_lib:transformation_tablekey(TName,
                                                                 [
                                                                     {'corps_mail_role_index', RoleUid, 0},
                                                                     {'corps_mail', CorpsUid, {[], 0}}
                                                                 ]),
                    Fun = fun(_, [{Index1, MaxUid}, {Index2, NCMail}]) ->
                        {NMList, FirstTime} = remove_timeout_mail(Now, NCMail),
                        Mid1 = uid_lib:get_id(MaxUid),
                        {AddMList, NMaxUid, NNMList} = z_lib:foreach(fun({Acc, MId, MAcc} = R, Mail) ->
                            MUid = mail:get_uid(Mail),
                            Mid2 = uid_lib:get_id(MUid),
                            case Mid2 > Mid1 of
                                true ->
                                    Flag = mail:get_flag(Mail),
                                    case is_list(Flag) andalso lists:member(RoleUid, Flag) of
                                        true ->
                                            NFlag = lists:delete(RoleUid, Flag),
                                            case NFlag =:= [] of
                                                true ->
                                                    {ok, {[Mail | Acc], max(Mid2, MId), MAcc}};
                                                false ->
                                                    NMail = mail:set_flag(Mail, NFlag),
                                                    {ok, {[Mail | Acc], max(Mid2, MId), [NMail | MAcc]}}
                                            end;
                                        false ->
                                            {ok, {Acc, max(Mid2, MId), [Mail | MAcc]}}
                                    end;
                                false ->
                                    {break, R}
                            end
                                                                     end, {[], Mid1, []}, NMList),
                        case AddMList =/= [] of
                            true ->
                                {ok, {ok, AddMList}, [{Index1, NMaxUid}, {Index2, {lists:reverse(NNMList), FirstTime}}]};
                            false ->
                                {ok, {ok, []}, [{Index2, {lists:reverse(NNMList), FirstTime}}]}
                        end
                          end,
                    {ok, AddMailList} = z_db_lib:handle(TName, Fun, [], TableKeys),
                    z_lib:foreach(fun(Acc, M) ->
                        Uid = uid_lib:create_mail_uid(Src),
                        {ok, [mail:set_uid(M, Uid) | Acc]}
                                  end, [], AddMailList);
                false ->
                    []
            end;
        false ->
            []
    end.

%% ----------------------------------------------------
%% @doc
%%      移除过期和限制大小
%% @end
%% ----------------------------------------------------
remove_timeout_mail(Now, {MList, FirstTime} = CMail) ->
    case Now - FirstTime >= ?CORPS_MAIL_TIMEOUT of
        true ->
            {NMList, NFirstTime} = z_lib:foreach(fun({Acc, T}, M) ->
                case mail:get_etime(M) =< Now of
                    true ->
                        {break, {Acc, T}};
                    false ->
                        {ok, {[M | Acc], mail:get_stime(M)}}
                end
                                                 end, {[], 0}, MList),
            {lists:reverse(NMList), NFirstTime};
        false ->
            CMail
    end.


%% ----------------------------------------------------
%% @doc
%%        插入军团日志
%% @end
%% ----------------------------------------------------
-spec insert_corps_log(atom(), integer(), tuple()) -> 'ok'.
insert_corps_log(Src, CorpsUid, CorpsLog) ->
    LogType = element(1, CorpsLog) div 100,
    {_, MaxNum} = zm_config:get('corps', 'corps_log_max_num'),
    Fun = fun(_, CorpsLogs) ->
        NCorpsLogs = lists:sublist([CorpsLog | CorpsLogs], MaxNum),
        {ok, ok, NCorpsLogs}
          end,
    z_db_lib:update(game_lib:get_table(Src, 'corps_log'), {CorpsUid, LogType}, [], Fun, []).

%% ----------------------------------------------------
%% @doc
%%        得到连续登陆主城等级分段多段组合uid
%% @end
%% ----------------------------------------------------
-spec get_corps_mf_level_list(atom(), [integer()], integer()) -> [integer()].
get_corps_mf_level_list(Src, Indexs, Country) ->
    Keys = lists:map(fun(Index) -> {Index, Country} end, Indexs),
    lists:append(z_db_lib:gets(game_lib:get_table(Src, 'corps_mb_level'), Keys, [])).

%% ----------------------------------------------------
%% @doc
%%      保存最近创建的军团uid
%% @end
%% ----------------------------------------------------
-spec save_new_corps_uid(atom(), corps:corps()) -> 'ok'.
save_new_corps_uid(Src, Corps) ->
    CorpsUid = corps:get_uid(Corps),
    Country = corps:get_country(Corps),
    Fun = fun(_, CorpsUidList) ->
        case lists:member(CorpsUid, CorpsUidList) of
            true ->
                {ok, ok};
            false ->
                {_, Num} = zm_config:get('corps', 'new_corps_save_num'),
                {ok, ok, lists:sublist([CorpsUid | CorpsUidList], Num)}
        end
          end,
    z_db_lib:update(game_lib:get_table(Src, 'corps_mb_level'), {'new_corps_uids', Country}, [], Fun, []).

%% ----------------------------------------------------
%% @doc
%%      获取最近创建的军团uid列表
%% @end
%% ----------------------------------------------------
-spec get_new_corps_uids(atom(), integer()) -> [integer()].
get_new_corps_uids(Src, Country) ->
    z_db_lib:get(game_lib:get_table(Src, 'corps_mb_level'), {'new_corps_uids', Country}, []).


%% ----------------------------------------------------
%% @doc
%%      删除最近创建的军团uid
%% @end
%% ----------------------------------------------------
-spec delete_new_corps_uid(atom(), corps:corps()) -> 'ok'.
delete_new_corps_uid(Src, Corps) ->
    CorpsUid = corps:get_uid(Corps),
    Country = corps:get_country(Corps),
    Fun = fun(_, CorpsUidList) ->
        {ok, ok, lists:delete(CorpsUid, CorpsUidList)}
          end,
    z_db_lib:update(game_lib:get_table(Src, 'corps_mb_level'), {'new_corps_uids', Country}, [], Fun, []).

%% ----------------------------------------------------
%% @doc
%%      移除没有连续登陆的主城等级分布
%% @end
%% ----------------------------------------------------
-spec refresh_corps_mf_level(atom()) -> 'ok'.
refresh_corps_mf_level(Src) ->
    Table = game_lib:get_table(Src, 'corps_mb_level'),
    Fun = fun(_, {K, _} = Index, _, _) ->
        if
            is_integer(K) ->
                RoleUidList = z_db_lib:get(Table, Index, []),
                RemoveRoleUidList = lists:filter(fun(RoleUid) ->
                    not corps_lib:check_corps_invite(Src, RoleUid)
                                                 end, RoleUidList),
                F = fun(_, List) ->
                    {ok, ok, List -- RemoveRoleUidList}
                    end,
                z_db_lib:update(Table, Index, F, []),
                ok;
            true ->
                ok
        end
          end,
    z_db_lib:table_iterate(Src, Table, Fun, [], []),
    ok.

%% ----------------------------------------------------
%% @doc
%%      更新主城等级分布
%% @end
%% ----------------------------------------------------
-spec update_corps_mf_level(atom(), integer(), atom(), role_show:role_show(), role_show:role_show()) -> 'ok'.
update_corps_mf_level(Src, RoleUid, Type, RoleShow, NRoleShow) ->
    case args_system:is_game_server(Src) of
        true ->
            update_corps_mf_level_1(Src, RoleUid, Type, RoleShow, NRoleShow);
        false ->
            ok
    end.

%% ----------------------------------------------------
%% @doc
%%      添加军团经验(奖励专用) {'corps_exp',增加值,增加后当前值}
%% @end
%% ----------------------------------------------------
-spec award_exp([Src], RoleUid, _, Exp) -> {'corps_exp', integer(), integer()} when
    Src :: atom(),
    RoleUid :: integer(),
    Exp :: integer().
award_exp([Src], RoleUid, _, Exp) when Exp > 0 ->
    RoleShow = role_db:get_role_show(Src, RoleUid),
    CorpsUid = role_show:get_corps_uid(RoleShow),
    if
        CorpsUid =:= 0 ->
            {'corps_exp', 0, 0};
        true ->
            F = fun(_, Corps) ->
                OldExp = corps:get_exp(Corps),
                NewExp = OldExp + round(Exp),
                NCorps = corps:set_exp(Corps, NewExp),
                {'ok', {Corps, NCorps}, NCorps}
                end,
            {Corps, NCorps} = z_db_lib:update(game_lib:get_table(Src, 'corps'), CorpsUid, F, []),
            NExp = corps:get_exp(NCorps),
            OLv = corps:get_level(Corps),
            NLv = corps:get_level(NCorps),
            if
                NLv > OLv ->
                    zm_event:notify(Src, {'corps_level_influence_rank', role_show:get_country(RoleShow)}, [{'uid', CorpsUid}]),
                    zm_event:notify(Src, 'bi_corps_change', [{'corps', Corps}]),
                    set_front_lib:send_corps_exp(Src, lists:delete(RoleUid, get_corps_members(Src, CorpsUid)), NExp),
                    zm_event:notify(Src, 'active_event', {'corps_up_level', [{'corps_uid', CorpsUid}, {'corps', NCorps}]}),
                    Country = corps:get_country(Corps),
                    CName = corps:get_name(Corps),
                    BKey = {'corps_lv_up', Country},
                    BArgs = [CorpsUid, Country, CName, NLv],
                    chat_lib:notice_world(Src, BKey, BArgs),
                    chat_lib:notice_country(Src, BKey, BArgs, Country);
                true ->
                    ok
            end,
            {'corps_exp', round(Exp), NExp}
    end.

%%-------------------------------------------------------------------
%% @doc
%%      获取占领城池积分
%% @end
%%-------------------------------------------------------------------
-spec get_corps_town_score(atom(), integer()) -> integer().
get_corps_town_score(Src, CorpsUid) ->
    CorpsTown = get_corps_town(Src, CorpsUid),
    OList = corps_town:get_olist_townsid(CorpsTown) ++ corps_town:get_clist_townsid(CorpsTown),
    lists:foldl(fun(TownSid, N) ->
        N + town_detail:get_score(town_detail:get_cfg(TownSid))
                end, 0, OList).

%% ----------------------------------------------------
%% @doc
%%     军团上线信息获取
%% @end
%% ----------------------------------------------------
online_format(Src, RoleUid, CorpsUid, RoleShow) ->
    RoleCorp = corps_db:get_role_corps(Src, RoleUid),
    IsFirst1 = role_corps:get_is_first(RoleCorp),
    EnterTime = role_corps:get_enter_time(RoleCorp),
    IsFirst = if
                  IsFirst1 =:= 0 andalso EnterTime =:= 0 ->
                      0;%未加入军团
                  IsFirst1 =:= 0 andalso EnterTime > 0 ->
                      1;%已加入军团未领奖
                  true ->
                      2%已领奖
              end,
    if
        CorpsUid =:= 0 ->
            {{CorpsUid, "", role_corps:get_exit_time(RoleCorp), {{}, {}}, 0, IsFirst}, RoleCorp};
        true ->
            CorpsTown = corps_db:get_corps_town(Src, CorpsUid),
            Day = time_lib:get_date_by_type('day_of_year'),
            ATimes = corps_town:get_atimes(CorpsTown),
            Times = case element(1, ATimes) =:= Day of
                        true ->
                            element(2, ATimes);
                        false ->
                            0
                    end,
            %% 军团相关 {军团uid,军团名字,军团退出时间,攻击中普通城池({sid,开始时间}),攻击中郡城({sid,开始时间})},当日军团放弃城池次数,是否领取过首次加入军团奖励(0=未加入军团，1=已加入军团未领取，2=已领取)}
            CInfo = {CorpsUid,
                     role_show:get_corps_name(RoleShow),
                     role_corps:get_exit_time(RoleCorp),
                     {list_to_tuple([{point_lib:sid2view(S), V} || {S, V} <- corps_town:get_flist(CorpsTown)]),
                      list_to_tuple([{point_lib:sid2view(S), V} || {S, V} <- corps_town:get_cflist(CorpsTown)])},
                     Times, IsFirst},
            {CInfo, RoleCorp}
    end.
%% ----------------------------------------------------
%% @doc
%%     第一次加入发送奖励
%% @end
%% ----------------------------------------------------
award_first_enter_corps(Src, RoleUid) ->
    F = fun(_, RoleCorps) ->
        case role_corps:get_is_first(RoleCorps) =:= 0 andalso role_corps:get_enter_time(RoleCorps) > 0 of
            true ->
                NRolrCorps = role_corps:set_is_first(RoleCorps, 1),
                {'ok', true, NRolrCorps};
            _ ->
                throw("not_first_enter_corps")
        end
        end,
    z_db_lib:update(game_lib:get_table(Src, 'role_corps'), RoleUid, role_corps:init(), F, []).
%% ----------------------------------------------------
%% @doc
%%     捐献 Type=1(money),  Type=2(rmb)
%% @end
%% ----------------------------------------------------
donate(_A, {Src, _RoleUid, Type, Number, Corps}, [{Index1, RoleCorps}, {Index2, DonateInfo}, {Index3, RoleOrRmb}]) ->
    CorpsLevel = corps:get_level(Corps),
    DonateCfg = element(2, zm_config:get('donate', CorpsLevel)),
    {_, DonateMaxTimes, Consume1, Award1} = lists:keyfind(Type, 1, DonateCfg),
    Award = awarder_game:award_multiple(Award1, Number),
    Consumes = awarder_game:award_multiple(Consume1, Number),
    ToDay = time_lib:get_date_by_type('day_of_year'),

    DonateTimes = if
                      Type =:= ?MONEY ->
                          role_corps:get_ctb_money_times(RoleCorps, ToDay);
                      true ->
                          role_corps:get_ctb_rmb_times(RoleCorps, ToDay)

                  end,
    Utcday = public_lib:day_of_utc(time_lib:now_second()),%%当前utc天数
    Num = case z_lib:get_value(DonateInfo, Type, {0, 0}) of%%获得公会今天的捐献次数
              {Utcday, Num2} -> Num2;
              _ -> 0
          end,
    {_, LimitNum} = zm_config:get(corps_donate_info, CorpsLevel),%%获得这个公会等级对应的捐献次数上限
    if
        Num >= LimitNum ->
            case Type of
                ?MONEY ->
                    throw("money_donate_num_limit");
                _ ->
                    throw("rmb_donate_num_limit")
            end;
        true ->
            if
                Num + 1 =:= LimitNum ->%%当这一次捐献之后到达最大次数之后给全军团玩家推送
                    zm_event:notify(Src, 'donate_max', [{'corps_uid', role_corps:get_corps_uid(RoleCorps)}, {'type', {2, Type}}]);
                true -> ok
            end
    end,
    Bool = game_lib:checks({'corps_lib', 'check'}, {RoleCorps, Type, DonateTimes, RoleOrRmb, DonateMaxTimes}, 'donate', Consumes),
    if
        Bool ->
            {Cs, {NDonateTimes, NRoleOrRmb}} = game_lib:consumes({corps_lib, consume}, {DonateTimes, RoleOrRmb}, 'donate', Consumes),
            NRoleCorps = if
                             Type =:= ?MONEY ->
                                 role_corps:set_ctb_money_times(RoleCorps, NDonateTimes, ToDay);
                             true ->
                                 role_corps:set_ctb_rmb_times(RoleCorps, NDonateTimes, ToDay)
                         end,
            {ok, {ok, Award, Cs, Num + 1}, [{Index1, NRoleCorps},
                                            {Index2, lists:keystore(Type, 1, DonateInfo, {Type, {Utcday, Num + 1}})}, {Index3, NRoleOrRmb}]};
        true ->
            throw(Bool)
    end.

%% ----------------------------------------------------
%% @doc
%%      请求互助
%% @end
%% ----------------------------------------------------
request_help(_A, {RoleUid, HelpInfo}, [{Index1, {MaxId, CCorpsHelp}}, {Index2, RCorpsHelp}]) ->
    F = fun({AddCH, CCHelp, RCHelp, Id1}, {BSid, Sid, Level}) ->
        case lists:keyfind({BSid, Sid}, 2, RCHelp) of
            false ->
                NId = Id1 + 1,
                CorpsHelp1 = corps_help:init(NId, RoleUid, BSid, Sid, Level, []),
                {ok, {[CorpsHelp1 | AddCH], [CorpsHelp1 | CCHelp], [{NId, {BSid, Sid}} | RCHelp], NId}};
            _ ->
                {ok, {AddCH, CCHelp, RCHelp, Id1}}
        end
        end,
    {AddCorpsHelp, NCCorpsHelp, NRCorpsHelp, NMaxId} = z_lib:foreach(F, {[], CCorpsHelp, RCorpsHelp, MaxId}, HelpInfo),
    {ok, {ok, AddCorpsHelp}, [{Index1, {NMaxId, NCCorpsHelp}}, {Index2, NRCorpsHelp}]}.


%% ----------------------------------------------------
%% @doc
%%      获取军团中申请的帮助列表
%% @end
%% ----------------------------------------------------
get_corps_help(Src, CorpsUid) ->
    {_, V} = z_db_lib:get(game_lib:get_table(Src, 'corps_help'), CorpsUid, {0, []}),
    V.

%% ----------------------------------------------------
%% @doc
%%      获取角色申请的帮助列表
%% @end
%% ----------------------------------------------------
get_role_corps_help(Src, RoleUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'role_corps_help'), RoleUid, []).
%% ----------------------------------------------------
%% @doc
%%      军团互助  帮助他人
%% @end
%% ----------------------------------------------------
help_other(_A, {RoleUid, Ids, MaxHelpTimes}, [{Index1, {MaxId, CCHelp}}]) ->
    IdIndex = corps_help:get_id_index(),
    F = fun({ReduceTimeCH1, CCHelp1}, Id) ->
        case lists:keyfind(Id, IdIndex, CCHelp1) of
            false ->
                {ok, {ReduceTimeCH1, CCHelp1}};
            CorpsHelp ->
                Helpers = corps_help:get_helpers(CorpsHelp),
                case lists:member(RoleUid, Helpers) of
                    true ->
                        {ok, {ReduceTimeCH1, CCHelp1}};
                    false ->
                        HelpTiems = length(Helpers),
                        {ReduceTimeCH2, CCHelp3} =
                            case HelpTiems + 1 >= MaxHelpTimes of
                                true ->
                                    CCHelp2 = lists:keydelete(Id, IdIndex, CCHelp1),
                                    {[CorpsHelp | ReduceTimeCH1], CCHelp2};
                                false ->
                                    NCorpsHelp = corps_help:add_helper(CorpsHelp, RoleUid),
                                    {[CorpsHelp | ReduceTimeCH1], lists:keyreplace(Id, IdIndex, CCHelp1, NCorpsHelp)}
                            end,
                        {ok, {ReduceTimeCH2, CCHelp3}}
                end
        end
        end,
    {ReduceTimeCHs, NCCHelp} = z_lib:foreach(F, {[], CCHelp}, Ids),
    {ok, {ok, ReduceTimeCHs}, [{Index1, {MaxId, NCCHelp}}]}.
%% ----------------------------------------------------
%% @doc
%%      军团互助  退出军团/踢出军团 需要删除军团表中此玩家的所有数据
%%
%% @end
%% ----------------------------------------------------
corps_help_quit_corps(Src, RoleUid, OCorpsUid) ->
    F1 = fun(_, {MaxID, CCHelp}) ->
        F2 = fun({DeleteIDs1, NCCH}, CorpsHelp) ->
            {RUid, _BSid, _Sid} = corps_help:get_key(CorpsHelp),
            if
                RUid =:= RoleUid ->
                    {ok, {[corps_help:get_id(CorpsHelp) | DeleteIDs1], NCCH}};
                true ->
                    {ok, {DeleteIDs1, [CorpsHelp | NCCH]}}
            end
             end,
        {DeleteIds2, NCCHelp} = z_lib:foreach(F2, {[], []}, CCHelp),
        {ok, {ok, DeleteIds2}, {MaxID, lists:reverse(NCCHelp)}}
         end,
    {ok, DeleteIds3} = z_db_lib:update(game_lib:get_table(Src, 'corps_help'), OCorpsUid, {0, []}, F1, []),
    OCorpsMember = corps_db:get_corps_members(Src, OCorpsUid),
    set_front_lib:send_complete_help(Src, OCorpsMember, {?DELETE, list_to_tuple(DeleteIds3)}).

%% ----------------------------------------------------
%% @doc
%%       军团互助  建筑（或者科技）升级完成 删除
%% @end
%% ----------------------------------------------------
corps_help_queue_over(Src, RoleUid, BSid, Sid) ->
    RoleShow = role_db:get_role_show(Src, RoleUid),
    CorpsUid = role_show:get_corps_uid(RoleShow),
    TableList = if
                    CorpsUid =:= 0 ->
                        [];
                    true ->
                        [{'corps_help', CorpsUid, {0, []}}]
                end,
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'role_corps_help', RoleUid, []} | TableList]),
    case z_db_lib:handle(TableName, {?MODULE, corps_help_queue_over1, []}, {RoleUid, BSid, Sid}, TableKeys) of
        {ok, DeleteId} ->
            CorpsMember = corps_db:get_corps_members(Src, CorpsUid),
            set_front_lib:send_complete_help(Src, CorpsMember, {?DELETE, {DeleteId}}),
            ok;
        Err ->
            Err
    end.

corps_help_queue_over2(Src, CorpsHelpList, CorpsUid, CorpsMember) -> %%加速的时候，刚好这个队列完成
    IdIndex = corps_help:get_id_index(),
    F1 = fun(_, {MaxId, CCHelp}) ->
        NCCHelp = z_lib:foreach(fun(ResCCHelp, CorpsHelp) ->
            {ok, lists:keydelete(corps_help:get_id(CorpsHelp), IdIndex, ResCCHelp)}
                                end, CCHelp, CorpsHelpList),
        {ok, ok, {MaxId, NCCHelp}}
         end,
    z_db_lib:update(game_lib:get_table(Src, 'corps_help'), CorpsUid, {0, []}, F1, []), %%处理军团表

    RTable = game_lib:get_table(Src, 'role_corps_help'),
    Ids = z_lib:foreach(fun(ResIds, CorpsHelp) ->
        Id = corps_help:get_id(CorpsHelp),
        {RoleUid, _BSid, _Sid} = corps_help:get_key(CorpsHelp),
        F2 = fun(_, RCHelp) ->
            NRCHelp = lists:keydelete(Id, 1, RCHelp),
            {ok, {ok, [Id | ResIds]}, NRCHelp}
             end,
        z_db_lib:update(RTable, RoleUid, [], F2, [])%%处理个人表
                        end, [], CorpsHelpList),
    set_front_lib:send_complete_help(Src, CorpsMember, {?DELETE, list_to_tuple(Ids)}).%%队列完成 ，删除

%% ----------------------------------------------------
%% @doc
%%      领取军团奖励
%%
%% @end
%% ----------------------------------------------------
position_award(_A, {_Src, _RoleUid, RoleCorps}, [{Index1, AwardState}, {Index2, PositionGiftNum}]) ->
    {AwardDay, Num} = corps_lib:refresh_position_award_state(AwardState),
    if
        Num =< 0 ->
            Pos = role_corps:get_position(RoleCorps),
            {_, NumLimitInfo} = zm_config:get('corps', 'position_gift_num'),
            case lists:keyfind(Pos, 1, NumLimitInfo) of
                {_, MaxNum} ->
                    Today = time_lib:get_date_by_type('day_of_year'),
                    case PositionGiftNum of
                        {Today, GotNum} ->
                            if
                                GotNum < MaxNum ->
                                    {_, Award} = zm_config:get('contribute_day_award', Pos),
                                    {ok, {ok, Award}, [{Index1, {AwardDay, Num + 1}}, {Index2, {Today, GotNum + 1}}]};
                                true ->
                                    throw("max_position_award_" ++ string_lib:to_string(Pos))
                            end;
                        _ ->
                            {_, Award} = zm_config:get('contribute_day_award', Pos),
                            {ok, {ok, Award}, [{Index1, {AwardDay, Num + 1}}, {Index2, {Today, 1}}]}
                    end;
                _ ->
                    {_, Award} = zm_config:get('contribute_day_award', Pos),
                    {ok, {ok, Award}, [{Index1, {AwardDay, Num + 1}}]}
            end;
        true ->
            throw("got_position_award")

    end.

%% ----------------------------------------------------
%% @doc
%%      格式化帮助信息
%% @end
%% ----------------------------------------------------
format_help(Src, RoleUid, CorpsUid) ->
    RCorpsHelp = lists:map(  fun({Id, {BSid, Sid}}) ->
        {Id, BSid, Sid} end, corps_db:get_role_corps_help(Src, RoleUid)),
    R1 = list_to_tuple(RCorpsHelp),
    CCorpsHelp = corps_db:get_corps_help(Src, CorpsUid),
    F2 = fun(Res, CorpsHelp) ->
        Id = corps_help:get_id(CorpsHelp),
        {RoleUid1, BSid, Sid} = corps_help:get_key(CorpsHelp),
        Level = corps_help:get_level(CorpsHelp),
        Helpers = corps_help:get_helpers(CorpsHelp),
        case lists:member(RoleUid, Helpers) of
            true ->
                {ok, Res};
            false ->
                HelpTimes = length(Helpers),
                Name = role_show:get_name(role_db:get_role_show(Src, RoleUid1)),
                {ok, [{Id, RoleUid1, Name, BSid, Sid, Level, HelpTimes} | Res]}
        end
         end,
    Res2 = z_lib:foreach(F2, [], CCorpsHelp),
    R2 = list_to_tuple(Res2),
    {R1, R2}.
%% ----------------------------------------------------
%% @doc
%%      设置参与城战次数、军团帮助次数
%% @end
%% ----------------------------------------------------
get_corps_show(Src, RoleUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'corps_show'), RoleUid, corps_show:init()).
%% ----------------------------------------------------
%% @doc
%%      设置参与城战次数、军团帮助次数
%% @end
%% ----------------------------------------------------
update_corps_show_times(Src, RoleUid, Type, Times) when Times > 0 ->
    GetTimesFun = string_lib:to_atom('get_', Type),
    SetTimesFun = string_lib:to_atom('set_', Type),
    Table = game_lib:get_table(Src, 'corps_show'),
    ToDay = time_lib:get_date_by_type('day_of_year'),
    Fun = fun(_, CorpsShow) ->
        NTimes = case corps_show:GetTimesFun(CorpsShow) of
                     {ToDay, Value} ->
                         Value + Times;
                     _ ->
                         Times
                 end,
        NCorpsShow = corps_show:SetTimesFun(CorpsShow, {ToDay, NTimes}),
        {ok, ok, NCorpsShow}
          end,
    z_db_lib:update(Table, RoleUid, corps_show:init(), Fun, []);
update_corps_show_times(_, _, _, _) ->
    ok.
%% ----------------------------------------------------
%% @doc
%%      自动移交军团长
%% @end
%% ----------------------------------------------------
auto_replace(Src, _RoleUid, RoleShow) ->
    case args_system:is_game_server(Src) of
        true ->
            CorpsUid = role_show:get_corps_uid(RoleShow),
            if
                CorpsUid =/= 0 ->
                    case cross_battle_db:check_corps_in_cross_battle(Src, CorpsUid) of
                        false ->
                            Today = time_lib:get_date_by_type('day_of_year'),
                            case z_db_lib:get(game_lib:get_table(Src, 'corps_auto_state'), CorpsUid) of
                                Today ->
                                    ok;
                                _ ->
                                    Corps = get_corps(Src, CorpsUid),
                                    CorpsOwnerUid = corps:get_owner(Corps),
                                    GUser = z_db_lib:get(game_lib:get_table(Src, 'user'), CorpsOwnerUid),
                                    {_, Conditions} = zm_config:get('corps', 'replace_owner_conditions'),
                                    Bool = game_lib:checks({corps_lib, check}, GUser, 'replace_owner', Conditions),
                                    if
                                        Bool ->
                                            case get_replace_owner_roleuid(Src, CorpsUid, Corps) of
                                                {0, _} ->
                                                    ok;
                                                {CorpsOwnerUid, _} ->%%自己不处理
                                                    ok;
                                                {NewOwerUid, Members} ->
                                                    TableName = game_lib:get_table(Src),
                                                    TableKeys = z_db_lib:transformation_tablekey(TableName, [
                                                        {'corps', CorpsUid},
                                                        {'role_corps', NewOwerUid, role_corps:init()},
                                                        {'role_corps', CorpsOwnerUid, role_corps:init()},
                                                        {'corps_auto_state', CorpsUid}
                                                    ]),
                                                    case z_db_lib:handle(TableName, {?MODULE, replace_owner, []}, {Src, NewOwerUid, CorpsOwnerUid, Today}, TableKeys) of
                                                        {ok, _NewCorps} ->
                                                            zm_log:info(Src, ?MODULE, 'replace_owner', "corps_replace_owner", [{'old_owner', CorpsOwnerUid}, {'corps_uid', CorpsUid}, {'new_owner', NewOwerUid}]),
                                                            zm_event:notify(Src, 'corps_replace_owner', [{'type', 0}, {'old_owner', CorpsOwnerUid}, {'new_owner', NewOwerUid}, {'members', Members}, {'corps_uid', CorpsUid}]);
                                                        Other ->
                                                            zm_log:info(Src, ?MODULE, 'replace_owner', "other", [{'other', Other}])
                                                    end
                                            end;
                                        true ->
                                            z_db_lib:update(game_lib:get_table(Src, 'corps_auto_state'), CorpsUid, Today)
                                    end
                            end;
                        true ->
                            ok
                    end;
                true ->
                    ok
            end;
        false ->
            ok
    end.

%% ----------------------------------------------------
%% @doc
%%      获取放弃中的城池信息
%% @end
%% ----------------------------------------------------
get_abandoning_town(Src, CorpsUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'abandoning_town'), CorpsUid, []).
%% ----------------------------------------------------
%% @doc
%%      添加放弃城池辅助信息
%% @end
%% ----------------------------------------------------
add_abondoning_town_tmp(Src, CorpsUid, TownSid, Sec) ->
    z_db_lib:update(game_lib:get_table(Src, 'abandoning_town_tmp'), {Sec, CorpsUid, TownSid}, 0).
%% ----------------------------------------------------
%% @doc
%%      删除放弃城池辅助信息
%% @end
%% ----------------------------------------------------
del_abondoning_town_tmp(Src, CorpsUid, TownSid, Sec) ->
    z_db_lib:delete(game_lib:get_table(Src, 'abandoning_town_tmp'), {Sec, CorpsUid, TownSid}).

%% ----------------------------------------------------
%% @doc
%%      改名
%% @end
%% ----------------------------------------------------
change_name(_, {_RoleUid, CorpsUid, OldCorpsName, NName}, [{Index1, Corps}, {Index2, 'none'}, {Index3, _}, {Index4, GoodStorage}, {_, RoleCorps}]) ->
    case corps_lib:check_position_limit('change_name', role_corps:get_position(RoleCorps)) of
        true ->
            ok;
        Err ->
            throw(Err)
    end,
    OldCorpsName = corps:get_name(Corps),%%匹配下名字
    {_, Consumes} = zm_config:get('corps', 'change_name_consume'),

    Bool2 = game_lib:checks({'corps_lib', 'check'}, {GoodStorage}, 'change_name', Consumes),
    if
        Bool2 ->
            ok;
        true ->
            throw(Bool2)
    end,
    {Cs, {NGoodStorage}} = game_lib:consumes({'corps_lib', 'consume'}, {GoodStorage}, 'change_name', Consumes),
    NCorps = corps:set_name(Corps, NName),
    {ok, {ok, NCorps, Cs}, [{Index1, NCorps}, {Index2, CorpsUid}, {Index3, 'delete'}, {Index4, NGoodStorage}]};
change_name(_, _, _) ->
    throw("corps_name_exist").
%% ----------------------------------------------------
%% @doc
%%      获取结盟信息
%% @end
%% ----------------------------------------------------
get_db_ally_info(Src, CorpsUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'ally_info'), CorpsUid, ally_info:init()).

%% ----------------------------------------------------
%% @doc
%%      申请结盟
%% @end
%% ----------------------------------------------------
ally_request(_A, {CorpsUid, _BCorpsUid, AllyCd, AllyRefuseCd, AllyRequsetValidTime, Now}, [{_Index1, AllyInfo}, {Index2, BAllyInfo}]) ->
    AllyCorpsList = ally_info:get_ally_corps(AllyInfo),
    BAllyCorpsList = ally_info:get_ally_corps(BAllyInfo),
    if
        AllyCorpsList =:= [] ->
            if
                BAllyCorpsList =:= [] ->
                    case ally_info:get_delete_time(AllyInfo) + AllyCd < Now of
                        true ->
                            case ally_info:get_delete_time(BAllyInfo) + AllyCd < Now of
                                true ->
                                    BRefuse = ally_info:get_refuses(BAllyInfo),
                                    NBRefuse = corps_lib:ally_clear_invalid_info(BRefuse, AllyRefuseCd, Now),
                                    case lists:keyfind(CorpsUid, 1, NBRefuse) of
                                        false ->
                                            BInvites = ally_info:get_invites(BAllyInfo),
                                            NBInvites = corps_lib:ally_clear_invalid_info(BInvites, AllyRequsetValidTime, Now),
                                            case lists:keyfind(CorpsUid, 1, BInvites) of
                                                false ->
                                                    NAAllyInfo = ally_info:set_refuses(ally_info:set_invites(BAllyInfo, [{CorpsUid, Now} | NBInvites]), NBRefuse),
                                                    {ok, ok, [{Index2, NAAllyInfo}]};
                                                _ ->
                                                    throw("ok")
                                            end;
                                        _ ->
                                            throw("ok")
                                    end;
                                false ->
                                    throw("other_cd_limit")
                            end;
                        false ->
                            throw("cd_limit")
                    end;
                true ->
                    throw("other_already_ally")
            end;
        true ->
            throw("already_ally")
    end.
%% ----------------------------------------------------
%% @doc
%%      回复结盟
%% @end
%% ----------------------------------------------------
ally_reply(_A, {CorpsUid, BCorpsUid, Reply, AllyCd, RefuseCd, RequsetValidTime, Now}, [{Index1, AllyInfo}, {Index2, BAllyInfo}]) ->
    BInvites = ally_info:get_invites(BAllyInfo),
    case lists:keytake(CorpsUid, 1, BInvites) of
        {'value', {CorpsUid, RequestTime}, NBInvites} ->
            NBAllyInfo1 = ally_info:set_invites(BAllyInfo, corps_lib:ally_clear_invalid_info(NBInvites, RequsetValidTime, Now)),
            BRefuse = ally_info:get_refuses(NBAllyInfo1),
            NBRefuse = corps_lib:ally_clear_invalid_info(BRefuse, RefuseCd, Now),
            NBAllyInfo2 = ally_info:set_refuses(NBAllyInfo1, NBRefuse),
            if
                Reply =:= ?REFUSE ->
                    NBAllyInfoTmp = ally_info:set_refuses(NBAllyInfo2, [{CorpsUid, Now} | NBRefuse]),
                    {ok, ok, [{Index2, NBAllyInfoTmp}]};
                Reply =:= ?AGREE ->
                    if
                        RequestTime + RequsetValidTime >= Now ->
                            CorpsAllyList = ally_info:get_ally_corps(AllyInfo),
                            BCorpsAllyList = ally_info:get_ally_corps(BAllyInfo),
                            if
                                CorpsAllyList =:= [] -> %%现在只能与一个军团结盟
                                    if
                                        BCorpsAllyList =:= [] ->
                                            case ally_info:get_delete_time(AllyInfo) + AllyCd < Now of
                                                true ->
                                                    case ally_info:get_delete_time(BAllyInfo) + AllyCd < Now of
                                                        true ->
                                                            NBAllyInfo3 = ally_info:set_ally_corps(NBAllyInfo2, [CorpsUid | BCorpsAllyList]),
                                                            NAllyInfo3 = ally_info:set_ally_corps(AllyInfo, [BCorpsUid | CorpsAllyList]),
                                                            {ok, ok, [{Index1, NAllyInfo3}, {Index2, NBAllyInfo3}]};
                                                        false ->
                                                            throw("other_cd_limit")
                                                    end;
                                                false ->
                                                    throw("cd_limit")
                                            end;
                                        true ->
                                            throw("other_already_ally")
                                    end;
                                true ->
                                    {ok, "already_ally", [{Index2, NBAllyInfo2}]}
                            end;
                        true ->
                            throw("request_valid_time_out")
                    end
            end;
        false ->
            throw("no_invite")
    end.
%% ----------------------------------------------------
%% @doc
%%      解散结盟
%% @end
%% ----------------------------------------------------
ally_delete(_A, {Now, CorpsUid, BCorpsUid}, [{Index1, AllyInfo}, {Index2, BAllyInfo}]) ->
    BAllyCorpsUids = ally_info:get_ally_corps(BAllyInfo),
    AllyCorpsUids = ally_info:get_ally_corps(AllyInfo),
    case hd(AllyCorpsUids) =:= BCorpsUid of
        true ->
            NBAllyInfo1 = ally_info:set_ally_corps(BAllyInfo, lists:delete(CorpsUid, BAllyCorpsUids)),
            NAllyInfo1 = ally_info:set_ally_corps(AllyInfo, lists:delete(BCorpsUid, AllyCorpsUids)),

            NBAllyInfo2 = ally_info:set_delete_time(NBAllyInfo1, Now),
            NAllyInfo2 = ally_info:set_delete_time(NAllyInfo1, Now),
            {ok, ok, [{Index1, NAllyInfo2}, {Index2, NBAllyInfo2}]};
        false ->
            throw("error_ally_corps_uid")
    end.

%% ----------------------------------------------------
%% @doc
%%       根据名字模糊查找军团Uid
%% @end
%% ----------------------------------------------------
search_by_name(Src, Name, Country) ->
    Table = game_lib:get_table(Src, 'corps_name'),
    Fun = fun(_Src, Key, _, R) ->
        Check = string_lib:string_with_exist(Name, Key),
        if
            Check ->
                CorpsUid = z_db_lib:get(Table, Key, none),
                if
                    CorpsUid =/= none ->
                        case corps_db:get_corps(Src, CorpsUid) of
                            'none' ->
                                {ok, R};
                            Cps ->
                                case corps:get_country(Cps) =:= Country of
                                    true ->
                                        {ok, [CorpsUid | R]};
                                    false ->
                                        {ok, R}
                                end
                        end;
                    true ->
                        {ok, R}
                end;
            true ->
                {ok, R}
        end
          end,
    z_db_lib:table_iterate(Src, Table, Fun, [], []).
%% ----------------------------------------------------
%% @doc
%%       获取盟军信息
%% @end
%% ----------------------------------------------------
ally_get_corps_info(Src, RoleUid, CorpsUid) ->
    BAllyInfo = corps_db:get_db_ally_info(Src, CorpsUid),
    RoleCorps = corps_db:get_role_corps(Src, RoleUid),
    Pos = role_corps:get_position(RoleCorps),
    Bool = corps_lib:check_position_limit('ally_operation', Pos) =:= true,
    case ally_info:get_ally_corps(BAllyInfo) of
        [] ->
            InvitesList = if
                              Bool ->
                                  Now = time_lib:now_second(),
                                  {_, RequestValidTime} = zm_config:get('corps', 'request_ally_valid_time'),
                                  corps_lib:ally_format_invites(Src, ally_get_invites(Src, CorpsUid, Now, RequestValidTime));
                              true ->
                                  {}
                          end,
            {{ally_info:get_delete_time(BAllyInfo)}, {}, InvitesList};
        [BCorpsUid | _] ->
            case corps_db:get_corps(Src, BCorpsUid) of
                none ->
                    Fun1 = fun(_, AllyInfoTmp) ->
                        BAllyInfo1 = ally_info:set_ally_corps(AllyInfoTmp, lists:delete(BCorpsUid, ally_info:get_ally_corps(AllyInfoTmp))),
                        {ok, ok, BAllyInfo1}
                           end,
                    z_db_lib:update(game_lib:get_table(Src, 'ally_info'), CorpsUid, ally_info:init(), Fun1, []),
                    {{ally_info:get_delete_time(BAllyInfo)}, {}, {}};
                BCorps ->
                    {corps_lib:ally_format_get_corps_info(Src, BCorpsUid, BCorps, Bool), list_to_tuple(corps_db:get_corps_members(Src, BCorpsUid)), {}}
            end
    end.
%% ----------------------------------------------------
%% @doc
%%       两个军团是否是盟军
%% @end
%% ----------------------------------------------------
is_ally(Src, CorpsUid1, CorpsUid2) ->
    AllyInfo1 = get_db_ally_info(Src, CorpsUid1),
    AllyCorpsUids1 = ally_info:get_ally_corps(AllyInfo1),
    AllyCorpsUids1 =/= [] andalso CorpsUid2 =:= hd(AllyCorpsUids1).
%% ----------------------------------------------------
%% @doc
%%       获取盟军uids
%% @end
%% ----------------------------------------------------
get_ally_corps_uids(Src, CorpsUid) ->
    AllyInfo = get_db_ally_info(Src, CorpsUid),
    ally_info:get_ally_corps(AllyInfo).
%% ----------------------------------------------------
%% @doc
%%       军团解散处理
%% @end
%% ----------------------------------------------------
ally_delete_corps(Src, Now, RoleUid, CorpsUid) ->
    AllyInfo = get_db_ally_info(Src, CorpsUid),
    case ally_info:get_ally_corps(AllyInfo) of
        [] ->
            ok;
        [BAllyCorpsUid | _] ->
            %%    盟军进入冷却
            Fun1 = fun(_, BAllyInfo) ->
                BAllyInfo1 = ally_info:set_ally_corps(BAllyInfo, lists:delete(CorpsUid, ally_info:get_ally_corps(BAllyInfo))),
                BAllyInfo2 = ally_info:set_delete_time(BAllyInfo1, Now),
                {ok, ok, BAllyInfo2}
                   end,
            z_db_lib:update(game_lib:get_table(Src, 'ally_info'), BAllyCorpsUid, ally_info:init(), Fun1, []),
            set_front_lib:send_ally_delete(Src, [RoleUid | corps_db:get_corps_members(Src, BAllyCorpsUid)], {})
    end.
%% ----------------------------------------------------
%% @doc
%%       获取邀请信息的时候，处理过期信息
%% @end
%% ----------------------------------------------------
ally_get_invites(Src, CorpsUid, Now, RequestValidTime) ->
    Fun1 = fun(_, BAllyInfo) ->
        BInvites = ally_info:get_invites(BAllyInfo),
        NBInvites = corps_lib:ally_clear_invalid_info(BInvites, RequestValidTime, Now),
        NBAllyInfo = ally_info:set_invites(BAllyInfo, NBInvites),
        {ok, NBInvites, NBAllyInfo}
           end,
    z_db_lib:update(game_lib:get_table(Src, 'ally_info'), CorpsUid, ally_info:init(), Fun1, []).
%%===================LOCAL FUNCTIONS==================

corps_help_queue_over1(_A, {_RoleUid, BSid, Sid} = Key, [{Index1, RCHelp} | T]) ->
    case lists:keyfind({BSid, Sid}, 2, RCHelp) of
        {Id, {BSid, Sid}} ->
            NRCHelp = lists:delete({Id, {BSid, Sid}}, RCHelp),
            case T of
                [{Index2, {MaxId, CCHelp}} | _] ->
                    NT = [{Index2, {MaxId, lists:keydelete(Key, corps_help:get_key_index(), CCHelp)}}],
                    {ok, {ok, Id}, [{Index1, NRCHelp} | NT]};

                [] ->
                    {ok, ok, [{Index1, NRCHelp}]}
            end;
        false ->
            {ok, ok}
    end.


%% ----------------------------------------------------
%% @doc
%%      更新主城等级分布
%% @end
%% ----------------------------------------------------
update_corps_mf_level_1(Src, RoleUid, Type, RoleShow, NRoleShow) when Type =:= 'castle' orelse Type =:= 'castle_lv' ->
    OldIndex = role_show:get_castle_lv(RoleShow),
    NewIndex = role_show:get_castle_lv(NRoleShow),
    case role_show:get_corps_uid(NRoleShow) =:= 0 andalso
         OldIndex =/= NewIndex andalso
        corps_lib:check_enter(Src, NRoleShow) =:= true of
        true ->
            Country = role_show:get_country(RoleShow),
            case corps_lib:check_corps_invite(Src, RoleUid) of
                true ->
                    Fun = fun(_, [{Index1, RUidList1}, {Index2, RUidList2}]) ->
                        NRUidList1 = lists:delete(RoleUid, RUidList1),
                        NRUidList2 = [RoleUid | lists:delete(RoleUid, RUidList2)],
                        {ok, ok, [{Index1, NRUidList1}, {Index2, NRUidList2}]}
                          end,
                    TableName = game_lib:get_table(Src),
                    TableKeys = z_db_lib:transformation_tablekey(TableName,
                                                                 [
                                                                     {'corps_mb_level', {OldIndex, Country}, []},
                                                                     {'corps_mb_level', {NewIndex, Country}, []}
                                                                 ]),
                    z_db_lib:handle(TableName, Fun, [], TableKeys);
                false ->
                    Fun = fun(_, RUidList) ->
                        {ok, ok, lists:delete(RoleUid, RUidList)}
                          end,
                    z_db_lib:update(game_lib:get_table(Src, 'corps_mb_level'), {OldIndex, Country}, [], Fun, [])
            end;
        false ->
            ok
    end;
update_corps_mf_level_1(Src, RoleUid, 'corps', RoleShow, NRoleShow) ->
    CorpsUid1 = role_show:get_corps_uid(RoleShow),
    CorpsUid2 = role_show:get_corps_uid(NRoleShow),
    Country = role_show:get_country(RoleShow),
    Index = role_show:get_castle_lv(NRoleShow),
    if
        CorpsUid1 =:= 0 andalso CorpsUid2 =/= 0 ->
            Fun = fun(_, RUidList) ->
                {ok, ok, lists:delete(RoleUid, RUidList)}
                  end,
            ok = z_db_lib:update(game_lib:get_table(Src, 'corps_mb_level'), {Index, Country}, [], Fun, []),
            ok;
        CorpsUid1 =/= 0 andalso CorpsUid2 =:= 0 ->
            case corps_lib:check_corps_invite(Src, RoleUid) andalso corps_lib:check_enter(Src, NRoleShow) =:= true of
                true ->
                    Fun = fun(_, RUidList) ->
                        {ok, ok, [RoleUid | lists:delete(RoleUid, RUidList)]}
                          end,
                    ok = z_db_lib:update(game_lib:get_table(Src, 'corps_mb_level'), {Index, Country}, [], Fun, []),
                    ok;
                false ->
                    ok
            end;
        true ->
            ok
    end;
update_corps_mf_level_1(Src, RoleUid, 'level', RoleShow, NRoleShow) ->
    CorpsUid = role_show:get_corps_uid(NRoleShow),
    Country = role_show:get_country(RoleShow),
    Index = role_show:get_castle_lv(NRoleShow),
    case CorpsUid =:= 0 andalso corps_lib:check_corps_invite(Src, RoleUid) andalso
         corps_lib:check_enter(Src, RoleShow) =/= true andalso corps_lib:check_enter(Src, NRoleShow) =:= true of
        true ->
            TableName = game_lib:get_table(Src, 'corps_mb_level'),
            Key = {Index, Country},
            case lists:member(RoleUid, z_db_lib:get(TableName, Key, [])) of
                false ->
                    Fun = fun(_, RUidList) ->
                        case lists:member(RoleUid, RUidList) of
                            true ->
                                {ok, ok};
                            false ->
                                {ok, ok, [RoleUid | lists:delete(RoleUid, RUidList)]}
                        end
                          end,
                    z_db_lib:update(TableName, Key, [], Fun, []);
                true ->
                    ok
            end;
        false ->
            ok
    end;
update_corps_mf_level_1(Src, RoleUid, 'login', RoleShow, _) ->
    CorpsUid = role_show:get_corps_uid(RoleShow),
    Country = role_show:get_country(RoleShow),
    Index = role_show:get_castle_lv(RoleShow),
    case CorpsUid =:= 0 andalso corps_lib:check_corps_invite(Src, RoleUid) andalso corps_lib:check_enter(Src, RoleShow) =:= true of
        true ->
            TableName = game_lib:get_table(Src, 'corps_mb_level'),
            Key = {Index, Country},
            case lists:member(RoleUid, z_db_lib:get(TableName, Key, [])) of
                false ->
                    Fun = fun(_, RUidList) ->
                        case lists:member(RoleUid, RUidList) of
                            true ->
                                {ok, ok};
                            false ->
                                {ok, ok, [RoleUid | lists:delete(RoleUid, RUidList)]}
                        end
                          end,
                    z_db_lib:update(TableName, Key, [], Fun, []);
                true ->
                    ok
            end;
        false ->
            ok
    end;
update_corps_mf_level_1(Src, RoleUid, 'change_country', RoleShow, NRoleShow) ->
    case role_show:get_corps_uid(NRoleShow) =:= 0 andalso
         corps_lib:check_enter(Src, NRoleShow) =:= true of
        true ->
            OldCountry = role_show:get_country(RoleShow),
            NewCountry = role_show:get_country(NRoleShow),
            CastleLv = role_show:get_castle_lv(NRoleShow),
            case corps_lib:check_corps_invite(Src, RoleUid) of
                true ->
                    Fun = fun(_, [{Index1, RUidList1}, {Index2, RUidList2}]) ->
                        NRUidList1 = lists:delete(RoleUid, RUidList1),
                        NRUidList2 = [RoleUid | lists:delete(RoleUid, RUidList2)],
                        {ok, ok, [{Index1, NRUidList1}, {Index2, NRUidList2}]}
                          end,
                    TableName = game_lib:get_table(Src),
                    TableKeys = z_db_lib:transformation_tablekey(TableName,
                                                                 [
                                                                     {'corps_mb_level', {CastleLv, OldCountry}, []},
                                                                     {'corps_mb_level', {CastleLv, NewCountry}, []}
                                                                 ]),
                    z_db_lib:handle(TableName, Fun, [], TableKeys);
                false ->
                    Fun = fun(_, RUidList) ->
                        {ok, ok, lists:delete(RoleUid, RUidList)}
                          end,
                    z_db_lib:update(game_lib:get_table(Src, 'corps_mb_level'), {CastleLv, OldCountry}, [], Fun, [])
            end;
        false ->
            ok
    end;
update_corps_mf_level_1(_, _, _, _, _) ->
    ok.
%% ----------------------------------------------------
%% @doc
%%      转换阵营2   选取新的军团长Uid
%% @end
%% ----------------------------------------------------
change_country2_new_owner(Src, CorpsUid, Corps) ->
    VList = corps:get_vice_owner_list(Corps),
    Now = time_lib:now_second(),
    {_, ActiveTime} = zm_config:get('corps', 'replace_active_time'),
    Members = corps_db:get_corps_members(Src, CorpsUid),
    ChooseMembers = lists:delete(corps:get_owner(Corps), Members--VList),
    RankList = z_db_lib:get(game_lib:get_table(Src, 'contribute_rank'), CorpsUid, []),
    case change_country2_new_owner_(Src, Now, VList, ActiveTime, RankList, true) of
        {0, _} ->
            {Uid, _} = change_country2_new_owner_(Src, Now, ChooseMembers, ActiveTime, RankList, false),
            Uid;
        {Uid, _} ->
            Uid
    end.
%% ----------------------------------------------------
%% @doc
%%      转换阵营2    获取最活跃军团玩家uid
%% @end
%% ----------------------------------------------------
change_country2_new_owner_(_, _, [], _, _, _) ->
    {0, 0};
change_country2_new_owner_(Src, Now, Members, ActiveTime, RankList, IsMustActive) ->
    Fun = fun({ActiveUid, ActiveContribute, NAUid, NAC} = Acc, {Uid, Guser}) ->
        InTime1 = guser:get_login_time(Guser),
        OutTime1 = guser:get_logout_time(Guser),
        CNum = z_lib:get_value(RankList, Uid, 0),
        if
            InTime1 > OutTime1 orelse Now - OutTime1 < ActiveTime ->
                if
                    CNum > ActiveContribute orelse ActiveUid =:= 0 ->
                        {ok, {Uid, CNum, NAUid, NAC}};
                    true ->
                        {ok, Acc}
                end;
            IsMustActive ->
                {ok, Acc};
            true ->
                if
                    CNum > NAC orelse NAUid =:= 0 ->
                        {ok, {ActiveUid, ActiveContribute, Uid, CNum}};
                    true ->
                        {ok, Acc}
                end
        end
          end,
    {AUid, AContribute, NAUid, NAContrubute} = z_lib:foreach(Fun, {0, 0, 0, 0}, lists:zip(Members, z_db_lib:gets(game_lib:get_table(Src, 'user'), Members))),
    if
        AUid =/= 0 ->
            {AUid, AContribute};
        true ->
            {NAUid, NAContrubute}
    end.