-module(mail).

-description("邮件基础模块").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_annex/1, get_content/1, get_etime/1, get_src/1, get_state/1, get_stime/1, get_title/1, get_type/1, get_uid/1, get_flag/1]).
-export([set_title/2, set_content/2, set_src/2, set_state/2, set_type/2, set_uid/2, set_annex/2, set_stime/2, set_etime/2, set_flag/2]).
-export([init/1]).
-export([get_stime_index/0, init_sys/2]).
-export([content_to_title/2]).
-export_type([mail/0]).
%%%=======================INCLUDE======================
-include("../include/mail.hrl").

%%%=======================RECORD=======================
-record(mail, {
    uid :: integer(),   %%uid
    src :: string(),   %%发起方
    type :: integer(),  %%类型
    stime :: integer(), %%发起时间
    etime :: integer(), %%过期时间
    title :: integer() | tuple(),%%标题
    content :: integer() | tuple(),%%内容
    annex :: list(),    %%附件
    state = 0 :: integer(),  %%状态
    flag = 0 :: integer()|list() %%标记 0普通邮件,[角色uid,..]军团邮件(可收取的人员uid)
}).

%%%=======================DEFINE=======================
%%%=======================TYPE=========================
-type mail() :: #mail{}.
%%%=================EXPORTED FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%        获得邮件id
%% @end
%% ----------------------------------------------------
-spec get_uid(mail()) -> integer().
get_uid(#mail{uid = Uid}) ->
    Uid.
%% ----------------------------------------------------
%% @doc
%%        发起方
%% @end
%% ----------------------------------------------------
-spec get_src(mail()) -> string().
get_src(#mail{src = Src}) ->
    Src.
%% ----------------------------------------------------
%% @doc
%%        获得类型 1:系统邮件 2：GM 3:包裹溢出邮件
%% @end
%% ----------------------------------------------------
-spec get_type(mail()) -> integer().
get_type(#mail{type = Type}) ->
    Type.
%% ----------------------------------------------------
%% @doc
%%        获得发起时间
%% @end
%% ----------------------------------------------------
-spec get_stime(mail()) -> integer().
get_stime(#mail{stime = STime}) ->
    STime.
%% ----------------------------------------------------
%% @doc
%%        过期时间
%% @end
%% ----------------------------------------------------
-spec get_etime(mail()) -> integer().
get_etime(#mail{etime = ETime}) ->
    ETime.
%% ----------------------------------------------------
%% @doc
%%        获得邮件主题
%% @end
%% ----------------------------------------------------
-spec get_title(mail()) -> integer() | tuple().
get_title(#mail{title = Title}) ->
    Title.
%% ----------------------------------------------------
%% @doc
%%        获得邮件内容
%% @end
%% ----------------------------------------------------
-spec get_content(mail()) -> integer() | tuple().
get_content(#mail{content = Content}) ->
    Content.
%% ----------------------------------------------------
%% @doc
%%        获得附件信息
%% @end
%% ----------------------------------------------------
-spec get_annex(mail()) -> list().
get_annex(#mail{annex = Annex}) ->
    Annex.
%% ----------------------------------------------------
%% @doc
%%        获得邮件状态
%% @end
%% ----------------------------------------------------
-spec get_state(mail()) -> integer().
get_state(#mail{state = State}) ->
    State.
%%-------------------------------------------------------------------
%% @doc
%%
%% @end
%%-------------------------------------------------------------------
-spec get_stime_index() -> integer().
get_stime_index() -> #mail.stime.

%% ----------------------------------------------------
%% @doc
%%        获得标记
%% @end
%% ----------------------------------------------------
-spec get_flag(mail()) -> integer()|list().
get_flag(#mail{flag = Flag}) -> Flag.

%% ----------------------------------------------------
%% @doc
%%        设置邮件uid
%% @end
%% ----------------------------------------------------
-spec set_uid(mail(), integer()) -> mail().
set_uid(Mail, Uid) ->
    Mail#mail{uid = Uid}.

%% ----------------------------------------------------
%% @doc
%%        设置邮件状态
%% @end
%% ----------------------------------------------------
-spec set_state(mail(), integer()) -> mail().
set_state(Mail, State) ->
    Mail#mail{state = State}.
%% ----------------------------------------------------
%% @doc
%%        设置发件人
%% @end
%% ----------------------------------------------------
-spec set_src(mail(), string()) -> mail().
set_src(Mail, Src) ->
    Mail#mail{src = Src}.
%% ----------------------------------------------------
%% @doc
%%        设置邮件类型 获得类型_1:系统邮件,2：GM,3溢出物品邮件
%% @end
%% ----------------------------------------------------
-spec set_type(mail(), integer()) -> mail().
set_type(Mail, Type) ->
    Mail#mail{type = Type}.
%% ----------------------------------------------------
%% @doc
%%        设置标题
%% @end
%% ----------------------------------------------------
-spec set_title(mail(), integer() | tuple()) -> mail().
set_title(Mail, V) ->
    Mail#mail{title = V}.
%% ----------------------------------------------------
%% @doc
%%        设置内容
%% @end
%% ----------------------------------------------------
-spec set_content(mail(), integer() | tuple()) -> mail().
set_content(Mail, Content) ->
    Mail#mail{content = Content}.
%% ----------------------------------------------------
%% @doc
%%        设置邮件附件
%% @end
%% ----------------------------------------------------
-spec set_annex(mail(), list()) -> mail().
set_annex(Mail, Annex) ->
    Mail#mail{annex = Annex}.
%% ----------------------------------------------------
%% @doc
%%        设置邮件生效时间
%% @end
%% ----------------------------------------------------
-spec set_stime(mail(), integer()) -> mail().
set_stime(Mail, V) ->
    Mail#mail{stime = V}.
%% ----------------------------------------------------
%% @doc
%%        设置邮件过期时间
%% @end
%% ----------------------------------------------------
-spec set_etime(mail(), integer()) -> mail().
set_etime(Mail, V) ->
    Mail#mail{etime = V}.
%% ----------------------------------------------------
%% @doc
%%        设置标记
%% @end
%% ----------------------------------------------------
-spec set_flag(mail(), integer()|list()) -> mail().
set_flag(Mail, V) ->
    Mail#mail{flag = V}.

%% ----------------------------------------------------
%% @doc
%%        初始化邮件 (language.cfg中需要加入,用于bi存储获取使用)
%%        type 为:对应 award_source.erl中定义的信息
%%        Title/Content=1:溢出物品,2=官职提升,3=活动,4=军团关卡通关奖励,5=军团章节,6=伤兵营上限转换为死亡
%% @end
%% ----------------------------------------------------
-spec init(Args) -> mail() when
    Args :: {integer(), integer(), integer(), integer() | tuple()|string(), integer() | tuple()|string(), list()}
    |{string(), integer(), integer(), integer(), integer() | tuple()|string(), integer() | tuple()|string(), list()}.
init({Type, STime, ETime, _Title, Content, Annex}) ->
    STime1 = if
        STime =< 0 ->
            time_lib:now_second();
        true ->
            STime
    end,
    ETime1 = if
        ETime =< 0 ->
            if
                Annex =:= [] ->
                    STime1 + ?MAIL_TIMEOUT_TIME_2;
                true ->
                    STime1 + ?MAIL_TIMEOUT_TIME_3
            end;
        true ->
            ETime
    end,
    Title = content_to_title(game_lib:get_game_src(), Content),
    #mail{uid = 0, src = "", type = Type, stime = STime1, etime = ETime1, title = Title, content = Content, annex = Annex};
init({Source, Type, STime, ETime, _Title, Content, Annex}) ->
    STime1 = if
        STime =< 0 ->
            time_lib:now_second();
        true ->
            STime
    end,
    ETime1 = if
        ETime =< 0 ->
            if
                Annex =:= [] ->
                    STime1 + ?MAIL_TIMEOUT_TIME_2;
                true ->
                    STime1 + ?MAIL_TIMEOUT_TIME_3
            end;
        true ->
            ETime
    end,
    Title = content_to_title(game_lib:get_game_src(), Content),
    #mail{uid = 0, src = Source, type = Type, stime = STime1, etime = ETime1, title = Title, content = Content, annex = Annex}.


%% ----------------------------------------------------
%% @doc
%%    system_mail时候设置uid
%% @end
%% ----------------------------------------------------
init_sys(Src, Args) ->
    Mail = init(Args),
    set_uid(Mail, uid_lib:create_mail_uid(Src)).

%% ----------------------------------------------------
%% @doc
%%      内容转标题
%% @end
%% ----------------------------------------------------
content_to_title(_Src, Content) when is_list(Content) ->
    lists:sublist(Content, 20);
content_to_title(Src, Content) when is_integer(Content) ->%%
    content_to_title(Src, mail_lib:format_content(Src, Content));
content_to_title(_Src, Content) ->
    case tuple_size(Content) =:= 2 andalso element(1, Content) =:= 0 andalso is_list(element(2, Content)) of
        true ->
            setelement(2, Content, lists:sublist(element(2, Content), 20));
        false ->
            Content
    end.