-module(mail_db).

-description("邮件数据库操作模块").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_mailbox/2]).
-export([get_mails_state/3, get_mails/3, read/3, take/3, del_mails/3, send/3, set_flag/4, reads/3]).
-export([send_system_mail/2, delete_system_mail/2]).
-export([get_all_sysmail/1, reads_sysmails/2]).
-export([get_mails_reminder/3]).
-export([clear_role_award_mail/4]).
-export([get_complete_system_mail/1]).
%%%=======================INCLUDE=======================
-include("../include/mail.hrl").

%%%=======================DEFINE=======================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%        得到邮箱
%% @end
%% ----------------------------------------------------
-spec get_mailbox(atom(), integer()) -> {[mail:mail()], [integer()]}.
get_mailbox(Src, Uid) ->
    z_db_lib:get(game_lib:get_table(Src, 'mailbox'), Uid, {[], []}).

%% ----------------------------------------------------
%% @doc
%%        得到邮件状态标记，0|1满|2存在未读
%% @end
%% ----------------------------------------------------
-spec get_mails_state(atom(), integer(), integer()) -> integer().
get_mails_state(Src, RoleUid, BiPlatformId) ->
    Mails = get_mails(Src, RoleUid, BiPlatformId),
    if
        length(Mails) >= ?MAIL_MAX_SYS + ?MAIL_MAX_CORPS ->
            1;
        true ->
            z_lib:foreach(fun(A, Mail) ->
                case mail:get_state(Mail) =:= 0 of
                    true ->
                        {break, 2};
                    _ ->
                        A
                end
            end, 0, Mails)
    end.
%% ----------------------------------------------------
%% @doc
%%        得到邮件红点数据, 未读取, 未领取
%% @end
%% ----------------------------------------------------
-spec get_mails_reminder(Src, RoleUid, BiPlatformId) -> integer() when
    Src :: atom(),
    RoleUid :: integer(),
    BiPlatformId :: integer().
get_mails_reminder(Src, RoleUid, BiPlatformId) ->
    Mails = get_mails(Src, RoleUid, BiPlatformId),
    Func1 = fun(Mail, Num) ->
        case mail:get_state(Mail) of
            ?TAKE ->
                Num;
            ?UNREAD ->
                Num + 1;
            _ ->
                Check = mail_lib:check_annex(Mail),
                if
                    Check =:= 1 ->
                        Num + 1;
                    true ->
                        Num
                end
        end
    end,
    lists:foldl(Func1, 0, Mails).


%% ----------------------------------------------------
%% @doc
%%        获取指定数量邮件(合并系统邮件)
%% @end
%% ----------------------------------------------------
-spec get_mails(atom(), integer(), integer()) -> [mail:mail()].
get_mails(Src, RoleUid, BiPlatFormId) ->
    TableName = game_lib:get_table(Src),
    {Mails, SystemMailUids} = get_mailbox(Src, RoleUid),
    {AddMails, NSystemMailUids, AddSystemMailUids} = get_add_sysmail1(Src, RoleUid, BiPlatFormId, SystemMailUids),
    CAddMails = corps_db:get_role_corps_mail(Src, RoleUid),
    case CAddMails =:= [] andalso AddMails =:= [] of
        true ->
            Mails;
        false ->
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'mailbox', RoleUid, {[], []}}]),
            {NMails, DeleteMails} =
                z_db_lib:handle(TableName, fun get_mails_/2, {Src, RoleUid, AddMails, NSystemMailUids, AddSystemMailUids, CAddMails}, TableKeys), %%清理过期
            if
                AddMails =:= [] andalso DeleteMails =:= [] ->
                    ok;
                true ->
                    zm_event:notify(Src, 'bi_get_mail', [{'role_uid', RoleUid}, {'get_mails', {NMails, AddMails, DeleteMails}}])
            end,
            NMails
    end.

%% ----------------------------------------------------
%% @doc
%%        读取邮件
%% @end
%% ----------------------------------------------------
-spec read(atom(), integer(), integer()) -> string() | mail:mail().
read(Src, RoleUid, MailUid) ->
    z_db_lib:update(game_lib:get_table(Src, 'mailbox'), RoleUid, {[], []},
        fun(_, {Mails, SystemMailUids}) ->
            case lists:keyfind(MailUid, 2, Mails) of
                false ->
                    throw("mail_not_exsit");
                Mail ->
                    case mail:get_state(Mail) of
                        ?UNREAD ->
                            NMail = mail_lib:change_mail_etime('read', mail:set_state(Mail, ?READ)),
                            {ok, NMail, {lists:keyreplace(MailUid, 2, Mails, NMail), SystemMailUids}};
                        _ ->
                            {ok, Mail}
                    end
            end
        end, []).

%% ----------------------------------------------------
%% @doc
%%        读取邮件
%% @end
%% ----------------------------------------------------
-spec reads(atom(), integer(), [integer()]) -> string() | 'ok'.
reads(Src, RoleUid, MailUids) ->
    Fun = fun(_, {Mails, SystemMailUids}) ->
        NMails = z_lib:foreach(fun(MailAcc, MailUid) ->
            case lists:keyfind(MailUid, 2, MailAcc) of
                false ->
                    throw("mail_not_exsit");
                Mail ->
                    case mail:get_state(Mail) of
                        ?UNREAD ->
                            NMail = mail_lib:change_mail_etime('read', mail:set_state(Mail, ?READ)),
                            {ok, lists:keyreplace(MailUid, 2, MailAcc, NMail)};
                        _ ->
                            {ok, MailAcc}
                    end
            end
        end, Mails, MailUids),
        {ok, ok, {NMails, SystemMailUids}}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'mailbox'), RoleUid, {[], []}, Fun, []).

%% ----------------------------------------------------
%% @doc
%%        设置标记
%% @end
%% ----------------------------------------------------
-spec set_flag(atom(), integer(), integer(), 0|1) -> string() | mail:mail().
set_flag(Src, RoleUid, MailUid, Flag) ->
    z_db_lib:update(game_lib:get_table(Src, 'mailbox'), RoleUid, {[], []},
        fun(_, {Mails, SystemMailUids}) ->
            case lists:keyfind(MailUid, 2, Mails) of
                false ->
                    throw("mail_not_exsit");
                Mail ->
                    NMail = mail:set_flag(Mail, Flag),
                    {ok, ok, {lists:keyreplace(MailUid, 2, Mails, NMail), SystemMailUids}}
            end
        end, []).

%% ----------------------------------------------------
%% @doc
%%        提取附件，外部使用award发奖
%% @end
%% ----------------------------------------------------
-spec take(atom(), integer(), integer()|[integer()]) -> string() | {list(), [mail:mail()]} | string().
take(Src, RoleUid, MailUid) when is_integer(MailUid) ->
    take(Src, RoleUid, [MailUid]);
take(Src, RoleUid, MailUids) ->
    NewMailUids = lists:usort(MailUids),
    Func = fun(_, {Mails, SystemMailUids}) ->
        case take_(Src, RoleUid, Mails, NewMailUids, [], [], []) of
            {NewMails, Award, TakeMail} ->
                {ok, {Award, TakeMail}, {NewMails, SystemMailUids}};
            Err ->
                throw(Err)
        end
    end,
    z_db_lib:update(game_lib:get_table(Src, 'mailbox'), RoleUid, {[], []}, Func, none).

%% ----------------------------------------------------
%% @doc
%%        迭代处理邮件
%% @end
%% ----------------------------------------------------
-spec take_(Src, RoleUid, NewMails, MailUids, BagStateList, Award, TakeMail) -> string() | {list(), list()} when
    Src :: atom(),
    RoleUid :: integer(),
    NewMails :: list(),
    MailUids :: list(),
    BagStateList :: list(),
    Award :: list(),
    TakeMail :: list().
take_(_Src, _RoleUid, NewMails, [], _, Award, TakeMail) ->
    {NewMails, lists:flatten(Award), TakeMail};
take_(Src, RoleUid, Mails, [MailUid | MailUids], BagStateList, Award, TakeMail) ->
    case lists:keyfind(MailUid, 2, Mails) of
        false ->
            take_(Src, RoleUid, Mails, MailUids, BagStateList, Award, TakeMail);
        Mail ->
            case mail_lib:check_annex(Mail) of
                1 ->
                    Annex = mail:get_annex(Mail),
                    case chk_storage(Src, RoleUid, Annex, BagStateList) of
                        false ->
                            "storage_full";
                        NewBagStateList ->
                            Mail1 = mail_lib:change_mail_etime('take', mail:set_state(Mail, 2)),
                            NewMails = lists:keyreplace(MailUid, 2, Mails, Mail1),
                            take_(Src, RoleUid, NewMails, MailUids, NewBagStateList, [Annex | Award], [Mail1 | TakeMail])
                    end;
                _ ->
                    take_(Src, RoleUid, Mails, MailUids, BagStateList, Award, TakeMail)
            end
    end.

%% ----------------------------------------------------
%% @doc
%%        处理邮件, 得到新的背包情况列表
%% @end
%% ----------------------------------------------------
-spec chk_storage(Src, RoleUid, Annexs, BagStateList) -> false | list() when
    Src :: atom(),
    RoleUid :: integer(),
    Annexs :: list(),
    BagStateList :: list().
chk_storage(Src, RoleUid, [{'month_card', _} | Annex], BagStateList) ->
    chk_storage(Src, RoleUid, Annex, BagStateList);
chk_storage(Src, RoleUid, [{'super_card', _} | Annex], BagStateList) ->
    chk_storage(Src, RoleUid, Annex, BagStateList);
chk_storage(Src, RoleUid, [{_, SidAndNum} | Annex] = Annexs, BagStateList) when is_tuple(SidAndNum) ->
    {Sid, Num} =
        case SidAndNum of
            {Sid1, Num1} ->
                {Sid1, Num1};
            {Sid2, _Uid2, Num2} ->%带uid的附件
                {Sid2, Num2}
        end,
    Prop = prop_kit_lib:get_prop(Sid),
    PropType = prop_kit_lib:get_prop_type(Prop),
    PropMax = prop_kit_lib:get_prop_max(Prop),
    case lists:keyfind(PropType, 1, BagStateList) of
        false ->
            chk_storage(Src, RoleUid, Annexs, storage_state_init(Src, RoleUid, BagStateList, PropType, PropMax));
        {_, CurNum} when is_integer(CurNum) ->
            if
                CurNum < Num ->
                    false;
                true ->
                    chk_storage(Src, RoleUid, Annex, lists:keystore(PropType, 1, BagStateList, {PropType, CurNum - Num}))
            end;
        {_, {CurNum, ExistSids}} ->
            if
                CurNum < 1 ->
                    false;
                true ->
                    case lists:member(Sid, ExistSids) of
                        true ->
                            chk_storage(Src, RoleUid, Annex, BagStateList);
                        false ->
                            L1 = lists:keystore(PropType, 1, BagStateList, {PropType, {CurNum - 1, [Sid | ExistSids]}}),
                            chk_storage(Src, RoleUid, Annex, L1)
                    end
            end
    end;
chk_storage(Src, RoleUid, [_ | Annex], BagStateList) ->
    chk_storage(Src, RoleUid, Annex, BagStateList);
chk_storage(_Src, _RoleUid, [], BagStateList) ->
    BagStateList.

%% ----------------------------------------------------
%% @doc
%%        初始化包裹状态列表
%% @end
%% ----------------------------------------------------
storage_state_init(Src, RoleUid, BagStateList, PropType, PropMax) ->
    LimitSize = storage_lib:get_limit_size(Src, RoleUid, PropType),
    PropSets = storage_db:get_storage(PropType, Src, RoleUid),
    if
        PropMax =:= 1 ->
            lists:keystore(PropType, 1, BagStateList, {PropType, LimitSize - tuple_size(PropSets)});
        true ->
            Fun1 = fun({Acc0, Acc1}, _N, PropItem) ->
                PropSid = prop_kit_lib:get_prop_sid(PropItem),
                {'ok', {Acc0 - 1, [PropSid | Acc1]}}
            end,
            V = z_lib:tuple_foreach(PropSets, Fun1, {LimitSize, []}),
            lists:keystore(PropType, 1, BagStateList, {PropType, V})
    end.

%% ----------------------------------------------------
%% @doc
%%        删除指定邮件
%% @end
%% ----------------------------------------------------
-spec del_mails(Src, RoleUid, MailUid) -> {'ok', [mail:mail()]} | string() when
    Src :: atom(),
    RoleUid :: integer(),
    MailUid :: integer() | [integer()].
del_mails(Src, RoleUid, MailUid) when is_integer(MailUid) ->
    del_mails(Src, RoleUid, [MailUid]);
del_mails(Src, RoleUid, MailUids) ->
    NewMailUids = lists:usort(MailUids),
    z_db_lib:update(game_lib:get_table(Src, 'mailbox'), RoleUid, {[], []},
        fun(_, {Mails, SystemMailUids}) ->
            case del_mails_(Mails, NewMailUids, []) of
                {NMails, [_ | _] = DelMails} ->
                    {ok, {ok, DelMails}, {NMails, SystemMailUids}};
                _ ->
                    throw("del_mail_error")
            end
        end, []).

%% ----------------------------------------------------
%% @doc
%%        发邮件
%% @end
%% ----------------------------------------------------
-spec send(atom(), integer(), mail:mail()) -> 'ok'.
send(Src, RoleUid, Mail) when is_integer(RoleUid) ->%%给单个人发送邮件
    %%为邮件创建唯一ID
    MailUid = uid_lib:create_mail_uid(Src),
    %%最终邮件
    NewMail = mail:set_uid(Mail, MailUid),
    {_NMails, DeleteMails} = z_db_lib:update(game_lib:get_table(Src, 'mailbox'), RoleUid, {[], []},
        fun(_, {Mails, SystemMailUids}) ->
            NMails1 = [NewMail | Mails],
            {SysMaxNum, CorpsMaxNum} = mail_lib:get_collate_mail_num(Src, RoleUid),
            %%先清理过期且没有附件的
            {NMails, DeleteMails} = mail_lib:collate_timeout(NMails1, SysMaxNum, CorpsMaxNum),
            {ok, {NMails, DeleteMails}, {NMails, SystemMailUids}}
        end, []),
    set_front_lib:send_mail(Src, RoleUid, Mail),
    zm_event:notify(Src, 'bi_mail_send', [{'role_uid', RoleUid}, {'mail', NewMail}]),
    case DeleteMails of
        [_ | _] ->
            zm_event:notify(Src, 'bi_del_mails', [{'role_uid', RoleUid}, {'delete_mails', DeleteMails}]);
        _ ->
            ok
    end,
    ok.


%% ----------------------------------------------------
%% @doc
%%        发系统邮件，同一封邮件，只替换系统邮件本身
%% @end
%% ----------------------------------------------------
-spec send_system_mail(atom(), system_mail:system_mail()) -> 'ok'.
send_system_mail(Src, SysMail) ->
    TableName = game_lib:get_table(Src),
    Uid = system_mail:get_uid(SysMail),
    Mail = system_mail:get_mail(SysMail),
    Title = mail:get_title(Mail),
    Content = mail:get_content(Mail),
    {NSysMail, TableKeys} =
        case is_tuple(Title) of
            true ->
                TableKeys1 = z_db_lib:transformation_tablekey(TableName, [
                    {'system_mail_uids', 'system_mail_uids', []},
                    {'system_mail', Uid, 'none'}]),
                {SysMail, TableKeys1};
            false ->
                NMail = mail:set_content(mail:set_title(Mail, Uid), Uid),
                NSysMail1 = system_mail:set_mail(SysMail, NMail),
                TableKeys1 = z_db_lib:transformation_tablekey(TableName, [
                    {'system_mail_uids', 'system_mail_uids', []},
                    {'system_mail', Uid, 'none'},
                    {'sys_content', mail_lib:get_sys_title_key(Uid)},
                    {'sys_content', mail_lib:get_sys_content_key(Uid)}]),
                {NSysMail1, TableKeys1}
        end,
    case z_db_lib:handle(TableName, fun send_system_mail_/2, {Uid, NSysMail, Title, Content}, TableKeys) of
        ok ->
            %%通知前端有新邮件
            Con = system_mail:get_condition(NSysMail),
            %检测是否为预先发送的系统邮件
            StartTime = z_lib:get_value(Con, 'start_time', 0),%开始收取时间
            Now = time_lib:now_second(),
            if
                Now >= StartTime ->
                    set_front_lib:send_mail(Src, Con, NSysMail);
                true ->
                    add_advance_sysmail(Src, Uid, StartTime)
            end,
            'ok';
        _ ->
            'ok'
    end.

%% ----------------------------------------------------
%% @doc
%%        删除指定系统邮件
%% @end
%% ----------------------------------------------------
-spec delete_system_mail(atom(), [integer()]) -> 'ok'.
delete_system_mail(Src, MailUids) ->
    z_db_lib:update(game_lib:get_table(Src, 'system_mail_uids'), 'system_mail_uids', [], fun(_, Uids) ->
        {ok, ok, Uids--MailUids} end, []),
    TableName = game_lib:get_table(Src, 'system_mail'),
%%    SysContentTableName = game_lib:get_table(Src, 'sys_content'),
    Now = time_lib:now_second(),
    lists:foreach(fun(MailUid) ->
        case z_db_lib:delete1(TableName, MailUid) of
            'ok' ->
                'ok';
            SysMail ->
                Con = system_mail:get_condition(SysMail),
                %检测是否为预先发送的系统邮件
                StartTime = z_lib:get_value(Con, 'start_time', 0),%开始收取时间
                if
                    Now < StartTime ->
                        del_advance_sysmail(Src, MailUid, StartTime);
                    true ->
                        'ok'
                end
            %%TODO 邮件标题,内容不清理(因为玩家有可能过期了也未清理系统邮件,导致玩家看到邮件为null)
%%        case is_tuple(mail:get_title(system_mail:get_mail(SysMail))) of
%%            false ->
%%                    catch z_db_lib:delete(SysContentTableName, mail_lib:get_sys_title_key(MailUid)),
%%                    catch z_db_lib:delete(SysContentTableName, mail_lib:get_sys_content_key(MailUid));
%%            true ->
%%                ok
%%        end
        end
    end, MailUids),
    ok.

%% ----------------------------------------------------
%% @doc
%%        获得可添加系统邮件
%% @end
%% ----------------------------------------------------
-spec get_add_sysmail1(atom(), integer(), integer(), [integer()]) -> {[mail:mail()], [integer()], [integer()]}.
get_add_sysmail1(Src, RoleUid, BiPlatformId, SysMUids) ->
    SystemMailUids = z_db_lib:get(game_lib:get_table(Src, 'system_mail_uids'), 'system_mail_uids', []),
    AddSystemMailUids = SystemMailUids--SysMUids,
    NewSysMUids = SysMUids -- (SysMUids -- SystemMailUids),%将已经清除的sysuid去掉
    if
        AddSystemMailUids =:= [] ->
            {[], NewSysMUids, []};
        true ->
            Table = game_lib:get_table(Src, 'system_mail'),
            {AddMails, AddSMailUids} =
                z_lib:foreach(fun({Acc, NNSysUids}, Uid) ->
                    case z_db_lib:get(Table, Uid, 'none') of
                        'none' ->
                            {Acc, NNSysUids};
                        SysMail -> %%系统邮件
                            case mail_lib:get_sysmail(Src, RoleUid, BiPlatformId, SysMail) of
                                'none' ->
                                    {Acc, NNSysUids};
                                SM ->
                                    {[SM | Acc], [Uid | NNSysUids]}
                            end
                    end
                end, {[], []}, AddSystemMailUids),
            NSystemMailUids = AddSMailUids ++ NewSysMUids,
            {AddMails, NSystemMailUids, AddSMailUids}
    end.

%% ----------------------------------------------------
%% @doc
%%        获得可添加系统邮件
%% @end
%% ----------------------------------------------------
-spec get_all_sysmail(atom()) -> [system_mail:system_mail()].
get_all_sysmail(Src) ->
    Uids = z_db_lib:get(game_lib:get_table(Src, 'system_mail_uids'), 'system_mail_uids', []),
    reads_sysmails(Src, Uids).

%% ----------------------------------------------------
%% @doc
%%        获得指定uid的系统邮件
%% @end
%% ----------------------------------------------------
-spec reads_sysmails(atom(), [integer()]) -> [system_mail:system_mail()].
reads_sysmails(_, []) ->
    [];
reads_sysmails(Src, Uids) ->
    Table = game_lib:get_table(Src, 'system_mail'),
    Reply = z_db_lib:gets(Table, Uids),
    [R || R <- Reply, R =/= 'none'].

%%%=======================LOC FUNCTIONS=================
% ----------------------------------------------------
%% @doc
%%        获取指定数量邮件(合并系统邮件)
%% @end
%% ----------------------------------------------------
-spec get_mails_(tuple(), list()) -> tuple().
get_mails_({Src, RoleUid, AddMails, NSystemMailUids, AddSystemMailUids, CorpsAddMails}, [{Index1, {Mails, SystemMailUids}}]) ->
%%    NMails1 = AddMails ++ Mails,
    NAddMails1 =
        case AddSystemMailUids--SystemMailUids =:= AddSystemMailUids of
            true ->
                AddMails ++ CorpsAddMails;
            false ->
                CorpsAddMails
        end,
    STimeIndex = mail:get_stime_index(),
    Fun = fun(E1, E2) -> element(STimeIndex, E1) > element(STimeIndex, E2) end,
    NAddMails = lists:sort(Fun, NAddMails1),
    NMails1 = insert_key_sort_list(NAddMails, mail:get_stime_index(), Mails),
    {SysMaxNum, CorpsMaxNum} = mail_lib:get_collate_mail_num(Src, RoleUid),
    %%先清理过期且没有附件的
    {NMails, DeleteMails} = mail_lib:collate_timeout(NMails1, SysMaxNum, CorpsMaxNum),
    {ok, {NMails, DeleteMails}, [{Index1, {NMails, NSystemMailUids}}]}.

%% ----------------------------------------------------
%% @doc
%%        删除指定邮件
%% @end
%% ----------------------------------------------------
-spec del_mails_([mail:mail()], [integer()], [mail:mail()]) -> {[mail:mail()], [mail:mail()]}.
del_mails_(Mails, [MailUid | T], R1) ->
    case lists:keytake(MailUid, 2, Mails) of
        false ->
            del_mails_(Mails, T, R1);
        {'value', Mail, NMails} ->
            case mail_lib:check_annex(Mail) of
                1 ->
                    del_mails_(Mails, T, R1);
                _ ->
                    del_mails_(NMails, T, [Mail | R1])
            end
    end;
del_mails_(Mails, [], R1) ->
    {Mails, R1}.

% ----------------------------------------------------
%% @doc
%%       发系统邮件
%% @end
%% ----------------------------------------------------
-spec send_system_mail_(Args, TableKeys) -> {'ok', 'ok'} | {'ok', 'ok', list()} when
    Args :: tuple(),
    TableKeys :: list().
send_system_mail_({SystemMailUid, SysMail, Title, Content}, [{Index1, SystemMailUids}, {Index2, 'none'}, {Index3, _}, {Index4, _}]) ->
    {ok, ok, [{Index1, [SystemMailUid | SystemMailUids]}, {Index2, SysMail}, {Index3, Title}, {Index4, Content}]};
send_system_mail_({SystemMailUid, SysMail, _Title, _Content}, [{Index1, SystemMailUids}, {Index2, 'none'}]) ->
    {ok, ok, [{Index1, [SystemMailUid | SystemMailUids]}, {Index2, SysMail}]};
send_system_mail_(_, _) ->
    {ok, ok}.


%% ----------------------------------------------------
%% @doc
%%      预发送邮件
%% @end
%% ----------------------------------------------------
add_advance_sysmail(Src, Uid, STime) ->
    z_db_lib:update(game_lib:get_table(Src, 'system_mail_advance'), {STime, Uid}, 0).

%% ----------------------------------------------------
%% @doc
%%      删除 预发送邮件
%% @end
%% ----------------------------------------------------
del_advance_sysmail(Src, Uid, STime) ->
    z_db_lib:delete(game_lib:get_table(Src, 'system_mail_advance'), {STime, Uid}).


%%-------------------------------------------------------------------
%% @doc
%%      两个排序好的列表合并
%% @end
%%-------------------------------------------------------------------
-spec insert_key_sort_list(list(), integer(), list()) -> list().
insert_key_sort_list(SortList1, Index, SortList2) ->
    insert_key_sort_list_1(SortList1, Index, SortList2, []).

insert_key_sort_list_1([Elem1 | TSortList1] = SortList1, Index, [Elem2 | TSortList2] = SortList2, Acc) ->
    case element(Index, Elem1) > element(Index, Elem2) of
        true ->
            insert_key_sort_list_1(TSortList1, Index, SortList2, [Elem1 | Acc]);
        false ->
            insert_key_sort_list_1(SortList1, Index, TSortList2, [Elem2 | Acc])
    end;
insert_key_sort_list_1([], _Index, SortList2, Acc) ->
    lists:reverse(Acc) ++ SortList2;
insert_key_sort_list_1(SortList1, _Index, [], Acc) ->
    lists:reverse(Acc) ++ SortList1.




clear_role_award_mail(Src, RoleUidList, SysUid, AwardList) ->
    TableName = game_lib:get_table(Src, 'mailbox'),
    z_lib:foreach(fun(R, {RoleUid, Count}) ->
        {Mails, SysUidList} = z_db_lib:get(TableName, RoleUid, {[], []}),
        {NMails, _Count} = z_lib:foreach(fun({Acc, N}, Mail) ->
            case mail:get_annex(Mail) =:= AwardList of
                true ->
                    case mail:get_state(Mail) =:= 2 of
                        true ->
                            {Acc, N + 1};
                        false ->
                            {Acc, N}
                    end;
                false ->
                    {ok, {[Mail | Acc], N}}
            end
        end, {[], 0}, Mails),
        NSysUidList = lists:delete(SysUid, SysUidList),
        z_db_lib:update(TableName, RoleUid, {lists:reverse(NMails), NSysUidList}),
        case Count > 0 of
            true ->
                Consumes = lists:map(fun({_, {Sid, Num}}) ->
                    {Sid, Num}
                end, awarder_game:award_multiple(AwardList, Count)),
                {ok, BiCs} = z_db_lib:update(game_lib:get_table(Src, 'goods'), RoleUid, {}, fun(_, GoodsStorage) ->
                    {Bi, NGoodsStorage} = storage_lib:deduct_by_sid(GoodsStorage, Consumes),
                    {ok, {ok, Bi}, NGoodsStorage}
                end, []),
                zm_event:notify(Src, 'bi_gm_storage', [{'role_uid', RoleUid}, {'consume', BiCs}]),
                {ok, [{RoleUid, Count, BiCs} | R]};
            false ->
                {ok, R}
        end
    end, [], RoleUidList).


get_complete_system_mail(Src) ->
    MailBoxTableName = game_lib:get_table(Src, 'mailbox'),
    TableName = game_lib:get_table(Src, 'system_mail'),
    Fun = fun(_, SysMailUid, _, Acc) ->
        SysMail = z_db_lib:get(TableName, SysMailUid, 'none'),
        case SysMail =/= 'none' of
            true ->
                case lists:keyfind('member_uid', 1, system_mail:get_condition(SysMail)) of
                    false ->
                        {ok, Acc};
                    {_, RUids} ->
                        Source = element(3, system_mail:get_mail(SysMail)),
                        CUid =
                            case string:tokens(Source, "(") of
                                [RName | _] ->
                                    case z_db_lib:get(game_lib:get_table(Src, 'role_name'), RName, 'none') of
                                        'none' ->
                                            0;
                                        Uid ->
                                            RShow = role_db:get_role_show(Src, Uid),
                                            case RShow =:= 'none' of
                                                true ->
                                                    0;
                                                false ->
                                                    role_show:get_corps_uid(RShow)
                                            end
                                    end;
                                _ ->
                                    0
                            end,
                        case lists:all(fun(RUid) ->
                            {_, YetUids} = z_db_lib:get(MailBoxTableName, RUid, {[], []}),
                            case lists:member(SysMailUid, YetUids) of
                                false ->
                                    CUid =/= 0 andalso role_show:get_corps_uid(role_db:get_role_show(Src, RUid)) =/= CUid;
                                true ->
                                    true
                            end
                        end, RUids) of
                            true ->
%%                                z_db_lib:delete(TableName, SysMailUid),
                                {ok, [SysMailUid | Acc]};
                            false ->
                                {ok, Acc}
                        end
                end;
            false ->
                {ok, Acc}
        end
    end,
    z_db_lib:table_iterate(Src, TableName, Fun, [], []).