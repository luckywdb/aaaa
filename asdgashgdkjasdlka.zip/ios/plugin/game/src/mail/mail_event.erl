%%邮件事件
-module(mail_event).

%%%=======================STATEMENT====================
-description("mail_event").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    clean_sysmail/3,
    advance_sysmail/3
]).

%%%=======================INCLUDE======================
-include("../../../include/sign_key.hrl").

%%%=======================RECORD=======================

%%%=======================DEFINE=======================


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%        清理系统邮件定时器
%% @end
%% ----------------------------------------------------
clean_sysmail(Src, _Args, _Time) ->
    Bl = zm_load:server_start_ok() =:= ?KEY,
    if
        Bl ->
            Time = time_lib:now_second() - 86400, %%1天内过期的不清理
            SystemMailUidsTable = game_lib:get_table(Src, 'system_mail_uids'),
            SystemMailUids = z_db_lib:get(SystemMailUidsTable, 'system_mail_uids', []),
            SystemMailTable = game_lib:get_table(Src, 'system_mail'),
            DeleteSystemMailUids = lists:filter(fun(SystemMailUid) ->
                case z_db_lib:get(SystemMailTable, SystemMailUid, 'none') of
                    'none' ->
                        true;
                    SysMail ->
                        CTime = system_mail:get_clean_time(SysMail),
                        CTime =/= 0 andalso Time >= CTime
                end
            end, SystemMailUids),
            if
                DeleteSystemMailUids =/= [] ->
                    mail_db:delete_system_mail(Src, DeleteSystemMailUids),
                    zm_log:info(Src, ?MODULE, 'clean_sysmail', "clean_sysmail", [{'delete_sysmail_uids', DeleteSystemMailUids}]),
                    'ok';
                true ->
                    ok
            end;
        true ->
            ok
    end.

%% ----------------------------------------------------
%% @doc
%%        通知在线玩家,有定时发送的邮件收到
%% @end
%% ----------------------------------------------------
advance_sysmail(Src, _Args, _Time) ->
    Bl = zm_load:server_start_ok() =:= ?KEY,
    if
        Bl ->
            Now = time_lib:now_second(),
            Table = game_lib:get_table(Src, 'system_mail_advance'),
            Fun = fun(_, {Sec, SysUid} = Key, _, _R) ->
                if
                    Now >= Sec ->
                        case z_db_lib:get(game_lib:get_table(Src, 'system_mail'), SysUid, 'none') of
                            'none' ->
                                'ok';
                            SysMial ->
                                Con = system_mail:get_condition(SysMial),
                                set_front_lib:send_mail(Src, Con, SysMial)
                        end,
                        z_db_lib:delete(Table, Key),
                        {'ok', 'ok'};
                    true ->
                        {'break', 'ok'}
                end
            end,
            z_db_lib:table_iterate(Src, Table, Fun, [], [], 'ascending');
        true ->
            ok
    end.

%%%===================LOCAL FUNCTIONS==================