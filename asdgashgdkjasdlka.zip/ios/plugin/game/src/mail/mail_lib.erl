-module(mail_lib).

-description("邮件工具模块").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([collate_timeout/3, format_mails/2, check_annex/1, get_sysmail/4, sysmail_condition/4,
    get_sys_content_key/1, get_sys_title_key/1, get_collate_mail_num/2, check_string_content/2, check_string_title/2]).
-export([format_title/2, format_content/2, assemble_title/2, assemble_content/2, change_mail_etime/2]).
%%%=======================INCLUDE======================
-include("../include/mail.hrl").

%%%=======================RECORD=======================
%%%=======================DEFINE=======================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%        检查标题是否合法
%% @end
%% ----------------------------------------------------
-spec check_string_title(atom(), string()) -> {'ok', string()} | string().
check_string_title(Src, Title) ->
    NTitle = string:strip(unicode:characters_to_list(Title, 'utf8')),
    Size = string_lib:compute_size(NTitle),
    if
        Size =:= 0 orelse Size > 20 ->
            "mail_title_len_error";
        true ->
            case string_lib:check_str(Src, NTitle) of
                false ->
                    {ok, NTitle};
                _ ->
                    "have_mask_word"
            end
    end.
%% ----------------------------------------------------
%% @doc
%%        检查内容是否合法
%% @end
%% ----------------------------------------------------
-spec check_string_content(atom(), string()) -> {'ok', string()} | string().
check_string_content(Src, Content) ->
    NContent = string:strip(unicode:characters_to_list(Content, 'utf8')),
    Size = string_lib:compute_size(NContent),
    if
        Size =:= 0 orelse Size > 600 ->
            "mail_content_len_error";
        true ->
            case string_lib:check_str(Src, NContent) of
                false ->
                    {ok, NContent};
                _ ->
                    "have_mask_word"
            end
    end.


%% ----------------------------------------------------
%% @doc
%%        格式化前台邮件标题(系统gm邮件标题单独存放的)
%% @end
%% ----------------------------------------------------
-spec format_title(atom(), integer()|tuple()) -> tuple().
format_title(Src, Title) when is_integer(Title) ->
    {0, z_db_lib:get(game_lib:get_table(Src, 'sys_content'), mail_lib:get_sys_title_key(Title), "null")};
format_title(_Src, Title) ->
    Title.

%% ----------------------------------------------------
%% @doc
%%        格式化前台邮件内容(系统gm邮件内容单独存放的)
%% @end
%% ----------------------------------------------------
-spec format_content(atom(), integer()|tuple()) -> tuple().
format_content(Src, Content) when is_integer(Content) ->
    {0, z_db_lib:get(game_lib:get_table(Src, 'sys_content'), mail_lib:get_sys_content_key(Content), "null")};
format_content(_Src, Content) ->
    Content.

%% ----------------------------------------------------
%% @doc
%%        拼装邮件标题,邮件从language中取配置时，统一在这里添加mail的头，在外部只需要单独写相应的数字
%% @end
%% ----------------------------------------------------
-spec assemble_title(atom(), integer()|tuple()) -> string().
assemble_title(Src, Title) when is_integer(Title) ->
    z_db_lib:get(game_lib:get_table(Src, 'sys_content'), mail_lib:get_sys_title_key(Title), "null");
assemble_title(_Src, {0, Title}) ->
    Title;
assemble_title(_Src, Title) ->
    [H | T] = tuple_to_list(Title),
    game_lib:get_language({'mail_title', H}, T).

%% ----------------------------------------------------
%% @doc
%%        拼装邮件内容,邮件从language中取配置时，统一在这里添加mail的头，在外部只需要单独写相应的数字
%% @end
%% ----------------------------------------------------
-spec assemble_content(atom(), integer()|tuple()) -> string().
assemble_content(Src, Content) when is_integer(Content) ->
    z_db_lib:get(game_lib:get_table(Src, 'sys_content'), mail_lib:get_sys_content_key(Content), "null");
assemble_content(_, {0, Content}) ->
    Content;
assemble_content(_Src, Content) ->
    [H | T] = tuple_to_list(Content),
    game_lib:get_language({'mail_content', H}, T).

%% ----------------------------------------------------
%% @doc
%%        获得整理邮件的长度(长度随离线时间减少)
%% @end
%% ----------------------------------------------------
-spec get_collate_mail_num(Src, RoleUid) -> {integer(), integer()} when
    Src :: atom(),
    RoleUid :: integer().
get_collate_mail_num(Src, RoleUid) ->
    GUser = user_db:get_user(Src, RoleUid),
    LoginOutTime = guser:get_logout_time(GUser),
    LoginTime = guser:get_login_time(GUser),
    NowTime = time_lib:now_second(),
    if
        LoginOutTime =:= 0 orelse LoginOutTime + ?LOGIN_OUT_TIME_ALIVE > NowTime orelse LoginTime > LoginOutTime ->   %% 活跃
            {?MAIL_COLLATE_NOR_ACTIVE_SYS_MAX, ?MAIL_COLLATE_NOR_ACTIVE_CORPS_MAX};
        LoginOutTime + ?LOGIN_OUT_TIME > NowTime ->     %% 一般
            {?MAIL_MAX_SYS, ?MAIL_MAX_CORPS};
        true -> %流失玩家
            {?LOGIN_OUT_MAIL_MAX_SYS, ?LOGIN_OUT_MAIL_MAX_CORPS}
    end.

%% ----------------------------------------------------
%% @doc
%%        获得系统邮件标题键值
%% @end
%% ----------------------------------------------------
-spec get_sys_title_key(integer()) -> {'title', integer()}.
get_sys_title_key(SysMailUid) ->
    {'title', SysMailUid}.

%% ----------------------------------------------------
%% @doc
%%        获得系统邮件内容键值
%% @end
%% ----------------------------------------------------
-spec get_sys_content_key(integer()) -> {'content', integer()}.
get_sys_content_key(SysMailUid) ->
    {'content', SysMailUid}.

%% ----------------------------------------------------
%% @doc
%%        邮件整理,清楚过期邮件，策略清除邮件
%% @end
%% ----------------------------------------------------
-spec collate_timeout(Mails, SysMaxNum, CorpsMaxNum) -> {SysMails, SysMailNum, CorpsMails, CorpsMailNum, DeleteMails} when
    Mails :: [mail:mail()],
    SysMaxNum :: integer(),%%系统邮件最大数
    CorpsMaxNum :: integer(),%%军团邮件最大数
    SysMails :: [mail:mail()],%%系统邮件
    SysMailNum :: integer(),%%系统邮件数量
    CorpsMails :: [mail:mail()],%%军团邮件
    CorpsMailNum :: integer(),%%军团邮件数量
    DeleteMails :: [mail:mail()].%%删除的邮件
collate_timeout(Mails, SysMaxNum, CorpsMaxNum) ->
    CorpsMailType = award_source:get_source("corps"),
    {SysMailList, SysMailNum, CorpsMailList, CorpsMailNum, DeleteMails1} =
        collate_timeout(time_lib:now_second(), Mails, CorpsMailType, [], 0, [], 0, [], false),
    {NSysMailList, DeleteMails2} = collate_max(SysMailList, max(0, SysMailNum - SysMaxNum), [], DeleteMails1),
    {NCorpsMailList, DeleteMails} = collate_max(CorpsMailList, max(0, CorpsMailNum - CorpsMaxNum), [], DeleteMails2),

    {NSysMailList ++ NCorpsMailList, DeleteMails}.

%% ----------------------------------------------------
%% @doc
%%        向前台信息将邮件固定格式（不给邮件内容，附件给标示）
%% @end
%% ----------------------------------------------------
-spec format_mails(Src, Mails) -> tuple() when
    Src :: atom(),
    Mails :: mail:mail() | [mail:mail()].
format_mails(Src, Mails) when is_list(Mails) ->
    F = fun(M) ->
%%        {mail:get_uid(M), mail:get_src(M), mail:get_type(M), format_title(Src, mail:get_title(M)), {0, ""}, mail:get_state(M), 0,
%%            mail:get_stime(M), mail:get_etime(M), check_annex(M)}
        {mail:get_uid(M), mail:get_src(M), mail:get_type(M), mail:content_to_title(Src, mail:get_content(M)), {0, ""}, mail:get_state(M), 0,
            mail:get_stime(M), mail:get_etime(M), check_annex(M)}
    end,
    list_to_tuple(lists:map(F, Mails));
format_mails(Src, Mail) ->
    format_mails(Src, [Mail]).

%% ----------------------------------------------------
%% @doc
%%        邮件是否还有附件未领取
%% @end
%% ----------------------------------------------------
-spec check_annex(Mail) -> Annex when
    Mail :: mail:mail(),
    Annex :: 0|1|2. %%无附件0|有附件1|2已领取
check_annex(Mail) ->
    case mail:get_annex(Mail) of
        [] ->
            0;
        _ ->
            case mail:get_state(Mail) of
                ?TAKE ->
                    2;
                _ ->
                    1
            end
    end.
%% ----------------------------------------------------
%% @doc
%%        获得系统邮件，会检查是否可领取
%% @end
%% ----------------------------------------------------
-spec get_sysmail(atom(), integer(), integer(), system_mail:system_mail()) -> 'none' | mail:mail().
get_sysmail(Src, RoleUid, BiPlatFormId, SysMail) ->
    case sysmail_condition(Src, RoleUid, BiPlatFormId,
        [{clean_time, system_mail:get_clean_time(SysMail)} | system_mail:get_condition(SysMail)]) of
        true -> %%初始化系统邮件
            Mail1 = system_mail:get_mail(SysMail),
            Update = system_mail:get_update(SysMail),
            %%TODO uid前台排序问题,会导致mail的bi导入冲突
            MailUid = uid_lib:create_mail_uid(Src),
            Mail2 = mail:set_uid(Mail1, MailUid),%%最终邮件
%%            Mail2 =
%%                case mail:get_uid(Mail1) =:= 0 of
%%                    true ->
%%                        MailUid = uid_lib:create_mail_uid(Src),
%%                        mail:set_uid(Mail1, MailUid);
%%                    false ->
%%                        Mail1
%%                end,
            mail_update(Src, RoleUid, Mail2, Update);
        _ ->
            'none'
    end.


%% ----------------------------------------------------
%% @doc
%%        系统邮件检查条件
%% @end
%% ----------------------------------------------------
-spec sysmail_condition(atom(), integer(), integer(), list()) -> boolean().
sysmail_condition(_, _, _, []) ->
    true;
sysmail_condition(Src, RoleUid, BiPlatformId, [H | T]) ->
    case sysmail_condition_(Src, RoleUid, BiPlatformId, H) of
        true ->
            sysmail_condition(Src, RoleUid, BiPlatformId, T);
        _ ->
            false
    end.


%% ----------------------------------------------------
%% @doc
%%        读取和领取附件时修改过期时间
%% @end
%% ----------------------------------------------------
-spec change_mail_etime('read' | 'take', mail:mail()) -> mail:mail().
change_mail_etime('read', Mail) ->
    Annex = mail:get_annex(Mail),
    if
        Annex =:= [] ->
            Type = mail:get_type(Mail),
            CorpsMailType = award_source:get_source("corps"),
            if
                Type =:= CorpsMailType ->
                    ETime = min(mail:get_etime(Mail), time_lib:now_second() + ?MAIL_TIMEOUT_TIME_2),
                    mail:set_etime(Mail, ETime);
                true ->
                    ETime = min(mail:get_etime(Mail), time_lib:now_second() + ?MAIL_TIMEOUT_TIME_1),
                    mail:set_etime(Mail, ETime)
            end;
        true ->
            ETime = min(mail:get_etime(Mail), time_lib:now_second() + ?MAIL_TIMEOUT_TIME_2),
            mail:set_etime(Mail, ETime)
    end;
change_mail_etime('take', Mail) ->
    ETime = min(mail:get_etime(Mail), time_lib:now_second() + ?MAIL_TIMEOUT_TIME_2),
    mail:set_etime(Mail, ETime).


%%%=======================LOC FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%        系统邮件检查条件
%% @end
%% ----------------------------------------------------
-spec sysmail_condition_(atom(), integer(), integer(), tuple()) -> boolean().
sysmail_condition_(_, _, _, {start_time, Time}) ->%%可收取开始时间
    time_lib:now_second() >= Time;
sysmail_condition_(_, _, _, {end_time, Time}) ->%%可收取截止时间
    Time =:= 0 orelse time_lib:now_second() =< Time;
sysmail_condition_(_, _, BiPlatformId, {bi_platform_id, List}) ->%%可收取平台
    lists:member(BiPlatformId, List);
sysmail_condition_(_, RoleUid, _, {member_uid, Members}) ->%%指定uid收取
    lists:member(RoleUid, Members);
sysmail_condition_(_, _, _, {clean_time, Time}) ->%%清理时间
    Time =:= 0 orelse time_lib:now_second() =< Time;
sysmail_condition_(Src, RoleUid, _, {create_time, Time}) ->%%在create_time之后创建的角色可收取
    case z_db_lib:get(game_lib:get_table(Src, 'user'), RoleUid, none) of
        none ->
            false;
        User ->
            guser:get_create_time(User) >= Time
    end;
sysmail_condition_(Src, RoleUid, _, {before_create_time, Time}) ->%%在before_create_time之 前 创建的角色可收取
    case z_db_lib:get(game_lib:get_table(Src, 'user'), RoleUid, none) of
        none ->
            false;
        User ->
            guser:get_create_time(User) < Time
    end;
sysmail_condition_(Src, RoleUid, _, {pid_sid, List}) ->%%服务器检查
    case z_db_lib:get(game_lib:get_table(Src, 'uid_psu'), RoleUid, none) of
        {P, S, _} ->
            lists:member({P, S}, List);
        _ ->
            false
    end;
sysmail_condition_(Src, RoleUid, _, {puid, List}) ->%%检查账号ID
    case z_db_lib:get(game_lib:get_table(Src, 'uid_psu'), RoleUid, none) of
        {_, _, U} ->
            lists:member(U, List);
        _ ->
            false
    end;
sysmail_condition_(Src, RoleUid, _, {'country', Country}) ->
    RoleShow = role_db:get_role_show(Src, RoleUid),
    role_show:get_country(RoleShow) =:= Country;
sysmail_condition_(_, _, _, _) -> %%其他情况不可领取
    false.

%% ----------------------------------------------------
%% @doc
%%        根据条件改变Mail
%% @end
%% ----------------------------------------------------
-spec mail_update(atom(), integer(), mail:mail(), list()) -> mail:mail().
mail_update(_, _, Mail, []) ->
    Mail;
mail_update(Src, RoleUid, Mail, [{valid_time, Time} | T]) ->
    NowTime = time_lib:now_second(),
    NMail = mail:set_etime(mail:set_stime(Mail, NowTime), NowTime + Time),
    mail_update(Src, RoleUid, NMail, T);
mail_update(Src, RoleUid, Mail, [_ | T]) ->
    mail_update(Src, RoleUid, Mail, T).

%% ----------------------------------------------------
%% @doc
%%        邮件整理,清楚过期邮件，策略清除邮件 (返回的邮件列表是反序的)
%% @end
%% ----------------------------------------------------
-spec collate_timeout(integer(), [mail:mail()], integer(), [mail:mail()], integer(), [mail:mail()], integer(), [mail:mail()], boolean()) ->
    {[mail:mail()], integer(), [mail:mail()], integer(), [mail:mail()]}.
collate_timeout(NowTime, [Mail | T], CorpsMailType, SysMailAcc, SysMailNum, CorpsMailAcc, CorpsMailNum, Deletes, DelAnnexFlag) ->
    EndTime = mail:get_etime(Mail),
    case NowTime >= EndTime andalso (DelAnnexFlag orelse check_annex(Mail) =/= 1) of %过期整理
        true ->
            collate_timeout(NowTime, T, CorpsMailType, SysMailAcc, SysMailNum, CorpsMailAcc, CorpsMailNum, [Mail | Deletes], DelAnnexFlag);
        false ->
            case mail:get_type(Mail) =:= CorpsMailType of
                true ->
                    collate_timeout(NowTime, T, CorpsMailType, SysMailAcc, SysMailNum, [Mail | CorpsMailAcc], CorpsMailNum + 1, Deletes, DelAnnexFlag);
                false ->
                    collate_timeout(NowTime, T, CorpsMailType, [Mail | SysMailAcc], SysMailNum + 1, CorpsMailAcc, CorpsMailNum, Deletes, DelAnnexFlag)
            end
    end;
collate_timeout(_, _, _, SysMailAcc, SysMailNum, CorpsMailAcc, CorpsMailNum, Deletes, _) ->
    {SysMailAcc, SysMailNum, CorpsMailAcc, CorpsMailNum, Deletes}.


collate_max([Mail | T], CollateNum, Saves, Deletes) when CollateNum > 0 ->
    case check_annex(Mail) =/= 1 of
        true ->
            collate_max(T, CollateNum - 1, Saves, [Mail | Deletes]);
        false ->
            collate_max(T, CollateNum, [Mail | Saves], Deletes)
    end;
collate_max([], CollateNum, Saves, Deletes) when CollateNum > 0 ->
    Len = length(Saves),
    {NSaves, AddDeletes} = lists:split(Len - CollateNum, Saves),
    {NSaves, AddDeletes ++ Deletes};
collate_max(Mails, _, Saves, Deletes) ->
    {lists:reverse(Mails, Saves), Deletes}.