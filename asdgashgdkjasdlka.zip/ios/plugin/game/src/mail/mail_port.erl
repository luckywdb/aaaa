-module(mail_port).

-description("邮件通讯模块").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_mails/5, get_mails_state/5, read/5, take/5, del_mails/5, set_flag/5, mark_reads/5, send_mail/5]).

%%%=======================DEFINE=======================

%%%=======================INCLUDE======================
-include("../include/mail.hrl").

%%%=================EXPORTED FUNCTIONS===================
%% ----------------------------------------------------
%% @doc
%%        获得邮件，每次都会检查系统邮件，频繁获取会有问题
%% @end
%% ----------------------------------------------------
get_mails(_, _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    BiPlatformId = user_db:get_user_platform(Src, RoleUid),
    MaxUid = list_to_integer(z_db_lib:get_value(Msg, "max", "0")),
    Mails = mail_db:get_mails(Src, RoleUid, BiPlatformId),
    if
        MaxUid =:= 0 ->
            {ok, [], Info, [{msg, mail_lib:format_mails(Src, Mails)}]};
        true ->
            Mid = uid_lib:get_id(MaxUid),
            {ok, [], Info, [{msg, mail_lib:format_mails(Src, lists:filter(fun(M) ->
                uid_lib:get_id(mail:get_uid(M)) > Mid end, Mails))}]}
    end.

%% ----------------------------------------------------
%% @doc
%%        得到邮件状态标记，0|1满|2存在未读
%% @end
%% ----------------------------------------------------
get_mails_state(_, _Session, Attr, Info, _) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    BiPlatformId = user_db:get_user_platform(Src, RoleUid),
    {ok, [], Info, [{msg, mail_db:get_mails_state(Src, RoleUid, BiPlatformId)}]}.

%% ----------------------------------------------------
%% @doc
%%        读取邮件
%% @end
%% ----------------------------------------------------
read(_, _Session, Attr, Info, Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    MailUid = list_to_integer(z_lib:get_value(Msg, "uid", "0")),
    if
        MailUid < 1 -> {ok, [], Info, [{msg, "input_error"}]};
        true ->
            case mail_db:read(Src, RoleUid, MailUid) of
                Mail when is_tuple(Mail) ->
                    {ok, [], Info, [{msg, {list_to_tuple(mail:get_annex(Mail)), mail_lib:format_content(Src, mail:get_content(Mail))}}]};
                Err ->
                    {ok, [], Info, [{msg, Err}]}
            end
    end.

%% ----------------------------------------------------
%% @doc
%%        标记读取邮件
%% @end
%% ----------------------------------------------------
mark_reads(_, _Session, Attr, Info, Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    MailUids = [list_to_integer(Uid) || Uid <- string:tokens(z_lib:get_value(Msg, "uids", ""), ",")],
    Reply = mail_db:reads(Src, RoleUid, MailUids),
    {ok, [], Info, [{msg, Reply}]}.


%% ----------------------------------------------------
%% @doc
%%        提取附件,支持一组
%% @end
%% ----------------------------------------------------
take(_, _Session, Attr, Info, Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    MailUids = [list_to_integer(Uid) || Uid <- string:tokens(z_lib:get_value(Msg, "uids", ""), ",")],
    case mail_db:take(Src, RoleUid, MailUids) of
        {Awards, Mails} ->
            AwardLog = awarder_game:give_award(Src, RoleUid, [], Awards),
            zm_log:info(Src, ?MODULE, 'take', "mail_take", [{'roleuid', RoleUid},
                {'mail_uids', MailUids}, {'award', AwardLog}]),
            %% 提取附件事件
            zm_event:notify(Src, 'bi_mail_take', [{'role_uid', RoleUid}, {'uid', MailUids}, {'mail', Mails}, {'award', AwardLog}]),
            Uids = [mail:get_uid(Mail) || Mail <- Mails],
            {ok, [], Info, [{msg, {AwardLog, list_to_tuple(Uids)}}]};
        Oth ->
            {ok, [], Info, [{msg, Oth}]}
    end.

%% ----------------------------------------------------
%% @doc
%%        删除玩家邮件,支持一组,有附件的不能删
%% @end
%% ----------------------------------------------------
del_mails(_, _Session, Attr, Info, Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    MailUids = [list_to_integer(Uid) || Uid <- string:tokens(z_lib:get_value(Msg, "uids", ""), ",")],
    case mail_db:del_mails(Src, RoleUid, MailUids) of
        {ok, DelMails} ->
            %% 删除玩家邮件事件
            zm_event:notify(Src, 'bi_del_mails', [{'role_uid', RoleUid}, {'delete_mails', DelMails}]),
            {ok, [], Info, [{msg, "ok"}]};
        Oth ->
            {ok, [], Info, [{msg, Oth}]}
    end.

%% ----------------------------------------------------
%% @doc
%%        设置是否标记
%% @end
%% ----------------------------------------------------
set_flag(_, _Session, Attr, Info, Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    Flag = z_lib:get_value(Msg, "flag", 0),
    MailUid = list_to_integer(z_lib:get_value(Msg, "uid", "0")),
    CheckVaild = valid_lib:check_valib([{'unequal', MailUid, 0}, {'range', Flag, {0, 1}}]),
    if
        CheckVaild ->
            Reply = mail_db:set_flag(Src, RoleUid, MailUid, Flag),
            {ok, [], Info, [{msg, Reply}]};
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%        发送邮件
%% @end
%% ----------------------------------------------------
send_mail(_, _Session, Attr, Info, Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    Type = z_lib:get_value(Msg, "type", 0),
    Title = z_lib:get_value(Msg, "title", ""),
    Content = z_lib:get_value(Msg, "content", ""),
    %_RoleUids = [list_to_integer(Uid) || Uid <- string:tokens(z_lib:get_value(Msg, "uids", ""), ",")],
    case mail_lib:check_string_title(Src, Title) of
        {ok, NTitle} ->
            case mail_lib:check_string_content(Src, Content) of
                {ok, NContent} ->
                    Reply =
                        case Type of
                            1 ->%%军团邮件
                                corps_db:send_corps_mail(Src, RoleUid, {0, NTitle}, {0, NContent});
                            _ ->
                                "input_error"
                        end,
                    {ok, [], Info, [{msg, Reply}]};
                Other ->
                    {ok, [], Info, [{msg, Other}]}
            end;
        Other ->
            {ok, [], Info, [{msg, Other}]}
    end.


%%%=================EXPORTED FUNCTIONS===================
