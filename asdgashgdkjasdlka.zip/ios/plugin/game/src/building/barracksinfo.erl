-module(barracksinfo).

%%%=======================STATEMENT====================
-description("兵营招募或伤兵恢复配置").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_cfg/1, get_max_num/1, get_once_num/1, get_once_time/1, get_once_consume/1]).

-export_type([barracksinfo/0]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(barracksinfo, {
    max_num :: integer(),%最大存储兵力/伤兵上限
    once_num :: integer(),%一次可招募/治疗最大兵力
    once_time :: integer(),%招募/治疗10000个兵消耗时间
    once_consume :: tuple()%招募/治疗10000个兵消耗资源,{本服消耗，跨服消耗}
}).

%%%=======================TYPE=========================
-type barracksinfo() :: #barracksinfo{}.


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%     根据等级,获取兵营/伤兵营配置
%% @end
%% ----------------------------------------------------
-spec get_cfg(Key :: {integer(), integer()}) -> barracksinfo().
get_cfg(Key) ->
    element(2, zm_config:get('barracks_info', Key)).

%% ----------------------------------------------------
%% @doc
%%     最大存储兵力/伤兵上限
%% @end
%% ----------------------------------------------------
-spec get_max_num(barracksinfo()) -> integer().
get_max_num(#barracksinfo{max_num = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%     一次可招募/治疗最大兵力
%% @end
%% ----------------------------------------------------
-spec get_once_num(barracksinfo()) -> integer().
get_once_num(#barracksinfo{once_num = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%     招募/治疗10000个兵消耗时间
%% @end
%% ----------------------------------------------------
-spec get_once_time(barracksinfo()) -> integer().
get_once_time(#barracksinfo{once_time = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%     招募/治疗10000个兵消耗资源
%% @end
%% ----------------------------------------------------
-spec get_once_consume(barracksinfo()) -> list().
get_once_consume(#barracksinfo{once_consume = V}) -> V.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
