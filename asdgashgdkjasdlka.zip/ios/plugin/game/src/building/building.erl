-module(building).

%%%=======================STATEMENT====================
-description("建筑").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    get_cfg/1,
    get_sid/1,
    get_type/1,
    get_max_lv/1,
    get_flourish/3,
    get_default_pos/1
]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(building, {
    sid :: integer(),
    type :: integer(),%类型
    name :: string(),
    max_lv :: integer(),%最大等级
    flourish :: tuple(), %每升1级加繁荣度
    default_pos :: integer()%默认位置
}).

%%%=======================TYPE=========================
-type building() :: #building{}.


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%     读取建筑配置
%% @end
%% ----------------------------------------------------
-spec get_cfg(Sid :: integer()) -> 'none'|building().
get_cfg(Sid) ->
    zm_config:get('building', Sid).

%% ----------------------------------------------------
%% @doc
%%     获取建筑sid
%% @end
%% ----------------------------------------------------
-spec get_sid(building()) -> integer().
get_sid(#building{sid = Sid}) -> Sid.

%% ----------------------------------------------------
%% @doc
%%     读取建筑类型
%% @end
%% ----------------------------------------------------
-spec get_type(building()) -> integer().
get_type(#building{type = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%     读取建筑最大等级
%% @end
%% ----------------------------------------------------
-spec get_max_lv(building()) -> integer().
get_max_lv(#building{max_lv = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%     根据当前等级,获取总繁荣度
%% @end
%% ----------------------------------------------------
-spec get_flourish(building(), integer(), integer()) -> integer().
get_flourish(#building{flourish = V}, MinLv, MaxLv) ->
    Size = tuple_size(V),
    F = fun(A, I) ->
        {'ok', A + element(min(Size, I), V)}
    end,
    z_lib:for(F, 0, MinLv, MaxLv + 1).

%% ----------------------------------------------------
%% @doc
%%     默认pos
%% @end
%% ----------------------------------------------------
-spec get_default_pos(building()) -> integer().
get_default_pos(#building{default_pos = V}) -> V.
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
