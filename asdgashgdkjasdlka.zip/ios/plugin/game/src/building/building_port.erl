-module(building_port).

%%%=======================STATEMENT====================
-description("建筑端口").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    up/5,
    up_over/5,
    gain/5,
    study/5,
    study_over/5,
    barracks/5,
    barracks_over/5,
    political/5,
    change_political/5,
    queue_cancel/5,
    mintage/5,
    mintage_over/5,
    buy_tmp_queue/5,
    dispatch/5,
    black_market/5,
    black_market_over/5,
    treasure_house/5,
    treasure_house_over/5
]).
-export([reduce_queue_time/5]).
-export([weapon_create/5, weapon_create_over/5, weapon_queue_cancle/5]).

%%%=======================INCLUDE======================
-include("../include/building.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%     建筑升级(type=0普通升级,=1使用rmb秒资源和cd)
%% @end
%% ----------------------------------------------------
up([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    BSid = list_to_integer(z_lib:get_value(Msg, "building_sid", "0")),
    Type = z_lib:get_value(Msg, "type", 0),
    Pos = z_lib:get_value(Msg, "pos", 0),
    QId = z_lib:get_value(Msg, "qid", 0),
    CheckVaild = valid_lib:check_valib([{'ge', BSid, 1}, {'ge', Pos, 1}, {'ge', QId, 1}, {'range', Type, {0, 1}}]),
    if
        CheckVaild ->
            Now = time_lib:now_second(),
            Study = building_db:get_study(Src, RoleUid),
            BuffList = role_db:get_role_buff(Src, RoleUid),
            ActiveAdd = active_addition:get_active_addition(Src, 'building_up_add'),
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'role', RoleUid}, {'castle', RoleUid},
                {'queue', RoleUid, []}, {'buy_tmp_queue', RoleUid, {0, []}}, {'gain_info', RoleUid, []},
                {'rmb', RoleUid, rmb_lib:init()}]),
            VipFreeTime =
                if
                    Type =:= 1 ->
                        RoleShow = role_db:get_role_show(Src, RoleUid),
                        vip_lib:get_building_queue_free_time(role_show:get_vip_level(RoleShow));
                    true ->
                        0
                end,
            case z_db_lib:handle(TableName, {M, F, A}, {Src, BSid, Type, Now, Study, BuffList, ActiveAdd, Pos, QId, VipFreeTime}, TableKeys) of
                {'ok', AwardList, CS, OldBLv, NewBLv, NeedTime} ->
                    AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, AwardList),
                    %% 记录建筑升级日志信息
                    zm_log:info(Src, ?MODULE, 'up', "building_up", [{'roleuid', RoleUid}, {'award', AwardLog}, {'consume', CS},
                        {'bsid', BSid}, {'pos', Pos}]),
                    %% 建筑事件
                    zm_event:notify(Src, 'building_up', [{'role_uid', RoleUid}, {'award', AwardLog},
                        {'consume', CS}, {'type', Type}, {'build_up', [{BSid, OldBLv, NewBLv}]}, {'sid', BSid}]),
                    case building_lib:get_bsid('main') =:= BSid andalso NewBLv > OldBLv of
                        true ->
                            %大殿排行榜活动
                            zm_event:notify(Src, 'active_event', {'active_castle_rank', [{'role_uid', RoleUid}, {'level', NewBLv}]});
                        false ->
                            'ok'
                    end,
                    {'ok', [], Info, [{'msg', {Now, NeedTime, AwardLog}}]};
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     建筑升级完成(0普通升级,1使用rmb秒cd)
%% @end
%% ----------------------------------------------------
up_over([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    BSid = list_to_integer(z_lib:get_value(Msg, "building_sid", "0")),
    Type = z_lib:get_value(Msg, "type", 0),
    Pos = z_lib:get_value(Msg, "pos", 0),
    CheckVaild = valid_lib:check_valib([{'ge', BSid, 1}, {'ge', Pos, 1}, {'range', Type, {0, 1}}]),
    if
        CheckVaild ->
            RoleShow = role_db:get_role_show(Src, RoleUid),
            QueueFreeTime = vip_lib:get_building_queue_free_time(role_show:get_vip_level(RoleShow)),
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'castle', RoleUid}, {'queue', RoleUid, []}, {'buy_tmp_queue', RoleUid, {0, []}},
                {'gain_info', RoleUid, []}, {'rmb', RoleUid, rmb_lib:init()}]),
            case z_db_lib:handle(TableName, {M, F, A}, {BSid, Type, Pos, QueueFreeTime}, TableKeys) of
                {'ok', AwardList, Cs, NBLv, DecRmb} ->
                    AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, AwardList),
                    %% 记录建筑升级日志信息
                    zm_log:info(Src, ?MODULE, 'up_over', "building_up_over", [{'roleuid', RoleUid}, {'consume', Cs}, {'award', AwardLog},
                        {'bsid', BSid}, {'pos', Pos}]),
                    %% 建筑升级完成事件
                    zm_event:notify(Src, 'building_up_over', [{'role_uid', RoleUid}, {'award', AwardLog},
                        {'consume', Cs}, {'type', Type}, {'build_up', [{BSid, NBLv - 1, NBLv}]}, {'sid', BSid}]),
                    %活动排行榜
                    case building_lib:get_bsid('main') =:= BSid of
                        true ->
                            %大殿排行榜活动
                            zm_event:notify(Src, 'active_event', {'active_castle_rank', [{'role_uid', RoleUid}, {'level', NBLv}]});
                        false ->
                            'ok'
                    end,
                    corps_db:corps_help_queue_over(Src, RoleUid, ?BUILDING, BSid),
                    {'ok', [], Info, [{'msg', {BSid, DecRmb, AwardLog}}]};
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     收取建筑产出资源(民居,采石场,伐木场,铁矿场)
%% @end
%% ----------------------------------------------------
gain(_, _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    BSids = [list_to_integer(Bid) || Bid <- string:tokens(z_lib:get_value(Msg, "building_sid", ""), ",")],
    if
        BSids =/= [] ->
            case building_db:gain(Src, RoleUid, BSids) of
                {'ok', Now, AwardList, AllNum} ->
                    if
                        AwardList =/= [] ->
                            AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, AwardList),
                            %% 记录建筑升级日志信息
                            zm_log:info(Src, ?MODULE, 'gain', "building_gain", [{'roleuid', RoleUid}, {'bsid', BSids}, {'award', AwardLog}]),
                            %% 建筑升级完成事件
                            zm_event:notify(Src, 'bi_building_gain', [{'role_uid', RoleUid}, {'award', AwardLog}]),
                            zm_event:notify(Src, achieve, {RoleUid, {argu, [{building_gain_times, 1}, {'building_gain_number', AllNum}]}}),
                            {'ok', [], Info, [{'msg', {Now, AwardLog}}]};
                        true ->
                            {'ok', [], Info, [{'msg', {Now, {}}}]}
                    end;
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     升级建筑内部信息(科技研究,36计研究,军械等)
%% @end
%% ----------------------------------------------------
study([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    Sid = list_to_integer(z_lib:get_value(Msg, "sid", "0")),
    BSid = list_to_integer(z_lib:get_value(Msg, "building_sid", "0")),%建筑sid
    Type = z_lib:get_value(Msg, "type", 0),
    CheckVaild = valid_lib:check_valib([{'ge', BSid, 1}, {'range', Type, {0, 1}}, {'ge', Sid, 1}]),
    if
        CheckVaild ->
            case zm_config:get('study_info', Sid) of
                'none' ->
                    {'ok', [], Info, [{'msg', "input_error"}]};
                {_, _, BSid} ->
                    Now = time_lib:now_second(),
                    BuffList = role_db:get_role_buff(Src, RoleUid),
                    Castle = castle_db:get_castle(Src, RoleUid),
                    ActiveAdd = active_addition:get_active_addition(Src, {'study_up_add', BSid}),
                    SpeedCardAdd = building_db:get_dispach_card_polity_addper(Src, RoleUid, Castle, BSid),
                    TableName = game_lib:get_table(Src),
                    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'role', RoleUid},
                        {'queue', RoleUid, []}, {'study', RoleUid, []}, {'rmb', RoleUid, rmb_lib:init()}]),
                    VipFreeTime =
                        if
                            Type =:= 1 ->
                                {_, BSidList} = zm_config:get('building_info', 'free_time_bsid_list'),
                                case lists:member(BSid, BSidList) of
                                    true ->
                                        RoleShow = role_db:get_role_show(Src, RoleUid),
                                        vip_lib:get_building_queue_free_time(role_show:get_vip_level(RoleShow));
                                    false ->
                                        0
                                end;
                            true ->
                                0
                        end,
                    case z_db_lib:handle(TableName, {M, F, A}, {Src, Sid, BSid, Type, Now, BuffList, Castle, ActiveAdd, SpeedCardAdd, VipFreeTime}, TableKeys) of
                        {'ok', CS, OLv, NLv, NeedTime} ->%完成研究/立即研究完成
                            %% 记录建筑升级日志信息
                            zm_log:info(Src, ?MODULE, 'study', "building_study", [{'roleuid', RoleUid}, {'bsid', BSid}, {'sid', Sid},
                                {'consume', CS}, {'olv', OLv}, {'nlv', NLv}, {'need_time', NeedTime}]),
                            %% 建筑内部研究事件
                            zm_event:notify(Src, 'bi_building_study', [{'role_uid', RoleUid}, {'consume', CS}, {'type', Type},
                                {'build_up', [{Sid, OLv, NLv}]}, {'sid', Sid}]),
                            case Type > 0 andalso building_lib:get_bsid('science') =:= BSid of
                                true ->
                                    %科技是否影响战斗力
                                    case role_addition:check_study_role_attr(Sid) of
                                        true ->
                                            %% 排行榜信息
                                            GarraySidList = garray_lib:get_garray_ids(Src, RoleUid),
                                            Country = role_lib:get_country(Attr),
                                            zm_event:notify(Src, {'power_change', Country}, [{'uid', RoleUid}, {'gid', GarraySidList}, {'country', Country}]);
                                        false ->
                                            'ok'
                                    end;
                                false ->
                                    ok
                            end,
                            %%采集类活动抛事件
                            if
                                NLv > OLv ->
                                    zm_event:notify(Src, 'active_event', {'active_collect_target', {'technology', [{'role_uid', RoleUid}, {'award_list', [{BSid, OLv}]}]}});
                                true -> ok
                            end,
                            {'ok', [], Info, [{'msg', {Now, NeedTime}}]};
                        Err ->
                            {'ok', [], Info, [{'msg', Err}]}
                    end;
                {_, _, _} ->
                    {'ok', [], Info, [{'msg', "input_error"}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     升级建筑内部信息(科技研究,36计研究,军械等)完成,type=queue.hrl中
%% @end
%% ----------------------------------------------------
study_over([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    Sid = list_to_integer(z_lib:get_value(Msg, "sid", "0")),%科技,36计,军械,城墙具体升级sid
    BSid = list_to_integer(z_lib:get_value(Msg, "building_sid", "0")),%建筑sid
    Type = z_lib:get_value(Msg, "type", 0),
    CheckVaild = valid_lib:check_valib([{'ge', BSid, 1}, {'range', Type, {0, 1}}, {'ge', Sid, 1}]),
    if
        CheckVaild ->
            case zm_config:get('study_info', Sid) of
                'none' ->
                    {'ok', [], Info, [{'msg', "input_error"}]};
                {_, _, BSid} ->
                    RoleShow = role_db:get_role_show(Src, RoleUid),
                    QueueFreeTime = vip_lib:get_building_queue_free_time(role_show:get_vip_level(RoleShow)),
                    TableName = game_lib:get_table(Src),
                    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'queue', RoleUid, []},
                        {'study', RoleUid, []}, {'rmb', RoleUid, rmb_lib:init()}]),
                    case z_db_lib:handle(TableName, {M, F, A}, {RoleUid, BSid, Type, QueueFreeTime}, TableKeys) of
                        {'ok', CS, Olv, DecRmb} ->
                            %% 记录科技研究等日志信息
                            zm_log:info(Src, ?MODULE, 'study_over', "building_study_over", [{'roleuid', RoleUid}, {'bsid', BSid},
                                {'sid', Sid}, {'old_lv', Olv}, {'new_lv', Olv + 1}, {'consume', CS}]),
                            %% 科技研究等事件
                            zm_event:notify(Src, 'building_study_over', [{'role_uid', RoleUid}, {'consume', CS},
                                {'type', Type}, {'build_up', [{Sid, Olv, Olv + 1}]}, {'sid', Sid}]),
                            %科技是否影响战斗力
                            case building_lib:get_bsid('science') =:= BSid andalso role_addition:check_study_role_attr(Sid) of
                                true ->
                                    %% 排行榜信息
                                    GarraySidList = garray_lib:get_garray_ids(Src, RoleUid),
                                    Country = role_lib:get_country(Attr),
                                    zm_event:notify(Src, {'power_change', Country}, [{'uid', RoleUid}, {'gid', GarraySidList}, {'country', Country}]);
                                false ->
                                    'ok'
                            end,
                            corps_db:corps_help_queue_over(Src, RoleUid, BSid, Sid),
                            %%采集类活动抛事件
                            zm_event:notify(Src, 'active_event', {'active_collect_target', {'technology', [{'role_uid', RoleUid}, {'award_list', [{BSid, Olv}]}]}}),
                            {'ok', [], Info, [{'msg', {BSid, Sid, DecRmb}}]};
                        Err ->
                            {'ok', [], Info, [{'msg', Err}]}
                    end;
                {_, _, _} ->
                    {'ok', [], Info, [{'msg', "input_error"}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     士兵招募,伤兵恢复 type=0普通,1rmb秒资源和Cd,2=取消招募
%% @end
%% ----------------------------------------------------
barracks([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    BSid = list_to_integer(z_lib:get_value(Msg, "building_sid", "0")),
    Number = z_lib:get_value(Msg, "num", 0),
    Type = z_lib:get_value(Msg, "type", 0),
    CheckVaild = valid_lib:check_valib([{'ge', BSid, 1}, {'range', Type, {0, 1}}, {'ge', Number, 1}]),
    if
        CheckVaild ->
            MapId = role_lib:get_mapid(Attr),
            Castle = castle_db:get_castle(Src, RoleUid),
            Study = building_db:get_study(Src, RoleUid),
            BuffList = role_db:get_role_buff(Src, RoleUid),
            ActiveAdd = active_addition:get_active_addition(Src, {'study_up_add', BSid}),
            SpeedCardAdd = building_db:get_dispach_card_polity_addper(Src, RoleUid, Castle, BSid),
            MinResource = if
                MapId > 0 ->
                    {_, MinResourceCfg} = zm_config:get('cross_battle_info', 'min_resource'),
                    MinResourceCfg;
                true ->
                    []
            end,
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'role', RoleUid},
                {'queue', RoleUid, []}, {'barracks', RoleUid, barracks:init()},
                {'rmb', RoleUid, rmb_lib:init()}]),
            case z_db_lib:handle(TableName, {M, F, A}, {Src, BSid, Number, Type, Castle, Study, BuffList, ActiveAdd, SpeedCardAdd, MapId, MinResource}, TableKeys) of
                {'ok', Now, CS, NeedTime, OldBarracks, NewBarracks} ->
                    %% 记录士兵招募,伤病恢复日志信息
                    zm_log:info(Src, ?MODULE, 'barracks', "building_barracks", [{'roleuid', RoleUid}, {'bsid', BSid},
                        {'consume', CS}, {'need_time', NeedTime}, {'number', Number}, {'old_barracks', OldBarracks}, {'new_barracks', NewBarracks}]),
                    %% 士兵招募,伤病恢复/取消招募恢复事件
                    zm_event:notify(Src, 'bi_building_barracks', [{'role_uid', RoleUid}, {'consume', CS}, {'sid', BSid}, {'type', Type}, {'number', Number}]),
                    zm_event:notify(Src, achieve, {RoleUid, {argu, {{building_barracks_times, BSid}, 1}}}),
                    case Type =:= 1 of
                        true ->
                            zm_event:notify(Src, achieve, {RoleUid, {argu, {{building_barracks_num, BSid}, Number}}});
                        false ->
                            ok
                    end,
                    {'ok', [], Info, [{'msg', {Now, NeedTime}}]};
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     士兵招募,伤兵恢复完成
%% @end
%% ----------------------------------------------------
barracks_over([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    BSid = list_to_integer(z_lib:get_value(Msg, "building_sid", "0")),
    Type = z_lib:get_value(Msg, "type", 0),
    CheckVaild = valid_lib:check_valib([{'ge', BSid, 1}, {'range', Type, {0, 1}}]),
    if
        CheckVaild ->
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'queue', RoleUid, []},
                {'barracks', RoleUid, barracks:init()}, {'rmb', RoleUid, rmb_lib:init()}]),
            RoleShow = role_db:get_role_show(Src, RoleUid),
            QueueFreeTime = vip_lib:get_building_queue_free_time(role_show:get_vip_level(RoleShow)),
            case z_db_lib:handle(TableName, {M, F, A}, {BSid, Type, QueueFreeTime}, TableKeys) of
                {'ok', Number, Cs, DecRmb, Barracks, NBarracks} ->
                    %% 记录士兵招募,伤病恢复日志信息
                    zm_log:info(Src, ?MODULE, 'barracks_over', "building_barracks_over", [{'roleuid', RoleUid},
                        {'bsid', BSid}, {'number', Number}, {'old_barracks', Barracks}, {'new_barracks', NBarracks}]),
                    %% 士兵招募,伤病恢复事件
                    zm_event:notify(Src, 'bi_building_barracks_over', [{'role_uid', RoleUid}, {'consume', Cs},
                        {'sid', BSid}, {'number', Number}, {'type', Type}]),
                    zm_event:notify(Src, achieve, {RoleUid, {argu, {{building_barracks_num, BSid}, Number}}}),
                    {'ok', [], Info, [{'msg', {Number, DecRmb}}]};
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     大殿任命
%% @end
%% ----------------------------------------------------
political(_, _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    CardUid = list_to_integer(z_lib:get_value(Msg, "card_uid", "-1")),
    Pos = z_lib:get_value(Msg, "pos", 0),
    CheckVaild = valid_lib:check_valib([{'ge', CardUid, 0}, {'gt', Pos, 0}]),
    if
        CheckVaild ->
            Reply = building_db:political(Src, RoleUid, Pos, CardUid),
            {'ok', [], Info, [{'msg', Reply}]};
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     大殿任命,交换位置
%% @end
%% ----------------------------------------------------
change_political(_, _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    Pos1 = z_lib:get_value(Msg, "pos1", 0),
    Pos2 = z_lib:get_value(Msg, "pos2", 0),
    CheckVaild = valid_lib:check_valib([{'gt', Pos1, 0}, {'gt', Pos2, 0}]),
    if
        CheckVaild ->
            Country = role_lib:get_country(Attr),
            Reply = building_db:change_political(Src, RoleUid, Country, Pos1, Pos2),
            {'ok', [], Info, [{'msg', Reply}]};
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     取消升级,招募,治疗等(建筑时候BSid=1,铸币取消=2,sid为建筑sid;其他科技,36计,士兵等BSid为对应建筑sid,sid为科技等sid)
%% @end
%% ----------------------------------------------------
queue_cancel(_, _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    BSid = list_to_integer(z_lib:get_value(Msg, "building_sid", "0")),
    Sid = list_to_integer(z_lib:get_value(Msg, "sid", "0")),
    CheckVaild = valid_lib:check_valib([{'ge', BSid, 1}, {'ge', Sid, 1}]),
    if
        CheckVaild ->
            Study = building_db:get_study(Src, RoleUid),
            Castle = castle_db:get_castle(Src, RoleUid),
            case building_db:queue_cancel(Src, RoleUid, BSid, Sid, Castle, Study) of
                {'ok', AwardList} ->
                    AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, AwardList),
                    %% 取消升级,招募等
                    zm_log:info(Src, ?MODULE, 'queue_cancel', "queue_cancel", [{'roleuid', RoleUid}, {'bsid', BSid},
                        {'sid', Sid}, {'award', AwardLog}]),
                    %% 取消升级,招募等事件
                    zm_event:notify(Src, 'bi_queue_cancel', [{'role_uid', RoleUid}, {'award', AwardLog}, {'sid', Sid}]),
                    corps_db:corps_help_queue_over(Src, RoleUid, BSid, Sid),
                    {'ok', [], Info, [{'msg', AwardLog}]};
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     铸币所:type={1,'wood'},{2,'forage'},{3,'mineral'},{4,'iron'}
%% @end
%% ----------------------------------------------------
mintage([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    BSid = list_to_integer(z_lib:get_value(Msg, "building_sid", "0")),
    Number = z_lib:get_value(Msg, "num", 0),
    Type = list_to_integer(z_lib:get_value(Msg, "type", "1")),
    BuildingCfg = building:get_cfg(BSid),
    {_, MType} = zm_config:get('building_info', 'mintage_build_type'),
    CheckVaild = valid_lib:check_valib([{'unequal', BuildingCfg, 'none'}, {'equal', building:get_type(BuildingCfg), MType},
        {'range', Type, {1, 4}}, {'ge', Number, 1}]),
    if
        CheckVaild ->
            Castle = castle_db:get_castle(Src, RoleUid),
            Building = castle:get_building(Castle),
            BLv = castle:get_buildlv(Building, BSid),
            {_, Percent, Time} = zm_config:get('mintage_info', BLv),
            SpeedCardAdd = building_db:get_dispach_card_polity_addper(Src, RoleUid, Castle, BSid),
            Speed = 10000 * (10000 + SpeedCardAdd) div 10000,
            NTime = game_lib:ceil(Time * 10000 / Speed),
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'role', RoleUid},
                {'queue', RoleUid, []}]),
            case z_db_lib:handle(TableName, {M, F, A}, {BSid, Number, Type, Percent, NTime, BLv}, TableKeys) of
                {'ok', Now, CS, NeedTime} ->
                    %% 记录铸币信息
                    zm_log:info(Src, ?MODULE, 'mintage', "building_mintage", [{'roleuid', RoleUid}, {'bsid', BSid},
                        {'consume', CS}, {'need_time', NeedTime}, {'number', Number}]),
                    %% 记录铸币bi
                    zm_event:notify(Src, 'bi_building_mintage', [{'role_uid', RoleUid}, {'consume', CS}, {'sid', BSid}]),
                    {'ok', [], Info, [{'msg', {Now, NeedTime}}]};
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     铸币完成
%% @end
%% ----------------------------------------------------
mintage_over(_, _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    BSid = list_to_integer(z_lib:get_value(Msg, "building_sid", "0")),
    CheckVaild = valid_lib:check_valib([{'ge', BSid, 1}]),
    if
        CheckVaild ->
            case building_db:mintage_over(Src, RoleUid, BSid) of
                {'ok', Number} ->
                    AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, [{'money', Number}]),
                    %% 记录铸币完成日志信息
                    zm_log:info(Src, ?MODULE, 'mintage_over', "building_mintage_over", [{'roleuid', RoleUid},
                        {'bsid', BSid}, {'number', Number}]),
                    %% 铸币bi
                    zm_event:notify(Src, 'bi_building_mintage_over', [{'role_uid', RoleUid}, {'award', AwardLog}, {'sid', BSid}]),
                    zm_event:notify(Src, achieve, {RoleUid, {argu, {mintage_money_num, Number}}}),
                    {'ok', [], Info, [{'msg', AwardLog}]};
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.


%% ----------------------------------------------------
%% @doc
%%     购买临时队列
%% @end
%% ----------------------------------------------------
buy_tmp_queue([{M, F, A}], _, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'buy_tmp_queue', RoleUid, {0, []}},
        {'rmb', RoleUid, rmb_lib:init()}
    ]),
    Role = role_db:get_role(Src, RoleUid),
    MaxLen = vip_lib:get_building_tmp_queue_max_len(Role),
    case MaxLen > 0 of
        true ->
            Queue = building_db:get_queue(Src, RoleUid),
            Now = time_lib:now_second(),
            case z_db_lib:handle(TableName, {M, F, A}, {Src, MaxLen, Queue, Now, Role}, TableKeys) of
                {ok, QId, CS, Count} ->
                    %% 记录铸币完成日志信息
                    zm_log:info(Src, ?MODULE, 'buy_tmp_queue', "building_buy_tmp_queue", [{'roleuid', RoleUid},
                        {'count', Count}, {'qid', QId}, {'cs', CS}]),
                    zm_event:notify(Src, 'bi_building_buy_tmp_queue', [{'role_uid', RoleUid}, {'consume', CS}]),
                    {'ok', [], Info, [{'msg', {QId, Now, Count}}]};
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end;
        false ->
            {'ok', [], Info, [{'msg', "tmp_queue_len_limit"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     派遣(取消派遣)武将
%% @end
%% ----------------------------------------------------
dispatch(_, _, Attr, Info, Msg) ->
    CardUid = list_to_integer(z_lib:get_value(Msg, "card_uid", "-1")),
    Pos = z_lib:get_value(Msg, "pos", 0),
    CheckVaild = valid_lib:check_valib([{'gt', Pos, 0}, {'ge', CardUid, 0}]),
    if
        CheckVaild ->
            Src = z_lib:get_value(Info, 'src', 'none'),
            RoleUid = role_lib:get_uid(Attr),
            if
                CardUid =:= 0 ->%取消派遣
                    Fun = fun(_, Castle) ->
                        Building = castle:get_building(Castle),
                        case lists:keyfind(Pos, 1, Building) of
                            false ->
                                throw("unlock_limit");
                            {_, Sid, Lv, _} ->
                                {'ok', "ok", castle:set_building(Castle, lists:keyreplace(Pos, 1, Building, {Pos, Sid, Lv, CardUid}))}
                        end
                    end,
                    Reply = z_db_lib:update(game_lib:get_table(Src, 'castle'), RoleUid, castle:init(), Fun, []),
                    {'ok', [], Info, [{'msg', Reply}]};
                true ->%派遣
                    CardSotrage = storage_db:get_storage('card', Src, RoleUid),
                    Reply =
                        case storage_lib:find_by_uid(CardSotrage, CardUid) of
                            {_, Prop} ->
                                Sid = prop_kit_lib:get_prop_sid(Prop),
                                Castle = castle_db:get_castle(Src, RoleUid),
                                Building = castle:get_building(Castle),
                                ExistBool =
                                    z_lib:foreach(fun(A, {Pos1, _, _, OCardUid}) ->
                                        if
                                            OCardUid > 0 ->
                                                {_, NProp} = storage_lib:find_by_uid(CardSotrage, OCardUid),
                                                NSid = prop_kit_lib:get_prop_sid(NProp),
                                                if
                                                    NSid =:= Sid andalso Pos1 =/= Pos ->
                                                        {'break', true};
                                                    true ->
                                                        {'ok', A}
                                                end;
                                            true ->
                                                {'ok', A}
                                        end
                                    end, false, Building),
                                if
                                    ExistBool ->
                                        "dispatch_exist_sid";
                                    true ->
                                        Fun = fun(_, Castle1) ->
                                            Building1 = castle:get_building(Castle1),
                                            case lists:keyfind(Pos, 1, Building1) of
                                                false ->
                                                    throw("unlock_limit");
                                                {_, BSid, BLv, _} ->
                                                    case BSid =:= building_lib:get_bsid('main') of
                                                        false ->
                                                            {'ok', "ok", castle:set_building(Castle1, lists:keyreplace(Pos, 1, Building1, {Pos, BSid, BLv, CardUid}))};
                                                        true ->
                                                            throw("main_building_not_dispatch")
                                                    end
                                            end
                                        end,
                                        z_db_lib:update(game_lib:get_table(Src, 'castle'), RoleUid, castle:init(), Fun, [])
                                end;
                            _ ->
                                "no_card"
                        end,
                    {'ok', [], Info, [{'msg', Reply}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.


%% ----------------------------------------------------
%% @doc
%%     黑市，生产材料，BSid,MSid,Number,Type=0普通,=1使用rmb,
%% @end
%% ----------------------------------------------------
black_market([{M, F, A}], _, Attr, Info, Msg) ->
    BSid = list_to_integer(z_lib:get_value(Msg, "bsid", "0")),
    MSid = list_to_integer(z_lib:get_value(Msg, "msid", "1")),
    Number = z_lib:get_value(Msg, "num", 0),
    Type = z_lib:get_value(Msg, "type", 0),
    CheckVaild = valid_lib:check_valib([{'ge', BSid, 1}, {'ge', Number, 1}, {'ge', MSid, 0}, {'range', Type, {0, 1}}]),
    if
        CheckVaild ->
            Src = z_lib:get_value(Info, 'src', 'none'),
            RoleUid = role_lib:get_uid(Attr),
            Qid = z_lib:get_value(Msg, "qid", 0),
            {_, {Conditions, Consumes, Time}} = zm_config:get('black_market_info', MSid), %配置里面获取，条件，消耗，时间
            Castle = castle_db:get_castle(Src, RoleUid),
            Building = castle:get_building(Castle),
            BLv = castle:get_buildlv(Building, BSid),
            QueueNum = game_lib:level_value(BLv, element(2, zm_config:get('building_info', 'black_market_queue'))), %获取对应等级队列数
            if
                (Qid > 0 andalso Qid =< QueueNum) orelse (Qid =:= -1 andalso Type =:= ?RMB_UP) ->
                    SpeedCardAdd = building_db:get_dispach_card_polity_addper(Src, RoleUid, Castle, BSid),
                    TableName = game_lib:get_table(Src),
                    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'role', RoleUid},
                        {'queue', RoleUid, []},
                        {'rmb', RoleUid, rmb_lib:init()}]),
                    case z_db_lib:handle(TableName, {M, F, A}, {Src, Type, BSid, MSid, Qid, Number, QueueNum, Conditions, Consumes, Time, Building,
                        [], [], {[], []}, SpeedCardAdd}, TableKeys) of
                        {'ok', Now, CS, NeedTime1} ->
                            AwardLog = if
                                Type =:= ?RMB_UP ->
                                    awarder_game:give_award(Src, RoleUid, ?MODULE, [{'prop', {MSid, Number}}]);
                                true ->
                                    {}
                            end,
                            %% 记录生产信息
                            zm_log:info(Src, ?MODULE, 'black_market', "building_black_market", [{'roleuid', RoleUid}, {'bsid', BSid}, {'msid', MSid}, {'number', Number},
                                {'consume', CS}, {'need_time', NeedTime1}, {'award_log', AwardLog}]),
                            %% 记录生产bi
                            zm_event:notify(Src, 'bi_building_black_market', [{'role_uid', RoleUid}, {'bsid', BSid}, {'msid', MSid}, {'number', Number},
                                {'consume', CS}, {'type', Type}, {'award', AwardLog}]),
                            {'ok', [], Info, [{'msg', {Now, NeedTime1, AwardLog}}]};
                        Err ->
                            {'ok', [], Info, [{'msg', Err}]}
                    end;
                true ->
                    {'ok', [], Info, [{'msg', "input_error"}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.
%% ----------------------------------------------------
%% @doc
%%     黑市，生存材料完成，BSid,MSid,Number,Type=0普通,=1使用rmb,
%% @end
%% ----------------------------------------------------
black_market_over([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    BSid = list_to_integer(z_lib:get_value(Msg, "bsid", "0")),
    Qid = z_lib:get_value(Msg, "qid", 0),
    Type = z_lib:get_value(Msg, "type", 0),
    CheckVaild = valid_lib:check_valib([{'range', Type, {0, 1}}, {'ge', Qid, 1}, {'gt', BSid, 1}]),
    if
        CheckVaild ->
            RoleShow = role_db:get_role_show(Src, RoleUid),
            QueueFreeTime = vip_lib:get_building_queue_free_time(role_show:get_vip_level(RoleShow)),
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'queue', RoleUid, []}, {'rmb', RoleUid, rmb_lib:init()}]),
            case z_db_lib:handle(TableName, {M, F, A}, {BSid, Qid, Type, QueueFreeTime}, TableKeys) of
                {'ok', MSid, Number, BiCs, DecRmb} ->
                    AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, [{'prop', {MSid, Number}}]),
                    %% 记录生产信息
                    zm_log:info(Src, ?MODULE, 'black_market_over', "building_black_market_over", [{'roleuid', RoleUid}, {'bsid', BSid}, {'msid', MSid},
                        {'number', Number}, {'consume', BiCs}]),
                    %% 记录生产bi
                    zm_event:notify(Src, 'bi_building_black_market_over', [{'role_uid', RoleUid}, {'bsid', BSid},
                        {'msid', MSid}, {'number', Number}, {'consume', BiCs}, {'award', AwardLog}]),
                    {'ok', [], Info, [{'msg', {AwardLog, DecRmb}}]};
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.


%% ----------------------------------------------------
%% @doc
%%     藏宝阁，
%% @end
%% ----------------------------------------------------
treasure_house([{M, F, A}], _, Attr, Info, Msg) ->
    BSid = list_to_integer(z_lib:get_value(Msg, "bsid", "0")),
    TSid = list_to_integer(z_lib:get_value(Msg, "tsid", "1")),
    CheckVaild = valid_lib:check_valib([{'ge', BSid, 1}, {'ge', TSid, 1}]),
    if
        CheckVaild ->
            Src = z_lib:get_value(Info, 'src', 'none'),
            RoleUid = role_lib:get_uid(Attr),
            Number = 1, %藏宝阁1次只能制作一个宝物
            {_, {Conditions, Consumes, Time}} = zm_config:get('treasure_house_info', TSid), %配置里面获取，条件，消耗，时间
            Castle = castle_db:get_castle(Src, RoleUid),
            Building = castle:get_building(Castle),
            Role = role_db:get_role(Src, RoleUid),
            SpeedCardAdd = building_db:get_dispach_card_polity_addper(Src, RoleUid, Castle, BSid),
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'treasure_draw', RoleUid, {}}, {'treasure_material', RoleUid, {}}, {'queue', RoleUid, []}]),
            case z_db_lib:handle(TableName, {M, F, A}, {Src, BSid, TSid, Number, Conditions, Consumes, Time, Building,
                Role, [], [], {[], []}, SpeedCardAdd}, TableKeys) of
                {'ok', Now, CS, NeedTime1} ->
                    %% 记录信息
                    zm_log:info(Src, ?MODULE, 'treasure_house', "building_treasure_house", [{'roleuid', RoleUid}, {'bsid', BSid}, {'tsid', TSid},
                        {'consume', CS}, {'need_time', NeedTime1}]),
                    %% 记录bi
                    zm_event:notify(Src, 'bi_building_treasure_house', [{'role_uid', RoleUid}, {'bsid', BSid}, {'tsid', TSid}, {'consume', CS}]),
                    {'ok', [], Info, [{'msg', {Now, NeedTime1}}]};
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     藏宝阁完成，Type=0普通,=1使用rmb,
%% @end
%% ----------------------------------------------------
treasure_house_over([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    BSid = list_to_integer(z_lib:get_value(Msg, "bsid", "0")),
    Type = z_lib:get_value(Msg, "type", 0),
    CheckVaild = valid_lib:check_valib([{'range', Type, {0, 1}}, {'gt', BSid, 1}]),
    if
        CheckVaild ->
            RoleShow = role_db:get_role_show(Src, RoleUid),
            QueueFreeTime = vip_lib:get_building_queue_free_time(role_show:get_vip_level(RoleShow)),
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'queue', RoleUid, []}, {'rmb', RoleUid, rmb_lib:init()}]),
            case z_db_lib:handle(TableName, {M, F, A}, {BSid, Type, QueueFreeTime}, TableKeys) of
                {'ok', TSid, Number, BiCs, DecRmb} ->
                    corps_db:corps_help_queue_over(Src, RoleUid, BSid, TSid),
                    AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, [{'prop', {TSid, Number}}]),
                    %% 记录信息
                    zm_log:info(Src, ?MODULE, 'treasure_house_over', "building_treasure_house_over", [{'roleuid', RoleUid}, {'bsid', BSid}, {'tsid', TSid},
                        {'consume', BiCs}]),
                    %% 记录bi
                    zm_event:notify(Src, 'bi_building_treasure_house_over', [{'role_uid', RoleUid}, {'bsid', BSid},
                        {'tsid', TSid}, {'consume', BiCs}, {'award', AwardLog}]),
                    {'ok', [], Info, [{'msg', {AwardLog, DecRmb}}]};
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     缩短时间
%% @end
%% ----------------------------------------------------
reduce_queue_time([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    BSid = list_to_integer(z_lib:get_value(Msg, "building_sid", "0")),
    Sid = list_to_integer(z_lib:get_value(Msg, "sid", "0")),
    PropSid = list_to_integer(z_lib:get_value(Msg, "psid", "0")),
    Num = list_to_integer(z_lib:get_value(Msg, "num", "0")),
    CheckVaild = valid_lib:check_valib([{'ge', BSid, 1}, {'ge', Sid, 1}, {'gt', Num, 0}, {'gt', PropSid, 0}]),
    if
        CheckVaild ->
            case reduce_time_goods:get_reduce_time(PropSid, BSid) of
                {ok, Time} ->
                    RTime = Time * Num,
                    TableName = game_lib:get_table(Src),
                    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'queue', RoleUid, []}, {'goods', RoleUid}]),
                    case z_db_lib:handle(TableName, {M, F, A}, {PropSid, Sid, BSid, RTime, Num}, TableKeys) of
                        {'ok', BiCs, NeedTime} ->
                            %% 记录信息
                            zm_log:info(Src, ?MODULE, 'reduce_queue_time', "reduce_queue_time", [{'roleuid', RoleUid}, {'bsid', BSid},
                                {'tsid', Sid}, {'consume', BiCs}]),
                            %% 记录bi
                            zm_event:notify(Src, 'bi_reduce_queue_time', [{'role_uid', RoleUid}, {'bsid', BSid}, {'tsid', Sid},
                                {'consume', BiCs}]),
                            {'ok', [], Info, [{'msg', NeedTime}]};
                        Err ->
                            {'ok', [], Info, [{'msg', Err}]}
                    end;
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.
%% ----------------------------------------------------
%% @doc
%%     兵器库打造兵器(type=0普通升级,=1使用rmb秒资源和cd)
%%      CreateType = 0 打造， =1 改造
%% @end
%% ----------------------------------------------------
weapon_create([{M, F, A}], _, Attr, Info, Msg) ->
    BSid = list_to_integer(z_lib:get_value(Msg, "bsid", "0")),
    Sid = list_to_integer(z_lib:get_value(Msg, "sid", "0")),
    Num = z_lib:get_value(Msg, "num", 0),
    Type = z_lib:get_value(Msg, "type", 0),
    CreateType = z_lib:get_value(Msg, "create_type", 0),
    MapId = role_lib:get_mapid(Attr),
    CheckVaild = valid_lib:check_valib([{'ge', BSid, 1}, {'ge', Sid, 1}, {'ge', Num, 1}, {'exist', Type, [0, 1]}, {'exist', CreateType, [0, 1]}, {'equal', MapId, 0}]),
    if
        CheckVaild ->
            Src = z_lib:get_value(Info, 'src', 'none'),
            RoleUid = role_lib:get_uid(Attr),
            Castle = castle_db:get_castle(Src, RoleUid),
            Building = castle:get_building(Castle),
            Level = case lists:keyfind(BSid, 2, Building) of
                {_, _, Lv, _} ->
                    Lv;
                _ ->
                    0
            end,
            {_, {Conditions1, Consumes1, Time1}} = zm_config:get('weapon_create', Sid),
            ConditionConsumeInfo = if
                CreateType =:= ?CREATE -> %0打造
                    {_, V, _} = zm_config:get('weapon_info', Level),
                    {{Conditions1, Consumes1, Time1}, V};
                true ->%%1改造
                    case zm_config:get('weapon_create', Sid + 1) of
                        {_, {Conditions2, Consumes2, Time2}} ->
                            Fun1 = fun(R, {Type2, Value2}) ->
                                case lists:keyfind(Type2, 1, Consumes1) of
                                    {_, Value1} ->
                                        {ok, [{Type2, Value2 - Value1} | R]};
                                    false ->
                                        {ok, [{Type2, Value2} | R]}
                                end
                            end,
                            AccConsume = z_lib:foreach(Fun1, [], Consumes2),
                            {_, _, V} = zm_config:get('weapon_info', Level),
                            {{Conditions2, AccConsume, Time2 - Time1}, V};
                        _ ->
                            "input_error"
                    end
            end,
            case ConditionConsumeInfo of
                {{Conditions, Consumes, Time}, MaxLimitNum} ->
                    if
                        Num > MaxLimitNum ->
                            {'ok', [], Info, [{'msg', "max_num_limit"}]};
                        true ->
                            Study = building_db:get_study(Src, RoleUid),
                            BuffList = role_db:get_role_buff(Src, RoleUid),
                            ActiveAdd = active_addition:get_active_addition(Src, {'study_up_add', BSid}),
                            SpeedCardAdd = building_db:get_dispach_card_polity_addper(Src, RoleUid, Castle, BSid),
                            TableName = game_lib:get_table(Src),
                            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'barracks', RoleUid, barracks:init()}, {'rmb', RoleUid, rmb_lib:init()}, {'role', RoleUid}, {'queue', RoleUid, []}]),
                            case z_db_lib:handle(TableName, {M, F, A}, {Src, BSid, Sid, Num, Type, CreateType, Conditions, Consumes, Time, Building,
                                Study, BuffList, ActiveAdd, SpeedCardAdd}, TableKeys) of
                                {'ok', Now, CS, NeedTime} ->
                                    %% 记录信息
                                    zm_log:info(Src, ?MODULE, 'weapon_create', "building_weapon_create", [{'roleuid', RoleUid}, {'bsid', BSid}, {'sid', Sid}, {'create_type', CreateType},
                                        {'consume', CS}, {'need_time', NeedTime}, {'type', Type}]),
                                    %% 记录bi
                                    zm_event:notify(Src, 'bi_building_weapon_create', [{'role_uid', RoleUid}, {'bsid', BSid}, {'sid', Sid}, {'create_type', CreateType}, {'num', Num}, {'consume', CS}, {'type', Type}]),
                                    {'ok', [], Info, [{'msg', {Now, NeedTime}}]};
                                Err ->
                                    {'ok', [], Info, [{'msg', Err}]}
                            end
                    end;
                Error ->
                    {'ok', [], Info, [{'msg', Error}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.
%% ----------------------------------------------------
%% @doc
%%     兵器库打造兵器完成(type=0普通升级,=1使用rmb秒时间)
%% @end
%% ----------------------------------------------------
weapon_create_over([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    BSid = list_to_integer(z_lib:get_value(Msg, "bsid", "0")),
    Type = z_lib:get_value(Msg, "type", 0),
    CheckSid = building_lib:get_bsid('weapon'),
    CheckVaild = valid_lib:check_valib([{'equal', BSid, CheckSid}, {'exist', Type, [0, 1]}]),
    if
        CheckVaild ->
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'queue', RoleUid, []},
                {'barracks', RoleUid, barracks:init()}, {'rmb', RoleUid, rmb_lib:init()}]),
            RoleShow = role_db:get_role_show(Src, RoleUid),
            QueueFreeTime = vip_lib:get_building_queue_free_time(role_show:get_vip_level(RoleShow)),
            case z_db_lib:handle(TableName, {M, F, A}, {BSid, Type, QueueFreeTime}, TableKeys) of
                {'ok', Num, Cs, DecRmb, Sid, CreateType} ->
                    %% 记录日志信息
                    zm_log:info(Src, ?MODULE, 'weapon_create_over', "building_weapon_create_over", [{'role_uid', RoleUid}, {'bsid', BSid}, {sid, Sid}, {'num', Num}, {'type', Type},
                        {'consume', Cs}, {'create_type', CreateType}]),
                    %%bi
                    zm_event:notify(Src, 'bi_building_weapon_create_over', [{'role_uid', RoleUid}, {'consume', Cs},
                        {'bsid', BSid}, {sid, Sid}, {'num', Num}, {'type', Type}, {'create_type', CreateType}]),
                    {'ok', [], Info, [{'msg', {Num, DecRmb}}]};
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.
%% ----------------------------------------------------
%% @doc
%%     兵器库取消队列
%% @end
%% ----------------------------------------------------
weapon_queue_cancle([{M, F, A}], _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    BSid = list_to_integer(z_lib:get_value(Msg, "bsid", "0")),
    CheckVaild = valid_lib:check_valib([{'ge', BSid, 1}]),
    if
        CheckVaild ->
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'queue', RoleUid, []}, {'barracks', RoleUid, barracks:init()}]),
            case z_db_lib:handle(TableName, {M, F, A}, BSid, TableKeys) of
                {'ok', AwardList, {Sid, Num}} ->
                    AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, AwardList),
                    %% 日志
                    zm_log:info(Src, ?MODULE, 'queue_cancel', "queue_cancel", [{'roleuid', RoleUid}, {'bsid', BSid},
                        {'sid', Sid}, {'award', AwardLog}]),
                    %% bi
                    zm_event:notify(Src, 'bi_queue_cancel', [{'role_uid', RoleUid}, {'award', AwardLog}, {'sid', Sid}]),
                    {'ok', [], Info, [{'msg', {AwardLog, {Sid, Num}}}]};
                Err ->
                    {'ok', [], Info, [{'msg', Err}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
