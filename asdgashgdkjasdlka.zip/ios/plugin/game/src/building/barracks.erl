-module(barracks).

%%%=======================STATEMENT====================
-description("兵营数据存储信息").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([format/1]).
-export([get_leisure/1, get_leisure/2, get_injured/1, get_occupy/1, get_weapon/1, get_weapon/2]).
-export([set_leisure/2, set_leisure/3, set_injured/2, set_occupy/2, set_weapon/2, set_weapon/3]).
-export([init/0, get_amount/1, up_soldiers/3, fight_over/5, fight_over/6]).
-export([get_stations/1]).
-export([set_stations/2]).
-export([update_weapons/3, update_weapons/4, get_weapon_type_bysid/1, get_weapon_level_bysid/1, get_weapon_sid_by_typeandleve/2, get_weapon_cur_sid/2,
    update_barracks_weapon/3, update_barracks_weapon/4, get_weapon_sidandnum_by_type_in_barracks/2, get_weapon_num/2]).
-export([update_gid_marching_dj/4, get_gid_marching_dj/2]).

-export([init_station/3]).
-export([get_station_gid_index/0]).
-export([get_station_gid/1, get_station_leisure/1, get_station_injured/1, get_station_weapon/1]).
-export([set_station_leisure/2, set_station_injured/2, set_station_weapon/2, init_cross/0]).

-export_type([barracks/0]).
-export_type([barracks_station/0]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(barracks, {
    leisure = 0 :: integer(),%当前健康空闲士兵数量
    injured = 0 :: integer(),%受伤士兵数量(伤兵数量只有在伤兵营治疗完成的那一刻才会减少)
    occupy = 0 :: integer(),%武将占用数量
    weapon = [] :: [{integer(), integer()}],%%[{类型+等级,空闲个数}]
    stations = [] :: [barracks_station()],%%驻扎点列表
    info = [] :: list() %扩展用
}).

-record(barracks_station, {
    gid = 0 :: integer(),%%阵型id
    leisure = 0 :: integer(),%%空闲兵力
    injured = 0 :: integer(),%%伤兵
    weapon = [] :: [{integer(), integer()}]%%兵器[{类型+等级,空闲个数}]
}).

%%%=======================TYPE=========================
-type barracks() :: #barracks{}.
-type barracks_station() :: #barracks_station{}.


%%%=================EXPORTED FUNCTIONS=================

format(Barracks) ->
    #barracks{leisure = Leisure, injured = Injured, occupy = Occupy,
        weapon = Weapon, stations = Stations} = Barracks,
    StationViews = lists:map(fun(#barracks_station{gid = GId, leisure = SLeisure, injured = SInjured, weapon = SWeapon}) ->
        {GId, SLeisure, SInjured, list_to_tuple(SWeapon)}
    end, Stations),
    {Leisure, Injured, Occupy, list_to_tuple(Weapon), list_to_tuple(StationViews)}.

%% ----------------------------------------------------
%% @doc  
%%     获取空闲健康士兵数量
%% @end
%% ----------------------------------------------------
-spec get_leisure(barracks()) -> integer().
get_leisure(#barracks{leisure = V}) -> V.

get_leisure(GId, #barracks{leisure = V, stations = Stations}) ->
    case lists:keyfind(GId, #barracks_station.gid, Stations) of
        false ->
            V;
        #barracks_station{leisure = V1} ->
            V1
    end.
set_leisure(GId, Barracks, V) ->
    #barracks{stations = Stations} = Barracks,
    case lists:keyfind(GId, #barracks_station.gid, Stations) of
        false ->
            Barracks#barracks{leisure = V};
        BStation ->
            Barracks#barracks{stations = lists:keyreplace(GId, #barracks_station.gid, Stations, BStation#barracks_station{leisure = V})}
    end.

%% ----------------------------------------------------
%% @doc
%%     获取受伤士兵数量
%% @end
%% ----------------------------------------------------
-spec get_injured(barracks()) -> integer().
get_injured(#barracks{injured = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%     获取武将等占用士兵数量
%% @end
%% ----------------------------------------------------
-spec get_occupy(barracks()) -> integer().
get_occupy(#barracks{occupy = V}) -> V.

%% ----------------------------------------------------
%% @doc
%%     设置空闲健康士兵数量
%% @end
%% ----------------------------------------------------
-spec set_leisure(Barracks :: barracks(), V :: integer()) -> barracks().
set_leisure(Barracks, V) -> Barracks#barracks{leisure = V}.

%% ----------------------------------------------------
%% @doc
%%     设置受伤士兵数量
%% @end
%% ----------------------------------------------------
-spec set_injured(Barracks :: barracks(), V :: integer()) -> barracks().
set_injured(Barracks, V) -> Barracks#barracks{injured = V}.

%% ----------------------------------------------------
%% @doc
%%     设置武将等占用士兵数量
%% @end
%% ----------------------------------------------------
-spec set_occupy(Barracks :: barracks(), V :: integer()) -> barracks().
set_occupy(Barracks, V) -> Barracks#barracks{occupy = V}.

%% ----------------------------------------------------
%% @doc
%%     初始化
%% @end
%% ----------------------------------------------------
-spec init() -> barracks().
init() ->
    {_, DefaultNum, DefInjured} = zm_config:get('role_init', 'barracks'),
    #barracks{leisure = DefaultNum, injured = DefInjured}.

%% ----------------------------------------------------
%% @doc
%%    初始化兵营中驻扎点信息
%% @end
%% ----------------------------------------------------
init_station(GId, Leisure, Weapon) ->
    #barracks_station{gid = GId, leisure = Leisure, weapon = Weapon}.

%% ----------------------------------------------------
%% @doc
%%     获取士兵总数
%% @end
%% ----------------------------------------------------
-spec get_amount(barracks()) -> integer().
get_amount(#barracks{leisure = Leisure, injured = Injured, occupy = Occupy, stations = Stations}) ->
    {SLeisure, SInjured} = z_lib:foreach(fun({SLNum, SINum}, #barracks_station{leisure = SLNum1, injured = SINum1}) ->
        {ok, {SLNum + SLNum1, SINum + SINum1}}
    end, {0, 0}, Stations),
    Leisure + Injured + Occupy + SLeisure + SInjured.

%% ----------------------------------------------------
%% @doc
%%     上阵分配武将带兵信息
%% @end
%% ----------------------------------------------------
-spec up_soldiers(Barracks :: barracks(), GId :: integer(), Num :: integer()) -> barracks().
up_soldiers(Barracks, GId, Num) ->
    #barracks{leisure = Leisure, occupy = Occupy, stations = Stations} = Barracks,
    NOccupy = max(Occupy + Num, 0),
    case lists:keyfind(GId, #barracks_station.gid, Stations) of
        false ->
            NLeisure = max(Leisure - Num, 0),
            Barracks#barracks{leisure = NLeisure, occupy = NOccupy};
        #barracks_station{leisure = SLeisure, injured = SInjured} = BStation ->
            NSLeisure = max(SLeisure - Num, 0),
            NStations = lists:keyreplace(GId, #barracks_station.gid, Stations, BStation#barracks_station{leisure = NSLeisure, injured = SInjured}),
            Barracks#barracks{occupy = NOccupy, stations = NStations}
    end.


%% ----------------------------------------------------
%% @doc
%%     战斗结束,修改伤兵,死亡兵数量
%% @end
%% ----------------------------------------------------
-spec fight_over(Barracks, GId, DeadNum, AddInjured, InjureMax) -> {integer(), barracks()} when
    Barracks :: barracks(),
    GId :: integer(),
    DeadNum :: integer(),
    AddInjured :: integer(),
    InjureMax :: integer().
fight_over(Barracks, GId, DeadNum, AddInjured, InjureMax) when DeadNum >= 0, AddInjured >= 0 ->
    fight_over(Barracks, GId, DeadNum, AddInjured, 0, InjureMax).


%% ----------------------------------------------------
%% @doc
%%     战斗结束,修改伤兵,死亡兵数量
%% @end
%% ----------------------------------------------------
-spec fight_over(Barracks, GId, DeadNum, AddInjured, AddInjuredNoOcc, InjureMax) -> {integer(), barracks()} when
    Barracks :: barracks(),
    GId :: integer(),
    DeadNum :: integer(),
    AddInjured :: integer(),
    AddInjuredNoOcc :: integer(),%%受伤但不影响武将占用
    InjureMax :: integer().
fight_over(Barracks, _GId, 0, 0, 0, _) ->
    {0, Barracks};
fight_over(Barracks, _GId, DeadNum, 0, 0, 0) when DeadNum >= 0 ->%只有死亡
    #barracks{occupy = Occupy} = Barracks,
    NBarracks = Barracks#barracks{
        occupy = max(Occupy - DeadNum, 0)
    },
    {0, NBarracks};
fight_over(Barracks, GId, DeadNum, AddInjured, AddInjuredNoOcc, InjureMax) when DeadNum >= 0, AddInjured >= 0, AddInjuredNoOcc >= 0 ->
    #barracks{occupy = Occupy, injured = Injured, stations = Stations} = Barracks,
    case lists:keyfind(GId, #barracks_station.gid, Stations) of
        false ->
            NInjured1 = Injured + AddInjured + AddInjuredNoOcc,
            NInjure = if
                NInjured1 > InjureMax ->
                    InjureMax;
                true ->
                    NInjured1
            end,
            Injure2Dead = NInjured1 - NInjure,%超过伤兵营上限的,直接转化为死亡,邮件通知玩家
            NBarracks = Barracks#barracks{
                occupy = max(Occupy - DeadNum - AddInjured, 0),
                injured = NInjure
            },
            {Injure2Dead, NBarracks};
        #barracks_station{injured = SInjured} = BStation ->
            NStations = lists:keyreplace(GId, #barracks_station.gid, Stations, BStation#barracks_station{injured = SInjured + AddInjured + AddInjuredNoOcc}),
            {0, Barracks#barracks{
                occupy = max(Occupy - DeadNum - AddInjured, 0),
                stations = NStations
            }}
    end.

%% ----------------------------------------------------
%% @doc
%%    修改阵型行军的死亡和受伤
%% @end
%% ----------------------------------------------------
update_gid_marching_dj(Barracks, GId, AddDeadNum, AddInjuredNum) ->
    #barracks{info = Info} = Barracks,
    {DeadNum, InjuredNum} = z_lib:get_value(Info, GId, {0, 0}),
    NDeadNum = max(DeadNum + AddDeadNum, 0),
    NInjuredNum = max(InjuredNum + AddInjuredNum, 0),
    NInfo =
        case NDeadNum =:= 0 andalso NInjuredNum =:= 0 of
            true ->
                lists:keydelete(GId, 1, Info);
            false ->
                lists:keystore(GId, 1, Info, {GId, {NDeadNum, NInjuredNum}})
        end,
    Barracks#barracks{info = NInfo}.

%% ----------------------------------------------------
%% @doc
%%      获取阵型行军的死亡和受伤
%% @end
%% ----------------------------------------------------
get_gid_marching_dj(Barracks, GId) ->
    #barracks{info = Info} = Barracks,
    z_lib:get_value(Info, GId, {0, 0}).


get_stations(#barracks{stations = Stations}) -> Stations.
set_stations(Barracks, Stations) ->
    Barracks#barracks{stations = Stations}.
%% ----------------------------------------------------
%% @doc
%%     获取所有兵器
%% @end
%% ----------------------------------------------------
get_weapon(#barracks{weapon = V}) ->
    V.
get_weapon(#barracks{weapon = V, stations = BStations}, GId) ->
    case lists:keyfind(GId, #barracks_station.gid, BStations) of
        false ->
            V;
        #barracks_station{weapon = V1} ->
            V1
    end.
%% ----------------------------------------------------
%% @doc
%%      设置兵器
%% @end
%% ----------------------------------------------------
set_weapon(Barracks, V) -> Barracks#barracks{weapon = V}.
set_weapon(Barracks, GId, V) ->
    #barracks{stations = BStations} = Barracks,
    case lists:keyfind(GId, #barracks_station.gid, BStations) of
        false ->
            Barracks#barracks{weapon = V};
        BStation ->
            NBStation = BStation#barracks_station{weapon = V},
            lists:keyreplace(GId, #barracks_station.gid, BStations, NBStation)
    end.
%%-------------------------------------------------------------------
%% @doc
%%      获得兵器类型
%% @end
%%-------------------------------------------------------------------
-spec get_weapon_type_bysid(Sid :: integer()) -> integer().
get_weapon_type_bysid(Sid) ->
    Sid div 1000.
%%-------------------------------------------------------------------
%% @doc
%%      获得兵器等级
%% @end
%%-------------------------------------------------------------------
-spec get_weapon_level_bysid(Sid :: integer()) -> integer().
get_weapon_level_bysid(Sid) ->
    Sid rem 1000.
%%-------------------------------------------------------------------
%% @doc
%%      根据type,和level获取兵器sid
%% @end
%%-------------------------------------------------------------------
-spec get_weapon_sid_by_typeandleve(Type :: integer(), Level :: integer()) -> integer().
get_weapon_sid_by_typeandleve(Type, Level) ->
    Type * 1000 + Level.
%%-------------------------------------------------------------------
%% @doc
%%      获得最高等级兵器sid
%% @end
%%-------------------------------------------------------------------
-spec get_weapon_cur_sid(Sid :: integer(), Level :: integer()) -> integer().
get_weapon_cur_sid(_Sid, 0) ->
    0;
get_weapon_cur_sid(0, _) ->
    0;
get_weapon_cur_sid(Sid, Level) ->
    NLevel = min(Sid rem 1000, Level),
    Type = get_weapon_type_bysid(Sid),
    get_weapon_sid_by_typeandleve(Type, NLevel).

%%-------------------------------------------------------------------
%% @doc
%%      获得兵器等级
%% @end
%%-------------------------------------------------------------------
get_weapon_num(Barracks, Sid) ->
    AllWeapon = get_weapon(Barracks),
    case lists:keyfind(Sid, 1, AllWeapon) of
        {_Sid, Leisure} ->
            Leisure;
        false ->
            0
    end.
%% ----------------------------------------------------
%% @doc
%%      更新兵营中的兵器，武将上阵 -空闲 ，武将下阵+空闲
%%      兵器库中空闲兵器减少传入num是负数，增加空闲兵器传入num正数
%% @end
%% ----------------------------------------------------
update_weapons(Barracks, Sid, Num) when Sid =:= 0;Num =:= 0 ->
    Barracks;
update_weapons(Barracks, Sid, Num) ->
    AllWeapon = get_weapon(Barracks),
    NAllWeapon =
        case lists:keyfind(Sid, 1, AllWeapon) of
            {Sid, Leisure} ->
                lists:keyreplace(Sid, 1, AllWeapon, {Sid, max(0, Leisure + Num)});
            _ when Num > 0 ->
                [{Sid, Num} | AllWeapon]
        end,
    set_weapon(Barracks, NAllWeapon).

%% ----------------------------------------------------
%% @doc
%%
%% @end
%% ----------------------------------------------------
update_weapons(Barracks, _GId, Sid, Num) when Sid =:= 0;Num =:= 0 ->
    Barracks;
update_weapons(Barracks, GId, Sid, Num) ->
    #barracks{weapon = AllWeapon, stations = BStations} = Barracks,
    case lists:keyfind(GId, #barracks_station.gid, BStations) of
        false ->
            NAllWeapon =
                case lists:keyfind(Sid, 1, AllWeapon) of
                    {Sid, Leisure} ->
                        lists:keyreplace(Sid, 1, AllWeapon, {Sid, max(0, Leisure + Num)});
                    _ when Num > 0 ->
                        [{Sid, Num} | AllWeapon]
                end,
            Barracks#barracks{weapon = NAllWeapon};
        #barracks_station{weapon = SAllWeapon} = BStation ->
            NSAllWeapon =
                case lists:keyfind(Sid, 1, SAllWeapon) of
                    {Sid, Leisure} ->
                        lists:keyreplace(Sid, 1, SAllWeapon, {Sid, max(0, Leisure + Num)});
                    _ when Num > 0 ->
                        [{Sid, Num} | SAllWeapon]
                end,
            NBStation = BStation#barracks_station{weapon = NSAllWeapon},
            NBStations = lists:keyreplace(GId, #barracks_station.gid, BStations, NBStation),
            Barracks#barracks{stations = NBStations}
    end.

%%-------------------------------------------------------------------
%% @doc
%%      兵营数据更新  %%OWeapon,更新前的阵容上的兵器；NWeapon,更新后阵容上的兵器
%%-------------------------------------------------------------------
update_barracks_weapon(Barracks, OWeapon, NWeapon) ->
    F1 = fun(CBarracks, {Sid, Num}) when Sid =:= 0;Num =:= 0 ->
        {ok, CBarracks};
        (CBarracks, {Sid, Num}) ->
            {ok, update_weapons(CBarracks, Sid, Num)}
    end,
    Barracks1 = z_lib:foreach(F1, Barracks, tuple_to_list(OWeapon)),

    F2 = fun(CBarracks, {Sid, Num}) when Sid =:= 0;Num =:= 0 ->
        {ok, CBarracks};
        (CBarracks, {Sid, Num}) ->
            {ok, update_weapons(CBarracks, Sid, -Num)}
    end,
    z_lib:foreach(F2, Barracks1, tuple_to_list(NWeapon)).

update_barracks_weapon(Barracks, GId, OWeapon, NWeapon) ->
    F1 = fun(CBarracks, {Sid, Num}) when Sid =:= 0;Num =:= 0 ->
        {ok, CBarracks};
        (CBarracks, {Sid, Num}) ->
            {ok, update_weapons(CBarracks, GId, Sid, Num)}
    end,
    Barracks1 = z_lib:foreach(F1, Barracks, tuple_to_list(OWeapon)),

    F2 = fun(CBarracks, {Sid, Num}) when Sid =:= 0;Num =:= 0 ->
        {ok, CBarracks};
        (CBarracks, {Sid, Num}) ->
            {ok, update_weapons(CBarracks, GId, Sid, -Num)}
    end,
    z_lib:foreach(F2, Barracks1, tuple_to_list(NWeapon)).
%% ----------------------------------------------------
%% @doc
%%     兵器库中 等级最高的兵器
%% @end
%% ----------------------------------------------------
get_weapon_sidandnum_by_type_in_barracks(Barracks, Type) ->
    Weapons = get_weapon(Barracks),
    Fun1 = fun({Sid, Num}, {_RSid, _RNum, MaxLevel} = R) ->
        case get_weapon_type_bysid(Sid) of
            Type ->
                Lv = get_weapon_level_bysid(Sid),
                if
                    Lv > MaxLevel andalso Num > 0 ->
                        {Sid, Num, Lv};
                    true ->
                        R
                end;

            _ ->
                R
        end
    end,
    {WeaponSid, WeaponNum, _} = lists:foldl(Fun1, {0, 0, 0}, Weapons),
    if
        WeaponNum =:= 0 orelse WeaponSid =:= 0 ->
            {0, 0};
        true ->
            {WeaponSid, WeaponNum}
    end.

get_station_gid_index() -> #barracks_station.gid.
get_station_gid(#barracks_station{gid = V}) -> V.
get_station_leisure(#barracks_station{leisure = V}) -> V.
get_station_injured(#barracks_station{injured = V}) -> V.
get_station_weapon(#barracks_station{weapon = V}) -> V.

set_station_leisure(BStation, V) ->
    BStation#barracks_station{leisure = V}.
set_station_injured(BStation, V) ->
    BStation#barracks_station{injured = V}.
set_station_weapon(BStation, V) ->
    BStation#barracks_station{weapon = V}.

%% ----------------------------------------------------
%% @doc
%%     初始化跨服
%% @end
%% ----------------------------------------------------
init_cross() ->
    {_, DefaultNum} = zm_config:get('cross_battle_info', 'barracks'),
    #barracks{leisure = DefaultNum}.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
