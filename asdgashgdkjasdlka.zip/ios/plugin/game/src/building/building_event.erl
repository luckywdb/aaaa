-module(building_event).

%%%=======================STATEMENT====================
-description("building_event").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    notify/4
]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc  
%%      建筑升级增加繁荣度和更新玩家roleshow,并给前台推送
%% @end
%% ----------------------------------------------------
notify(_, Src, 'building_up', Args) ->
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, BuildingLevels} = lists:keyfind('build_up', 1, Args),
    List = lists:filter(fun({_, OldLevel, NewLevel}) -> NewLevel > OldLevel end, BuildingLevels),
    if
        List =:= [] ->
            ok;
        true ->
            update_role_show(Src, RoleUid, List),
            restore_db:build_level_restore(Src, RoleUid, List)
    % set_front_lib:send_restore(Src, RoleUid, list_to_tuple(NRestore))
    end;
notify(_, Src, 'building_up_over', Args) ->
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, BuildingLevels} = lists:keyfind('build_up', 1, Args),
    List = lists:filter(fun({_, OldLevel, NewLevel}) -> NewLevel > OldLevel end, BuildingLevels),
    if
        List =:= [] ->
            ok;
        true ->
            update_role_show(Src, RoleUid, List),
            restore_db:build_level_restore(Src, RoleUid, List)
    % set_front_lib:send_restore(Src, RoleUid, list_to_tuple(NRestore))
    end;
notify(_, Src, 'building_over_role_online', Args) ->
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, BuildingLevels} = lists:keyfind('build_up', 1, Args),
    List = lists:filter(fun({_, OldLevel, NewLevel}) -> NewLevel > OldLevel end, BuildingLevels),
    if
        List =:= [] ->
            ok;
        true ->
            update_role_show(Src, RoleUid, BuildingLevels),
            %%不主动推
            restore_db:build_level_restore(Src, RoleUid, List)
    end;
notify(_, Src, 'building_flourish_zero', Args) ->%繁荣度为0或者冲车击飞
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, BreachNamePUid} = lists:keyfind('breach_puid_name', 1, Args),
    {_, RoleOnlines} = lists:keyfind('role_onlines', 1, Args),
    {_, PlunderTime} = lists:keyfind('plunder_time', 1, Args),
    {_, MapId} = lists:keyfind('map_id', 1, Args),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    OldPointUid = role_show:get_point(RoleShow),
    NPointUid = castle_db:random_move_castle(Src, RoleUid, PlunderTime, element(1, BreachNamePUid) =:= 1, MapId),
    %协防处理
    PointMarch = z_db_lib:get(game_lib:get_table(Src, 'point_march'), OldPointUid, point_march:init()),
    lists:foreach(fun(OccMarching) ->
        {MRUid, MGId} = marching:get_roleuid_gid(OccMarching),
        garrison_db:repatriate(Src, RoleUid, OldPointUid, {?ROLE, RoleUid}, MRUid, MGId)
    end, point_march:get_occupy(PointMarch)),
    fight_db:castle_move_dealline(Src, RoleUid, OldPointUid, NPointUid, true),
    BPUN =
        case BreachNamePUid of
            {1, BPUid, BPRoleUid} ->
                BRoleShow = role_db:get_role_show(Src, BPRoleUid),
                {point_lib:xyz2view(BPUid), role_show:get_name(BRoleShow), BPRoleUid, 1};
            {2, SPoint, CorpsName} ->
                {point_lib:xyz2view(SPoint), CorpsName, 0, 2} %%冲车击飞
        end,
    case lists:member(RoleUid, RoleOnlines) =:= false andalso login_db:is_online(Src, RoleUid) =:= 0 of %不是玩家上线处理战斗并且在线的才推送,否则都更新castle
        true ->
            set_front_lib:send_random_move_point(Src, RoleUid, {point_lib:xyz2view(NPointUid), BPUN});
        false ->
            Fun = fun(_, Castle1) ->
                {'ok', 'ok', castle:set_breach(Castle1, NPointUid, BPUN)}
            end,
            z_db_lib:update(game_lib:get_table(Src, 'castle'), RoleUid, castle:init(), Fun, [])
    end.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%      更新role_show中的主城等级
%% @end
%% ----------------------------------------------------
update_role_show(Src, RoleUid, BuildingLevels) ->
    BSid = building_lib:get_bsid('main'),
    case lists:keyfind(BSid, 1, BuildingLevels) of
        false ->
            ok;
        {_, _, Level} ->
            zm_event:notify(Src, 'update_role_show', {RoleUid, {'castle_lv', Level}}),
            zm_event:notify(Src, 'broadcast', {'castle_lv', [{'role_uid', RoleUid}, {'castle_lv', Level}]})
    end.

