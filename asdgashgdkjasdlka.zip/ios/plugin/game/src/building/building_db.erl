-module(building_db).

%%%=======================STATEMENT====================
-description("建筑db").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_queue/2, get_queue_bytype/2, get_study/2, get_study_by_key/3, online_format/3]).
-export([up/3, up_over/3, gain/3, study/3, study_over/3, barracks/3, barracks_over/3, queue_cancel/6, mintage/3, mintage_over/3, buy_tmp_queue/3]).
-export([plunder_award/6, plunder_award_callback/3, get_injure_max/2, get_spy_plunder_award/3, get_resources/2]).
-export([political/4, change_political/5, get_political/2, get_political_attr/2, get_political_carduids/2, check_pos_queue/3, get_all_dispatch_carduids/2]).
-export([get_bposlv/2, get_dispach_card_polity_addper/4]).
-export([black_market/3, black_market_over/3, treasure_house/3, treasure_house_over/3]).
-export([reduce_queue_time/3]).
-export([update_month_card_tmp_queue/3]).
-export([reduce_queue_time/5]).
-export([get_building_up_queue/1]).
-export([weapon_create/3, weapon_create_over/3, weapon_queue_cancle/3, get_quick_consume/6]).
-export([overflow_res_award/3]).
%%%=======================INCLUDE======================
-include("../include/building.hrl").
%%%=======================DEFINE======================
%各升级或消耗cd的队列,存储在 queue表中的标识位 ,科技,36计,各军械,城门各部件升级;士兵招募,伤兵恢复都直接使用该建筑对应的sid

-define(FAILOVER_TIME1, 5).%容错处理时间 %%因为这里point.hrl中有重复定义，所以这里修改下名字


%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%     获取所有队列(建筑,科技升级,士兵招募)[{类型,[{sid,time,needtime}]},...]
%% @end
%% ----------------------------------------------------
-spec get_queue(Src, RoleUid) -> list() when
    Src :: atom(),
    RoleUid :: integer().
get_queue(Src, RoleUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'queue'), RoleUid, []).

%% ----------------------------------------------------
%% @doc
%%     根据类型获取队列(建筑升级使用building.hrl中对应类型,科技研究,36计,士兵招募等直接用建筑sid作为类型)[{类型,[{sid,start_time,needtime}]},...]
%% @end
%% ----------------------------------------------------
-spec get_queue_bytype(Queue, Key) -> list() when
    Queue :: list(),
    Key :: integer().
get_queue_bytype(Queue, Type) when is_integer(Type) ->
    z_lib:get_value(Queue, Type, []).

%% ----------------------------------------------------
%% @doc
%%      获取建筑升级队列
%% @end
%% ----------------------------------------------------
-spec get_building_up_queue(Queue) -> list() when
    Queue :: list().
get_building_up_queue(Queue) ->
    get_queue_bytype(Queue, ?BUILDING).
%% ----------------------------------------------------
%% @doc
%%     资源(民居,采石场,伐木场,铁矿场)产出类建筑,收取资源时间及被掠夺时间记录,[{sid,{计算用时间,存量,上一次收取time(前台用)}},..]
%% @end
%% ----------------------------------------------------
-spec get_gain_info(Src, RoleUid) -> [{integer(), {integer(), integer()}}] when
    Src :: atom(),
    RoleUid :: integer().
get_gain_info(Src, RoleUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'gain_info'), RoleUid, []).

%% ----------------------------------------------------
%% @doc
%%     科技信息,36计,军械,城墙等  key=建筑sid
%% @end
%% ----------------------------------------------------
-spec get_study(Src, RoleUid) -> list() when
    Src :: atom(),
    RoleUid :: integer().
get_study(Src, RoleUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'study'), RoleUid, []).

%% ----------------------------------------------------
%% @doc
%%     科技信息,36计,军械,城墙等  key=建筑sid
%% @end
%% ----------------------------------------------------
-spec get_study_by_key(Src, RoleUid, Key) -> list() when
    Src :: atom(),
    RoleUid :: integer(),
    Key :: integer()|atom().
get_study_by_key(Src, RoleUid, Key) ->
    List = get_study(Src, RoleUid),
    z_lib:get_value(List, Key, []).

%% ----------------------------------------------------
%% @doc
%%      角色上线,获取玩家城堡信息
%% @end
%% ----------------------------------------------------
-spec online_format(Src :: atom(), RoleUid :: integer(), list()) -> tuple().
online_format(Src, RoleUid, Study) ->
    FQueue = get_queue(Src, RoleUid),
    Fun = fun(_, Castle1) ->
        Breach = castle:get_breach(Castle1),
        if
            Breach > 0 ->
                {'ok', Castle1, castle:clear_breach(Castle1)};
            true ->
                {'ok', Castle1}
        end
    end,
    Castle = z_db_lib:update(game_lib:get_table(Src, 'castle'), RoleUid, castle:init(), Fun, []),
    Barracks = z_db_lib:get(game_lib:get_table(Src, 'barracks'), RoleUid, barracks:init()),
    BarracksTuple = barracks:format(Barracks),
    GainList = z_db_lib:get(game_lib:get_table(Src, 'gain_info'), RoleUid, []),
    {_, QIdETimeList} = z_db_lib:get(game_lib:get_table(Src, 'buy_tmp_queue'), RoleUid, {0, []}),
    {
        castle:format_castle(Castle),
        list_to_tuple([{QType, format_queue(QType, QList)} || {QType, QList} <- FQueue]),
        list_to_tuple([{SKey, list_to_tuple(SList)} || {SKey, SList} <- Study]),
        BarracksTuple,
        list_to_tuple([{Sid, LTime} || {Sid, {_, _, LTime}} <- GainList]),
        list_to_tuple(get_political(Src, RoleUid)),
        list_to_tuple(QIdETimeList)
    }.

format_queue(?BUILDING, QList) ->
    list_to_tuple([building_queue:format_up(Q) || Q <- QList]);
format_queue(BSid, QList) ->
    BarracksSid = building_lib:get_bsid('barracks'),
    RecoverSid = building_lib:get_bsid('recover'),
    BLackMarketSid = building_lib:get_bsid('black_market'),
    TreasureSid = building_lib:get_bsid('treasure'),
    MintageSid = building_lib:get_bsid('mintage'),
    WeaponSid = building_lib:get_bsid('weapon'),
    MountSid = building_lib:get_bsid('mount'),
    if
        BSid =:= BarracksSid orelse BSid =:= RecoverSid ->
            list_to_tuple([building_queue:format_barracks(Q) || Q <- QList]);
        BSid =:= BLackMarketSid ->
            list_to_tuple([building_queue:format_bm(Q) || Q <- QList]);
        BSid =:= TreasureSid ->
            list_to_tuple([building_queue:format_th(Q) || Q <- QList]);
        BSid =:= MintageSid ->
            list_to_tuple([building_queue:format_mintage(Q) || Q <- QList]);
        BSid =:= WeaponSid ->
            list_to_tuple([building_queue:format_weapon(Q) || Q <- QList]);
        BSid =:= MountSid ->
            list_to_tuple([building_queue:format_mount(Q) || Q <- QList]);
        BSid =:= ?STATION_BARRACKS_SID ->
            list_to_tuple([building_queue:format_station_barracks(Q) || Q <- QList]);
        true ->
            list_to_tuple([building_queue:format_study(Q) || Q <- QList])
    end.

%% ----------------------------------------------------
%% @doc
%%     建筑升级 (type=0普通升级,=1使用rmb立即完成)
%% @end
%% ----------------------------------------------------
-spec up(term(), tuple(), list()) -> string()|tuple().
up(_, {Src, BSid, Type, Now, Study, BuffList, ActiveAdd, Pos, QId, FreeTime}, [{Index1, Role}, {Index2, Castle}, {Index3, Queue}, {Index4, BuyTmpQueue}, {Index5, GainInfo}, {Index6, Rmb}]) ->
    BQueue = get_queue_bytype(Queue, ?BUILDING),
    {MonthCardQid, QIdETimeList} = refresh_building_tmp_queue(BQueue, BuyTmpQueue),
    PosIndex = building_queue:get_up_pos_index(),
    case lists:keyfind(Pos, PosIndex, BQueue) of
        false ->
            Building = castle:get_building(Castle),
            {Pos1, BSid1, BLv, _CardUid} = get_bposlv(Building, Pos),
            if
                (Pos1 =:= Pos andalso BSid1 =:= BSid) orelse Pos1 =:= 0 ->
                    Build = building:get_cfg(BSid),
                    case BLv >= building:get_max_lv(Build) of
                        true ->
                            throw("building_max_level");
                        false ->
                            BSidIndex = building_queue:get_up_bsid_index(),
                            case lists:keyfind(BSid, BSidIndex, BQueue) of  %在队列里面找该建筑
                                false ->
                                    BType = building:get_type(Build),
                                    %需要增加pos点解锁限制判断,建筑类型数量限制
                                    UnLockBool = building_lib:check_pos_type_num(Building, BLv, Pos, BType),
                                    if
                                        UnLockBool ->
                                            {_, {NeedTime1, _, Conditions, Consumes, _}} = zm_config:get('building_up', {BType, BLv + 1}),
                                            NeedTime = role_addition:get_study_need_time({Src, Role, Study, BuffList, ActiveAdd}, ?BUILDING, NeedTime1, ?BUILDING_BASE_SPEED, 0),
                                            NeedConsume =
                                                if
                                                    Type =:= ?RMB_UP ->
                                                        RmbCon = building_lib:quick_consume(Consumes, NeedTime - FreeTime),
                                                        RmbCon ++ Conditions;
                                                    true ->
                                                        QIdIndex = building_queue:get_up_qid_index(),
                                                        case lists:keyfind(QId, QIdIndex, BQueue) of
                                                            false ->
                                                                ok;
                                                            _ ->
                                                                throw("building_queue_used")
                                                        end,
                                                        DefaultLen = vip_lib:get_building_up_queue_len(Role),
                                                        if
                                                            QId > DefaultLen ->
                                                                case lists:keyfind(QId, 1, QIdETimeList) of
                                                                    false ->
                                                                        throw("tmp_queue_not_find");
                                                                    _ ->
                                                                        ok
                                                                end;
                                                            true ->
                                                                ok
                                                        end,
                                                        Consumes ++ Conditions
                                                end,
                                            case game_lib:checks({'building_lib', 'check'}, {Role, Building, Rmb}, 'up', NeedConsume) of
                                                true ->
                                                    {CS, {NRole, NRmb}} = game_lib:consumes({'building_lib', 'consume'}, {Role, Rmb}, 'up', NeedConsume),
                                                    if
                                                        Type =:= ?RMB_UP ->
                                                            {NCastle, NGainInfo, AwardList, NBLv} = do_up_over(Castle, BSid, GainInfo, Pos),
                                                            {'ok', {'ok', AwardList, CS, BLv, NBLv, 0}, [{Index1, NRole}, {Index2, NCastle},
                                                                {Index4, {MonthCardQid, QIdETimeList}}, {Index5, NGainInfo}, {Index6, NRmb}]};
                                                        true ->
                                                            UpQ = building_queue:init_up(BSid, Now, NeedTime, Pos, QId, CS),
                                                            {'ok', {'ok', [], CS, BLv, BLv, NeedTime}, [{Index1, NRole},
                                                                {Index3, lists:keystore(?BUILDING, 1, Queue, {?BUILDING, [UpQ | BQueue]})},
                                                                {Index4, {MonthCardQid, QIdETimeList}}, {Index6, NRmb}]}
                                                    end;
                                                Err ->
                                                    throw(Err)
                                            end;
                                        true ->
                                            throw("unlock_limit")
                                    end;
                                _ ->
                                    throw("building_queue_ing")%升级队列中
                            end
                    end;
                true ->
                    throw("pos_not_empty")
            end;
        _ ->
            throw("pos_in_queue")
    end.

%% ----------------------------------------------------
%% @doc
%%     建筑升级完成(type=0普通升级,=1使用rmb加速)
%% @end
%% ----------------------------------------------------
-spec up_over(term(), tuple(), list()) -> string()|tuple().
up_over(_, {BSid, Type, Pos, QueueFreeTime}, [{Index1, Castle}, {Index2, Queue}, {Index3, BuyTmpQueue}, {Index4, GainInfo}, {Index5, Rmb}]) ->
    BQueue = get_queue_bytype(Queue, ?BUILDING),
    BSidIndex = building_queue:get_up_bsid_index(),
    case lists:keyfind(BSid, BSidIndex, BQueue) of
        false ->
            throw("building_no_up_info");
        UpQ ->
            Time = building_queue:get_start_time(UpQ),
            NeedTime = building_queue:get_need_time(UpQ),
            %%对比是否一致
            Pos = building_queue:get_up_pos(UpQ),
            {Cs, NRmb, DecRmb} = get_quick_consume(Type, NeedTime, Time, QueueFreeTime, Rmb, ?BUILDING),
            {NCastle, NGainInfo, AwardList, NBLv} = do_up_over(Castle, BSid, GainInfo, Pos),
            NBQueue = lists:keydelete(BSid, BSidIndex, BQueue),
            {'ok', {'ok', AwardList, Cs, NBLv, DecRmb}, [{Index1, NCastle},
                {Index2, lists:keystore(?BUILDING, 1, Queue, {?BUILDING, NBQueue})},
                {Index3, refresh_building_tmp_queue(NBQueue, BuyTmpQueue)}, {Index4, NGainInfo}, {Index5, NRmb}]}

    end.

%% ----------------------------------------------------
%% @doc
%%     收取建筑产出资源(民居,采石场,伐木场,铁矿场)
%% @end
%% ----------------------------------------------------
-spec gain(Src, RoleUid, BSids) -> string()|tuple() when
    Src :: atom(),
    RoleUid :: integer(),
    BSids :: [integer()].
gain(Src, RoleUid, BSids) ->
    Role = role_db:get_role(Src, RoleUid),
    Castle = castle_db:get_castle(Src, RoleUid),
    Building = castle:get_building(Castle),
    ResTypes = element(2, zm_config:get('building_info', 'res_type')),
    F = fun({Bool, AList}, BSid) ->
        case lists:keyfind(BSid, 2, Building) of
            false ->
                {'break', {false, AList}};
            {_, _, BLv, _} ->
                Build = building:get_cfg(BSid),
                Type = building:get_type(Build),
                case lists:member(Type, ResTypes) of
                    true ->
                        {_, ResType, _, _, _} = BuildResConfig = zm_config:get('building_resource', {Type, BLv}),
                        ActiveAddition = active_addition:get_resource_addition(Src, ResType),
                        BDispachCardAdd = get_dispach_card_polity_addper(Src, RoleUid, Castle, BSid),
                        case lists:keyfind(ResType, 1, AList) of
                            false ->
                                {'ok', {Bool, [{ResType, ActiveAddition, [{BSid, BuildResConfig, BDispachCardAdd}]} | AList]}};
                            {_, _, OldList} ->
                                {'ok', {Bool, lists:keyreplace(ResType, 1, AList, {ResType, ActiveAddition, [{BSid, BuildResConfig, BDispachCardAdd} | OldList]})}}
                        end;
                    false ->
                        {'break', {false, AList}}
                end

        end
    end,
    {CBool, CList} = z_lib:foreach(F, {true, []}, BSids),
    if
        CBool andalso CList =/= [] ->
            [{RType1, RAddition1, BBDList1} | _] = CList,%%目前只需要一次只处理1个类型的
            WSid = building_lib:get_bsid('warehouse'),
            WLv = castle:get_buildlv(Building, WSid),
            {_, {WareUpper, _}} = zm_config:get('warehouse', WLv),
            FName = award_source:get_res_fun_by_type(RType1),
            Value = role:FName(Role),
            case RType1 =/= 'money' andalso Value >= WareUpper of
                true ->
                    "warehouse_full";
                false ->
                    Now = time_lib:now_second(),
                    Study = building_db:get_study(Src, RoleUid),
                    BuffList = role_db:get_role_buff(Src, RoleUid),
                    Flourish = restore_lib:get_value(restore_db:get_restore(Src, RoleUid), 'flourish'),
                    FDb = fun(_, GainList) ->
                        AddFun = fun({AddAcc, GainTmp, CurValue}, {BSid, Cfg, DisAdd}) ->
                            {LastGainTime, RestValue, _LTime} = z_lib:get_value(GainTmp, BSid, {Now, 0, Now}),
                            ActiveTimeAddList = active_addition:get_active_time_add_list(RAddition1, LastGainTime, Now),
                            RealAwardNum = role_addition:get_resource({Src, RoleUid, Study, BuffList, ActiveTimeAddList, Flourish, DisAdd}, Cfg, LastGainTime, RestValue),
                            MaxAdd = WareUpper - CurValue,
                            {NewGainInfo, Add} =
                                if
                                    RType1 =/= 'money' andalso RealAwardNum >= MaxAdd ->
                                        if
                                            MaxAdd > 0 ->
                                                NGainInfo1 = lists:keystore(BSid, 1, GainTmp, {BSid, {Now, RealAwardNum - MaxAdd, Now}}),
                                                {NGainInfo1, MaxAdd};
                                            true ->
                                                NGainInfo1 = lists:keystore(BSid, 1, GainTmp, {BSid, {Now, RealAwardNum, Now}}),
                                                {NGainInfo1, 0}
                                        end;
                                    true ->
                                        NGainInfo1 = lists:keystore(BSid, 1, GainTmp, {BSid, {Now, 0, Now}}),
                                        if
                                            RealAwardNum > 0 ->
                                                {NGainInfo1, RealAwardNum};
                                            true ->
                                                {NGainInfo1, 0}
                                        end

                                end,
                            NewAwardList = if
                                Add > 0 ->
                                    awarder_game:merger([{RType1, Add}], AddAcc);
                                true ->
                                    AddAcc
                            end,
                            {'ok', {NewAwardList, NewGainInfo, CurValue + Add}}

                        end,
                        {AwardList, NGainInfo, AllAddValue} = z_lib:foreach(AddFun, {[], GainList, Value}, BBDList1),
                        {'ok', {'ok', Now, AwardList, AllAddValue}, NGainInfo}
                    end,
                    z_db_lib:update(game_lib:get_table(Src, 'gain_info'), RoleUid, [], FDb, [])
            end;
        true ->
            "building_unlock" %该建筑未解锁
    end.


%% ----------------------------------------------------
%% @doc
%%     获取玩家自身仓库存量+未收集的产出资源点存量
%% @end
%% ----------------------------------------------------
-spec get_resources(Src, RoleUid) -> [{integer(), integer(), integer(), integer()}] when
    Src :: atom(),
    RoleUid :: integer().
get_resources(Src, RoleUid) ->
    restore_db:restore(Src, RoleUid),%玩家收成之前恢复一下繁荣度,繁荣度会影响到收成
    Castle = castle_db:get_castle(Src, RoleUid),
    Building = castle:get_building(Castle),
    ResTypes = element(2, zm_config:get('building_info', 'res_type')),
    UnPType = element(2, zm_config:get('building_info', 'unplunder_type')),
    CheckTypes = ResTypes--UnPType,
    Now = time_lib:now_second(),
    Study = building_db:get_study(Src, RoleUid),
    BuffList = role_db:get_role_buff(Src, RoleUid),
    Flourish = restore_lib:get_value(restore_db:get_restore(Src, RoleUid), 'flourish'),
    GainList = get_gain_info(Src, RoleUid),
    F = fun(Args, {_, BSid, Lv, _}) ->
        Type = building:get_type(building:get_cfg(BSid)),
        case lists:member(Type, CheckTypes) of
            true ->
                {LastGainTime, RestValue, _} = z_lib:get_value(GainList, BSid, {Now, 0, Now}),
                {_, ResType, _, _, BaseLimit} = BuildResConfig = zm_config:get('building_resource', {Type, Lv}),
                ActiveTimeAddList = active_addition:get_active_time_add_list(active_addition:get_resource_addition(Src, ResType), LastGainTime, Now),
                BDispachCardAdd = get_dispach_card_polity_addper(Src, RoleUid, Castle, BSid),
                RealAwardNum = role_addition:get_resource({Src, RoleUid, Study, BuffList, ActiveTimeAddList, Flourish, BDispachCardAdd},
                    BuildResConfig, LastGainTime, RestValue),
                {StudyLimitInt, StudyLimitPer} = role_addition:get_study_addition({'resource_limit', ResType}, Study),%科技增加
                ResLimit = (BaseLimit + StudyLimitInt) * (10000 + StudyLimitPer) div 10000, %资源点产出存储上限
                {'ok', [{BSid, ResType, RealAwardNum, ResLimit} | Args]};
            false ->
                {'ok', Args}
        end
    end,
    z_lib:foreach(F, [], Building).


%% ----------------------------------------------------
%% @doc
%%     升级建筑内部信息(科技研究,36计研究,军械,士兵招募,伤兵恢复等),type=queue.hrl中此类型队列都只有1个队列
%%     获取建筑内部各元素等级(36计,军械等直接存储为{type,[{sid,lv}]},科技特殊一点{{type,sub_type},[{sid,lv}]},增加了一层子类型)
%% @end
%% ----------------------------------------------------
-spec study(term(), tuple(), list()) -> string()|tuple().
study(_, {Src, Sid, BSid, Type, Now, BuffList, Castle, ActiveAdd, SpeedCardAdd, VipFreeTime}, [{Index1, Role}, {Index3, Queue}, {Index4, Study}, {Index5, Rmb}]) ->
    BQueue = get_queue_bytype(Queue, BSid),
    if
        erlang:length(BQueue) >= 1 ->
            throw("study_queue_full");
        true ->
            SidIndex = building_queue:get_study_sid_index(),
            case lists:keyfind(Sid, SidIndex, BQueue) of
                false ->
                    Building = castle:get_building(Castle),
                    BStudy = z_lib:get_value(Study, BSid, []),
                    SLv = z_lib:get_value(BStudy, Sid, 0),
                    case zm_config:get('study_up', {Sid, SLv + 1}) of
                        'none' ->
                            throw("study_max_lv");
                        {_, {NeedTime1, Conditions, Counsume}} ->
                            BLv = castle:get_buildlv(Building, BSid),
                            BType = building:get_type(building:get_cfg(BSid)),
                            case zm_config:get('building_up', {BType, BLv}) of
                                'none' ->
                                    throw("no_lock");
                                BuilindUpInfo ->
                                    StudyBaseSpeed = element(2, element(2, BuilindUpInfo)),
                                    NeedTime = role_addition:get_study_need_time({Src, Role, Study, BuffList, ActiveAdd}, BSid, NeedTime1, StudyBaseSpeed, SpeedCardAdd),
                                    CheckConditions =
                                        if
                                            Type =:= ?RMB_UP ->
                                                RmbCon = building_lib:quick_consume(Counsume, NeedTime - VipFreeTime),
                                                RmbCon ++ Conditions;
                                            true ->
                                                Counsume ++ Conditions
                                        end,
                                    case game_lib:checks({'building_lib', 'check'}, {Role, Building, Rmb}, 'study', CheckConditions) of
                                        true ->
                                            {CS, {NRole, NRmb}} = game_lib:consumes({'building_lib', 'consume'}, {Role, Rmb}, 'study', CheckConditions),
                                            if
                                                Type =:= ?RMB_UP ->
                                                    NStudy1 = lists:keystore(Sid, 1, BStudy, {Sid, SLv + 1}),
                                                    {'ok', {'ok', CS, SLv, SLv + 1, 0}, [{Index1, NRole},
                                                        {Index4, lists:keystore(BSid, 1, Study, {BSid, NStudy1})},
                                                        {Index5, NRmb}]};
                                                true ->
                                                    SQ = building_queue:init_study(Sid, Now, NeedTime, BLv, CS),
                                                    {'ok', {'ok', CS, SLv, SLv, NeedTime}, [{Index1, NRole},
                                                        {Index3, lists:keystore(BSid, 1, Queue, {BSid, [SQ | BQueue]})},
                                                        {Index5, NRmb}]}
                                            end;
                                        Err ->
                                            throw(Err)
                                    end
                            end
                    end;
                _ ->
                    throw("study_queue_ing")%升级队列中
            end
    end.

%% ----------------------------------------------------
%% @doc
%%     升级建筑内部信息(科技研究,36计研究,军械)完成,type=queue.hrl中此类型队列都只有1个队列
%%     获取建筑内部各元素等级(36计,军械等直接存储为{type,[{sid,lv}]},科技特殊一点{{type,sub_type},[{sid,lv}]},增加了一层子类型)
%% @end
%% ----------------------------------------------------
-spec study_over(term(), tuple(), list()) -> string()|tuple().
study_over(_, {_RoleUid, BSid, Type, QueueFreeTime}, [{Index1, Queue}, {Index2, Study}, {Index3, Rmb}]) ->
    case get_queue_bytype(Queue, BSid) of
        [SQ | _] ->%都只有1个队列,如果后续有多个队列需求再修改
            Sid = building_queue:get_study_sid(SQ),
            Time = building_queue:get_start_time(SQ),
            NeedTime = building_queue:get_need_time(SQ),
            {Cs, NRmb, DecRmb} = get_quick_consume(Type, NeedTime, Time, QueueFreeTime, Rmb, BSid),
            BStudy = z_lib:get_value(Study, BSid, []),
            OLv = z_lib:get_value(BStudy, Sid, 0),
            NStudy1 = lists:keystore(Sid, 1, BStudy, {Sid, OLv + 1}),
            {'ok', {'ok', Cs, OLv, DecRmb}, [{Index1, lists:keydelete(BSid, 1, Queue)},
                {Index2, lists:keystore(BSid, 1, Study, {BSid, NStudy1})}, {Index3, NRmb}]};
        _ ->
            throw("study_no_up_info")
    end.

%% ----------------------------------------------------
%% @doc
%%      兵营招募/伤兵恢复
%% @end
%% ----------------------------------------------------
-spec barracks(term(), tuple(), list()) -> string()|tuple().
barracks(_, {Src, BSid, Number, Type, Castle, Study, BuffList, ActiveAdd, SpeedCardAdd, MapId, CrossBattleMinResource}, [{Index1, Role}, {Index3, Queue}, {Index4, Barracks}, {Index5, Rmb}]) ->
    BQueue = get_queue_bytype(Queue, BSid),
    if
        erlang:length(BQueue) >= 1 ->
            throw("barracks_queue_full");
        true ->
            Building = castle:get_building(Castle),
            BLv = castle:get_buildlv(Building, BSid),
            BarracksInfo = barracksinfo:get_cfg({BSid, BLv}),
            OnNum = barracksinfo:get_once_num(BarracksInfo),
            Recover = building_lib:get_bsid('recover'),
            InjureNum = barracks:get_injured(Barracks),
            MaxNum = barracksinfo:get_max_num(BarracksInfo),
            Amount = barracks:get_amount(Barracks),
            if
                Number > OnNum ->
                    throw("one_number_limit");
                BSid =:= Recover andalso Number > InjureNum ->
                    throw("injured_limit");%伤兵不足
                BSid =/= Recover andalso Number + Amount > MaxNum ->
                    throw("max_number_limit");
                true ->
                    NeedTime1 = game_lib:ceil(barracksinfo:get_once_time(BarracksInfo) * Number / 10000),%向上取整
                    BType = building:get_type(building:get_cfg(BSid)),%建筑等级增加速度
                    StudyBaseSpeed = element(2, element(2, zm_config:get('building_up', {BType, BLv}))),
                    NeedTime = role_addition:get_study_need_time({Src, Role, Study, BuffList, ActiveAdd}, BSid, NeedTime1, StudyBaseSpeed, SpeedCardAdd),
                    %国策等增加buff信息
                    DecBuff = 10000 + role_addition:get_barracks_forage(BuffList),
                    {Consume0, CrossBattleConsume} = barracksinfo:get_once_consume(BarracksInfo),
                    ConsumeTmp = if
                        MapId > 0 ->
                            CrossBattleConsume;
                        true ->
                            Consume0
                    end,
                    Consumes = [{T, game_lib:ceil(V * Number / 10000)} || {T, V} <- awarder_game:award_percent(ConsumeTmp, DecBuff)],%向上取整
                    {CheckConsumes, ConConsume} =
                        if
                            Type =:= ?RMB_UP ->
                                C = building_lib:quick_consume(Consumes, NeedTime),
                                {C, C};
                            BSid =:= Recover ->
                                {Consumes, Consumes};
                            true ->
                                {awarder_game:merger(Consumes, CrossBattleMinResource), Consumes}
                        end,
                    case game_lib:checks({'building_lib', 'check'}, {Role, 'none', Rmb}, 'barracks', CheckConsumes) of
                        true ->
                            {CS, {NRole, NRmb}} = game_lib:consumes({'building_lib', 'consume'}, {Role, Rmb}, 'barracks', ConConsume),
                            Now = time_lib:now_second(),
                            if
                                Type =:= ?RMB_UP ->
                                    NewBarracks = building_lib:barracks_calc(Number, Barracks, BSid),
                                    {'ok', {'ok', Now, CS, 0, Barracks, NewBarracks}, [{Index1, NRole},
                                        {Index4, NewBarracks},
                                        {Index5, NRmb}]};
                                true ->
                                    BQ = building_queue:init_barracks(Number, Now, NeedTime, BLv, DecBuff, CS),
                                    {'ok', {'ok', Now, CS, NeedTime, Barracks, Barracks}, [{Index1, NRole},
                                        {Index3, lists:keystore(BSid, 1, Queue, {BSid, [BQ | BQueue]})},
                                        {Index5, NRmb}]}
                            end;
                        Err ->
                            throw(Err)
                    end
            end
    end.

%% ----------------------------------------------------
%% @doc
%%     兵营招募/伤兵恢复完成
%% @end
%% ----------------------------------------------------
-spec barracks_over(term(), tuple(), list()) -> string()|tuple().
barracks_over(_, {BSid, Type, QueueFreeTime}, [{Index1, Queue}, {Index2, Barracks}, {Index3, Rmb}]) ->
    case get_queue_bytype(Queue, BSid) of
        [BQ | _] ->%都只有1个队列,如果后续有多个队列需求再修改
            Number = building_queue:get_barracks_number(BQ),
            Time = building_queue:get_start_time(BQ),
            NeedTime = building_queue:get_need_time(BQ),
            {Cs, NRmb, DecRmb} = get_quick_consume(Type, NeedTime, Time, QueueFreeTime, Rmb, BSid),
            NBarracks = building_lib:barracks_calc(Number, Barracks, BSid),
            {'ok', {'ok', Number, Cs, DecRmb, Barracks, NBarracks}, [{Index1, lists:keydelete(BSid, 1, Queue)},
                {Index2, NBarracks}, {Index3, NRmb}]};
        _ ->
            throw("no_barracks")
    end.

%% ----------------------------------------------------
%% @doc
%%      内政 {pos,card_uid,card_sid}
%% @end
%% ----------------------------------------------------
-spec political(Src, RoleUid, Pos, CardUid) -> string()|tuple() when
    Src :: atom(),
    RoleUid :: integer(),
    Pos :: integer(),
    CardUid :: integer().
political(Src, RoleUid, Pos, 0) ->
    case check_political(Src, RoleUid, Pos, 0) of
        {'ok', _CSid, GIds} ->
            Fun = fun(_, Political1) ->
                {'ok', ok, lists:keydelete(Pos, 1, Political1)}
            end,
            z_db_lib:update(game_lib:get_table(Src, 'political'), RoleUid, [], Fun, []),
            case GIds =/= [] of
                true ->
                    Country = role_show:get_country(role_db:get_role_show(Src, RoleUid)),
                    zm_event:notify(Src, {'official_update_garray', Country}, [{'uid', RoleUid}, {'gid', GIds}, {'country', Country}]);
                false ->
                    ok
            end,
            "ok";
        Err ->
            Err
    end;
political(Src, RoleUid, Pos, CardUid) ->
    case check_political(Src, RoleUid, Pos, CardUid) of
        {'ok', CSid, GIds} ->
            Fun = fun(_, Political1) ->
                case lists:keyfind(CardUid, 2, Political1) of
                    {Pos, CardUid, _} ->
                        throw("ok");
                    {OldPos, CardUid, _} ->%该武将在其他位置上阵了,其他位置下阵,新位置上阵
%%                        Sids = [S || {_, _, S} <- lists:keydelete(Pos, 1, Political1)],
%%                        case lists:member(CSid, Sids) of
%%                            true ->
%%                                throw("political_card_exist");
%%                            false ->
                        NP = lists:keystore(Pos, 1, lists:keydelete(OldPos, 1, Political1), {Pos, CardUid, CSid}),
                        {'ok', "ok", NP};
%%                        end;
                    false ->%该武将未上阵,新位置直接上阵
                        Sids = [S || {_, _, S} <- lists:keydelete(Pos, 1, Political1)],
                        case lists:member(CSid, Sids) of
                            true ->
                                throw("political_card_exist");
                            false ->
                                NP = lists:keystore(Pos, 1, Political1, {Pos, CardUid, CSid}),
                                {'ok', "ok", NP}
                        end
                end
            end,
            R = z_db_lib:update(game_lib:get_table(Src, 'political'), RoleUid, [], Fun, []),
            case R =:= "ok" andalso GIds =/= [] of
                true ->
                    Country = role_show:get_country(role_db:get_role_show(Src, RoleUid)),
                    zm_event:notify(Src, {'official_update_garray', Country}, [{'uid', RoleUid}, {'gid', GIds}, {'country', Country}]);
                false ->
                    ok
            end,
            R;
        Err ->
            Err
    end.

%% ----------------------------------------------------
%% @doc
%%      切换任命
%% @end
%% ----------------------------------------------------
change_political(Src, RoleUid, Country, Pos1, Pos2) ->
    Castle = castle_db:get_castle(Src, RoleUid),
    CLv = castle:get_level(Castle),
    {_, OpenLv1, _} = zm_config:get('political_attr', Pos1),
    {_, OpenLv2, _} = zm_config:get('political_attr', Pos2),
    if
        CLv >= OpenLv1 andalso CLv >= OpenLv2 ->
            Fun = fun(_, Political1) ->
                case lists:keyfind(Pos1, 1, Political1) of
                    false ->
                        case lists:keyfind(Pos2, 1, Political1) of
                            false ->
                                throw("input_error");
                            {Pos2, CardUid2, CSid2} ->
                                {'ok', {"ok", [CardUid2]}, [{Pos1, CardUid2, CSid2} | lists:keydelete(Pos2, 1, Political1)]}
                        end;
                    {Pos1, CardUid1, CSid1} ->
                        case lists:keyfind(Pos2, 1, Political1) of
                            false ->
                                {'ok', {"ok", [CardUid1]}, [{Pos2, CardUid1, CSid1} | lists:keydelete(Pos1, 1, Political1)]};
                            {Pos2, CardUid2, CSid2} ->
                                {'ok', {"ok", [CardUid1, CardUid2]}, lists:keyreplace(Pos1, 1, lists:keyreplace(Pos2, 1, Political1, {Pos2, CardUid1, CSid1}), {Pos1, CardUid2, CSid2})}
                        end
                end
            end,
            case z_db_lib:update(game_lib:get_table(Src, 'political'), RoleUid, [], Fun, []) of
                {R, CardUids} ->
                    GIds =
                        if
                            CardUids =/= [] ->
                                z_lib:foreach(fun(A, {_, Prop}) ->
                                    State = card:get_state(prop_kit_lib:get_prop_record(Prop)),
                                    if
                                        State > 0 ->
                                            {'ok', [State | A]};
                                        true ->
                                            {'ok', A}
                                    end;
                                    (A, _) ->
                                        {'ok', A}
                                end, [], storage_lib:find_by_uid(storage_db:get_storage('card', Src, RoleUid), CardUids));
                            true ->
                                []
                        end,
                    if
                        GIds =/= [] ->
                            zm_event:notify(Src, {'official_update_garray', Country}, [{'uid', RoleUid}, {'gid', GIds}, {'country', Country}]);
                        true ->
                            ok
                    end,
                    R;
                Err ->
                    Err
            end;
        true ->
            "not_open"
    end.

%%-------------------------------------------------------------------
%% @doc
%%      检查是否可以实施 {pos,carduid,cardsid}
%% @end
%%-------------------------------------------------------------------
check_political(Src, RoleUid, Pos, CardUid) ->
    Castle = castle_db:get_castle(Src, RoleUid),
    CLv = castle:get_level(Castle),
    case zm_config:get('political_attr', Pos) of
        'none' ->
            "input_error";
        {_, OpenLv, _} ->
            case CLv >= OpenLv of
                true ->
                    CardStorage = storage_db:get_storage('card', Src, RoleUid),
                    case CardUid =:= 0 of
                        true ->
                            Political = z_db_lib:get(game_lib:get_table(Src, 'political'), RoleUid, []),
                            case lists:keyfind(Pos, 1, Political) of
                                false ->
                                    "no_card";
                                {_, CUid, _} ->
                                    {_, CardProp} = storage_lib:find_by_uid(CardStorage, CUid),
                                    GId = card:get_state(prop_kit_lib:get_prop_record(CardProp)),
                                    CSid = prop_kit_lib:get_prop_sid(CardProp),
                                    if
                                        GId > 0 ->
                                            case garray:check_idle(garray_db:get_garray(Src, RoleUid, GId)) of
                                                true ->
                                                    {ok, CSid, [GId]};
                                                false ->
                                                    "no_idle"
                                            end;
                                        true ->
                                            {ok, CSid, []}
                                    end
                            end;
                        false ->
                            case storage_lib:find_by_uid(CardStorage, CardUid) of
                                {_, CardProp} ->
                                    GId = card:get_state(prop_kit_lib:get_prop_record(CardProp)),
                                    CSid = prop_kit_lib:get_prop_sid(CardProp),
                                    case GId =:= 0 orelse garray:check_idle(garray_db:get_garray(Src, RoleUid, GId)) of
                                        true ->
                                            Political = z_db_lib:get(game_lib:get_table(Src, 'political'), RoleUid, []),
                                            Bool = lists:keyfind(CardUid, 2, Political) =/= false,
                                            case lists:keyfind(Pos, 1, Political) of
                                                false ->
                                                    case Bool andalso GId > 0 of
                                                        true ->
                                                            {ok, CSid, [GId]};
                                                        false ->
                                                            {ok, CSid, []}
                                                    end;
                                                {_, CardUid, _} ->
                                                    {ok, CSid, []};
                                                {_, CardUid1, _} ->
                                                    {_, CardProp1} = storage_lib:find_by_uid(CardStorage, CardUid1),
                                                    GId1 = card:get_state(prop_kit_lib:get_prop_record(CardProp1)),
                                                    case GId1 =:= 0 orelse garray:check_idle(garray_db:get_garray(Src, RoleUid, GId1)) of
                                                        true ->
                                                            case Bool andalso GId > 0 andalso GId1 > 0 of
                                                                true ->
                                                                    {ok, CSid, lists:usort([GId, GId1])};
                                                                false ->
                                                                    if
                                                                        GId > 0 ->
                                                                            {ok, CSid, [GId]};
                                                                        true ->
                                                                            if
                                                                                GId1 > 0 ->
                                                                                    {ok, CSid, [GId1]};
                                                                                true ->
                                                                                    {ok, CSid, []}
                                                                            end
                                                                    end
                                                            end;
                                                        false ->
                                                            "no_idle"
                                                    end
                                            end;
                                        false ->
                                            "no_idle"
                                    end;
                                _ ->
                                    "no_card"
                            end
                    end;
                false ->
                    "not_open"
            end
    end.
%% ----------------------------------------------------
%% @doc
%%     内政信息
%% @end
%% ----------------------------------------------------
-spec get_political(Src :: atom(), RoleUid :: integer()) -> [{integer(), integer(), integer()}].
get_political(Src, RoleUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'political'), RoleUid, []).

%% ----------------------------------------------------
%% @doc
%%     获取内政属性 {pos,card_uid,card_sid}
%% @end
%% ----------------------------------------------------
-spec get_political_attr(CardUid :: integer(), Political :: [{integer(), integer(), integer()}]) ->
    fighter:attr().
get_political_attr(CardUid, Political) ->
    case lists:keyfind(CardUid, 2, Political) of
        false ->
            [];
        {Pos, _, _} ->
            element(3, zm_config:get('political_attr', Pos))
    end.

%% ----------------------------------------------------
%% @doc
%%      武将分解
%% @end
%% ----------------------------------------------------
-spec get_political_carduids(atom(), integer()) -> [integer()].
get_political_carduids(Src, RoleUid) ->
    Political = get_political(Src, RoleUid),
    lists:foldl(fun({_, CardUid, _}, Acc) -> [CardUid | Acc] end, [], Political).

%% ----------------------------------------------------
%% @doc
%%      取消升级,招募,治疗等
%% @end
%% ----------------------------------------------------
-spec queue_cancel(Src, RoleUid, BSid, Sid, Castle, Study) -> tuple()|string() when
    Src :: atom(),
    RoleUid :: integer(),
    BSid :: integer(),
    Sid :: integer(),
    Castle :: castle:castle(),
    Study :: list().
queue_cancel(Src, RoleUid, BSid, Sid, Castle, Study) ->
    {_, DefaultPercent, PercenList} = zm_config:get('building_info', 'canel_percent'),
    Percent = z_db_lib:get_value(PercenList, BSid, DefaultPercent),
    Building = castle:get_building(Castle),
    Fun = fun(_, Queue) ->
        BQueue = z_lib:get_value(Queue, BSid, []),
        if
            BQueue =:= [] ->
                throw("no_queue");
            true ->
                BarracksSid = building_lib:get_bsid('barracks'),
                RecoverSid = building_lib:get_bsid('recover'),
                BLackMarketSid = building_lib:get_bsid('black_market'),
                TreasureSid = building_lib:get_bsid('treasure'),
                MintageSid = building_lib:get_bsid('mintage'),
                if
                    BSid =:= TreasureSid ->%%藏宝阁不能取消
                        throw("input_error");
                    BSid =:= RecoverSid ->
                        {'ok', {'ok', []}, lists:keydelete(BSid, 1, Queue)};
                    BSid =:= ?STATION_BARRACKS_SID ->
                        %%Sid当gid
                        NBQueue = lists:keydelete(Sid, building_queue:get_station_barracks_gid_index(), BQueue),
                        {'ok', {'ok', []}, lists:keystore(BSid, 1, Queue, {BSid, NBQueue})};
                    BSid =:= BarracksSid ->
                        [BQ | _] = BQueue,
                        Number = building_queue:get_barracks_number(BQ),
                        OldBlv = building_queue:get_barracks_blv(BQ),
                        BarracksInfo = barracksinfo:get_cfg({BSid, OldBlv}),
                        Consumes = case building_queue:get_consume_logs(BQ) of
                            [] ->
                                F1 = fun(A, {Type, V}) ->
                                    NewV = V * Number div 10000,
                                    if
                                        NewV > 0 ->
                                            {'ok', [{Type, NewV} | A]};
                                        true ->
                                            {'ok', A}
                                    end
                                end,
                                z_lib:foreach(F1, [], awarder_game:award_percent(barracksinfo:get_once_consume(BarracksInfo), building_queue:get_barracks_per(BQ)));
                            ConsumeLogs ->
                                building_lib:consume_log_to_consume(ConsumeLogs)
                        end,
                        F = fun(A, {Type, V}) ->
                            NewV = V * Percent div 10000,
                            if
                                NewV > 0 ->
                                    {'ok', [{Type, NewV} | A]};
                                true ->
                                    {'ok', A}
                            end
                        end,
                        AwardList = z_lib:foreach(F, [], Consumes),
                        {'ok', {'ok', AwardList}, lists:keydelete(BSid, 1, Queue)};
                    true ->
                        {Consume, NQueue} =
                            if
                                BSid =:= ?BUILDING ->
                                    SidIndex = building_queue:get_up_bsid_index(),
                                    case lists:keyfind(Sid, SidIndex, BQueue) of
                                        false ->
                                            throw("no_queue");
                                        BQ ->
                                            Consume_ = case building_queue:get_consume_logs(BQ) of
                                                [] ->
                                                    Build = building:get_cfg(Sid),
                                                    BLv = castle:get_buildlv(Building, Sid),
                                                    {_, UpInfo} = zm_config:get('building_up', {building:get_type(Build), BLv + 1}),
                                                    element(4, UpInfo);
                                                ConsumeLogs ->
                                                    building_lib:consume_log_to_consume(ConsumeLogs)
                                            end,
                                            {Consume_, lists:keyreplace(BSid, 1, Queue, {BSid, lists:keydelete(Sid, SidIndex, BQueue)})}
                                    end;
                                BSid =:= MintageSid ->
                                    SidIndex = building_queue:get_mintage_bsid_index(),
                                    case lists:keyfind(Sid, SidIndex, BQueue) of
                                        false ->
                                            throw("no_queue");
                                        BQ ->
                                            Consume_ = case building_queue:get_consume_logs(BQ) of
                                                [] ->
                                                    ResType = building_queue:get_mintage_type(BQ),
                                                    Number = building_queue:get_mintage_number(BQ),
                                                    OldBlv = building_queue:get_mintage_blv(BQ),
                                                    {_, MPercent, _MTime} = zm_config:get('mintage_info', OldBlv),
                                                    Res = z_lib:get_value([{1, 'wood'}, {2, 'forage'}, {3, 'mineral'}, {4, 'iron'}], ResType, 'none'),
                                                    ResNum = game_lib:ceil(Number * MPercent / 10000),
                                                    [{Res, ResNum}];
                                                ConsumeLogs ->
                                                    building_lib:consume_log_to_consume(ConsumeLogs)
                                            end,
                                            {Consume_, lists:keyreplace(BSid, 1, Queue, {BSid, lists:keydelete(Sid, SidIndex, BQueue)})}
                                    end;
                                BSid =:= BLackMarketSid -> %黑市
                                    QidIndex = building_queue:get_bm_qid_index(),
                                    %%客户端传过来的是QId
                                    QId = Sid,
                                    case lists:keyfind(QId, QidIndex, BQueue) of
                                        false ->
                                            throw("no_queue");
                                        BQ ->
                                            Consume_ = case building_queue:get_consume_logs(BQ) of
                                                [] ->
                                                    MaterialSid = building_queue:get_bm_sid(BQ),
                                                    Number = building_queue:get_bm_number(BQ),
                                                    {_, {_, Consume1, _}} = zm_config:get('black_market_info', MaterialSid),
                                                    awarder_game:award_multiple(Consume1, Number);
                                                ConsumeLogs ->
                                                    building_lib:consume_log_to_consume(ConsumeLogs)
                                            end,
                                            {Consume_, lists:keyreplace(BSid, 1, Queue, {BSid, lists:keydelete(QId, QidIndex, BQueue)})}
                                    end;
                                true ->
                                    SidIndex = building_queue:get_study_sid_index(),
                                    case lists:keyfind(Sid, SidIndex, BQueue) of
                                        false ->
                                            throw("no_queue");
                                        BQ ->
                                            Consume_ = case building_queue:get_consume_logs(BQ) of
                                                [] ->
                                                    StudyList = z_lib:get_value(Study, BSid, []),
                                                    SLv = z_lib:get_value(StudyList, Sid, 0),
                                                    {_, UpInfo} = zm_config:get('study_up', {Sid, SLv + 1}),
                                                    element(3, UpInfo);
                                                ConsumeLogs ->
                                                    building_lib:consume_log_to_consume(ConsumeLogs)
                                            end,
                                            {Consume_, lists:keyreplace(BSid, 1, Queue, {BSid, lists:keydelete(Sid, SidIndex, BQueue)})}
                                    end
                            end,
                        F = fun(A, {Type, V}) ->
                            NewV = V * Percent div 10000,
                            if
                                NewV > 0 ->
                                    {'ok', [{Type, NewV} | A]};
                                true ->
                                    {'ok', A}
                            end
                        end,
                        AwardList = z_lib:foreach(F, [], Consume),
                        {'ok', {'ok', AwardList}, NQueue}
                end
        end
    end,
    z_db_lib:update(game_lib:get_table(Src, 'queue'), RoleUid, [], Fun, []).

%%-------------------------------------------------------------------
%% @doc
%%     %%--- 旧规则 得到玩家被掠夺资源信息(与掠夺公式一摸一样,只是不用比较负重)
%%     %%--- 新规则 该玩家当前超出其仓库保护上限的所有资源总量
%% @end
%%-------------------------------------------------------------------
-spec get_spy_plunder_award(atom(), integer(), integer()) -> [{atom(), integer()}].
get_spy_plunder_award(Src, MRoleUid, EndRoleUid) ->
%%    GainAwardList = get_resources(Src, EndRoleUid),
%%    ResAwards1 =
%%        lists:foldl(fun({_BSid, ResType, AwardNum, ResLimit}, Acc0) ->
%%            PNum = min(ResLimit, AwardNum),
%%            awarder_game:merger([{ResType, PNum}], Acc0)
%%        end, [], GainAwardList),
%%    ResTypes = element(2, zm_config:get('building_info', 'res_type')),
%%    UnPType = element(2, zm_config:get('building_info', 'unplunder_type')),
%%    CheckTypes = ResTypes--UnPType,
%%    ResAwards =
%%        lists:foldl(fun(Type, Acc) ->
%%            {_, ResType, _, _, _} = zm_config:get('building_resource', {Type, 1}),
%%            case lists:keyfind(ResType, 1, ResAwards1) of
%%                false ->
%%                    [{ResType, 0} | Acc];
%%                R ->
%%                    [R | Acc]
%%            end
%%        end, [], CheckTypes),
%%    WarehouseProtect = role_addition:get_warehouse_res(Src, EndRoleUid, 0),
%%    EndRole = role_db:get_role(Src, EndRoleUid),
%%    F1 = fun(Acc1, {RType, _PNum}) ->
%%        FName = string_lib:to_atom("get_", RType),
%%        Value = role:FName(EndRole),
%%        if
%%            Value =< WarehouseProtect ->%玩家仓库存量低于保护量
%%                {'ok', Acc1};
%%            true ->
%%                PlunRoleNum = (Value - WarehouseProtect),
%%                {'ok', [{RType, PlunRoleNum} | Acc1]}
%%        end
%%    end,
%%    RoleDelList = z_lib:foreach(F1, [], ResAwards),
%%    [{T, V} || {T, V} <- awarder_game:merger(ResAwards, RoleDelList), V > 0].

%%旧版本
    PlunPer = role_addition:get_plunder_add(Src, MRoleUid),
    MainPasvPlunder = get_main_pasvplunder(Src, EndRoleUid),
    {_, Reply, _, _} = plunder_res(Src, EndRoleUid, true, MainPasvPlunder, 0, PlunPer),
    Reply.

%% ----------------------------------------------------
%% @doc
%%      抢夺计算 %产出被掠夺  产出资源不受保护;另外需要记录每一个农田具体的掠夺量
%%      负重(每种资源都那么多负重)
%%      被掠夺玩家B城外资源被掠夺=B资源点产量 *B当前被掠夺比率
%%      被掠夺玩家B损失量=（B当前资源存量-B仓库保护量*（1+B科技增加仓库保护率-A掠夺比率增加率【科技、才略、buff等】））*B当前被掠夺比率，（不大于掠夺者当前总负重）
%% @end
%% ----------------------------------------------------
-spec plunder_award(Src, EndRoleUid, CurBear, Marching, EnemyAddFeats, Attack) ->
    {list(), list(), list(), tuple(), list(), list(), integer(), integer()} when
    Src :: atom(),
    EndRoleUid :: integer(),
    CurBear :: integer(),
    Marching :: marching:marching(),
    EnemyAddFeats :: integer(),
    Attack :: integer().
plunder_award(Src, EndRoleUid, SoldierBearLoad, Marching, EnemyAddFeats, Attack) ->
    MarchingExtra = marching:get_extra(Marching),
    BearPer = marching:get_extra_bearload_add(MarchingExtra),
    PlunPer = marching:get_extra_role_plunder_add(MarchingExtra),
    AllBear = SoldierBearLoad * (BearPer + 10000) div 10000 + marching:get_extra_ordnance_bearload(MarchingExtra),
    MainPasvPlunder = get_main_pasvplunder(Src, EndRoleUid),
    {NGValueList, AwardPlunder, EndRoleDelRes, BGainDelList} = plunder_res(Src, EndRoleUid, false, MainPasvPlunder, AllBear, PlunPer),
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'role', EndRoleUid},
        {'role_restore', EndRoleUid, []},
        {'gain_info', EndRoleUid, []}
    ]),
    PlunderTime = marching:get_etime(Marching),
    restore_db:restore(Src, EndRoleUid, PlunderTime),%扣除繁荣度之前先恢复一次.
    DelFlourish = building_lib:get_del_flourish_var(Attack),
    {ok, BiCs, FlourishInfo, AwardList, NFlourish, RDelFlourish} =
        z_db_lib:handle(TableName, {?MODULE, plunder_award_callback, []},
            {Src, EndRoleDelRes, NGValueList, EnemyAddFeats, DelFlourish, PlunderTime}, TableKeys),
    %日志
    zm_log:info(Src, ?MODULE, 'plunder_award', "role_plunder", [{'role_uid', marching:get_roleuid(Marching)}, {'plunder_award', AwardPlunder},
        {'ruid', EndRoleUid}, {'end_consume', BiCs}, {'end_award', AwardList}]),
    {EndRoleDelRes, AwardPlunder, BiCs, FlourishInfo, AwardList, BGainDelList, RDelFlourish, NFlourish}.

%% ----------------------------------------------------
%% @doc
%%      获取玩家伤兵营上限
%% @end
%% ----------------------------------------------------
-spec get_injure_max(Src :: atom(), RoleUid :: integer()) -> integer().
get_injure_max(Src, RoleUid) ->
    Castle = castle_db:get_castle(Src, RoleUid),
    Buiding = castle:get_building(Castle),
    BSid = building_lib:get_bsid('recover'),
    InjureBLv = castle:get_buildlv(Buiding, BSid),
    BarracksInfo = barracksinfo:get_cfg({BSid, InjureBLv}),
    barracksinfo:get_max_num(BarracksInfo).

%% ----------------------------------------------------
%% @doc
%%      铸币
%% @end
%% ----------------------------------------------------
-spec mintage(term(), tuple(), list()) -> string()|tuple().
mintage(_, {BSid, Number, Type, Percent, Time, BLv}, [{Index1, Role}, {Index2, Queue}]) ->
    MintageSid = building_lib:get_bsid('mintage'),
    BQueue = get_queue_bytype(Queue, MintageSid),
    BSidIndex = building_queue:get_mintage_bsid_index(),
    case lists:keyfind(BSid, BSidIndex, BQueue) of
        false ->
            DeductNum = game_lib:ceil(Number * Percent / 10000),
            Consume = case z_lib:get_value([{1, 'wood'}, {2, 'forage'}, {3, 'mineral'}, {4, 'iron'}], Type, 'none') of
                'none' ->
                    throw("input_error");
                Rtype ->
                    [{Rtype, DeductNum}]
            end,
            case game_lib:checks({'building_lib', 'check'}, {Role, 'none', 'none'}, 'mintage', Consume) of
                true ->
                    NeedTime1 = game_lib:ceil(Time * Number / 10000),%向上取整
                    {CS, {NRole, _}} = game_lib:consumes({'building_lib', 'consume'}, {Role, 'none'}, 'mintage', Consume),
                    Now = time_lib:now_second(),
                    MQ = building_queue:init_mintage(BSid, Type, Number, Now, NeedTime1, BLv, CS),
                    {'ok', {'ok', Now, CS, NeedTime1}, [{Index1, NRole},
                        {Index2, lists:keystore(MintageSid, 1, Queue, {MintageSid, [MQ | BQueue]})}]};
                Err ->
                    throw(Err)
            end;
        _ ->
            throw("barracks_queue_full")
    end.

%% ----------------------------------------------------
%% @doc
%%     铸币完成
%% @end
%% ----------------------------------------------------
-spec mintage_over(Src, RoleUid, BSid) -> {'ok', integer()}|string() when
    Src :: atom(),
    RoleUid :: integer(),
    BSid :: integer().
mintage_over(Src, RoleUid, BSid) ->
    Now = time_lib:now_second(),
    MintageSid = building_lib:get_bsid('mintage'),
    Fun = fun(_, Queue) ->
        BQueue = get_queue_bytype(Queue, MintageSid),
        BSidIndex = building_queue:get_mintage_bsid_index(),
        case lists:keyfind(BSid, BSidIndex, BQueue) of
            false ->
                throw("no_mintage");
            MQ ->%都只有1个队列,如果后续有多个队列需求再修改
                BSid = building_queue:get_mintage_bsid(MQ),
                Number = building_queue:get_mintage_number(MQ),
                Time = building_queue:get_start_time(MQ),
                NeedTime = building_queue:get_need_time(MQ),
                if
                    Time + NeedTime =< Now + 5 ->%增加5秒容错
                        {'ok', {'ok', Number}, lists:keystore(MintageSid, 1, Queue, {MintageSid, lists:keydelete(BSid, BSidIndex, BQueue)})};
                    true ->
                        throw("mintage_time_limit")
                end
        end
    end,
    z_db_lib:update(game_lib:get_table(Src, 'queue'), RoleUid, [], Fun, []).

%% ----------------------------------------------------
%% @doc
%%      购买临时队列
%% @end
%% ----------------------------------------------------
-spec buy_tmp_queue(term(), tuple(), list()) -> string()|tuple().
buy_tmp_queue(_, {_Src, MaxLen, Queue, Now, Role}, [{Index1, BuyTmpQueue}, {Index2, Rmb}]) ->
    BQueue = get_queue_bytype(Queue, ?BUILDING),
    {MonthCardQId, QIdETimeList} = refresh_building_tmp_queue(BQueue, BuyTmpQueue),
    Len = length(QIdETimeList),
    case Len >= MaxLen of
        true ->
            throw("tmp_queue_len_limit");
        false ->
            ok
    end,
    DefaultLen = vip_lib:get_building_up_queue_len(Role),
    QId = z_lib:foreach(fun(R, {Id, _}) -> {ok, max(R, Id)} end, DefaultLen, QIdETimeList) + 1,
    TmpQueueConsume = element(2, zm_config:get('building_info', 'tmp_queue_consume')),
    Count = min(Len + 1, tuple_size(TmpQueueConsume)),
    NeedConsume = element(Count, TmpQueueConsume),
    case game_lib:checks({'building_lib', 'check'}, {Rmb}, 'buy_tmp_queue', NeedConsume) of
        true ->
            Timeout = element(2, zm_config:get('building_info', 'tmp_queue_timeout')),
            {CS, {NRmb}} = game_lib:consumes({'building_lib', 'consume'}, {Rmb}, 'buy_tmp_queue', NeedConsume),
            {ok, {ok, QId, CS, Count}, [{Index1, {MonthCardQId, [{QId, Now, Now + Timeout} | QIdETimeList]}}, {Index2, NRmb}]};
        Err ->
            throw(Err)
    end.

%%-------------------------------------------------------------------
%% @doc
%%      购买月卡增加零时队列
%% @end
%%-------------------------------------------------------------------
update_month_card_tmp_queue(Src, RoleUid, ETime) ->
    Now = time_lib:now_second(),
    Role = role_db:get_role(Src, RoleUid),
    Queue = building_db:get_queue(Src, RoleUid),
    BQueue = get_queue_bytype(Queue, ?BUILDING),
    MaxLen = max(vip_lib:get_building_tmp_queue_max_len(Role), 1),
    Fun = fun(_, BuyTmpQueue) ->
        {MonthCardQId, QIdETimeList} = refresh_building_tmp_queue(BQueue, BuyTmpQueue),
        case lists:keyfind(MonthCardQId, 1, QIdETimeList) of
            false ->
                Len = length(QIdETimeList),
                case Len >= MaxLen of
                    true ->
                        {QId, OSTime, OETime} = lists:nth(Len, QIdETimeList),
                        {NSTime, NETime} =
                            case Now > OETime of
                                true ->
                                    {time_lib:get_zero_time(Now), ETime};
                                false ->
                                    {OSTime, ETime + OETime - OSTime}
                            end,
                        NQIdETimeList = lists:keyreplace(QId, 1, QIdETimeList, {QId, NSTime, NETime}),
                        {ok, {QId, NSTime, NETime}, {QId, NQIdETimeList}};
                    false ->
                        DefaultLen = vip_lib:get_building_up_queue_len(Role),
                        QId = z_lib:foreach(fun(R, {Id, _}) ->
                            {ok, max(R, Id)} end, DefaultLen, QIdETimeList) + 1,
                        NSTime = time_lib:get_zero_time(Now),
                        NQIdETimeList = [{QId, NSTime, ETime} | QIdETimeList],
                        {ok, {QId, NSTime, ETime}, {QId, NQIdETimeList}}
                end;
            {_, OSTime, OETime} ->
                NSTime =
                    case Now > OETime of
                        true ->
                            time_lib:get_zero_time(Now);
                        false ->
                            OSTime
                    end,
                NQIdETimeList = lists:keyreplace(MonthCardQId, 1, QIdETimeList, {MonthCardQId, NSTime, ETime}),
                {ok, {MonthCardQId, NSTime, ETime}, {MonthCardQId, NQIdETimeList}}
        end
    end,
    {MonthCardQId, STime, ETime} = z_db_lib:update(game_lib:get_table(Src, 'buy_tmp_queue'), RoleUid, {0, []}, Fun, []),
    set_front_lib:send_buy_tmp_queue(Src, RoleUid, MonthCardQId, STime, ETime),
    ok.

%% ----------------------------------------------------
%% @doc
%%     检测建筑pos是否在升级队列中
%% @end
%% ----------------------------------------------------
check_pos_queue(Src, RoleUid, Pos) ->
    Queue = get_queue(Src, RoleUid),
    BuildQueue = get_queue_bytype(Queue, ?BUILDING),
    lists:keyfind(Pos, 4, BuildQueue) =/= false.

%% ----------------------------------------------------
%% @doc
%%     获取派遣中的所有武将uid
%% @end
%% ----------------------------------------------------
get_all_dispatch_carduids(Src, RoleUid) ->
    Castle = castle_db:get_castle(Src, RoleUid),
    Building = castle:get_building(Castle),
    [CardUid || {_, _, _, CardUid} <- Building, CardUid > 0].

%% ----------------------------------------------------
%% @doc
%%      黑市，生产材料
%% @end
%% ----------------------------------------------------
-spec black_market(term(), tuple(), list()) -> string()|tuple().
black_market(_, {Src, Type, BSid, MSid, Qid, Number, QueueNum, Conditions, Consumes, Time, Building, Study, BuffList, ActiveAdd, SpeedCardAdd},
        [{Index1, Role}, {Index2, Queue}, {Index3, Rmb}]) ->
    BQueue = get_queue_bytype(Queue, BSid),
    if
        erlang:length(BQueue) >= QueueNum ->
            throw("black_market_queue_full");
        true ->
            QidIndex = building_queue:get_bm_qid_index(),
            case lists:keyfind(Qid, QidIndex, BQueue) of
                false ->
                    ok;
                _ ->  %此队列已存在
                    throw("qid_already_queue")
            end,
            ConsumesMultiple = awarder_game:award_multiple(Consumes, Number),
            NeedTime1 = game_lib:ceil(Time * Number),
            NeedTime = role_addition:get_study_need_time({Src, Role, Study, BuffList, ActiveAdd}, BSid, NeedTime1, ?BASE_SPEED, SpeedCardAdd),
            CheckConsumes =
                if
                    Type =:= ?RMB_UP ->
                        building_lib:quick_consume(ConsumesMultiple, NeedTime);
                    true ->
                        ConsumesMultiple
                end,
            case game_lib:checks({'building_lib', 'check'}, {Role, Building, Rmb}, 'black_market', CheckConsumes ++ Conditions) of%Conditions建筑等级
                true ->
                    {CS, {NRole, NRmb}} = game_lib:consumes({'building_lib', 'consume'}, {Role, Rmb}, 'black_market', CheckConsumes),
                    Now = time_lib:now_second(),
                    if
                        Type =:= ?RMB_UP ->
                            {'ok', {'ok', Now, CS, 0}, [{Index1, NRole}, {Index3, NRmb}]};
                        true ->
                            BMQ = building_queue:init_bm(Qid, MSid, NeedTime, Number, Now, CS),
                            {'ok', {'ok', Now, CS, NeedTime}, [{Index1, NRole},
                                {Index2, lists:keystore(BSid, 1, Queue, {BSid, [BMQ | BQueue]})}]}
                    end;
                Err ->
                    throw(Err)
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      黑市，生产材料完成
%% @end
%% ----------------------------------------------------
black_market_over(_, {BSid, Qid, Type, QueueFreeTime}, [{Index1, Queue}, {Index2, Rmb}]) ->
    BQueue = get_queue_bytype(Queue, BSid),
    QidIndex = building_queue:get_bm_qid_index(),
    case lists:keyfind(Qid, QidIndex, BQueue) of
        false ->
            throw("no_qid");
        BMQ ->
            MSid = building_queue:get_bm_sid(BMQ),
            Number = building_queue:get_bm_number(BMQ),
            StartTime = building_queue:get_start_time(BMQ),
            NeedTime = building_queue:get_need_time(BMQ),
            {BiCs, NRmb, DecRmb} = get_quick_consume(Type, NeedTime, StartTime, QueueFreeTime, Rmb, BSid),
            {'ok', {'ok', MSid, Number, BiCs, DecRmb}, [{Index1, lists:keystore(BSid, 1, Queue, {BSid, lists:keydelete(Qid, QidIndex, BQueue)})}, {Index2, NRmb}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      藏宝阁
%% @end
%% ----------------------------------------------------
-spec treasure_house(term(), tuple(), list()) -> string()|tuple().
treasure_house(_, {Src, BSid, TSid, Number, Conditions, Consumes, Time, Building, Role, Study, BuffList, ActiveAdd, SpeedCardAdd},
        [{Index1, TDStorage}, {Index2, TMStorage}, {Index3, Queue}]) ->
    BQueue = get_queue_bytype(Queue, BSid),
    if
        erlang:length(BQueue) > 0 ->
            throw("treasure_house_queue_full");
        true ->
            ConsumesMultiple = awarder_game:award_multiple(Consumes, Number),
            case game_lib:checks({'building_lib', 'check'}, {TDStorage, Building, TMStorage}, 'treasure_house', ConsumesMultiple ++ Conditions) of%Conditions建筑等级
                true ->
                    NeedTime1 = game_lib:ceil(Time * Number),
                    NeedTime = role_addition:get_study_need_time({Src, Role, Study, BuffList, ActiveAdd}, BSid, NeedTime1, ?BASE_SPEED, SpeedCardAdd),
                    {CS, {NTDStorage, NTMStorage}} = game_lib:consumes({'building_lib', 'consume'}, {TDStorage, TMStorage}, 'treasure_house', ConsumesMultiple),
                    Now = time_lib:now_second(),
                    THQ = building_queue:init_th(TSid, Number, NeedTime, Now, CS),
                    {'ok', {'ok', Now, CS, NeedTime}, [{Index1, NTDStorage}, {Index2, NTMStorage},
                        {Index3, lists:keystore(BSid, 1, Queue, {BSid, [THQ | BQueue]})}]};
                Err ->
                    throw(Err)
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      黑市，生产材料完成
%% @end
%% ----------------------------------------------------
treasure_house_over(_, {BSid, Type, QueueFreeTime}, [{Index1, Queue}, {Index2, Rmb}]) ->
    case get_queue_bytype(Queue, BSid) of
        [THQ | _] ->
            TSid = building_queue:get_th_tsid(THQ),
            Number = building_queue:get_th_number(THQ),
            StartTime = building_queue:get_start_time(THQ),
            NeedTime = building_queue:get_need_time(THQ),
            {BiCs, NRmb, DecRmb} = get_quick_consume(Type, NeedTime, StartTime, QueueFreeTime, Rmb, BSid),

            {'ok', {'ok', TSid, Number, BiCs, DecRmb}, [{Index1, lists:keydelete(BSid, 1, Queue)}, {Index2, NRmb}]};
        _ ->
            throw("no_queue")
    end.

%% ----------------------------------------------------
%% @doc
%%     缩短队列时间
%% @end
%% ----------------------------------------------------
-spec reduce_queue_time(term(), tuple(), list()) -> string()|tuple().
reduce_queue_time(_, {ReduceSid, ItemSid, BSid, RTime, Num}, [{Index1, Queue}, {Index2, GoodStorage}]) ->
    BQueue = get_queue_bytype(Queue, BSid),
    if
        BQueue =:= [] ->
            throw("no_queue");
        true ->
            %%已经结束了的,不让再使用道具
            DealQueue = hd(BQueue),
            case time_lib:now_second() >= building_queue:get_start_time(DealQueue) + building_queue:get_need_time(DealQueue) of
                true ->
                    throw("no_queue");
                false ->
                    case game_lib:checks({building_lib, check}, {GoodStorage}, 'reduce_queue_time', [{prop, {ReduceSid, Num}}]) of
                        true ->
                            {BiCs, {NGoodStorage}} = game_lib:consumes({'building_lib', 'consume'}, {GoodStorage}, 'reduce_queue_time', [{prop, {ReduceSid, Num}}]),
                            {NeedTime, NBQueue, _IsComplete} = reduce_queue_time_1(BSid, ItemSid, BQueue, RTime),
                            NQueue = lists:keystore(BSid, 1, Queue, {BSid, NBQueue}),
                            {'ok', {'ok', BiCs, NeedTime}, [{Index1, NQueue}, {Index2, NGoodStorage}]};
                        Err ->
                            throw(Err)
                    end
            end
    end.


%%-------------------------------------------------------------------
%% @doc
%%      扣队列时间
%% @end
%%-------------------------------------------------------------------
reduce_queue_time(Src, RoleUid, BSid, Sid, RTime) ->
    Fun = fun(_, Queue) ->
        BQueue = get_queue_bytype(Queue, BSid),
        if
            BQueue =:= [] ->
                throw("no_queue");
            true ->
                {NeedTime, NBQueue, IsComplete} = reduce_queue_time_1(BSid, Sid, BQueue, RTime),
                NQueue = lists:keystore(BSid, 1, Queue, {BSid, NBQueue}),
                {ok, {ok, NeedTime, IsComplete}, NQueue}
        end
    end,
    z_db_lib:update(game_lib:get_table(Src, 'queue'), RoleUid, [], Fun, []).

reduce_queue_time_1(BSid, Sid, BQueue, RTime) ->
    Now = time_lib:now_second(),
    case BSid =:= building_lib:get_bsid('barracks') orelse
        BSid =:= building_lib:get_bsid('recover') orelse
        BSid =:= building_lib:get_bsid('treasure') of
        true ->
            [Q | TailBQueue] = BQueue,
            {NQ, NewNeedTime, IsComplete} = reduce_time(Q, RTime, Now),
            {NewNeedTime, [NQ | TailBQueue], IsComplete};
        false ->
            BLackMarketSid = building_lib:get_bsid('black_market'),
            MintageSid = building_lib:get_bsid('mintage'),
            MountSid = building_lib:get_bsid('mount'),
            Index =
                if
                    BSid =:= ?BUILDING ->
                        building_queue:get_up_bsid_index();
                    BSid =:= MintageSid ->
                        building_queue:get_mintage_bsid_index();
                    BSid =:= BLackMarketSid ->
                        building_queue:get_bm_qid_index();
                    BSid =:= MountSid ->
                        building_queue:get_mount_sid_index();
                    BSid =:= ?STATION_BARRACKS_SID ->
                        building_queue:get_station_barracks_gid_index();
                    true ->
                        building_queue:get_study_sid_index()
                end,
            case lists:keyfind(Sid, Index, BQueue) of
                false ->
                    throw("no_queue");
                Q ->
                    {NQ, NewNeedTime, IsComplete} = reduce_time(Q, RTime, Now),
                    {NewNeedTime, lists:keystore(Sid, Index, BQueue, NQ), IsComplete}
            end
    end.
%% ----------------------------------------------------
%% @doc
%%      兵器库打造兵器
%% @end
%% ----------------------------------------------------
weapon_create(_, {Src, BSid, Sid, Num, Type, CreateType, Conditions, Consumes, Time, Building, Study, BuffList, ActiveAdd, SpeedCardAdd},
        [{Index1, Barracks}, {Index2, Rmb}, {Index3, Role}, {Index4, Queue}]) ->
    BQueue = get_queue_bytype(Queue, BSid),
    if
        erlang:length(BQueue) > 0 ->
            throw("queue_full");
        true ->
            ConsumesMultiple = awarder_game:award_multiple(Consumes, Num),
            NeedTime1 = game_lib:ceil(Time * Num / 10000),%%向上取整
            NeedTime = role_addition:get_study_need_time({Src, Role, Study, BuffList, ActiveAdd}, BSid, NeedTime1, ?BASE_SPEED, SpeedCardAdd),
            CheckConsumes =
                if
                    Type =:= ?RMB_UP ->
                        building_lib:quick_consume(ConsumesMultiple, NeedTime);
                    true ->
                        ConsumesMultiple
                end,
            case game_lib:checks({'building_lib', 'check'}, {Role, Building, Rmb}, 'weapon_create', Conditions ++ CheckConsumes) of
                true ->
                    {CS, {NRole, NRmb}} = game_lib:consumes({'building_lib', 'consume'}, {Role, Rmb}, 'weapon_create', CheckConsumes),
                    Now = time_lib:now_second(),
                    if
                        Type =:= ?RMB_UP ->
                            NBarracks =
                                if
                                    CreateType =:= ?CREATE ->
                                        barracks:update_weapons(Barracks, Sid, Num);
                                    true ->
                                        case check_weapon_num(Barracks, Sid, Num) of
                                            true ->
                                                NB = barracks:update_weapons(Barracks, Sid, -Num),
                                                barracks:update_weapons(NB, Sid + 1, Num);
                                            false ->
                                                throw("number_not_enough")
                                        end
                                end,
                            {'ok', {'ok', Now, CS, 0}, [{Index1, NBarracks}, {Index2, NRmb}, {Index3, NRole}]};
                        true ->
                            NBarracks = if
                                CreateType =:= ?CREATE ->
                                    Barracks;
                                true ->
                                    case check_weapon_num(Barracks, Sid, Num) of
                                        true ->
                                            barracks:update_weapons(Barracks, Sid, -Num);
                                        false ->
                                            throw("number_not_enough")
                                    end
                            end,
                            BQ = building_queue:init_weapon(CreateType, Sid, Num, NeedTime, Now, CS),
                            {'ok', {'ok', Now, CS, NeedTime}, [{Index1, NBarracks}, {Index2, NRmb}, {Index3, NRole},
                                {Index4, lists:keystore(BSid, 1, Queue, {BSid, [BQ | BQueue]})}]}
                    end;
                Err ->
                    throw(Err)
            end
    end.

%% ----------------------------------------------------
%% @doc
%%     兵器库打造兵器完成
%% @end
%% ----------------------------------------------------
weapon_create_over(_, {BSid, Type, QueueFreeTime}, [{Index1, Queue}, {Index2, Barracks}, {Index3, Rmb}]) ->
    case get_queue_bytype(Queue, BSid) of
        [BQ | _] ->%都只有1个队列,如果后续有多个队列需求再修改
            Number = building_queue:get_weapon_number(BQ),
            Time = building_queue:get_start_time(BQ),
            NeedTime = building_queue:get_need_time(BQ),
            Sid = building_queue:get_weapon_sid(BQ),
            CreateType = building_queue:get_weapon_type(BQ),
            {Cs, NRmb, DecRmb} = get_quick_consume(Type, NeedTime, Time, QueueFreeTime, Rmb, BSid),
            NBarracks = if
                CreateType =:= ?CREATE ->
                    barracks:update_weapons(Barracks, Sid, Number);
                true ->
                    barracks:update_weapons(Barracks, Sid + 1, Number)
            end,
            {'ok', {'ok', Number, Cs, DecRmb, Sid, CreateType}, [{Index1, lists:keydelete(BSid, 1, Queue)},
                {Index2, NBarracks}, {Index3, NRmb}]};
        _ ->
            throw("no_queue")
    end.
%% ----------------------------------------------------
%% @doc
%%      兵器库  取消队列
%% @end
%% ----------------------------------------------------
weapon_queue_cancle(_, BSid, [{Index1, Queue}, {Index2, Barracks}]) ->
    {_, DefaultPercent, PercenList} = zm_config:get('building_info', 'canel_percent'),
    Percent = z_db_lib:get_value(PercenList, BSid, DefaultPercent),
    BQueue = z_lib:get_value(Queue, BSid, []),
    if
        BQueue =:= [] ->
            throw("no_queue");
        true ->
            [BQ | _] = BQueue,
            Sid = building_queue:get_weapon_sid(BQ),
            CreateType = building_queue:get_weapon_type(BQ),
            Num = building_queue:get_weapon_number(BQ),
            {_, {_Conditions1, Consumes1, _Time1}} = zm_config:get('weapon_create', Sid),
            {Consume, NBarracks, RWeapon} =
                if
                    CreateType =:= ?CREATE -> %0打造
                        {Consumes1, Barracks, {Sid, 0}};
                    true ->%%1改造
                        {_, {_Conditions2, Consumes2, _Time2}} = zm_config:get('weapon_create', Sid + 1),
                        Fun1 = fun(R, {Type2, Value2}) ->
                            case lists:keyfind(Type2, 1, Consumes1) of
                                {_, Value1} ->
                                    {ok, [{Type2, Value2 - Value1} | R]};
                                false ->
                                    {ok, [{Type2, Value2} | R]}
                            end
                        end,
                        AccConsume = z_lib:foreach(Fun1, [], Consumes2),
                        {AccConsume, barracks:update_weapons(Barracks, Sid, Num), {Sid, Num}}
                end,
            Consumes = case building_queue:get_consume_logs(BQ) of
                [] ->
                    awarder_game:award_multiple(Consume, Num);
                ConsumeLogs ->
                    building_lib:consume_log_to_consume(ConsumeLogs)
            end,
            F = fun(A, {Type, V}) ->
                NewV = V * Percent div 10000,
                if
                    NewV > 0 ->
                        {'ok', [{Type, NewV} | A]};
                    true ->
                        {'ok', A}
                end
            end,
            AwardList = z_lib:foreach(F, [], Consumes),
            NQueue = lists:keydelete(BSid, 1, Queue),
            {ok, {ok, AwardList, RWeapon}, [{Index1, NQueue}, {Index2, NBarracks}]}
    end.

%% ----------------------------------------------------
%% @doc
%%      处理资源奖励溢出
%% @end
%% ----------------------------------------------------
overflow_res_award(Src, RoleUid, AwardList) ->
    {_, Flag} = zm_config:get('building_info', 'resource_overflow_flag'),
    case Flag =:= 1 of
        true ->
            Castle = castle_db:get_castle(Src, RoleUid),
            Building = castle:get_building(Castle),
            WSid = building_lib:get_bsid('warehouse'),
            WLv = castle:get_buildlv(Building, WSid),
            {_, {WareUpper, _}} = zm_config:get('warehouse', WLv),
            Role = role_db:get_role(Src, RoleUid),
            Fun = fun({Acc1, Acc2}, {RType, _} = Item) when RType =:= 'wood' orelse RType =:= 'mineral' orelse RType =:= 'iron' orelse RType =:= 'forage' ->
                Fun = string_lib:to_atom('get_not_safe_', RType),
                V = role:Fun(Role),
                case V >= WareUpper of
                    true ->
                        {ok, {Acc1, [Item | Acc2]}};
                    false ->
                        {ok, {[Item | Acc1], Acc2}}
                end;
                (Acc, Item) ->
                    {ok, [Item | Acc]}
            end,
            {NAwardList, OFAwardList} = z_lib:foreach(Fun, {[], []}, AwardList),
            case OFAwardList =/= [] of
                true ->
                    OFAwardList1 = z_lib:foreach(fun(Acc, Item) ->
                        times_set_lib:update(Acc, Item) end, [{'forage', 0}, {'wood', 0}, {'mineral', 0}, {'iron', 0}], OFAwardList),
                    [F, W, M, I] = lists:map(fun({_, N}) -> -N end, OFAwardList1),
                    MailType = award_source:get_source("fighting"),
                    Mail = mail:init({MailType, time_lib:now_second(), 0, {43}, {43, F, W, M, I}, []}),
                    mail_db:send(Src, RoleUid, Mail);
                false ->
                    ok
            end,
            NAwardList;
        false ->
            AwardList
    end.

%%%===================LOCAL FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%      刷新购买的临时队列
%% @end
%%-------------------------------------------------------------------
refresh_building_tmp_queue(BQueue, {MonthCardQId, BuyTmpQueue}) ->
    Now = time_lib:now_second(),
    NBuyTmpQueue = lists:reverse(z_lib:foreach(fun(R, {QId, _, ETime} = Item) ->
        case Now >= ETime of
            true ->
                case lists:keyfind(QId, 5, BQueue) of
                    false ->
                        {ok, R};
                    _ ->
                        {ok, [Item | R]}
                end;
            false ->
                {ok, [Item | R]}
        end
    end, [], BuyTmpQueue)),
    case lists:keyfind(MonthCardQId, 1, NBuyTmpQueue) of
        false ->
            {0, NBuyTmpQueue};
        _ ->
            {MonthCardQId, NBuyTmpQueue}
    end.
%% ----------------------------------------------------
%% @doc  
%%      执行建筑升级
%% @end
%% ----------------------------------------------------
-spec do_up_over(Castle, Sid, GainInfo, Pos) -> {castle:castle(), GainInfo, list(), integer()} when
    Castle :: castle:castle(),
    Sid :: integer(),
    GainInfo :: [{integer(), {integer(), integer(), integer()}}],
    Pos :: integer().
do_up_over(Castle, Sid, GainInfo, Pos) ->
    Building = castle:get_building(Castle),
    {Pos1, BSid1, BLv, CardUid} = get_bposlv(Building, Pos),
    Build = building:get_cfg(Sid),
    BType = building:get_type(Build),
    {_, UpInfo} = zm_config:get('building_up', {BType, BLv + 1}),
    AwardList1 = element(5, UpInfo),
    NBuilding = if
        Pos =:= Pos1 andalso BSid1 =:= Sid andalso BLv > 0 ->
            lists:keyreplace(Pos, 1, Building, {Pos, Sid, BLv + 1, CardUid});
        Pos1 =:= 0 ->
            case lists:keyfind(Sid, 2, Building) of
                false ->
                    [{Pos, Sid, 1, 0} | Building];
                _ ->
                    throw("input_error")
            end;
        true ->
            throw("input_error")
    end,
    MainBuildSid = building_lib:get_bsid('main'),
    NCastle = if
        MainBuildSid =:= Sid ->
            castle:set_level(castle:set_building(Castle, NBuilding), BLv + 1);
        true ->
            castle:set_building(Castle, NBuilding)
    end,
    NGainInfo = building_lib:check_gain_info(GainInfo, Sid, BType, BLv),%解锁新建筑时候,如果是资源类建筑,初始化收获时间
    {NCastle, NGainInfo, AwardList1, BLv + 1}.

%% ----------------------------------------------------
%% @doc
%%      根据类型获取加速秒cd需要的消耗信息
%% @end
%% ----------------------------------------------------
-spec get_quick_consume(Type, RealNeedTime, Time, QueueFreeTime, Rmb, BSid) -> string()|{list(), {integer(), integer()}, integer()} when
    Type :: integer(),
    RealNeedTime :: integer(),
    Time :: integer(),
    QueueFreeTime :: integer(),
    Rmb :: {integer(), integer()},
    BSid :: integer().%%
get_quick_consume(Type, RealNeedTime, Time, QueueFreeTime, Rmb, BSid) ->
    Now = time_lib:now_second(),
    {_, BSidList} = zm_config:get('building_info', 'free_time_bsid_list'),
    CheckVipFree = lists:member(BSid, BSidList),
    case CheckVipFree andalso Now - Time + ?FAILOVER_TIME1 >= RealNeedTime - QueueFreeTime of
        true ->
            {[], Rmb, 0};
        false ->
            if
                Type =:= ?RMB_UP ->
                    NeedRmb =
                        if
                            CheckVipFree ->
                                max(building_lib:quick_time2rmb(RealNeedTime - QueueFreeTime - (Now - Time)), 1);
                            true ->
                                max(building_lib:quick_time2rmb(RealNeedTime - (Now - Time)), 1) %由于前台给后台发送时候,可能存在刚好1秒误差,前台最少都要扣除1点
                        end,
                    case rmb_lib:reduct_rmb(Rmb, NeedRmb) of
                        {BiCs, NRmb1} ->
                            {BiCs, NRmb1, NeedRmb};
                        Err ->
                            throw(Err)
                    end;
                true ->
                    if
                        Now - Time + ?FAILOVER_TIME1 >= RealNeedTime ->%加上5s的容错处理时间
                            {[], Rmb, 0};
                        true ->
                            throw("time_limit")
                    end
            end
    end.

%% ----------------------------------------------------
%% @doc
%%     掠夺资源信息(PlunderView=false表示掠夺;=true表示侦查)
%% @end
%% ----------------------------------------------------
-spec plunder_res(Src, EndRoleUid, PlunderView, MainPasvPlunder, AllBear, PlunPer) -> {list(), list(), list(), list()} when
    Src :: atom(),
    EndRoleUid :: integer(),
    PlunderView :: boolean(),
    MainPasvPlunder :: integer(),
    AllBear :: integer(),
    PlunPer :: integer().
plunder_res(Src, EndRoleUid, PlunderView, MainPasvPlunder, AllBear, PlunPer) ->
    GainAwardList = get_resources(Src, EndRoleUid),
    {ResAwards1, NGainsList} = lists:foldl(fun({BSid, ResType, AwardNum, ResLimit}, {Acc0, DAcc}) ->
        PNum = min(ResLimit, AwardNum) * MainPasvPlunder div 10000,
        {awarder_game:merger([{ResType, PNum}], Acc0), [{BSid, max(AwardNum - PNum, 0)} | DAcc]}
    end, {[], []}, GainAwardList),
    ResTypes = element(2, zm_config:get('building_info', 'res_type')),
    UnPType = element(2, zm_config:get('building_info', 'unplunder_type')),
    CheckTypes = ResTypes--UnPType,
    {ResAwards, ResNum} =
        lists:foldl(fun(Type, {Acc, NAcc}) ->
            {_, ResType, _, _, _} = zm_config:get('building_resource', {Type, 1}),
            case lists:keyfind(ResType, 1, ResAwards1) of
                false ->
                    {[{ResType, 0} | Acc], NAcc};
                R ->
                    {[R | Acc], NAcc + element(2, R)}
            end
        end, {[], 0}, CheckTypes),
    WarehouseProtect = role_addition:get_warehouse_res(Src, EndRoleUid, PlunPer),
    EndRole = role_db:get_role(Src, EndRoleUid),
    F1 = fun({Acc1, Acc2}, {RType, _PNum}) ->
        FName = award_source:get_res_fun_by_type(RType),
        Value = role:FName(EndRole),
        if
            Value =< WarehouseProtect ->%玩家仓库存量低于保护量
                {'ok', {Acc1, Acc2}};
            true ->
                PlunRoleNum = (Value - WarehouseProtect) * MainPasvPlunder div 10000,
                {'ok', {[{RType, PlunRoleNum} | Acc1], Acc2 + PlunRoleNum}}
        end
    end,
    {RoleDelList, DelNum} = z_lib:foreach(F1, {[], 0}, ResAwards),
    PlunderAwards = [{T, V} || {T, V} <- awarder_game:merger(ResAwards, RoleDelList), V > 0],
    if
        PlunderView ->
            {[], PlunderAwards, [], []};
        true ->
            S = ResNum + DelNum,
            if
                S =< AllBear ->
                    {NGainsList, PlunderAwards, RoleDelList, ResAwards};
                true ->
                    {PerList1, RBear} = lists:foldl(fun({T1, V1}, {A0, A1}) ->
                        Rv = V1 * AllBear div S,
                        {[{T1, V1 - Rv} | A0], Rv + A1}
                    end, {[], 0}, PlunderAwards),
                    PerList = if
                        RBear =:= AllBear ->
                            PerList1;
                        true ->
                            [{T2, V2} | Rest] = PerList1,
                            [{T2, V2 - (AllBear - RBear)} | Rest]
                    end,
                    {NRoleDelList, ResDList} = plunder_res_(RoleDelList, ResAwards, PerList),
                    NPlunderAwards = [{T, V} || {T, V} <- awarder_game:merger(ResDList, NRoleDelList), V > 0],
                    {_, NGainList} = gain_list(GainAwardList, ResDList, MainPasvPlunder),
                    {NGainList, NPlunderAwards, NRoleDelList, ResDList}
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      计算各个资源产出点具体被掠夺后当前存量
%% @end
%% ----------------------------------------------------
-spec gain_list(GainAwardList, ResDList, MainPasvPlunder) -> {[{atom(), integer()}], [{integer(), integer()}]} when
    GainAwardList :: [{integer(), atom(), integer(), integer()}],
    ResDList :: [{atom(), integer()}],
    MainPasvPlunder :: integer().
gain_list(GainAwardList, ResDList, MainPasvPlunder) ->
    F = fun({RAcc, PAcc}, {BSid, ResType, AwardNum, ResLimit}) ->
        NAwardNum = min(ResLimit, AwardNum),
        NAllBear = z_lib:get_value(ResDList, ResType, 0) - z_lib:get_value(RAcc, ResType, 0),
        if
            NAllBear > 0 ->
                PlunNum = min(NAllBear, NAwardNum * MainPasvPlunder div 10000),%掠夺量
                {'ok', {awarder_game:merger([{ResType, PlunNum}], RAcc), [{BSid, max(AwardNum - PlunNum, 0)} | PAcc]}};
            true ->
                {'ok', {RAcc, PAcc}}
        end
    end,
    z_lib:foreach(F, {[], []}, GainAwardList).

%% ----------------------------------------------------
%% @doc
%%     资源掠夺
%% @end
%% ----------------------------------------------------
-spec plunder_res_([{atom(), integer()}], [{atom(), integer()}], [{atom(), integer()}]) ->
    {[{atom(), integer()}], [{atom(), integer()}]}.
plunder_res_(RoleDelList, ResAwards, []) ->
    {RoleDelList, ResAwards};
plunder_res_(RoleDelList, ResAwards, [{RType, DelV} | Rest]) ->
    V = z_lib:get_value(RoleDelList, RType, 0),
    if
        V >= DelV ->
            NRoleDelList = lists:keyreplace(RType, 1, RoleDelList, {RType, V - DelV}),
            plunder_res_(NRoleDelList, ResAwards, Rest);
        true ->
            ResV = z_lib:get_value(ResAwards, RType, 0),
            NResAwards = lists:keyreplace(RType, 1, ResAwards, {RType, ResV - (DelV - V)}),
            plunder_res_(lists:keydelete(RType, 1, RoleDelList), NResAwards, Rest)
    end.

%% ----------------------------------------------------
%% @doc
%%      plunder_award 的事务操作的回调
%% @end
%% ----------------------------------------------------
-spec plunder_award_callback(_, {Src, RoleDelRes, NGValueList, EnemyAddFeats, DelFlourish, PlunderTime}, TableKeys) -> tuple() when
    Src :: atom(),
    RoleDelRes :: [{atom(), integer()}],
    NGValueList :: [{integer(), integer()}],
    EnemyAddFeats :: integer(),
    DelFlourish :: integer(),
    PlunderTime :: integer(),
    TableKeys :: list().
plunder_award_callback(_, {Src, RoleDelRes, NGValueList, EnemyAddFeats, DelFlourish, PlunderTime}, [{Index1, Role}, {Index2, Restore}, {Index3, GainInfo}]) ->
    Func1 = fun
        ({ResType, Value}, {BiCsArg, RoleArg}) when Value > 0 ->
            FName = string_lib:to_atom("deduct_", ResType),
            GFName = string_lib:to_atom("get_", ResType),
            {BiCs, Role1} = role_lib:FName(RoleArg, min(Value, role:GFName(Role))),
            {BiCs ++ BiCsArg, Role1};
        (_, A) ->
            A
    end,
    {BiCs, NewRole} = lists:foldl(Func1, {[], Role}, RoleDelRes),
    AwardList =
        if
            EnemyAddFeats > 0 ->
                [{'feats', EnemyAddFeats}];
            true ->
                []
        end,
    NRestore = restore_lib:update(Restore, PlunderTime, restore_lib:get_max(Src, Role, 'flourish'), 'flourish', -DelFlourish),
    OldFlourish = restore_lib:get_value(Restore, 'flourish'),
    {_, NFlourish, _} = FlourishInfo = lists:keyfind('flourish', 1, NRestore),
    NGainInfo = z_lib:foreach(fun(A, {BSid, V}) ->
        case lists:keyfind(BSid, 1, A) of
            false ->
                {'ok', [{BSid, {PlunderTime, V, PlunderTime}} | A]};
            {_, {_, _, LTime}} ->
                {'ok', lists:keyreplace(BSid, 1, A, {BSid, {PlunderTime, V, LTime}})}
        end
    end, GainInfo, NGValueList),
    RDelFlourish = OldFlourish - NFlourish,
    {ok, {ok, [{'flourish', RDelFlourish, NFlourish} | BiCs], FlourishInfo, AwardList, NFlourish, RDelFlourish}, [
        {Index1, NewRole},
        {Index2, NRestore},
        {Index3, NGainInfo}]}.

%% ----------------------------------------------------
%% @doc
%%      掠夺, 得到被掠夺概率
%% @end
%% ----------------------------------------------------
-spec get_main_pasvplunder(Src, RoleUid) -> integer() when
    Src :: atom(),
    RoleUid :: integer().
get_main_pasvplunder(Src, RoleUid) ->
    RoleShow = role_db:get_role_show(Src, RoleUid),
    CastleLv = role_show:get_castle_lv(RoleShow),
    {_, Val, _} = zm_config:get(main_building, CastleLv),
    Val.

%% ----------------------------------------------------
%% @doc
%%     获取建筑坐标对应的信息
%% @end
%% ----------------------------------------------------
get_bposlv(Building, Pos) ->
    case lists:keyfind(Pos, 1, Building) of
        false ->
            {0, 0, 0, 0};
        V ->
            V
    end.
%%-------------------------------------------------------------------
%% @doc
%%      获取派遣的政治影响速度加成
%% @end
%%-------------------------------------------------------------------
get_dispach_card_polity_addper(Src, RoleUid, Castle, BSid) ->
    Building = castle:get_building(Castle),
    CardUid = case lists:keyfind(BSid, 2, Building) of
        false ->
            0;
        {_, _, _, V} ->
            V
    end,
    if
        CardUid =:= 0 ->
            0;
        true ->
            CardStorage = storage_db:get_storage('card', Src, RoleUid),
            {_, Prop} = storage_lib:find_by_uid(CardStorage, CardUid),
            Card = prop_kit_lib:get_prop_record(Prop),
            building_lib:get_polity_addper(card:get_polity(Card))
    end.

%% ----------------------------------------------------
%% @doc
%%      加速道具 减小需求中需求队列时间
%% @end
%% ----------------------------------------------------
reduce_time(Q, RTime, Now) ->
    StartTime = building_queue:get_start_time(Q),
    NeedTime = building_queue:get_need_time(Q),
    case Now >= StartTime + NeedTime of
        true ->
            {Q, NeedTime, true};
        false ->
            NewNeedTime = max(0, NeedTime - RTime),
            {building_queue:set_need_time(Q, NewNeedTime), NewNeedTime, Now >= StartTime + NewNeedTime}
    end.

%% ----------------------------------------------------
%% @doc
%%      检查是否有足够的兵器
%% @end
%% ----------------------------------------------------
check_weapon_num(Barracks, Sid, Num) ->
    z_db_lib:get_value(barracks:get_weapon(Barracks), Sid, 0) >= Num.


%%%% ----------------------------------------------------
%%%% @doc
%%%%     角色上线,需要进行的处理(离线过程中,所有完成的队列信息前台自己处理)
%%%% @end
%%%% ----------------------------------------------------
%%-spec role_online(Src, RoleUid) -> tuple() when
%%    Src :: atom(),
%%    RoleUid :: integer().
%%role_online(Src, RoleUid) ->
%%    case FQueue =:= [] of
%%        true ->
%%            Castle = castle_db:get_castle(Src, RoleUid),
%%            Study = building_db:get_study(Src, RoleUid),
%%            Barracks = z_db_lib:get(game_lib:get_table(Src, 'barracks'), RoleUid, barracks:init()),
%%            Gain = z_db_lib:get(game_lib:get_table(Src, 'gain_info'), RoleUid, gain_info_init()),
%%            {Castle, FQueue, Study, Barracks, Gain};
%%        false ->
%%            TableName = game_lib:get_table(Src),
%%            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'castle', RoleUid},
%%                {'queue', RoleUid, []}, {'study', RoleUid, []},
%%                {'barracks', RoleUid, barracks:init()},
%%                {'gain_info', RoleUid, gain_info_init()}]),
%%            Reply = z_db_lib:handle(TableName, {?MODULE, role_online_, []}, {Src, RoleUid}, TableKeys),
%%            {Castle, Queue, Study, Barracks, Gain, AwardList, BuildUpList} = Reply,
%%            case AwardList =:= [] of
%%                true ->
%%                    ok;
%%                false ->
%%                    AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, AwardList),
%%                    zm_event:notify(Src, 'building_over_role_online', [{'role_uid', RoleUid}, {'award', AwardLog}, {'build_up', BuildUpList}])
%%            end,
%%            {Castle, Queue, Study, Barracks, Gain}
%%    end.

%%role_online_(_, {_Src, _RoleUid}, [{_Index1, Castle}, {_Index2, Queue}, {_Index3, Study}, {_Index4, Barracks}, {_Index5, Gain}]) ->
%%    {Castle, Queue, Study, Barracks, Gain, [], []}.
%%    BarracksBSid = building_lib:get_bsid('barracks'),
%%    RecoverBSid = building_lib:get_bsid('recover'),
%%    Now = time_lib:now_second(),
%%    Fun = fun(Args, {_, []}) ->
%%        {'ok', Args};
%%        (Args, {?MINTAGE, _QueueList}) ->
%%            {'ok', Args};
%%        ({Castle1, Queue1, Study1, Barracks1, Gain1, Award, BUpList}, {?BUILDING, QueueList}) ->
%%            BFun = fun({Castle2, QueueList2, Gain2, Award2, BUpList2}, {Sid, Time, NeedTime, Pos} = R) ->
%%                if
%%                    Now - Time >= NeedTime ->
%%                        {Castle3, Gain3, Award3, BLv} = do_up_over(Castle2, Sid, Gain2, Pos),
%%                        {'ok', {Castle3, QueueList2, Gain3, awarder_game:merger(Award3, Award2), [{Sid, BLv - 1, BLv} | BUpList2]}};
%%                    true ->
%%                        {'ok', {Castle2, [R | QueueList2], Gain2, Award2, BUpList2}}
%%                end
%%            end,
%%            {NCastle1, NQueueList, NGain1, Award1, NBUpList} = z_lib:foreach(BFun, {Castle1, [], Gain1, Award, BUpList}, QueueList),
%%            {'ok', {NCastle1, lists:keystore(?BUILDING, 1, Queue1, {?BUILDING, NQueueList}), Study1, Barracks1, NGain1, Award1, NBUpList}};
%%        ({Castle1, Queue1, Study1, Barracks1, Gain1, Award, BUpList} = Args, {Type, [{SidOrNumber, Time, NeedTime, _OldBLv} | _]}) ->
%%            if
%%                Now - Time >= NeedTime ->
%%                    if
%%                        Type =:= BarracksBSid orelse Type =:= RecoverBSid ->%士兵招募或恢复
%%                            NBarracks = building_lib:barracks_calc(SidOrNumber, Barracks, Type),
%%                            {'ok', {Castle1, lists:keydelete(Type, 1, Queue1), Study1, NBarracks, Gain1, Award, BUpList}};
%%                        true ->%科技研究,军械,36计,城墙等研究
%%                            BStudy = z_lib:get_value(Study1, Type, []),
%%                            {NStudy1, NLv} =
%%                                case lists:keyfind(SidOrNumber, 1, BStudy) of
%%                                    false ->
%%                                        {[{SidOrNumber, 1} | BStudy], 1};
%%                                    {_, Lv} ->
%%                                        {lists:keystore(SidOrNumber, 1, BStudy, {SidOrNumber, Lv + 1}), Lv + 1}
%%                                end,
%%                            {'ok', {Castle1, lists:keydelete(Type, 1, Queue1),
%%                                lists:keystore(Type, 1, Study1, {Type, NStudy1}), Barracks1, Gain1, Award, [{SidOrNumber, NLv - 1, NLv} | BUpList]}}
%%                    end;
%%                true ->
%%                    {'ok', Args}
%%            end
%%    end,
%%    Reply = z_lib:foreach(Fun, {Castle, Queue, Study, Barracks, Gain, [], []}, Queue),
%%    {Castle2, Queue2, Study2, Barracks2, Gain2, _AwardList2, _BuildUpList} = Reply,
%%    {'ok', Reply, [{Index1, Castle2}, {Index2, Queue2}, {Index3, Study2}, {Index4, Barracks2}, {Index5, Gain2}]}.
