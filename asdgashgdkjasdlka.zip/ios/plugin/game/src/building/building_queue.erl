-module(building_queue).

%%%=======================STATEMENT====================
-description("building_queue").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_start_time/1, get_need_time/1, set_need_time/2, get_consume_logs/1]).

-export([init_up/6, format_up/1, get_up_bsid/1, get_up_pos/1, get_up_qid/1]).
-export([get_up_bsid_index/0, get_up_pos_index/0, get_up_qid_index/0]).

-export([init_study/5, format_study/1, get_study_sid/1, get_study_blv/1]).
-export([get_study_sid_index/0]).

-export([init_barracks/6, format_barracks/1, get_barracks_blv/1, get_barracks_per/1, get_barracks_number/1]).

-export([init_mintage/7, format_mintage/1, get_mintage_bsid/1, get_mintage_number/1, get_mintage_type/1, get_mintage_blv/1]).
-export([get_mintage_bsid_index/0]).

-export([init_bm/6, format_bm/1, get_bm_sid/1, get_bm_number/1, get_bm_qid/1]).
-export([get_bm_qid_index/0, get_bm_sid_index/0]).

-export([init_th/5, format_th/1, get_th_number/1, get_th_tsid/1]).

-export([init_weapon/6, format_weapon/1, get_weapon_number/1, get_weapon_sid/1, get_weapon_type/1]).

-export([init_mount/6, format_mount/1, get_mount_sid/1, get_mount_award/1, get_mount_consume/1]).
-export([get_mount_sid_index/0]).

-export([init_station_barracks/7, format_station_barracks/1, get_station_barracks_gid/1, get_station_barracks_number/1,
    get_station_barracks_blv/1, get_station_barracks_per/1
]).
-export([get_station_barracks_gid_index/0]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================
-record(building_queue, {
    %% up       {BSid, Now, NeedTime, Pos, QId}
    %%study     {Sid, Now, NeedTime, BLv}
    %%barracks  {Number, Now, NeedTime, BLv}
    %%mintage   {BSid, Type, Number, Now, NeedTime1, BLv}
    %%black_market        {Qid, MSid, NeedTime, Number, Now}
    %%bw        {TSid, Number, NeedTime, Now}
    start_time = 0 :: integer(),
    need_time = 0 :: integer(),
    v1 = 0 :: integer(),
    v2 = 0 :: integer(),
    v3 = 0 :: integer(),
    v4 = 0 :: integer(),
    consume_logs = [] :: list()
}).
%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%      开始时间
%% @end
%%-------------------------------------------------------------------
get_start_time(#building_queue{start_time = StartTime}) -> StartTime.
%%-------------------------------------------------------------------
%% @doc
%%      需要时间
%% @end
%%-------------------------------------------------------------------
get_need_time(#building_queue{need_time = NeedTime}) -> NeedTime.
%%-------------------------------------------------------------------
%% @doc
%%    设置需要时间
%% @end
%%-------------------------------------------------------------------
set_need_time(BuildingQueue, NeedTime) -> BuildingQueue#building_queue{need_time = NeedTime}.
%% ----------------------------------------------------
%% @doc  
%%        建筑升级队列初始化
%% @end
%% ----------------------------------------------------
init_up(BSid, Now, NeedTime, Pos, QId, ConsumeLogs) ->
    #building_queue{start_time = Now, need_time = NeedTime, v1 = BSid, v2 = Pos, v3 = QId, consume_logs = ConsumeLogs}.

format_up(#building_queue{start_time = Now, need_time = NeedTime, v1 = BSid, v2 = Pos, v3 = QId}) ->
    {BSid, Now, NeedTime, Pos, QId}.
%%-------------------------------------------------------------------
%% @doc
%%      建筑sid
%% @end
%%-------------------------------------------------------------------
get_up_bsid(#building_queue{v1 = BSid}) -> BSid.
get_up_bsid_index() -> #building_queue.v1.
%%-------------------------------------------------------------------
%% @doc
%%      位置
%% @end
%%-------------------------------------------------------------------
get_up_pos(#building_queue{v2 = Pos}) -> Pos.
get_up_pos_index() -> #building_queue.v2.
%%-------------------------------------------------------------------
%% @doc
%%      使用队列
%% @end
%%-------------------------------------------------------------------
get_up_qid(#building_queue{v3 = QId}) -> QId.
get_up_qid_index() -> #building_queue.v3.


%%-------------------------------------------------------------------
%% @doc
%%      初始化study队列
%% @end
%%-------------------------------------------------------------------
init_study(Sid, Now, NeedTime, BLv, ConsumeLogs) ->
    #building_queue{start_time = Now, need_time = NeedTime, v1 = Sid, v2 = BLv, consume_logs = ConsumeLogs}.
format_study(#building_queue{start_time = Now, need_time = NeedTime, v1 = Sid, v2 = BLv}) ->
    {Sid, Now, NeedTime, BLv}.
%%-------------------------------------------------------------------
%% @doc
%%      study sid
%% @end
%%-------------------------------------------------------------------
get_study_sid(#building_queue{v1 = Sid}) -> Sid.
get_study_sid_index() -> #building_queue.v1.
%%-------------------------------------------------------------------
%% @doc
%%    建筑等级
%% @end
%%-------------------------------------------------------------------
get_study_blv(#building_queue{v2 = BLv}) -> BLv.


%%-------------------------------------------------------------------
%% @doc
%%    初始化兵营伤兵营队列
%% @end
%%-------------------------------------------------------------------
init_barracks(Number, Now, NeedTime, BLv, DecBuff, ConsumeLogs) ->
    #building_queue{start_time = Now, need_time = NeedTime, v1 = Number, v2 = BLv, v3 = DecBuff, consume_logs = ConsumeLogs}.
format_barracks(#building_queue{start_time = Now, need_time = NeedTime, v1 = Number, v2 = BLv}) ->
    {Number, Now, NeedTime, BLv}.

%%-------------------------------------------------------------------
%% @doc
%%      兵营伤兵营队列中数量
%% @end
%%-------------------------------------------------------------------
get_barracks_number(#building_queue{v1 = Number}) -> Number.
%%-------------------------------------------------------------------
%% @doc
%%      兵营伤兵营建筑等级
%% @end
%%-------------------------------------------------------------------
get_barracks_blv(#building_queue{v2 = BLv}) -> BLv.
%% ----------------------------------------------------
%% @doc
%%  兵营升级时候,对应的粮食消耗损益buff
%% @end
%% ----------------------------------------------------
get_barracks_per(#building_queue{v3 = V}) -> V.

%%-------------------------------------------------------------------
%% @doc
%%    初始化兵营伤兵营队列
%% @end
%%-------------------------------------------------------------------
init_station_barracks(GId, Number, Now, NeedTime, BLv, DecBuff, ConsumeLogs) ->
    #building_queue{start_time = Now, need_time = NeedTime, v1 = GId, v2 = Number, v3 = BLv, v4 = DecBuff, consume_logs = ConsumeLogs}.
format_station_barracks(#building_queue{start_time = Now, need_time = NeedTime, v1 = GId, v2 = Number}) ->
    {GId, Number, Now, NeedTime}.
get_station_barracks_gid_index() -> #building_queue.v1.
get_station_barracks_gid(#building_queue{v1 = GId}) -> GId.
get_station_barracks_number(#building_queue{v2 = Number}) -> Number.
get_station_barracks_blv(#building_queue{v3 = BLv}) -> BLv.
get_station_barracks_per(#building_queue{v4 = V}) -> V.

%%-------------------------------------------------------------------
%% @doc
%%      铸币所
%% @end
%%-------------------------------------------------------------------
init_mintage(BSid, Type, Number, Now, NeedTime, BLv, ConsumeLogs) ->
    #building_queue{start_time = Now, need_time = NeedTime, v1 = BSid, v2 = Type, v3 = Number, v4 = BLv, consume_logs = ConsumeLogs}.
format_mintage(#building_queue{start_time = Now, need_time = NeedTime, v1 = BSid, v2 = Type, v3 = Number, v4 = BLv}) ->
    {BSid, Type, Number, Now, NeedTime, BLv}.

get_mintage_bsid(#building_queue{v1 = BSid}) -> BSid.
get_mintage_bsid_index() -> #building_queue.v1.
get_mintage_type(#building_queue{v2 = Type}) -> Type.
get_mintage_number(#building_queue{v3 = Number}) -> Number.
get_mintage_blv(#building_queue{v4 = BLv}) -> BLv.


%%-------------------------------------------------------------------
%% @doc
%%    黑市
%% @end
%%-------------------------------------------------------------------
init_bm(Qid, MSid, NeedTime, Number, Now, ConsumeLogs) ->
    #building_queue{start_time = Now, need_time = NeedTime, v1 = Qid, v2 = MSid, v3 = Number, consume_logs = ConsumeLogs}.
format_bm(#building_queue{start_time = Now, need_time = NeedTime, v1 = Qid, v2 = MSid, v3 = Number}) ->
    {Qid, MSid, NeedTime, Number, Now}.

get_bm_qid(#building_queue{v1 = QId}) -> QId.
get_bm_qid_index() -> #building_queue.v1.
get_bm_sid(#building_queue{v2 = Sid}) -> Sid.
get_bm_sid_index() -> #building_queue.v2.
get_bm_number(#building_queue{v3 = Number}) -> Number.


%%-------------------------------------------------------------------
%% @doc
%%    宝物
%% @end
%%-------------------------------------------------------------------
init_th(TSid, Number, NeedTime, Now, ConsumeLogs) ->
    #building_queue{start_time = Now, need_time = NeedTime, v1 = TSid, v2 = Number, consume_logs = ConsumeLogs}.
format_th(#building_queue{start_time = Now, need_time = NeedTime, v1 = TSid, v2 = Number}) ->
    {TSid, Number, NeedTime, Now}.
get_th_tsid(#building_queue{v1 = TSid}) -> TSid.
get_th_number(#building_queue{v2 = Number}) -> Number.
%%-------------------------------------------------------------------
%% @doc
%%     兵器库
%% @end
%%-------------------------------------------------------------------
init_weapon(Type, Sid, Num, NeedTime, Now, ConsumeLogs) ->
    #building_queue{start_time = Now, need_time = NeedTime, v1 = Sid, v2 = Num, v3 = Type, consume_logs = ConsumeLogs}.
format_weapon(#building_queue{start_time = Now, need_time = NeedTime, v1 = Sid, v2 = Num, v3 = Type}) ->
    {Type, Sid, Num, NeedTime, Now}.
get_weapon_sid(#building_queue{v1 = Sid}) -> Sid.
get_weapon_number(#building_queue{v2 = Number}) -> Number.
get_weapon_type(#building_queue{v3 = Type}) -> Type.

%%-------------------------------------------------------------------
%% @doc
%%     马场
%% @end
%%-------------------------------------------------------------------
init_mount(Sid, Now, NeedTime, Consumes, Award, ConsumeLogs) ->
    #building_queue{start_time = Now, need_time = NeedTime, v1 = Sid, v2 = Award, v3 = Consumes, consume_logs = ConsumeLogs}.
format_mount(#building_queue{start_time = Now, need_time = NeedTime, v1 = Sid}) ->
    {Sid, Now, NeedTime}.
get_mount_sid(#building_queue{v1 = Sid}) -> Sid.
get_mount_sid_index() -> #building_queue.v1.
get_mount_award(#building_queue{v2 = Award}) -> Award.
get_mount_consume(#building_queue{v3 = Consume}) -> Consume.

%%-------------------------------------------------------------------
%% @doc
%%     获得建筑队列消耗信息
%% @end
%%-------------------------------------------------------------------
get_consume_logs(#building_queue{consume_logs = ConsumeLogs}) -> ConsumeLogs.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------


