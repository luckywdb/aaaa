-module(building_lib).

%%%=======================STATEMENT====================
-description("建筑工具").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_bsid/1, check_gain_info/4, barracks_calc/3,
    quick_consume/2, quick_res2rmb/1, quick_time2rmb/1, get_max_flourish/4, get_max_flourish/2, get_add_flourish/3]).
-export([check/3, consume/3, convert_rmb/2, check_pos_type_num/4, get_polity_addper/1, get_del_flourish_var/1, consume_log_to_consume/1]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%     获取各建筑sid
%% @end
%% ----------------------------------------------------
-spec get_bsid(Type) -> integer() when Type :: atom().
get_bsid(Type) ->
    BType = case Type of
        'main' ->%主城府
            'main_building';
        'science' ->%技法所
            'science_building';
        'barracks' ->%兵营
            'barracks_building';
        'ordnance' ->%军械所
            'ordnance_building';
        'recover' ->%伤兵营
            'recover_building';
        'warehouse' ->%仓库
            'warehouse_building';
        'skill36' ->%军师营（36计）
            'skill36_building';
        'wall' ->%城墙
            'wall_building';
        'black_market' ->%黑市
            'black_market_building';
        'treasure' -> %藏宝阁
            'treasure_building';
        'mintage' ->%铸币所
            'mintage_building';
        'weapon' ->%%兵器库
            'weapon_building';
        'mount' -> %%马场
            'mount_building'
    end,
    element(2, zm_config:get('building_info', BType)).

%% ----------------------------------------------------
%% @doc
%%     建筑解锁,判断是否为资源类型建筑,并将该建筑加入收获列表
%% @end
%% ----------------------------------------------------
-spec check_gain_info(GainList, Sid, BType, Lv) -> [{integer(), {integer(), integer(), integer()}}] when
    GainList :: list(),
    Sid :: integer(),
    BType :: integer(),
    Lv :: integer().
check_gain_info(GainList, Sid, BType, 0) ->
    ResTypes = element(2, zm_config:get('building_info', 'res_type')),
    case lists:member(BType, ResTypes) of
        true ->
            Now = time_lib:now_second(),
            lists:keystore(Sid, 1, GainList, {Sid, {Now, 0, Now}});
        false ->
            GainList
    end;
check_gain_info(GainList, _, _, Lv) when Lv > 0 ->
    GainList.

%% ----------------------------------------------------
%% @doc
%%     兵营招募或伤兵恢复
%% @end
%% ----------------------------------------------------
-spec barracks_calc(Number, Barracks, BSid) -> barracks:barracks() when
    Number :: integer(),
    Barracks :: barracks:barracks(),
    BSid :: integer().
barracks_calc(Number, Barracks, BSid) ->
    BarracksSid = get_bsid('barracks'),
    NBarracks = barracks:set_leisure(Barracks, barracks:get_leisure(Barracks) + Number),
    if
        BSid =:= BarracksSid ->
            NBarracks;
        true ->
            barracks:set_injured(NBarracks, barracks:get_injured(Barracks) - Number)
    end.

%% ----------------------------------------------------
%% @doc
%%     根据资源,时间消耗换算成需要的rmb
%% @end
%% ----------------------------------------------------
-spec quick_consume(Consume, NeedTime) -> list() when
    Consume :: list(),
    NeedTime :: integer().
quick_consume(Consume, NeedTime) ->
    NeedRmb = quick_res2rmb(Consume) + quick_time2rmb(NeedTime),
    if
        NeedRmb > 0 ->
            [{'rmb', NeedRmb}];
        true ->
            []
    end.

%% ----------------------------------------------------
%% @doc
%%     根据资源换算成需要的rmb
%% @end
%% ----------------------------------------------------
-spec quick_res2rmb(list()) -> integer().
quick_res2rmb(Consume) ->
    F = fun(A, {_, Value}) ->
        {'ok', A + convert_rmb('resource_rmb', Value)}
    end,
    z_lib:foreach(F, 0, Consume).

%% ----------------------------------------------------
%% @doc
%%     根据时间消耗换算成需要的rmb
%% @end
%% ----------------------------------------------------
-spec quick_time2rmb(Time :: integer()) -> integer().
quick_time2rmb(Time) ->
    convert_rmb('time_rmb', Time).

%% ----------------------------------------------------
%% @doc
%%     得到最大繁荣度(restore中用)
%% @end
%% ----------------------------------------------------
-spec get_max_flourish(any(), atom(), role:role(), 'flourish') -> integer().
get_max_flourish(_, Src, Role, 'flourish') ->
    RoleUid = role:get_uid(Role),
    get_max_flourish(Src, RoleUid).

%% ----------------------------------------------------
%% @doc
%%      最大繁荣度
%% @end
%% ----------------------------------------------------
get_max_flourish(Src, RoleUid) ->
    Castle = castle_db:get_castle(Src, RoleUid),
    {_, Args} = zm_config:get('restore', 'flourish'),
    Default = z_lib:get_value(Args, 'default', 0),
    lists:foldl(fun({_, BSid, Level, _}, C) ->
        Building = zm_config:get('building', BSid),
        building:get_flourish(Building, 1, Level) + C
    end, Default, castle:get_building(Castle)).

%% ----------------------------------------------------
%% @doc
%%     得到繁荣度增加(restore中用),List中的科技/36计等需要排除
%% @end
%% ----------------------------------------------------
-spec get_add_flourish(any(), 'flourish', list()) -> integer().
get_add_flourish(_, 'flourish', List) ->
    lists:foldl(fun({BSid, OldLevel, NewLevel}, C) ->
        case building:get_cfg(BSid) of
            'none' ->
                C;
            Building ->
                building:get_flourish(Building, OldLevel + 1, NewLevel) + C
        end
    end, 0, List).

%% ----------------------------------------------------
%% @doc
%%     检测条件 建筑升级,科技研究,36计,军械,城墙,招募兵,治疗伤兵
%% @end
%% ----------------------------------------------------
-spec check(term(), term(), tuple()) -> boolean().
check({_Role, _Building, Rmb}, _, {'rmb', NeedRmb}) ->%增加临时队列,消耗,秒cd资源消耗
    rmb_lib:get_rmb(Rmb) >= NeedRmb;
check({Role, _Building, _Rmb}, _, {'role_lv', V}) ->%升级,检测主公等级
    game_lib:get_level('role', Role) >= V;
check({Role, _Building, _Rmb}, _, {'wood', V}) ->%升级,检测木材
    role:get_wood(Role) >= V;
check({Role, _Building, _Rmb}, _, {'forage', V}) ->%升级,检测粮草
    role:get_forage(Role) >= V;
check({Role, _Building, _Rmb}, _, {'mineral', V}) ->%升级,检测矿石
    role:get_mineral(Role) >= V;
check({Role, _Building, _Rmb}, _, {'iron', V}) ->%升级,检测铁
    role:get_iron(Role) >= V;
check({Role, _Building, _Rmb}, _, {'cb_wood', V}) ->%升级,检测跨服木材
    role:get_cb_wood(Role) >= V;
check({Role, _Building, _Rmb}, _, {'cb_forage', V}) ->%升级,检测跨服粮草
    role:get_cb_forage(Role) >= V;
check({Role, _Building, _Rmb}, _, {'cb_mineral', V}) ->%升级,检测跨服矿石
    role:get_cb_mineral(Role) >= V;
check({Role, _Building, _Rmb}, _, {'cb_iron', V}) ->%升级,检测跨服铁
    role:get_cb_iron(Role) >= V;
check({_Role, Building, _Rmb}, _, {'building_type', TLvList}) ->%升级,检测要求的建筑类型的任意1建筑的等级是否满足
    F = fun(A, {Type, Lv}) ->
        case Lv =< 0 of
            true ->
                {ok, A};
            false ->
                Bool = lists:any(fun({_, Sid, NLv, _}) ->
                    Build = building:get_cfg(Sid),
                    Type =:= building:get_type(Build) andalso NLv >= Lv
                end, Building),
                if
                    Bool ->
                        {'ok', A};
                    true ->
                        {'break', false}
                end
        end
    end,
    z_lib:foreach(F, true, TLvList);
check({Rmb}, 'buy_tmp_queue', {'rmb', NeedRmb}) ->
    rmb_lib:get_rmb(Rmb) >= NeedRmb;

check({TDStorage, _, TMStorage}, 'treasure_house', {'prop', {Sid, Number}}) ->
%%    由Sid获取type,
    case prop_kit_lib:get_prop_type(prop_kit_lib:get_prop(Sid)) of
        'treasure_material' ->
            storage_lib:exist_by_sid(TMStorage, {Sid, Number});
        'treasure_draw' ->
            storage_lib:exist_by_sid(TDStorage, {Sid, Number});
        _ ->
            false
    end;

check({GoodStorage}, 'reduce_queue_time', {'prop', {Sid, Value}}) ->
    storage_lib:exist_by_sid(GoodStorage, {Sid, Value});

check(_, _, _) ->
    false.

%% ----------------------------------------------------
%% @doc
%%     消耗
%% @end
%% ----------------------------------------------------
-spec consume(term(), term(), tuple()) -> {'none'|tuple(), tuple()}.
consume({Role, Rmb}, _, {'rmb', NeedRmb}) ->%升级,临时队列扣rmb,秒cd资源消耗
    {CRS, NRmb} = rmb_lib:reduct_rmb(Rmb, NeedRmb),
    {CRS, {Role, NRmb}};
consume({Role, Rmb}, _, {'wood', Value}) ->%升级,扣木材
    {BiCs, Role1} = role_lib:deduct_wood(Role, Value),
    {BiCs, {Role1, Rmb}};
consume({Role, Rmb}, _, {'forage', Value}) ->%升级,扣粮草
    {BiCs, Role1} = role_lib:deduct_forage(Role, Value),
    {BiCs, {Role1, Rmb}};
consume({Role, Rmb}, _, {'mineral', Value}) ->%升级,扣矿石
    {BiCs, Role1} = role_lib:deduct_mineral(Role, Value),
    {BiCs, {Role1, Rmb}};
consume({Role, Rmb}, _, {'iron', Value}) ->%升级,扣铁
    {BiCs, Role1} = role_lib:deduct_iron(Role, Value),
    {BiCs, {Role1, Rmb}};
consume({Role, Rmb}, _, {'cb_wood', Value}) ->%升级,扣跨服木材
    {BiCs, Role1} = role_lib:deduct_cb_wood(Role, Value),
    {BiCs, {Role1, Rmb}};
consume({Role, Rmb}, _, {'cb_forage', Value}) ->%升级,扣跨服粮草
    {BiCs, Role1} = role_lib:deduct_cb_forage(Role, Value),
    {BiCs, {Role1, Rmb}};
consume({Role, Rmb}, _, {'cb_mineral', Value}) ->%升级,扣跨服矿石
    {BiCs, Role1} = role_lib:deduct_cb_mineral(Role, Value),
    {BiCs, {Role1, Rmb}};
consume({Role, Rmb}, _, {'cb_iron', Value}) ->%升级,扣跨服铁
    {BiCs, Role1} = role_lib:deduct_cb_iron(Role, Value),
    {BiCs, {Role1, Rmb}};
consume({Rmb}, 'buy_tmp_queue', {'rmb', NeedRmb}) ->
    {CRS, NRmb} = rmb_lib:reduct_rmb(Rmb, NeedRmb),
    {CRS, {NRmb}};

consume({TDStorage, TMStorage}, 'treasure_house', {'prop', {Sid, Number}}) ->
    case prop_kit_lib:get_prop_type(prop_kit_lib:get_prop(Sid)) of
        'treasure_material' ->
            {BiCs, NTMStorage} = storage_lib:deduct_by_sid(TMStorage, {Sid, Number}),
            {BiCs, {TDStorage, NTMStorage}};
        _ ->
            {BiCs, NTDStorage} = storage_lib:deduct_by_sid(TDStorage, {Sid, Number}),
            {BiCs, {NTDStorage, TMStorage}}
    end;

consume({GoodStorage}, 'reduce_queue_time', {'prop', {Sid, Value}}) ->
    {Cs, NGoodStorage} = storage_lib:deduct_by_sid(GoodStorage, {Sid, Value}),
    {Cs, {NGoodStorage}};

consume(Table, _, _) ->%外部条件不需处理
    {'none', Table}.

%% ----------------------------------------------------
%% @doc
%%     建筑,pos解锁检测
%% @end
%% ----------------------------------------------------
check_pos_type_num(Building, BLv, Pos, BuildType) ->
    if
        BLv > 0 ->
            true;
        true ->
            MainSid = get_bsid('main'),
            MainLv = castle:get_buildlv(Building, MainSid),
            {_, PosList} = zm_config:get('main_building', 'pos'),
            NeedLv = z_lib:get_value(PosList, Pos, 0),
            if
                MainLv >= NeedLv ->
                    {_, _, MBTList} = zm_config:get('main_building', MainLv),
                    case z_lib:get_value(MBTList, BuildType, 'none') of
                        'none' ->
                            true;
                        TypeNum ->
                            BTypeNum = z_lib:foreach(fun(A, {_, Bsid, _, _}) ->
                                Build = building:get_cfg(Bsid),
                                case building:get_type(Build) =:= BuildType of
                                    true ->
                                        {'ok', A + 1};
                                    false ->
                                        {'ok', A}
                                end
                            end, 0, Building),
                            BTypeNum + 1 =< TypeNum
                    end;
                true ->
                    false
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      政治影响速度公式: 75%*r/（r+300）
%% @end
%% ----------------------------------------------------
get_polity_addper(Polity) ->
    {_, {Per, Coe}} = zm_config:get('building_info', 'polity'),
    game_lib:ceil(Per * Polity * 10000 / (Polity * 10000 + Coe)).

%% ----------------------------------------------------
%% @doc
%%     根据攻击获取扣除繁荣度值
%% @end
%% ----------------------------------------------------
get_del_flourish_var(Attack) ->
    Attack.
%% ----------------------------------------------------
%% @doc
%%     根据消耗日志获得消耗
%% @end
%% ----------------------------------------------------
consume_log_to_consume(ConsumeLogs) ->
    Fun = fun({Type, Value, _}, R) ->
        [{Type, Value} | R];
        (ConsumeLog, R) ->
            [ConsumeLog | R]
    end,
    lists:foldl(Fun, [], ConsumeLogs).
%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%      资源,时间折算成rmb
%%      y=a(n)×[x(n)-t(n-1)]+b(n-1) ******* y向上取整 (建筑的免费时间vip中去处理)
%%      a(n)=(b(n)-b(n-1))/[t(n)-t(n-1)]
%% @end
%% ----------------------------------------------------
convert_rmb(ConfigName, Value) ->
    {_, List} = zm_config:get('building_info', ConfigName),
    F = fun(A, {{Tn1, Tn}, {Bn, Bn1}}) ->
        if
            Tn1 < Value andalso Value =< Tn ->
                {'break', game_lib:ceil(((Bn - Bn1) / (Tn - Tn1)) * (Value - Tn1)) + Bn1};
            Tn1 < Value andalso Tn =:= 0 ->
                NTn = z_lib:get_value(element(2, zm_config:get('building_info', 'res_time_rmb')), ConfigName, 0),
                {'break', game_lib:ceil(((Bn - Bn1) / (NTn - Tn1)) * (Value - Tn1)) + Bn1};
            true ->
                A
        end
    end,
    z_lib:foreach(F, 0, List).
