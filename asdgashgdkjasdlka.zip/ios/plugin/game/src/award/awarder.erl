%%奖励制造者
-module(awarder).
-description("awarder").
-copyright({seasky, 'www.seasky.cn'}).
-author({cb, 'chenbin@youkia.net'}).
-vsn(1).
%%%=======================EXPORT=======================
-export([get/4, get/5, give_award/1, give_award/4, give_award/5, give_award_split/5, give_award_by_table/5, give_award_by_table/6,
    award_total_item/1, award_total_item/2, merge_item/2]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================
%%奖励头
-define(AWARD_HANDLER, list_to_existing_atom(lists:concat([Src, ".award_handler"]))).
%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%% Description: 生成多次奖励的随机条目
%%@param Number 随机奖励条目次数
%%@param Award 奖励或奖励条目
%% Returns:  list.
%% @end
%% ----------------------------------------------------
-spec award_total_item(Award) -> list() when
    Award :: list().
award_total_item(Award) ->
    award_total_item(Award, 1).
award_total_item(Award, Number) ->
    award_lib:award_total_item(Award, Number, []).

%%---------------------------------------------------
%% @doc
%%      进行角色奖励,通过award
%% @end
%%----------------------------------------------------
-spec get(Src, RoleUid, Args, Award) -> {RoleUid, Args, [{term(), atom(), integer()|tuple()}]} when
    Src :: atom(),
    RoleUid :: integer(),
    Args :: term(),
    Award :: list().
get(Src, RoleUid, Args, Award) ->
    get(Src, RoleUid, Args, Award, 1).

%%---------------------------------------------------
%% @doc
%%      进行角色奖励(多次),通过award
%% @end
%%----------------------------------------------------
-spec get(Src, RoleUid, Args, Award, Number) -> {RoleUid, Args, [{term(), atom(), integer()|tuple()}]} when
    Src :: atom(),
    RoleUid :: integer(),
    Args :: term(),
    Award :: list(),
    Number :: integer().
get(Src, RoleUid, Args, Award, Number) ->
    award_lib:get(?AWARD_HANDLER, RoleUid, Args, Award, Number).

%%---------------------------------------------------
%% @doc
%%      进行角色奖励,通过award的sid
%% @end
%%----------------------------------------------------
-spec give_award(Award) -> tuple() when
    Award :: {integer(), term(), list()}.
give_award({_RoleUid, _Args, _AwardExpend} = Award) ->
    game_lib:arrange_award_logs(award_lib:give(Award)).

%%---------------------------------------------------
%% @doc
%%      进行角色奖励
%% @end
%%----------------------------------------------------
-spec give_award(Src, RoleUid, Args, Award) -> tuple() when
    Src :: atom(),
    RoleUid :: integer(),
    Args :: term(),
    Award :: list().
give_award(Src, RoleUid, Args, Award) when is_integer(RoleUid) ->
    give_award(Src, RoleUid, Args, Award, 1).
%%---------------------------------------------------
%% @doc
%%      进行角色奖励(多次)
%% @end
%%----------------------------------------------------
-spec give_award(Src, RoleUid, Args, Award, Number) -> tuple() when
    Src :: atom(),
    RoleUid :: integer(),
    Args :: term(),
    Award :: list(),
    Number :: integer().
give_award(Src, RoleUid, Args, Award, Number) when is_integer(RoleUid) ->
    game_lib:arrange_award_logs(award_lib:give(?AWARD_HANDLER, RoleUid, Args, Award, Number)).

%%---------------------------------------------------
%% @doc
%%      进行角色奖励,指定奖励配置中的表名
%% @end
%%----------------------------------------------------
-spec give_award_by_table(Src, Table, RoleUid, Args, Sid) -> tuple() when
    Src :: atom(),
    Table :: atom(),
    RoleUid :: integer(),
    Args :: term(),
    Sid :: integer().
give_award_by_table(Src, Table, RoleUid, Args, Sid) when is_atom(Table) ->
    give_award_by_table(Src, Table, RoleUid, Args, Sid, 1).
%%---------------------------------------------------
%% @doc
%%      进行角色奖励(多次),指定奖励配置中的表名
%% @end
%%----------------------------------------------------
-spec give_award_by_table(Src, Table, RoleUid, Args, Sid, Number) -> tuple() when
    Src :: atom(),
    Table :: atom(),
    RoleUid :: integer(),
    Args :: term(),
    Sid :: integer(),
    Number :: integer().
give_award_by_table(Src, Table, RoleUid, Args, Sid, Number) when is_atom(Table) ->
    {_, Award} = zm_config:get(Table, Sid),
    game_lib:arrange_award_logs(award_lib:give(?AWARD_HANDLER, RoleUid, Args, Award, Number)).

%%---------------------------------------------------
%% @doc
%%      进行角色奖励(多次奖励,并返回每一次奖励的详细信息)
%% @end
%%----------------------------------------------------
-spec give_award_split(Src, RoleUid, Args, Award, Number) -> tuple() when
    Src :: atom(),
    RoleUid :: integer(),
    Args :: term(),
    Award :: list(),
    Number :: integer().
give_award_split(Src, RoleUid, Args, Award, Number) when is_integer(RoleUid) ->
    {R, S} = award_lib:give_split(?AWARD_HANDLER, RoleUid, Args, Award, Number),
    {game_lib:arrange_award_logs(R), list_to_tuple(S)}.

%%---------------------------------------------------
%% @doc
%%      合并奖励条目
%% @end
%%----------------------------------------------------
-spec merge_item(list(), list()) -> list().
merge_item([H | T], R) ->
    merge_item(T, merge_item_(H, R, []));
merge_item([], R) ->
    R.
%%---------------------------------------------------
%% @doc
%%      合并奖励条目辅助
%% @end
%%----------------------------------------------------
-spec merge_item_({Type, Value}, T, R) -> list() when
    Type :: atom(),
    Value :: integer()|{integer(), integer()},
    T :: list(),
    R :: list().
merge_item_({'prop', {Sid, N1}}, [{'prop', {Sid, N2}} | T], R) ->
    lists:reverse([{'prop', {Sid, N1 + N2}} | R], T);
merge_item_({Type, N1}, [{Type, N2} | T], R) when is_integer(N1), is_integer(N2) ->
    lists:reverse([{Type, N1 + N2} | R], T);
merge_item_(Item, [Item1 | T], R) ->
    merge_item_(Item, T, [Item1 | R]);
merge_item_(H, [], R) ->
    [H | R].
%%%===================LOCAL FUNCTIONS==================
