-module(award_source).
-description("解析奖励来源,用于邮件解析").
-copyright('youkia,www.youkia.net').
-author("zjx,zhaojunxian@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_source/1, get_res_source/1, get_res_type/1, get_res_fun_by_type/1]).
%%%=======================INCLUDE======================

%%%=======================RECORD=======================
%% gm发送系统邮件,-1|gm包裹增加东西溢出,-2|未知,0|任务,1|活动,2|武将卡牌,3|充值,4|装备,5|开宝箱,6|商店,7|武将分解重生,装备分解,8|官职,9|战斗战报,10|采集,11|侦查,12|空战报,13|军团邮件,14|大地图战斗,15|
%% 寻访信息,16|城池城墙,17|充值返利,18|城池首占,19|君主,22|平台活动,21 ,22|攻城新邮件 被建筑击飞23 | 合服24 | 跨服25
-define(SOURCE, [{"achieve", 1}, {"active", 2}, {"card", 3}, {"cash", 4}, {"equipment", 5}, {"box", 6}, {"shop", 7},
    {"resolve", 8}, {"official", 9}, {"gm", -2}, {"reportfight", 10}, {"reportcollect", 11}, {"reportspy", 12},
    {"reportnull", 13}, {"corps", 14}, {"fighting", 15}, {"reportlook", 16}, {"reportwall", 17}, {"rebate", 18},
    {"town", 19}, {"monarch", 20}, {"platform", 21}, {"new_town", 22}, {"reportmbfly", 23}, {"merge", 24}, {"cross", 25}]).
-define(RES_SOURCE, [{"box_goods", 'safe'}, {"role_gift_db", 'safe'}]).
-define(RES_FUN, [{'wood', "get_not_safe_"}, {'forage', "get_not_safe_"}, {'mineral', "get_not_safe_"}, {'iron', "get_not_safe_"}]).
%%%=======================DEFINE=======================

%%%=================EXPORTED FUNCTIONS=================
%%---------------------------------------------------
%% @doc
%%      获得资源方法名
%% @end
%%----------------------------------------------------
get_res_fun_by_type(Type) ->
    case lists:keyfind(Type, 1, ?RES_FUN) of
        false ->
            string_lib:to_atom("get_", Type);
        {_, Value} ->
            string_lib:to_atom(Value, Type)
    end.
%%---------------------------------------------------
%% @doc
%%      获得资源类型(安全和非安全转换为同一类型)
%% @end
%%----------------------------------------------------
get_res_type(Module) when is_atom(Module) ->
    SModule = string_lib:to_string(Module),
    case string:chr(SModule, $_) of
        0 ->
            Module;
        Index ->
            string_lib:to_atom(lists:sublist(SModule, Index - 1))
    end;
get_res_type(Module) ->
    case string:chr(Module, $_) of
        0 ->
            Module;
        Index ->
            string_lib:to_atom(lists:sublist(Module, Index - 1))
    end.

%%---------------------------------------------------
%% @doc
%%      通过模块名获得资源源
%% @end
%%----------------------------------------------------
get_res_source(Module) when is_atom(Module) ->
    SModule = string_lib:to_string(Module),
    case lists:keyfind(SModule, 1, ?RES_SOURCE) of
        false ->
            'not_safe';
        {_, Value} ->
            Value
    end;
get_res_source(Module) ->
    case lists:keyfind(Module, 1, ?RES_SOURCE) of
        false ->
            'not_safe';
        {_, Value} ->
            Value
    end.

%%---------------------------------------------------
%% @doc
%%      通过模块名获得源
%% @end
%%----------------------------------------------------
-spec get_source(Module) -> integer() when
    Module :: atom() | string().
get_source(Module) when is_atom(Module) ->
    SModule = string_lib:to_string(Module),
    Type = case string:chr(SModule, $_) of
        0 ->
            SModule;
        Index ->
            lists:sublist(SModule, Index - 1)
    end,
    case lists:keyfind(Type, 1, ?SOURCE) of
        false ->
            0;
        {_, Value} ->
            Value
    end;
get_source(Module) ->
    case lists:keyfind(Module, 1, ?SOURCE) of
        false ->
            0;
        {_, Value} ->
            Value
    end.


%%%===================LOCAL FUNCTIONS==================

