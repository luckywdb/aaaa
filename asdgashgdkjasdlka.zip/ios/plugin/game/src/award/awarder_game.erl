%%三国志奖励模块
-module(awarder_game).

%%%=======================STATEMENT====================
-description("awarder_game").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([get_award_list/1]).
-export([get_advance_award/4, get_advance_award/5, format_award/1]).
-export([give_award/1, give_award/4, give_award/5, give_award_split/5]).
-export([give_award_by_table/5, give_award_by_table/6]).
-export([give_role_award/4]).
-export([merger/2, get_lv_award/3, award_total_item/2, award_total_item/3, level_pool/2]).
-export([check_award/2, check_resource/2, check_prop/2, check_month_card/2, award_multiple/2, award_percent/2]).
-export([award_item/1]).

-export_type([award_type/0]).
%%%=======================INCLUDE======================

%%%=======================RECORD======================

%%%=======================DEFINE=======================
-define(AWARD_HANDLER, list_to_existing_atom(lists:concat([Src, ".award_handler"]))). %%奖励头
-define(RESOURCE_MIN, 0). %%单次奖励资源最小值
-define(RESOURCE_MAX, 210000000). %%单次奖励资源最大值
-define(UID_PROP_MAX, 500).%单次奖励uid类型的道具个数最多500

%%%=======================TYPE=========================
-type award_type() :: {integer(), integer()}.

%%%=================EXPORTED FUNCTIONS=================
%%---------------------------------------------------
%% @doc
%%      得到'role_award'奖励列表
%% @end
%%----------------------------------------------------
-spec get_award_list(AwarSid) -> list() when
    AwarSid :: integer().
get_award_list(AwarSid) when is_integer(AwarSid) ->
    case zm_config:get('role_award', AwarSid) of
        none ->
            throw(lists:concat(["no_role_award_sid_", AwarSid]));
        {_, List} ->
            List
    end.
%%---------------------------------------------------
%% @doc
%%      奖励预处理，'role_award'奖励
%% @end
%%----------------------------------------------------
-spec get_advance_award(Src, RoleUid, Args, AwarSid) -> {list(), tuple()} when Src :: atom(),
    RoleUid :: integer(),
    Args :: term(),
    AwarSid :: integer()|list().
get_advance_award(Src, RoleUid, Args, AwarSid) when is_integer(AwarSid) ->
    get_advance_award(Src, 'role_award', RoleUid, Args, AwarSid);
get_advance_award(Src, RoleUid, Args, AwarList) when is_list(AwarList) ->
    Award = awarder:get(Src, RoleUid, Args, AwarList),
    {_, _, AwardExpend} = Award,
    AdvanceAward = [{Type, Value} || {_, Type, Value} <- AwardExpend],
    {AdvanceAward, Award}.

%%---------------------------------------------------
%% @doc
%%      奖励预处理，
%% @end
%%----------------------------------------------------
-spec get_advance_award(Src, Table, RoleUid, Args, AwarSid) -> {list(), tuple()} when
    Src :: atom(),
    Table :: atom(),
    RoleUid :: integer(),
    Args :: term(),
    AwarSid :: integer().
get_advance_award(Src, Table, RoleUid, Args, AwarSid) when is_integer(AwarSid) ->
    Award = case zm_config:get(Table, AwarSid) of
        none ->
            throw(lists:concat(["no_", Table, "_awardsid_", AwarSid]));
        {_, List} ->
            List
    end,
    get_advance_award(Src, RoleUid, Args, Award).

%%---------------------------------------------------
%% @doc
%%      进行角色奖励,通过预奖励(get_advance_award)获得奖励
%% @end
%%----------------------------------------------------
-spec give_award(Award :: tuple()) -> tuple().
give_award({}) ->
    {};
give_award(Award) ->
    awarder:give_award(Award).

%%---------------------------------------------------
%% @doc
%%      进行角色奖励，不能发预奖励处理过的奖励，否则会重复扩展
%% @end
%%----------------------------------------------------
-spec give_award(Src, RoleUid, Args, Award) -> tuple() when
    Src :: atom(),
    RoleUid :: integer(),
    Args :: term(),
    Award :: list()|integer().
give_award(Src, RoleUid, Args, AwardSid) when is_integer(AwardSid) ->
    give_award(Src, RoleUid, Args, get_award_list(AwardSid));
give_award(_Src, _RoleUid, _Args, []) ->
    {};
give_award(Src, RoleUid, Args, AwardList) ->
    awarder:give_award(Src, RoleUid, Args, AwardList).

%%---------------------------------------------------
%% @doc
%%      进行角色奖励,通过award的sid(只能role_award奖励)
%% @end
%%----------------------------------------------------
-spec give_award(Src, RoleUid, Args, AwardList, Number) -> tuple() when
    Src :: atom(),
    RoleUid :: integer(),
    Args :: term(),
    AwardList :: list()|integer(),
    Number :: integer().
give_award(Src, RoleUid, Args, AwardSid, Number) when is_integer(AwardSid) ->
    awarder:give_award(Src, RoleUid, Args, get_award_list(AwardSid), Number);
give_award(_Src, _RoleUid, _Args, [], _Number) ->
    {};
give_award(Src, RoleUid, Args, AwardList, Number) ->
    awarder:give_award(Src, RoleUid, Args, AwardList, Number).

%%---------------------------------------------------
%% @doc
%%      进行角色奖励,(多倍奖励,并将每次具体奖励信息返回)
%% @end
%%----------------------------------------------------
-spec give_award_split(Src, RoleUid, Args, AwardList, Number) -> {tuple(), tuple()} when
    Src :: atom(),
    RoleUid :: integer(),
    Args :: term(),
    AwardList :: list(),
    Number :: integer().
give_award_split(Src, RoleUid, Args, AwardList, Number) ->
    awarder:give_award_split(Src, RoleUid, Args, AwardList, Number).

%%---------------------------------------------------
%% @doc
%%      进行角色奖励,只能用于role_award里面的sid的奖励
%% @end
%%----------------------------------------------------
-spec give_award_by_table(Src, Table, RoleUid, Args, Sid) -> tuple() when
    Src :: atom(),
    Table :: atom(),
    RoleUid :: integer(),
    Args :: term(),
    Sid :: integer().
give_award_by_table(Src, Table, RoleUid, Args, Sid) ->
    awarder:give_award_by_table(Src, Table, RoleUid, Args, Sid).

%%---------------------------------------------------
%% @doc
%%      进行角色奖励,用于指定table的sid奖励
%% @end
%%----------------------------------------------------
-spec give_award_by_table(Src, Table, RoleUid, Args, Sid, Number) -> tuple() when
    Src :: atom(),
    Table :: atom(),
    RoleUid :: integer(),
    Args :: term(),
    Sid :: integer(),
    Number :: integer().
give_award_by_table(Src, Table, RoleUid, Args, Sid, Number) ->
    awarder:give_award_by_table(Src, Table, RoleUid, Args, Sid, Number).

%%---------------------------------------------------
%% @doc
%%      进行角色奖励,只能给予,role_award奖励,[{sid,num},...]
%% @end
%%----------------------------------------------------
-spec give_role_award(Src, RoleUid, Args, Award) -> tuple() when
    Src :: atom(),
    RoleUid :: integer(),
    Args :: term(),
    Award :: [award_type()].
give_role_award(Src, RoleUid, Args, Award) ->
    give_role_award(Src, 'role_award', RoleUid, Args, Award).

%%---------------------------------------------------
%% @doc
%%      进行角色奖励,给予table奖励,[{sid,num},...]
%% @end
%%----------------------------------------------------
-spec give_role_award(Src, Table, RoleUid, Args, Award) -> tuple() when
    Src :: atom(),
    Table :: atom(),
    RoleUid :: integer(),
    Args :: term(),
    Award :: [award_type()].
give_role_award(Src, Table, RoleUid, Args, Award) ->
    Item = give_role_award_(Table, Award, []),
    Log = award_lib:give({RoleUid, Args, award_lib:award_expand(?AWARD_HANDLER, RoleUid, Args, Item, [])}),
    game_lib:arrange_award_logs(Log).

%%---------------------------------------------------
%% @doc
%%      奖励合并
%% @end
%%----------------------------------------------------
-spec merger(AwardList1, AwardList2) -> list() when
    AwardList1 :: list(),
    AwardList2 :: list().
merger(AwardList1, AwardList2) ->
    award_lib:merger(AwardList1, AwardList2).

%%---------------------------------------------------
%% @doc
%%      根据等级获取奖励sid,配置key必须为 lv_award
%% @end
%%----------------------------------------------------
-spec get_lv_award(Src, RoleUid, AwardSid) -> integer() when
    Src :: atom(),
    RoleUid :: integer(),
    AwardSid :: integer().
get_lv_award(Src, RoleUid, AwardSid) ->
    Role = role_db:get_role(Src, RoleUid),
    Level = game_lib:get_level('role', Role),
    {_, LvAwards} = zm_config:get('lv_award', AwardSid),
    Fun = fun(_, {{MinLv, MaxLv}, Award}) ->
        Bl = Level >= MinLv andalso MaxLv >= Level,
        if
            Bl ->
                {break, Award};
            true ->
                0
        end
    end,
    z_lib:foreach(Fun, 0, LvAwards).

%%---------------------------------------------------
%% @doc
%%      生成多次奖励的条目
%% @end
%%----------------------------------------------------
-spec award_total_item(Award, Number) -> list() when
    Award :: list(),
    Number :: integer().
award_total_item(Award, Number) ->
    award_total_item(Award, Number, []).

%%---------------------------------------------------
%% @doc
%%      生成多次奖励的条目并与R进行奖励合并
%% @end
%%----------------------------------------------------
-spec award_total_item(Award, Number, R) -> list() when
    Award :: list(),
    Number :: integer(),
    R :: list().
award_total_item(Award, Number, R) ->
    award_lib:award_total_item(Award, Number, R).

%% ----------------------------------------------------
%% @doc
%%      以等级取库
%% @end
%% ----------------------------------------------------
-spec level_pool(Level, Args2) -> integer() when
    Level :: integer(),
    Args2 :: list().
level_pool(Leve, [L, Sid | _]) when Leve =< L ->
    Sid;
level_pool(_Leve, [_, Sid | []]) ->
    Sid;
level_pool(Leve, [_, _ | T]) ->
    level_pool(Leve, T).

%% ----------------------------------------------------
%% @doc
%%      检查奖励是否符合规范 true符合规范|{false,Info}不符合规范
%% @end
%% ----------------------------------------------------
-spec check_award(Src, List) -> true|{false, term()} when
    Src :: atom(),
    List :: list().
check_award(Src, [H | T]) ->
    Bl = award_lib:check_award(?AWARD_HANDLER, H),
    if
        Bl -> check_award(Src, T);
        true -> {false, H}
    end;
check_award(_, []) ->
    true.

%% ----------------------------------------------------
%% @doc
%%      检查资源是否符合规范,true符合规范|false
%% @end
%% ----------------------------------------------------
-spec check_resource(List, V) -> boolean() when
    List :: list(),
    V :: integer().
check_resource([], V) ->
    is_integer(V) andalso ?RESOURCE_MIN < V andalso V < ?RESOURCE_MAX;
check_resource([Min, Max], V) ->
    is_integer(V) andalso Min < V andalso V < Max.

%% ----------------------------------------------------
%% @doc
%%      检查道具是否符合规范,true符合规范|false
%% @end
%% ----------------------------------------------------
-spec check_prop(List, {Sid, V}) -> boolean() when
    List :: list(),
    Sid :: integer(),
    V :: integer().
check_prop([Min, Max], {Sid, V}) ->
    case prop_kit_lib:get_prop(Sid) of
        'none' ->
            false;
        Prop ->
            ChkMax =
                case prop_kit_lib:get_prop_max(Prop) of
                    1 ->
                        V =< ?UID_PROP_MAX;
                    _ ->
                        true
                end,
            ChkMax andalso is_integer(V) andalso Min < V andalso V < Max
    end.

%% ----------------------------------------------------
%% @doc
%%      检查月卡是否符合规范,true符合规范|false
%% @end
%% ----------------------------------------------------
-spec check_month_card(List, V) -> boolean() when
    List :: list(),
    V :: tuple().
check_month_card(List, {Sid, V}) ->
    is_integer(V) andalso (lists:member(Sid, List) orelse zm_config:get('cash_list', Sid) =/= 'none').

%% ----------------------------------------------------
%% @doc
%%      奖励多倍或整理(将奖励配置中所有奖励的物品*倍数/保留原概率权重)
%% @end
%% ----------------------------------------------------
-spec award_multiple(List, Multiple) -> list()|tuple() when
    List :: list(),
    Multiple :: integer().
award_multiple(AwardSid, Multiple) ->
    award_multiple(AwardSid, Multiple, 10000).

%% ----------------------------------------------------
%% @doc
%%      奖励按万分比整理(将奖励配置中所有奖励的物品*倍数/保留原概率权重)
%%      注意:如果是 rate或weight的结构,如果计算出来的数值为=<0的则该值对应的权重直接会删除.
%% @end
%% ----------------------------------------------------
-spec award_percent(Award, Percent) -> list()|tuple() when
    Award :: integer()|list(),
    Percent :: integer().
award_percent(Award, Percent) ->
    award_multiple(Award, 1, Percent).


%% ----------------------------------------------------
%% @doc
%%      奖励条目
%% @end
%% ----------------------------------------------------
-spec award_item(list()) -> list()|tuple().
award_item(Award) ->
    case award_lib:award_item(Award) of
        [[]] ->
            [];
        V ->
            V
    end.

%% ----------------------------------------------------
%% @doc
%%     前台展示奖励信息(去掉概率,权重,显示所有可能获得道具)
%% @end
%% ----------------------------------------------------
-spec format_award(Award) -> list() when
    Award :: integer()|list().
format_award(AwardSid) when is_integer(AwardSid) ->
    award_lib:award_format_item(get_award_list(AwardSid));
format_award(Award) when is_list(Award) ->
    award_lib:award_format_item(Award).

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%      循环制作预奖励
%% @end
%% ----------------------------------------------------
give_role_award_(Table, [{Sid, Num} | T], Item) ->
    {_, Award} = zm_config:get(Table, Sid),
    give_role_award_(Table, T, award_total_item(Award, Num, Item));
give_role_award_(_Table, [], Item) ->
    Item.

%% ----------------------------------------------------
%% @doc
%%      奖励多倍整理(将奖励配置中所有奖励的物品*倍数/保留原概率权重)
%% @end
%% ----------------------------------------------------
-spec award_multiple(Award, Multiple, Percent) -> list()|tuple()|'none' when
    Award :: list()|integer(),
    Multiple :: integer(),
    Percent :: integer().
award_multiple(AwardSid, Multiple, Percent) when is_integer(AwardSid) ->
    award_multiple(get_award_list(AwardSid), Multiple, Percent);
award_multiple([], _Multiple, _Percent) ->
    [];
award_multiple([rate | Award], Multiple, Percent) ->
    [rate | award_multiple_(Award, [], Multiple, Percent)];
award_multiple([weight | Award], Multiple, Percent) ->
    [weight | award_multiple_(Award, [], Multiple, Percent)];
award_multiple([average | Award], Multiple, Percent) ->
    [average | award_multiple_(Award, [], Multiple, Percent)];
award_multiple([_H | _] = Award, Multiple, Percent) ->
    lists:foldl(fun(E, Acc) ->
        case award_multiple(E, Multiple, Percent) of
            'none' ->
                Acc;
            V ->
                [V | Acc]
        end
    end, [], lists:reverse(Award));
award_multiple({Type, Min, Max}, Multiple, Percent) when is_atom(Type) ->%%具体数值
    RMin = (Min * Multiple * Percent div 10000),
    RMax = (Max * Multiple * Percent div 10000),
    if
        RMin =< 0 orelse RMax =< 0 ->
            'none';
        true ->
            {Type, (Min * Multiple * Percent div 10000), (Max * Multiple * Percent div 10000)}
    end;
award_multiple({Type, {Sid, Number}}, Multiple, Percent) when is_integer(Number) ->
    Num = (Number * Multiple * Percent div 10000),
    if
        Num =< 0 ->
            'none';
        true ->
            {Type, {Sid, Num}}
    end;
award_multiple({Type, Value}, Multiple, Percent) when is_integer(Value) ->
    Num = Value * Multiple * Percent div 10000,
    if
        Num =< 0 ->
            'none';
        true ->
            {Type, Num}
    end;
award_multiple({Type, _Args} = Item, _Multiple, _Percent) when is_atom(Type) ->
    Item.

%% ----------------------------------------------------
%% @doc
%%      奖励多倍整理
%% @end
%% ----------------------------------------------------
-spec award_multiple_(List, L, Multiple, Percent) -> list() when
    List :: list(),
    L :: list(),
    Multiple :: integer(),
    Percent :: integer().
award_multiple_([Rate, Award | T], L, Multiple, Percent) ->
    case award_multiple(Award, Multiple, Percent) of
        'none' ->
            award_multiple_(T, L, Multiple, Percent);
        V ->
            award_multiple_(T, [V, Rate | L], Multiple, Percent)
    end;
award_multiple_([], L, _Multiple, _Percent) ->
    lists:reverse(L).