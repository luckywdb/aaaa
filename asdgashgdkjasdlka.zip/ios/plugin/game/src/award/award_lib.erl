%%%奖励库函数
%%% 
%%% 每个类型的奖励表结构为{键, 奖励}，键应该根据功能来设计。比如：
%%%	如果任务奖励，则为任务ID。
%%%	如果关卡奖励，则为{关卡ID, 难度, 完成度}。
%%% 
%%% 奖励为列表结构（可循环嵌套）。
%%%	如果是全部多个奖励，则列表中的每个元素为奖励或奖励条目。
%%%	如果是多个奖励按概率都尝试取出来，则列表中的第一个必须为rate，偶数为万分率，奇数为奖励或奖励条目。
%%%	如果是多个奖励按权重取随机的一个，则列表中的第一个必须为weight，偶数为权重，奇数为奖励或奖励条目。
%%%	如果是多个奖励按平均随机的一个，则列表中的第一个必须为average，其后为奖励或奖励条目。
%%% 奖励条目分为数值型条目和对象型条目。
%%% 数值型条目为{奖励类型, 最小值, 最大值}
%%% 对象型条目为{奖励类型, 参数}，简单物品的参数为Sid，复杂物品的参数为{Sid, [数据]}
%%% 
%%% 每游戏需要配置奖励类型操作表，结构如下：
%%%	{奖励类型, 展开函数{M, F, A}, 添加函数{M, F, A}}
%%% 展开函数，M:F(A, Role, Value), 返回参数为{ok, 值} | {error, Reason}
%%%	对数值型条目而言，可引入其他参数，比如系统状态（比如双倍时间），玩家状态（比如防挂机、防沉迷状态等）的影响。
%%%	对对象型条目而言，可根据参数计算获得实际的对象奖励。
%%%
%%% 添加函数，M:F(A, Type, RoleUid, Args, Value), 返回参数为{ok, 改变值} | {error, Reason}

-module(award_lib).

-description("award lib").
-copyright({seasky, 'www.seasky.cn'}).
-author({zmyth, leo, 'zmythleo@gmail.com'}).
-vsn(1).

%%%=======================EXPORT=======================
-export([
    award_item/1,
    expand/5,
    get/5,
    give/1,
    give/5,
    give_split/5,
    award_total_item/3,
    award_expand/5,
    merger/2,
    check_award/2,
    award_format_item/1
]).
%%%=======================DEFINE=======================
-define(RAND_RATE, 10000).
%%%=================EXPORTED FUNCTIONS=================
%%---------------------------------------------------
%% @doc
%% Description: 预先随机出给指定角色的奖励
%%@param RoleUid 角色id
%%@param ObjectUid 被奖励对象id
%%@param Award 预先随机出奖励或奖励条目
%%@param Number 随机的次数
%% @end
%%----------------------------------------------------
-spec get(Table, RoleUid, Args, Award, Number) -> {RoleUid, Args, [{term(), atom(), integer()|tuple()}]} when
    Table :: atom(),
    RoleUid :: integer(),
    Args :: term(),
    Award :: list(),
    Number :: integer().
get(Table, RoleUid, Args, Award, Number) ->
    {RoleUid, Args, award_expand(Table, RoleUid, Args, award_total_item(Award, Number, []), [])}.

%% ----------------------------------------------------
%% @doc
%% Description: 通过预先随机出的奖励给指定的角色
%%@param RoleUid 角色id
%%@param ObjectUid 被奖励对象id
%%@param Award 奖励或奖励条目
%%@param Number 随机的次数
%% Returns:  {ok, ResultList, ChangeList} | {error, Reason} | {error, Reason, StackTrace}.
%% @end
%% ----------------------------------------------------
-spec give({RoleUid, Args, AwardExpend}) -> list() when
    RoleUid :: integer(),
    Args :: term(),
    AwardExpend :: [{term(), atom(), integer()|tuple()}].
give({RoleUid, Args, AwardExpend}) ->
    award_fun(RoleUid, Args, AwardExpend, []).

%% ----------------------------------------------------
%% @doc
%% Description: 奖励给指定的角色
%%@param RoleUid 角色id
%%@param ObjectUid 被奖励对象id
%%@param Award 奖励或奖励条目
%%@param Number 随机的次数
%% Returns:  {ok, ResultList, ChangeList} | {error, Reason} | {error, Reason, StackTrace}.
%% @end
%% ----------------------------------------------------
-spec give(Table, RoleUid, Args, Award, Number) -> list() when
    Table :: atom(),
    RoleUid :: integer(),
    Args :: term(),
    Award :: list(),
    Number :: integer().
give(Table, RoleUid, Args, Award, Number) when Number > 0 ->
    L = award_total_item(Award, Number, []),
    give_(Table, RoleUid, Args, L).
give_(Table, RoleUid, Args, L) ->
    award_fun(RoleUid, Args, award_expand(Table, RoleUid, Args, L, []), []).

%% ----------------------------------------------------
%% @doc
%% Description: 生成多次奖励的随机条目
%%@param Number 随机奖励条目次数
%%@param Award 奖励或奖励条目
%% Returns:  list.
%% @end
%% ----------------------------------------------------
-spec award_total_item(Award, Number, R) -> list() when
    Award :: list(),
    Number :: integer(),
    R :: list().
award_total_item(Award, Number, R) when Number > 0 ->
    L = case award_item(Award) of
        List when is_list(List) ->
            [X || X <- lists:flatten(List), X =/= []];
        Item ->
            [Item]
    end,
    award_total_item(Award, Number - 1, merger(L, R));
award_total_item(_Award, _Number, R) ->
    R.

%% ----------------------------------------------------
%% @doc
%% Description: 奖励给指定的角色,并返回多次奖励的详细信息
%%@param RoleUid 角色id
%%@param ObjectUid 被奖励对象id
%%@param Award 奖励或奖励条目
%%@param Number 随机的次数
%% Returns:  {ok, ResultList, ChangeList} | {error, Reason} | {error, Reason, StackTrace}.
%% @end
%% ----------------------------------------------------
-spec give_split(Table, RoleUid, Args, Award, Number) -> {list(), list()} when
    Table :: atom(),
    RoleUid :: integer(),
    Args :: term(),
    Award :: list(),
    Number :: integer().
give_split(Table, RoleUid, Args, Award, Number) when Number > 0 ->
    {L, Split} = award_total_item_split(Award, Number, [], []),
    {give_(Table, RoleUid, Args, L), Split}.

%% ----------------------------------------------------
%% @doc
%% Description: 生成多次奖励的随机条目,并将每次奖励详细信息返回
%%@param Number 随机奖励条目次数
%%@param Award 奖励或奖励条目
%% Returns:  list.
%% @end
%% ----------------------------------------------------
-spec award_total_item_split(Award, Number, R, S) -> {list(), list()} when
    Award :: list(),
    Number :: integer(),
    R :: list(),
    S :: list().
award_total_item_split(Award, Number, R, S) when Number > 0 ->
    L = case award_item(Award) of
        List when is_list(List) ->
            [X || X <- lists:flatten(List), X =/= []];
        Item ->
            [Item]
    end,
    award_total_item_split(Award, Number - 1, merger(L, R), [list_to_tuple(L) | S]);
award_total_item_split(_Award, _Number, R, S) ->
    {R, S}.

%% ----------------------------------------------------
%% @doc
%% Description: 无改变的奖励扩展函数
%%@param Args 参数
%%@param RoleUid 角色id
%%@param Award 奖励的值
%% Returns:  Award
%% @end
%% ----------------------------------------------------
-spec expand(_A, _Type, _RoleUid, _Args, Value) -> {'ok', Value} when
    Value :: term().
expand(_A, _Type, _RoleUid, _Args, Value) ->
    {ok, Value}.

%% ----------------------------------------------------
%% @doc
%%      进行数据合并
%% @end
%% ----------------------------------------------------
-spec merger(List, R) -> list() when
    List :: list(),
    R :: list().
merger([H | T], R) ->
    merger(T, merger_(H, R, []));
merger([], R) ->
    R.

%% ----------------------------------------------------
%% @doc
%% Description: 检查单个奖励条目是否符合规范，调用配置MFA
%%@param {Type,V} 单个奖励条目
%% Returns:  true符合规范|false
%% @end
%% ----------------------------------------------------
-spec check_award(Table, {Type, V}) -> boolean() when
    Table :: atom(),
    Type :: atom(),
    V :: integer()|{atom(), integer()}.
check_award(Table, {Type, V}) ->
    case zm_config:get(Table, Type) of
        {_, _, _, {M, F, A}} -> M:F(A, V);
        _ -> false
    end.

%% ----------------------------------------------------
%% @doc
%%     前台奖励格式化
%% @end
%% ----------------------------------------------------
-spec award_format_item(list()) -> list().
award_format_item([rate | Award]) ->
    award_format(Award, []);
award_format_item([weight | Award]) ->
    award_format(Award, []);
award_format_item([average | Award]) ->
    award_format(Award, []);
award_format_item([H | _] = Award) when is_list(H) ->
    Fun = fun(H2, R) ->
        FormatAward = award_format_item(H2),
        if
            is_list(FormatAward) ->
                lists:append(FormatAward, R);
            true ->
                [FormatAward | R]
        end
    end,
    lists:foldl(Fun, [], Award);
award_format_item([H | _] = Award) when is_tuple(H) ->
    [award_format_item(E) || E <- Award];
award_format_item({Type, _Min, Max}) when is_atom(Type) ->%%具体数值
    {Type, Max};
award_format_item({Type, _Args} = Item) when is_atom(Type) ->
    Item;
award_format_item(_) ->
    [].

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%      道具合并
%% @end
%% ----------------------------------------------------
-spec merger_({Type, Value}, [{Type, Value2} | T], R) -> list() when
    Type :: atom(),
    Value :: integer()|{integer(), integer()},
    Value2 :: integer()|{integer(), integer()},
    T :: list(),
    R :: list().
merger_({Type, {Sid, Number}}, [{Type, {Sid, Number1}} | T], R) when is_integer(Number) andalso is_integer(Number1) ->
    lists:reverse([{Type, {Sid, Number + Number1}} | R], T);
%% ----------------------------------------------------
%% @doc
%%      资源合并
%% @end
%% ----------------------------------------------------
merger_({Type, Value}, [{Type, Value1} | T], R) when is_integer(Value) andalso is_integer(Value1) ->
    lists:reverse([{Type, Value + Value1} | R], T);
merger_(Item, [I | T], R) ->
    merger_(Item, T, [I | R]);
merger_(Item, [], R) ->
    lists:reverse([Item | R]).

%% ----------------------------------------------------
%% @doc
%%      奖励条目
%% @end
%% ----------------------------------------------------
-spec award_item(list()) -> list()|tuple().
award_item([]) ->
    [];
award_item([rate | Award]) ->
    award_rate(Award, []);
award_item([weight | Award]) ->
    award_weight(Award, Award, 0);
award_item([average | Award]) ->
    award_average(Award);
award_item([_H | _] = Award) ->
    [award_item(E) || E <- Award];
award_item({Type, Min, Max}) when is_atom(Type) ->%%具体数值
    {Type, z_lib:random(Min, Max)};
award_item({Type, _Args} = Item) when is_atom(Type) ->
    Item.

%% ----------------------------------------------------
%% @doc
%%      计算概率奖励，返回奖励
%% @end
%% ----------------------------------------------------
-spec award_rate(list(), list()) -> list().
award_rate([Rate, Award | T], L) ->
    case z_lib:random(1, ?RAND_RATE) of
        N when N > Rate ->
            award_rate(T, L);
        _ ->
            award_rate(T, [award_item(Award) | L])
    end;
award_rate([], L) ->
    lists:reverse(L).

%% ----------------------------------------------------
%% @doc
%%      计算随机奖励的权重，返回奖励
%% @end
%% ----------------------------------------------------
-spec award_weight(list(), list(), integer()) -> list()|tuple().
award_weight(L, [Weight, _Award | T], C) ->
    award_weight(L, T, Weight + C);
award_weight(L, [], C) ->
    random_award(L, z_lib:random(1, C)).

%% ----------------------------------------------------
%% @doc
%%      根据随机权重，返回奖励
%% @end
%% ----------------------------------------------------
-spec random_award(list(), integer()) -> list()|tuple().
random_award([Weight, _Award | T], C) when Weight < C ->
    random_award(T, C - Weight);
random_award([_Weight, Award | _T], _C) ->
    award_item(Award).

%% ----------------------------------------------------
%% @doc
%%      计算平均随机奖励，返回奖励
%% @end
%% ----------------------------------------------------
-spec award_average(Award) -> list()|tuple() when
    Award :: list().
award_average(Award) ->
    award_item(lists:nth(z_lib:random(1, length(Award)), Award)).

%% ----------------------------------------------------
%% @doc
%%      奖励展开
%% @end
%% ----------------------------------------------------
-spec award_expand(Table, RoleUid, Args, [{Type, Value} | T], L) -> list() when
    Table :: atom(),
    RoleUid :: integer(),
    Args :: term(),
    Type :: atom(),
    Value :: integer()|{integer(), integer()},
    T :: list(),
    L :: list().
award_expand(Table, RoleUid, Args, [{Type, Value} | T], L) ->
    {Type, {M, F, A}, MFA, _} = zm_config:get(Table, Type),
    {ok, V} = M:F(A, Type, RoleUid, Args, Value),
    award_expand(Table, RoleUid, Args, T, [{MFA, Type, V} | L]);
award_expand(_Table, _RoleUid, _Args, [], L) ->
    lists:reverse(L).

%% ----------------------------------------------------
%% @doc
%%      奖励MFA函数
%% @end
%% ----------------------------------------------------
-spec award_fun(RoleUid, Args, [{{M, F, A}, _Type, Value} | T], R) -> list() when
    RoleUid :: integer(),
    Args :: term(),
    M :: module(),
    F :: atom(),
    A :: term(),
    Value :: integer()|{integer(), integer()},
    T :: list(),
    R :: list().
award_fun(RoleUid, Args, [{{M, F, A}, _Type, Value} | T], R) ->
    award_fun(RoleUid, Args, T, [M:F(A, RoleUid, Args, Value) | R]);
award_fun(_RoleUid, _Args, [], R) ->
    lists:reverse(R).

%% ----------------------------------------------------
%% @doc
%%     奖励去掉概率,权重,给前台展示用
%% @end
%% ----------------------------------------------------
award_format([_Weight, Award | T], R) ->
    FormatAward = award_format_item(Award),
    if
        is_list(FormatAward) ->
            award_format(T, lists:append(FormatAward, R));
        true ->
            award_format(T, [award_format_item(Award) | R])
    end;
award_format([], R) ->
    lists:reverse(R).