-module(achieve_check_garray).

%%%=======================STATEMENT====================
-description("achieve_check_garray").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([check/3, complete/3]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      外部条件检查
%% @end
%% ----------------------------------------------------
-spec check(term(), term(), term()) -> boolean().
check({Src, 'garray_up_card_num'}, Value, RoleUid) ->%%上阵武将个数
    List = garray_db:get_garray(Src, RoleUid, garray_lib:get_garray_ids(Src, RoleUid)),
    F = fun(A, _, Item) ->
        if
            element(1, Item) =:= 0 ->
                A;
            true ->
                A + 1
        end
    end,
    Fun = fun(A, {_, Garray}) ->
        z_lib:tuple_foreach(garray:get_queue(Garray), F, A)
    end,
    z_lib:foreach(Fun, 0, List) >= Value;
check(_, _, _) ->
    false.
%% ----------------------------------------------------
%% @doc
%%      外部条件完成
%% @end
%% ----------------------------------------------------
-spec complete(term(), term(), term()) -> 'ok' | string().
complete(_, _, _) ->
    ok.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
