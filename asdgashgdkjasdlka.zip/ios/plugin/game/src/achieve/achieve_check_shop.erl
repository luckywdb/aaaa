%%商店购买
-module(achieve_check_shop).
-description("achieve_check_shop").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).
%%%=======================EXPORT=======================
-export([notify/3, finish/3]).
%%%=======================DEFINE=======================

%%%=================EXPORTED FUNCTIONS===================
%% ----------------------------------------------------
%% @doc
%%      通用累加方式任务
%% @end
%% ----------------------------------------------------
-spec notify(term(), term(), term()) -> {'ok', term()} | 'ignore'.
notify({_Src, 'shop_buy_item', Sid}, Var, {'shop_buy', _Name, Sid, Number}) when Number > 0 ->
    {'ok', Var + Number};
notify({_Src, 'shop_buy', Name}, Var, {'shop_buy', Name, _Sid, Number}) when Number > 0 ->
    {'ok', Var + Number};
notify({_Src, 'shop_refresh', Name}, Var, {'shop_refresh', Name}) ->
    {'ok', Var + 1};
notify(_, _, _) ->
    'ignore'.

%% ----------------------------------------------------
%% @doc
%%      完成检查
%% @end
%% ----------------------------------------------------
-spec finish(term(), term(), term()) -> boolean().
finish(_, Count, Var) ->
    Var >= Count.
%%%===================LOC FUNCTIONS===================
