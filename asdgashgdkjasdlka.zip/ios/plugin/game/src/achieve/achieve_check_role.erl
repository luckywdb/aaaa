-module(achieve_check_role).
-description("achieve_check_role").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).
%%%=======================EXPORT=======================
-export([check/3, complete/3]).

%%%=======================DEFINE=======================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      外部条件检查
%% @end
%% ----------------------------------------------------
-spec check(term(), term(), term()) -> boolean().
%角色等级
check({Src, role_level}, Value, RoleUid) ->
    game_lib:get_level('role', role_db:get_role(Src, RoleUid)) >= Value;
%vip等级
check({Src, vip}, Value, RoleUid) ->
    game_lib:get_level('vip', role_db:get_role(Src, RoleUid)) >= Value;
check(_, _, _) ->
    false.

%% ----------------------------------------------------
%% @doc
%%      外部条件完成
%% @end
%% ----------------------------------------------------
-spec complete(term(), term(), term()) -> 'ok' | string().
complete(_, _, _) ->
    ok.
