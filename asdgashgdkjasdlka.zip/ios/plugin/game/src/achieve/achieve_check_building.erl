-module(achieve_check_building).

%%%=======================STATEMENT====================
-description("achieve_check_building").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([check/3, complete/3]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      外部条件检查
%% @end
%% ----------------------------------------------------
-spec check(term(), term(), term()) -> boolean().
%%升级指定sid建筑到x级
check({Src, building_lv}, {Sid, Value}, RoleUid) ->
    Castle = castle_db:get_castle(Src, RoleUid),
    Buildings = castle:get_building(Castle),
    castle:get_buildlv(Buildings, Sid) >= Value;
check({Src, building_type_lv}, {BuildType, NeedLevel, NeedNum}, RoleUid) ->
    Castle = castle_db:get_castle(Src, RoleUid),
    Buildings = castle:get_building(Castle),
    z_lib:foreach(fun
        (CurNum, _) when CurNum >= NeedNum ->
            {break, CurNum};
        (CurNum, {_, LocalSid, LocalLevel, _}) when LocalLevel >= NeedLevel ->
            case building:get_type(building:get_cfg(LocalSid)) of
                BuildType ->
                    {ok, CurNum + 1};
                _ ->
                    {ok, CurNum}
            end;
        (CurNum, _) ->
            {ok, CurNum}
    end, 0, Buildings) >= NeedNum;
check({Src, building_other_lv}, {Sid, ItemSid, Value}, RoleUid) ->
    List = building_db:get_study_by_key(Src, RoleUid, Sid),
    z_lib:get_value(List, ItemSid, -1) >= Value;
check({Src, building_study_any_up}, {BSid, Num, Level}, RoleUid) ->
    List = building_db:get_study_by_key(Src, RoleUid, BSid),
    z_lib:foreach(fun(CurNum, {_, LocalVal}) ->
        if
            LocalVal >= Level ->
                if
                    CurNum + 1 >= Num ->
                        {'break', Num};
                    true ->
                        {'ok', CurNum + 1}
                end;
            true ->
                {'ok', CurNum}
        end
    end, 0, List) >= Num;
check(_, _, _) ->
    false.
%% ----------------------------------------------------
%% @doc
%%      外部条件完成
%% @end
%% ----------------------------------------------------
-spec complete(term(), term(), term()) -> 'ok' | string().
complete(_, _, _) ->
    ok.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
