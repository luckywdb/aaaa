%%成就事件
-module(achieve_event).
-description("achieve_event").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).
%%%=======================EXPORT========================
-export([event_notify/4, up_grade_notify/4]).

%%%===================PUBLIC FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%      任务事件触发接收
%% @end
%% ----------------------------------------------------
-spec event_notify(_, Src, achieve, {RoleUid, EventArgu}) -> atom() when
    Src :: atom(),
    RoleUid :: integer(),
    EventArgu :: term().
event_notify(_, Src, achieve, {RoleUid, EventArgu}) ->
    case EventArgu of
        {argu, Argu} ->
            achieve_db:notify(Src, RoleUid, Argu);%%%Argu---要校验  数组要展开;
        _ ->
            none
    end.

%% ----------------------------------------------------
%% @doc
%%      升级开启任务
%% @end
%% ----------------------------------------------------
-spec up_grade_notify(_, atom(), up_grade, list()) -> atom().
up_grade_notify(_, Src, up_grade, [{role, Role} | _]) ->
    RoleUid = role:get_uid(Role),
    F = fun(_, none) ->
        AchieveSet = achieve_lib:init(Role),
        {ok, AchieveSet, erlang:list_to_tuple([achieve_lib:encode(Achieve) || Achieve <- AchieveSet])};
        (_, AchieveSet) ->
            case achieve_lib:init(Role, tuple_to_list(AchieveSet)) of
                [] ->
                    {ok, ok};
                Achieves ->
                    FormatAchieve = list_to_tuple([achieve_lib:format_achieve(Achieve) || Achieve <- Achieves]),
                    NAchieves = lists:foldl(fun(Achieve, Set) ->
                        erlang:append_element(Set, achieve_lib:encode(Achieve)) end, AchieveSet, Achieves),
                    {ok, FormatAchieve, NAchieves}
            end
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'achieve'), RoleUid, 'none', F, []) of
        ok ->
            ok;
        Reply ->
            set_front_lib:send_achieve(Src, RoleUid, Reply)
    end.

