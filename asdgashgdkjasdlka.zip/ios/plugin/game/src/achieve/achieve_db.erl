%%成就系统数据库操作
-module(achieve_db).
-description("achieve_db").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).
%%%=======================EXPORT=======================
-export([
    get_achieves/2,
    notify/3,
    complete/4,
    refresh/2,
    get_award_sid/3,
    computer_integral/2,
    accept/3,
    give_town_award/5,
    get_give_up_times/2,
    give_up/3,
    get_award_by_country/3,
    update_refresh_monster_times/3,
    delete_refresh_monster_times/3
]).
-export([get_achieve_by_sid/3]).

%%%=======================INCLUDE======================
-include("../include/achieve.hrl").
-include("../include/corps.hrl").
%%%=======================DEFINE=======================
-define(MAX_REFRESH_MONSTER_TIMES, 5).
%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      获得玩家任务信息
%% @end
%% ----------------------------------------------------
-spec get_achieves(atom(), integer()) -> tuple().
get_achieves(Src, RoleUid) ->
    z_db_lib:get(game_lib:get_table(Src, 'achieve'), RoleUid, {}).

%% ----------------------------------------------------
%% @doc
%%      更加任务sid获取玩家身上的任务
%% @end
%% ----------------------------------------------------
get_achieve_by_sid(Src, RoleUid, ASid) ->
    Achieves = get_achieves(Src, RoleUid),
    Fun = fun
        (_A, _I, {_, Sid, _} = Prop) when Sid =:= ASid ->
            {sid, _, Record} = achieve_lib:decode(Prop),
            {'break', Record};
        (A, _I, _E) ->
            {ok, A}
    end,
    z_lib:tuple_foreach(Achieves, Fun, 'none').

%% ----------------------------------------------------
%% @doc
%%      事件通知项目下指定角色的任务，任务可能因此而改变，返回改变的任务列表
%% @end
%% ----------------------------------------------------
-spec notify(Src, RoleUid, Events) -> atom() when
    Src :: atom(),
    RoleUid :: integer(),
    Events :: term().
notify(Src, RoleUid, Events) ->
    Second = time_lib:now_second(),
    Role = role_db:get_role(Src, RoleUid),
    F = fun(_, none) ->
        AchieveSet = erlang:list_to_tuple([achieve_lib:encode(Achieve) || Achieve <- achieve_lib:init(Role)]),
        {NAchieveSet, Modify} = achieve_set_lib:notify(Role, AchieveSet, Events, Second),
        {ok, Modify, NAchieveSet};
        (_, AchieveSet) ->
            {NAchieveSet, Modify} = achieve_set_lib:notify(Role, AchieveSet, Events, Second),
            {ok, Modify, NAchieveSet}
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'achieve'), RoleUid, none, F, {}) of
        [] ->
            ok;
        Modify ->
            set_front_lib:send_achieve(Src, RoleUid, list_to_tuple([achieve_lib:format_achieve(A) || A <- Modify]))
    end.

%% ----------------------------------------------------
%% @doc
%%      完成项目下指定角色的指定任务
%% @end
%% ----------------------------------------------------
-spec complete(atom(), integer(), integer(), integer()) ->
    {'ok', {'sid', integer(), achieve:achieve()}, [{'sid', integer(), achieve:achieve()}]}|
    {'ok', achieve:achieve(), [achieve:achieve()]}|{'update', string(), [{'sid', integer(), achieve:achieve()}]}|{'ok', string()}.
complete(Src, RoleUid, AchieveSid, TownSid) ->
    Second = time_lib:now_second(),
    Role = role_db:get_role(Src, RoleUid),
    F = fun(_, none) ->
        {ok, "achieve_not_found"};
        (_, AchieveSet) ->
            case achieve_set_lib:complete(AchieveSet, RoleUid, AchieveSid, TownSid) of
                {ok, NAchieveSet1, NAchieve, OldAchieve} ->
                    Achieve = achieve_lib:get_record(OldAchieve),
                    StepTriggerSids = achieve:get_triggers(Achieve),
                    Step = achieve:get_step(Achieve),
                    TriggerSids = z_lib:get_value(StepTriggerSids, Step, []),
                    AddAchieveProps = achieve_lib:init(Role, tuple_to_list(NAchieveSet1), TriggerSids),
                    {NAchieveSet, AddAchieves} = lists:foldl(fun(AchieveProp, {Set, AchieveAcc}) ->
                        {erlang:append_element(Set, achieve_lib:encode(AchieveProp)), [AchieveProp | AchieveAcc]}
                    end, {NAchieveSet1, []}, AddAchieveProps),
                    NewAddAchieves =
                        if
                            NAchieve =:= 'delete' ->%过期皇榜任务领奖后删除
                                AddAchieves;
                            true ->
                                [NAchieve | AddAchieves]
                        end,
                    {ok, {ok, OldAchieve, NewAddAchieves}, NAchieveSet};
                "achieve_timeout" ->%%日常任务超时，需要刷新任务集
                    {NAchieveSet, UpdateAchieveList} = achieve_set_lib:check_achieve(AchieveSet, Second),
                    {ok, {update, "achieve_timeout", UpdateAchieveList}, NAchieveSet};
                Other ->
                    {ok, Other}
            end
    end,
    z_db_lib:update(game_lib:get_table(Src, 'achieve'), RoleUid, none, F, none).

%% ----------------------------------------------------
%% @doc
%%      刷新任务，跨天
%% @end
%% ----------------------------------------------------
-spec refresh(atom(), integer()) -> [{'sid', integer(), achieve:achieve()}].
refresh(Src, RoleUid) ->
    Second = time_lib:now_second(),
    Role = role_db:get_role(Src, RoleUid),
    F = fun(_, none) ->
        AchieveSet = achieve_lib:init(Role),
        {ok, AchieveSet, erlang:list_to_tuple([achieve_lib:encode(Achieve) || Achieve <- AchieveSet])};
        (_, AchieveSetTmp) ->
            AchieveSet =
                case achieve_lib:init(Role, tuple_to_list(AchieveSetTmp)) of
                    [] ->
                        AchieveSetTmp;
                    AddList ->
                        lists:foldl(fun(Achieve, Set) ->
                            erlang:append_element(Set, achieve_lib:encode(Achieve)) end, AchieveSetTmp, AddList)
                end,
            {NAchieveSet, UpdateAchieveList} = achieve_set_lib:check_achieve(AchieveSet, Second),
            %%有更新,或者皇榜任务过期删除,都需要存入数据
            case UpdateAchieveList =/= [] orelse tuple_size(AchieveSetTmp) =/= tuple_size(NAchieveSet) of
                true ->
                    {ok, [achieve_lib:decode(Achieve) || Achieve <- erlang:tuple_to_list(NAchieveSet)], NAchieveSet};
                false ->
                    {ok, [achieve_lib:decode(Achieve) || Achieve <- erlang:tuple_to_list(NAchieveSet)]}
            end
    end,
    z_db_lib:update(game_lib:get_table(Src, 'achieve'), RoleUid, none, F, []).

%% ----------------------------------------------------
%% @doc
%%      根据等级获得sid
%% @end
%% ----------------------------------------------------
-spec get_award_sid(atom(), integer(), list()) -> integer() | 'none'.
get_award_sid(Src, RoleUid, List) ->
    Level = game_lib:get_level('role', z_db_lib:get(game_lib:get_table(Src, 'role'), RoleUid)),
    get_award_sid(Level, List).

%% ----------------------------------------------------
%% @doc
%%      计算任务积分
%% @end
%% ----------------------------------------------------
-spec computer_integral(integer(), achieve:achieve()) -> integer().
computer_integral(Level, Achieve) ->
    computer_integral_(Level, achieve:get_integral(Achieve), achieve:get_step(Achieve), achieve:get_state(Achieve)).

%% ----------------------------------------------------
%% @doc
%%     接取皇榜任务
%% @end
%% ----------------------------------------------------
accept(_, {Day, RoleLv, TownSid, MSid, TownDetail, TownLv, DayMax}, [{Index1, {AcceptDayNum, GiveUpDayNum, RefreshDay, TownAchieve}}, {Index2, AchieveSet}]) ->
    {NAcceptDayNum, NGiveUpDayNum} =
        if
            RefreshDay =:= Day ->
                {AcceptDayNum, GiveUpDayNum};
            true ->
                {0, 0}
        end,
    if
        NAcceptDayNum >= DayMax ->
            throw("town_achieve_daymax");
        true ->
            Second = time_lib:now_second(),
            F = fun(false, _, _) ->
                {'break', false};
                (Bool, _, Achieve) ->
                    case achieve_lib:decode(Achieve) of
                        {_, CMSid, ARecord} ->
                            case achieve:get_type(ARecord) =:= ?TOWN_ACHIEVE of
                                true ->
                                    case achieve_lib:check_timeout(ARecord, Second) of
                                        true ->
                                            {'break', false};
                                        false ->
                                            if
                                                CMSid =:= MSid ->
                                                    {'ok', achieve:get_state(ARecord) =/= ?UNFINISH};
                                                true ->
                                                    {'ok', Bool}
                                            end
                                    end;
                                false ->
                                    {'ok', Bool}
                            end;
                        _ ->
                            {'ok', Bool}
                    end
            end,
            CanAccept = z_lib:tuple_foreach(AchieveSet, F, true),
            if
                CanAccept ->
                    case lists:keyfind(TownSid, 1, TownAchieve) of
                        false ->
                            throw("town_no_achieve_sid");
                        {_, {OldDay, Sids, HSids}} ->
                            if
                                OldDay =/= Day ->
                                    throw("town_ahcieve_refresh");
                                true ->
                                    case lists:member(MSid, Sids) of
                                        true ->
                                            NTAchive =
                                                case lists:delete(MSid, Sids) of
                                                    [] ->%任务接完了后直接刷新任务
                                                        {_, {DM, DF, DA}} = zm_config:get('mission_info', {town_detail:get_type(TownDetail), TownLv}),
                                                        {PoolList, _} = DM:DF(DA, RoleLv, []),
                                                        {Day, PoolList, []};
                                                    Rest ->
                                                        {Day, Rest, [MSid | HSids]}
                                                end,
                                            AchieveProp = zm_config:get('achieve_sample_table', MSid),
                                            {'sid', _, ARecord} = achieve_lib:achieve(AchieveProp, Second),
                                            NARecord = achieve:set_townsid(ARecord, TownSid),
                                            NAchieveSet = erlang:append_element(AchieveSet, achieve_lib:encode({'sid', MSid, NARecord})),
                                            {'ok', 'ok', [{Index1, {NAcceptDayNum + 1, NGiveUpDayNum, Day, lists:keystore(TownSid, 1, TownAchieve, {TownSid, NTAchive})}}, {Index2, NAchieveSet}]};
                                        false ->
                                            throw("town_no_achieve_sid")
                                    end
                            end
                    end;
                true ->
                    throw("can_not_accept")
            end
    end.

%% ----------------------------------------------------
%% @doc
%%     城池皇榜任务完成,奖励
%% @end
%% ----------------------------------------------------
give_town_award([AwardSid], Src, RoleUid, TownSid, AchieveSid) ->
    RoleShow = role_db:get_role_show(Src, RoleUid),
    CorpsUid = role_show:get_corps_uid(RoleShow),
    {_, {Exp, AwardList}} = zm_config:get('achieve_award', AwardSid),
    AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, AwardList),
    corps_db:update_corps_show_times(Src, RoleUid, 'town_achieve_times', 1),
    if
        CorpsUid > 0 ->
            case point_db:chk_corps_owner(Src, CorpsUid, TownSid) of
                true ->
                    TownAwardLog = town_db:add_exp(Src, RoleUid, TownSid, Exp), %todo添加城池经验后启用
                    RoleName = role_show:get_name(RoleShow),
                    {'town_exp', TownAddExp, TownExp, TSid} = TownAwardLog,
                    case TSid =:= TownSid of
                        true ->
                            TownLv = town:get_lv(TownExp, town_detail:get_cfg(TownSid)),
                            CorpsLog = corps_log:town_complete_achieve(RoleName, TownSid, TownLv, AchieveSid, TownAddExp),
                            corps_db:insert_corps_log(Src, CorpsUid, CorpsLog);
                        false ->
                            ok
                    end,
                    if
                        TownAddExp > 0 ->
                            erlang:append_element(AwardLog, TownAwardLog);
                        true ->
                            AwardLog
                    end;
                false ->
                    AwardLog
            end;
        true ->
            AwardLog
    end.


%% ----------------------------------------------------
%% @doc
%%     城池皇榜任务放弃
%% @end
%% ----------------------------------------------------
give_up(_, {Day, DayMax, ASid, TSid}, [{Index1, {AcceptDayNum, GiveUpDayNum, RefreshDay, TownAchieve}}, {Index2, AchieveSet}]) ->
    {NAcceptDayNum, NGiveUpDayNum} =
        if
            RefreshDay =:= Day ->
                {AcceptDayNum, GiveUpDayNum};
            true ->
                {0, 0}
        end,
    if
        NGiveUpDayNum >= DayMax ->
            throw("give_up_daymax");
        true ->
            F = fun
                (A, I, {_, Sid, _} = Prop) when Sid =:= ASid ->
                    {sid, _, Record} = achieve_lib:decode(Prop),
                    RecordState = achieve:get_state(Record),
                    RecordTSid = achieve:get_townsid(Record),
                    RecordType = achieve:get_type(Record),
                    if
                        RecordType =:= ?TOWN_ACHIEVE andalso TSid =:= RecordTSid andalso RecordState =:= ?UNFINISH ->
                            {'break', I};
                        true ->
                            {'ok', A}
                    end;
                (A, _I, _E) ->
                    {'ok', A}
            end,
            case z_lib:tuple_foreach(AchieveSet, F, none) of
                none ->
                    throw("no_this_achieve");
                Index ->
                    NAchieveSet = erlang:delete_element(Index, AchieveSet),
                    NTownAchieve = case lists:keyfind(TSid, 1, TownAchieve) of
                        false ->
                            TownAchieve;
                        {_, {OldDay, Sids, HSids}} ->
                            lists:keyreplace(TSid, 1, TownAchieve, {TSid, {OldDay, [ASid | Sids], lists:delete(ASid, HSids)}})
                    end,
                    {'ok', 'ok', [{Index1, {max(NAcceptDayNum - 1, 0), NGiveUpDayNum + 1, Day, NTownAchieve}}, {Index2, NAchieveSet}]}
            end
    end.
%% ----------------------------------------------------
%% @doc
%%     获取放弃次数，刷新
%% @end
%% ----------------------------------------------------
get_give_up_times(Src, RoleUid) ->
    Day = time_lib:get_date_by_type('day_of_year'),
    Fun = fun(_, 'none') ->
        {'ok', 0};
        (_, {AcceptNum, GiveUpNum, RefreshDay, TownAchieve}) ->
            {NAcceptNum, NGiveUpNum} = if
                RefreshDay =:= Day ->
                    {AcceptNum, GiveUpNum};
                true ->
                    {0, 0}
            end,
            {'ok', NGiveUpNum, {NAcceptNum, NGiveUpNum, Day, TownAchieve}}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'town_achieve'), RoleUid, 'none', Fun, []).

%% ----------------------------------------------------
%% @doc
%%     根据不同国家获取奖励
%% @end
%% ----------------------------------------------------
get_award_by_country(Src, RoleUid, AwardList) ->
    Country = role:get_country(role_db:get_role(Src, RoleUid)),
    AwardId = element(2, lists:keyfind(Country, 1, AwardList)),
    element(2, zm_config:get('achieve_award', AwardId)).
%% ----------------------------------------------------
%% @doc
%%     任务刷怪次数
%% @end
%% ----------------------------------------------------
update_refresh_monster_times(Src, RoleUid, AchieveSid) ->
    ToDay = time_lib:get_date_by_type('day_of_year'),
    Fun1 = fun(_, {Day, Num}) when Day =:= ToDay ->
        if
            Num < ?MAX_REFRESH_MONSTER_TIMES ->
                {ok, true, {Day, Num + 1}};
            true ->
                {ok, false}
        end;
        (_, _Day) ->
            {ok, true, {ToDay, 1}}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'refresh_monster_times'), {RoleUid, AchieveSid}, 0, Fun1, []).
%% ----------------------------------------------------
%% @doc
%%     皇榜任务完成，删除此任务刷怪次数记录
%% @end
%% ----------------------------------------------------
delete_refresh_monster_times(Src, RoleUid, AchieveSid) ->
    Fun1 = fun(_, none) ->
        {ok, ok};
        (_, _) ->
            {ok, ok, delete}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'refresh_monster_times'), {RoleUid, AchieveSid}, none, Fun1, []).

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%      根据等级获得sid
%% @end
%% ----------------------------------------------------
-spec get_award_sid(integer(), list()) -> integer() | 'none'.
get_award_sid(Level, [L, Sid | _]) when Level =< L ->
    Sid;
get_award_sid(Level, [_, _ | T]) ->
    get_award_sid(Level, T);
get_award_sid(_Level, []) ->
    none.

%% ----------------------------------------------------
%% @doc
%%      计算任务积分
%% @end
%% ----------------------------------------------------
-spec computer_integral_(integer(), mfa()|integer(), integer(), achieve:state()) -> integer().
computer_integral_(Level, {M, F, A}, Step, State) ->
    M:F(Level, A, Step, State);
computer_integral_(_Level, Integral, Step, State) when is_list(Integral) ->
    if
        Step > 0 andalso State =:= ?FINISH ->
            lists:sum(lists:sublist(Integral, Step));
        Step > 0 ->
            lists:sum(lists:sublist(Integral, Step - 1));
        State =:= ?FINISH ->
            lists:sum(lists:sublist(Integral, 1));
        true ->
            0
    end;
computer_integral_(_Level, Integral, Step, State) when is_integer(Integral) ->
    if
        Step > 0 andalso State =:= ?FINISH ->
            Integral * Step;
        Step > 0 ->
            Integral * (Step - 1);
        State =:= ?FINISH ->
            Integral;
        true ->
            0
    end.