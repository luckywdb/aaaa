%%副本任务检查
-module(achieve_check_duplicate).

%%%=======================STATEMENT====================
-description("achieve_check_duplicate").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([check/3, complete/3, finish/3, notify/3]).

%%%=======================INCLUDE======================

%%%=======================RECORD=======================

%%%=======================DEFINE=======================


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      外部条件检查
%% @end
%% ----------------------------------------------------
-spec check(term(), term(), term()) -> boolean().
check({Src, duplicate_sid}, V, RoleUid) -> %%通关指定sid关卡
    Duplicate = duplicate_db:get_duplicate_info(Src, RoleUid),
    case lists:keyfind(V, 2, Duplicate) of
        false ->
            false;
        _ ->
            true
    end;
check(_, _, _) ->
    false.
%% ----------------------------------------------------
%% @doc
%%      外部条件完成
%% @end
%% ----------------------------------------------------
-spec complete(term(), term(), term()) -> 'ok' | string().
complete(_, _, _) ->
    ok.
%% ----------------------------------------------------
%% @doc
%%      完成检查
%% @end
%% ----------------------------------------------------
-spec finish(term(), term(), term()) -> boolean().
finish(_, Count, Var) ->
    Var >= Count.
%% ----------------------------------------------------
%% @doc
%%      通用累加方式任务
%% @end
%% ----------------------------------------------------
-spec notify(term(), term(), term()) -> {'ok', term()} | 'ignore'.
notify({_Src, duplicate, Types}, Var, {'duplicate', Sid, Number}) when is_list(Types) ->
    case zm_config:get('duplicate', Sid) of
        {Sid, Duplicate} ->
            case lists:keyfind('type', 1, Duplicate) of
                {_, Type} ->
                    Bl = lists:member(Type, Types),
                    if
                        Bl ->
                            {'ok', Var + Number};
                        true ->
                            'ignore'
                    end;
                _ ->
                    'ignore'
            end;
        _ ->
            'ignore'
    end;
notify({_Src, duplicate, Type}, Var, {'duplicate', Sid, Number}) ->
    case zm_config:get('duplicate', Sid) of
        {Sid, Duplicate} ->
            case lists:keyfind('type', 1, Duplicate) of
                {_, Type} ->
                    {'ok', Var + Number};
                _ ->
                    'ignore'
            end;
        _ ->
            'ignore'
    end;
notify({_Src, duplicate_sid_num, Sid}, Var, {'duplicate', Sid, Number}) ->
    {'ok', Var + Number};
notify(_, _, _) ->
    ignore.


%%%===================LOCAL FUNCTIONS==================