-module(achieve_check_fight).

%%%=======================STATEMENT====================
-description("achieve_check_fight").
-copyright('youkia,www.youkia.net').
-author("zyc,zhouyucheng@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([
    finish/3,
    notify/3
]).

%%%=======================INCLUDE======================
-include("../include/point.hrl").
%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      完成任务条件判断
%% @end
%%-------------------------------------------------------------------
-spec finish(_, Count, Var) -> boolean() when
    Count :: integer(),
    Var :: integer().
finish(_, Count, Var) ->
    Var >= Count.

%%-------------------------------------------------------------------
%% @doc
%%      事件处理
%% @end
%%-------------------------------------------------------------------
-spec notify({Src, {FightType, Type}}, Var, {fight_times, Type, Sid, WinFlag}) -> {ok, integer()} | 'ignore' when
    Src :: atom(),
    FightType :: fight_times | fight_win_times,
    Type :: ?ROLE | ?MONSTER | ?RESOURCE,
    Var :: integer(),
    Sid :: integer(),
    WinFlag :: 1 | 0.
notify({_Src, {FightType, Type}}, Var, {fight_times, Type, _Sid, WinFlag}) ->
    if
        FightType =:= fight_times ->
            {ok, Var + 1};
        FightType =:= fight_win_times, WinFlag =:= 1 ->
            {ok, Var + 1};
        true ->
            'ignore'
    end;
%% 指定等级攻打土匪, 资源
notify({_Src, FightType, {Type, Level}}, Var, {fight_times, Type, Sid, WinFlag}) when is_integer(Level) ->
    EnemyLevel = case Type of
        ?MONSTER ->
            Detail = monster_detail:get_cfg(Sid),
            monster_detail:get_level(Detail);
        ?RESOURCE ->
            Detail = resource_detail:get_cfg(Sid),
            resource_detail:get_level(Detail);
        ?RES ->
            Detail = res_detail:get_cfg(Sid),
            res_detail:get_level(Detail)
    end,
    if
        EnemyLevel < Level ->
            'ignore';
        FightType =:= fight_times ->
            {ok, Var + 1};
        FightType =:= fight_win_times, WinFlag =:= 1 ->
            {ok, Var + 1};
        true ->
            'ignore'
    end;
%% 指定Sid攻打土匪
notify({_Src, FightType, {Type, SidList}}, Var, {fight_times, Type, Sid, WinFlag}) when is_list(SidList) ->
    Exist = lists:member(Sid, SidList),
    if
        not Exist ->
            'ignore';
        FightType =:= fight_times ->
            {ok, Var + 1};
        FightType =:= fight_win_times, WinFlag =:= 1 ->
            {ok, Var + 1};
        true ->
            'ignore'
    end;
notify(_, _, _) ->
    'ignore'.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
