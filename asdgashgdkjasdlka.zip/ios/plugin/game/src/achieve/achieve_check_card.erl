-module(achieve_check_card).

%%%=======================STATEMENT====================
-description("achieve_check_card").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([check/3, complete/3]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      外部条件检查
%% @end
%% ----------------------------------------------------
-spec check(term(), term(), term()) -> boolean().
%%card:FunName(Card)的值大于V的个数大于等于Value
check({Src, FunName}, {V, Value}, RoleUid) ->
    CardPropSet = storage_db:get_storage('card', Src, RoleUid),
    Fun = fun(N, _, CardProp) ->
        Card = prop_kit_lib:get_prop_record(prop_kit_lib:decode(CardProp)),
        case card:FunName(Card) >= V of
            true ->
                NewN = N + 1,
                if
                    NewN >= Value ->
                        {break, NewN};
                    true ->
                        {ok, N + 1}
                end;
            false ->
                {ok, N}
        end
    end,
    z_lib:tuple_foreach(CardPropSet, Fun, 0) >= Value;
check(_, _, _) ->
    false.
%% ----------------------------------------------------
%% @doc
%%      外部条件完成
%% @end
%% ----------------------------------------------------
-spec complete(term(), term(), term()) -> 'ok' | string().
complete(_, _, _) ->
    ok.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
