%%通用检查模块
-module(achieve_check_nor).

%%%=======================STATEMENT====================
-description("achieve_check_nor").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([check/3, complete/3, finish/3, notify/3]).

%%%=======================INCLUDE======================

%%%=======================RECORD=======================

%%%=======================DEFINE=======================


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      外部条件检查
%% @end
%% ----------------------------------------------------
-spec check(term(), term(), term()) -> boolean().
check(_, _, _) ->
    false.
%% ----------------------------------------------------
%% @doc
%%      外部条件完成
%% @end
%% ----------------------------------------------------
-spec complete(term(), term(), term()) -> 'ok' | string().
complete(_, _, _) ->
    ok.
%% ----------------------------------------------------
%% @doc
%%      完成检查
%% @end
%% ----------------------------------------------------
-spec finish(term(), term(), term()) -> boolean().
finish(_, Count, Var) ->
    Var >= Count.
%% ----------------------------------------------------
%% @doc
%%      通用累加方式任务
%% @end
%% ----------------------------------------------------
-spec notify(term(), term(), term()) -> {'ok', term()} | 'ignore'.
notify({_Src, Tag1, Types}, Var, {Tag2, Type, V}) when Tag1 =:= Tag2 andalso is_list(Types) ->
    case is_integer(V) andalso V > 0 andalso lists:member(Type, Types) of
        true ->
            {ok, Var + V};
        false ->
            ignore
    end;
notify({_Src, Types}, Var, {Type, V}) when is_list(Types) ->
    case is_integer(V) andalso V > 0 andalso lists:member(Type, Types) of
        true ->
            {ok, Var + V};
        false ->
            ignore
    end;
notify({_Src, Type}, Var, {Type, V}) -> %%加
    if
        is_integer(V) andalso V > 0 ->
            {ok, Var + V};
        true ->
            ignore
    end;
notify({_Src, {Type, 'compare1'}}, Var, {Type, V}) -> %%比较替换
    if
        is_integer(V) andalso V > Var ->
            {ok, V};
        true ->
            ignore
    end;
notify({_Src, {Type, 'compare2', V1}}, Var, {Type, {V2, V3}}) -> %%条件比较替换
    if
        is_integer(V2) andalso is_integer(V3) andalso V2 >= V1 andalso V3 > Var ->
            {ok, V3};
        true ->
            ignore
    end;
notify(_, _, _) ->
    ignore.

%%%===================LOCAL FUNCTIONS==================