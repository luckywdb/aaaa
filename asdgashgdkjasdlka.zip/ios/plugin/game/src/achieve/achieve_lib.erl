-module(achieve_lib).
-description("achieve_lib").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).
%%%=======================EXPORT=======================
-export([init/1, init/2, init/3, achieve/2, init_condition/1, notify/3, check_timeout/2, check/2, complete/2]).
-export([change_achieve/3, next_condition/2, format_achieve/1, check/3]).
-export([get_sid/1, get_record/1, set_record/2, get_sample/1, get_condition/1, decode/1, encode/1]).
-export([get_complete_award/3]).
-export([get_accept_times/2, get_give_up_times/2]).
%%%=======================DEFINE=======================

%%%=======================RECORD=======================

%%%=======================INCLUDE======================
-include("../include/achieve.hrl").

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      初始化所有任务
%% @end
%% ----------------------------------------------------
-spec init(role:role()) -> [{'sid', integer(), achieve:achieve()}].
init(Role) ->
    init(Role, []).

%% ----------------------------------------------------
%% @doc
%%      初始化列表任务
%% @end
%% ----------------------------------------------------
-spec init(role:role(), [integer()]) -> [{'sid', integer(), achieve:achieve()}].
init(Role, AchieveList) ->
    List = zm_config:get('achieve_sample_table'),
    Sids = lists:map(fun({'sid', Sid, _}) -> Sid end, List),
    init(Role, AchieveList, Sids).

%% ----------------------------------------------------
%% @doc
%%      初始化列表任务(需要初始化哪些)
%% @end
%% ----------------------------------------------------
-spec init(role:role(), [integer()], [integer()]) -> [{'sid', integer(), achieve:achieve()}].
init(Role, AchieveList, Sids) ->
    Second = time_lib:now_second(),
    L = z_lib:foreach(fun(A, Sid) when is_integer(Sid) ->
        case lists:keyfind(Sid, 2, A) of
            false ->
                {sid, _, Achieve} = AchieveProp = zm_config:get('achieve_sample_table', Sid),
                Conditions = achieve:get_init_conds(Achieve),
                case lists:keyfind(Sid, 2, AchieveList) =:= false andalso game_lib:checks({?MODULE, check}, {Role, AchieveList}, 'init', Conditions) =:= true of
                    true ->
                        {ok, [AchieveProp | A]};
                    false ->
                        {ok, A}
                end;
            _ ->
                {ok, A}
        end
    end, [], Sids),
    [achieve(AchieveProp, Second) || AchieveProp <- L].

%% ----------------------------------------------------
%% @doc
%%      初始化单个任务
%% @end
%% ----------------------------------------------------
-spec achieve({'sid', integer(), achieve:achieve()}, integer()) -> {'sid', integer(), achieve:achieve()}.
achieve({sid, Sid, ARecord}, Second) ->
    NewRecord = case achieve_lib:get_condition(Sid) of
        none ->
            ARecord;
        {Sid, ConditionList, AwardList} ->
            change_achieve(ARecord, ConditionList, AwardList)
    end,
    {sid, Sid, achieve:set_timeout(NewRecord, Second)}.

%% ----------------------------------------------------
%% @doc
%%      初始化任务条件，增加条件用
%% @end
%% ----------------------------------------------------
-spec init_condition({'sid', integer(), achieve:achieve()}) -> {'sid', integer(), achieve:achieve()}.
init_condition({sid, Sid, ARecord}) ->
    NewRecord = case achieve_lib:get_condition(Sid) of
        none ->
            ARecord;
        {Sid, ConditionList, AwardList} ->
            Step = achieve:get_step(ARecord),
            Bool1 = achieve:get_state(ARecord) =:= ?FINISH,
            if
                Bool1 ->
                    Bool2 = z_lib:foreach(fun(A, {_, _, Condition}) ->
                        if
                            length(Condition) =< Step ->
                                {break, false};
                            true ->
                                A
                        end
                    end, true, ConditionList),
                    if
                        Bool2 ->
                            change_achieve(ARecord, ConditionList, AwardList);
                        true ->
                            ARecord
                    end;
                true ->
                    ARecord
            end
    end,
    {sid, Sid, NewRecord}.
%% ----------------------------------------------------
%% @doc
%%      修改任务条件及奖励
%% @end
%% ----------------------------------------------------
-spec change_achieve(achieve:achieve(), [achieve:condition()], [mfa()|integer()]) -> achieve:achieve().
change_achieve(ARecord, ConditionList, AwardList) ->
    NextStep = achieve:get_step(ARecord) + 1,
    Award = if
        NextStep > length(AwardList) ->
            [];
        true ->
            lists:nth(NextStep, AwardList)
    end,
    achieve:set_award(change_condition(ARecord, ConditionList, NextStep), Award).

%% ----------------------------------------------------
%% @doc
%%      修改任务条件
%% @end
%% ----------------------------------------------------
-spec change_condition(achieve:achieve(), [achieve:condition()], integer()) -> achieve:achieve().
change_condition(ARecord, [{_, _, A} = Condition | T], NextStep) ->
    if
        NextStep > length(A) ->
            achieve:set_state(ARecord, ?FINISH);
        true ->
            change_condition(change_condition_(ARecord, Condition, NextStep), T, NextStep)
    end;
change_condition(ARecord, [], NextStep) ->
    achieve:set_step(ARecord, NextStep).

%% ----------------------------------------------------
%% @doc
%%      修改任务条件
%% @end
%% ----------------------------------------------------
-spec change_condition_(achieve:achieve(), achieve:condition(), integer()) -> achieve:achieve().
change_condition_(ARecord, Condition, NextStep) ->
    F = fun([Record, {M, A1, A2}, Step], I, {M, A1, _}) ->
        {break, setelement(I, Record, {M, A1, lists:nth(Step, A2)})};
        ([Record, {M, A1, A2}, Step], I, {M, A1, _, Var}) ->
            {break, setelement(I, Record, {M, A1, lists:nth(Step, A2), Var})};
        (A, _, _) ->
            A
    end,
    case foreach(ARecord, F, [ARecord, Condition, NextStep]) of
        [AR | _] ->
            AR;
        AR ->
            achieve:set_state(AR, ?UNFINISH)
    end.
%% ----------------------------------------------------
%% @doc
%%      用指定的事件通知任务
%% @end
%% ----------------------------------------------------
-spec notify(role:role(), achieve:achieve(), term()) -> achieve:achieve() | 'ignore'.
notify(Role, Achieve, Events) when is_list(Events) ->%%多事件
    notify_events(Role, Achieve, Events, 'ignore');
notify(Role, Achieve, Event) ->%%单事件
    notify_(Role, Achieve, Event).

%% ----------------------------------------------------
%% @doc
%%     多事件,只有都是ignore时候才返回ignore
%% @end
%% ----------------------------------------------------
notify_events(Role, Achieve, [Event | T], Reply) ->%%多事件
    case notify_(Role, Achieve, Event) of
        'ignore' ->
            notify_events(Role, Achieve, T, Reply);
        NAchieve ->
            notify_events(Role, NAchieve, T, NAchieve)
    end;
notify_events(_Role, _Achieve, [], Reply) ->
    Reply.

%% ----------------------------------------------------
%% @doc
%%      判断任务是否超时
%% @end
%% ----------------------------------------------------
-spec check_timeout(achieve:achieve(), integer()) -> boolean().
check_timeout(Achieve, Second) ->
    TimeOut = achieve:get_timeout(Achieve),
    if
        TimeOut =:= 0 ->
            false;
        true ->
            Second > achieve:get_timeout(Achieve)
    end.

%% ----------------------------------------------------
%% @doc
%%      检查任务是否完成
%% @end
%% ----------------------------------------------------
-spec check(achieve:achieve(), integer()) -> boolean().
check(Achieve, RoleUid) ->
    F = fun
        (A, _I, {M, MA1, MA2, Var}) ->
            case M:finish(MA1, MA2, Var) of
                true ->
                    A;
                false ->
                    {break, false}
            end;
        (A, _I, {M, MA1, MA2}) ->
            case M:check(MA1, MA2, RoleUid) of
                true ->
                    A;
                false ->
                    {break, false}
            end
    end,
    foreach(Achieve, F, true).

%% ----------------------------------------------------
%% @doc
%%       完成任务，由于条件完成可能存在不可回退的情况，所以应该已经调用过check方法
%% @end
%% ----------------------------------------------------
complete(Achieve, Role) ->
    F = fun
        (A, _I, {M, MA1, MA2, Var}) ->
            case M:finish(MA1, MA2, Var) of
                true ->
                    A;
                false ->
                    {break, condition_not_completed}
            end;
        (A, _I, {M, MA1, MA2}) ->
            case M:complete(MA1, MA2, Role) of
                ok ->
                    A;
                E ->
                    {break, E}
            end
    end,
    foreach(Achieve, F, ok).

%% ----------------------------------------------------
%% @doc
%%       添加下一任务
%% @end
%% ----------------------------------------------------
-spec next_condition(integer(), achieve:achieve()) -> achieve:achieve().
next_condition(Sid, ARecord) ->
    case zm_config:get(achieve_condition_table, Sid) of
        none ->
            achieve:set_state(ARecord, ?FINISH);
        {_, ConditionList, AwardList} ->
            change_achieve(ARecord, ConditionList, AwardList)
    end.

%% ----------------------------------------------------
%% @doc
%%       格式化任务，发前台需要的数据
%% @end
%% ----------------------------------------------------
-spec format_achieve({'sid', integer(), achieve:achieve()}) ->
    {integer(), achieve:type(), integer(), tuple(), achieve:state(), integer(), integer()}.
format_achieve({sid, Sid, Achieve}) when is_tuple(Achieve) ->
    F = fun
        (A, _I, {_M, _MA1, _MA2, Var}) ->
            z_lib:tuple_insert(?CONDITION_MAX, A, Var);
        (A, _, _) ->
            A
    end,
    {Sid, achieve:get_type(Achieve), achieve:get_step(Achieve), foreach(Achieve, F, {}), achieve:get_state(Achieve), achieve:get_timeout(Achieve), achieve:get_townsid(Achieve)}.

%% ----------------------------------------------------
%% @doc
%%       获得任务Sid
%% @end
%% ----------------------------------------------------
-spec get_sid({'sid', integer(), _}) -> integer().
get_sid({sid, Sid, _}) ->
    Sid.
%% ----------------------------------------------------
%% @doc
%%       获得任务
%% @end
%% ----------------------------------------------------
-spec get_record({'sid', _, achieve:achieve()}) -> achieve:achieve().
get_record({sid, _, Record}) when is_tuple(Record) ->
    Record.
%% ----------------------------------------------------
%% @doc
%%       设置任务
%% @end
%% ----------------------------------------------------
-spec set_record({'sid', integer(), achieve:achieve()}, achieve:achieve()) -> {'sid', integer(), achieve:achieve()}.
set_record({sid, Sid, Record}, Record1) when is_tuple(Record) ->
    {sid, Sid, Record1}.
%% ----------------------------------------------------
%% @doc
%%       获得任务样本
%% @end
%% ----------------------------------------------------
-spec get_sample(integer()) -> {'sid', integer(), achieve:achieve()} | 'none'.
get_sample(Sid) ->
    zm_config:get(achieve_sample_table, Sid).
%% ----------------------------------------------------
%% @doc
%%       获得任务条件
%% @end
%% ----------------------------------------------------
-spec get_condition(integer()) -> tuple() | 'none'.
get_condition(Sid) ->
    zm_config:get(achieve_condition_table, Sid).
%% ----------------------------------------------------
%% @doc
%%       解压(根据当前步骤初始化条件和奖励)
%% @end
%% ----------------------------------------------------
-spec decode({'sid', integer(), list()}) -> {'sid', integer(), achieve:achieve()}.
decode({sid, _, _} = EncodedAchieve) ->
    {sid, Sid, Achieve} = zm_sample:decode(EncodedAchieve, {fun(_, Sid) ->
        zm_config:get(achieve_sample_encode_table, Sid) end, none}),
    NAchieve = case achieve_lib:get_condition(Sid) of
        none ->
            Achieve;
        {_, ConditionList, AwardList} ->
            State = achieve:get_state(Achieve),
            Step = achieve:get_step(Achieve),
            case State =:= ?FINISH of
                true ->
                    change_achieve(Achieve, ConditionList, AwardList);
                false ->
                    NA = achieve:set_step(change_achieve(achieve:set_step(Achieve, max(Step - 1, 0)), ConditionList, AwardList), Step),
                    NState = achieve:get_state(NA),
                    case NState =:= ?FINISH of
                        true ->
                            NA;
                        false ->
                            achieve:set_state(NA, State)
                    end
            end
    end,
    {sid, Sid, NAchieve}.

%% ----------------------------------------------------
%% @doc
%%       压缩
%% @end
%% ----------------------------------------------------
-spec encode({'sid', integer(), achieve:achieve()}) -> {'sid', integer(), list()}.
encode(Achieve) ->
    zm_sample:encode(Achieve, {fun(_, Sid) -> zm_config:get(achieve_sample_encode_table, Sid) end, none}).


%% ----------------------------------------------------
%% @doc
%%      获取皇榜任务可领取次数
%% @end
%% ----------------------------------------------------
-spec get_accept_times(atom(), integer()) -> integer().
get_accept_times(Src, RoleUid) ->
    Role = role_db:get_role(Src, RoleUid),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    RoleLv = role_show:get_level(RoleShow),
    AcceptTimes1 = game_lib:level_value(RoleLv, element(2, element(2, zm_config:get('mission_info', 'accept_times')))),
    AcceptTimes2 = vip_lib:get_accept_times(Role),
    AcceptTimes1 + AcceptTimes2.

%% ----------------------------------------------------
%% @doc
%%      获取皇榜任务可放弃次数
%% @end
%% ----------------------------------------------------
-spec get_give_up_times(atom(), integer()) -> integer().
get_give_up_times(Src, RoleUid) ->
    Role = role_db:get_role(Src, RoleUid),
    RoleShow = role_db:get_role_show(Src, RoleUid),
    RoleLv = role_show:get_level(RoleShow),
    GiveUpTimes1 = game_lib:level_value(RoleLv, element(2, element(2, zm_config:get('mission_info', 'give_up_times')))),
    GiveUpTimes2 = vip_lib:get_give_up_times(Role),
    GiveUpTimes1 + GiveUpTimes2.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%       遍历任务条件元组
%% @end
%% ----------------------------------------------------
-spec foreach(achieve:achieve(), term(), term()) -> term().
foreach(Tuple, F, A) ->
    foreach(Tuple, ?CONDITION_MIN, ?CONDITION_MAX, F, A).

%% ----------------------------------------------------
%% @doc
%%       遍历任务条件元组
%% @end
%% ----------------------------------------------------
-spec foreach(achieve:achieve(), integer(), integer(), term(), term()) -> term().
foreach(Tuple, I, N, F, A) when I =< N ->
    case element(I, Tuple) of
        E when is_tuple(E) ->
            case F(A, I, E) of
                {ok, A1} ->
                    foreach(Tuple, I + 1, N, F, A1);
                {break, A1} ->
                    A1;
                A1 ->
                    foreach(Tuple, I + 1, N, F, A1)
            end;
        _ ->
            A
    end;
foreach(_Tuple, _I, _N, _F, A) ->
    A.

%% ----------------------------------------------------
%% @doc
%%       通知造成的条件元组的修改
%% @end
%% ----------------------------------------------------
-spec notify_modify(achieve:achieve(), [{integer(), term()}]) -> achieve:achieve().
notify_modify(Tuple, [{I, C} | T]) ->
    notify_modify(setelement(I, Tuple, C), T);
notify_modify(Tuple, []) ->
    Tuple.

%% ----------------------------------------------------
%% @doc
%%      用指定的事件通知任务，通知修改，一个事件
%% @end
%% ----------------------------------------------------
-spec notify_(role:role(), achieve:achieve(), term()) -> achieve:achieve() | 'ignore'.
notify_(Role, Achieve, Event) ->
    State = achieve:get_state(Achieve),
    if
        State =:= ?FINISH ->
            'ignore';
        true ->
            F = fun(A, I, {M, MA1, MA2, Var}) ->
                case M:notify(MA1, Var, Event) of
                    'ignore' ->
                        A;
                    {'ok', Var1} ->%只有未完成状态进入,增加之后如果已经完成则修改为完成状态
                        case M:finish(MA1, MA2, Var1) of
                            true ->
                                {'break', {'finish', [{I, {M, MA1, MA2, Var1}} | A]}};
                            false ->
                                [{I, {M, MA1, MA2, Var1}} | A]
                        end
                end;
                (A, _I, _E) ->
                    A
            end,
            case foreach(Achieve, F, []) of
                {'finish', L} ->
                    NAchieve = notify_modify(Achieve, L),
                    case complete(NAchieve, Role) of
                        'ok' ->
                            if
                                State =:= ?UNFINISH ->
                                    achieve:set_state(NAchieve, ?COMPLETE);
                                true ->
                                    NAchieve
                            end;
                        _ ->
                            NAchieve
                    end;
                [] ->
                    'ignore';
                L ->
                    notify_modify(Achieve, L)
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      初始化条件校验
%% @end
%% ----------------------------------------------------
-spec check(tuple(), any(), term()) -> boolean().
check({Role, _AchieveSet}, _, {role_level, Level}) ->%%等级
    game_lib:get_level('role', Role) >= Level;
check({_Role, AchieveList}, _, {'complete_achieves', Sid, Step}) ->%%完成任务
    case lists:keyfind(Sid, 2, AchieveList) of
        false ->
            false;
        R ->
            {_, _, Achieve} = achieve_lib:decode(R),
            achieve:get_state(Achieve) =:= ?FINISH orelse achieve:get_step(Achieve) > Step
    end;
check(_, _, {not_init, _}) ->%%皇榜任务不初始化,玩家自己接
    false.

%% ----------------------------------------------------
%% @doc
%%      获取任务完成奖励
%% @end
%% ----------------------------------------------------
-spec get_complete_award(atom(), integer(), integer()) -> list().
get_complete_award(_Src, _RoleUid, AchieveAwardSid) ->
    element(2, zm_config:get('achieve_award', AchieveAwardSid)).
