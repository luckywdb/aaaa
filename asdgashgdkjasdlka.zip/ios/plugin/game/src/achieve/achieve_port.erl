%%成就系统通讯端口
-module(achieve_port).
-description("achieve_port").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).
%%%=======================EXPORT=======================
-export([
    get_achieves/5,
    complete_achieve/5,
    star_award/5,
    get_achieves_/2,
    town_achieve/5,
    accept/5,
    give_up/5
]).

%%%=======================INCLUDE======================
-include("../include/achieve.hrl").
%%%=======================DEFINE======================

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      得到任务
%% @end
%% ----------------------------------------------------
get_achieves(_, _, Attr, Info, _) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, src, none),
    {ok, [], Info, [{msg, get_achieves_(Src, RoleUid)}]}.

%% ----------------------------------------------------
%% @doc
%%      完成成就
%% @end
%% ----------------------------------------------------
complete_achieve(_, _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    Sid = z_lib:get_value(Msg, "sid", 0),
    case zm_config:get('achieve_sample_table', Sid) of
        none ->
            {ok, [], Info, [{msg, "input_error"}]};
        _ ->
            TownSid = list_to_integer(z_lib:get_value(Msg, "town_sid", "0")),
            CheckVaild = valid_lib:check_valib([{'ge', TownSid, 0}]),
            if
                CheckVaild ->
                    case achieve_db:complete(Src, RoleUid, Sid, TownSid) of
                        {ok, {sid, Sid, Achieve}, UpdateAchieveList} ->
                            set_front_lib:send_achieve(Src, RoleUid, list_to_tuple([achieve_lib:format_achieve(A) || A <- UpdateAchieveList])),
                            AwardLog =
                                if
                                    TownSid > 0 ->
                                        {M, F, A} = achieve:get_award(Achieve),
                                        achieve_db:delete_refresh_monster_times(Src, RoleUid, Sid),
                                        M:F(A, Src, RoleUid, TownSid, Sid);
                                    true ->
                                        AwardList =
                                            case achieve:get_award(Achieve) of
                                                {M, F, A} ->
                                                    M:F(Src, RoleUid, A);
                                                ID ->
                                                    element(2, zm_config:get('achieve_award', ID))
                                            end,
                                        %奖励
                                        awarder_game:give_award(Src, RoleUid, ?MODULE, AwardList)
                                end,
                            %% 记录任务完成日志
                            zm_log:info(Src, ?MODULE, 'complete_achieve', "complete_achieve", [{'roleuid', RoleUid}, {'sid', Sid}, {'achieve', Achieve}, {'award', AwardLog}]),
                            %% 任务完成触发事件
                            zm_event:notify(Src, 'bi_achieve_complete', [{'role_uid', RoleUid}, {'sid', Sid}, {'achieve', Achieve}, {'award', AwardLog}]),
                            {ok, [], Info, [{msg, AwardLog}]};
                        {'update', Other, UpdateAchieveList} ->
                            set_front_lib:send_achieve(Src, RoleUid, list_to_tuple([achieve_lib:format_achieve(A) || A <- UpdateAchieveList])),
                            {ok, [], Info, [{msg, Other}]};
                        Other ->
                            {ok, [], Info, [{msg, Other}]}
                    end;
                true ->
                    {'ok', [], Info, [{'msg', "input_error"}]}
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      领星星奖励
%% @end
%% ----------------------------------------------------
star_award(_, _, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, src, none),
    RoleUid = role_lib:get_uid(Attr),
    Index = z_lib:get_value(Msg, "index", 0),
    case zm_config:get('achieve_star_award', Index) of
        none ->
            {ok, [], Info, [{msg, "input_error"}]};
        {_, Star, LevelAward} ->
            Role = z_db_lib:get(game_lib:get_table(Src, 'role'), RoleUid),
            Level = game_lib:get_level('role', Role),
            F = fun({'sid', _, Achieve}) ->
                case achieve:get_type(Achieve) =:= ?CYCLE_ACHIEVE of
                    false ->
                        0;
                    true ->
                        achieve_db:computer_integral(Level, Achieve)
                end
            end,
            Integral = lists:sum(lists:map(F, achieve_db:refresh(Src, RoleUid))),
            Day = time_lib:get_date_by_type('day_of_year'),
            F2 = fun(_, KVS) ->
                Times = [{K, V} || {K, V} <- KVS, V =:= Day],
                case lists:keyfind(Index, 1, Times) of
                    false ->
                        if
                            Integral >= Star ->
                                {ok, ok, lists:keystore(Index, 1, Times, {Index, Day})};
                            true ->
                                throw("achieve_integral_no_enough")
                        end;
                    _ ->
                        throw("achieve_integral_already_get")
                end
            end,
            Reply = case z_db_lib:update(game_lib:get_table(Src, 'times_set'), {RoleUid, 1}, [], F2, []) of
                ok ->
                    Award = game_lib:level_value(Level, LevelAward),
                    %奖励
                    AwardInfo = awarder_game:give_award(Src, RoleUid, ?MODULE, Award),
                    %% 任务星级奖励日志
                    zm_log:info(Src, ?MODULE, 'star_award', "achieve_star_award", [{'roleuid', RoleUid}, {'index', Index}, {'award', AwardInfo}]),
                    %% 任务星级奖励触发事件
                    zm_event:notify(Src, 'bi_achieve_star_award', [{'role_uid', RoleUid}, {'index', Index}, {'award', AwardInfo}]),
                    AwardInfo;
                Other ->
                    AchieveSet = achieve_db:get_achieves(Src, RoleUid),
                    set_front_lib:send_achieve(Src, RoleUid, list_to_tuple([achieve_lib:format_achieve(achieve_lib:decode(A)) || A <- tuple_to_list(AchieveSet)])),
                    Other
            end,
            {ok, [], Info, [{msg, Reply}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     获取城池任务信息
%%     皇榜db存储: {当日接取任务次数,[{城池sid,{刷新日期,当前刷新任务sids,当前刷新已领取的任务sids}}]}
%% @end
%% ----------------------------------------------------
town_achieve(_, _, Attr, Info, Msg) ->
    TownSid = list_to_integer(z_lib:get_value(Msg, "town_sid", "0")),
    CheckVaild = valid_lib:check_valib([{'gt', TownSid, 0}]),
    if
        CheckVaild ->
            Src = z_lib:get_value(Info, src, none),
            RoleUid = role_lib:get_uid(Attr),
            RoleShow = role_db:get_role_show(Src, RoleUid),
            CorpsUid = role_show:get_corps_uid(RoleShow),
            if
                CorpsUid > 0 ->
                    case point_db:chk_corps_owner(Src, CorpsUid, TownSid) of
                        true ->
                            Day = time_lib:get_date_by_type('day_of_year'),
                            RoleLv = role_show:get_level(RoleShow),
                            TownDetail = town_detail:get_cfg(TownSid),
                            TownLv = town_db:get_town_lv(Src, TownSid, TownDetail),
                            Fun = fun(_, {AcceptNum, GiveUpNum, RefreshDay, TownAchieve}) ->
                                {NAcceptNum, NGiveUpNum} = if
                                    RefreshDay =:= Day ->
                                        {AcceptNum, GiveUpNum};
                                    true ->
                                        {0, 0}
                                end,
                                case lists:keyfind(TownSid, 1, TownAchieve) of
                                    {_, {Day, Sids, ASids}} ->
                                        {'ok', {list_to_tuple(Sids), list_to_tuple(ASids)}, {NAcceptNum, NGiveUpNum, Day, TownAchieve}};
                                    _ ->
                                        TownType = town_detail:get_type(TownDetail),
                                        {_, {M, F, A}} = zm_config:get('mission_info', {TownType, TownLv}),
                                        {PoolList, _} = M:F(A, RoleLv, []),
                                        NTAchieve = lists:keystore(TownSid, 1, TownAchieve, {TownSid, {Day, PoolList, []}}),
                                        {'ok', {list_to_tuple(PoolList), {}}, {NAcceptNum, NGiveUpNum, Day, NTAchieve}}
                                end
                            end,
                            Reply = z_db_lib:update(game_lib:get_table(Src, 'town_achieve'), RoleUid, {0, 0, 0, []}, Fun, []),
                            {'ok', [], Info, [{'msg', Reply}]};
                        false ->
                            {'ok', [], Info, [{'msg', "town_not_owner"}]}
                    end;
                true ->
                    {'ok', [], Info, [{'msg', "no_corps"}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     接任务
%% @end
%% ----------------------------------------------------
accept([{M, F, A}], _, Attr, Info, Msg) ->
    TownSid = list_to_integer(z_lib:get_value(Msg, "town_sid", "0")),
    MSid = list_to_integer(z_lib:get_value(Msg, "m_sid", "0")),
    CheckVaild = valid_lib:check_valib([{'gt', TownSid, 0}, {'gt', MSid, 0}]),
    if
        CheckVaild ->
            Src = z_lib:get_value(Info, src, none),
            RoleUid = role_lib:get_uid(Attr),
            RoleShow = role_db:get_role_show(Src, RoleUid),
            CorpsUid = role_show:get_corps_uid(RoleShow),
            if
                CorpsUid > 0 ->
                    case point_db:chk_corps_owner(Src, CorpsUid, TownSid) of
                        true ->
                            DayMax = achieve_lib:get_accept_times(Src, RoleUid),
                            Day = time_lib:get_date_by_type('day_of_year'),
                            RoleLv = role_show:get_level(RoleShow),
                            TableName = game_lib:get_table(Src),
                            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'town_achieve', RoleUid, {0, 0, 0, []}}, {'achieve', RoleUid, {}}]),
                            TownDetail = town_detail:get_cfg(TownSid),
                            TownLv = town_db:get_town_lv(Src, TownSid, TownDetail),
                            Reply = z_db_lib:handle(TableName, {M, F, A}, {Day, RoleLv, TownSid, MSid, TownDetail, TownLv, DayMax}, TableKeys),
                            {'ok', [], Info, [{'msg', Reply}]};
                        false ->
                            {'ok', [], Info, [{'msg', "town_not_owner"}]}
                    end;
                true ->
                    {'ok', [], Info, [{'msg', "no_corps"}]}
            end;
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.

%% ----------------------------------------------------
%% @doc
%%     放弃任务
%% @end
%% ----------------------------------------------------
give_up([{M, F, A}], _, Attr, Info, Msg) ->
    ASid = list_to_integer(z_lib:get_value(Msg, "asid", "0")),
    TSid = list_to_integer(z_lib:get_value(Msg, "tsid", "0")),
    CheckVaild = valid_lib:check_valib([{'gt', ASid, 0}, {'gt', TSid, 0}]),
    if
        CheckVaild ->
            Src = z_lib:get_value(Info, src, none),
            RoleUid = role_lib:get_uid(Attr),
            DayMax = achieve_lib:get_give_up_times(Src, RoleUid),
            Day = time_lib:get_date_by_type('day_of_year'),
            TableName = game_lib:get_table(Src),
            TableKeys = z_db_lib:transformation_tablekey(TableName, [{'town_achieve', RoleUid, {0, 0, 0, []}}, {'achieve', RoleUid, {}}]),
            Reply = z_db_lib:handle(TableName, {M, F, A}, {Day, DayMax, ASid, TSid}, TableKeys),
            {'ok', [], Info, [{'msg', Reply}]};
        true ->
            {'ok', [], Info, [{'msg', "input_error"}]}
    end.


%%%======================LOC FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      得到任务
%% @end
%% ----------------------------------------------------
-spec get_achieves_(atom(), integer()) -> {tuple(), tuple()}.
get_achieves_(Src, RoleUid) ->
    AchieveSet = list_to_tuple([achieve_lib:format_achieve(Achieve) || Achieve <- achieve_db:refresh(Src, RoleUid)]),
    Day = time_lib:get_date_by_type('day_of_year'),
    Times = [K || {K, V} <- z_db_lib:get(game_lib:get_table(Src, 'times_set'), {RoleUid, 1}, []), V =:= Day],
    {erlang:list_to_tuple(Times), AchieveSet}.