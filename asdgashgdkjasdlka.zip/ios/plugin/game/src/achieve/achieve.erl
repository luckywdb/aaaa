%%任务
-module(achieve).
-description("achieve").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).
%%%=======================EXPORT=======================
-compile(export_all).
%%%=======================INCLUDE======================

-export_type([
    achieve/0,
    condition/0,
    type/0,
    state/0
]).

%%%=======================DEFINE======================
-define(DATE_SECONDS, 86400).

%%%=======================RECORD=======================
-record(achieve, {
    condition1 :: condition(),
    condition2 :: condition(),
    condition3 :: condition(),
    condition4 :: condition(),
    condition5 :: condition(),
    condition6 :: condition(),
    condition7 :: condition(),
    condition8 :: condition(),
    award :: mfa() | integer(),%%奖励
    type :: type(),
    timeout :: term(),%%超时时间
    step :: integer(),%%处于第几步骤
    state :: state(),
    integral :: mfa() | integer()  | [integer()],%%任务积分
    init_conds :: list(),%%初始化条件(主公等级,前置任务步数)
    triggers :: [{integer(), [integer()]}],%%触发任务列表 [{步骤,[sid]}]
    info :: list()
}).

-type achieve() :: #achieve{}.
%%任务条件
-type condition() :: {module(), term(), term(), term()} | {module(), term(), term()} | 'none'.
%%任务类型
-type type() :: 0..3.%%0主线 1日常,2军团任务,3城池皇榜任务
%%任务状态
-type state() :: 0..2.%%0为未完成,1为已完成未领奖,2已领奖


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      获得奖励
%% @end
%% ----------------------------------------------------
-spec get_award(achieve()) -> mfa() | integer().
get_award(#achieve{award = Award}) ->
    Award.
%% ----------------------------------------------------
%% @doc
%%      获得类型
%% @end
%% ----------------------------------------------------
-spec get_type(achieve()) -> type().
get_type(#achieve{type = Type}) ->
    Type.
%% ----------------------------------------------------
%% @doc
%%      获得步骤
%% @end
%% ----------------------------------------------------
-spec get_step(achieve()) -> integer().
get_step(#achieve{step = Step}) ->
    Step.
%% ----------------------------------------------------
%% @doc
%%      获得任务积分
%% @end
%% ----------------------------------------------------
-spec get_integral(achieve()) -> mfa() | integer() | [integer()].
get_integral(#achieve{integral = Integral}) ->
    Integral.
%% ----------------------------------------------------
%% @doc
%%      获得状态
%% @end
%% ----------------------------------------------------
-spec get_state(achieve()) -> state().
get_state(#achieve{state = State}) ->
    State.
%% ----------------------------------------------------
%% @doc
%%      初始化条件
%% @end
%% ----------------------------------------------------
-spec get_init_conds(achieve()) -> list().
get_init_conds(#achieve{init_conds = InitConds}) ->
    InitConds.
%% ----------------------------------------------------
%% @doc
%%      触发任务sid列表
%% @end
%% ----------------------------------------------------
-spec get_triggers(achieve()) -> [{integer(), [integer()]}].
get_triggers(#achieve{triggers = Triggers}) ->
    Triggers.
%% ----------------------------------------------------
%% @doc
%%      获得超时时间
%% @end
%% ----------------------------------------------------
-spec get_timeout(achieve()) -> term().
get_timeout(#achieve{timeout = TimeOut}) ->
    TimeOut.

%% ----------------------------------------------------
%% @doc
%%      获得拓展信息
%% @end
%% ----------------------------------------------------
-spec get_info(achieve()) -> list().
get_info(#achieve{info = Info}) ->
    Info.


%% ----------------------------------------------------
%% @doc
%%      设置奖励
%% @end
%% ----------------------------------------------------
-spec set_award(achieve(), mfa() | integer()) -> achieve().
set_award(Achieve, Award) ->
    Achieve#achieve{award = Award}.

%% ----------------------------------------------------
%% @doc
%%      设置步骤
%% @end
%% ----------------------------------------------------
-spec set_step(achieve(), integer()) -> achieve().
set_step(Achieve, Step) ->
    Achieve#achieve{step = Step}.

%% ----------------------------------------------------
%% @doc
%%      设置状态
%% @end
%% ----------------------------------------------------
-spec set_state(achieve(), state()) -> achieve().
set_state(Achieve, State) ->
    Achieve#achieve{state = State}.

%% ----------------------------------------------------
%% @doc
%%      设置任务的超时时间
%% @end
%% ----------------------------------------------------
-spec set_timeout(achieve(), term()) -> achieve().
set_timeout(#achieve{timeout = 0} = Achieve, _) ->
    Achieve;
set_timeout(#achieve{timeout = Timeout} = Achieve, Second) when is_integer(Timeout) ->
    Achieve#achieve{timeout = Timeout + Second};
set_timeout(#achieve{timeout = HourList} = Achieve, Second) when is_list(HourList) -> %%每天整时
    {Day, {Hour, _, _}} = z_lib:second_to_localtime(Second),
    NHour = z_lib:foreach(fun(Args, H) ->
        if
            H > Hour ->
                {'break', H};
            true ->
                {'ok', Args}
        end
    end, -1, HourList),
    NTimeout =
        if
            NHour =:= -1 ->
                [NHour1 | _] = HourList,
                z_lib:localtime_to_second({Day, {NHour1, 0, 0}}) + ?DATE_SECONDS;
            true ->
                z_lib:localtime_to_second({Day, {NHour, 0, 0}})
        end,
    Achieve#achieve{timeout = NTimeout};
set_timeout(#achieve{timeout = day} = Achieve, Second) ->%%过期时间1天
    {Day, _} = z_lib:second_to_localtime(Second + ?DATE_SECONDS),
    Achieve#achieve{timeout = z_lib:localtime_to_second({Day, {0, 0, 0}})};
set_timeout(#achieve{timeout = day2} = Achieve, Second) ->%%过期时间2天
    {Day, _} = z_lib:second_to_localtime(Second + ?DATE_SECONDS + ?DATE_SECONDS),
    Achieve#achieve{timeout = z_lib:localtime_to_second({Day, {0, 0, 0}})};
set_timeout(#achieve{timeout = week} = Achieve, Second) ->%%过期时间1周
    {Day, _} = z_lib:second_to_localtime(Second),
    {Day1, _} = z_lib:second_to_localtime(Second +
        (8 - calendar:day_of_the_week(Day)) * ?DATE_SECONDS),
    Achieve#achieve{timeout = z_lib:localtime_to_second({Day1, {0, 0, 0}})};
set_timeout(#achieve{timeout = week2} = Achieve, Second) ->%%过期时间2周
    {Day, _} = z_lib:second_to_localtime(Second),
    {Day1, _} = z_lib:second_to_localtime(Second +
        (15 - calendar:day_of_the_week(Day)) * ?DATE_SECONDS),
    Achieve#achieve{timeout = z_lib:localtime_to_second({Day1, {0, 0, 0}})};
set_timeout(#achieve{timeout = month} = Achieve, Second) ->%%过期时间1个月
    {{Y, M, _D}, _} = z_lib:second_to_localtime(Second),
    Achieve#achieve{timeout = z_lib:localtime_to_second(
        {{Y, M, calendar:last_day_of_the_month(Y, M)}, {23, 59, 59}}) + 1};
set_timeout(#achieve{timeout = month2} = Achieve, Second) ->%%过期时间2个月
    case z_lib:second_to_localtime(Second) of
        {{Y, 12, _D}, _} ->
            Achieve#achieve{timeout = z_lib:localtime_to_second(
                {{Y + 1, 1, calendar:last_day_of_the_month(Y + 1, 1)}, {23, 59, 59}}) + 1};
        {{Y, M, _D}, _} ->
            Achieve#achieve{timeout = z_lib:localtime_to_second(
                {{Y, M + 1, calendar:last_day_of_the_month(Y, M + 1)}, {23, 59, 59}}) + 1}
    end.

%% ----------------------------------------------------
%% @doc
%%      设置拓展信息
%% @end
%% ----------------------------------------------------
-spec set_info(achieve(), list()) -> achieve().
set_info(Achieve, Info) ->
    Achieve#achieve{info = Info}.

%% ----------------------------------------------------
%% @doc
%%     获取任务所属城池信息
%% @end
%% ----------------------------------------------------
get_townsid(#achieve{info = Info}) ->
    case lists:keyfind('town', 1, Info) of
        false ->
            0;
        {_, Sid} ->
            Sid
    end.
%% ----------------------------------------------------
%% @doc
%%     设置城池sid
%% @end
%% ----------------------------------------------------
set_townsid(#achieve{info = Info} = Achieve, TownSid) ->
    Achieve#achieve{info = lists:keystore('town', 1, Info, {'town', TownSid})}.
