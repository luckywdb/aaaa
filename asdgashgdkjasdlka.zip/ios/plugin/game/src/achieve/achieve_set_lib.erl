-module(achieve_set_lib).
-description("achieve_set_lib").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).
%%%=======================EXPORT=======================

%%%=======================INCLUDE======================
-include("../include/achieve.hrl").

%%%=======================DEFINE=======================

%%%=================EXPORTED FUNCTIONS==================

%%%=======================EXPORT=======================
-export([notify/4, complete/4, check_achieve/2]).

%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      用指定的事件通知任务集，如果任务已经超时，则忽略事件
%% @end
%% ----------------------------------------------------
-spec notify(Role, AchieveSet, Events, Second) -> {NAchieveSet, ModifyTaskList} when
    Role :: role:role(),
    AchieveSet :: tuple(),%{'sid', integer(), list()}
    Events :: term(),
    Second :: integer(),
    NAchieveSet :: tuple(),%{'sid', integer(), list()}
    ModifyTaskList :: [achieve:achieve()].
notify(Role, AchieveSet, Events, Second) ->
    Ftemp = fun(A, I, Achieve) ->
        {sid, Sid, Record} = achieve_lib:decode(Achieve),
        Type = achieve:get_type(Record),
        State = achieve:get_state(Record),
        case achieve_lib:check_timeout(Record, Second) of
            true when Type =:= ?CYCLE_ACHIEVE ->%%超时、日常
                {_, _, NRecord} = achieve_lib:achieve(achieve_lib:get_sample(Sid), Second),
                case achieve_lib:notify(Role, NRecord, Events) of
                    ignore ->
                        A;
                    S1 ->
                        [{I, {sid, Sid, S1}} | A]
                end;
            true ->%%超时
                A;
            _ when State =:= ?UNFINISH ->
                case achieve_lib:notify(Role, Record, Events) of
                    ignore ->
                        A;
                    S1 ->
                        [{I, {sid, Sid, S1}} | A]
                end;
            _ ->
                A
        end
    end,
    notify_modify(AchieveSet, z_lib:tuple_foreach(AchieveSet, Ftemp, []), []).

%% ----------------------------------------------------
%% @doc
%%      完成任务集中指定角色的指定任务，会调用check方法保证正确性，完成后会加上后续条件
%% @end
%% ----------------------------------------------------
complete(AchieveSet, RoleUid, AchieveSid, TownSid) ->
    Second = time_lib:now_second(),
    Ftemp = fun
        (A, I, {_, Sid, _} = Prop) when Sid =:= AchieveSid ->
            {sid, _, Record} = Achieve = achieve_lib:decode(Prop),
            State = achieve:get_state(Record),
            TSid = achieve:get_townsid(Record),
            Type = achieve:get_type(Record),
            if
                Type =:= ?TOWN_ACHIEVE andalso TSid =:= TownSid andalso State =:= ?COMPLETE ->%皇榜任务,只有已经完成状态,未领奖的情况
                    {'break', {I, State, Record, Achieve}};
                Type =/= ?TOWN_ACHIEVE ->%其他任务
                    {'break', {I, State, Record, Achieve}};
                true ->
                    {'ok', A}
            end;
        (A, _I, _E) ->
            A
    end,
    case z_lib:tuple_foreach(AchieveSet, Ftemp, -1) of
        -1 ->
            "achieve_not_found";
        {I, State, ARecord, Achieve1} ->
            if
                State =:= ?UNFINISH orelse State =:= ?COMPLETE ->
                    case complete2(RoleUid, AchieveSid, ARecord, Second) of
                        {'ok', 'delete'} ->%过期皇榜任务领取后直接删除
                            NAchieveSet = erlang:delete_element(I, AchieveSet),
                            {ok, NAchieveSet, 'delete', Achieve1};
                        {ok, NRecord} ->
                            NAchieve = achieve_lib:set_record(Achieve1, NRecord),
                            NAchieveSet = setelement(I, AchieveSet, achieve_lib:encode(NAchieve)),
                            {ok, NAchieveSet, NAchieve, Achieve1};
                        E ->
                            E
                    end;
                true ->
                    "achieve_already_finish"
            end
    end.

%% ----------------------------------------------------
%% @doc
%%      检查任务集合
%% @end
%% ----------------------------------------------------
-spec check_achieve(AchieveSet, Second) -> {NAchieveSet, UpdateAchieveList} when
    AchieveSet :: tuple(),%{'sid', integer(), list()}
    Second :: integer(),
    NAchieveSet :: tuple(),%{'sid', integer(), list()}
    UpdateAchieveList :: [{'sid', integer(), achieve:achieve()}].
check_achieve(AchieveSet, Second) ->
    check_achieve_(AchieveSet, 1, tuple_size(AchieveSet), Second, []).
%% ----------------------------------------------------
%% @doc
%%      逐条检测是否超时和刷新 Achieves成就集合,I索引,M最大值,Return最终返回是否改变成就集合
%% @end
%% ----------------------------------------------------
-spec check_achieve_(AchieveSet, I, M, Second, UpdateList) -> NAchieveSet when
    AchieveSet :: tuple(),%{'sid', integer(), list()}
    I :: integer(),
    M :: integer(),
    Second :: integer(),
    NAchieveSet :: tuple(),%{'sid', integer(), list()}
    UpdateList :: [{'sid', integer(), achieve:achieve()}].
check_achieve_(Achieves, I, M, Second, UpdateList) when I =< M ->
    {sid, Sid, ARecord} = Achieve = achieve_lib:decode(element(I, Achieves)),
    Bool = achieve_lib:check_timeout(ARecord, Second),
    Type = achieve:get_type(ARecord),
    if
        Bool andalso (Type =:= ?CYCLE_ACHIEVE orelse Type =:= ?CORPS_ACHIEVE) ->
            NewAchieve = achieve_lib:achieve(achieve_lib:get_sample(Sid), Second),
            check_achieve_(setelement(I, Achieves, achieve_lib:encode(NewAchieve)), I + 1, M, Second, [NewAchieve | UpdateList]);
        Bool andalso Type =:= ?TOWN_ACHIEVE -> %皇榜任务,已领奖的已超时的任务删除,未完成的也删除,已完成未领奖的保留
            State = achieve:get_state(ARecord),
            if
                State =:= ?COMPLETE -> %已完成未领奖
                    check_achieve_(Achieves, I + 1, M, Second, UpdateList);
                true ->%未完成;已领奖的都删除
                    check_achieve_(erlang:delete_element(I, Achieves), I, M - 1, Second, UpdateList)
            end;
        Bool ->%%主线任务超时，设置已完成
            NewAchieve = achieve_lib:set_record(Achieve, achieve:set_state(ARecord, ?FINISH)),
            check_achieve_(setelement(I, Achieves, achieve_lib:encode(NewAchieve)), I + 1, M, Second, [NewAchieve | UpdateList]);
        true ->
            NewAchieve = achieve_lib:init_condition(Achieve),
            if
                Achieve =:= NewAchieve ->
                    check_achieve_(Achieves, I + 1, M, Second, UpdateList);
                true ->
                    check_achieve_(setelement(I, Achieves, achieve_lib:encode(NewAchieve)), I + 1, M, Second, [NewAchieve | UpdateList])
            end
    end;
check_achieve_(AchieveSet, _, _, _, UpdateList) ->
    {AchieveSet, UpdateList}.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%      通知造成的任务元组的修改
%% @end
%% ----------------------------------------------------
-spec notify_modify(AchieveSet, IndexAchieveChangeList, ModifyTaskAcc) -> {NAchieveSet, ModifyTaskList} when
    AchieveSet :: tuple(),%{'sid', integer(), list()}
    IndexAchieveChangeList :: [{integer(), achieve:achieve()}],
    ModifyTaskAcc :: [{'sid', integer(), achieve:achieve()}],
    NAchieveSet :: tuple(),%{'sid', integer(), list()}
    ModifyTaskList :: [{'sid', integer(), achieve:achieve()}].
notify_modify(Tuple, [{I, Achieve} | T], L) ->
    notify_modify(setelement(I, Tuple, achieve_lib:encode(Achieve)), T, [Achieve | L]);
notify_modify(Tuple, [], L) ->
    {Tuple, L}.

%% ----------------------------------------------------
%% @doc
%%      完成任务时要先查看是否有后续任务
%% @end
%% ----------------------------------------------------
complete2(RoleUid, Sid, ARecord, Second) ->
    Type = achieve:get_type(ARecord),
    TimeOut = achieve_lib:check_timeout(ARecord, Second),
    if
        Type =:= ?TOWN_ACHIEVE -> %皇榜任务允许过期了领奖
            case complete3(RoleUid, Sid, ARecord) of
                {'ok', NewARecord} ->
                    if
                        TimeOut ->
                            {'ok', 'delete'};%过期皇榜任务领奖后删除
                        true ->
                            {'ok', NewARecord}
                    end;
                Err ->
                    Err
            end;
        true ->
            if
                TimeOut ->
                    "achieve_timeout";
                true ->
                    complete3(RoleUid, Sid, ARecord)
            end
    end.

complete3(RoleUid, Sid, ARecord) ->
    case achieve_lib:check(ARecord, RoleUid) of
        true ->
            NewARecord = achieve_lib:next_condition(Sid, ARecord),%%新的成就记录
            case achieve_lib:complete(ARecord, RoleUid) of
                ok ->
                    {ok, NewARecord};
                E ->
                    E
            end;
        false ->
            "achieve_not_completed"
    end.