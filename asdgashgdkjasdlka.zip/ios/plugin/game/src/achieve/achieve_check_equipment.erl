-module(achieve_check_equipment).

%%%=======================STATEMENT====================
-description("achieve_check_equipment").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([check/3, complete/3]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      外部条件检查
%% @end
%% ----------------------------------------------------
-spec check(term(), term(), term()) -> boolean().
%%equipment:FunName(Equipment)的值大于V的个数大于等于Value
check({Src, FunName}, {V, Value}, RoleUid) ->
    EStorage = storage_db:get_storage('equipment', Src, RoleUid),
    F = fun(N, _, 0) ->
        {'ok', N};
        (N, _, EquipProp) ->
            Equipment = prop_kit_lib:get_prop_record(EquipProp),
            case equipment:FunName(Equipment) >= V of
                true ->
                    Num = N + 1,
                    if
                        Num >= Value ->
                            {'break', Num};
                        true ->
                            {'ok', Num}
                    end;
                false ->
                    {'ok', N}
            end
    end,
    SNum = z_lib:tuple_foreach(EStorage, F, 0),
    if
        SNum >= Value ->
            true;
        true ->
            GarrayIds = garray_lib:get_garray_ids(Src, RoleUid),
            GarrayList = garray_db:get_garray(Src, RoleUid, GarrayIds),
            CardUidList = lists:foldl(fun({_, Garray}, Acc) ->
                [Uid || {Uid, _} <- tuple_to_list(garray:get_queue(Garray)), Uid =/= 0] ++ Acc
            end, [], GarrayList),
            Fun = fun(N, CardUid) ->
                CardPutProp = equipment_db:get(Src, CardUid),
                Equips = card_put_prop:get_equipments(CardPutProp),
                NewN = z_lib:tuple_foreach(Equips, F, N),
                if
                    NewN >= Value ->
                        {break, NewN};
                    true ->
                        {ok, NewN}
                end
            end,
            GNum = z_lib:foreach(Fun, SNum, CardUidList),
            if
                GNum >= Value ->
                    true;
                true ->
                    CStorage = storage_db:get_storage('card', Src, RoleUid),
                    CardFun = fun(Acc, _, CardProp) ->
                        Card = prop_kit_lib:get_prop_record(CardProp),
                        case card:get_state(Card) > 0 of
                            true ->
                                {'ok', Acc};
                            false ->
                                CardPutProp1 = equipment_db:get(Src, prop_kit_lib:get_prop_uid(CardProp)),
                                Equips1 = card_put_prop:get_equipments(CardPutProp1),
                                Num1 = z_lib:tuple_foreach(Equips1, F, Acc),
                                if
                                    Num1 >= Value ->
                                        {'break', Num1};
                                    true ->
                                        {'ok', Num1}
                                end
                        end
                    end,
                    z_lib:tuple_foreach(CStorage, CardFun, GNum) >= Value
            end
    end;
check(_, _, _) ->
    false.
%% ----------------------------------------------------
%% @doc
%%      外部条件完成
%% @end
%% ----------------------------------------------------
-spec complete(term(), term(), term()) -> 'ok' | string().
complete(_, _, _) ->
    ok.


%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
