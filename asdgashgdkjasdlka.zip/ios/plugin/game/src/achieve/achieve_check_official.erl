-module(achieve_check_official).

%%%=======================STATEMENT====================
-description("achieve_check_building").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([check/3, complete/3]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% @doc
%%      外部条件检查
%% @end
%% ----------------------------------------------------
-spec check(term(), term(), term()) -> boolean().
%%当前sid官职
check({Src, official_id, Sid}, _Value, RoleUid) ->
    Official = official_db:get_official(Src, RoleUid),
    official:get_oid(Official) =:= Sid;
%%%%当前有官职
check({Src, official_id}, _Value, RoleUid) ->
    Official = official_db:get_official(Src, RoleUid),
    official:get_oid(Official) =/= 0;
check(_, _, _) ->
    false.
%% ----------------------------------------------------
%% @doc
%%      外部条件完成
%% @end
%% ----------------------------------------------------
-spec complete(term(), term(), term()) -> 'ok' | string().
complete(_, _, _) ->
    ok.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc  
%%  
%% @end
%% ----------------------------------------------------
