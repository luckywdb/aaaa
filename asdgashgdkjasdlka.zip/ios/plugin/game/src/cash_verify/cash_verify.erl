%%%订单校验
-module(cash_verify).
%%%=======================STATEMENT====================
-description("cash_http_db").
-copyright('youkia,www.youkia.net').
-author('lb,luobo@youkia.net').
-vsn(1).
%%%=======================EXPORT=======================
-export([verify_order_table/1]).
-export([event/4, verify/3]).

%%%=======================INCLUDE======================
%%%=======================RECORD=======================
%%%=======================DEFINE=======================
-define(VERIFY_URL, "http://sgzcenter.youkia.net/index.php/record/invalid?").%接入中心给出的校验地址
-define(VERIFY_NUM, 10).%每次校验多少个
%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% Func: cash_order_table/1
%% Description: 订单缓存表
%% Key = order_id,value=Format_Log
%% Returns:
%% ----------------------------------------------------
cash_order_table(Src) ->
    game_lib:get_table(Src, order_cash).
%% ----------------------------------------------------
%% Func: verify_order_table/1
%% Description: 校验信息表
%% 订单白名单:Key = {exception_uid,服ID},value=[uid1,uid2,.....]
%% Returns:
%% ----------------------------------------------------
verify_order_table(Src) ->
    game_lib:get_table(Src, verify_order_info).

%% ----------------------------------------------------
%% Func: event/4
%% Description: 充值事件
%% Returns:
%% ----------------------------------------------------
event(_, Src, cash_event, {Info, Msg, Args}) ->
    RoleUid = z_lib:get_value(Args, role_uid, none),
    ServerID = z_lib:get_value(Msg, "game_server", none),
    Bool = lists:member(RoleUid, z_db_lib:get(verify_order_table(Src), {exception_uid, ServerID}, [])),
    if
        Bool ->%白名单中的玩家,不验证订单
            ok;
        true ->%非白名单中的玩家,需要先缓存起来,然后向sdk验证订单
            z_db_lib:update(cash_order_table(Src), z_lib:get_value(Msg, "orderid", none), format_log(Src, Info, Msg, Args))
    end.
%% ----------------------------------------------------
%% Func: verify/2
%% Description: 定时校验
%% Returns:
%% ----------------------------------------------------
verify(Src, _Args, _) ->
    Fun = fun(_, Key, _, {Num, R}) ->
        if
            Num >= ?VERIFY_NUM ->
                {'break', {Num, R}};
            true ->
                {'ok', {Num + 1, [Key | R]}}
        end
    end,
    case z_db_lib:table_iterate(Src, game_lib:get_table(Src, 'order_cash'), Fun, [], {0, []}) of
        {_, []} ->%没有数据不校验
            ok;
        {_, CheckList} ->
            %每一个Log以竖线分割
            FunMerge =
                fun(Key1, Acc) ->
                    [z_db_lib:get(cash_order_table(Src), Key1), "|" | Acc]
                end,
            try
                AllUrl = binary_to_list(list_to_binary([?VERIFY_URL, "logs=", lists:concat(lists:foldr(FunMerge, [], CheckList))])),
                case zm_communicator:request('http_connect_asyn_binary', 'get', AllUrl, 30000) of
                    {{_, _, "OK"}, _, Result} ->
                        [z_db_lib:delete(cash_order_table(Src), Key) || Key <- CheckList],%删除验证过的订单
                        zm_log:info(Src, ?MODULE, verify, "success", [{check_list, CheckList}, {result, Result}]);
                    Response ->
                        zm_log:warn(Src, ?MODULE, verify, "request_error", [{check_list, CheckList}, {all_url, AllUrl}, {response, Response}])
                end
            catch
                E1:E2 ->
                    [z_db_lib:delete(cash_order_table(Src), Key) || Key <- CheckList],%删除验证过的订单
                    zm_log:warn(Src, ?MODULE, verify, "error", [{check_list, CheckList}, {error, E1, E2, erlang:get_stacktrace()}])
            end
    end.

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% Func: format_log/3
%% Description: 格式化校验信息
%% 参数格式:bi_pid,订单ID,服务器名字(旧版本是pid_sid),p_uid,time,rmb,ip
%% 传给sdk的参数可以自定义,但是有一个bi_pid是必须要有的
%% Returns:
%% ----------------------------------------------------
format_log(Src, Info, Msg, _Args) ->
    ServerName = case z_lib:get_value(Msg, "server_name", none) of
        none ->
            lists:concat([args_system:get_sid(Src), "_", args_system:get_pid(Src)]);
        SN ->
            SN
    end,
    lists:concat([
        args_system:get_bi_pid(Src), ",",
        z_lib:get_value(Msg, "orderid", none), ",",
        ServerName, ",",
        z_lib:get_value(Msg, "userid", "0"), ",",
        time_lib:now_second(), ",",
        z_lib:get_value(Msg, "rmb", "0"), ",",
        z_lib:get_value(Info, host, "0")
    ]).
