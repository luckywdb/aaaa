%%限时抽卡活动
-module(active_ld).

%%%=======================STATEMENT====================
-description("active_ld").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_event/4, handle_format/3]).
-export([rank_view/4, get/6, role_red/4]).
%%%=======================DEFINE=======================

%%%=======================INCLUDE=======================
-include("../include/active.hrl").

%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
-spec handle_get(atom(), integer(), term(), active:active()) -> tuple().
handle_get(Src, RoleUid, A, Active) ->
    Key = active_lib:get_role_active_key(RoleUid, Active),
    Sid = active:get_sid(Active),
    {Score, List, _CList} = z_db_lib:get(game_lib:get_table(Src, ?MODULE), Key, {0, [], []}),
    [{{Template}, _, _}] = A,
    {_, LdInfo} = zm_config:get(ld_info, Template),
    Format = handle_format(Src, A, Active),
    CountInfo = ld_lib:front_format(Sid, ld:refresh_count(ld_db:get_ld_count(Src, {RoleUid, Sid})), LdInfo),
    {Format, {{Score, erlang:list_to_tuple(List)}, CountInfo}}.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
-spec handle_start(atom(), term(), active:active(), integer()) -> 'ok'.
handle_start(Src, _A, Active, _Time) ->
    start(Src, Active),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
-spec handle_run(atom(), term(), active:active(), integer()) -> 'ok'.
handle_run(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
-spec handle_close(atom(), term(), active:active(), integer()) -> 'ok'.
handle_close(Src, _A, Active, _Time) ->
    stop(Src, Active),
    zm_event:notify(Src, active_clear, {?MODULE, Active}),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
-spec handle_shut(atom(), term(), active:active(), integer()) -> 'ok'.
handle_shut(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动抽卡事件处理
%% @end
%%-------------------------------------------------------------------
-spec handle_event(atom(), term(), active:active(), tuple()) -> 'ok'.
handle_event(Src, A, Active, {'active_ld_ok', List}) ->
    RoleUid = z_lib:get_value(List, 'role_uid', 0),
    Choose = z_lib:get_value(List, 'choose', 0),
    Sid = z_lib:get_value(List, 'sid', 0),
    ASid = active:get_sid(Active),
    if
        Sid =:= ASid ->
            [{{Template}, _RankList, ScoreAwardList}] = A,
            Score = get_choose_score(Template, Choose),
            NScore = add_score(Src, RoleUid, Score, Active, ScoreAwardList),
%%            score_award(Src, RoleUid, Active, NScore, ScoreAwardList),
            %%增加积分后,排行榜刷新
            zm_event:notify(Src, 'active_rank', [{'sid', Sid}, {'uid', RoleUid}, {'value', NScore}, {'m', active:get_m(Active)}]),
            ok;
        true ->
            ok
    end;
handle_event(_Src, _A, _Active, _Event) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
-spec handle_format(atom(), list(), active:active()) -> tuple().
handle_format(Src, A, Active) ->
    [{{Template}, RankList, ScoreAwardList}] = A,
    LdInfo = element(2, zm_config:get(ld_info, Template)),
    Fun1 = fun({Min, Max, AwardList}) -> {Min, Max, list_to_tuple(AwardList)} end,
    Fun2 = fun({Index, Target, AwardList}) -> {Index, Target, list_to_tuple(AwardList)} end,
    {_, Times} = lists:keyfind(times, 1, LdInfo),
    Free = z_lib:get_value(LdInfo, free, 0),
    Cd = z_lib:get_value(LdInfo, cd, 0),
    {_, Score} = lists:keyfind(scores, 1, LdInfo),
    {_, CardSid} = lists:keyfind('card_sid', 1, LdInfo),
    Consumes = list_to_tuple(z_lib:tuple_foreach(Times, fun(Acc0, Index, Num) ->
        case Num =:= 0 of
            true ->
                {ok, [{Num, {}, 0} | Acc0]};
            false ->
                List = zm_config:get(ld_consume_info, {Template, Index}),
                NList = lists:filter(fun(Consume) ->
                    Type = element(1, Consume),
                    Type =:= money orelse Type =:= rmb orelse Type =:= prop
                end, element(3, List)),
                {ok, [{Num, list_to_tuple(NList), element(Index, Score)} | Acc0]}
        end
    end, [])),
    {
        active:format_front(Src, ?MODULE, Active),
        {{CardSid, Free, Cd, Consumes}, list_to_tuple(lists:map(Fun1, RankList)), list_to_tuple(lists:map(Fun2, ScoreAwardList))}
    }.


%%-------------------------------------------------------------------
%% @doc
%%      排行榜玩家显示数据
%% @end
%%-------------------------------------------------------------------
-spec rank_view(term(), atom(), integer(), integer()) -> tuple().
rank_view(_A, Src, RoleUid, Value) ->
    RoleShow = role_db:get_role_show(Src, RoleUid),
    {
        RoleUid,
        role_show:get_name(RoleShow),
        role_show:get_corps_uid(RoleShow),
        role_show:get_corps_name(RoleShow),
        Value,
        role_show:get_country(RoleShow)
    }.

%%-------------------------------------------------------------------
%% @doc
%%      增加积分
%% @end
%%-------------------------------------------------------------------
-spec add_score(atom(), integer(), integer(), active:active(), list()) -> integer().
add_score(Src, RoleUid, Score, Active, ScoreAwardList) ->
    Key = active_lib:get_role_active_key(RoleUid, Active),
    F = fun(_, {OldScore, List, _}) ->
        NewScore = OldScore + Score,
        CList = lists:foldl(fun({ItemSid, S, _AList}, Acc) ->
            case S =< NewScore andalso not lists:member(ItemSid, List) of
                true ->
                    [ItemSid | Acc];
                _ ->
                    Acc
            end
        end, [], ScoreAwardList),
        {ok, NewScore, {NewScore, List, CList}}
    end,
    z_db_lib:update(game_lib:get_table(Src, ?MODULE), Key, {0, [], []}, F, []).

%%%%-------------------------------------------------------------------
%%%% @doc
%%%%      发放达到积分奖励
%%%% @end
%%%%-------------------------------------------------------------------
%%-spec score_award(atom(), integer(), active:active(), integer(), list()) -> term().
%%score_award(Src, RoleUid, Active, NScore, ScoreAwardList) ->
%%    Key = active_lib:get_role_active_key(RoleUid, Active),
%%    {IndexList, ItemList} = lists:foldl(fun({ItemSid, S, AList}, {Acc0, Acc1}) ->
%%        case S =< NScore of
%%            true ->
%%                {[ItemSid | Acc0], [{ItemSid, AList} | Acc1]};
%%            _ ->
%%                {Acc0, Acc1}
%%        end
%%    end, {[], []}, ScoreAwardList),
%%    Fun = fun(_, {OScore, List}) ->
%%        case IndexList -- List of
%%            [] ->
%%                {ok, ok};
%%            NList ->
%%                {ok, {ok, NList}, {OScore, lists:usort(NList ++ List)}}
%%        end
%%    end,
%%    case z_db_lib:update(game_lib:get_table(Src, ?MODULE), Key, {NScore, []}, Fun, []) of
%%        {ok, IList} ->
%%
%%            Reply = [begin
%%                AwardLog = awarder_game:give_award(Src, RoleUid, [], AwardList),
%%                zm_event:notify(Src, 'bi_active_id', [{'role_uid', RoleUid}, {'active', Active}, {'index', Index}, {'award', AwardLog}]),
%%                {Index, AwardLog}
%%            end || {Index, AwardList} <- ItemList, lists:member(Index, IList)],
%%            set_front_lib:send_active_ld_award(Src, RoleUid, erlang:list_to_tuple(Reply));
%%        _ ->
%%            'ignore'
%%    end.

%%-------------------------------------------------------------------
%% @doc
%%      获取限时抽卡类型对应对应积分
%% @end
%%-------------------------------------------------------------------
-spec get_choose_score(atom(), integer()) -> integer().
get_choose_score(Template, Choose) ->
    {_, List} = zm_config:get('ld_info', Template),
    element(Choose, z_lib:get_value(List, 'scores', {})).

%%-------------------------------------------------------------------
%% @doc
%%      领取
%% @end
%%-------------------------------------------------------------------
-spec get(atom(), integer(), active:active(), integer(), list(), term()) -> tuple()|string().
get(Src, RoleUid, Active, ItemSid, [{_, _, ScoreAwardList}], _) ->
    case lists:keyfind(ItemSid, 1, ScoreAwardList) of
        false ->
            "input_error";
        {_, NeedScore, AwardList} ->
            Key = active_lib:get_role_active_key(RoleUid, Active),
            F = fun(_, {TotalScore, List, CList}) ->
                case lists:member(ItemSid, List) of
                    true ->
                        throw("already_get");
                    false ->
                        case lists:member(ItemSid, CList) orelse TotalScore >= NeedScore of
                            true ->
                                {ok, {ok, AwardList}, {TotalScore, [ItemSid | List], lists:delete(ItemSid, CList)}};
                            false ->
                                throw("input_error")
                        end
                end
            end,
            z_db_lib:update(game_lib:get_table(Src, ?MODULE), Key, {0, [], []}, F, [])
    end.
%%-------------------------------------------------x------------------
%% @doc
%%      红点
%% @end
%%-------------------------------------------------------------------
role_red(Src, RoleUid, _A, Active) ->
    Key = active_lib:get_role_active_key(RoleUid, Active),
    {_TotalScore, _List, CList} = z_db_lib:get(game_lib:get_table(Src, ?MODULE), Key, {0, [], []}),
    if
        CList =:= [] ->
            0;
        true ->
            1
    end.
%%%=====================LOC FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%
%% @end
%%-------------------------------------------------------------------
start(Src, Active) ->
    [{{Template}, _RankList, _ScoreAwardList}] = active:get_a(Active),
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'sid_template', template_lib:get_key(Src, 'other_rank'), []},
        {'sid_template', template_lib:get_key(Src, ?MODULE), []}
    ]),
    z_db_lib:handle(TableName, fun start_/2, {Src, Template, Active}, TableKeys).

%%-------------------------------------------------------------------
%% @doc
%%      新增排行榜类型
%%      新增抽卡活动sid在GM那边新增活动时候增加,GM配置的活动则读取数据库配置
%% @end
%%-------------------------------------------------------------------
start_({_Src, Template, Active}, [{Index1, RankTypeList}, {Index2, ALd}]) ->
    Sid = active:get_sid(Active),
    {ok, ok, [{Index1, lists:keystore(Sid, 1, RankTypeList, {Sid, ?MODULE})},
        {Index2, lists:keystore(Sid, 1, ALd, {Sid, Template})}]}.

%%-------------------------------------------------------------------
%% @doc
%%      活动结束扩展信息清理
%% @end
%%-------------------------------------------------------------------
stop(Src, Active) ->
    [{{_Template}, AwardList, ScoreAwardList}] = active:get_a(Active),
    Sid = active:get_sid(Active),
    %%未领取目标奖励
    score_award(Src, Active, ScoreAwardList),
    %%发放积分排行榜奖励
    rank_award(Src, Active, AwardList),
    %%清除本次活动积分排行榜,排行榜sid,抽卡sid
    rank_db:clear_ranks(Src, Sid),
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'sid_template', template_lib:get_key(Src, ?MODULE), []}
    ]),
    z_db_lib:handle(TableName, fun stop_/2, {Src, Active}, TableKeys).

%%-------------------------------------------------------------------
%% @doc
%%      清理排行榜类型 清理抽卡活动相关扩展信息
%% @end
%%-------------------------------------------------------------------
stop_({_Src, Active}, [{Index1, ALd}]) ->
    Sid = active:get_sid(Active),
    {ok, ok, [{Index1, lists:keydelete(Sid, 1, ALd)}]}.


%%-------------------------------------------------------------------
%% @doc
%%      发放排行榜奖励
%% @end
%%-------------------------------------------------------------------
-spec rank_award(atom(), active:active(), [{integer(), integer(), list()}]) -> term().
rank_award(Src, Active, AwardList) ->
    Key = game_lib:get_server_key(Src, active),
    Sid = active:get_sid(Active),
    Term = active:get_term(Active),
    case active_db:update_award_flag(Src, Sid, Term, Key) of
        false ->
            %%刷新一次排行榜
            rank_refresh:timer_refresh(Src, [[Sid]], []),
            AllRank = get_max_rank(AwardList),
            RankActions = rank_get:get_rank_range(Src, Sid, 1, AllRank),
            RanksSize = erlang:length(RankActions),
            [send_mail(Src, Award, RankActions, RanksSize, MinRank, MaxRank) || {MinRank, MaxRank, Award} <- AwardList];
        true ->
            'ignore'
    end.

%%-------------------------------------------------------------------
%% @doc
%%      发放达到积分奖励
%% @end
%%-------------------------------------------------------------------
-spec score_award(atom(), active:active(), list()) -> term().
score_award(Src, Active, ScoreAwardList) ->
    Table = game_lib:get_table(Src, ?MODULE),
    ActiveSid = active:get_sid(Active),
    Trem = active:get_term(Active),
    F = fun(_Src1, Key, _Args, R) ->
        case Key of
            {RoleUid, ActiveSid, Trem} ->
                {_Score, _List, CList} = z_db_lib:get(game_lib:get_table(Src, ?MODULE), Key, {0, [], []}),
                case CList =/= [] of
                    true ->
                        AwardList = z_lib:foreach(fun(Acc, ItemSid) ->
                            case lists:keyfind(ItemSid, 1, ScoreAwardList) of
                                false ->
                                    {ok, Acc};
                                {_, _, AList} ->
                                    {ok, awarder_game:merger(AList, Acc)}
                            end
                        end, [], CList),
                        MailType = award_source:get_source(?MODULE),
                        Mail = mail:init({MailType, time_lib:now_second(), 0, {17}, {17}, AwardList}),
                        mail_db:send(Src, RoleUid, Mail),
                        ok;
                    false ->
                        ok
                end,
                {ok, R};
            _Other ->
                {ok, R}
        end
    end,
    z_db_lib:table_iterate(Src, Table, F, [], []).

%%-------------------------------------------------------------------
%% @doc
%%      发放邮件
%% @end
%%-------------------------------------------------------------------
send_mail(_Src, _Award, _Ranks, RanksSize, MinRank, _MaxRank) when RanksSize < MinRank ->
    'ignore';
send_mail(Src, Award, Ranks, RanksSize, MinRank, MaxRank) ->
    AllRank = if
        RanksSize > MaxRank ->
            MaxRank - MinRank + 1;
        true ->
            RanksSize - MinRank + 1
    end,
    MailType = award_source:get_source(?MODULE),
    lists:foldl(fun(Info, Rank) ->
        {RoleUid, Score} = Info,
        Mail = mail:init({MailType, time_lib:now_second(), 0, {3}, {3, Score, Rank}, Award}),
        mail_db:send(Src, RoleUid, Mail),
        Rank + 1
    end, MinRank, lists:sublist(Ranks, MinRank, AllRank)).


%%-------------------------------------------------------------------
%% @doc
%%      获取配置的最大名次
%% @end
%%-------------------------------------------------------------------
-spec get_max_rank(list()) -> integer().
get_max_rank(ConfigList) ->
    lists:max([Max || {_, Max, _} <- ConfigList]).