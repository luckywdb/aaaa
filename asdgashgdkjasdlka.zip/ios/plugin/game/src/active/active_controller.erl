%%活动控制器
-module(active_controller).
-description("active controller").
-copyright({seasky, 'www.seasky.cn'}).
-author({cb, 'chenbin@seaskyjoy.com'}).
-vsn(1).

%%%=======================EXPORT=======================
-export([active/3, format_send/3]).
%%%=======================DEFINE=======================

%%%=======================INCLUDE=======================
-include("../include/active.hrl").
-include("../../../include/sign_key.hrl").
%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      活动运行处理器
%% @end
%%-------------------------------------------------------------------
active(Src, _, T) ->
    Bool = zm_load:server_start_ok() =:= ?KEY andalso not args_system:is_game_center_server(Src),
    if
        Bool ->
            Time = T div 1000 + time_lib:get_difference_time(),
            ActivesState = active_db:get_active_state_list(Src),
            TableActive = game_lib:get_table(Src, 'active'),
            %%为了合服做准备，ActiveSid 为 ｛pid, sid, sid｝
            Pid = args_system:get_pid(Src),
            Sid = args_system:get_sid(Src),
            %%将数据库中的活动和配置的活动进行合并
            ActiveSids = [{P, S, ID} || {P, S, ID} <- lists:usort(z_db_lib:table_iterate(Src, TableActive, fun(_, ActiveSid, _Args, R) ->
                {ok, [ActiveSid | R]} end, [], active_lib:get_config_actives_sid(Src))),
                Pid =:= P, Sid =:= S],%只对本服的活动进行处理
            List = active(Src, ActiveSids, Time, TableActive, ActivesState, []),
            %% 新的活动状态
            NActivesState = [begin
                zm_config:set(?ACTIVE_STATE_CONFIG, {{Pid, Sid, active:get_sid(Active)}, State}),
                {{Pid, Sid, active:get_sid(Active)}, State}
            end || {Active, State, _} <- List],
            z_db_lib:update(game_lib:get_table(Src, 'actives_state'), active_lib:get_active_state_key(Src), NActivesState),
            handle(Src, Time, List),
            %%进行数据推送，异步处理, 考虑在线人多的情况会耽误主线程时间
            zm_event:notify(Src, 'active_send', List);
        true ->
            none
    end.

%%-------------------------------------------------------------------
%% @doc
%%      循环所有活动id [{Active, new_state, old_state}|...]
%% @end
%%-------------------------------------------------------------------
-spec active(atom(), [{integer(), integer(), integer()}], integer(), atom(), [{{integer(), integer(), integer()}, integer()}], [{active:active(), integer(), integer()}]) ->
    [{active:active(), integer(), integer()}].
active(Src, [{_Pid, _Sid, _} = ActiveSid | T], Time, TableActive, ActivesState, R) ->%只对本服的活动进行处理
    NR =
        try
            case active_db:get_active(Src, ActiveSid) of
                none ->
                    R;
                Active ->
                    case active:get_visible(Active) =/= ?NO_RUN of %%在不运行状态下不处理
                        true ->
                            EndTerm = active:get_term_num(Active),
                            ACurState = z_lib:get_value(ActivesState, ActiveSid, ?CLOSE),
                            Bool1 = EndTerm =:= 0 orelse EndTerm > active:get_term(Active) orelse ACurState =/= ?CLOSE,
                            if
                                Bool1 ->
                                    case active_db:get_stute(Src, Time, Active) of
                                        ?RUN ->
                                            if
                                                ACurState =:= ?CLOSE orelse ACurState =:= ?BEFORE ->
                                                    %%更新活动季
                                                    NActive = active:set_term(Active, active:get_term(Active) + 1),
                                                    z_db_lib:update(TableActive, ActiveSid, NActive),
                                                    [{NActive, ?RUN, ACurState} | R];
                                                true ->
                                                    [{Active, ?RUN, ACurState} | R]
                                            end;
                                        ?CLOSE ->
                                            [{Active, ?CLOSE, ACurState} | R];
                                        ?BEFORE ->
                                            [{Active, ?BEFORE, ACurState} | R];
                                        _Other -> %%在stop状态下不做处理，此状态用于领奖
                                            [{Active, ?STOP, ACurState} | R]
                                    end;
                                true ->
                                    R
                            end;
                        _ ->
                            R
                    end
            end
        catch
            E:E1 ->
                zm_log:warn(?MODULE, ?MODULE, 'active', "check_error", [{'e', E}, {'e1', E1}, {'sid', ActiveSid}, {'stacktrace', erlang:get_stacktrace()}]),
                R
        end,
    active(Src, T, Time, TableActive, ActivesState, NR);
active(_Src, [], _Time, _TableActive, _ActivesState, R) ->
    R.


%%-------------------------------------------------------------------
%% @doc
%%      活动处理
%% @end
%%-------------------------------------------------------------------
-spec handle(atom(), integer(), [{active:active(), integer(), integer()}]) -> 'ok'.
handle(Src, Time, [{Active, NowState, OldState} | T]) ->
    try
        handle_(Src, Time, Active, NowState, OldState)
    catch
        E:E1 ->
            zm_log:warn(Src, ?MODULE, "handle", "handle_error", [{time, Time}, {'args', {Active, NowState, OldState}}, {E, E1}, {'stacktrace', erlang:get_stacktrace()}])
    end,
    handle(Src, Time, T);
handle(_Src, _Time, []) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      对活动进行分方法处理
%% @end
%%-------------------------------------------------------------------
handle_(Src, Time, Active, ?RUN, ?CLOSE) ->%%活动开启
    {M, A} = active:get_ma(Active),
    M:handle_start(Src, A, Active, Time),
    zm_event:notify(Src, 'active_start', {Active, Time});
handle_(Src, Time, Active, ?RUN, ?RUN) ->%%活动运行中
    {M, A} = active:get_ma(Active),
    M:handle_run(Src, A, Active, Time);
handle_(Src, Time, Active, ?CLOSE, ?RUN) ->%%活动关闭
    {M, A} = active:get_ma(Active),
    M:handle_close(Src, A, Active, Time);
handle_(Src, Time, Active, ?BEFORE, ?RUN) ->
    {M, A} = active:get_ma(Active),
    M:handle_close(Src, A, Active, Time);
handle_(Src, Time, Active, ?CLOSE, ?STOP) ->%%活动关闭
    {M, A} = active:get_ma(Active),
    M:handle_close(Src, A, Active, Time);
handle_(Src, Time, Active, ?CLOSE, ?CLOSE) ->%%活动关闭中
    {M, A} = active:get_ma(Active),
    M:handle_shut(Src, A, Active, Time);
handle_(Src, Time, Active, ?RUN, ?BEFORE) -> %%预热到开启
    {M, A} = active:get_ma(Active),
    M:handle_start(Src, A, Active, Time),
    zm_event:notify(Src, 'active_start', {Active, Time});
handle_(_Src, _Time, _Active, _, _) -> %预热到关闭 关闭到预热不做操作
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动推送
%% @end
%%-------------------------------------------------------------------
format_send(Src, [{Active, NowState, OldState} | T], List) ->
    NList = try
        format_send_(Src, Active, NowState, OldState, List)
    catch
        E:E1 ->
            zm_log:warn(Src, ?MODULE, "format_send", "format_error", [{'args', {Active, NowState, OldState}}, {E, E1}, {'stacktrace', erlang:get_stacktrace()}]),
            List
    end,
    format_send(Src, T, NList);
format_send(_Src, [], []) ->
    ok;
format_send(Src, [], List) ->
    Tuple = erlang:list_to_tuple(List),
    set_front_lib:send_active(Src, Tuple).

%%对活动进行推送
format_send_(Src, Active, ?RUN, ?BEFORE, List) ->
    {M, A} = active:get_ma(Active),
    [M:handle_format(Src, A, Active) | List];
format_send_(Src, Active, CurState, ?CLOSE, List) when CurState =:= ?RUN orelse CurState =:= ?BEFORE ->
    {M, A} = active:get_ma(Active),
    [M:handle_format(Src, A, Active) | List];
format_send_(_Src, _Active,?CLOSE, ?CLOSE, List)->
    List;
format_send_(Src, Active, ?CLOSE, OldState, List)  when OldState =:= ?RUN orelse OldState =:= ?BEFORE ->
    {M, A} = active:get_ma(Active),
    [M:handle_format(Src, A, Active) | List];
format_send_(_Src, _Active, _, _, List) ->
    List.
