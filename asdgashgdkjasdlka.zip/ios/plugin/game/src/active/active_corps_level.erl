%%限时军团等级活动
-module(active_corps_level).

%%%=======================STATEMENT====================
-description("active_ld").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_event/4, handle_format/3]).
%%%=======================DEFINE=======================

%%%=======================INCLUDE=======================
-include("../include/active.hrl").
-include("../include/rank.hrl").

%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
-spec handle_get(atom(), integer(), term(), active:active()) -> tuple().
handle_get(Src, RoleUid, A, Active) ->
    Key = active_lib:get_role_active_key(RoleUid, Active),
    Format = handle_format(Src, A, Active),
    {CPoint, _} = z_db_lib:get(game_lib:get_table(Src, ?MODULE), Key, {0, []}),
    {Format, {CPoint}}.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
-spec handle_start(atom(), term(), active:active(), integer()) -> 'ok'.
handle_start(Src, _A, Active, _Time) ->
    start(Src, Active),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
-spec handle_run(atom(), term(), active:active(), integer()) -> 'ok'.
handle_run(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
-spec handle_close(atom(), term(), active:active(), integer()) -> 'ok'.
handle_close(Src, _A, Active, _Time) ->
    stop(Src, Active),
    zm_event:notify(Src, active_clear, {?MODULE, Active}),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
-spec handle_shut(atom(), term(), active:active(), integer()) -> 'ok'.
handle_shut(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      事件处理
%% @end
%%-------------------------------------------------------------------
-spec handle_event(atom(), term(), active:active(), tuple()) -> 'ok'.
handle_event(Src, _A, Active, {'corps_up_level', Args}) ->
    {_, CorpsUid} = lists:keyfind(corps_uid, 1, Args),
    {_, Corps} = lists:keyfind(corps, 1, Args),
    target_corps_award(Src, CorpsUid, Active, Corps),
    ok;
handle_event(Src, _A, Active, {'role_enter_corps', Args}) ->
    {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
    {_, Corps} = lists:keyfind('corps', 1, Args),
    CorpsLevel = corps:get_level(Corps),
    CorpsName = corps:get_name(Corps),
    {_, CPoints} = zm_config:get(corp_lv_pt, CorpsLevel),
    target_role_award(Src, Active, RoleUid, CorpsName, CPoints),
    ok;
handle_event(_Src, _A, _Active, _Event) ->
    ok.
%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
-spec handle_format(atom(), list(), active:active()) -> tuple().
handle_format(Src, A, Active) ->
    {RankAwardList, TargetList} =
        case A of%%匹配老数据结构
            [{AwardList1, TargetList1}] ->
                {AwardList1, TargetList1};
            [{AwardList1, TargetList1, _}] ->
                {AwardList1, TargetList1}
        end,
    %[{RankAwardList, TargetList, _}] = A,
    Fun1 = fun({Min, Max, AwardList}) -> {Min, Max, list_to_tuple(AwardList)} end,
    Fun2 = fun({Index, Target, AwardList}) -> {Index, Target, list_to_tuple(AwardList)} end,
    {
        active:format_front(Src, ?MODULE, Active),
        {list_to_tuple(lists:map(Fun1, RankAwardList)), list_to_tuple(lists:map(Fun2, TargetList))}
    }.


%%%=====================LOC FUNCTIONS==================
start(Src, Active) ->
    Fun = fun(_, CorpsUid, _, R) ->
        Corps = corps_db:get_corps(Src, CorpsUid),
        CorpsLevel = corps:get_level(Corps),
        case CorpsLevel > 1 of
            true ->
                target_corps_award(Src, CorpsUid, Active, Corps),
                {ok, R};
            false ->
                {ok, R}
        end
    end,
    z_db_lib:table_iterate(Src, game_lib:get_table(Src, 'corps'), Fun, [], []).


%%-------------------------------------------------------------------
%% @doc
%%      活动结束扩展信息清理
%% @end
%%-------------------------------------------------------------------
stop(Src, Active) ->
    {RankAwardList, _TargetList} =
        case active:get_a(Active) of%%匹配老数据结构
            [{AwardList1, TargetList1}] ->
                {AwardList1, TargetList1};
            [{AwardList1, TargetList1, _}] ->
                {AwardList1, TargetList1}
        end,
    %[{RankAwardList, _TargetList, _}] = active:get_a(Active),
    rank_award(Src, Active, RankAwardList).


%%-------------------------------------------------------------------
%% @doc
%%      发放排行榜奖励
%% @end
%%-------------------------------------------------------------------
-spec rank_award(atom(), active:active(), [{integer(), integer(), list()}]) -> term().
rank_award(Src, Active, AwardList) ->
    Key = game_lib:get_server_key(Src, active),
    Sid = active:get_sid(Active),
    Term = active:get_term(Active),
    case active_db:update_award_flag(Src, Sid, Term, Key) of
        false ->
            %%刷新一次排行榜
            rank_refresh:timer_refresh(Src, [[?CORPS_LV_ALL_RANK]], []),
            AllRank = get_max_rank(AwardList),
            RankActions = rank_get:get_rank_range(Src, ?CORPS_LV_ALL_RANK, 1, AllRank),
            RanksSize = erlang:length(RankActions),
            ActiveName = active:get_name(Active),
            [send_mail(Src, Award, RankActions, RanksSize, MinRank, MaxRank, ActiveName) || {MinRank, MaxRank, Award} <- AwardList];
        true ->
            'ignore'
    end.


%%-------------------------------------------------------------------
%% @doc
%%      目标奖励
%% @end
%%-------------------------------------------------------------------
target_corps_award(Src, CorpsUid, Active, Corps) ->
    CorpsLevel = corps:get_level(Corps),
    {_, CPoints} = zm_config:get(corp_lv_pt, CorpsLevel),
    {_AwardList, TargetList} =
        case active:get_a(Active) of%%匹配老数据结构
            [{AwardList1, TargetList1}] ->
                {AwardList1, TargetList1};
            [{AwardList1, TargetList1, _}] ->
                {AwardList1, TargetList1}
        end,
    %[{_, TargetList, _}] = active:get_a(Active),
    case lists:any(fun({_, T, _}) -> CPoints >= T end, TargetList) of
        true ->
            RoleUids = corps_db:get_corps_members(Src, CorpsUid),
            CorpsName = corps:get_name(Corps),
            lists:foreach(fun(RoleUid) ->
                target_role_award(Src, Active, RoleUid, CorpsName, CPoints)
            end, RoleUids);
        false ->
            ok
    end.

%%-------------------------------------------------------------------
%% @doc
%%      目标奖励
%% @end
%%-------------------------------------------------------------------
target_role_award(Src, Active, RoleUid, CorpsName, CPoints) ->
    {_AwardList, TargetList} =
        case active:get_a(Active) of%%匹配老数据结构
            [{AwardList1, TargetList1}] ->
                {AwardList1, TargetList1};
            [{AwardList1, TargetList1, _}] ->
                {AwardList1, TargetList1}
        end,
    %[{_, TargetList, _}] = active:get_a(Active),
    Key = active_lib:get_role_active_key(RoleUid, Active),
    {IndexList, ItemList} = lists:foldl(fun({Index, T, Award}, {Acc0, Acc1}) ->
        case T =< CPoints of
            true ->
                {[Index | Acc0], [{Index, T, Award} | Acc1]};
            _ ->
                {Acc0, Acc1}
        end
    end, {[], []}, TargetList),
    Fun = fun(_, {_, AwardList}) ->
        case IndexList -- AwardList of
            [] ->
                {ok, ok, {CPoints, AwardList}};
            NList ->
                {ok, {ok, NList}, {CPoints, lists:usort(NList ++ AwardList)}}
        end
    end,
    case z_db_lib:update(game_lib:get_table(Src, ?MODULE), Key, {0, []}, Fun, []) of
        {ok, IList} ->
            ActiveName = active:get_name(Active),
            lists:foreach(fun({Index, Score, Award}) ->
                case lists:member(Index, IList) of
                    true ->
                        MailType = award_source:get_source(?MODULE),
                        Mail = mail:init({MailType, time_lib:now_second(), 0, {10, ActiveName}, {10, CorpsName, ActiveName, Score}, Award}),
                        mail_db:send(Src, RoleUid, Mail);
                    false ->
                        ok
                end
            end, ItemList),
            set_front_lib:send_active_score_award(Src, RoleUid, {active:get_sid(Active), CPoints}),
            ok;
        _ ->
            set_front_lib:send_active_score_award(Src, RoleUid, {active:get_sid(Active), CPoints}),
            ok
    end.

%%-------------------------------------------------------------------
%% @doc
%%      发放邮件
%% @end
%%-------------------------------------------------------------------
send_mail(_Src, _Award, _Ranks, RanksSize, MinRank, _MaxRank, _ActiveName) when RanksSize < MinRank ->
    'ignore';
send_mail(Src, Award, Ranks, RanksSize, MinRank, MaxRank, ActiveName) ->
    AllRank = if
        RanksSize > MaxRank ->
            MaxRank - MinRank + 1;
        true ->
            RanksSize - MinRank + 1
    end,
    MailType = award_source:get_source(?MODULE),
    lists:foldl(fun(Info, Rank) ->
        {CorpsUid, _Lv} = Info,
        CorpsName = corps:get_name(corps_db:get_corps(Src, CorpsUid)),
        Mail = mail:init({MailType, time_lib:now_second(), 0, {9, ActiveName}, {9, CorpsName, ActiveName, Rank}, Award}),
        lists:foreach(fun(RoleUid) ->
            mail_db:send(Src, RoleUid, Mail)
        end, corps_db:get_corps_members(Src, CorpsUid)),
        Rank + 1
    end, MinRank, lists:sublist(Ranks, MinRank, AllRank)).


%%-------------------------------------------------------------------
%% @doc
%%      获取配置的最大名次
%% @end
%%-------------------------------------------------------------------
-spec get_max_rank(list()) -> integer().
get_max_rank(ConfigList) ->
    lists:max([Max || {_, Max, _} <- ConfigList]).