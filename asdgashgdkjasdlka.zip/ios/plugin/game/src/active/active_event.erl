-module(active_event).

-description("active_event").
-copyright({seasky, 'www.seasky.cn'}).
-author({cb, 'chenbin@seaskyjoy.com'}).
-vsn(1).
%%%=======================EXPORT=======================
-export([active_event/4, active_send/4, active_clear/4]).
%%%=======================DEFINE=======================

%%%=======================INCLUDE=======================
-include("../include/active.hrl").
%%%=================EXPORTED FUNCTIONS=================
%% ----------------------------------------------------
%% Func: active_event/4
%% Description: 活动捕获事件
%% Returns:  ok
%% ----------------------------------------------------
%%-------------------------------------------------------------------
%% @doc
%%      活动捕获事件
%% @end
%%-------------------------------------------------------------------
-spec active_event(_, atom(), atom(), term()) -> 'ok'.
active_event(_, Src, 'cash_ok', Event) ->
    active_db:event(Src, {'cash_ok', Event});
active_event(_, Src, 'cash_giftbag_ok', Event) ->
    active_db:event(Src, {'cash_giftbag_ok', Event});
active_event(_, Src, 'login', Event) ->
    active_db:event(Src, {'login', Event});
active_event(_, Src, 'active_event', Event) ->
    active_db:event(Src, Event).

%%-------------------------------------------------------------------
%% @doc
%%      异步推送消息给前台
%% @end
%%-------------------------------------------------------------------
-spec active_send(_, atom(), 'active_send', [{active:active(), integer(), integer()}]) -> 'ok'.
active_send(_, Src, 'active_send', List) ->
    active_controller:format_send(Src, List, []),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      进行活动数据清理
%% @end
%%-------------------------------------------------------------------
-spec active_clear(_, atom(), atom(), {atom(), active:active()}) -> 'ok'.
active_clear(_, Src, 'active_clear', {TableSName, Active}) ->
    active_db:clear(Src, game_lib:get_table(Src, TableSName), Active).

%%%=================LOC FUNCTIONS===================
