-module(active_sign_in).

%%%=======================STATEMENT====================
-description("active_sign_in").
-copyright('youkia,www.youkia.net').
-author("ljh,lvjihong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_stop/4, handle_event/4, handle_format/3]).
-export([get/6, role_red/4]).
%%%=======================INCLUDE======================
-include("../include/active.hrl").

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
handle_get(Src, RoleUid, A, Active) ->
    Key = active_lib:get_role_active_key(RoleUid, Active),
    {SignInList, LastSignInDay} = z_db_lib:get(game_lib:get_table(Src, ?MODULE), Key, {[], 0}),
    Format = handle_format(Src, A, Active),
    {Format, {length(SignInList), LastSignInDay}}.
%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
handle_start(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
handle_run(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
handle_close(Src, _A, Active, _Time) ->
    %%进行数据清理，异步处理
    zm_event:notify(Src, active_clear, {?MODULE, Active}),
    'ok'.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
handle_shut(_Src, _A, _Active, _Time) ->
    ok.
%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
handle_stop(_Src, _A, _Active, _Time) ->
    ok.
%%-------------------------------------------------------------------
%% @doc
%%      事件处理
%% @end
%%-------------------------------------------------------------------
-spec handle_event(atom(), term(), active:active(), tuple()) -> 'ok'.
handle_event(_Src, _A, _Active, _Event) ->
    ok.
%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
handle_format(Src, [List], Active) ->
    F1 = fun({Day, AwardList}) ->
        {Day, list_to_tuple(AwardList)}
    end,
    {
        active:format_front(Src, ?MODULE, Active),
        list_to_tuple(lists:map(F1, List))
    }.
%%-------------------------------------------------------------------
%% @doc
%%      领奖
%% @end
%%-------------------------------------------------------------------
get(Src, RoleUid, Active, Sid, [A], _Msg) ->
    ToDay = time_lib:get_date_by_type('day_of_year'),
    F = fun(_, {SignInList, LastSignInDay}) ->
        case lists:member(Sid, SignInList) orelse ToDay =:= LastSignInDay of
            true ->
                throw("already_sign_in");
            _ ->
                if
                    length(SignInList) + 1 =/= Sid ->
                        throw("last_sign_is_incomplete");
                    true ->
                        case lists:keyfind(Sid, 1, A) of
                            {Sid, Award} ->
                                {ok, {ok, Award}, {[Sid | SignInList], ToDay}};
                            _ ->
                                throw("no_sid")
                        end
                end
        end
    end,
    case z_db_lib:update(game_lib:get_table(Src, ?MODULE), active_lib:get_role_active_key(RoleUid, Active), {[], 0}, F, none) of
        {ok, AwardList} ->
            {ok, AwardList};
        Err ->
            Err
    end.
%%-------------------------------------------------x------------------
%% @doc
%%      红点
%% @end
%%-------------------------------------------------------------------
role_red(Src, RoleUid, _A, Active) ->
    ToDay = time_lib:get_date_by_type('day_of_year'),
    Key = active_lib:get_role_active_key(RoleUid, Active),
    {_SignInList, LastSignInDay} = z_db_lib:get(game_lib:get_table(Src, ?MODULE), Key, {[], 0}),
    case ToDay =:= LastSignInDay of
        true ->
            0;
        _ ->
            1
    end.
%%%===================LOCAL FUNCTIONS==================
