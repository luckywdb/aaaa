-module(active_consume_target).

%%%=======================STATEMENT====================
-description("active_consume_target").
-copyright('youkia,www.youkia.net').
-author("ljh,lvjihong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_stop/4, handle_event/4, handle_format/3]).
-export([get_type/1, check/1]).
%%%=======================INCLUDE======================
-include("../include/active.hrl").

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
handle_get(Src, RoleUid, A, Active) ->
    Key = active_lib:get_role_active_key(RoleUid, Active),
    Score = element(1, z_db_lib:get(game_lib:get_table(Src, ?MODULE), Key, {0, 0})),
    Format = handle_format(Src, A, Active),
    {Format, {Score}}.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
handle_start(Src, _A, _Active, _Time) ->
    start_(Src),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
handle_run(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
handle_close(Src, _A, Active, _Time) ->
    %%进行数据清理，异步处理
    zm_event:notify(Src, active_clear, {?MODULE, Active}),
    close_(Src),
    'ok'.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
handle_shut(_Src, _A, _Active, _Time) ->
    ok.
%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
handle_stop(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      事件处理
%% @end
%%-------------------------------------------------------------------
handle_event(Src, _, Active, {'active_consume_target', Msg}) ->
    RoleUid = z_lib:get_value(Msg, 'role_uid', none),
    Consumes = z_lib:get_value(Msg, 'consumes', none),
    Annx = add_score(Src, RoleUid, Consumes, Active),
    send_award(Src, RoleUid, Active, Annx);
handle_event(_Src, _A, _Active, _Event) ->
    ok.
%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
handle_format(Src, [{ConsumeList, _Percent, TargetAward}], Active) ->
    F1 = fun({ItemSid, Target, AwardList}) ->
        {ItemSid, Target, list_to_tuple(AwardList)}
    end,
    {
        active:format_front(Src, ?MODULE, Active),
        {{get_type(ConsumeList)}, list_to_tuple(lists:reverse(lists:map(F1, TargetAward)))}
    }.


%%-------------------------------------------------------------------
%% @doc
%%      增加积分
%% @end
%%-------------------------------------------------------------------
add_score(Src, RoleUid, Consumes, Active) ->
    [{ConsumeList, Percent, TargetAndAward}] = active:get_a(Active),
    AddScore = z_lib:foreach(fun(S, {Type, Number}) ->  %%遍历消耗 刷新积分
        case lists:member(Type, ConsumeList) of
            true ->
                {ok, Number * Percent div 10000 + S};
            false ->
                {ok, S}
        end
    end, 0, Consumes),
    if
        AddScore > 0 ->
            F = fun(_, {Score, ItemList}) ->
                NScore = Score + AddScore,
                {NAnnx, R2} = z_lib:foreach(fun({Annx, IList}, {ItemSid, Target, Award}) -> %%遍历活动子条目，判断积分是否达到可以发放奖励
                    case NScore >= Target andalso not lists:member(ItemSid, IList) of
                        true ->
                            {ok, {[{Target, Award} | Annx], [ItemSid | IList]}};
                        false ->
                            {ok, {Annx, IList}}
                    end
                end, {[], ItemList}, TargetAndAward),
                {ok, {ok, NAnnx}, {NScore, R2}}
            end,
            {ok, Award} = z_db_lib:update(game_lib:get_table(Src, ?MODULE), active_lib:get_role_active_key(RoleUid, Active), {0, []}, F, []),
            set_front_lib:send_active_score_award(Src, RoleUid, {active:get_sid(Active), AddScore}),
            Award;
        true ->
            []
    end.


%%-------------------------------------------------------------------
%% @doc
%%
%% @end
%%-------------------------------------------------------------------
get_type(TypeList) ->
    if
        TypeList =:= ['soldier'] ->
            "Soldier";
        TypeList =:= ['rmb'] ->
            "Rmb";
        true ->
            "Res"
    end.
%%-------------------------------------------------------------------
%% @doc
%%      在bi抛事件的时候好检查是否有活动开启
%% @end
%%-------------------------------------------------------------------
check(Src) ->
    case zm_config:get('$active_consume_tartget_', 'num') of
        {_, 0} ->
            false;
        {_, _Num} ->
            true;
        none ->
            Num = z_db_lib:get(game_lib:get_table(Src, ?MODULE), num, 0),
            zm_config:set('$active_consume_tartget_', {'num', Num}),
            Num > 0
    end.
%%%===================LOCAL FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%      发送奖励
%% @end
%%-------------------------------------------------------------------
send_award(Src, RoleUid, Active, Annx) ->
    lists:foreach(fun({Target, Award}) ->
        send_mail(Src, RoleUid, active:get_name(Active), Target, Award)
    end, Annx).
%% ----------------------------------------------------
%% @doc  
%%      发送邮件
%% @end
%% ----------------------------------------------------
send_mail(Src, RoleUid, Name, Target, Annex) ->
    MailType = award_source:get_source(?MODULE),
    Mail = mail:init({MailType, time_lib:now_second(), 0, {8, Name}, {8, Name, Target}, Annex}),
    mail_db:send(Src, RoleUid, Mail),
    zm_log:info(Src, ?MODULE, 'send_mail', "send_mail", [{'role_uid', RoleUid}, {'award', Annex}]).
%%-------------------------------------------------------------------
%% @doc
%%      活动开始时加上数据，在bi抛事件的时候好检查是否有活动开启,开启活动Num+1，关闭活动Num-1
%% @end
%%-------------------------------------------------------------------
start_(Src) ->
    F = fun(_, Num) ->
        {ok, Num + 1, Num + 1}
    end,
    Num = z_db_lib:update(game_lib:get_table(Src, ?MODULE), num, 0, F, []),
    zm_config:set('$active_consume_tartget_', {'num', Num}).

close_(Src) ->
    F = fun(_, 0) ->
        {ok, 0, 0};
        (_, Num) ->
            {ok, Num - 1, Num - 1}
    end,
    R = z_db_lib:update(game_lib:get_table(Src, ?MODULE), num, 0, F, []),
    zm_config:set('$active_consume_tartget_', {'num', R}).
