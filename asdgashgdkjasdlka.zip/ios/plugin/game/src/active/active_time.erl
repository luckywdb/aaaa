%%活动时间
-module(active_time).
-description("active_time").
-copyright({seasky, 'www.seasky.cn'}).
-author({cb, 'chenbin@seaskyjoy.com'}).
-vsn(1).

%%%=======================EXPORT=======================
-export([get_type/1, get_get_time/1, get_interval/1, get_over_time/1, get_run_time/1, get_sid/1, get_start_time/1, get_stute/3, get_day/1, get_info/1]).
-export([format/2, init/11]).
-export([get_before_sttime/1, get_before_endtime/1, get_starttime_week/1]).
-export_type([active_time/0]).
%%%=======================INCLUDE======================

%%%=======================RECORD=======================
-record(active_time, {
    sid :: integer(),%% 时间sid
    type :: integer(), %%时间类型 0 相对开服时间，1为绝对时间
    start_time :: integer()|{atom(), atom(), term()},%%开始时间
    run_time :: integer(),%%运行时长(相对开始时间)
    get_time :: integer(),%%领奖时间(相对开始时间)
    over_time :: integer(),%%领奖结束时间(相对领奖时间)
    interval :: integer(), %%关闭后多少时间后开启 0表示不开启
    day :: integer(), %%开服多少天以上
    before_sttime :: integer(), %%预热开始时间
    before_endtime :: integer(), %%预热结束时间
    info = [] :: list()
}).
-type active_time() :: #active_time{}.
%%%=======================DEFINE=======================
-include("../include/active.hrl").
%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      初始化
%% @end
%%-------------------------------------------------------------------
init(Sid, Type, StartTime, RunTime, GetTime, OverTime, Interval, Day, Before_Sttime, Before_Endtime, Info) ->
    #active_time{
        sid = Sid, type = Type, start_time = StartTime, run_time = RunTime, get_time = GetTime,
        over_time = OverTime, interval = Interval, day = Day, before_sttime = Before_Sttime, before_endtime = Before_Endtime,
        info = Info
    }.

%%-------------------------------------------------------------------
%% @doc
%%      根据时间获得活动当前的状态
%% @end
%%-------------------------------------------------------------------
-spec get_stute(atom(), integer(), active_time()) -> integer().
get_stute(Src, Time, #active_time{type = Type, start_time = StartTime1, interval = Interval} = ActiveTime) ->
    Table = game_lib:get_table(Src, 'active_time'),
    NActiveTime = case Type of
        0 ->
            NActiveTime1 = ActiveTime#active_time{type = 1, start_time = args_system:get_online_time(Src) + StartTime1},
            z_db_lib:update(Table, active_lib:get_active_time_key(Src, NActiveTime1), NActiveTime1),
            NActiveTime1;
        1 ->
            ActiveTime;
        2 ->%%时间类型: mfa获取开始时间
            {M, F, A} = StartTime1,
            NActiveTime1 = ActiveTime#active_time{type = 1, start_time = M:F(A)},
            z_db_lib:update(Table, active_lib:get_active_time_key(Src, NActiveTime1), NActiveTime1),
            NActiveTime1
    end,
    #active_time{start_time = StartTime, run_time = RunTime, get_time = GetTime, over_time = OverTime, interval = Interval, day = Day, before_sttime = Before_St, before_endtime = Before_End} = NActiveTime,
    OpenDay = element(1, z_lib:second_to_localtime(args_system:get_online_time(Src))),%%{2016,6,24}
    NowDay = element(1, z_lib:second_to_localtime(Time)),%%当前时间
    D1 = time_lib:day_two_date(OpenDay, NowDay)-1,
    if
        D1 >= Day ->%%达到开服时间要求
            if
                Time >= StartTime andalso Time =< (StartTime + RunTime) ->
                    ?RUN;
                GetTime =/= 0 andalso OverTime =/= 0 andalso Time >= (StartTime + GetTime) andalso Time =< (StartTime + GetTime + OverTime) ->
                    ?STOP;
                GetTime =/= 0 andalso OverTime =/= 0 andalso Interval =/= 0 andalso Time >= (StartTime + GetTime + OverTime + Interval) ->
                    z_db_lib:update(Table, active_lib:get_active_time_key(Src, NActiveTime), NActiveTime#active_time{start_time = StartTime + GetTime + OverTime + Interval}),
                    ?RUN;
                (GetTime =:= 0 orelse OverTime =:= 0) andalso Interval =/= 0 andalso Time >= (StartTime + RunTime + Interval) ->
                    z_db_lib:update(Table, active_lib:get_active_time_key(Src, NActiveTime), NActiveTime#active_time{start_time = StartTime + RunTime + Interval}),
                    ?RUN;
                Before_St > 0 andalso Time >= StartTime - Before_St andalso Time < StartTime - Before_End ->
                    ?BEFORE;
                Before_St > 0 andalso GetTime =/= 0 andalso OverTime =/= 0 andalso Interval =/= 0 andalso
                    Time >= (StartTime + GetTime + OverTime + Interval) - Before_St andalso Time < (StartTime + GetTime + OverTime + Interval) - Before_End ->
                    z_db_lib:update(Table, active_lib:get_active_time_key(Src, NActiveTime), NActiveTime#active_time{start_time = StartTime + GetTime + OverTime + Interval}),
                    ?BEFORE;
                Before_St > 0 andalso (GetTime =:= 0 orelse OverTime =:= 0) andalso Interval =/= 0 andalso
                    Time >= (StartTime + RunTime + Interval) - Before_St andalso Time < (StartTime + RunTime + Interval) - Before_End ->
                    z_db_lib:update(Table, active_lib:get_active_time_key(Src, NActiveTime), NActiveTime#active_time{start_time = StartTime + RunTime + Interval}),
                    ?BEFORE;
                true ->
                    ?CLOSE
            end;
        true ->
            ?CLOSE
    end.

%%-------------------------------------------------------------------
%% @doc
%%      活动时间格式化给前台
%% @end
%%-------------------------------------------------------------------
-spec format(atom(), active_time()) ->
    {integer(), integer(), integer(), integer(), integer(), integer()}.
format(Src, #active_time{type = 0, start_time = StartTime, run_time = RunTime, get_time = GetTime, over_time = OverTime, before_sttime = Before_St, before_endtime = Before_End}) ->
    {args_system:get_online_time(Src) + StartTime, RunTime, GetTime, OverTime, Before_St, Before_End};
format(_Src, #active_time{type = 1, start_time = StartTime, run_time = RunTime, get_time = GetTime, over_time = OverTime, before_sttime = Before_St, before_endtime = Before_End}) ->
    {StartTime, RunTime, GetTime, OverTime, Before_St, Before_End}.

%%-------------------------------------------------------------------
%% @doc
%%      活动时间sid
%% @end
%%-------------------------------------------------------------------
-spec get_sid(active_time()) -> integer().
get_sid(#active_time{sid = Value}) -> Value.

%%-------------------------------------------------------------------
%% @doc
%%      活动时间类型
%% @end
%%-------------------------------------------------------------------
-spec get_type(active_time()) -> integer().
get_type(#active_time{type = Type}) -> Type.

%%-------------------------------------------------------------------
%% @doc
%%      开始时间
%% @end
%%-------------------------------------------------------------------
-spec get_start_time(active_time()) -> integer().
get_start_time(#active_time{start_time = Value}) -> Value.

%%-------------------------------------------------------------------
%% @doc
%%      活动运行时间
%% @end
%%-------------------------------------------------------------------
-spec get_run_time(active_time()) -> integer().
get_run_time(#active_time{run_time = Value}) -> Value.

%%-------------------------------------------------------------------
%% @doc
%%      活动间隔时间
%% @end
%%-------------------------------------------------------------------
-spec get_interval(active_time()) -> integer().
get_interval(#active_time{interval = Value}) -> Value.

%%-------------------------------------------------------------------
%% @doc
%%      获取领取时间
%% @end
%%-------------------------------------------------------------------
-spec get_get_time(active_time()) -> integer().
get_get_time(#active_time{get_time = Value}) -> Value.

%%-------------------------------------------------------------------
%% @doc
%%      获取结束领取时间
%% @end
%%-------------------------------------------------------------------
-spec get_over_time(active_time()) -> integer().
get_over_time(#active_time{over_time = Value}) -> Value.

%%-------------------------------------------------------------------
%% @doc
%%      获得开服多少天限制
%% @end
%%-------------------------------------------------------------------
-spec get_before_sttime(active_time()) -> integer().
get_before_sttime(#active_time{before_sttime = Value}) -> Value.

%%-------------------------------------------------------------------
%% @doc
%%      获得开服多少天限制
%% @end
%%-------------------------------------------------------------------
-spec get_before_endtime(active_time()) -> integer().
get_before_endtime(#active_time{before_endtime = Value}) -> Value.

%%-------------------------------------------------------------------
%% @doc
%%      获得开服多少天限制
%% @end
%%-------------------------------------------------------------------
-spec get_day(active_time()) -> integer().
get_day(#active_time{day = Value}) -> Value.

%%-------------------------------------------------------------------
%% @doc
%%
%% @end
%%-------------------------------------------------------------------
-spec get_info(active_time()) -> list().
get_info(#active_time{info = Value}) -> Value.

%% ----------------------------------------------------
%% @doc
%%  获取开服后,第一个周XX 对应的活动开始时间
%% @end
%% ----------------------------------------------------
get_starttime_week([_Src, Week]) ->
    time_lib:get_time_week(time_lib:now_second(), Week).