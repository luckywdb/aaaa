%%活动
-module(active).
-description("active_lib").
-copyright('youkia,www.youkia.net').
-author('cb,chenbin@youkia.net').
-vsn(1).

%%%=======================EXPORT=======================
-export([get_sid/1, get_a/1, get_description/1, get_icon/1, get_m/1, get_ma/1, get_name/1, get_sequence/1, get_term/1,
    get_time_id/1, get_title/1, get_visible/1]).
-export([set_ma/2, set_term/2, set_visible/2, init/11]).
-export([format_front/3]).
-export([set_term_num/2, get_term_num/1]).

-export_type([active/0]).
%%%=======================INCLUDE======================

%%%=======================RECORD=======================
-record(active, {
    sid :: integer(),%%活动sid
    icon :: string(),%%活动图标
    title :: string(),%%活动标题
    sequence :: integer(),%%活动序列号
    name :: string(),%%活动名字
    ma :: {atom()|tuple(), term()},%%活动{Module,Args}
    time_id :: integer(),%%活动时间id
    term :: integer(),%%活动季(第几次循环)
    term_num :: integer(),%%活动运行期数
    description :: string(),%%活动描述
    visible :: integer() %%活动可见 0可见 ｜ 1不可见
}).
%%%=======================DEFINE=======================

-type active() :: #active{}.

%%%=================EXPORTED FUNCTIONS===================
%%-------------------------------------------------------------------
%% @doc
%%      活动图标
%% @end
%%-------------------------------------------------------------------
-spec get_icon(active()) -> string().
get_icon(#active{icon = Value}) ->
    Value.

%%-------------------------------------------------------------------
%% @doc
%%      活动标题
%% @end
%%-------------------------------------------------------------------
-spec get_title(active()) -> string().
get_title(#active{title = Value}) ->
    Value.

%%-------------------------------------------------------------------
%% @doc
%%      活动序列号
%% @end
%%-------------------------------------------------------------------
-spec get_sequence(active()) -> integer().
get_sequence(#active{sequence = Value}) ->
    Value.


%%-------------------------------------------------------------------
%% @doc
%%      活动条目MA
%% @end
%%-------------------------------------------------------------------
-spec get_ma(active()) -> {atom()|tuple(), term()}.
get_ma(#active{ma = Value}) ->
    Value.

%%-------------------------------------------------------------------
%% @doc
%%      得到活动条目模块
%% @end
%%-------------------------------------------------------------------
-spec get_m(active()) -> atom().
get_m(#active{ma = {M, _A}}) ->
    M.

%%-------------------------------------------------------------------
%% @doc
%%      得到活动条目参数
%% @end
%%-------------------------------------------------------------------
-spec get_a(active()) -> term().
get_a(#active{ma = {_M, A}}) ->
    A.

%%-------------------------------------------------------------------
%% @doc
%%      得到活动条目id
%% @end
%%-------------------------------------------------------------------
-spec get_sid(active()) -> integer().
get_sid(#active{sid = Value}) ->
    Value.

%%-------------------------------------------------------------------
%% @doc
%%      获得名字
%% @end
%%-------------------------------------------------------------------
-spec get_name(active()) -> string().
get_name(#active{name = Value}) ->
    Value.

%%-------------------------------------------------------------------
%% @doc
%%      得到活动运行期数
%% @end
%%-------------------------------------------------------------------
-spec get_term_num(active()) -> integer().
get_term_num(#active{term_num = Value}) ->
    Value.

%%-------------------------------------------------------------------
%% @doc
%%      得到活动条目时间
%% @end
%%-------------------------------------------------------------------
-spec get_time_id(active()) -> integer().
get_time_id(#active{time_id = Value}) ->
    Value.

%%-------------------------------------------------------------------
%% @doc
%%      得到活动季
%% @end
%%-------------------------------------------------------------------
-spec get_term(active()) -> integer().
get_term(#active{term = Value}) ->
    Value.

%%-------------------------------------------------------------------
%% @doc
%%      活动描述
%% @end
%%-------------------------------------------------------------------
-spec get_description(active()) -> string().
get_description(#active{description = Value}) ->
    Value.

%%-------------------------------------------------------------------
%% @doc
%%      活动是否可见
%% @end
%%-------------------------------------------------------------------
-spec get_visible(active()) -> integer().
get_visible(#active{visible = Value}) ->
    Value.


%%-------------------------------------------------------------------
%% @doc
%%      活动条目MA
%% @end
%%-------------------------------------------------------------------
-spec set_ma(active(), {atom(), term()}) -> active().
set_ma(Active, {_M, _A} = Value) ->
    Active#active{ma = Value}.

%%-------------------------------------------------------------------
%% @doc
%%      设置活动季
%% @end
%%-------------------------------------------------------------------
-spec set_term(active(), integer()) -> active().
set_term(Active, Value) ->
    Active#active{term = Value}.

%%-------------------------------------------------------------------
%% @doc
%%      设置可见
%% @end
%%-------------------------------------------------------------------
-spec set_visible(active(), integer()) -> active().
set_visible(Active, Value) ->
    Active#active{visible = Value}.

%%-------------------------------------------------------------------
%% @doc
%%      设置活动运行期数
%% @end
%%-------------------------------------------------------------------
-spec set_term_num(active(), integer()) -> active().
set_term_num(Active, Value) ->
    Active#active{term_num = Value}.

%%-------------------------------------------------------------------
%% @doc
%%      初始化
%% @end
%%-------------------------------------------------------------------
init(Sid, Icon, Title, Sequence, Name, Ma, TimeId, Term, TermNum, Description, Visible) ->
    #active{
        sid = Sid, icon = Icon, title = Title, sequence = Sequence, name = Name,
        ma = Ma, time_id = TimeId, term = Term, term_num = TermNum, description = Description, visible = Visible
    }.

%% ----------------------------------------------------
%% @doc
%%      前台显示用的,活动基本结构
%% @end
%% ----------------------------------------------------
format_front(Src, Mod, Active) ->
    #active{
        sid = Sid, icon = Icon, title = Title, sequence = Sequence, name = Name, term = Term, description = Description
    } = Active,
    {Sid, Icon, Title, Sequence, Mod, Name, active_db:format_active_time(Src, Active), Description, Term}.