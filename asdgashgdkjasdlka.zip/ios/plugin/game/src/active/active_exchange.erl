%%限时兑换
-module(active_exchange).

-description("active_exchange").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_stop/4, handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_event/4, handle_format/3]).
-export([exchange/6]).
%%%=======================DEFINE=======================

%%%=======================INCLUDE=======================
-include("../include/active.hrl").
%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
-spec handle_get(atom(), integer(), term(), active:active()) -> tuple().
handle_get(Src, RoleUid, A, Active) ->
    Key = active_lib:get_role_active_key(RoleUid, Active),
    Format = handle_format(Src, A, Active),
    {Format, list_to_tuple(z_db_lib:get(game_lib:get_table(Src, ?MODULE), Key, []))}.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
-spec handle_start(atom(), term(), active:active(), integer()) -> 'ok'.
handle_start(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
-spec handle_run(atom(), term(), active:active(), integer()) -> 'ok'.
handle_run(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
-spec handle_stop(atom(), term(), active:active(), integer()) -> 'ok'.
handle_stop(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
-spec handle_close(atom(), term(), active:active(), integer()) -> 'ok'.
handle_close(Src, _A, Active, _Time) ->
    %%进行数据清理，异步处理
    zm_event:notify(Src, active_clear, {?MODULE, Active}),
    'ok'.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
-spec handle_shut(atom(), term(), active:active(), integer()) -> 'ok'.
handle_shut(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      事件处理
%% @end
%%-------------------------------------------------------------------
-spec handle_event(atom(), term(), active:active(), tuple()) -> 'ok'.
handle_event(_Src, _A, _Active, _Event) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
-spec handle_format(atom(), list(), active:active()) -> tuple().
handle_format(Src, A, Active) ->
    [List] = A,
    F = fun({ItemSid, Consumes, MaxTimes, AwardLists, Discount}) ->
        Award = list_to_tuple([list_to_tuple(AwardList) || AwardList <- AwardLists]),
        {ItemSid, erlang:list_to_tuple(Consumes), MaxTimes, Award, Discount}
    end,
    {
        active:format_front(Src, ?MODULE, Active),
        erlang:list_to_tuple(lists:map(F, List))
    }.


%%-------------------------------------------------------------------
%% @doc
%%      兑换
%% @end
%%-------------------------------------------------------------------
exchange(Src, RoleUid, Active, Item, Number, Msg) ->
    Index = z_lib:get_value(Msg, "index", 'none'),
    {ItemSid, Consumes, MaxTimes, AwardLists, _} = Item,
    case is_integer(Index) andalso Index >= 0 andalso Index < length(AwardLists) of
        true ->
            Conditions = [{'times', MaxTimes} | Consumes],
            F = fun
                (_, Exchange) ->
                    Bool = checks(Src, RoleUid, ItemSid, Number, Exchange, Conditions),
                    if
                        Bool ->
                            CInfo = consumes(Src, RoleUid, ItemSid, Number, Exchange, Conditions, []),
                            NChange = times_set_lib:update(Exchange, {ItemSid, Number}),
                            {ok, {CInfo, NChange}, NChange};
                        true ->
                            throw("limit")
                    end
            end,
            case z_db_lib:update(game_lib:get_table(Src, ?MODULE), active_lib:get_role_active_key(RoleUid, Active), [], F, none) of
                {BiCs, _NC} ->
                    %%Index客户端传过来以0开始
                    {ok, BiCs, lists:nth(Index + 1, AwardLists)};
                Err ->
                    Err
            end;
        false ->
            "input_error"
    end.

%%%=====================LOC FUNCTIONS==================
%%检验条件
checks(Src, RoleUid, ItemSid, Number, Exchange, [H | T]) ->
    case check(Src, RoleUid, ItemSid, Number, Exchange, H) of
        false ->
            false;
        _ ->
            checks(Src, RoleUid, ItemSid, Number, Exchange, T)
    end;
checks(_Src, _RoleUid, _ItemSid, _Number, _Exchange, []) ->
    true.
%%消耗条件
consumes(Src, RoleUid, ItemSid, Number, Exchange, [Consume | T], List) ->
    case consume(Src, RoleUid, ItemSid, Number, Exchange, Consume) of
        none ->
            consumes(Src, RoleUid, ItemSid, Number, Exchange, T, List);
        Info when is_list(Info) ->
            consumes(Src, RoleUid, ItemSid, Number, Exchange, T, Info ++ List);
        Info ->
            consumes(Src, RoleUid, ItemSid, Number, Exchange, T, [Info | List])
    end;
consumes(_Src, _RoleUid, _ItemSid, _Number, _Exchange, [], List) ->
    List.

check(Src, RoleUid, _ItemSid, Number, _Exchange, {'rmb', Value}) ->
    rmb_db:get_all_rmb(Src, RoleUid) >= Value * Number;
check(_Src, _RoleUid, ItemSid, Number, Exchange, {'times', Value}) ->
    (z_lib:get_value(Exchange, ItemSid, 0) + Number) =< Value;
%%校验所扣物品是否够
check(Src, RoleUid, _ItemSid, Number, _Exchange, {'prop', {Sid, Value}}) ->
    Type = prop_kit_lib:get_prop_type(prop_kit_lib:get_prop(Sid)),
    Storage = storage_db:get_storage(Type, Src, RoleUid),
    storage_lib:exist_by_sid(Storage, {Sid, Value * Number});
%%校验金币是否足够
check(Src, RoleUid, _ItemSid, Number, _Exchange, {'money', Value}) ->
    Role = role_db:get_role(Src, RoleUid),
    role:get_money(Role) >= Value * Number;
check(Src, RoleUid, _ItemSid, Number, _Exchange, {Res, Value}) when is_atom(Res) ->
    Role = role_db:get_role(Src, RoleUid),
    FunName = string_lib:to_atom("get_", Res),
    role:FunName(Role) >= Value * Number.

%%消耗物品
consume(Src, RoleUid, _ItemSid, Number, _Exchange, {'prop', {Sid, Value}}) ->
    Type = prop_kit_lib:get_prop_type(prop_kit_lib:get_prop(Sid)),
    F =
        fun(_, Storage) ->
            {BiCs, NStorage} = storage_lib:deduct_by_sid(Storage, {Sid, Value * Number}),
            {'ok', BiCs, NStorage}
        end,
    z_db_lib:update(game_lib:get_table(Src, Type), RoleUid, {}, F, []);
%% 消耗rmb
consume(Src, RoleUid, _ItemSid, Number, _Exchange, {'rmb', Value}) ->
    Fun = fun(V1, Rmb) ->
        {BiCs, NRmb} = rmb_lib:reduct_rmb(Rmb, V1),
        {ok, BiCs, NRmb}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'rmb'), RoleUid, {0, 0}, Fun, Value * Number);
%% 消耗金币
consume(Src, RoleUid, _ItemSid, Number, _Exchange, {'money', Value}) ->
    Fun = fun(_, Role) ->
        {BiCs, NRole} = role_lib:deduct_money(Role, Value * Number),
        {'ok', BiCs, NRole}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'role'), RoleUid, Fun, []);
%% 消耗货币
consume(Src, RoleUid, _ItemSid, Number, _Exchange, {Res, Value}) when is_atom(Res), Res =/= 'times' ->
    Fun = fun(_, Role) ->
        FunName = string_lib:to_atom("deduct_", Res),
        {BiCs, NRole} = role_lib:FunName(Role, Value * Number),
        {'ok', BiCs, NRole}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'role'), RoleUid, Fun, []);
consume(_Src, _RoleUid, _ItemSid, _Number, _Exchange, _) ->
    none.