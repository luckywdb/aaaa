-module(active_everday_cash_two).

%%%=======================STATEMENT====================
-description("active_everday_cash_two").
-copyright('youkia,www.youkia.net').
-author("ljh,lvjihong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_event/4, handle_format/3]).
-export([role_red/4, get/6]).
%%%=======================INCLUDE=======================
-include("../include/active.hrl").
%%%=======================DEFINE========================
-define(FAIL_TO_TARGET, 0).
-define(CAN_GET_AWARD, 1).
-define(ALREADY_GET_AWARD, 2).
%%%=======================RECORD========================
-record(role_day_cash, {
    cash_day = 0 :: integer(),%%充值的日期
    award_day = 0 :: integer(),%%领奖的日期
    rmb = 0 :: integer(),%%充值金额
    state = 0 :: 0 | 1 | 2 %%0未达成目标，1可领奖，2已经领
}).
%%%=================EXPORTED FUNCTIONS===================
%%-------------------------------------------------------------------
%% @doc
%%      基础方法
%% @end
%%-------------------------------------------------------------------
init() -> #role_day_cash{}.
get_cash_day(#role_day_cash{cash_day = V}) -> V.
get_award_day(#role_day_cash{award_day = V}) -> V.
get_rmb(#role_day_cash{rmb = V}) -> V.
get_state(#role_day_cash{state = V}) -> V.
set_rmb(RDC, V) -> RDC#role_day_cash{rmb = V}.
set_state(RDC, V) -> RDC#role_day_cash{state = V}.
set_cash_day(RDC, V) -> RDC#role_day_cash{cash_day = V}.
set_award_day(RDC, V) -> RDC#role_day_cash{award_day = V}.

%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
-spec handle_get(atom(), integer(), term(), active:active()) -> tuple().
handle_get(Src, RoleUid, A, Active) ->
    Key = active_lib:get_role_active_key(RoleUid, Active),
    RoleDayCash = z_db_lib:get(game_lib:get_table(Src, ?MODULE), Key, init()),
    Format = handle_format(Src, A, Active),
    ToDay = time_lib:get_date_by_type('day_of_year'),
    Rmb =
        case get_cash_day(RoleDayCash) of
            ToDay ->
                get_rmb(RoleDayCash);
            _ ->
                0
        end,
    {Format, {Rmb, get_award_day(RoleDayCash)}}.


%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
-spec handle_start(atom(), term(), active:active(), integer()) -> 'ok'.
handle_start(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
-spec handle_run(atom(), term(), active:active(), integer()) -> 'ok'.
handle_run(Src, A, Active, _Time) ->
    %%检测跨天未领奖的
    award_reissue(Src, A, Active),
    ok.
%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
-spec handle_close(atom(), term(), active:active(), integer()) -> 'ok'.
handle_close(Src, A, Active, _Time) ->
    %%结束的时候补发没有领取的奖励
    award_reissue(Src, A, Active),
    %%进行数据清理，异步处理
    zm_event:notify(Src, active_clear, {?MODULE, Active}),
    'ok'.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
-spec handle_shut(atom(), term(), active:active(), integer()) -> 'ok'.
handle_shut(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      事件处理
%% @end
%%-------------------------------------------------------------------
-spec handle_event(atom(), term(), active:active(), tuple()) -> 'ok'.
handle_event(Src, [ItemList], Active, {'cash_ok', List}) ->
    RoleUid = z_lib:get_value(List, 'role_uid', 'none'),
    Cash = z_lib:get_value(List, 'cash_rmb', none),
    if
        RoleUid =:= none orelse Cash =:= 'none' ->
            zm_log:warn(Src, ?MODULE, 'handle_event', "error_role_itemId", [{'cash_ok', List}]);
        true ->
            [{_, TargetRmb, AwardList} | _] = ItemList,
            Fun = fun(_, RoleDayCash) ->
                {MailBool, NRoledayCash1} = refresh_role_everyday_cash(RoleDayCash, true),
                NRmb = get_rmb(NRoledayCash1) + Cash,
                State = get_state(NRoledayCash1),
                NState = if
                    NRmb >= TargetRmb andalso State =:= ?FAIL_TO_TARGET ->
                        ?CAN_GET_AWARD;
                    true ->
                        State
                end,
                NRoledayCash2 = set_state(set_rmb(NRoledayCash1, NRmb), NState),
                {ok, {ok, MailBool}, NRoledayCash2}
            end,
            case z_db_lib:update(game_lib:get_table(Src, ?MODULE), active_lib:get_role_active_key(RoleUid, Active), init(), Fun, 'none') of
                {ok, true} ->
                    send_mail(Src, RoleUid, AwardList, Active);
                _ ->
                    ok
            end
    end;
handle_event(_, _, _, _) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
-spec handle_format(atom(), list(), active:active()) -> tuple().
handle_format(Src, [List], Active) ->
    Fun = fun({_ItemSid, Rmb, AwardList}) ->
        {Rmb, list_to_tuple(AwardList)}
    end,
    {
        active:format_front(Src, ?MODULE, Active),
        list_to_tuple(lists:map(Fun, List))
    }.

%%-------------------------------------------------------------------
%% @doc
%%      是否有红点
%% @end
%%-------------------------------------------------------------------
-spec role_red(atom(), integer(), list(), active:active()) -> 0|1.
role_red(Src, RoleUid, [_ItemList], Active) ->
    RoleDayCash = z_db_lib:get(game_lib:get_table(Src, ?MODULE), active_lib:get_role_active_key(RoleUid, Active), init()),
    ToDay = time_lib:get_date_by_type('day_of_year'),
    case get_state(RoleDayCash) =:= ?CAN_GET_AWARD andalso get_cash_day(RoleDayCash) =:= ToDay of
        true ->
            1;
        false ->
            0
    end.

%%-------------------------------------------------------------------
%% @doc
%%      领取
%% @end
%%-------------------------------------------------------------------
-spec get(atom(), integer(), active:active(), integer(), list(), term()) -> tuple()|string().
get(Src, RoleUid, Active, _, _, _Msg) ->
    [ItemList] = active:get_a(Active),
    [{_, _TargetRmb, AwardList} | _] = ItemList,
    ToDay = time_lib:get_date_by_type('day_of_year'),
    Fun = fun(_, RoleDayCash) ->
        {MailBool, NRoleDayCash1} = refresh_role_everyday_cash(RoleDayCash, false),
        case get_state(NRoleDayCash1) =:= ?CAN_GET_AWARD andalso get_cash_day(NRoleDayCash1) =:= ToDay of
            true ->
                NRoleDayCash = set_award_day(set_state(NRoleDayCash1, ?ALREADY_GET_AWARD), ToDay),
                {ok, {ok, MailBool, AwardList}, NRoleDayCash};
            false ->
                throw("limit")
        end
    end,
    case z_db_lib:update(game_lib:get_table(Src, ?MODULE), active_lib:get_role_active_key(RoleUid, Active), init(), Fun, []) of
        {ok, MailBool, AwardList} ->
            if
                MailBool ->
                    send_mail(Src, RoleUid, AwardList, Active);
                true ->
                    ok
            end,
            {ok, AwardList};
        Err ->
            Err
    end.

%%-------------------------------------------------------------------
%% @doc
%%      发送邮件
%% @end
%%-------------------------------------------------------------------
send_mail(Src, RoleUid, AwardList, _Active) ->
    send_mail(Src, RoleUid, {12}, {12}, AwardList).
send_mail(_, _, _, _, []) ->
    ok;
send_mail(Src, RoleUid, MailTitle, MailContent, AwardList) ->
    MailType = award_source:get_source(?MODULE),
    Mail = mail:init({MailType, time_lib:now_second(), 0, MailTitle, MailContent, AwardList}),
    mail_db:send(Src, RoleUid, Mail).


%%-------------------------------------------------------------------
%% @doc
%%      刷新玩家数据
%% @end
%%-------------------------------------------------------------------
refresh_role_everyday_cash(RoleDayCash, Bool) ->
    CashDay = get_cash_day(RoleDayCash),
    State = get_state(RoleDayCash),
    ToDay = time_lib:get_date_by_type('day_of_year'),
    {MailBool, NRDC1} = if
        CashDay + 1 =:= ToDay andalso State =:= ?CAN_GET_AWARD ->
            {true, init()};
        CashDay =:= ToDay ->
            {false, RoleDayCash};
        true ->
            {false, init()}
    end,
    NRDC = if
        Bool ->
            set_cash_day(NRDC1, ToDay);
        true ->
            NRDC1
    end,
    {MailBool, NRDC}.


%%-------------------------------------------------------------------
%% @doc
%%      所有人奖励补发
%% @end
%%-------------------------------------------------------------------
-spec award_reissue(atom(), term(), active:active()) -> 'ok'.
award_reissue(Src, [ItemList], Active) ->
    ToDay = time_lib:get_date_by_type('day_of_year'),
    [{_, _TargetRmb, AwardList} | _] = ItemList,
    Table = game_lib:get_table(Src, ?MODULE),
    Fun = fun
        (_, {RoleUid, _, _} = Key, _, _) ->
            F = fun(_, RoleDayCash) ->
                State = get_state(RoleDayCash),
                AwardDay = get_award_day(RoleDayCash),
                CashDay = get_cash_day(RoleDayCash),
                if
                    State =:= ?CAN_GET_AWARD andalso AwardDay =/= ToDay andalso CashDay + 1 =:= ToDay ->
                        {ok, {ok, RoleUid}, init()};
                    CashDay =/= ToDay ->
                        {ok, ok, init()};
                    true ->
                        {ok, ok}
                end
            end,
            case z_db_lib:update(Table, Key, init(), F, []) of
                {ok, RoleUid} ->
                    send_mail(Src, RoleUid, AwardList, Active);
                _ ->
                    ok
            end
    end,
    z_db_lib:table_iterate(Src, Table, Fun, [], []),
    ok.