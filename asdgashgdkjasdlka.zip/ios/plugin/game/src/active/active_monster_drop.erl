%%野怪掉落活动
-module(active_monster_drop).

%%%=======================STATEMENT====================
-description("active_monster_drop").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_event/4, handle_format/3]).
-export([handle_update/2]).
-export([get_active_monster_drops/2]).
-export([delete/2]).
%%%=======================DEFINE=======================

%%%=======================INCLUDE=======================
-include("../include/active.hrl").
%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
-spec handle_get(atom(), integer(), term(), active:active()) -> tuple().
handle_get(Src, _RoleUid, A, Active) ->
    Format = handle_format(Src, A, Active),
    {Format, {}}.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
-spec handle_start(atom(), term(), active:active(), integer()) -> 'ok'.
handle_start(Src, _A, Active, _Time) ->
    start(Src, Active),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
-spec handle_run(atom(), term(), active:active(), integer()) -> 'ok'.
handle_run(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
-spec handle_close(atom(), term(), active:active(), integer()) -> 'ok'.
handle_close(Src, _A, Active, _Time) ->
    stop(Src, Active),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
-spec handle_shut(atom(), term(), active:active(), integer()) -> 'ok'.
handle_shut(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      事件处理
%% @end
%%-------------------------------------------------------------------
-spec handle_event(atom(), term(), active:active(), tuple()) -> 'ok'.
handle_event(_Src, _A, _Active, _Event) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
-spec handle_format(atom(), list(), active:active()) -> tuple().
handle_format(Src, A, Active) ->
    [MTypeLevelAwardList] = A,
    Views = lists:map(fun({Type, List}) ->
        ViewList = lists:map(fun({Min, Max, AwardList}) ->
            {Min, Max, list_to_tuple(awarder_game:format_award(AwardList))}
        end, List),
        {Type, list_to_tuple(ViewList)}
    end, MTypeLevelAwardList),
    {
        active:format_front(Src, ?MODULE, Active),
        list_to_tuple(Views)
    }.


%%-------------------------------------------------------------------
%% @doc
%%      数据更新
%% @end
%%-------------------------------------------------------------------
-spec handle_update(atom(), active:active()) -> 'ok'.
handle_update(Src, Active) ->
    update(Src, Active).

%%-------------------------------------------------------------------
%% @doc
%%      获取怪物掉落
%% @end
%%-------------------------------------------------------------------
-spec get_active_monster_drops(atom(), integer()) -> list().
get_active_monster_drops(Src, MonsterSid) ->
    MonsterDetail = monster_detail:get_cfg(MonsterSid),
    MonsterLv = monster_detail:get_level(MonsterDetail),
    MonseterType = monster_detail:get_type(MonsterDetail),
    MonsterDropList = z_db_lib:get(game_lib:get_table(Src, 'active_drop'), 'monster_drop_list', []),
    z_lib:foreach(fun(R, {_Sid, MTypeLevelAwardList}) ->
        LvDrops = z_lib:get_value(MTypeLevelAwardList, 0, []) ++ z_lib:get_value(MTypeLevelAwardList, MonseterType, []),
        NR = z_lib:foreach(fun(R1, {Min, Max, AList}) ->
            case MonsterLv >= Min andalso MonsterLv =< Max of
                true ->
                    {ok, AList ++ R1};
                false ->
                    {ok, R1}
            end
        end, R, LvDrops),
        {ok, NR}
    end, [], MonsterDropList).


%%%=====================LOC FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%
%% @end
%%-------------------------------------------------------------------
start(Src, Active) ->
    update(Src, Active).

%%-------------------------------------------------------------------
%% @doc
%%      活动结束扩展信息清理
%% @end
%%-------------------------------------------------------------------
stop(Src, Active) ->
    delete(Src, Active).



update(Src, Active) ->
    Sid = active:get_sid(Active),
    [MTypeLevelAwardList] = active:get_a(Active),
    Fun = fun(_, List) ->
        NList = lists:keystore(Sid, 1, List, {Sid, MTypeLevelAwardList}),
        {ok, ok, NList}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'active_drop'), 'monster_drop_list', [], Fun, []).
delete(Src, Active) ->
    Sid = active:get_sid(Active),
    Fun = fun(_, List) ->
        NList = lists:keydelete(Sid, 1, List),
        case NList =:= [] of
            true ->
                {ok, ok, 'delete'};
            false ->
                {ok, ok, NList}
        end
    end,
    z_db_lib:update(game_lib:get_table(Src, 'active_drop'), 'monster_drop_list', [], Fun, []).