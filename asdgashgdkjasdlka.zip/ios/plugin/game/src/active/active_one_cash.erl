%%限时单笔充值
-module(active_one_cash).

-description("active_one_cash").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_event/4, handle_format/3]).
-export([role_red/4, get/6]).
%%%=======================DEFINE=======================

%%%=======================INCLUDE=======================
-include("../include/active.hrl").
%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
-spec handle_get(atom(), integer(), term(), active:active()) -> tuple().
handle_get(Src, RoleUid, A, Active) ->
    Key = active_lib:get_role_active_key(RoleUid, Active),
    Format = handle_format(Src, A, Active),
    NRoleItemList = z_db_lib:get(game_lib:get_table(Src, ?MODULE), Key, []),
    {Format, list_to_tuple(NRoleItemList)}.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
-spec handle_start(atom(), term(), active:active(), integer()) -> 'ok'.
handle_start(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
-spec handle_run(atom(), term(), active:active(), integer()) -> 'ok'.
handle_run(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
-spec handle_close(atom(), term(), active:active(), integer()) -> 'ok'.
handle_close(Src, _A, Active, _Time) ->
    %%进行数据清理，异步处理
    zm_event:notify(Src, active_clear, {?MODULE, Active}),
    'ok'.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
-spec handle_shut(atom(), term(), active:active(), integer()) -> 'ok'.
handle_shut(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      事件处理
%% @end
%%-------------------------------------------------------------------
-spec handle_event(atom(), term(), active:active(), tuple()) -> 'ok'.
handle_event(Src, [ItemList], Active, {'cash_ok', List}) ->
    RoleUid = z_lib:get_value(List, 'role_uid', none),
    Cash = z_lib:get_value(List, 'cash_rmb', none),
    if
        RoleUid =:= none orelse Cash =:= none ->
            zm_log:warn(Src, ?MODULE, 'handle_event', "error", [{'cash_ok', List}]);
        true ->
            ItemSidMaxTimess = z_lib:foreach(fun(R, {Sid, Number, _, Times}) ->
                case Cash >= Number of
                    true ->
                        {ok, [{Sid, Times} | R]};
                    false ->
                        {'break', R}
                end
            end, [], ItemList),
            if
                ItemSidMaxTimess =/= [] ->
                    Fun = fun(_, RoleItemList) ->
                        V = z_lib:foreach(fun(R, {ItemSid, MaxTimes}) ->
                            {GetTimes, ComTimes} = case lists:keyfind(ItemSid, 1, RoleItemList) of
                                false ->
                                    {0, 0};
                                {_, GTimes, CTimes} ->
                                    {GTimes, CTimes}
                            end,
                            case ComTimes >= MaxTimes of
                                true ->
                                    {ok, R};
                                false ->
                                    {'break', {lists:keystore(ItemSid, 1, RoleItemList, {ItemSid, GetTimes, ComTimes + 1}), ItemSid, ComTimes + 1}}
                            end
                        end, {}, ItemSidMaxTimess),
                        case V of
                            {NRoleItemList, ItemSid, Times} ->
                                {ok, {ok, ItemSid, Times}, NRoleItemList};
                            _ ->
                                {ok, ok}
                        end
                    end,
                    case z_db_lib:update(game_lib:get_table(Src, ?MODULE), active_lib:get_role_active_key(RoleUid, Active), [], Fun, none) of
                        {ok, ItemSid, Times} ->
                            set_front_lib:send_active_one_cash(Src, RoleUid, {active:get_sid(Active), ItemSid, Times});
                        _ ->
                            ok
                    end;
                true ->
                    ok
            end
    end;
handle_event(_Src, _A, _Active, _Event) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
-spec handle_format(atom(), list(), active:active()) -> tuple().
handle_format(Src, [ItemList], Active) ->
    F = fun({ItemSid, Rmb, AwardList, Times}) ->
        {ItemSid, Rmb, erlang:list_to_tuple(AwardList), Times}
    end,
    {
        active:format_front(Src, ?MODULE, Active),
        erlang:list_to_tuple(lists:map(F, ItemList))
    }.

%%-------------------------------------------------------------------
%% @doc
%%      是否有红点
%% @end
%%-------------------------------------------------------------------
-spec role_red(atom(), integer(), list(), active:active()) -> 0|1.
role_red(Src, RoleUid, [ItemList], Active) ->
    RoleItemList = z_db_lib:get(game_lib:get_table(Src, ?MODULE), active_lib:get_role_active_key(RoleUid, Active), []),
    Bool = lists:any(fun({ItemSid, GetTimes, ComTimes}) ->
        case ComTimes > GetTimes of
            true ->
                {_, _Number, _AwardList, Times} = lists:keyfind(ItemSid, 1, ItemList),
                GetTimes < Times;
            false ->
                false
        end
    end, RoleItemList),
    if
        Bool ->
            1;
        true ->
            0
    end.
%%-------------------------------------------------------------------
%% @doc
%%      领取
%% @end
%%-------------------------------------------------------------------
-spec get(atom(), integer(), active:active(), integer(), list(), term()) -> tuple()|string().
get(Src, RoleUid, Active, ItemSid, [ItemList], _Msg) ->
    case lists:keyfind(ItemSid, 1, ItemList) of
        false ->
            "input_error";
        {ItemSid, _Number, AwardList, Times} ->
            F = fun(_, RoleItemList) ->
                {GetTimes, ComTimes} = case lists:keyfind(ItemSid, 1, RoleItemList) of
                    false ->
                        {0, 0};
                    {_, GTimes, CTimes} ->
                        {GTimes, CTimes}
                end,
                case ComTimes > GetTimes andalso GetTimes < Times of
                    true ->
                        {ok, ok, lists:keyreplace(ItemSid, 1, RoleItemList, {ItemSid, GetTimes + 1, ComTimes})};
                    false ->
                        throw("already_get")
                end
            end,
            case z_db_lib:update(game_lib:get_table(Src, ?MODULE), active_lib:get_role_active_key(RoleUid, Active), [], F, []) of
                ok ->
%%            AwardLog = awarder_game:give_award(Src, RoleUid, [], AwardList),
%%            zm_event:notify(Src, 'bi_active_one_cash', [{'role_uid', RoleUid}, {'active', Active}, {'itemsid', ItemSid}, {'number', Number}, {'awards', AwardLog}]),
                    {ok, AwardList};
                Err ->
                    Err
            end
    end.

%%%====================LOC FUNCTIONS===================
