-module(active_platform_answer).

%%%=======================STATEMENT====================
-description("active_platform_answer").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_event/4, handle_format/3]).
-export([answer/4]).

%%%=======================INCLUDE======================

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
-spec handle_get(atom(), integer(), term(), active:active()) -> tuple().
handle_get(Src, _RoleUid, A, Active) ->
    Format = handle_format(Src, A, Active),
    {Format, {}}.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
-spec handle_start(atom(), term(), active:active(), integer()) -> 'ok'.
handle_start(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
-spec handle_run(atom(), term(), active:active(), integer()) -> 'ok'.
handle_run(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
-spec handle_close(atom(), term(), active:active(), integer()) -> 'ok'.
handle_close(Src, _A, Active, _Time) ->
    zm_event:notify(Src, active_clear, {?MODULE, Active}),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
-spec handle_shut(atom(), term(), active:active(), integer()) -> 'ok'.
handle_shut(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      事件处理
%% @end
%%-------------------------------------------------------------------
-spec handle_event(atom(), term(), active:active(), tuple()) -> 'ok'.
handle_event(_Src, _A, _Active, _Event) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
-spec handle_format(atom(), list(), active:active()) -> tuple().
handle_format(Src, _A, Active) ->
    {
        active:format_front(Src, ?MODULE, Active),
        {}
    }.

%% ----------------------------------------------------
%% @doc
%%  答题
%% @end
%% ----------------------------------------------------
answer(Src, RoleUid, Active, Id) ->
    [A] = active:get_a(Active),
    %% 查询题对应的答案是否正确
    case lists:keyfind(Id, 1, A) of
        false ->
            -2; %% 没有该ID的题
        {_, _, Award} ->%id,答案,奖励
            Key = active_lib:get_role_active_key(RoleUid, Active),
            F = fun(_, List) ->
                case lists:member(Id, List) of
                    false ->
                        {ok, Award, [Id | List]};
                    true ->
                        {ok, -4}%% 本次活动该ID的题已经答过
                end
            end,

            case z_db_lib:update(game_lib:get_table(Src, ?MODULE), Key, [], F, []) of
                -4 ->
                    -4;
                Award ->
                    %% 发邮件
                    {Theme, Content} = z_lib:get_value(A, mail_theme_content, {"", ""}),
%%                    MailType = award_source:get_source(?MODULE),
                    Mail = mail:init({-1, time_lib:now_second(), 0, {0, Theme}, {0, Content}, Award}),
                    mail_db:send(Src, RoleUid, Mail),
                    zm_log:info(Src, ?MODULE, ?MODULE, "answer", [{'roleuid', RoleUid}, {sid, Id}, {award, Award}]),
                    1
            end
    end.
%%%=====================LOC FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%
%% @end
%%-------------------------------------------------------------------
