%%活动工具
-module(active_lib).

%%%=======================STATEMENT===================
-description("active_lib").
-copyright({seasky, 'www.seasky.cn'}).
-author({cb, 'chenbin@youkia.net'}).
-vsn(1).

%%%=======================EXPORT=======================
-export([get_active_state_key/1, get_active_time_key/2, get_role_active_key/2, get_active_mod_key/2, get_active_key/2, get_config_actives_sid/1, get_fixed_active_sequence/1]).
-export([combination_award/5]).
%%%=======================INCLUDE======================
-include("../include/active.hrl").
%%%=======================RECORD=======================

%%%=======================DEFINE=======================

%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      得到活动状态key
%% @end
%%-------------------------------------------------------------------
-spec get_active_state_key(atom()) -> {integer(), integer(), 'state'}.
get_active_state_key(Src) ->
    game_lib:get_server_key(Src, state).

%%-------------------------------------------------------------------
%% @doc
%%      得到活动key
%% @end
%%-------------------------------------------------------------------
-spec get_active_time_key(atom(), integer()|active_time:active_time()) -> {integer(), integer(), integer()}.
get_active_time_key(Src, Sid) when is_integer(Sid) ->
    game_lib:get_server_key(Src, Sid);
get_active_time_key(Src, Recode) when is_tuple(Recode) ->
    game_lib:get_server_key(Src, active_time:get_sid(Recode)).

%%-------------------------------------------------------------------
%% @doc
%%      得到个人参与的数据key
%% @end
%%-------------------------------------------------------------------
-spec get_role_active_key(integer(), active:active()) -> {integer(), integer(), integer()}.
get_role_active_key(RoleUid, Active) ->
    {RoleUid, active:get_sid(Active), active:get_term(Active)}.

%%-------------------------------------------------------------------
%% @doc
%%      得到模块内key(active_db中cliear时候,有匹配规则)
%% @end
%%-------------------------------------------------------------------
-spec get_active_mod_key(term(), active:active()) -> {term(), integer(), integer()}.
get_active_mod_key(Key, Active) ->
    {Key, active:get_sid(Active), active:get_term(Active)}.

%%-------------------------------------------------------------------
%% @doc
%%      得到活动key
%% @end
%%-------------------------------------------------------------------
-spec get_active_key(atom(), integer() | active:active()) -> {integer(), integer(), integer()}.
get_active_key(Src, Sid) when is_integer(Sid) ->
    game_lib:get_server_key(Src, Sid);
get_active_key(Src, Active) ->
    game_lib:get_server_key(Src, active:get_sid(Active)).

%% ----------------------------------------------------
%% Func: get_config_actives_sid/2
%% Description: 得到配置文件中的所有活动sid
%% Returns:  tuple
%% ----------------------------------------------------
%%-------------------------------------------------------------------
%% @doc
%%      得到配置文件中的所有活动key
%% @end
%%-------------------------------------------------------------------
-spec get_config_actives_sid(atom()) -> [{integer(), integer(), integer()}].
get_config_actives_sid(Src) ->
    case zm_config:get('active') of
        none ->
            [];
        Actives ->
            [get_active_key(Src, Active) || Active <- Actives]
    end.

%% ----------------------------------------------------
%% Func: get_fixed_active_sequence/1
%% Description: 得到配置文件中的所有活动sid
%% Returns:  tuple
%% ----------------------------------------------------
get_fixed_active_sequence(Type) ->
    {_, List} = zm_config:get(fixed_active_sequence, sequence),
    case lists:keyfind(Type, 1, List) of
        false ->
            100;%%放最后
        {_, Sequence} ->
            Sequence
    end.

%% ----------------------------------------------------
%% Func: combination_award/5
%% Description: 组合翻倍奖励
%% Returns:  tuple
%% ----------------------------------------------------
combination_award(Src, GAward, {Table, Key}, Multiple, Module) ->
    if
        Multiple > 0 ->
            case zm_config:get(Table, Key) of
                none ->
                    GAward;
                {_, MultipleList} ->
                    {GAwardUid, GAwardArgs, GAwardAexpend} = GAward,
                    {_, _, MAward} = awarder:get(Src, GAwardUid, Module, MultipleList, Multiple),
                    {GAwardUid, GAwardArgs, GAwardAexpend ++ MAward}
            end;
        true ->
            GAward
    end.
