-module(active_sworn_brothers).

%%%=======================STATEMENT====================
-description("active_sworn_brothers").
-copyright('youkia,www.youkia.net').
-author("ljh,lvjihong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_event/4, handle_format/3]).

-export([stop/2]).
%%%=======================DEFINE=======================

%%%=======================INCLUDE=======================
-include("../include/active.hrl").

%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
-spec handle_get(atom(), integer(), term(), active:active()) -> tuple().
handle_get(Src, RoleUid, A, Active) ->
    Format = handle_format(Src, A, Active),
    ActiveSid = active:get_sid(Active),
    ActiveSidTemplate = template_lib:get_templates(Src, ?MODULE),
    {_, TName} = lists:keyfind(ActiveSid, 1, ActiveSidTemplate),
    {_, LdInfo} = zm_config:get('ld_info', TName),
    RoleLdInfo = ld_lib:front_format(ActiveSid, ld:refresh_count(ld_db:get_ld_count(Src, {RoleUid, ActiveSid})), LdInfo),
    {Format, RoleLdInfo}.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
-spec handle_start(atom(), term(), active:active(), integer()) -> 'ok'.
handle_start(Src, _A, Active, _Time) ->
    start(Src, Active),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
-spec handle_run(atom(), term(), active:active(), integer()) -> 'ok'.
handle_run(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
-spec handle_close(atom(), term(), active:active(), integer()) -> 'ok'.
handle_close(Src, _A, Active, _Time) ->
    stop(Src, Active),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
-spec handle_shut(atom(), term(), active:active(), integer()) -> 'ok'.
handle_shut(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动抽卡事件处理
%% @end
%%-------------------------------------------------------------------
-spec handle_event(atom(), term(), active:active(), tuple()) -> 'ok'.
handle_event(_Src, _A, _Active, _Event) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
-spec handle_format(atom(), list(), active:active()) -> tuple().
handle_format(Src, [A], Active) ->
    [{_Template, MustAward, RandomAward, OneConsume, TenConSume, SeeVipLevel, LdVipLevel}] = A,
    {
        active:format_front(Src, ?MODULE, Active),
        {MustAward, RandomAward, OneConsume, TenConSume, SeeVipLevel, LdVipLevel}
    }.


%%%=====================LOC FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%
%% @end
%%-------------------------------------------------------------------
start(Src, Active) ->
    [A] = active:get_a(Active),
    [{Template, _MustAward, _RandomAward, _OneConsume, _TenConSume, _SeeVipLevel, _LdVipLevel}] = A,
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'sid_template', template_lib:get_key(Src, ?MODULE), []}
    ]),
    z_db_lib:handle(TableName, fun start_/2, {Src, Template, Active}, TableKeys).

%%-------------------------------------------------------------------
%% @doc
%%      新增排行榜类型
%%      新增抽卡活动sid在GM那边新增活动时候增加,GM配置的活动则读取数据库配置
%% @end
%%-------------------------------------------------------------------
start_({_Src, Template, Active}, [{Index1, ALd}]) ->
    Sid = active:get_sid(Active),
    {ok, ok, [{Index1, lists:keystore(Sid, 1, ALd, {Sid, Template})}]}.
%%-------------------------------------------------------------------
%% @doc
%%      活动结束扩展信息清理
%% @end
%%-------------------------------------------------------------------
stop(Src, Active) ->
    %%清除本次活动积分排行榜,排行榜sid,抽卡sid
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'sid_template', template_lib:get_key(Src, ?MODULE), []}
    ]),
    z_db_lib:handle(TableName, fun stop_/2, {Src, Active}, TableKeys).

%%-------------------------------------------------------------------
%% @doc
%%      清理抽卡活动相关扩展信息
%% @end
%%-------------------------------------------------------------------
stop_({_Src, Active}, [{Index1, ALd}]) ->
    Sid = active:get_sid(Active),
    {ok, ok, [{Index1, lists:keydelete(Sid, 1, ALd)}]}.
