%%采集活动，仅有只有目标奖励类型
-module(active_collect_target).

%%%=======================STATEMENT====================
-description("active_collect_target").
-copyright('youkia,www.youkia.net').
-author("oymh,ouyangminghui@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_event/4, handle_format/3, get_list/2, get_type/1]).
%%%=======================DEFINE=======================

%%%=======================INCLUDE=======================
-include("../include/active.hrl").

%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
-spec handle_get(atom(), integer(), term(), active:active()) -> tuple().
handle_get(Src, RoleUid, A, Active) ->
    Key = active_lib:get_role_active_key(RoleUid, Active),
    Format = handle_format(Src, A, Active),
    {Score, _} = z_db_lib:get(game_lib:get_table(Src, ?MODULE), Key, {0, []}),
    {Format, {Score}}.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
-spec handle_start(atom(), term(), active:active(), integer()) -> 'ok'.
handle_start(_Src, _A, _Active, _Time) ->
    %start(Src, Active),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
-spec handle_run(atom(), term(), active:active(), integer()) -> 'ok'.
handle_run(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
-spec handle_close(atom(), term(), active:active(), integer()) -> 'ok'.
handle_close(Src, _A, Active, _Time) ->
    %stop(Src, Active),
    zm_event:notify(Src, active_clear, {?MODULE, Active}),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
-spec handle_shut(atom(), term(), active:active(), integer()) -> 'ok'.
handle_shut(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动事件处理
%% @end
%%-------------------------------------------------------------------
-spec handle_event(atom(), term(), active:active(), tuple()) -> 'ok'.
handle_event(Src, _A, Active, {'active_collect_target', {Type, List}}) ->
    {_, RoleUid} = lists:keyfind('role_uid', 1, List),
    {_, AwardList} = lists:keyfind('award_list', 1, List),
    NActiveList = get_list(Type, AwardList),%%将抽到的卡片整理成活动对应的数据
    NScore = add_score(Src, RoleUid, NActiveList, Active),
    target_award(Src, RoleUid, Active, NScore),
    ok;
handle_event(_Src, _A, _Active, _Event) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
-spec handle_format(atom(), list(), active:active()) -> tuple().
handle_format(Src, A, Active) ->
    [{TargetList, OtherInfo}] = A,
    Fun2 = fun({Index, Target, AwardList}) -> {Index, Target, list_to_tuple(AwardList)} end,
    {
        active:format_front(Src, ?MODULE, Active),
        {{get_type(OtherInfo)}, list_to_tuple(lists:map(Fun2, TargetList))}
    }.


%%-------------------------------------------------------------------
%% @doc
%%      排行榜玩家显示数据
%% @end
%%-------------------------------------------------------------------
%%-spec rank_view(term(), atom(), integer(), integer()) -> tuple().
%%rank_view(_A, Src, RoleUid, Value) ->
%%    RoleShow = role_db:get_role_show(Src, RoleUid),
%%    {RoleUid, role_show:get_name(RoleShow), role_show:get_corps_uid(RoleShow), role_show:get_corps_name(RoleShow), Value, role_show:get_country(RoleShow)}.

%%-------------------------------------------------------------------
%% @doc
%%      增加积分
%% @end
%%-------------------------------------------------------------------
-spec add_score(atom(), integer(), integer(), active:active()) -> integer().
add_score(Src, RoleUid, AwardList, Active) ->
    [{_TargetList1, OtherInfo}] = active:get_a(Active),
    {_, TypeList} = lists:keyfind(type, 1, OtherInfo),
    Key = active_lib:get_role_active_key(RoleUid, Active),
    F = fun(AwardList1, {OldScore, ItemList}) ->
        AddScore = z_lib:foreach(fun(S, {Resource, Num}) ->
            case lists:member(Resource, TypeList) of
                true ->
                    {ok, S + Num};
                false ->
                    {ok, S}
            end
        end, 0, AwardList1),
        NewScore = OldScore + AddScore,
        {ok, NewScore, {NewScore, ItemList}}
    end,
    z_db_lib:update(game_lib:get_table(Src, ?MODULE), Key, {0, []}, F, AwardList).


%%%=====================LOC FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%
%% @end
%%-------------------------------------------------------------------
%%start(Src, Active) ->
%%    rank_db:add_rank_type(Src, active:get_sid(Active), ?MODULE),
%%    TableName = game_lib:get_table(Src),
%%    TableKeys = z_db_lib:transformation_tablekey(TableName, [
%%        {'sid_template', template_lib:get_key(Src, 'other_rank'), []}
%%    ]),
%%    z_db_lib:handle(TableName, fun start_/2, {Src, Active}, TableKeys).

%%-------------------------------------------------------------------
%% @doc
%%      新增排行榜类型
%% @end
%%-------------------------------------------------------------------
%%start_({_Src, Active}, [{Index1, RankTypeList}]) ->
%%    Sid = active:get_sid(Active),
%%    {ok, ok, [{Index1, lists:keystore(Sid, 1, RankTypeList, {Sid, ?MODULE})}]}.

%%-------------------------------------------------------------------
%% @doc
%%      活动结束扩展信息清理
%% @end
%%-------------------------------------------------------------------
%%stop(Src, Active) ->
%%    Sid = active:get_sid(Active),
%%    %%发放积分排行榜奖励
%%    [{AwardList, _TargetList, _}] = active:get_a(Active),
%%    rank_award(Src, Active, AwardList),
%%    rank_db:clear_ranks(Src, Sid).


%%-------------------------------------------------------------------
%% @doc
%%      发放排行榜奖励
%% @end
%%-------------------------------------------------------------------
%%-spec rank_award(atom(), active:active(), [{integer(), integer(), list()}]) -> term().
%%rank_award(Src, Active, AwardList) ->
%%    Key = game_lib:get_server_key(Src, active),
%%    Sid = active:get_sid(Active),
%%    Term = active:get_term(Active),
%%    case active_db:update_award_flag(Src, Sid, Term, Key) of
%%        false ->
%%            %%刷新一次排行榜
%%            rank_refresh:timer_refresh(Src, [[Sid]], []),
%%            AllRank = get_max_rank(AwardList),
%%            %%TODO 分多次取
%%            RankActions = rank_get:get_rank_range(Src, Sid, 1, AllRank),
%%            RanksSize = erlang:length(RankActions),
%%            ActiveName = active:get_name(Active),
%%            [send_mail(Src, Award, RankActions, RanksSize, MinRank, MaxRank, ActiveName) || {MinRank, MaxRank, Award} <- AwardList];
%%        true ->
%%            'ignore'
%%    end.

%%-------------------------------------------------------------------
%% @doc
%%      目标奖励
%% @end
%%-------------------------------------------------------------------
-spec target_award(atom(), integer(), active:active(), integer()) -> term().
target_award(Src, RoleUid, Active, NScore) ->
    [{TargetList, _}] = active:get_a(Active),
    Key = active_lib:get_role_active_key(RoleUid, Active),
    {IndexList, ItemList} = lists:foldl(fun({Index, T, Award}, {Acc0, Acc1}) ->
        case T =< NScore of
            true ->
                {[Index | Acc0], [{Index, T, Award} | Acc1]};
            _ ->
                {Acc0, Acc1}
        end
    end, {[], []}, TargetList),
    Fun = fun(_, {OScore, AwardList}) ->
        case IndexList -- AwardList of
            [] ->
                {ok, ok};
            NList ->
                {ok, {ok, NList}, {OScore, lists:usort(NList ++ AwardList)}}
        end
    end,
    case z_db_lib:update(game_lib:get_table(Src, ?MODULE), Key, {NScore, []}, Fun, []) of
        {ok, IList} ->
            ActiveName = active:get_name(Active),
            lists:foreach(fun({Index, Score, Award}) ->
                case lists:member(Index, IList) of
                    true ->
                        MailType = award_source:get_source(?MODULE),
                        Mail = mail:init({MailType, time_lib:now_second(), 0, {8, ActiveName}, {8, ActiveName, Score}, Award}),
                        mail_db:send(Src, RoleUid, Mail);
                    false ->
                        ok
                end
            end, ItemList),
            set_front_lib:send_active_score_award(Src, RoleUid, {active:get_sid(Active), NScore});
        _ ->
            set_front_lib:send_active_score_award(Src, RoleUid, {active:get_sid(Active), NScore})
    end.


%%-------------------------------------------------------------------
%% @doc
%%      发放邮件
%% @end
%%-------------------------------------------------------------------
%%send_mail(_Src, _Award, _Ranks, RanksSize, MinRank, _MaxRank, _ActiveName) when RanksSize < MinRank ->
%%    'ignore';
%%send_mail(Src, Award, Ranks, RanksSize, MinRank, MaxRank, ActiveName) ->
%%    AllRank = if
%%        RanksSize > MaxRank ->
%%            MaxRank - MinRank + 1;
%%        true ->
%%            RanksSize - MinRank + 1
%%    end,
%%    MailType = award_source:get_source(?MODULE),
%%    lists:foldl(fun(Info, Rank) ->
%%        {RoleUid, _Score} = Info,
%%        Mail = mail:init({MailType, time_lib:now_second(), 0, {7, ActiveName}, {7, ActiveName, Rank}, Award}),
%%        mail_db:send(Src, RoleUid, Mail),
%%        Rank + 1
%%    end, MinRank, lists:sublist(Ranks, MinRank, AllRank)).

%%-------------------------------------------------------------------
%% @doc
%%      在抛活动事件之前，整理成活动索需要的数据格式{活动类型，积分} 根据传入的类型算出对应活动的积分
%% @end
%%-------------------------------------------------------------------
get_list(Type, List) ->
    case Type of
        'card' ->%%求贤若渴
            AllScore = lists:foldl(fun({prop, {Sid, Num}}, R) ->
                %%根据sid获得武将品质，转化为积分返回
                Prop = prop_kit_lib:get_prop(Sid),
                Type1 = prop_kit_lib:get_prop_type(Prop),
                case Type1 of%%因为抽卡获得的不一样是卡牌
                    'card' ->
                        Card = prop_kit_lib:get_prop_record(Prop),
                        Quality = card:get_quality(Card),
                        {_, Score} = zm_config:get(card_to_score, Quality),
                        Score * Num + R;
                    _ ->
                        R
                end
            end, 0, List),
            [{Type, AllScore}];
        _ ->
            List
    end.

%%-------------------------------------------------------------------
%% @doc
%%      获取活动的子类型
%% @end
%%-------------------------------------------------------------------
get_type(OtherInfo) ->
    {_, TypeList} = lists:keyfind(type, 1, OtherInfo),
    List = zm_config:get(gm_active_type),
    NList = lists:foldl(fun({_, Type, Type1}, R) ->
        Check = lists:member(Type, TypeList),
        if
            Check orelse Type =:= TypeList ->%%因为这里有可能是技法强国，则两个type都是list类型
                [Type1 | R];
            true ->
                R
        end end, [], List),
    lists:nth(1, NList).