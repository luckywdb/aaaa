%%副本掉落活动
-module(active_duplicate_drop).

%%%=======================STATEMENT====================
-description("active_monster_drop").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_event/4, handle_format/3]).
-export([handle_update/2]).
-export([get_active_duplicate_drops/2]).
-export([delete/2]).
%%%=======================DEFINE=======================

%%%=======================INCLUDE=======================
-include("../include/active.hrl").
%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
-spec handle_get(atom(), integer(), term(), active:active()) -> tuple().
handle_get(Src, _RoleUid, A, Active) ->
    Format = handle_format(Src, A, Active),
    {Format, {}}.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
-spec handle_start(atom(), term(), active:active(), integer()) -> 'ok'.
handle_start(Src, _A, Active, _Time) ->
    start(Src, Active),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
-spec handle_run(atom(), term(), active:active(), integer()) -> 'ok'.
handle_run(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
-spec handle_close(atom(), term(), active:active(), integer()) -> 'ok'.
handle_close(Src, _A, Active, _Time) ->
    stop(Src, Active),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
-spec handle_shut(atom(), term(), active:active(), integer()) -> 'ok'.
handle_shut(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      事件处理
%% @end
%%-------------------------------------------------------------------
-spec handle_event(atom(), term(), active:active(), tuple()) -> 'ok'.
handle_event(_Src, _A, _Active, _Event) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      数据更新
%% @end
%%-------------------------------------------------------------------
-spec handle_update(atom(), active:active()) -> 'ok'.
handle_update(Src, Active) ->
    update(Src, Active).
%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
-spec handle_format(atom(), list(), active:active()) -> tuple().
handle_format(Src, A, Active) ->
    [MTypeCSidAwardList] = A,
    Views = lists:map(fun({Type, List}) ->
        ViewList = lists:map(fun({Min, Max, _ChapterSidRangeList, AwardList}) ->
            {Min, Max, list_to_tuple(awarder_game:format_award(AwardList))}
        end, List),
        {Type, list_to_tuple(ViewList)}
    end, MTypeCSidAwardList),
    {
        active:format_front(Src, ?MODULE, Active),
        list_to_tuple(Views)
    }.


%%-------------------------------------------------------------------
%% @doc
%%      获取副本掉落
%% @end
%%-------------------------------------------------------------------
-spec get_active_duplicate_drops(atom(), integer()) -> list().
get_active_duplicate_drops(Src, DuplicateSid) ->
    {_, DConfig} = zm_config:get('duplicate', DuplicateSid),
    ChapterSid = z_lib:get_value(DConfig, 'chapter', 0),
    Type = z_lib:get_value(DConfig, 'type', 0),
    DuplicateDropList = z_db_lib:get(game_lib:get_table(Src, 'active_drop'), 'duplicate_drop_list', []),
    z_lib:foreach(fun(R, {_Sid, MCSidAwardList}) ->
        Drops = z_lib:get_value(MCSidAwardList, 0, []) ++ z_lib:get_value(MCSidAwardList, Type, []),
        NR = z_lib:foreach(fun(R1, {ChapterSidRangeList, AList}) ->
            case lists:any(fun({MinChapterSid, MaxChapterSid}) ->
                ChapterSid >= MinChapterSid andalso ChapterSid =< MaxChapterSid end, ChapterSidRangeList) of
                true ->
                    {'ok', AList ++ R1};
                false ->
                    {ok, R1}
            end
        end, R, Drops),
        {ok, NR}
    end, [], DuplicateDropList).


%%%=====================LOC FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%
%% @end
%%-------------------------------------------------------------------
start(Src, Active) ->
    update(Src, Active).


%%-------------------------------------------------------------------
%% @doc
%%      活动结束扩展信息清理
%% @end
%%-------------------------------------------------------------------
stop(Src, Active) ->
    delete(Src, Active).


update(Src, Active) ->
    Sid = active:get_sid(Active),
    [MTypeCSidAwardList] = active:get_a(Active),
    NList = lists:map(fun({Type, List}) ->
        ViewList = lists:map(fun({_Min, _Max, ChapterSidRangeList, AwardList}) ->
            {ChapterSidRangeList, AwardList}
        end, List),
        {Type, ViewList}
    end, MTypeCSidAwardList),
    Fun = fun(_, VList) ->
        NVList = lists:keystore(Sid, 1, VList, {Sid, NList}),
        {ok, ok, NVList}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'active_drop'), 'duplicate_drop_list', [], Fun, []).
delete(Src, Active) ->
    Sid = active:get_sid(Active),
    Fun = fun(_, List) ->
        NList = lists:keydelete(Sid, 1, List),
        case NList =:= [] of
            true ->
                {ok, ok, 'delete'};
            false ->
                {ok, ok, NList}
        end
    end,
    z_db_lib:update(game_lib:get_table(Src, 'active_drop'), 'duplicate_drop_list', [], Fun, []).