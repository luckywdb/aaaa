%%活动通讯端口
-module(active_port).
-description("active_port").
-copyright({seasky, 'www.seasky.cn'}).
-author({cb, 'chenbin@youkia.net'}).
-vsn(1).
%%%=======================EXPORT=======================
-export([check_active/5, get_actives/5, get_active_by_mod/5, get_short_actives/5, get_active_extra/5, get_active_by_sid/5]).
-export([get/5, exchange/5]).
-export([seek_precious/5, score_shop/5, buy_seek_token/5]).
%%%=======================INCLUDE======================
-include("../include/active.hrl").
%%%=======================DEFINE======================

%%%=================EXPORTED FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%      得到开始活动信息
%% @end
%%-------------------------------------------------------------------
get_actives(_, _Session, Attr, Info, _Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, 'src', 'none'),
    ActivesState = active_db:get_config_active_state_list(Src),
    F = fun({ActiveSid, State}, List) when State =:= ?STOP orelse State =:= ?RUN orelse State =:= ?BEFORE ->
        case active_db:get_active(Src, ActiveSid) of
            none ->
                List;
            Active ->
%%                case active:get_visible(Active) of
%%                    ?VISIBLE ->
                {M, A} = active:get_ma(Active),
                try
                    case M:handle_get(Src, RoleUid, A, Active) of
                        ActiveInfo when is_tuple(ActiveInfo) ->
                            [ActiveInfo | List];
                        _ ->
                            List
                    end
                catch
                    E:E1 ->
                        zm_log:warn(Src, ?MODULE, 'active', "get_actives", [{'e', E}, {'e1', E1}, {'sid', ActiveSid}, {'stacktrace', erlang:get_stacktrace()}]),
                        List
                end
%%                    _ ->
%%                        List
%%                end
        end;
        (_, List) ->
            List
    end,
    Reply = erlang:list_to_tuple(lists:foldl(F, [], ActivesState)),
    {ok, [], Info, [{msg, Reply}]}.


%%-------------------------------------------------------------------
%% @doc
%%      根据模块名得到活动信息
%% @end
%%-------------------------------------------------------------------
get_active_by_mod(_, _Session, Attr, Info, Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, 'src', 'none'),
    Mod = string_lib:to_atom(z_lib:get_value(Msg, "mod", "none")),
    Reply = erlang:list_to_tuple(active_db:get_actives_by_mod(Src, RoleUid, Mod)),
    {ok, [], Info, [{msg, Reply}]}.

%%-------------------------------------------------------------------
%% @doc
%%      根据活动sid得到活动信息
%% @end
%%-------------------------------------------------------------------
get_active_by_sid(_, _Session, Attr, Info, Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, 'src', 'none'),
    ActiveSid = erlang:list_to_integer(z_lib:get_value(Msg, "sid", "none")),
    Reply = erlang:list_to_tuple(active_db:get_actives_by_sid(Src, RoleUid, active_lib:get_active_key(Src, ActiveSid))),
    {ok, [], Info, [{msg, Reply}]}.

%%-------------------------------------------------------------------
%% @doc
%%      获取
%% @end
%%-------------------------------------------------------------------
get(_, _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    ActiveSid = z_lib:get_value(Msg, "active_sid", 0),
    Sid = z_lib:get_value(Msg, "sid", 0),
    case z_db_lib:get(game_lib:get_table(Src, 'active'), active_lib:get_active_key(Src, ActiveSid), none) of
        none ->
            {ok, [], Info, [{msg, "no_active"}]};
        Active ->
            {M, A} = active:get_ma(Active),
            case M:get(Src, RoleUid, Active, Sid, A, Msg) of
                {ok, []} ->
                    {ok, [], Info, [{msg, {}}]};
                {ok, AwardList} ->
                    AwardLog = awarder:give_award(Src, RoleUid, ?MODULE, AwardList),
                    zm_log:info(Src, ?MODULE, 'get', "active_get", [{'roleuid', RoleUid}, {'active', Active},
                        {'item_sid', Sid}, {'award', AwardLog}]),
                    zm_event:notify(Src, 'active_get', [{'role_uid', RoleUid}, {'active', Active},
                        {'item_sid', Sid}, {'award', AwardLog}]),
                    {ok, [], Info, [{msg, AwardLog}]};
                Err ->
                    {ok, [], Info, [{msg, Err}]}
            end
    end.

%%-------------------------------------------------------------------
%% @doc
%%      兑换
%% @end
%%-------------------------------------------------------------------
exchange(_, _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    ActiveSid = z_lib:get_value(Msg, "active_sid", 0),
    Sid = z_lib:get_value(Msg, "sid", 0),
    Number = z_lib:get_value(Msg, "number", 1),
    case z_db_lib:get(game_lib:get_table(Src, 'active'), active_lib:get_active_key(Src, ActiveSid), none) of
        none ->
            {ok, [], Info, [{msg, "no_active"}]};
        Active ->
            {M, A} = active:get_ma(Active),
            [List] = A,
            Item = lists:keyfind(Sid, 1, List),
            Bool = (Item =/= false) andalso Number > 0,
            if
                Bool ->
                    case M:exchange(Src, RoleUid, Active, Item, Number, Msg) of
                        {ok, Consume, AwardList} ->
                            AwardLog = awarder:give_award(Src, RoleUid, ?MODULE, AwardList, Number),
                            zm_log:info(Src, ?MODULE, 'exchange', "active_exchange", [{'roleuid', RoleUid}, {'active', Active},
                                {'item_sid', Sid}, {'consume', Consume}, {'exchange', AwardLog}]),
                            zm_event:notify(Src, 'active_exchange', [{'role_uid', RoleUid}, {'active', Active},
                                {'item_sid', Sid}, {'consume', Consume}, {'award', AwardLog}]),
                            {ok, [], Info, [{msg, AwardLog}]};
                        Err ->
                            {ok, [], Info, [{msg, Err}]}
                    end;
                true ->
                    {ok, [], Info, [{msg, "input_error"}]}
            end
    end.

%%-------------------------------------------------------------------
%% @doc
%%      得到活动简要信息
%% @end
%%-------------------------------------------------------------------
get_short_actives(_, _Session, Attr, Info, _Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    Reply = erlang:list_to_tuple(active_db:get_short_actives(Src, RoleUid)),
    {ok, [], Info, [{msg, Reply}]}.

%%-------------------------------------------------------------------
%% @doc
%%      检查任务是否允许中
%% @end
%%-------------------------------------------------------------------
check_active(_, _Session, _Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    ActiveSid = z_lib:get_value(Msg, "active_sid", 0),
    case active_db:is_closed(Src, active_lib:get_active_key(Src, ActiveSid)) of
        true ->
            {break, [], Info, [{msg, "no_active_open"}]};
        false ->
            {ok, [], Info, Msg}
    end.


%%-------------------------------------------------------------------
%% @doc
%%      活动获取额外信息
%% @end
%%-------------------------------------------------------------------
get_active_extra(_, _Session, Attr, Info, Msg) ->
    RoleUid = role_lib:get_uid(Attr),
    Src = z_lib:get_value(Info, 'src', 'none'),
    ActiveSid = z_lib:get_value(Msg, "active_sid", 0),
    Reply =
        case active_db:get_active(Src, active_lib:get_active_key(Src, ActiveSid)) of
            none ->
                {};
            Active ->
                {M, _A} = active:get_ma(Active),
                try
                    M:handle_get_extra(Src, RoleUid, Active, Msg)
                catch
                    E:E1 ->
                        zm_log:warn(Src, ?MODULE, 'active', "get_active_extra", [{'e', E}, {'e1', E1}, {'sid', ActiveSid}, {'stacktrace', erlang:get_stacktrace()}]),
                        {}
                end
        end,
    {ok, [], Info, [{msg, Reply}]}.
%%-------------------------------------------------------------------
%% @doc
%%      皇宫探宝抽奖
%% @end
%%-------------------------------------------------------------------
seek_precious(_, _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    ActiveSid = z_lib:get_value(Msg, "active_sid", 0),
    Times = z_lib:get_value(Msg, "times", 0),
    CheckValid = valid_lib:check_valib([{'exist', Times, [1, 10]}]),
    if
        CheckValid ->
            case z_db_lib:get(game_lib:get_table(Src, 'active'), active_lib:get_active_key(Src, ActiveSid), none) of
                none ->
                    {ok, [], Info, [{msg, "no_active"}]};
                Active ->
                    {M, [A]} = active:get_ma(Active),
                    TableName = game_lib:get_table(Src),
                    TableKeys = z_db_lib:transformation_tablekey(TableName, [{'active_seek_precious', active_lib:get_role_active_key(RoleUid, Active), active_seek_precious:init()},
                        {'rmb', RoleUid, rmb_lib:init()},
                        {'goods', RoleUid, {}}]),
                    case z_db_lib:handle(TableName, {M, 'seek_precious', []}, {Src, RoleUid, Times, A, time_lib:get_date_by_type('day_of_year')}, TableKeys) of
                        {ok, Consume, Awards, GridIds} ->
                            AwardLog = awarder:give_award(Src, RoleUid, ?MODULE, Awards),
                            zm_log:info(Src, ?MODULE, 'seek_precious', "active_seek_precious", [{'roleuid', RoleUid}, {'active', Active},
                                {'times', Times}, {'award', AwardLog}, {'consume', Consume}]),
                            zm_event:notify(Src, 'active_seek_precious', [{'role_uid', RoleUid}, {'active', Active},
                                {'times', Times}, {'award', AwardLog}, {'consume', Consume}]),
                            zm_event:notify(Src, 'broadcast', {'awards_broadcast', [{'role_uid', RoleUid}, {'award', Awards},
                                {'source', active:get_name(Active)}, {'language', 'awards_broadcast'}]}),
                            {ok, [], Info, [{msg, {AwardLog, list_to_tuple(GridIds)}}]};
                        Err ->
                            {ok, [], Info, [{msg, Err}]}
                    end
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.

%%-------------------------------------------------------------------
%% @doc
%%      皇宫探宝的积分商店
%% @end
%%-------------------------------------------------------------------
score_shop(_, _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    ActiveSid = z_lib:get_value(Msg, "active_sid", 0),
    Sid = z_lib:get_value(Msg, "sid", 0),
    Num = z_lib:get_value(Msg, "num", 0),
    CheckValid = valid_lib:check_valib([{'gt', Sid, 0}, {'gt', Num, 0}]),
    if
        CheckValid ->
            case z_db_lib:get(game_lib:get_table(Src, 'active'), active_lib:get_active_key(Src, ActiveSid), none) of
                none ->
                    {ok, [], Info, [{msg, "no_active"}]};
                Active ->
                    {M, [A]} = active:get_ma(Active),
                    case M:score_shop(Src, RoleUid, Sid, Num, Active, A) of
                        {ok, Award} ->
                            AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, Award),
                            zm_log:info(Src, ?MODULE, 'score_shop', "active_score_shop", [{'roleuid', RoleUid}, {'active', Active},
                                {'sid', Sid}, {'num', Num}, {'award', AwardLog}]),
                            zm_event:notify(Src, 'active_seek_precious_shop', [{'role_uid', RoleUid}, {'active', Active},
                                {'sid', Sid}, {'num', Num}, {'award', AwardLog}]),
                            {ok, [], Info, [{msg, AwardLog}]};
                        Err ->
                            {ok, [], Info, [{msg, Err}]}
                    end
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.
%%-------------------------------------------------------------------
%% @doc
%%      皇宫探宝购买寻宝令
%% @end
%%-------------------------------------------------------------------
buy_seek_token(_, _Session, Attr, Info, Msg) ->
    Src = z_lib:get_value(Info, 'src', 'none'),
    RoleUid = role_lib:get_uid(Attr),
    ActiveSid = z_lib:get_value(Msg, "active_sid", 0),
    Num = z_lib:get_value(Msg, "num", 0),
    CheckValid = valid_lib:check_valib([{'gt', Num, 0}]),
    if
        CheckValid ->
            case z_db_lib:get(game_lib:get_table(Src, 'active'), active_lib:get_active_key(Src, ActiveSid), none) of
                none ->
                    {ok, [], Info, [{msg, "no_active"}]};
                Active ->
                    {M, [A]} = active:get_ma(Active),
                    case M:buy_seek_token(Src, RoleUid, Num, A) of
                        {ok, Cs, Award} ->
                            AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, Award),
                            zm_log:info(Src, ?MODULE, 'buy_seek_token', "active_buy_seek_token", [{'roleuid', RoleUid}, {'active', Active}, {'num', Num}, {'consume', Cs}, {'award', AwardLog}]),
                            zm_event:notify(Src, 'active_seek_precious_token', [{'role_uid', RoleUid}, {'active', Active}, {'num', Num}, {'consume', Cs}, {'award', AwardLog}]),
                            {ok, [], Info, [{msg, AwardLog}]};
                        Err ->
                            {ok, [], Info, [{msg, Err}]}
                    end
            end;
        true ->
            {ok, [], Info, [{msg, "input_error"}]}
    end.