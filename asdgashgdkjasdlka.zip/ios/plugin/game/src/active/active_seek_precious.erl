-module(active_seek_precious).

%%%=======================STATEMENT====================
-description("active_seek_precious").
-copyright('youkia,www.youkia.net').
-author("ljh,lvjihong@youkia.net").
-vsn(1).


%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_stop/4, handle_event/4, handle_format/3]).
-export([seek_precious/3, check/3, consume/3, handle_get_extra/4, score_shop/6, init/0, buy_seek_token/4]).
%%%=======================INCLUDE======================

%%%=======================DEFINE======================
-define(MAX_SAVE_AWARD, 50).
-define(ACTIVE_INFO, 1).  %%同步修改gm_active_seek_precious.erl
-define(SEEK_PRECIOUS_INFO, 2).
-define(SHOP_INFO, 3).
-define(SEEK_TOKEN_INFO, 4).  %%购买寻宝令
%%%=======================RECORD=======================
-record(role_seek, {
    awards_record = [] :: list(),%%获得奖励
    score = 0 :: integer(),%%积分
    day_times = 0 :: integer(),%%参与次数
    day = 0 :: integer(),%%最后是哪天参与的
    buy_list = [] :: list(),%%商店已经兑换的记录[{prop,times}..]
    special_grid = [] :: list(),%%活动期间只能获得一次的特殊格子
    count_times = 0 :: integer()%%总参与次数
}).
%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================

%%-------------------------------------------------------------------
%% @doc
%%      基础方法
%% @end
%%-------------------------------------------------------------------
get_awards_record(#role_seek{awards_record = V}) -> V.
get_score(#role_seek{score = V}) -> V.
get_day_times(#role_seek{day_times = V}) -> V.
get_day(#role_seek{day = V}) -> V.
get_buy_list(#role_seek{buy_list = V}) -> V.
get_sepcial_grid(#role_seek{special_grid = V}) -> V.
get_count_times(#role_seek{count_times = V}) -> V.


set_score(RoleSeek, V) -> RoleSeek#role_seek{score = V}.
set_buy_list(RoleSeek, V) -> RoleSeek#role_seek{buy_list = V}.
init() -> #role_seek{day = time_lib:get_date_by_type('day_of_year')}.
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
handle_get(Src, RoleUid, A, Active) ->
    Key = active_lib:get_role_active_key(RoleUid, Active),
    RoleSeek = z_db_lib:get(game_lib:get_table(Src, ?MODULE), Key, init()),
    Format = handle_format(Src, A, Active),
    {Format, {list_to_tuple(get_awards_record(RoleSeek)), get_score(RoleSeek), get_day(RoleSeek), get_day_times(RoleSeek)}}.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
handle_start(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
handle_run(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
handle_close(Src, _A, Active, _Time) ->
    %%进行数据清理，异步处理
    zm_event:notify(Src, active_clear, {?MODULE, Active}),
    'ok'.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
handle_shut(_Src, _A, _Active, _Time) ->
    ok.
%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
handle_stop(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      事件处理
%% @end
%%-------------------------------------------------------------------
handle_event(_Src, _A, _Active, _Event) ->
    ok.
%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
handle_format(Src, [A], Active) ->
    F = fun
        (R, {?ACTIVE_INFO, OneAwardScore, OneConsume, TenConsumes, Times, _TenOnceGrid, _ActiveOnceGrid, _MinTimes, _MinTimesGrid}) ->
            {ok, [{OneAwardScore, list_to_tuple(OneConsume), list_to_tuple(TenConsumes), Times} | R]};
        (R, {?SEEK_PRECIOUS_INFO, Awards, _Weights}) ->
            {ok, [list_to_tuple(Awards) | R]};
        (R, {?SEEK_TOKEN_INFO, BuyProp, _GiftProp, Consume}) ->
            {ok, [{list_to_tuple(BuyProp), list_to_tuple(Consume)} | R]};
        (R, _) ->
            {ok, R}
    end,
    {
        active:format_front(Src, ?MODULE, Active),
        list_to_tuple(z_lib:foreach(F, [], A))
    }.

%%-------------------------------------------------------------------
%% @doc
%%      探宝
%% @end
%%-------------------------------------------------------------------
seek_precious(_, {Src, RoleUid, Times, A, ToDay}, [{Index1, RoleSeek}, {Index2, Rmb}, {Index3, Storage}]) ->
    {_, AwardScore, OneConsume, TenConsume, MaxTimes, TenlimitGrid, ActiveLimitGrid, MinTimes, MinTimesGrid} = lists:keyfind(?ACTIVE_INFO, 1, A),
    NTimes = case get_day(RoleSeek) of
        ToDay ->
            get_day_times(RoleSeek) + Times;
        _ ->
            Times
    end,
    if
        NTimes > MaxTimes ->
            throw("times_limit");
        true ->
            ok
    end,
    Consumes = if
        Times =:= 1 ->
            OneConsume;
        true ->
            TenConsume
    end,
    case game_lib:checks({?MODULE, check}, {Storage, Rmb}, 'seek_precious', Consumes) of
        true ->
            {Consume, {NStorage, NRmb}} = game_lib:consumes({?MODULE, consume}, {Storage, Rmb}, 'seek_precious', Consumes),
            {_, Pool, Weights} = lists:keyfind(?SEEK_PRECIOUS_INFO, 1, A),

            {Awards, AwardRecords, GridIds, NSpecialGrid} = random_prop(Src, RoleUid, time_lib:now_second(), RoleSeek, Pool, Weights, Times, TenlimitGrid, ActiveLimitGrid, MinTimes, MinTimesGrid),
            NAwardRecord1 = AwardRecords ++ get_awards_record(RoleSeek),%%保存的awards里面是{时间，awards}
            NAwardRecord2 = lists:sublist(NAwardRecord1, ?MAX_SAVE_AWARD),
            NScore = AwardScore * Times + get_score(RoleSeek),
            NCountTimes = Times + get_count_times(RoleSeek),
            NRoleSeek = RoleSeek#role_seek{awards_record = NAwardRecord2, score = NScore, day_times = NTimes, day = ToDay, special_grid = NSpecialGrid, count_times = NCountTimes},
            {ok, {ok, Consume, Awards, GridIds}, [{Index1, NRoleSeek}, {Index2, NRmb}, {Index3, NStorage}]};
        Err ->
            throw(Err)
    end.
%% ----------------------------------------------------
%% @doc
%%      获取活动额外信息(商店信息)
%% @end
%% ----------------------------------------------------
handle_get_extra(Src, RoleUid, Active, _Msg) ->
    [A] = active:get_a(Active),
    {_, ShopList} = lists:keyfind(?SHOP_INFO, 1, A),
    RoleSeek = z_db_lib:get(game_lib:get_table(Src, ?MODULE), active_lib:get_role_active_key(RoleUid, Active), init()),
    BuyList = get_buy_list(RoleSeek),
    F = fun({RAwards, RScores, RMaxTimes, RTimes}, {{_, {Sid, _}} = Prop, Score, MaxTimes}) ->
        Times = z_lib:get_value(BuyList, Sid, 0),
        {ok, {[Prop | RAwards], [Score | RScores], [MaxTimes | RMaxTimes], [Times | RTimes]}}
    end,
    {AllAwards, AllScores, AllMaxTimes, AllTimes} = z_lib:foreach(F, {[], [], [], []}, ShopList),
    {list_to_tuple(AllAwards), list_to_tuple(AllScores), list_to_tuple(AllMaxTimes), list_to_tuple(AllTimes)}.

%% ----------------------------------------------------
%% @doc
%%      积分商店购买东西
%% @end
%% ----------------------------------------------------
score_shop(Src, RoleUid, Sid, Num, Active, A) ->
    {_, ShopList} = lists:keyfind(?SHOP_INFO, 1, A),
    Fun1 = fun({ResAward, _, _}, {{prop, {Sid1, Num1}}, Score, MaxTimes}) when Sid1 =:= Sid ->
        {break, {[{prop, {Sid, Num1}} | ResAward], Score, MaxTimes}};
        (R, _) ->
            {ok, R}
    end,
    {Award, ConsumeScore, MaxTimes} = z_lib:foreach(Fun1, {[], 0, 0}, ShopList),
    if
        Award =:= [] ->
            "sid_error";
        true ->
            F = fun(_, RoleSeek) ->
                Bool = check_shop(RoleSeek, Sid, Num, ConsumeScore, MaxTimes),
                if
                    Bool ->
                        NRoleSeek = consume_shop(RoleSeek, Sid, Num, ConsumeScore),
                        {ok, ok, NRoleSeek};
                    true ->
                        throw(Bool)
                end
            end,
            case z_db_lib:update(game_lib:get_table(Src, ?MODULE), active_lib:get_role_active_key(RoleUid, Active), init(), F, []) of
                ok ->
                    {ok, awarder_game:award_multiple(Award, Num)};
                Err ->
                    Err
            end
    end.
%% ----------------------------------------------------
%% @doc
%%      购买寻宝令
%% @end
%% ----------------------------------------------------
buy_seek_token(Src, RoleUid, Num, A) ->
    {_, BuyProp, GiftProp, Consume} = lists:keyfind(?SEEK_TOKEN_INFO, 1, A),
    {Consumes, Awards} = if
        Num > 1 ->
            {awarder_game:award_multiple(Consume, Num), awarder_game:award_multiple(BuyProp ++ GiftProp, Num)};
        true ->
            {Consume, BuyProp ++ GiftProp}
    end,
    Fun1 = fun(_, Rmb) ->
        case game_lib:checks({?MODULE, check}, {{}, Rmb}, 'seek_precious', Consumes) of
            true ->
                {Cs, {_, NRmb}} = game_lib:consumes({?MODULE, consume}, {{}, Rmb}, 'seek_precious', Consumes),
                {ok, {ok, Cs}, NRmb};
            Err ->
                {ok, Err}
        end
    end,
    case z_db_lib:update(game_lib:get_table(Src, 'rmb'), RoleUid, rmb_lib:init(), Fun1, []) of
        {ok, Cs} ->
            {ok, Cs, Awards};
        Err ->
            Err
    end.
%%%===================LOCAL FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%      条件检查
%% @end
%%-------------------------------------------------------------------
check({_Storage, Rmb}, 'seek_precious', {'rmb', Value}) ->
    rmb_lib:get_rmb(Rmb) >= Value;
check({Storage, _Rmb}, 'seek_precious', {'prop', {Sid, Num}}) ->
    storage_lib:exist_by_sid(Storage, {Sid, Num});
check(_, 'seek_precious', _) ->
    false.
%%-------------------------------------------------------------------
%% @doc
%%      消耗
%% @end
%%-------------------------------------------------------------------
consume({Storage, Rmb}, 'seek_precious', {'rmb', Num}) ->
    {Cs, NRmb} = rmb_lib:reduct_rmb(Rmb, Num),
    {Cs, {Storage, NRmb}};
consume({Storage, Rmb}, 'seek_precious', {'prop', {Sid, Num}}) ->
    {Cs, NStorage} = storage_lib:deduct_by_sid(Storage, {Sid, Num}),
    {Cs, {NStorage, Rmb}}.

%%-------------------------------------------------------------------
%% @doc
%%      随机道具
%% @end
%%-------------------------------------------------------------------
random_prop(Src, RoleUid, NowSecond, RoleSeek, AwardPool, Weights, MaxTimes, TenlimitGrid, ActiveLimitGrid, MinTimes, MinTimesGrid) ->
    SpecialGridList = get_sepcial_grid(RoleSeek),
    CountTimes = get_count_times(RoleSeek),
    Fun1 = fun({R, N}, Weight) ->
        {ok, {[Weight, N + 1 | R], N + 1}}
    end,
    {WeightList, _} = z_lib:foreach(Fun1, {[], 0}, Weights),
    Fun2 = fun({R1, R2, R3, CSpecialGridList, MaxTimes1, Times1} = R) ->
        if
            Times1 >= MaxTimes1 ->
                {break, {R1, R2, R3, CSpecialGridList}};
            true ->
                GridId = game_lib:random_value(WeightList),
                case (lists:member(GridId, R3) andalso lists:member(GridId, TenlimitGrid))
                    orelse lists:member(GridId, CSpecialGridList)
                    orelse (lists:member(GridId, MinTimesGrid) andalso CountTimes < MinTimes) of
                    true ->
                        {ok, R};
                    false ->
                        Award = lists:nth(GridId, AwardPool),
                        case lists:member(GridId, ActiveLimitGrid) of
                            true ->
                                case check_special_goods(Src, RoleUid, Award) of
                                    true ->
                                        {ok, {[Award | R1], [{NowSecond, {Award}} | R2], [GridId | R3], [GridId | CSpecialGridList], MaxTimes1, Times1 + 1}};
                                    false ->
                                        {ok, R}
                                end;
                            false ->
                                {ok, {[Award | R1], [{NowSecond, {Award}} | R2], [GridId | R3], CSpecialGridList, MaxTimes1, Times1 + 1}}
                        end
                end
        end
    end,
    z_lib:while(Fun2, {[], [], [], SpecialGridList, MaxTimes, 0}).
%%-------------------------------------------------------------------
%% @doc
%%      检查购买消耗以及次数
%% @end
%%-------------------------------------------------------------------
check_shop(RoleSeek, Sid, Num, ConsumeScore, MaxTimes) ->
    Times = z_lib:get_value(get_buy_list(RoleSeek), Sid, 0),
    Score = get_score(RoleSeek),
    if
        Times + Num =< MaxTimes ->
            if
                ConsumeScore * Num =< Score ->
                    true;
                true ->
                    "score_limit"
            end;
        true ->
            "tiems_limit"
    end.
%%-------------------------------------------------------------------
%% @doc
%%      积分商店购买消耗
%% @end
%%-------------------------------------------------------------------
consume_shop(RoleSeek, Sid, Num, ConsumeScore) ->
    NRoleSeek1 = set_score(RoleSeek, get_score(RoleSeek) - ConsumeScore * Num),
    BuyList = get_buy_list(RoleSeek),
    Times = z_lib:get_value(BuyList, Sid, 0),
    NBuyList = lists:keystore(Sid, 1, get_buy_list(NRoleSeek1), {Sid, Times + Num}),
    set_buy_list(NRoleSeek1, NBuyList).
%%-------------------------------------------------------------------
%% @doc
%%      特殊道具已经拥有就不再抽中，检查皮肤是否已经拥有
%% @end
%%-------------------------------------------------------------------
check_special_goods(Src, RoleUid, {prop, {Sid, _}}) ->
    Prop = prop_kit_lib:create_prop(Src, Sid),
    case prop_kit_lib:get_prop_mod(Prop) of
        'skin_goods' ->
            SkinGoods = prop_kit_lib:get_prop_record(Prop),
            SkinSid = skin_goods:get_use_sid(SkinGoods),
            RoleSkin = skin_db:get_skin(Src, RoleUid),
            AllCastleSkin = skin:get_all_castle_skin(RoleSkin),
            AllChatSkin = skin:get_all_chat_skin(RoleSkin),
            case lists:member(SkinSid, AllChatSkin) orelse lists:member(SkinSid, AllCastleSkin) of
                true ->
                    false;
                false ->
                    not (storage_db:get_count(Src, RoleUid, Sid) > 0)
            end;
        _ ->
            true
    end;
check_special_goods(_, _, _) ->
    true.
