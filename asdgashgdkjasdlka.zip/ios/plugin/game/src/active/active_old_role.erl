%%老玩家回归活动
-module(active_old_role).

%%%=======================STATEMENT====================
-description("active_old_role").
-copyright('youkia,www.youkia.net').
-author("oymh,ouyangminghui@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_event/4, handle_format/3]).
-export([get_day_vip_award/3, handle_event1/3]).
%%%=======================DEFINE=======================

%%%=======================INCLUDE=======================
-include("../include/active.hrl").

%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
-spec handle_get(atom(), integer(), term(), active:active()) -> tuple().
handle_get(Src, _RoleUid, A, Active) ->
    %Key = active_lib:get_role_active_key(RoleUid, Active),
    Format = handle_format(Src, A, Active),
    %RoleInfo = z_db_lib:get(game_lib:get_table(Src, ?MODULE), Key, []),
    {Format, {}}.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
-spec handle_start(atom(), term(), active:active(), integer()) -> 'ok'.
handle_start(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
-spec handle_run(atom(), term(), active:active(), integer()) -> 'ok'.
handle_run(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
-spec handle_close(atom(), term(), active:active(), integer()) -> 'ok'.
handle_close(Src, _A, Active, _Time) ->
    %%清理活动的个人特殊数据
    clear_role_active_info(Src),
    zm_event:notify(Src, active_clear, {?MODULE, Active}),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
-spec handle_shut(atom(), term(), active:active(), integer()) -> 'ok'.
handle_shut(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动事件处理 因为只有在活动是运行状态的时候才能到这一步，所以需要在外部处理 在玩家登陆时候检测如果玩家有活动数据在进入这个步骤
%%      这里只处理没有数据的玩家
%% @end
%%-------------------------------------------------------------------
-spec handle_event(atom(), term(), active:active(), tuple()) -> 'ok'.
handle_event(Src, A, Active, {'login', List}) ->
    {_, Role} = lists:keyfind('role', 1, List),
    RoleUid = role:get_uid(Role),
    RoleLevel = game_lib:get_level(role, Role),
    Key = active_lib:get_role_active_key(RoleUid, Active),

    %%获得活动的奖励信息[{1,[{[1,1],Award},{[2,3],Award}]},{2,[{[1,2],Award}]}]
    %%邮件天数信息[{1,1},{2,2}]
    [{AwardList, OtherInfo}] = A,

    LimitTime = z_lib:get_value(OtherInfo, 'time', 0),%%回归时间限制 秒
    LimitLevel = z_lib:get_value(OtherInfo, 'lv', 0),%%回归等级限制
    NowTime = time_lib:now_second(),
    Today = public_lib:day_of_utc(NowTime),%%当前utc天数
    %%玩家登陆之后检查活动信息，如果么有，检查是否满足条件，如果满足，查看今天是否发送过登陆奖励，
    R = z_db_lib:update(game_lib:get_table(Src, ?MODULE), Key, 'none',
        fun(_, 'none') ->%%玩家没有活动数据
            %%在活动运行阶段,判断玩家是否满足要求 时间和等级同时满足
            LoginOutTime = guser:get_logout_time(user_db:get_user(Src, RoleUid)),%%玩家上一次的登出时间
            if
                NowTime >= LoginOutTime + LimitTime andalso RoleLevel >= LimitLevel ->
                    {ok, {ok, 1}, [{'award_day', [Today]}]};
                true ->
                    {ok, ok}
            end;
            (_, _) ->%%有活动数据，说明有资格,这里不处理
                {ok, ok}
        end, none),
    case R of
        {ok, AwardIndex} ->%%玩家发奖，
            %%记录玩家的个人参与的数据key
            z_db_lib:update(game_lib:get_table(Src, ?MODULE), RoleUid, active:get_sid(Active)),
            send_mail(Src, RoleUid, NowTime, AwardIndex, Role, AwardList),
            ok;
        _ -> ok
    end;
handle_event(_Src, _A, _Active, _Event) ->
    ok.

%%由登陆时候检查进入
handle_event1(Src, Active, Role) ->
    A = active:get_a(Active),
    RoleUid = role:get_uid(Role),
    Key = active_lib:get_role_active_key(RoleUid, Active),

    %%获得活动的奖励信息[{1,[{[1,1],Award},{[2,3],Award}]},{2,[{[1,2],Award}]}]
    %%邮件天数信息[{1,1},{2,2}]
    [{AwardList, _OtherInfo}] = A,

    NowTime = time_lib:now_second(),
    Today = public_lib:day_of_utc(NowTime),%%当前utc天数

    %%玩家登陆之后检查活动信息，如果么有，检查是否满足条件，如果满足，查看今天是否发送过登陆奖励，
    R = z_db_lib:update(game_lib:get_table(Src, ?MODULE), Key, 'none',
        fun(_, 'none') ->%%玩家没有活动数据
            {ok, ok};
            (_, RoleInfo) ->%%有活动数据，说明有资格直接判断是否发奖
                AwardDays = z_lib:get_value(RoleInfo, 'award_day', []),
                GetNum = length(AwardDays),
                AllNum = length(AwardList),
                if
                    GetNum < AllNum -> %%还没有领取完奖励
                        case lists:member(Today, AwardDays) of
                            false ->
                                {ok, {ok, length(AwardDays) + 1}, [{'award_day', [Today | AwardDays]}]};
                            _ ->
                                {ok, ok}
                        end;
                    true ->%%奖励已经领取完毕
                        {ok, ok}
                end
        end, none),
    case R of
        {ok, AwardIndex} ->%%玩家发奖，
            send_mail(Src, RoleUid, NowTime, AwardIndex, Role, AwardList),
            ok;
        _ -> ok
    end.


%%根据领奖天数和vip等级获得对应奖励
%%[{1,[{[1,1],Award},{[2,3],Award}]},{2,[{[1,2],Award}]}]
get_day_vip_award(Index, Role, AwardList) ->
    %%获取对应天数的奖励
    DayAward = z_lib:get_value(AwardList, Index, []),%%[{[1,1],[]},{[2,3],[]}]
    %%根据vip等级获取对应的奖励
    Vip = game_lib:get_level(vip, Role),
    Fun = fun(R, {[V1, V2], Award}) ->
        if
            Vip >= V1 andalso Vip =< V2 ->
                {'break', Award};
            true ->
                {'ok', R}
        end
    end,
    z_lib:foreach(Fun, [], DayAward).
%%对需要发奖的玩家发送邮件
send_mail(Src, RoleUid, NowTime, AwardIndex, Role, AwardList) ->
    case get_day_vip_award(AwardIndex, Role, AwardList) of
        [] -> ok;
        Award ->
            MailType = award_source:get_source(?MODULE),
            AllDay = length(AwardList),%%总共的活动天数
            Mail = mail:init({MailType, NowTime, 0, {49}, {49, AllDay, AwardIndex}, Award}),
            mail_db:send(Src, RoleUid, Mail)
    end.
%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
-spec handle_format(atom(), list(), active:active()) -> tuple().
handle_format(Src, _A, Active) ->
    {
        active:format_front(Src, ?MODULE, Active)
    }.

%%%=====================LOC FUNCTIONS==================
clear_role_active_info(Src) ->
    Table = game_lib:get_table(Src, ?MODULE),
    F = fun(_Src1, Key, _Args, _) when is_integer(Key) ->
        z_db_lib:delete(Table, Key);
        (_Src1, _, _Args, _) ->
            ok
    end,
    z_db_lib:table_iterate(Src, Table, F, [], []).

