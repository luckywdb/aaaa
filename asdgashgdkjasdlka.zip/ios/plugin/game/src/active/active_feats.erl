%%限时功勋排行活动
-module(active_feats).

%%%=======================STATEMENT====================
-description("active_feats").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_event/4, handle_format/3]).
-export([rank_view/4]).
%%%=======================DEFINE=======================

%%%=======================INCLUDE=======================
-include("../include/active.hrl").
-include("../include/rank.hrl").
%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
-spec handle_get(atom(), integer(), term(), active:active()) -> tuple().
handle_get(Src, RoleUid, A, Active) ->
    Key = active_lib:get_role_active_key(RoleUid, Active),
    Format = handle_format(Src, A, Active),
    {Score, _} = z_db_lib:get(game_lib:get_table(Src, ?MODULE), Key, {0, []}),
    {Format, {Score}}.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
-spec handle_start(atom(), term(), active:active(), integer()) -> 'ok'.
handle_start(Src, _A, Active, _Time) ->
    start(Src, Active),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
-spec handle_run(atom(), term(), active:active(), integer()) -> 'ok'.
handle_run(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
-spec handle_close(atom(), term(), active:active(), integer()) -> 'ok'.
handle_close(Src, _A, Active, _Time) ->
    stop(Src, Active),
    zm_event:notify(Src, active_clear, {?MODULE, Active}),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
-spec handle_shut(atom(), term(), active:active(), integer()) -> 'ok'.
handle_shut(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动事件处理
%% @end
%%-------------------------------------------------------------------
-spec handle_event(atom(), term(), active:active(), tuple()) -> 'ok'.
handle_event(Src, _A, Active, {'active_add_feats', List}) ->
    {_, RoleUid} = lists:keyfind('role_uid', 1, List),
    {_, AddFeats} = lists:keyfind('add_feats', 1, List),
    NScore = add_score(Src, RoleUid, Active, AddFeats),
    target_award(Src, RoleUid, Active, NScore),
    Sid = active:get_sid(Active),
    %%增加积分后,排行榜刷新
    zm_event:notify(Src, 'active_rank', [{'sid', Sid}, {'uid', RoleUid}, {'value', NScore}, {'m', active:get_m(Active)}]),
    ok;
handle_event(_Src, _A, _Active, _Event) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
-spec handle_format(atom(), list(), active:active()) -> tuple().
handle_format(Src, A, Active) ->
    {RankAwardList, TargetList} =
        case A of%%匹配老数据结构
            [{AwardList1, TargetList1}] ->
                {AwardList1, TargetList1};
            [{AwardList1, TargetList1, _}] ->
                {AwardList1, TargetList1}
        end,
    %[{RankAwardList, TargetList, _}] = A,
    Fun1 = fun({Min, Max, AwardList}) -> {Min, Max, list_to_tuple(AwardList)} end,
    Fun2 = fun({Index, Target, AwardList}) -> {Index, Target, list_to_tuple(AwardList)} end,
    {
        active:format_front(Src, ?MODULE, Active),
        {list_to_tuple(lists:map(Fun1, RankAwardList)), list_to_tuple(lists:map(Fun2, TargetList))}
    }.


%%-------------------------------------------------------------------
%% @doc
%%      排行榜玩家显示数据
%% @end
%%-------------------------------------------------------------------
-spec rank_view(term(), atom(), integer(), integer()) -> tuple().
rank_view(_A, Src, RoleUid, Value) ->
    RoleShow = role_db:get_role_show(Src, RoleUid),
    {RoleUid, role_show:get_name(RoleShow), role_show:get_corps_uid(RoleShow), role_show:get_corps_name(RoleShow), Value, role_show:get_country(RoleShow)}.

%%-------------------------------------------------------------------
%% @doc
%%      增加积分
%% @end
%%-------------------------------------------------------------------
-spec add_score(atom(), integer(), active:active(), integer()) -> integer().
add_score(Src, RoleUid, Active, AddFeats) ->
    AddScore = AddFeats,
    Key = active_lib:get_role_active_key(RoleUid, Active),
    F = fun(_, {OldScore, List}) ->
        NewScore = OldScore + AddScore,
        {ok, NewScore, {NewScore, List}}
    end,
    z_db_lib:update(game_lib:get_table(Src, ?MODULE), Key, {0, []}, F, []).

%%%=====================LOC FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%
%% @end
%%-------------------------------------------------------------------
start(Src, Active) ->
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'sid_template', template_lib:get_key(Src, 'other_rank'), []}
    ]),
    z_db_lib:handle(TableName, fun start_/2, {Src, Active}, TableKeys).

%%-------------------------------------------------------------------
%% @doc
%%      新增排行榜类型
%% @end
%%-------------------------------------------------------------------
start_({_Src, Active}, [{Index1, RankTypeList}]) ->
    Sid = active:get_sid(Active),
    {ok, ok, [{Index1, lists:keystore(Sid, 1, RankTypeList, {Sid, ?MODULE})}]}.
%%-------------------------------------------------------------------
%% @doc
%%      活动结束扩展信息清理
%% @end
%%-------------------------------------------------------------------
stop(Src, Active) ->
    Sid = active:get_sid(Active),
    %%发放积分排行榜奖励
    {RankAwardList, _TargetList} =
        case active:get_a(Active) of%%匹配老数据结构
            [{AwardList1, TargetList1}] ->
                {AwardList1, TargetList1};
            [{AwardList1, TargetList1, _}] ->
                {AwardList1, TargetList1}
        end,
    %[{RankAwardList, _TargetList, _}] = active:get_a(Active),
    rank_award(Src, Active, RankAwardList),
    rank_db:clear_ranks(Src, Sid).

%%-------------------------------------------------------------------
%% @doc
%%      发放排行榜奖励
%% @end
%%-------------------------------------------------------------------
-spec rank_award(atom(), active:active(), [{integer(), integer(), list()}]) -> term().
rank_award(Src, Active, AwardList) ->
    Key = game_lib:get_server_key(Src, active),
    Sid = active:get_sid(Active),
    Term = active:get_term(Active),
    case active_db:update_award_flag(Src, Sid, Term, Key) of
        false ->
            %%刷新一次排行榜
            rank_refresh:timer_refresh(Src, [[Sid]], []),
            AllRank = get_max_rank(AwardList),
            %%TODO 分多次取
            RankActions = rank_get:get_rank_range(Src, Sid, 1, AllRank),
            RanksSize = erlang:length(RankActions),
            ActiveName = active:get_name(Active),
            [send_mail(Src, Award, RankActions, RanksSize, MinRank, MaxRank, ActiveName) || {MinRank, MaxRank, Award} <- AwardList];
        true ->
            'ignore'
    end.


%%-------------------------------------------------------------------
%% @doc
%%      目标奖励
%% @end
%%-------------------------------------------------------------------
-spec target_award(atom(), integer(), active:active(), integer()) -> term().
target_award(Src, RoleUid, Active, NScore) ->
    {_AwardList, TargetList} =
        case active:get_a(Active) of%%匹配老数据结构
            [{AwardList1, TargetList1}] ->
                {AwardList1, TargetList1};
            [{AwardList1, TargetList1, _}] ->
                {AwardList1, TargetList1}
        end,
    %[{_, TargetList, _}] = active:get_a(Active),
    Key = active_lib:get_role_active_key(RoleUid, Active),
    {IndexList, ItemList} = lists:foldl(fun({Index, T, Award}, {Acc0, Acc1}) ->
        case T =< NScore of
            true ->
                {[Index | Acc0], [{Index, T, Award} | Acc1]};
            _ ->
                {Acc0, Acc1}
        end
    end, {[], []}, TargetList),
    Fun = fun(_, {OScore, AwardList}) ->
        case IndexList -- AwardList of
            [] ->
                {ok, ok};
            NList ->
                {ok, {ok, NList}, {OScore, lists:usort(NList ++ AwardList)}}
        end
    end,
    case z_db_lib:update(game_lib:get_table(Src, ?MODULE), Key, {NScore, []}, Fun, []) of
        {ok, IList} ->
            ActiveName = active:get_name(Active),
            MailType = award_source:get_source(?MODULE),
            lists:foreach(fun({Index, Score, Award}) ->
                case lists:member(Index, IList) of
                    true ->
                        Mail = mail:init({MailType, time_lib:now_second(), 0, {8, ActiveName}, {8, ActiveName, Score}, Award}),
                        mail_db:send(Src, RoleUid, Mail);
                    false ->
                        ok
                end
            end, ItemList),
            set_front_lib:send_active_score_award(Src, RoleUid, {active:get_sid(Active), NScore});
        _ ->
            set_front_lib:send_active_score_award(Src, RoleUid, {active:get_sid(Active), NScore})
    end.


%%-------------------------------------------------------------------
%% @doc
%%      发放邮件
%% @end
%%-------------------------------------------------------------------
send_mail(_Src, _Award, _Ranks, RanksSize, MinRank, _MaxRank, _ActiveName) when RanksSize < MinRank ->
    'ignore';
send_mail(Src, Award, Ranks, RanksSize, MinRank, MaxRank, ActiveName) ->
    AllRank = if
        RanksSize > MaxRank ->
            MaxRank - MinRank + 1;
        true ->
            RanksSize - MinRank + 1
    end,
    MailType = award_source:get_source(?MODULE),
    lists:foldl(fun(Info, Rank) ->
        {RoleUid, _Feats} = Info,
        Mail = mail:init({MailType, time_lib:now_second(), 0, {7, ActiveName}, {7, ActiveName, Rank}, Award}),
        mail_db:send(Src, RoleUid, Mail),
        Rank + 1
    end, MinRank, lists:sublist(Ranks, MinRank, AllRank)).


%%-------------------------------------------------------------------
%% @doc
%%      获取配置的最大名次
%% @end
%%-------------------------------------------------------------------
-spec get_max_rank(list()) -> integer().
get_max_rank(ConfigList) ->
    lists:max([Max || {_, Max, _} <- ConfigList]).