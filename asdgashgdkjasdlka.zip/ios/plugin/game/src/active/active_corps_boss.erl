-module(active_corps_boss).

%%%=======================STATEMENT====================
-description("active_corps_boss").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_event/4, handle_format/3,
    get_born_info/4, handle_update/2, handle_get_extra/4, reborn/4, rank_view/4, delete_corps_rank/2]).

%%%=======================INCLUDE======================
-include("../include/active.hrl").
-include("../include/rank.hrl").

%%%=======================DEFINE======================

%%%=======================RECORD=======================

%%%=======================TYPE=========================
%%-type my_type() :: atom() | integer().


%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
-spec handle_get(atom(), integer(), term(), active:active()) -> tuple().
handle_get(Src, _RoleUid, A, Active) ->
    Format = handle_format(Src, A, Active),
    {Format, {}}.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
-spec handle_start(atom(), term(), active:active(), integer()) -> 'ok'.
handle_start(Src, _A, Active, _Time) ->
    Sid = active:get_sid(Active),
    Fun = fun(_, 'none') ->
        {'ok', Active};
        (_, ActiveDb) ->
            M = active:get_m(ActiveDb),
            NewA = active:get_a(zm_config:get('active', Sid)),
            NAct = active:set_ma(ActiveDb, {M, NewA}),
            {'ok', NAct, NAct}
    end,
    NActive = z_db_lib:update(game_lib:get_table(Src, 'active'), active_lib:get_active_key(Src, Sid), 'none', Fun, []),
    start(Src, NActive),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
-spec handle_run(atom(), term(), active:active(), integer()) -> 'ok'.
handle_run(Src, _A, Active, _Time) ->
    Now = time_lib:now_second(),
    Fun = fun(_, List) ->
        {BornList, NList} = lists:partition(fun({_Muid, BTime}) -> BTime =< Now end, List),
        {ok, BornList, NList}
    end,
    BornLists = z_db_lib:update(game_lib:get_table(Src, ?MODULE), get_dead_key(Active), [], Fun, []),
    if
        BornLists =:= [] ->
            ok;
        true ->
            zm_event:notify(Src, 'corps_boss_reborn', [{'active', Active}, {'born_list', BornLists}])
    end.


%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
-spec handle_close(atom(), term(), active:active(), integer()) -> 'ok'.
handle_close(Src, _A, Active, _Time) ->
    stop(Src, Active),
    zm_event:notify(Src, active_clear, {?MODULE, Active}),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
-spec handle_shut(atom(), term(), active:active(), integer()) -> 'ok'.
handle_shut(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      事件处理
%% @end
%%-------------------------------------------------------------------
handle_event(Src, _A, Active, {'active_corps_boss_score', Args}) ->
    {_, Sid} = lists:keyfind('active_sid', 1, Args),
    case active:get_sid(Active) =:= Sid of
        true ->
            %处理积分等
            {_, Score} = lists:keyfind('score', 1, Args),
            {_, AddListTmp} = lists:keyfind('add_rank', 1, Args),%多波怪物,一个玩家多个数据
            AddList = game_lib:merge_kv(AddListTmp, []),
            Table = game_lib:get_table(Src, 'role_show'),
            RTable = game_lib:get_table(Src, ?MODULE),
            RankTable = game_lib:get_table(Src, 'boss_data'),
            {_, RankSize} = zm_config:get('active_boss', 'boss_rank_size'),
            {_, MonsterUid} = lists:keyfind('monster_uid', 1, Args),
            CorpsAdd =
                z_lib:foreach(fun(Acc, {RoleUid, Num}) ->
                    %增加个人boss排行榜
                    add_role_muid_num(RTable, RankTable, RoleUid, Active, MonsterUid, Num, RankSize),
                    %增加军团积分
                    CorpsUid = role_show:get_corps_uid(z_db_lib:get(Table, RoleUid)),
                    if CorpsUid > 0 ->
                        AddNUm = Num * Score div 10000,
                        if
                            AddNUm > 0 ->
                                {ok, game_lib:merge_kv([{CorpsUid, AddNUm}], Acc)};
                            true ->
                                {ok, Acc}
                        end;
                        true ->
                            {ok, Acc}
                    end
                end, [], AddList),
            if
                CorpsAdd =/= [] ->
                    F = fun(_, List) ->
                        NList = game_lib:merge_kv(CorpsAdd, List),
                        {ok, NList, NList}
                    end,
                    Changes = z_db_lib:update(game_lib:get_table(Src, ?MODULE), get_corpsrank_key(Active), [], F, []),
                    lists:foreach(fun({Uid, V}) ->
                        zm_event:notify(Src, 'active_rank', [{'sid', Sid}, {'uid', Uid}, {'value', z_lib:get_value(Changes, Uid, V)}, {'m', active:get_m(Active)}])
                    end, CorpsAdd);
                true ->
                    ok
            end,
            {_, Dead} = lists:keyfind('dead', 1, Args),
            if
                Dead ->
                    {_, MonsterUid} = lists:keyfind('monster_uid', 1, Args),
                    {_, MonsterDetail} = lists:keyfind('monster_deail', 1, Args),
                    BossData = z_db_lib:delete1(game_lib:get_table(Src, 'boss_data'), MonsterUid, boss_data:init()),
                    Mlv = monster_detail:get_level(MonsterDetail),
                    Mname = monster_detail:get_name(MonsterDetail),
                    {_, AwardList} = zm_config:get('active_boss', {'boss_kill_rank', Mlv}),
                    boss_dead_rank_award(Src, Active, MonsterUid, boss_data:get_rank(BossData), AwardList, Mname, Mlv),
                    del_mpuids(Src, MonsterUid, Active),
                    add_reborn(Src, MonsterUid, MonsterDetail, Active);
                true ->
                    ok
            end;
        false ->
            'ok'
    end;
handle_event(_Src, _A, _Active, _Event) ->
    ok.
%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
-spec handle_format(atom(), list(), active:active()) -> tuple().
handle_format(Src, _A, Active) ->
    {
        active:format_front(Src, ?MODULE, Active)
    }.

%% ----------------------------------------------------
%% @doc
%%  更新活动
%% @end
%% ----------------------------------------------------
handle_update(_Src, _Active) ->
    ok.

%% ----------------------------------------------------
%% @doc
%%  获取活动额外信息(type=0南蛮入侵显示信息,type=1 boss信息查看)
%% @end
%% ----------------------------------------------------
handle_get_extra(Src, _RoleUid, Active, Msg) ->
    Type = z_lib:get_value(Msg, "type", 0),
    if
        Type =:= 0 ->
            ActiveTable = game_lib:get_table(Src, ?MODULE),
            BornLists = z_db_lib:get(ActiveTable, get_dead_key(Active), []),
            BornInfo = list_to_tuple([{MId, BornTime + 20} || {MId, BornTime} <- BornLists]),
            {_, MonstList} = z_db_lib:get(ActiveTable, get_sid_key(Active), {[], []}),
            Table = game_lib:get_table(Src, 'boss_data'),
            BossInit = boss_data:init(),
            Viewinfo = list_to_tuple(z_lib:foreach(fun(A, {MonsterUid, PointUid}) ->
                MSid = monster_db:muid_2_msid(MonsterUid),
                MaxLen = monster_detail:get_num(monster_detail:get_cfg(MSid)),
                BossData = z_db_lib:get(Table, MonsterUid, BossInit),
                {Len, _} = boss_data:get_npc_state(BossData),
                RestLen = (MaxLen + 1 - Len),
                if
                    RestLen > 0 ->
                        [{MonsterUid, PointUid, (MaxLen + 1 - Len), MaxLen} | A];
                    true ->
                        A
                end
            end, [], MonstList)),
            {Viewinfo, BornInfo};
        true ->
            MonsterUid = list_to_integer(z_lib:get_value(Msg, "monster_uid", "0")),
            get_active_boss_rank(Src, active:get_sid(Active), MonsterUid)
    end.

%% ----------------------------------------------------
%% @doc
%%   获取活动怪物排行榜信息
%% @end
%% ----------------------------------------------------
get_active_boss_rank(Src, _ActiveSid, MonsterUid) ->
    MSid = monster_db:muid_2_msid(MonsterUid),
    MonsterDetail = monster_detail:get_cfg(MSid),
    BossData = z_db_lib:get(game_lib:get_table(Src, 'boss_data'), MonsterUid, boss_data:init()),
    {Len, _Hp} = Lhp = boss_data:get_npc_state(BossData),
    NpcArray = monster_detail:get_npc(MonsterDetail),
    MaxLen = monster_detail:get_num(MonsterDetail),
    Table = game_lib:get_table(Src, 'role_show'),
    {CurSoliders, MaxSoldiers} = boss_fight:get_cur_soldiers(NpcArray, Lhp),
    {(MaxLen + 1 - Len), MaxLen, CurSoliders, MaxSoldiers, list_to_tuple([get_role_rank_view(Src, Table, RoleUid, V) || {RoleUid, V} <- boss_data:get_rank(BossData)])}.

%% ----------------------------------------------------
%% @doc
%%    boss排行榜信息\
%% @end
%% ----------------------------------------------------
get_role_rank_view(_Src, Table, RoleUid, V) ->
    RoleShow = z_db_lib:get(Table, RoleUid),
    {RoleUid, role_show:get_name(RoleShow), role_show:get_corps_name(RoleShow), role_show:get_country(RoleShow), V}.

%%-------------------------------------------------------------------
%% @doc
%%      军团排行榜显示数据
%% @end
%%-------------------------------------------------------------------
-spec rank_view(term(), atom(), integer(), integer()) -> tuple().
rank_view(_A, Src, CorpsUid, Value) ->
    Corps = corps_db:get_corps(Src, CorpsUid),
    {CorpsUid, corps:get_name(Corps), corps:get_country(Corps), corps:get_banner(Corps), corps:get_level(Corps), Value}.

%%-------------------------------------------------------------------
%% @doc
%%      军团解散 删除
%% @end
%%-------------------------------------------------------------------
-spec delete_corps_rank(atom(), integer()) -> term().
delete_corps_rank(Src, CorpsUid) ->
    %%TODO 后续军团统一方法
    ActiveStateList = active_db:get_active_state_list(Src),
    lists:foreach(fun({Key, State}) ->
        case State =:= ?RUN of
            true ->
                Active = active_db:get_active(Src, Key),
                case Active =/= 'none' andalso active:get_m(Active) =:= ?MODULE of
                    true ->
                        {_, _, Sid} = Key,
                        zm_event:notify(Src, 'active_rank_delete', [{'sid', Sid}, {'uid', CorpsUid}]);
                    false ->
                        ok
                end;
            false ->
                ok
        end
    end, ActiveStateList).

%%%=====================LOC FUNCTIONS==================
start(Src, Active) ->
    Sid = active:get_sid(Active),
    [{CityList, CityMaxNum, BossSidNums}] = active:get_a(Active),
    {_, BornInfo, CityNums} = get_born_info([], CityList, CityMaxNum, BossSidNums),
    AddMPuids =
        case catch monster_db:refresh_monster(Src, BornInfo, {'active', Sid}, 0, 0) of
            {"reinit_monster_error", Monsters} ->
                zm_log:warn(?MODULE, ?MODULE, 'init_boss_error', "init_error", [{'point_uids', Monsters}]),
                Monsters;
            MonsterPuids ->
                MonsterPuids
        end,
    init_active_data(Src, Active, AddMPuids, CityNums),
    % 新增排行榜类型(军团积分,每个boss的uid)
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'sid_template', template_lib:get_key(Src, 'other_rank'), []}
    ]),
    z_db_lib:handle(TableName, fun start_/2, {Src, Active}, TableKeys).

%%-------------------------------------------------------------------
%% @doc
%%      新增排行榜类型
%% @end
%%-------------------------------------------------------------------
start_({_Src, Active}, [{Index1, RankTypeList}]) ->
    Sid = active:get_sid(Active),
    {ok, ok, [{Index1, lists:keystore(Sid, 1, RankTypeList, {Sid, ?MODULE})}]}.

%%-------------------------------------------------------------------
%% @doc
%%      活动结束扩展信息清理
%% @end
%%-------------------------------------------------------------------
stop(Src, Active) ->
    Sid = active:get_sid(Active),
    %%发放积分排行榜奖励
    {_, AwardList} = zm_config:get('active_boss', 'corps_rank'),
    rank_award(Src, Active, AwardList),
    rank_db:clear_ranks(Src, Sid),
    kill_boss(Src, Active).

%%-------------------------------------------------------------------
%% @doc
%%      发放排行榜奖励
%% @end
%%-------------------------------------------------------------------
-spec rank_award(atom(), active:active(), [{integer(), integer(), list()}]) -> term().
rank_award(Src, Active, AwardList) ->
    Key = game_lib:get_server_key(Src, active),
    Sid = active:get_sid(Active),
    Term = active:get_term(Active),
    case active_db:update_award_flag(Src, Sid, Term, Key) of
        false ->
            %%刷新一次排行榜
            rank_refresh:timer_refresh(Src, [[Sid]], []),
            AllRank = get_max_rank(AwardList),
            %%TODO 分多次取
            RankActions = rank_get:get_rank_range(Src, Sid, 1, AllRank),
            RanksSize = erlang:length(RankActions),
            ActiveName = active:get_name(Active),
            [send_corps_mail(Src, Award, RankActions, RanksSize, MinRank, MaxRank, ActiveName) || {MinRank, MaxRank, Award} <- AwardList],
            zm_log:info(Src, ?MODULE, ?MODULE, "corps_rank_award", [{'rank', RanksSize}]);
        true ->
            'ignore'
    end.

%%-------------------------------------------------------------------
%% @doc
%%      发放boss排行榜奖励
%% @end
%%-------------------------------------------------------------------
boss_dead_rank_award(Src, Active, MonsterUid, RankList, AwardList, MName, MLv) ->
    Table = game_lib:get_table(Src, ?MODULE),
    Fun = fun(_, {RoleUid, _, _} = Key, _, R) when is_integer(RoleUid) ->
        F = fun(_, Data) ->
            {ok, ok, lists:keydelete(MonsterUid, 1, Data)}
        end,
        z_db_lib:update(Table, Key, [], F, []),
        {ok, R};
        (_, _, _, R) ->
            {ok, R}
    end,
    z_db_lib:table_iterate(Src, Table, Fun, [], []),
    ActiveName = active:get_name(Active),
    [send_mail(Src, Award, RankList, length(RankList), MinRank, MaxRank, ActiveName, MName, MLv) || {MinRank, MaxRank, Award} <- AwardList].

%%-------------------------------------------------------------------
%% @doc
%%      发放邮件(个人排名)
%% @end
%%-------------------------------------------------------------------
send_mail(_Src, _Award, _Ranks, RanksSize, MinRank, _MaxRank, _ActiveName, _MonsterName, _MonsterLv) when RanksSize < MinRank ->
    'ignore';
send_mail(Src, Award, Ranks, RanksSize, MinRank, MaxRank, ActiveName, MonsterName, MonsterLv) ->
    AllRank = if
        RanksSize > MaxRank ->
            MaxRank - MinRank + 1;
        true ->
            RanksSize - MinRank + 1
    end,
    MailType = award_source:get_source(?MODULE),
    AwardList =
        if
            is_integer(Award) ->
                awarder_game:get_award_list(Award);
            true ->
                Award
        end,
    lists:foldl(fun({RoleUid, V}, Rank) ->
        Mail = mail:init({MailType, time_lib:now_second(), 0, {19, ActiveName}, {19, MonsterName, MonsterLv, lists:flatten(io_lib:format("~.4f", [V / 10000])), Rank}, AwardList}),
        mail_db:send(Src, RoleUid, Mail),
        Rank + 1
    end, MinRank, lists:sublist(Ranks, MinRank, AllRank)).

%%-------------------------------------------------------------------
%% @doc
%%      发放邮件(军团排名)
%% @end
%%-------------------------------------------------------------------
send_corps_mail(_Src, _Award, _Ranks, RanksSize, MinRank, _MaxRank, _ActiveName) when RanksSize < MinRank ->
    'ignore';
send_corps_mail(Src, Award, Ranks, RanksSize, MinRank, MaxRank, ActiveName) ->
    AllRank = if
        RanksSize > MaxRank ->
            MaxRank - MinRank + 1;
        true ->
            RanksSize - MinRank + 1
    end,
    MailType = award_source:get_source(?MODULE),
    AwardList =
        if
            is_integer(Award) ->
                awarder_game:get_award_list(Award);
            true ->
                Award
        end,
    lists:foldl(fun(Info, Rank) ->
        {CorpsUid, V} = Info,
        Mail = mail:init({MailType, time_lib:now_second(), 0, {20, ActiveName}, {20, lists:flatten(io_lib:format("~.4f", [V / 10000])), Rank}, AwardList}),
        lists:foreach(fun(RoleUid) ->
            mail_db:send(Src, RoleUid, Mail)
        end, corps_db:get_corps_members(Src, CorpsUid)),
        Rank + 1
    end, MinRank, lists:sublist(Ranks, MinRank, AllRank)).

%%%===================LOCAL FUNCTIONS==================
%% ----------------------------------------------------
%% @doc
%%  刷新土匪后,初始化db数据
%% @end
%% ----------------------------------------------------
init_active_data(Src, Active, AddMPuids, CityNums) ->
    Fun = fun(_, {OCNumList, OCMPuids}) ->
        NMonsterPuids =
            z_lib:foreach(fun(A, {_, {MUid, PUids}}) ->
                {MUPList, _} =
                    z_lib:foreach(fun({B, Num}, Puid) ->
                        {ok, {[{MUid + Num, Puid} | B], Num + 1}}
                    end, {A, 0}, PUids),
                {ok, MUPList}
            end, [], AddMPuids),
        {ok, ok, {game_lib:merge_kv(CityNums, OCNumList), NMonsterPuids ++ OCMPuids}}
    end,
    %{当前郡刷新数量,具体[{monster_sid,{monster_uid,[point_uids]}}]
    z_db_lib:update(game_lib:get_table(Src, ?MODULE), get_sid_key(Active), {[], []}, Fun, []).

%% ----------------------------------------------------
%% @doc  
%%  根据配置信息,获取怪物刷新列表
%% @end
%% ----------------------------------------------------
get_born_info(CurCityList, CityList, CityMaxNum, MSidNums) ->
    CityCanList = z_lib:foreach(fun(Acc, City) ->
        case lists:keyfind(City, 1, CurCityList) of
            false ->
                {ok, [{City, CityMaxNum} | Acc]};
            {_, V} ->
                if
                    V >= CityMaxNum ->
                        {ok, Acc};
                    true ->
                        {ok, [{City, CityMaxNum - V} | Acc]}
                end
        end
    end, [], CityList),
    z_lib:foreach(fun({CCList, BornList, CityAddList}, {MSid, MNum}) ->
        F = fun({Acc1, Acc2, Acc3}, _) ->
            case game_lib:random_list(Acc1, 1) of
                [] ->
                    {break, {Acc1, Acc2, Acc3}};
                [{C, N}] ->
                    NAcc2 = case lists:keyfind(C, 1, Acc2) of
                        false ->
                            [{C, [{MSid, 1}]} | Acc2];
                        {_, List} ->
                            lists:keyreplace(C, 1, Acc2, {C, game_lib:merge_kv([{MSid, 1}], List)})
                    end,
                    if
                        N =:= 1 ->
                            {ok, {lists:keydelete(C, 1, Acc1), NAcc2, game_lib:merge_kv([{C, 1}], Acc3)}};
                        true ->
                            {ok, {lists:keyreplace(C, 1, Acc1, {C, N - 1}), NAcc2, game_lib:merge_kv([{C, 1}], Acc3)}}
                    end
            end
        end,
        {ok, z_lib:for(F, {CCList, BornList, CityAddList}, 0, MNum)}
    end, {CityCanList, [], []}, MSidNums).


%% ----------------------------------------------------
%% @doc
%%  玩家攻击增加数量,排行榜信息
%% @end
%% ----------------------------------------------------
add_role_muid_num(RTable, RankTable, RoleUid, Active, MonsterUid, Num, Size) ->
    AddFun = fun(_, RoleMonList) ->
        NList = game_lib:merge_kv([{MonsterUid, Num}], RoleMonList),
        {ok, z_lib:get_value(NList, MonsterUid, Num), NList}
    end,
    AllNum = z_db_lib:update(RTable, active_lib:get_role_active_key(RoleUid, Active), [], AddFun, []),
    Fun = fun(_, BossData) ->
        Ranks = lists:keydelete(RoleUid, 1, boss_data:get_rank(BossData)),
        {_, NRanks} = rank_lib:limit_size_insert(Ranks, rank_lib:sort_fun([], active:get_sid(Active)), Size, {RoleUid, AllNum}, length(Ranks)),
        {ok, ok, boss_data:set_rank(BossData, NRanks)}
    end,
    z_db_lib:update(RankTable, MonsterUid, boss_data:init(), Fun, []).

%%-------------------------------------------------------------------
%% @doc
%%      获取配置的最大名次
%% @end
%%-------------------------------------------------------------------
-spec get_max_rank(list()) -> integer().
get_max_rank(ConfigList) ->
    lists:max([Max || {_, Max, _} <- ConfigList]).

%% ----------------------------------------------------
%% @doc
%%  加入复活队列
%% @end
%% ----------------------------------------------------
add_reborn(Src, MonsterUid, MonsterDetail, Active) ->
    case active_db:get_active_time(Src, Active) of
        none ->
            ok;
        ActiveTime ->
            Now = time_lib:now_second(),
            Cd = monster_detail:get_cd(MonsterDetail),
            case active_time:get_start_time(ActiveTime) + active_time:get_run_time(ActiveTime) > Cd + Now of
                true ->
                    Fun = fun(_, List) ->
                        {ok, ok, [{MonsterUid, Now + Cd} | List]}
                    end,
                    z_db_lib:update(game_lib:get_table(Src, ?MODULE), get_dead_key(Active), [], Fun, []);
                false ->
                    ok
            end
    end.

%% ----------------------------------------------------
%% @doc
%%   复活土匪
%% @end
%% ----------------------------------------------------
reborn(_, Src, 'corps_boss_reborn', Args) ->
    {_, Active} = lists:keyfind('active', 1, Args),
    {_, BornList} = lists:keyfind('born_list', 1, Args),
    Sid = active:get_sid(Active),
    case z_db_lib:get(game_lib:get_table(Src, 'active'), active_lib:get_active_key(Src, Sid), none) of
        none ->%活动结束,不存在的情况,不刷新
            ok;
        _ ->
            [{CityList, CityMaxNum, _BossSidNums}] = active:get_a(Active),
            Table = game_lib:get_table(Src, ?MODULE),
            {CurList, _} = z_db_lib:get(Table, get_sid_key(Active), {[], []}),
            BornMSids = game_lib:merge_kv([{monster_db:muid_2_msid(Muid), 1} || {Muid, _} <- BornList], []),
            {_, BornInfo, CityNums} = get_born_info(CurList, CityList, CityMaxNum, BornMSids),
            AddMPuids =
                case catch monster_db:refresh_monster(Src, BornInfo, {'active', Sid}, 0, 0) of
                    {"reinit_monster_error", Monsters} ->
                        zm_log:warn(?MODULE, ?MODULE, 'reborn_boss_error', "reborn_error", [{'point_uids', Monsters}, {'msids', BornMSids}]),
                        Monsters;
                    MonsterPuids ->
                        MonsterPuids
                end,
            init_active_data(Src, Active, AddMPuids, CityNums)
    end.

%% ----------------------------------------------------
%% @doc
%%  活动结束杀死所有的boss
%% @end
%% ----------------------------------------------------
kill_boss(Src, Active) ->
    {_, Puids} = z_db_lib:get(game_lib:get_table(Src, ?MODULE), get_sid_key(Active), {[], []}),
    lists:foreach(fun({MUid, PUid}) ->
        MonsterDetail = monster_detail:get_cfg(monster_db:muid_2_msid(MUid)),
        monster_db:monster_dead(Src, MUid, PUid, MonsterDetail, active:get_sid(Active)),
        z_db_lib:delete(game_lib:get_table(Src, 'boss_data'), MUid)
    end, Puids).

%% ----------------------------------------------------
%% @doc
%%  boss死亡后,从存活列表清除
%% @end
%% ----------------------------------------------------
del_mpuids(Src, MonsterUid, Active) ->
    BSid = monster_db:muid_2_bsid(MonsterUid),
    Fun = fun(_, {CityNums, List}) ->
        NCityNums = game_lib:merge_kv([{BSid, -1}], CityNums),
        {ok, ok, {NCityNums, lists:keydelete(MonsterUid, 1, List)}}
    end,
    z_db_lib:update(game_lib:get_table(Src, ?MODULE), get_sid_key(Active), {[], []}, Fun, []).

%% ----------------------------------------------------
%% @doc
%%    获取各key
%% @end
%% ----------------------------------------------------
get_sid_key(Active) ->%存储活动基础信息{[各郡怪物数量],[怪物uid以及对应坐标]}
    active_lib:get_active_mod_key(sid, Active).
get_dead_key(Active) ->%死亡存储(boss复活列表)
    active_lib:get_active_mod_key('boss_dead', Active).
get_corpsrank_key(Active) ->%军团积分排行榜使用存储的各军团数值
    active_lib:get_active_mod_key('corps_rank', Active).