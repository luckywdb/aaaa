-module(active_castle_rank).

%%%=======================STATEMENT====================
-description("active_castle_rank").
-copyright('youkia,www.youkia.net').
-author("lqq,liqiqiang@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_event/4, handle_format/3]).
-export([role_red/4, get/6]).
-export([rank_view/4]).
-export([init_rank_data/1]).
%%%=======================DEFINE=======================

%%%=======================INCLUDE=======================
-include("../include/active.hrl").

%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
-spec handle_get(atom(), integer(), term(), active:active()) -> tuple().
handle_get(Src, RoleUid, A, Active) ->
    Key = active_lib:get_role_active_key(RoleUid, Active),
    Format = handle_format(Src, A, Active),
    Get = z_db_lib:get(game_lib:get_table(Src, ?MODULE), Key, 0),
    {Format, Get}.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
-spec handle_start(atom(), term(), active:active(), integer()) -> 'ok'.
handle_start(Src, _A, Active, _Time) ->
    start(Src, Active),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
-spec handle_run(atom(), term(), active:active(), integer()) -> 'ok'.
handle_run(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
-spec handle_close(atom(), term(), active:active(), integer()) -> 'ok'.
handle_close(Src, _A, Active, _Time) ->
    stop(Src, Active),
    zm_event:notify(Src, active_clear, {?MODULE, Active}),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
-spec handle_shut(atom(), term(), active:active(), integer()) -> 'ok'.
handle_shut(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动事件处理
%% @end
%%-------------------------------------------------------------------
-spec handle_event(atom(), term(), active:active(), tuple()) -> 'ok'.
handle_event(Src, _A, Active, {'active_castle_rank', List}) ->
    {_, RoleUid} = lists:keyfind('role_uid', 1, List),
    {_, Level} = lists:keyfind('level', 1, List),
    Sid = active:get_sid(Active),
    %%增加积分后,排行榜刷新
    zm_event:notify(Src, 'active_rank', [{'sid', Sid}, {'uid', RoleUid}, {'value', Level}, {'m', active:get_m(Active)}]),
    ok;
handle_event(_Src, _A, _Active, _Event) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      初始化排行榜
%% @end
%%-------------------------------------------------------------------
init_rank_data(Src) ->
    Fun = fun(_, RoleUid, _, R) ->
        RoleShow = role_db:get_role_show(Src, RoleUid),
        CastleLv = role_show:get_castle_lv(RoleShow),
        case CastleLv > 1 of
            true ->
                zm_event:notify(Src, 'active_event', {'active_castle_rank', [{'role_uid', RoleUid}, {'level', CastleLv}]}),
                {ok, R + 1};
            false ->
                {ok, R}
        end
    end,
    z_db_lib:table_iterate(Src, game_lib:get_table(Src, 'role_show'), Fun, [], 0).

%%-------------------------------------------------------------------
%% @doc
%%      初始化排行榜
%% @end
%%-------------------------------------------------------------------
%%init_rank_data(Src, Active) ->
%%    Sid = active:get_sid(Active),
%%    M = active:get_m(Active),
%%    Fun = fun(_, RoleUid, _, R) ->
%%        RoleShow = role_db:get_role_show(Src, RoleUid),
%%        CastleLv = role_show:get_castle_lv(RoleShow),
%%        case CastleLv > 1 of
%%            true ->
%%                zm_event:notify(Src, 'active_rank', [{'sid', Sid}, {'uid', RoleUid}, {'value', CastleLv}, {'m', M}]);
%%            false ->
%%                'ok'
%%        end,
%%        {ok, R}
%%    end,
%%    z_db_lib:table_iterate(Src, game_lib:get_table(Src, 'role_show'), Fun, [], []).

%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
-spec handle_format(atom(), list(), active:active()) -> tuple().
handle_format(Src, A, Active) ->
    [RankAwardList] = A,
    Fun1 = fun({Min, Max, AwardList}) -> {Min, Max, list_to_tuple(AwardList)} end,
    {
        active:format_front(Src, ?MODULE, Active),
        list_to_tuple(lists:map(Fun1, RankAwardList))
    }.

%%-------------------------------------------------------------------
%% @doc
%%      是否有红点
%% @end
%%-------------------------------------------------------------------
-spec role_red(atom(), integer(), list(), active:active()) -> 0|1.
role_red(Src, RoleUid, _A, Active) ->
    case active_db:is_stoped(Src, active:get_sid(Active)) of
        true ->
            Key = active_lib:get_role_active_key(RoleUid, Active),
            Get = z_db_lib:get(game_lib:get_table(Src, ?MODULE), Key, 0),
            case Get =:= 0 of
                true ->
                    1;
                false ->
                    0
            end;
        false ->
            0
    end.

%%-------------------------------------------------------------------
%% @doc
%%      领取
%% @end
%%-------------------------------------------------------------------
-spec get(atom(), integer(), active:active(), integer(), list(), term()) -> tuple()|string().
get(Src, RoleUid, Active, _, _, _) ->
    case active_db:is_stoped(Src, active_lib:get_active_key(Src, Active)) of
        true ->
            F = fun(_, Get) ->
                case Get =:= 0 of
                    true ->
                        {ok, ok, 1};
                    false ->
                        throw("already_get")
                end
            end,
            case z_db_lib:update(game_lib:get_table(Src, ?MODULE), active_lib:get_role_active_key(RoleUid, Active), 0, F, []) of
                ok ->
                    Sid = active:get_sid(Active),
                    R = rank_get:get_rank(Src, RoleUid, Sid),
                    [RankAward] = active:get_a(Active),
                    AwardList = z_lib:foreach(fun(_, {Min, Max, AList}) ->
                        case R >= Min andalso R =< Max of
                            true ->
                                {'break', AList};
                            false ->
                                {ok, []}
                        end
                    end, [], RankAward),
%%            AwardLog = awarder_game:give_award(Src, RoleUid, [], AwardList),
%%            zm_event:notify(Src, 'bi_active_total_cash', [{'role_uid', RoleUid}, {'active', Active}, {'itemsid', ItemSid}, {'number', Number}, {'awards', AwardLog}]),
                    {ok, AwardList};
                Err ->
                    Err
            end;
        false ->
            "input_error"
    end.

%%-------------------------------------------------------------------
%% @doc
%%      排行榜玩家显示数据
%% @end
%%-------------------------------------------------------------------
-spec rank_view(term(), atom(), integer(), integer()) -> tuple().
rank_view(_A, Src, RoleUid, Value) ->
    RoleShow = role_db:get_role_show(Src, RoleUid),
    {RoleUid, role_show:get_name(RoleShow), role_show:get_corps_uid(RoleShow), role_show:get_corps_name(RoleShow),
        role_show:get_country(RoleShow), role_show:get_corps_banner(RoleShow), Value}.


%%%=====================LOC FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%
%% @end
%%-------------------------------------------------------------------
start(Src, Active) ->
%%    rank_db:add_rank_type(Src, active:get_sid(Active), ?MODULE),
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'sid_template', template_lib:get_key(Src, 'other_rank'), []}
    ]),
    z_db_lib:handle(TableName, fun start_/2, {Src, Active}, TableKeys).

%%-------------------------------------------------------------------
%% @doc
%%      新增排行榜类型
%% @end
%%-------------------------------------------------------------------
start_({_Src, Active}, [{Index1, RankTypeList}]) ->
    Sid = active:get_sid(Active),
    {ok, ok, [{Index1, lists:keystore(Sid, 1, RankTypeList, {Sid, ?MODULE})}]}.

%%-------------------------------------------------------------------
%% @doc
%%      活动结束扩展信息清理
%% @end
%%-------------------------------------------------------------------
stop(Src, Active) ->
    Sid = active:get_sid(Active),
    %%发放积分排行榜奖励
    [AwardList] = active:get_a(Active),
    rank_award(Src, Active, AwardList),
    rank_db:clear_ranks(Src, Sid).


%%-------------------------------------------------------------------
%% @doc
%%      发放排行榜奖励
%% @end
%%-------------------------------------------------------------------
-spec rank_award(atom(), active:active(), [{integer(), integer(), list()}]) -> term().
rank_award(Src, Active, AwardList) ->
    Key = game_lib:get_server_key(Src, active),
    Sid = active:get_sid(Active),
    Term = active:get_term(Active),
    case active_db:update_award_flag(Src, Sid, Term, Key) of
        false ->
            %%刷新一次排行榜
            rank_refresh:timer_refresh(Src, [[Sid]], []),
            AllRank = get_max_rank(AwardList),
            %%TODO 分多次取
            RankActions = rank_get:get_rank_range(Src, Sid, 1, AllRank),
            RanksSize = erlang:length(RankActions),
            ActiveName = active:get_name(Active),
            [send_mail(Src, Award, RankActions, RanksSize, MinRank, MaxRank, ActiveName, Active) || {MinRank, MaxRank, Award} <- AwardList];
        true ->
            'ignore'
    end.

%%-------------------------------------------------------------------
%% @doc
%%      发放邮件
%% @end
%%-------------------------------------------------------------------
send_mail(_Src, _Award, _Ranks, RanksSize, MinRank, _MaxRank, _ActiveName, _Active) when RanksSize < MinRank ->
    'ignore';
send_mail(Src, Award, Ranks, RanksSize, MinRank, MaxRank, ActiveName, Active) ->
    AllRank = if
        RanksSize > MaxRank ->
            MaxRank - MinRank + 1;
        true ->
            RanksSize - MinRank + 1
    end,
    MailType = award_source:get_source(?MODULE),
    TableName = game_lib:get_table(Src, ?MODULE),
    lists:foldl(fun(Info, Rank) ->
        {RoleUid, _Score} = Info,
        Get = z_db_lib:get(TableName, active_lib:get_role_active_key(RoleUid, Active), 0),
        case Get =:= 0 of
            true ->
                Mail = mail:init({MailType, time_lib:now_second(), 0, {7, ActiveName}, {7, ActiveName, Rank}, Award}),
                mail_db:send(Src, RoleUid, Mail);
            false ->
                ok
        end,
        Rank + 1
    end, MinRank, lists:sublist(Ranks, MinRank, AllRank)).


%%-------------------------------------------------------------------
%% @doc
%%      获取配置的最大名次
%% @end
%%-------------------------------------------------------------------
-spec get_max_rank(list()) -> integer().
get_max_rank(ConfigList) ->
    lists:max([Max || {_, Max, _} <- ConfigList]).