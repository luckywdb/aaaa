%%限时福利加成活动
-module(active_addition).

%%%=======================STATEMENT====================
-description("active_addition").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_event/4, handle_format/3]).
-export([handle_update/2]).
-export([get_active_addition/2, get_active_time_add_list/3, get_monster_drop_multi/1, get_duplicate_drop_multi/1,
    get_collect_speed_add/2, get_resource_addition/2]).
-export([get_active_additions/1, get_active_add/3]).
-export([get_addition_type/1]).
-export([delete/2]).
%%%=======================DEFINE=======================

%%%=======================INCLUDE=======================
-include("../include/active.hrl").
-define(MID_ADDITION_TYPES, []).
%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
-spec handle_get(atom(), integer(), term(), active:active()) -> tuple().
handle_get(Src, _RoleUid, A, Active) ->
    Format = handle_format(Src, A, Active),
    {Format, {}}.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
-spec handle_start(atom(), term(), active:active(), integer()) -> 'ok'.
handle_start(Src, _A, Active, _Time) ->
    start(Src, Active),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
-spec handle_run(atom(), term(), active:active(), integer()) -> 'ok'.
handle_run(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
-spec handle_close(atom(), term(), active:active(), integer()) -> 'ok'.
handle_close(Src, _A, Active, _Time) ->
    stop(Src, Active),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
-spec handle_shut(atom(), term(), active:active(), integer()) -> 'ok'.
handle_shut(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      事件处理
%% @end
%%-------------------------------------------------------------------
-spec handle_event(atom(), term(), active:active(), tuple()) -> 'ok'.
handle_event(_Src, _A, _Active, _Event) ->
    ok.


%%-------------------------------------------------------------------
%% @doc
%%      数据更新
%% @end
%%-------------------------------------------------------------------
-spec handle_update(atom(), active:active()) -> 'ok'.
handle_update(Src, Active) ->
    update(Src, Active).
%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
-spec handle_format(atom(), list(), active:active()) -> tuple().
handle_format(Src, A, Active) ->
    [{AdditionType, Add}] = A,
    {
        active:format_front(Src, ?MODULE, Active),
        {get_addition_type(AdditionType), Add}
    }.


%%-------------------------------------------------------------------
%% @doc
%%      获取所有活动加成及时间区间
%% @end
%%-------------------------------------------------------------------
-spec get_active_additions(atom()) -> list().
get_active_additions(Src) ->
    z_lib:foreach(fun(Acc, AdditionType) ->
        {List, _} = get_active_addition(Src, AdditionType),
        T = get_addition_type(AdditionType),
        z_lib:foreach(fun(Acc1, {Sid, Add, STime}) ->
            case active_db:get_active(Src, active_lib:get_active_key(Src, Sid)) of
                'none' ->
                    {'ok', Acc1};
                Active ->
                    ActiveTime = active_db:get_active_time(Src, Active),
                    ETime = STime + active_time:get_run_time(ActiveTime),
                    {ok, [{Sid, T, Add, STime, ETime} | Acc1]}
            end
        end, Acc, List)
    end, [], ?ACTIVE_ALL_ADDITIONS).

%%-------------------------------------------------------------------
%% @doc
%%      得到怪物掉落倍数(以10000为基数)
%% @end
%%-------------------------------------------------------------------
-spec get_monster_drop_multi(atom()) -> integer().
get_monster_drop_multi(Src) ->
    Now = time_lib:now_second(),
    {List, _} = get_active_addition(Src, ?ACTIVE_ADDITION_MONSTER_DROP_ADD),
    TAddList = get_active_time_add_list({List, []}, Now, Now),
    lists:foldl(fun({_, Add}, C) -> C + Add end, 10000, TAddList).

%%-------------------------------------------------------------------
%% @doc
%%      得到副本掉落倍数(以10000为基数)
%% @end
%%-------------------------------------------------------------------
-spec get_duplicate_drop_multi(atom()) -> integer().
get_duplicate_drop_multi(Src) ->
    Now = time_lib:now_second(),
    {List, _} = get_active_addition(Src, ?ACTIVE_ADDITION_DUPLICATE_DROP_ADD),
    TAddList = get_active_time_add_list({List, []}, Now, Now),
    lists:foldl(fun({_, Add}, C) -> C + Add end, 10000, TAddList).

%%-------------------------------------------------------------------
%% @doc
%%      资源采集速度加成
%% @end
%%-------------------------------------------------------------------
-spec get_collect_speed_add(atom(), atom()) -> integer().
get_collect_speed_add(Src, ResourceType) ->
    Now = time_lib:now_second(),
    {List1, _} = get_active_addition(Src, {ResourceType, 'col'}),
    {List2, _} = get_active_addition(Src, ?ACTIVE_ADDITION_COL_ALL),
    TAddList = get_active_time_add_list({List1 ++ List2, []}, Now, Now),
    lists:foldl(fun({_, Add}, C) -> C + Add end, 0, TAddList).

%%-------------------------------------------------------------------
%% @doc
%%      获取活动资源产量加成信息
%% @end
%%-------------------------------------------------------------------
-spec get_resource_addition(atom(), atom()) -> tuple().
get_resource_addition(Src, ResourceType) ->
    {List1, TList1} = get_active_addition(Src, ResourceType),
    case ResourceType =:= ?ACTIVE_ADDITION_RES_MONEY of
        true ->
            {List1, TList1};
        false ->
            {List2, TList2} = get_active_addition(Src, ?ACTIVE_ADDITION_RES_ALL),
            {List1 ++ List2, TList1 ++ TList2}
    end.
%%-------------------------------------------------------------------
%% @doc
%%      转换时间点加成列表
%% @end
%%-------------------------------------------------------------------
-spec get_active_time_add_list({List, ToutList}, StartTime, EndTime) -> [{integer(), integer()}] when
    List :: list(),
    ToutList :: list(),
    StartTime :: integer(),
    EndTime :: integer().
get_active_time_add_list({List, ToutList}, StartTime, EndTime) ->
    NToutList = remove_timeout(ToutList, time_lib:now_second()),
    ATList = lists:map(fun({_, Add, STime}) -> {max(StartTime, STime), Add} end, List),
    lists:foldl(fun({_, Add, STime, ETime}, Acc) ->
        if
            STime > EndTime orelse ETime < StartTime ->
                Acc;
            true ->
                [{max(StartTime, STime), Add}, {min(ETime, EndTime), -Add} | Acc]
        end
    end, ATList, NToutList).


%%-------------------------------------------------------------------
%% @doc
%%      活动活动加成
%% @end
%%-------------------------------------------------------------------
-spec get_active_add({List, ToutList}, StartTime, EndTime) -> integer() when
    List :: list(),
    ToutList :: list(),
    StartTime :: integer(),
    EndTime :: integer().
get_active_add({List, ToutList}, StartTime, EndTime) ->
    TimeAddList = get_active_time_add_list({List, ToutList}, StartTime, EndTime),
    lists:foldl(fun({_, Add}, C) -> C + Add end, 0, TimeAddList).

%%-------------------------------------------------------------------
%% @doc
%%      获得加成数据
%% @end
%%-------------------------------------------------------------------
-spec get_active_addition(Src, AdditionType) -> tuple() when
    Src :: atom(),
    AdditionType :: term().
get_active_addition(Src, AdditionType) ->
    z_db_lib:get(game_lib:get_table(Src, ?MODULE), AdditionType, {[], []}).

%%%=====================LOC FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%
%% @end
%%-------------------------------------------------------------------
start(Src, Active) ->
    update(Src, Active).


%%-------------------------------------------------------------------
%% @doc
%%      活动结束扩展信息清理
%% @end
%%-------------------------------------------------------------------
stop(Src, Active) ->
    delete(Src, Active).



update(Src, Active) ->
    Sid = active:get_sid(Active),
    [{AdditionType, Add}] = active:get_a(Active),
    ActiveTime = active_db:get_active_time(Src, Active),
    Now = time_lib:now_second(),
    Fun = fun(_, {List, ToutList}) ->
        NList = lists:keystore(Sid, 1, List, {Sid, Add, active_time:get_start_time(ActiveTime)}),
        {ok, ok, {NList, remove_timeout(ToutList, Now)}}
    end,
    z_db_lib:update(game_lib:get_table(Src, ?MODULE), AdditionType, {[], []}, Fun, []).


delete(Src, Active) ->
    Sid = active:get_sid(Active),
    Now = time_lib:now_second(),
    [{AdditionType, Add}] = active:get_a(Active),
    Fun = fun(_, {List, ToutList}) ->
        case lists:keyfind(Sid, 1, List) of
            false ->%活动已经被停止了之后,GM删除操作
                throw("ok");
            {_, _, BTime} ->
                NList = lists:keydelete(Sid, 1, List),
                NToutList = [{Sid, Add, BTime, Now} | remove_timeout(ToutList, Now)],
                {ok, ok, {NList, NToutList}}
        end
    end,
    z_db_lib:update(game_lib:get_table(Src, ?MODULE), AdditionType, {[], []}, Fun, []).

%%-------------------------------------------------------------------
%% @doc
%%      移除
%% @end
%%-------------------------------------------------------------------
remove_timeout(ToutList, Time) ->
    lists:filter(fun({_, _, _, EndTime}) ->
        EndTime > Time - 86400
    end, ToutList).


%%-------------------------------------------------------------------
%% @doc
%%      获取加成类型
%% @end
%%-------------------------------------------------------------------
-spec get_addition_type(atom()|tuple()) -> atom().
get_addition_type(AdditionType) ->
    if
        is_atom(AdditionType) ->
            AdditionType;
        true ->
            {T1, T2} = AdditionType,
            string_lib:to_atom(lists:concat([T1, "_", T2]))
    end.