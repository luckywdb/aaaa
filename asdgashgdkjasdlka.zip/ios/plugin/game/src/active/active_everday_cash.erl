%%每日充值活动
-module(active_everday_cash).

-description("active_everday_cash").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_event/4, handle_format/3]).
-export([role_red/4, get/6]).
%%%=======================DEFINE=======================
-define(ACTIVE_HANDLE_KEY, 'over_award').
%%%=======================INCLUDE=======================
-include("../include/active.hrl").

-record(role_ervery_cash, {
    curr_index = 1 :: integer(),%%当前天数index
    day = 0 :: integer(),
    is_get = 0 :: 0 | 1,%%是否已经领取
    is_complete = 0 :: 0 | 1,%%是否已经完成
    total_cash = 0 :: integer()
}).
%%%=================EXPORTED FUNCTIONS===================
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
-spec handle_get(atom(), integer(), term(), active:active()) -> tuple().
handle_get(Src, RoleUid, A, Active) ->
    Key = active_lib:get_role_active_key(RoleUid, Active),
    RoleEverdayCash = z_db_lib:get(game_lib:get_table(Src, ?MODULE), Key, init_data()),
    [EDItemList] = A,
    #role_ervery_cash{curr_index = CurrIndex, total_cash = TotalCash, is_get = IsGet, is_complete = IsComplete} = refresh_role_everyday_cash(RoleEverdayCash, length(EDItemList)),
%%    [ItemList] = A,
%%    case CurrIndex > length(ItemList) of
%%        false ->
    Format = handle_format(Src, A, Active),
    {Format, {CurrIndex, TotalCash, IsGet, IsComplete}}.
%%        true ->
%%            ok
%%    end.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
-spec handle_start(atom(), term(), active:active(), integer()) -> 'ok'.
handle_start(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
-spec handle_run(atom(), term(), active:active(), integer()) -> 'ok'.
handle_run(Src, A, Active, _Time) ->
    Table = game_lib:get_table(Src, ?MODULE),
    Key = active_lib:get_active_key(Src, active:get_sid(Active)),
    Day = time_lib:get_date_by_type('day_of_year'),
    case z_db_lib:get(Table, Key, Day) of
        Day ->
            z_db_lib:update(Table, Key, Day);
        _ ->
            z_db_lib:update(Table, Key, Day),
            award_reissue(Src, A, Active)
    end.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
-spec handle_close(atom(), term(), active:active(), integer()) -> 'ok'.
handle_close(Src, A, Active, _Time) ->
    %%结束的时候补发没有领取的奖励
    Key = active_lib:get_active_key(Src, active:get_sid(Active)),
    Table = game_lib:get_table(Src, ?MODULE),
    Day = time_lib:get_date_by_type('day_of_year'),
    case z_db_lib:delete1(Table, Key, Day) of
        Day ->
            ok;
        _ ->
            award_reissue(Src, A, Active)
    end,
    %%进行数据清理，异步处理
    zm_event:notify(Src, active_clear, {?MODULE, Active}),
    'ok'.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
-spec handle_shut(atom(), term(), active:active(), integer()) -> 'ok'.
handle_shut(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      事件处理
%% @end
%%-------------------------------------------------------------------
-spec handle_event(atom(), term(), active:active(), tuple()) -> 'ok'.
handle_event(Src, [EDItemList], Active, {'cash_ok', List}) ->
    RoleUid = z_lib:get_value(List, 'role_uid', 'none'),
    Cash = z_lib:get_value(List, 'cash_rmb', none),
    if
        RoleUid =:= none orelse Cash =:= 'none' ->
            zm_log:warn(Src, ?MODULE, 'handle_event', "error_role_itemId", [{'cash_ok', List}]);
        true ->
            EDItemTuple = list_to_tuple(EDItemList),
            Fun = fun(_, RoleEverdayCash) ->
                NRoleEverdayCash1 = refresh_role_everyday_cash(RoleEverdayCash, length(EDItemList)),
                #role_ervery_cash{curr_index = CurrIndex, is_complete = IsComplete, total_cash = TotalCash} = NRoleEverdayCash1,
                case IsComplete =:= 1 of
                    true ->
                        {ok, ok};
                    false ->
                        Size = tuple_size(EDItemTuple),
                        case CurrIndex > Size of
                            true ->
                                {ok, ok};
                            false ->
                                {_, Rmb, _, _, _} = element(CurrIndex, EDItemTuple),
                                NTotalCash = TotalCash + Cash,
                                case NTotalCash >= Rmb of
                                    true ->
                                        NRoleEverdayCash = NRoleEverdayCash1#role_ervery_cash{is_complete = 1, total_cash = NTotalCash},
                                        {ok, {ok, CurrIndex, NTotalCash, true}, NRoleEverdayCash};
                                    false ->
                                        NRoleEverdayCash = NRoleEverdayCash1#role_ervery_cash{total_cash = NTotalCash},
                                        {ok, {ok, CurrIndex, NTotalCash, false}, NRoleEverdayCash}
                                end
                        end
                end
            end,
            case z_db_lib:update(game_lib:get_table(Src, ?MODULE), active_lib:get_role_active_key(RoleUid, Active), init_data(), Fun, 'none') of
                {ok, CurrIndex, TotalCash, IsSend} ->
                    case IsSend of
                        true ->
                            {_, _, _, _, SendAwardList} = element(CurrIndex, EDItemTuple),
                            send_mail(Src, RoleUid, {11}, {11}, SendAwardList);
                        false ->
                            ok
                    end,
                    set_front_lib:send_active_ervery_cash(Src, RoleUid, {CurrIndex, TotalCash});
                ok ->
                    ok
            end
    end;
handle_event(_, _, _, _) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
-spec handle_format(atom(), list(), active:active()) -> tuple().
handle_format(Src, [EDItemList], Active) ->
    Fun = fun({ItemSid, Rmb, GetRAwardList, GetAwardList, SendAwardList}) ->
        {ItemSid, Rmb, list_to_tuple(GetRAwardList), list_to_tuple(GetAwardList), list_to_tuple(SendAwardList)}
    end,
    {
        active:format_front(Src, ?MODULE, Active),
        list_to_tuple(lists:map(Fun, EDItemList))
    }.

%%-------------------------------------------------------------------
%% @doc
%%      是否有红点
%% @end
%%-------------------------------------------------------------------
-spec role_red(atom(), integer(), list(), active:active()) -> 0|1.
role_red(Src, RoleUid, [EDItemList], Active) ->
    EDItemTuple = list_to_tuple(EDItemList),
    Size = tuple_size(EDItemTuple),
    RoleEverdayCash = z_db_lib:get(game_lib:get_table(Src, ?MODULE), active_lib:get_role_active_key(RoleUid, Active), init_data()),
    #role_ervery_cash{curr_index = CurrIndex, is_complete = IsComplete, is_get = IsGet} = refresh_role_everyday_cash(RoleEverdayCash, Size),
    case CurrIndex =< Size andalso IsGet =:= 0 andalso IsComplete =:= 1 of
        true ->
            1;
        false ->
            0
    end.

%%-------------------------------------------------------------------
%% @doc
%%      领取
%% @end
%%-------------------------------------------------------------------
-spec get(atom(), integer(), active:active(), integer(), list(), term()) -> tuple()|string().
get(Src, RoleUid, Active, _, _, Msg) ->
    Index = z_lib:get_value(Msg, "index", 0),
    case Index > 0 of
        true ->
            [EDItemList] = active:get_a(Active),
            EDItemTuple = list_to_tuple(EDItemList),
            Size = tuple_size(EDItemTuple),
            Fun = fun(_, RoleEverdayCash) ->
                #role_ervery_cash{curr_index = CurrIndex, is_complete = IsComplete, is_get = IsGet, total_cash = TotalCash} = refresh_role_everyday_cash(RoleEverdayCash, Size),
                case CurrIndex =< Size of
                    true ->
                        case IsGet =:= 0 of
                            true ->
                                {_, Rmb, GetRAwardList, _, _} = element(CurrIndex, EDItemTuple),
                                case Index > length(GetRAwardList) of
                                    true ->
                                        throw("input_error");
                                    false ->
                                        if
                                            IsComplete =:= 1 ->
                                                {ok, {ok, CurrIndex, false}, RoleEverdayCash#role_ervery_cash{is_get = 1}};
                                            TotalCash >= Rmb ->
                                                {ok, {ok, CurrIndex, true}, RoleEverdayCash#role_ervery_cash{is_get = 1, is_complete = 1}};
                                            true ->
                                                throw("no_enough")
                                        end
                                end;
                            false ->
                                throw("already_get")
                        end;
                    false ->
                        throw("already_get")
                end
            end,
            case z_db_lib:update(game_lib:get_table(Src, ?MODULE), active_lib:get_role_active_key(RoleUid, Active), init_data(), Fun, 'none') of
                {ok, CurrIndex, IsSend} ->
                    {_, _, GetRandomAwardList, GetAwardList, SendAwardList} = element(CurrIndex, EDItemTuple),
                    case IsSend of
                        true ->
                            send_mail(Src, RoleUid, {11}, {11}, SendAwardList);
                        false ->
                            ok
                    end,
                    {ok, [lists:nth(Index, GetRandomAwardList), GetAwardList]};
                Err ->
                    Err
            end;
        false ->
            "input_error"
    end.

%%-------------------------------------------------------------------
%% @doc
%%      发送邮件
%% @end
%%-------------------------------------------------------------------
send_mail(_, _, _, _, []) ->
    ok;
send_mail(Src, RoleUid, MailTitle, MailContent, AwardList) ->
    MailType = award_source:get_source(?MODULE),
    Mail = mail:init({MailType, time_lib:now_second(), 0, MailTitle, MailContent, AwardList}),
    mail_db:send(Src, RoleUid, Mail).


%%-------------------------------------------------------------------
%% @doc
%%      刷新玩家数据
%% @end
%%-------------------------------------------------------------------
refresh_role_everyday_cash(#role_ervery_cash{curr_index = CurrIndex, day = Day, is_complete = IsComplete} = RoleEverdayCash, MaxIndex) ->
    CurDay = time_lib:get_date_by_type('day_of_year'),
    case CurDay =:= Day of
        true ->
            RoleEverdayCash;
        false ->
            NCurrIndex = case IsComplete =:= 1 of
                true ->
                    CurrIndex + 1;
                false ->
                    CurrIndex
            end,
            case NCurrIndex > MaxIndex of
                true ->
                    RoleEverdayCash#role_ervery_cash{curr_index = MaxIndex, day = Day, is_complete = 1, is_get = 1};
                false ->
                    #role_ervery_cash{
                        curr_index = NCurrIndex,
                        day = CurDay
                    }
            end
    end.

init_data() ->
    #role_ervery_cash{
        day = time_lib:get_date_by_type('day_of_year')
    }.

%%-------------------------------------------------------------------
%% @doc
%%      所有人奖励补发
%% @end
%%-------------------------------------------------------------------
-spec award_reissue(atom(), term(), active:active()) -> 'ok'.
award_reissue(Src, [EDItemList], Active) ->
    Table = game_lib:get_table(Src, ?MODULE),
    EDItemTuple = list_to_tuple(EDItemList),
    Size = tuple_size(EDItemTuple),
    Fun = fun(_, {RoleUid, _, _}, _, _) ->
        Fun1 = fun(_, RoleEverdayCash) when is_record(RoleEverdayCash, role_ervery_cash) ->
            #role_ervery_cash{curr_index = CurrIndex, is_complete = IsComplete, is_get = IsGet, total_cash = TotalCash} = RoleEverdayCash,
            case CurrIndex =< Size andalso IsGet =:= 0 of
                true ->
                    {_ItemSid, Rmb, _GetRandomList, _GetAwardList, _SendAwardList} = element(CurrIndex, EDItemTuple),
                    if
                        IsComplete =:= 1 ->
                            {ok, {ok, CurrIndex, false}, RoleEverdayCash#role_ervery_cash{is_get = 1}};
                        TotalCash >= Rmb ->
                            {ok, {ok, CurrIndex, true}, RoleEverdayCash#role_ervery_cash{is_get = 1, is_complete = 1}};
                        true ->
                            {ok, ok}
                    end;
                false ->
                    {ok, ok}
            end;
            (_, _) ->
                {ok, ok}
        end,
        Key = active_lib:get_role_active_key(RoleUid, Active),
        case z_db_lib:update(Table, Key, init_data(), Fun1, []) of
            {ok, CurrIndex, IsSend} ->
                {_ItemSid, _Rmb, GetRandomAwardList, GetAwardList, SendAwardList} = element(CurrIndex, EDItemTuple),
                send_mail(Src, RoleUid, {12}, {12}, game_lib:random_list(GetRandomAwardList, 1) ++ GetAwardList),
                case IsSend of
                    true ->
                        send_mail(Src, RoleUid, {11}, {11}, SendAwardList),
                        ok;
                    false ->
                        ok
                end;
            ok ->
                ok
        end
    end,
    z_db_lib:table_iterate(Src, Table, Fun, 'none', []),
    ok.