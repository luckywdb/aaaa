%%充值礼包活动
-module(active_cash_award).

-description("active_cash_award").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_event/4, handle_format/3]).
%%%=======================DEFINE=======================
-define(DELAY_TIME, 1800).
%%%=======================INCLUDE=======================
-include("../include/active.hrl").

%%%=================EXPORTED FUNCTIONS===================
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
-spec handle_get(atom(), integer(), term(), active:active()) -> tuple().
handle_get(Src, RoleUid, A, Active) ->
    Key = active_lib:get_role_active_key(RoleUid, Active),
    ItemTimesList = z_db_lib:get(game_lib:get_table(Src, ?MODULE), Key, []),
    Format = handle_format(Src, A, Active),
    {Format, list_to_tuple(ItemTimesList)}.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
-spec handle_start(atom(), term(), active:active(), integer()) -> 'ok'.
handle_start(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
-spec handle_run(atom(), term(), active:active(), integer()) -> 'ok'.
handle_run(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
-spec handle_close(atom(), term(), active:active(), integer()) -> 'ok'.
handle_close(Src, _A, Active, _Time) ->
    %%进行数据清理，异步处理
    zm_event:notify(Src, active_clear, {?MODULE, Active}),
    'ok'.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
-spec handle_shut(atom(), term(), active:active(), integer()) -> 'ok'.
handle_shut(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      事件处理
%% @end
%%-------------------------------------------------------------------
-spec handle_event(atom(), term(), active:active(), tuple()) -> 'ok'.
handle_event(Src, [{_, ItemList}], Active, {'cash_giftbag_ok', Args}) ->
    zm_log:info(Src, ?MODULE, 'handle_event', "cash_giftbag", [{'args', Args}]),
    ItemSidStr = z_lib:get_value(Args, 'active_item_sid', ""),
    case is_list(ItemSidStr) andalso ItemSidStr =/= "" of
        true ->
            ItemSid = list_to_integer(ItemSidStr),
            {_, RoleUid} = lists:keyfind('role_uid', 1, Args),
            {_, CashItem} = lists:keyfind('item_id', 1, Args),
            case lists:keyfind(ItemSid, 1, ItemList) of
                {_, CItem, AwardList, MaxTimes, StartTime, ContinuTime, _Cost, _TitleDir} ->
                    case CItem =:= CashItem of
                        true ->
                            Now = time_lib:now_second(),
                            ActiveTime = active_db:get_active_time(Src, Active),
                            case ActiveTime =/= 'none' andalso active_time:get_start_time(ActiveTime) + StartTime =< Now andalso
                                active_time:get_start_time(ActiveTime) + StartTime + ContinuTime + ?DELAY_TIME > Now of
                                true ->
                                    Fun = fun(_, GotItemTimesList) ->
                                        case lists:keyfind(ItemSid, 1, GotItemTimesList) of
                                            false ->
                                                {ok, ok, [{ItemSid, 1} | GotItemTimesList]};
                                            {_, CurrTimes} ->
                                                case CurrTimes >= MaxTimes of
                                                    true ->
                                                        throw("max_times_limit");
                                                    false ->
                                                        {ok, ok, lists:keyreplace(ItemSid, 1, GotItemTimesList, {ItemSid, CurrTimes + 1})}
                                                end
                                        end
                                    end,
                                    Key = active_lib:get_role_active_key(RoleUid, Active),
                                    case z_db_lib:update(game_lib:get_table(Src, ?MODULE), Key, [], Fun, []) of
                                        ok ->
                                            AwardLog = awarder_game:give_award(Src, RoleUid, ?MODULE, AwardList),
                                            zm_event:notify(Src, 'active_cash_award', [{'role_uid', RoleUid}, {'active_item_sid', ItemSid},
                                                {'cash_item_sid', CashItem}, {'award', AwardLog}, {'active', Active}, {'active_time', ActiveTime}]),
                                            set_front_lib:send_active_cash_award(Src, RoleUid, ItemSid, AwardLog),
                                            zm_event:notify(Src, 'cash_gift_award_crops_email', Args),
                                            zm_log:info(Src, ?MODULE, 'handle_event', "cash_giftbag_ok", [{'args', Args}, {'award', AwardLog}]);
                                        Err ->
                                            zm_log:warn(Src, ?MODULE, 'handle_event', "cash_giftbag", [{'args', Args}, {'error', Err}]),
                                            Err
                                    end;
                                false ->
                                    zm_log:warn(Src, ?MODULE, 'handle_event', "active_time_error", [{'args', Args}, {'active_time', ActiveTime}]),
                                    ok
                            end;
                        false ->
                            zm_log:warn(Src, ?MODULE, 'handle_event', "cash_item_error", [{'args', Args}, {'cash_item', CashItem}]),
                            ok
                    end;
                false ->
                    zm_log:warn(Src, ?MODULE, 'handle_event', "not_find_itemsid", [{'args', Args}, {'item_sid', ItemSid}]),
                    ok
            end;
        false ->
            zm_log:warn(Src, ?MODULE, 'handle_event', "itemsid_str_error", [{'args', Args}]),
            ok
    end;
handle_event(_, _, _, _) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
-spec handle_format(atom(), list(), active:active()) -> tuple().
handle_format(Src, [{HeadUrl, ItemList}], Active) ->
    Fun = fun({ItemSid, CashItem, AwardList, MaxTimes, StartTime, ContinuTime, Cost, TitleDir}) ->
        {ItemSid, CashItem, list_to_tuple(AwardList), MaxTimes, StartTime, ContinuTime, Cost, TitleDir}
    end,
    {
        active:format_front(Src, ?MODULE, Active),
        {
            HeadUrl,
            ?DELAY_TIME,
            list_to_tuple(lists:map(Fun, ItemList))
        }
    }.