%%活动库操作
-module(active_db).

%%%=======================STATEMENT===================
-description("active_db").
-copyright({seasky, 'www.seasky.cn'}).
-author({cb, 'chenbin@youkia.net'}).
-vsn(1).

%%%=======================EXPORT=======================
-export([get_active/2, get_active_time/2, get_active_state_list/1, get_config_active_state_list/1, get_stute/3, format_active_time/2, is_closed/2, is_stoped/2, clear/3, event/2]).
-export([get_short_actives/2, get_actives_by_mod/3]).
-export([update_award_flag/4, clear_award_flag/4, get_actives_by_sid/3]).
%%%=======================INCLUDE======================
-include("../include/active.hrl").
%%%=======================RECORD=======================

%%%=======================DEFINE=======================

%%%=================EXPORTED FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%      得到活动
%% @end
%%-------------------------------------------------------------------
-spec get_active(atom(), {integer(), integer(), integer()}) -> 'none' | active:active().
get_active(Src, {_, _, ID} = ActiveSid) ->
    case z_db_lib:get(game_lib:get_table(Src, 'active'), ActiveSid, none) of
        none ->
            zm_config:get('active', ID);
        Active ->
            Active
    end.


%%-------------------------------------------------------------------
%% @doc
%%
%% @end
%%-------------------------------------------------------------------
-spec get_actives_by_mod(atom(), integer(), atom()) -> list().
get_actives_by_mod(Src, RoleUid, Mod) ->
    ActivesState = active_db:get_config_active_state_list(Src),
    F = fun({ActiveSid, State}, List) when State =:= ?STOP orelse State =:= ?RUN orelse State =:= ?BEFORE ->
        case active_db:get_active(Src, ActiveSid) of
            none ->
                List;
            Active ->
%%                case active:get_visible(Active) of
%%                    ?VISIBLE ->
                {M, A} = active:get_ma(Active),
                case M =:= Mod of
                    true ->
                        try
                            case M:handle_get(Src, RoleUid, A, Active) of
                                ActiveInfo when is_tuple(ActiveInfo) ->
                                    [ActiveInfo | List];
                                _ ->
                                    List
                            end
                        catch
                            E:E1 ->
                                zm_log:warn(Src, ?MODULE, 'active', "get_actives", [{'e', E}, {'e1', E1}, {'sid', ActiveSid}, {'stacktrace', erlang:get_stacktrace()}]),
                                List
                        end;
                    false ->
                        List
                end
%%                    _ ->
%%                        List
%%                end
        end;
        (_, List) ->
            List
    end,
    lists:foldl(F, [], ActivesState).

%%-------------------------------------------------------------------
%% @doc
%%
%% @end
%%-------------------------------------------------------------------
-spec get_actives_by_sid(atom(), integer(), {integer(), integer(), integer()}) -> list().
get_actives_by_sid(Src, RoleUid, Sid) ->
    ActivesState = active_db:get_config_active_state_list(Src),
    F = fun({ActiveSid, State}, List) when State =:= ?STOP orelse State =:= ?RUN orelse State =:= ?BEFORE ->
        case active_db:get_active(Src, ActiveSid) of
            none ->
                List;
            Active ->
                {M, A} = active:get_ma(Active),
                case ActiveSid =:= Sid of
                    true ->
                        try
                            case M:handle_get(Src, RoleUid, A, Active) of
                                ActiveInfo when is_tuple(ActiveInfo) ->
                                    [ActiveInfo | List];
                                _ ->
                                    List
                            end
                        catch
                            E:E1 ->
                                zm_log:warn(Src, ?MODULE, 'active', "get_actives", [{'e', E}, {'e1', E1}, {'sid', ActiveSid}, {'stacktrace', erlang:get_stacktrace()}]),
                                List
                        end;
                    false ->
                        List
                end
%%                    _ ->
%%                        List
%%                end
        end;
        (_, List) ->
            List
    end,
    lists:foldl(F, [], ActivesState).

%%-------------------------------------------------------------------
%% @doc
%%      得到活动简要信息
%% @end
%%-------------------------------------------------------------------
-spec get_short_actives(atom(), integer()) -> list().
get_short_actives(Src, RoleUid) ->
    ActivesState = active_db:get_config_active_state_list(Src),
    F = fun({ActiveSid, State}, List) when State =:= ?STOP orelse State =:= ?RUN orelse State =:= ?BEFORE ->
        case active_db:get_active(Src, ActiveSid) of
            none ->
                List;
            Active ->
                {M, A} = active:get_ma(Active),
                Red =
                    case erlang:function_exported(M, 'role_red', 4) of
                        true ->
                            M:role_red(Src, RoleUid, A, Active);
                        false ->
                            0
                    end,
%%                case active:get_visible(Active) of
%%                    ?VISIBLE ->
                {M, A} = active:get_ma(Active),
                SubType = if
                    M =:= 'active_addition' ->
                        [{AdditionType, _Add}] = A,
                        active_addition:get_addition_type(AdditionType);
                    M =:= 'active_consume_target' ->
                        [{ConsumeList, _, _}] = A,
                        M:get_type(ConsumeList);
                    M =:= 'active_collect_target_rank' ->
                        [{_, _, OtherInfo}] = A,
                        M:get_type(OtherInfo);
                    M =:= 'active_collect_target' ->
                        [{_, OtherInfo}] = A,
                        M:get_type(OtherInfo);
                    true ->
                        ""
                end,
                [{active:get_sid(Active), active:get_icon(Active), active:get_sequence(Active), M, SubType, active:get_term(Active),
                    active_db:format_active_time(Src, Active), Red} | List]
%%                    _ ->
%%                        List
%%                end
        end;
        (_, List) ->
            List
    end,
    lists:foldl(F, [], ActivesState).

%%-------------------------------------------------------------------
%% @doc
%%      得到活动时间记录
%% @end
%%-------------------------------------------------------------------
-spec get_active_time(atom(), active:active()) -> active_time:active_time() | 'none'.
get_active_time(Src, Active) ->
    case z_db_lib:get(game_lib:get_table(Src, 'active_time'), active_lib:get_active_time_key(Src, active:get_time_id(Active)), none) of
        none ->
            zm_config:get('active_time', active:get_time_id(Active));
        ActiveTime ->
            ActiveTime
    end.

%%-------------------------------------------------------------------
%% @doc
%%      得到活动状态
%% @end
%%-------------------------------------------------------------------
-spec get_active_state_list(atom()) -> [{{integer(), integer(), integer()}, integer()}].
get_active_state_list(Src) ->
    z_db_lib:get(game_lib:get_table(Src, 'actives_state'), active_lib:get_active_state_key(Src), []).

%%-------------------------------------------------------------------
%% @doc
%%      得到活动状态
%% @end
%%-------------------------------------------------------------------
-spec get_config_active_state_list(atom()) -> [{{integer(), integer(), integer()}, integer()}].
get_config_active_state_list(Src) ->
    case zm_config:get(?ACTIVE_STATE_CONFIG) of
        none ->
            get_active_state_list(Src);
        States ->
            States
    end.

%%-------------------------------------------------------------------
%% @doc
%%      获得活动当前状态
%% @end
%%-------------------------------------------------------------------
-spec get_stute(atom(), integer(), active:active()) -> integer().
get_stute(Src, Time, Active) ->
    case get_active_time(Src, Active) of
        none ->
            zm_log:warn(Src, ?MODULE, 'check', "no_config", [{'active_sid', active:get_sid(Active)}, {'time_id', active:get_time_id(Active)}]),
            ?STOP;
        Record ->
            M = erlang:element(1, Record),
            M:get_stute(Src, Time, Record)
    end.

%%-------------------------------------------------------------------
%% @doc
%%      获得时间格式化
%% @end
%%-------------------------------------------------------------------
-spec format_active_time(atom(), active:active()) -> {integer(), integer(), integer(), integer(), integer(), integer()}.
format_active_time(Src, Active) ->
    case get_active_time(Src, Active) of
        none ->
            zm_log:warn(Src, ?MODULE, 'check', "no_config", [{'active_sid', active:get_sid(Active)}, {'time_id', active:get_time_id(Active)}]),
            {0, 0, 0, 0, 0, 0};
        Record ->
            M = erlang:element(1, Record),
            M:format(Src, Record)
    end.

%%-------------------------------------------------------------------
%% @doc
%%      事件处理
%% @end
%%-------------------------------------------------------------------
-spec event(atom(), term()) -> 'ok'.
event(Src, Event) ->
    F = fun({ActiveSid, ?RUN}) ->%%开启的活动才进行接收
        try
            case get_active(Src, ActiveSid) of
                none ->
                    ok;
                Active ->
                    {M, A} = active:get_ma(Active),
                    M:handle_event(Src, A, Active, Event)
            end
        catch
            E:E1 ->
                zm_log:warn(?MODULE, ?MODULE, "active_event", "error", [{'e', E}, {'e1', E1}, {'sid', ActiveSid}, {'stacktrace', erlang:get_stacktrace()}])
        end;
        (_) ->
            ok
    end,
    lists:map(F, get_config_active_state_list(Src)),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动是否处于关闭中
%% @end
%%-------------------------------------------------------------------
is_closed(Src, ActiveSid) ->
    ?CLOSE =:= z_lib:get_value(get_config_active_state_list(Src), ActiveSid, ?CLOSE).

%%-------------------------------------------------------------------
%% @doc
%%      活动是否处于停止中
%% @end
%%-------------------------------------------------------------------
is_stoped(Src, ActiveSid) ->
    ?STOP =:= z_lib:get_value(get_config_active_state_list(Src), ActiveSid, ?CLOSE).
%%-------------------------------------------------------------------
%% @doc
%%      活动数据清理
%% @end
%%-------------------------------------------------------------------
-spec clear(atom(), atom(), active:active()) -> 'ok'.
clear(Src, Table, Active) ->
    ActiveSid = active:get_sid(Active),
    Trem = active:get_term(Active),
    F = fun(_Src1, Key, _Args, R) ->
        case Key of
            {_, ActiveSid, Trem} ->
                z_db_lib:delete(Table, Key),
                {ok, R};
            _Other ->
                {ok, R}
        end
    end,
    z_db_lib:table_iterate(Src, Table, F, [], []),
    zm_log:info(Src, ?MODULE, 'clear', "active_clear", [{'table', Table}, {active, Active}]),
    clear_award_flag(Src, ActiveSid, Trem, game_lib:get_server_key(Src, active)),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动领奖标记
%% @end
%%-------------------------------------------------------------------
update_award_flag(Src, Sid, Term, Key) ->
    F = fun(_, TimesSet) ->
        {ok, TimesSet, times_set_lib:update(TimesSet, {{Sid, Term}, 1})}
    end,
    TimesSet = z_db_lib:update(game_lib:get_table(Src, 'times_set'), Key, [], F, []),
    times_set_lib:get(TimesSet, {Sid, Term}) =/= none.


%%-------------------------------------------------------------------
%% @doc
%%      删除领奖标记,防止多期的堆集了
%% @end
%%-------------------------------------------------------------------
clear_award_flag(Src, Sid, Term, Key) ->
    F = fun(_, TimesSet) ->
        {ok, ok, times_set_lib:clear(TimesSet, {Sid, Term})}
    end,
    z_db_lib:update(game_lib:get_table(Src, 'times_set'), Key, [], F, []).