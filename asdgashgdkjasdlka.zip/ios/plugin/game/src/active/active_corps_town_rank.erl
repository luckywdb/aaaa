-module(active_corps_town_rank).

%%%=======================STATEMENT====================
-description("active_corps_town_rank").
-copyright('youkia,www.youkia.net').
-author("ljh,lvjihong@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_event/4, handle_format/3]).
-export([delete_corps_rank/2, rank_view/4]).
%%%=======================DEFINE=======================

%%%=======================INCLUDE=======================
-include("../include/active.hrl").
-include("../include/rank.hrl").

%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
-spec handle_get(atom(), integer(), term(), active:active()) -> tuple().
handle_get(Src, _RoleUid, A, Active) ->
    Format = handle_format(Src, A, Active),
    {Format, {}}.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
-spec handle_start(atom(), term(), active:active(), integer()) -> 'ok'.
handle_start(Src, _A, Active, _Time) ->
    start(Src, Active).

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
-spec handle_run(atom(), term(), active:active(), integer()) -> 'ok'.
handle_run(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
-spec handle_close(atom(), term(), active:active(), integer()) -> 'ok'.
handle_close(Src, _A, Active, _Time) ->
    stop(Src, Active),
    zm_event:notify(Src, active_clear, {?MODULE, Active}),
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
-spec handle_shut(atom(), term(), active:active(), integer()) -> 'ok'.
handle_shut(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      事件处理
%% @end
%%-------------------------------------------------------------------
-spec handle_event(atom(), term(), active:active(), tuple()) -> 'ok'.
handle_event(Src, _A, Active, {'active_corps_town_rank', Args}) ->
    {_, CorpsUid} = lists:keyfind('corps_uid', 1, Args),
    {_, TownDetail} = lists:keyfind('town_detail', 1, Args),
    NScore = add_score(Src, CorpsUid, TownDetail, Active),
    Sid = active:get_sid(Active),
    case NScore > 0 of
        true ->
            %%增加积分后,排行榜刷新
            zm_event:notify(Src, 'active_rank', [{'sid', Sid}, {'uid', CorpsUid}, {'value', NScore}, {'m', active:get_m(Active)}]);
        false ->
            %%删除排行榜
            zm_event:notify(Src, 'active_rank_delete', [{'sid', Sid}, {'uid', CorpsUid}])
    end;
handle_event(_Src, _A, _Active, _Event) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
-spec handle_format(atom(), list(), active:active()) -> tuple().
handle_format(Src, A, Active) ->
    [CorpsAwardList] = A,
    Fun = fun({Min, Max, OAwardList, AwardList}) -> {Min, Max, list_to_tuple(OAwardList), list_to_tuple(AwardList)} end,
    {
        active:format_front(Src, ?MODULE, Active),
        list_to_tuple(lists:map(Fun, CorpsAwardList))
    }.


%%-------------------------------------------------------------------
%% @doc
%%      军团解散 删除
%% @end
%%-------------------------------------------------------------------
-spec delete_corps_rank(atom(), integer()) -> term().
delete_corps_rank(Src, CorpsUid) ->
    ActiveStateList = active_db:get_active_state_list(Src),
    lists:foreach(fun({Key, State}) ->
        case State =:= ?RUN of
            true ->
                Active = active_db:get_active(Src, Key),
                z_db_lib:delete(game_lib:get_table(Src, ?MODULE), active_lib:get_role_active_key(CorpsUid, Active)),
                case Active =/= 'none' andalso active:get_m(Active) =:= ?MODULE of
                    true ->
                        {_, _, Sid} = Key,
                        zm_event:notify(Src, 'active_rank_delete', [{'sid', Sid}, {'uid', CorpsUid}]);
                    false ->
                        ok
                end;
            false ->
                ok
        end
    end, ActiveStateList).


%%-------------------------------------------------------------------
%% @doc
%%      排行榜玩家显示数据
%% @end
%%-------------------------------------------------------------------
-spec rank_view(term(), atom(), integer(), integer()) -> tuple().
rank_view(_A, Src, CorpsUid, Value) ->
    Corps = corps_db:get_corps(Src, CorpsUid),
    {CorpsUid, corps:get_name(Corps), corps:get_country(Corps), corps:get_banner(Corps), corps:get_level(Corps), Value}.

%%%=====================LOC FUNCTIONS==================
%%-------------------------------------------------------------------
%% @doc
%%
%% @end
%%-------------------------------------------------------------------
start(Src, Active) ->
    TableName = game_lib:get_table(Src),
    TableKeys = z_db_lib:transformation_tablekey(TableName, [
        {'sid_template', template_lib:get_key(Src, 'other_rank'), []}
    ]),
    z_db_lib:handle(TableName, fun start_/2, {Src, Active}, TableKeys).


%%-------------------------------------------------------------------
%% @doc
%%      新增排行榜类型
%% @end
%%-------------------------------------------------------------------
start_({_Src, Active}, [{Index1, RankTypeList}]) ->
    Sid = active:get_sid(Active),
    {ok, ok, [{Index1, lists:keystore(Sid, 1, RankTypeList, {Sid, ?MODULE})}]}.
%%-------------------------------------------------------------------
%% @doc
%%      活动结束扩展信息清理
%% @end
%%-------------------------------------------------------------------
stop(Src, Active) ->
    Sid = active:get_sid(Active),
    %%发放积分排行榜奖励
    [CorpsAwardList] = active:get_a(Active),
    rank_award(Src, Active, CorpsAwardList),
    rank_db:clear_ranks(Src, Sid).

%%-------------------------------------------------------------------
%% @doc
%%      发放排行榜奖励
%% @end
%%-------------------------------------------------------------------
-spec rank_award(atom(), active:active(), [{integer(), integer(), list()}]) -> term().
rank_award(Src, Active, AwardList) ->
    Key = game_lib:get_server_key(Src, active),
    Sid = active:get_sid(Active),
    Term = active:get_term(Active),
    case active_db:update_award_flag(Src, Sid, Term, Key) of
        false ->
            %%刷新一次排行榜
            rank_refresh:timer_refresh(Src, [[Sid]], []),
            AllRank = get_max_rank(AwardList),
            %%TODO 分多次取
            RankActions = rank_get:get_rank_range(Src, Sid, 1, AllRank),
            RanksSize = erlang:length(RankActions),
            ActiveName = active:get_name(Active),
            [send_mail(Src, {Award1, Award2}, RankActions, RanksSize, MinRank, MaxRank, ActiveName) || {MinRank, MaxRank, Award1, Award2} <- AwardList];
        true ->
            'ignore'
    end.

%%-------------------------------------------------------------------
%% @doc
%%      发放邮件
%% @end
%%-------------------------------------------------------------------
send_mail(_Src, _Award, _Ranks, RanksSize, MinRank, _MaxRank, _ActiveName) when RanksSize < MinRank ->
    'ignore';
send_mail(Src, {Award1, Award2}, Ranks, RanksSize, MinRank, MaxRank, ActiveName) ->
    AllRank = if
        RanksSize > MaxRank ->
            MaxRank - MinRank + 1;
        true ->
            RanksSize - MinRank + 1
    end,
    MailType = award_source:get_source(?MODULE),
    lists:foldl(fun(Info, Rank) ->
        {CorpsUid, _Score} = Info,
        Corps = corps_db:get_corps(Src, CorpsUid),
        CorpsName = corps:get_name(Corps),
        OwnerRoleUid = corps:get_owner(Corps),
        Mail1 = mail:init({MailType, time_lib:now_second(), 0, {9, ActiveName}, {9, CorpsName, ActiveName, Rank}, Award1}),
        Mail2 = mail:init({MailType, time_lib:now_second(), 0, {9, ActiveName}, {9, CorpsName, ActiveName, Rank}, Award2}),
        lists:foreach(fun(RoleUid) ->
            case RoleUid =:= OwnerRoleUid of
                true ->
                    mail_db:send(Src, RoleUid, Mail1);
                false ->
                    mail_db:send(Src, RoleUid, Mail2)
            end
        end, corps_db:get_corps_members(Src, CorpsUid)),
        Rank + 1
    end, MinRank, lists:sublist(Ranks, MinRank, AllRank)).


%%-------------------------------------------------------------------
%% @doc
%%      获取配置的最大名次
%% @end
%%-------------------------------------------------------------------
-spec get_max_rank(list()) -> integer().
get_max_rank(ConfigList) ->
    lists:max([Max || {_, Max, _, _} <- ConfigList]).


%%-------------------------------------------------------------------
%% @doc
%%      增加积分
%% @end
%%-------------------------------------------------------------------
-spec add_score(atom(), integer(), integer(), active:active()) -> integer().
add_score(Src, CorpsUid, TownDetail, Active) ->
    Key = active_lib:get_role_active_key(CorpsUid, Active),
    F = fun(_, OldScore) ->
        NScore = OldScore + town_detail:get_score(TownDetail),
        {ok, NScore, NScore}
    end,
    z_db_lib:update(game_lib:get_table(Src, ?MODULE), Key, 0, F, []).