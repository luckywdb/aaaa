%%限时累计充值
-module(active_total_cash).

-description("active_total_cash").
-copyright('youkia,www.youkia.net').
-author("lhc,lihuachao@youkia.net").
-vsn(1).

%%%=======================EXPORT=======================
-export([handle_get/4, handle_start/4, handle_run/4, handle_close/4, handle_shut/4, handle_event/4, handle_format/3]).
-export([role_red/4, get/6]).
%%%=======================DEFINE=======================

%%%=======================INCLUDE=======================
-include("../include/active.hrl").
%%%=================EXPORTED FUNCTIONS=================
%%-------------------------------------------------------------------
%% @doc
%%      得到数据
%% @end
%%-------------------------------------------------------------------
-spec handle_get(atom(), integer(), term(), active:active()) -> tuple().
handle_get(Src, RoleUid, A, Active) ->
    Key = active_lib:get_role_active_key(RoleUid, Active),
    Format = handle_format(Src, A, Active),
    {GetItemSids, TotalCash} = z_db_lib:get(game_lib:get_table(Src, ?MODULE), Key, {[], 0}),
    {Format, {list_to_tuple(GetItemSids), TotalCash}}.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启
%% @end
%%-------------------------------------------------------------------
-spec handle_start(atom(), term(), active:active(), integer()) -> 'ok'.
handle_start(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动开启中
%% @end
%%-------------------------------------------------------------------
-spec handle_run(atom(), term(), active:active(), integer()) -> 'ok'.
handle_run(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭
%% @end
%%-------------------------------------------------------------------
-spec handle_close(atom(), term(), active:active(), integer()) -> 'ok'.
handle_close(Src, _A, Active, _Time) ->
    %%进行数据清理，异步处理
    zm_event:notify(Src, active_clear, {?MODULE, Active}),
    'ok'.

%%-------------------------------------------------------------------
%% @doc
%%      活动关闭中
%% @end
%%-------------------------------------------------------------------
-spec handle_shut(atom(), term(), active:active(), integer()) -> 'ok'.
handle_shut(_Src, _A, _Active, _Time) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      事件处理
%% @end
%%-------------------------------------------------------------------
-spec handle_event(atom(), term(), active:active(), tuple()) -> 'ok'.
handle_event(Src, _A, Active, {'cash_ok', List}) ->
    RoleUid = z_lib:get_value(List, 'role_uid', none),
    Cash = z_lib:get_value(List, 'cash_rmb', none),
    if
        RoleUid =:= none orelse Cash =:= none ->
            zm_log:warn(Src, ?MODULE, 'handle_event', "error", [{'cash_ok', List}]);
        true ->
            {ok, TotalCash} = z_db_lib:update(game_lib:get_table(Src, ?MODULE), active_lib:get_role_active_key(RoleUid, Active), {[], 0},
                fun(_, {L, V}) -> {ok, {ok, Cash + V}, {L, Cash + V}} end, none),
            set_front_lib:send_active_total_cash(Src, RoleUid, {active:get_sid(Active), TotalCash})
    end;
handle_event(_Src, _A, _Active, _Event) ->
    ok.

%%-------------------------------------------------------------------
%% @doc
%%      数据格式
%% @end
%%-------------------------------------------------------------------
-spec handle_format(atom(), list(), active:active()) -> tuple().
handle_format(Src, [ItemList], Active) ->
    F = fun({ItemSid, Rmb, AwardList}) ->
        {ItemSid, Rmb, erlang:list_to_tuple(AwardList)}
    end,
    {
        active:format_front(Src, ?MODULE, Active),
        erlang:list_to_tuple(lists:map(F, ItemList))
    }.

%%-------------------------------------------------------------------
%% @doc
%%      是否有红点
%% @end
%%-------------------------------------------------------------------
-spec role_red(atom(), integer(), list(), active:active()) -> 0|1.
role_red(Src, RoleUid, [ItemList], Active) ->
    {GetItemSids, TotalCash} = z_db_lib:get(game_lib:get_table(Src, ?MODULE), active_lib:get_role_active_key(RoleUid, Active), {[], 0}),
    Bool = lists:any(fun({ItemSid, Rmb, _}) ->
        TotalCash >= Rmb andalso not lists:member(ItemSid, GetItemSids) end, ItemList),
    if
        Bool ->
            1;
        true ->
            0
    end.

%%-------------------------------------------------------------------
%% @doc
%%      领取
%% @end
%%-------------------------------------------------------------------
-spec get(atom(), integer(), active:active(), integer(), list(), term()) -> tuple()|string().
get(Src, RoleUid, Active, ItemSid, [ItemList], _) ->
    case lists:keyfind(ItemSid, 1, ItemList) of
        false ->
            "input_error";
        {ItemSid, Number, AwardList} ->
            F = fun(_, {GetItemSids, TotalCash}) ->
                case lists:member(ItemSid, GetItemSids) of
                    false ->
                        if
                            TotalCash >= Number ->
                                {ok, ok, {[ItemSid | GetItemSids], TotalCash}};
                            true ->
                                throw("no_enough")
                        end;
                    true ->
                        throw("already_get")
                end
            end,
            case z_db_lib:update(game_lib:get_table(Src, ?MODULE), active_lib:get_role_active_key(RoleUid, Active), {[], 0}, F, []) of
                ok ->
%%            AwardLog = awarder_game:give_award(Src, RoleUid, [], AwardList),
%%            zm_event:notify(Src, 'bi_active_total_cash', [{'role_uid', RoleUid}, {'active', Active}, {'itemsid', ItemSid}, {'number', Number}, {'awards', AwardLog}]),
                    {ok, AwardList};
                Err ->
                    Err
            end
    end.

%%%====================LOC FUNCTIONS===================
