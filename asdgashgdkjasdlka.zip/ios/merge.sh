#!/bin/sh

#引入服务器配置
source ./work_dir.info
#主服务器db路径
main_db_dir=./db
#副服务器db列表路径
dir_ass=./merge_db
#合服日志文件
merge_log=./log/merge.log
#阶段1完成后会生成的文件
merge_stage_file=./boot/merge_stage1.config



#移除数据库文件夹
remove_db_dir()
{
	echo "移除数据库$1下多余快照文件夹"
	get_dir_names $1 | while read src
	do
		get_dir_names $1/$src | while read table
		do
			#包含文件夹个数
			dir_names=$(get_dir_names $1/$src/$table)
			dir_count=`echo "$dir_names" | wc -l`
			if [ "$dir_count" -gt 1 ]
			then
				#移除最大文件夹之前的所有文件夹
				let rm_dir_count=dir_count-1
				echo "$dir_names" | head -$rm_dir_count | while read rm_dir
				do
					echo "rm $1/$src/$table/$rm_dir"
					rm -rf $1/$src/$table/$rm_dir
				done
			fi
		done
	done
}

#拷贝数据表文件
copy_db()
{
	echo "开始拷贝数据库$1到$2"
	get_dir_names $1 | while read src
	do
		get_dir_names $1/$src | while read table
		do
			main_dir=$(get_dir_names $2/$src/$table | tail -1)
			max_file=$(get_file_names $2/$src/$table/$main_dir | tail -1 | sed 's/^[0]*//g')
			echo "cp $1/$src/$table $2/$src/$table"
			get_dir_names $1/$src/$table | while read ass_dir
			do
				get_file_names $1/$src/$table/$ass_dir | while read file
				do
					let max_file=max_file+1
					nfile=$(echo $max_file | awk '{printf("%05d",$0)}')
					echo "cp $1/$src/$table/$ass_dir/$file $2/$src/$table/$main_dir/$nfile"
					cp $1/$src/$table/$ass_dir/$file $2/$src/$table/$main_dir/$nfile
				done
			done
		done
	done
}

#获取文件夹下所有文件夹名字列表
get_dir_names()
{
	ls -l $1 | grep -v "total" | grep "^d" | awk '{print $NF}'
}

#获取文件夹下所有文件的名字
get_file_names()
{
	ls -l $1 | grep -v "total" | grep "^-" | awk '{print $NF}'
}

#移除数据库表多余文件夹并拷贝数据库表文件
remove_copy_db()
{
	remove_db_dir "$main_db_dir"
	if [ "$?" -eq 0 ]
    then
        reset_db_dir_name "$main_db_dir"
        ls -l $dir_ass | grep -v "total" | grep "^d" | awk '{print $NF}' | while read server
        do
            remove_db_dir "$dir_ass/$server"
            copy_db $dir_ass/$server $main_db_dir
        done
    else
        echo "清理数据库$(main_db_dir)失败"
        exit 1
    fi
}

#重置数据库下所有表名 00001开始
reset_db_dir_name()
{
    echo "重命名数据库$1下所有表名"
    get_dir_names $1 | while read src
    do
        get_dir_names $1/$src | while read table
        do
            max_file=1
            tabdir=$1/$src/$table
            get_dir_names $tabdir | while read dir_name
            do
                ndir_name=$(echo $max_file | awk '{printf("%05d",$0)}')
                dbdir=$tabdir/$ndir_name
                if [ "ndir_name" != "$dir_name" ]
                then
                    mv $tabdir/$dir_name $dbdir
                fi
				
                let omax_file=max_file
				file_names=$(get_file_names $dbdir)
                file_count=`echo "$file_names" | wc -l`
                echo "$file_names" | while read file_name
                do
                    nfile_name=$(echo $max_file | awk '{printf("%05d",$0)}')
                    if [ "$nfile_name" != "$file_name" ]
                    then
                        mv $dbdir/$file_name $dbdir/$nfile_name
                    fi
                    let max_file=max_file+1
                done
                let max_file=omax_file+file_count
            done
        done
    done
}

start_merge_server()
{
	#检测服务器是否关闭
	check=`ps aux | grep beam | grep "name $node"| wc -l`
	if [ $check -eq 0 ]
	then
		#修改expen.config Emakefile        
		echo "update expend ......" >> $merge_log
		cd $server_root
		rm -f boot/expend.config
		cp expend/expend.config boot/
		rm -f boot/Emakefile
		cp expend/Emakefile boot/
		echo "update expend ok ......" >> $merge_log
		#修改端口
		echo "update port" >> $merge_log
		sh port.sh
		echo "update port ok ......" >> $merge_log
		#启动服务器
		echo "start $node ......" >> $merge_log
		cd $server_root/boot
		$erl +K true +c +sbt db +e 100000 +P 400000 -detached -hidden -boot start_sasl -config sasl -setcookie abc -name $node -statue network -env ERL_LIBS ../lib -env ERL_MAX_PORTS 400000 -eval  'merge:do(2)'
		cd $server_root
		echo "服务器启动中.....`date +%s`" >> $merge_log
	else
		echo "$node节点已经存在 !!!!" >> $merge_log
		exit 1
	fi
}

echo "resule $?"

echo "请选择步骤:"
echo "  步骤1:合服前各信息检测和处理,然后执行快照等步骤,请输入数字1,回车..."
echo "  步骤2:步骤1已执行完,清理无用快照表文件夹,拷贝所有副服务器表到主服务器,请输入数字2,回车..."
echo "  步骤3:步骤2已执行完,并且将副服务器db已拷贝到相应位置了,执行合服以及之后操作,请输入数字2,回车..."
read var_stage
if [ $var_stage = "1" ]
then
    if [ -f "$merge_stage_file" ]
    then
        echo "第一阶段已完成,请不要重复执行,如需强制执行,请删除boot目录merge_stage1.config文件后再执行."
        exit 1
    else    
        echo "是否已经备份过数据?(是:y/yes;否:n/no)"
        read var1
        if [ $var1 = "yes" -o $var1 = "y" ]
        then
            echo "是否开启外部访问防火墙?(是:y/yes;否:n/no)"
            read var2
            if [ $var2 = "yes" -o $var2 = "y" ]
            then 
                echo "是否将merge.config拷贝到所有需要合服的服务器boot目录下?(是:y/yes;否:n/no)"
                read var3
                if [ $var3 = "yes" -o $var3 = "y" ]
                then 
                    echo "是否确认过各服务器都处于可合服状态?(是:y/yes;否:n/no)"
                    read var4
                    if [ $var4 = "yes" -o $var4 = "y" ]
                    then 
                        echo "开始合服...."    
                        echo "..............阶段一....开始............................." >> $merge_log                        
                        var_cookie=$(ps -ef|grep $node|awk '{print $35}')
                        #echo $var_cookie            
                        nodename=$(echo $node | sed "s/"\""/"\'"/g")    
                        #echo $nodename
                        func=$(echo "rpc:call('"$nodename"',merge,do,[1])")
                        #echo $func
                        $erl -noshell -name merge_node@127.0.0.1 -setcookie $var_cookie -eval $func -s init stop
                        tail -n 100000 -f $merge_log               
                    else
                        echo "未确认各服务器是否可合服!"
                        exit 0
                    fi
                else
                    echo "未将merge.config文件拷贝到所有需要合服的服务器!"
                    exit 0
                fi 
            else
                echo "未开启外部访问防火墙!"
                exit 0
            fi    
        else
            echo "未备份数据,请先备份各服务器数据!"
            exit 0
        fi
    fi
elif [ $var_stage = "2" ]
then
	echo "阶段1是否执行完成,并没有错误?(是:y/yes;否:n/no)"
    read var1
    if [ $var1 = "yes" -o $var1 = "y" ]
    then
        if [ -f "$merge_stage_file" ]
        then
            check=`ps aux | grep beam | grep "name $node"| wc -l`
            if [ $check -eq 0 ]
            then
                remove_copy_db
                if [ "$?" -eq 0 ]
                then
                    echo "..............阶段二..拷贝数据库成功..............................." >> $merge_log                        
                    echo "拷贝数据库成功"
                else
                    echo "拷贝数据库成功失败"
                fi
            else
                echo "$node节点已经存在 !!!!"
                exit 1
            fi
		else
		    echo "$merge_stage_file文件不存在"
		    exit 1
		fi
    else
        echo "阶段1有误,请先处理错误!"
        exit 0
    fi
else
    echo "拷贝数据库是否执行完成,并没有错误?(是:y/yes;否:n/no)"
    read var1
    if [ $var1 = "yes" -o $var1 = "y" ]
    then
		check=`ps aux | grep beam | grep "name $node"| wc -l`
		if [ $check -eq 0 ]
		then
			#清除日志
			echo "..............阶段三...开始.............................." >> $merge_log
			start_merge_server
			if [ "$?" -eq 0 ]
			then
				tail -f $merge_log
                exit 1
			fi    
		else
			echo "$node节点已经存在 !!!!"
			exit 1
		fi
    else
        echo "阶段1有误,请先处理错误!"
        exit 0
    fi
fi    
echo "结束"



